"""
VM_FAWN Auto Runner - Automated VM_FAWN Execution
==================================================

Automatically runs VM_FAWN parser on .mp files and generates Excel output.
Used by STAG for on-the-fly VM_FAWN execution during graph indexing.

Author: STAG Integration
"""

import os
import sys
import shutil
from pathlib import Path
from typing import Optional
import tempfile
from loguru import logger


class VMFAWNAutoRunner:
    """Automatically run VM_FAWN parser and generate Excel output"""

    def __init__(self, vm_fawn_dir: str = None, output_dir: str = None):
        """
        Initialize VM_FAWN auto runner

        Args:
            vm_fawn_dir: Path to VM_FAWN directory (default: parsers/abinitio/vm_fawn)
            output_dir: Path for VM_FAWN Excel output (default: Input Files/VM_FAWN/bbi_preprocessing_output)
        """
        if vm_fawn_dir is None:
            vm_fawn_dir = Path(__file__).parent / "vm_fawn"
        else:
            vm_fawn_dir = Path(vm_fawn_dir)

        if output_dir is None:
            output_dir = Path("Input Files/VM_FAWN/bbi_preprocessing_output")
        else:
            output_dir = Path(output_dir)

        self.vm_fawn_dir = vm_fawn_dir.resolve()
        self.output_dir = output_dir.resolve()

        # Ensure output directory exists
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # Add VM_FAWN to Python path
        if str(self.vm_fawn_dir) not in sys.path:
            sys.path.insert(0, str(self.vm_fawn_dir))

        logger.info(f"VM_FAWN Auto Runner initialized")
        logger.info(f"  VM_FAWN directory: {self.vm_fawn_dir}")
        logger.info(f"  Output directory: {self.output_dir}")

    def run_vm_fawn(self, mp_file_path: str) -> Optional[Path]:
        """
        Run VM_FAWN parser on .mp file and generate Excel

        Args:
            mp_file_path: Path to .mp file

        Returns:
            Path to generated Excel file, or None if failed
        """
        mp_file = Path(mp_file_path).resolve()

        if not mp_file.exists():
            logger.error(f"MP file not found: {mp_file}")
            return None

        logger.info(f"Running VM_FAWN on: {mp_file.name}")

        # Import VM_FAWN modules (direct import since we're in vm_fawn directory)
        try:
            import parser as vm_fawn_parser
            import utils as vm_fawn_utils
            import config as vm_fawn_config
            import pandas as pd
        except ImportError as e:
            logger.error(f"Failed to import VM_FAWN modules: {e}")
            logger.error(f"Current sys.path: {sys.path[:3]}")
            logger.error(f"Current directory: {os.getcwd()}")
            return None

        # Create temporary working directories
        temp_base = Path(tempfile.mkdtemp(prefix="vm_fawn_run_"))
        upload_folder = temp_base / "upload"
        text_folder = temp_base / "text"
        upload_folder.mkdir(parents=True, exist_ok=True)
        text_folder.mkdir(parents=True, exist_ok=True)

        original_dir = os.getcwd()

        try:
            # Change to VM_FAWN directory (required for relative imports)
            os.chdir(str(self.vm_fawn_dir))

            logger.info("  Loading VM_FAWN patterns...")
            patterns, pattern_file = vm_fawn_parser.load_patterns()

            logger.info("  Converting MP to TXT...")
            # Copy .mp file to upload folder
            shutil.copy(str(mp_file), str(upload_folder / mp_file.name))

            # Convert MP to TXT
            file_path, sandbox_file_path, original_filename = vm_fawn_utils.mp_to_txt(
                upload_folder=str(upload_folder),
                text_folder=str(text_folder),
                sandbox_file_path=str(upload_folder / mp_file.name),
                timestamp="auto"
            )

            logger.info("  Parsing with VM_FAWN...")
            # Read and parse
            content = vm_fawn_utils.read_file(file_path)
            blockset = vm_fawn_parser.extract_blocks(content)
            block_with_internal, blocks_by_graph = vm_fawn_parser.extract_and_store_blocks(content, patterns)
            unique_id_blocks = {gid: blocks for gid, blocks in blocks_by_graph.items()}
            block_dicts = vm_fawn_parser.parse_blocks(unique_id_blocks, patterns)
            flattened_data = vm_fawn_parser.flatten_data(block_dicts)
            df = pd.DataFrame(flattened_data)

            logger.info("  Processing and generating Excel...")
            # Process and save to our output directory (NOT temp directory)
            dataset_df, component_df, graph_param_df, csv_file = vm_fawn_parser.process_and_save_data(
                df=df,
                sandbox_file_path=str(mp_file),
                patterns=patterns,
                output_folder=str(self.output_dir),
                base_filename=original_filename,
                timestamp="auto"
            )

            graph_csv_input = vm_fawn_parser.generate_csv_from_dataframe(
                graph_param_df, str(self.output_dir), original_filename, "auto"
            )

            tracking_df = pd.DataFrame()  # No tracking file

            # Generate final Excel file
            saved_file = vm_fawn_parser.update_transform_rule_and_save(
                dataset_df, component_df, graph_param_df, tracking_df,
                csv_file, graph_csv_input, str(self.output_dir),
                original_filename, "auto"
            )

            # Cleanup pattern file
            if pattern_file and os.path.exists(pattern_file):
                os.remove(pattern_file)

            # Return to original directory
            os.chdir(original_dir)

            # Cleanup temp directories
            try:
                shutil.rmtree(temp_base)
            except Exception as e:
                logger.warning(f"Failed to cleanup temp directory: {e}")

            if saved_file:
                excel_path = self.output_dir / saved_file
                if excel_path.exists():
                    logger.info(f"✅ VM_FAWN Excel generated: {excel_path}")
                    return excel_path
                else:
                    logger.error(f"Expected Excel file not found: {excel_path}")
                    return None
            else:
                logger.error("VM_FAWN did not generate Excel file")
                return None

        except Exception as e:
            logger.error(f"VM_FAWN execution failed: {e}", exc_info=True)
            os.chdir(original_dir)
            return None


# CLI usage
if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python vm_fawn_auto_runner.py <mp_file_path>")
        print("\nExample:")
        print("  python vm_fawn_auto_runner.py 'Input Files/blade/mp/265_fileTransferToHadoopServer.mp'")
        sys.exit(1)

    mp_file = sys.argv[1]

    runner = VMFAWNAutoRunner()
    result = runner.run_vm_fawn(mp_file)

    if result:
        print(f"\n✅ Success! Excel file: {result}")
        sys.exit(0)
    else:
        print(f"\n❌ Failed to generate VM_FAWN Excel")
        sys.exit(1)
