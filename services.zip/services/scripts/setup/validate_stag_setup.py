#!/usr/bin/env python3
"""
STAG Setup Validation Script
Run this in client AVD to verify everything is ready for testing
"""

import os
import json
from pathlib import Path
from loguru import logger


def check_dependencies():
    """Check required Python packages"""
    print("\n" + "=" * 60)
    print("1. CHECKING DEPENDENCIES")
    print("=" * 60)

    required = [
        "streamlit",
        "chromadb",
        "sentence_transformers",
        "pandas",
        "openpyxl",
        "openai",
        "loguru",
    ]

    missing = []
    for package in required:
        try:
            __import__(package)
            print(f"   ✅ {package}")
        except ImportError:
            print(f"   ❌ {package} - MISSING")
            missing.append(package)

    if missing:
        print(f"\n⚠️  Install missing packages:")
        print(f"   pip install {' '.join(missing)}")
        return False

    print("\n✅ All dependencies installed")
    return True


def check_ai_provider():
    """Check AI provider configuration"""
    print("\n" + "=" * 60)
    print("2. CHECKING AI PROVIDER")
    print("=" * 60)

    # Check Azure OpenAI
    azure_key = os.getenv("AZURE_OPENAI_API_KEY")
    azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")

    if azure_key and azure_endpoint:
        print(f"   ✅ Azure OpenAI configured")
        print(f"      Endpoint: {azure_endpoint[:50]}...")
        print(f"      Deployment: {os.getenv('AZURE_OPENAI_DEPLOYMENT_NAME', 'gpt-4')}")
        return True

    # Check AWS Bedrock
    aws_key = os.getenv("AWS_ACCESS_KEY_ID")
    aws_secret = os.getenv("AWS_SECRET_ACCESS_KEY")

    if aws_key and aws_secret:
        print(f"   ✅ AWS Bedrock configured")
        print(f"      Region: {os.getenv('AWS_REGION', 'us-east-1')}")
        print(f"      ⚠️  Note: Requires IAM permission fix")
        return True

    print("   ❌ No AI provider configured")
    print("\n💡 To configure Azure OpenAI (recommended for client AVD):")
    print("   1. Create .env file:")
    print("      AZURE_OPENAI_API_KEY=your_key")
    print("      AZURE_OPENAI_ENDPOINT=your_endpoint")
    print("      AZURE_OPENAI_DEPLOYMENT_NAME=gpt-4")
    return False


def check_repositories():
    """Check repository paths"""
    print("\n" + "=" * 60)
    print("3. CHECKING REPOSITORIES")
    print("=" * 60)

    repos = {
        "Hadoop": "hadoop_repos/hadoop_repos",
        "Databricks": "Databricks_repo",
    }

    all_found = True

    for name, path in repos.items():
        full_path = Path(path)
        if full_path.exists():
            file_count = len(list(full_path.rglob("*")))
            print(f"   ✅ {name}: {path} ({file_count} files)")
        else:
            print(f"   ❌ {name}: {path} - NOT FOUND")
            all_found = False

    return all_found


def check_existing_data():
    """Check existing indexed data and checkpoints"""
    print("\n" + "=" * 60)
    print("4. CHECKING EXISTING DATA")
    print("=" * 60)

    # Check vector DB
    vector_db = Path("outputs/vector_db")
    if vector_db.exists():
        db_size = sum(f.stat().st_size for f in vector_db.rglob('*') if f.is_file())
        db_size_mb = db_size / (1024 * 1024)
        print(f"   ✅ Vector DB exists: {db_size_mb:.2f} MB")
        print(f"      ⚠️  Recommend deleting for fresh indexing: rm -rf outputs/vector_db")
    else:
        print(f"   ℹ️  No vector DB (will be created on first index)")

    # Check checkpoints
    checkpoints = Path("outputs/checkpoints")
    if checkpoints.exists():
        checkpoint_files = list(checkpoints.glob("checkpoint_*.json"))
        if checkpoint_files:
            print(f"   ✅ Found {len(checkpoint_files)} checkpoint(s)")
            for cp_file in checkpoint_files:
                with open(cp_file) as f:
                    cp_data = json.load(f)
                print(f"      - {cp_data['system_type']}: {cp_data['files_processed']}/{cp_data['total_files']}")
        else:
            print(f"   ℹ️  No checkpoints (fresh indexing)")
    else:
        print(f"   ℹ️  No checkpoint directory (will be created)")

    # Check analysis outputs
    outputs = {
        "Databricks analysis": "databricks_pipeline_analysis.json",
        "Ab Initio mappings": "abinitio_graph_mappings.json",
    }

    for name, file in outputs.items():
        if Path(file).exists():
            print(f"   ✅ {name}: {file}")
        else:
            print(f"   ℹ️  {name} not generated yet")


def check_disk_space():
    """Check available disk space"""
    print("\n" + "=" * 60)
    print("5. CHECKING DISK SPACE")
    print("=" * 60)

    import shutil

    try:
        stat = shutil.disk_usage(".")
        free_gb = stat.free / (1024 ** 3)
        used_pct = (stat.used / stat.total) * 100

        print(f"   Free space: {free_gb:.2f} GB ({100-used_pct:.1f}% available)")

        if free_gb < 1:
            print(f"   ⚠️  WARNING: Low disk space!")
            print(f"      Indexing may fail - free up space first")
            return False
        elif free_gb < 5:
            print(f"   ⚠️  Disk space is limited")
            print(f"      Monitor during indexing")
        else:
            print(f"   ✅ Sufficient disk space")

        return True

    except Exception as e:
        print(f"   ⚠️  Could not check disk space: {e}")
        return True


def test_ai_connection():
    """Test AI provider connection"""
    print("\n" + "=" * 60)
    print("6. TESTING AI CONNECTION")
    print("=" * 60)

    try:
        from services.ai_providers import MultiProviderAIClient

        client = MultiProviderAIClient()

        if not client.enabled:
            print("   ❌ No AI provider available")
            return False

        print(f"   ✅ AI Provider: {client.provider.provider_name}")
        print(f"   🔧 Testing connection...")

        response = client.chat_completion([
            {"role": "user", "content": "Say 'STAG AI is working!' in exactly those words."}
        ])

        if response and "STAG AI is working" in response:
            print(f"   ✅ AI connection successful!")
            print(f"      Response: {response[:100]}")
            return True
        else:
            print(f"   ⚠️  AI responded but unexpected output:")
            print(f"      {response[:200]}")
            return False

    except Exception as e:
        print(f"   ❌ AI connection failed: {e}")
        return False


def main():
    """Run all validation checks"""
    print("\n" + "=" * 70)
    print(" " * 20 + "STAG SETUP VALIDATION")
    print("=" * 70)

    results = {
        "Dependencies": check_dependencies(),
        "AI Provider": check_ai_provider(),
        "Repositories": check_repositories(),
        "Disk Space": check_disk_space(),
    }

    check_existing_data()

    # Test AI only if provider configured
    if results["AI Provider"]:
        results["AI Connection"] = test_ai_connection()

    # Summary
    print("\n" + "=" * 70)
    print("VALIDATION SUMMARY")
    print("=" * 70)

    all_passed = True
    for check, passed in results.items():
        status = "✅ PASS" if passed else "❌ FAIL"
        print(f"   {status}: {check}")
        if not passed:
            all_passed = False

    print("\n" + "=" * 70)

    if all_passed:
        print("🎉 ALL CHECKS PASSED - READY FOR TESTING!")
        print("\nNext steps:")
        print("1. Start STAG: streamlit run stag_app.py")
        print("2. Index systems: System Integrations tab")
        print("3. Test features: Search, Lineage, Chat, Comparison")
    else:
        print("⚠️  SOME CHECKS FAILED - FIX ISSUES ABOVE")
        print("\nRefer to: STAG_ENHANCEMENTS_COMPLETE.md for setup instructions")

    print("=" * 70)


if __name__ == "__main__":
    main()
