#!/usr/bin/env python3
"""
Reset ChromaDB Vector Database
===============================
Use this script to reset/repair a corrupted ChromaDB database

Usage:
    python reset_vector_db.py              # Interactive mode
    python reset_vector_db.py --force      # Force reset without confirmation
"""

import os
import sys
import shutil
from pathlib import Path
from loguru import logger


def reset_vector_db(db_path: str = "./outputs/vector_db", force: bool = False):
    """
    Reset the ChromaDB vector database

    Args:
        db_path: Path to the vector database
        force: If True, skip confirmation
    """
    db_path = Path(db_path)

    if not db_path.exists():
        logger.info(f"✓ Database doesn't exist at {db_path} - nothing to reset")
        return

    logger.info(f"Found ChromaDB database at: {db_path}")

    # Check size
    total_size = sum(f.stat().st_size for f in db_path.glob('**/*') if f.is_file())
    size_mb = total_size / (1024 * 1024)
    logger.info(f"Database size: {size_mb:.2f} MB")

    # List collections
    try:
        import chromadb
        from chromadb.config import Settings

        client = chromadb.PersistentClient(
            path=str(db_path),
            settings=Settings(anonymized_telemetry=False, allow_reset=True),
        )

        collections = client.list_collections()
        logger.info(f"Found {len(collections)} collections:")
        for coll in collections:
            try:
                count = coll.count()
                logger.info(f"  - {coll.name}: {count} documents")
            except Exception as e:
                logger.warning(f"  - {coll.name}: ERROR - {e}")
    except Exception as e:
        logger.warning(f"Could not read database: {e}")

    # Confirm deletion
    if not force:
        print("\n" + "="*60)
        print("⚠️  WARNING: This will DELETE the entire vector database!")
        print("="*60)
        print(f"\nPath: {db_path}")
        print(f"Size: {size_mb:.2f} MB")
        print("\nYou will need to re-index all your data after this.")
        print("\nAre you sure you want to continue? (yes/no): ", end="")

        response = input().strip().lower()

        if response != "yes":
            logger.info("❌ Reset cancelled")
            return

    # Delete the database
    logger.info(f"Deleting database at {db_path}...")

    try:
        shutil.rmtree(db_path)
        logger.info(f"✅ Successfully deleted {db_path}")
        logger.info("\n📋 Next steps:")
        logger.info("1. Restart your Streamlit app")
        logger.info("2. Re-index your data:")
        logger.info("   - Go to Index Management tab")
        logger.info("   - Upload or index from directory")
        logger.info("3. Verify indexing completes successfully")
    except Exception as e:
        logger.error(f"❌ Failed to delete database: {e}")
        logger.error(f"💡 Try manually: rm -rf {db_path}")
        sys.exit(1)


def backup_vector_db(db_path: str = "./outputs/vector_db"):
    """
    Create a backup of the vector database before resetting

    Args:
        db_path: Path to the vector database
    """
    db_path = Path(db_path)

    if not db_path.exists():
        logger.warning(f"No database found at {db_path}")
        return

    from datetime import datetime
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = Path(f"{db_path}_backup_{timestamp}")

    logger.info(f"Creating backup at {backup_path}...")

    try:
        shutil.copytree(db_path, backup_path)
        logger.info(f"✅ Backup created: {backup_path}")
        return str(backup_path)
    except Exception as e:
        logger.error(f"❌ Backup failed: {e}")
        return None


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="Reset corrupted ChromaDB vector database",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python reset_vector_db.py                    # Interactive reset
  python reset_vector_db.py --force            # Force reset
  python reset_vector_db.py --backup           # Backup before reset
  python reset_vector_db.py --path ./my_db     # Custom path
        """
    )

    parser.add_argument(
        "--force",
        action="store_true",
        help="Force reset without confirmation"
    )

    parser.add_argument(
        "--backup",
        action="store_true",
        help="Create backup before resetting"
    )

    parser.add_argument(
        "--path",
        type=str,
        default="./outputs/vector_db",
        help="Path to vector database (default: ./outputs/vector_db)"
    )

    args = parser.parse_args()

    print("="*60)
    print("ChromaDB Vector Database Reset Tool")
    print("="*60)
    print()

    # Backup if requested
    if args.backup:
        backup_path = backup_vector_db(args.path)
        if backup_path:
            print(f"\n✅ Backup saved to: {backup_path}")
            print()

    # Reset
    reset_vector_db(args.path, args.force)
