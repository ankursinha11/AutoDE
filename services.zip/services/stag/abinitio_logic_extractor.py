"""
Ab Initio Logic Extractor

Extracts logic and transformations from Ab Initio graphs using:
1. Enhanced Parser results (parsed JSON components)
2. VM_Automation pipeline (step1 → step2 → step3) for detailed STTM
3. Vector search to find graph documents
4. DML/XFR file analysis
5. Graph flow reconstruction

Handles:
- Graph components (vertices, flows, ports)
- Component transformations
- Data flow paths
- DML schema definitions
- XFR transformation rules
- Detailed attribute-level mappings via VM_Automation
"""

from pathlib import Path
from typing import Dict, List, Any, Optional
from loguru import logger
import json

# Import VM_Automation components
try:
    from parsers.abinitio.automation import AbInitioSTTMGenerator
    from parsers.abinitio import EnhancedAbInitioParser
    VM_AUTOMATION_AVAILABLE = True
except ImportError:
    VM_AUTOMATION_AVAILABLE = False
    AbInitioSTTMGenerator = None
    EnhancedAbInitioParser = None


class AbInitioLogicExtractor:
    """Extract logic from Ab Initio graphs using Enhanced Parser and VM_Automation"""

    def __init__(self, indexer=None, ai_analyzer=None, blade_path: str = None):
        """
        Initialize Ab Initio Logic Extractor

        Args:
            indexer: MultiCollectionIndexer for vector search
            ai_analyzer: AIAnalyzer for natural language extraction
            blade_path: Path to blade directory containing mp, dml, xfr files
        """
        self.indexer = indexer
        self.ai_analyzer = ai_analyzer
        self.blade_path = blade_path or "Input Files/blade"

        # Initialize VM_Automation generator if available
        self.automation_generator = None
        if VM_AUTOMATION_AVAILABLE and ai_analyzer:
            try:
                self.automation_generator = AbInitioSTTMGenerator(
                    blade_path=self.blade_path,
                    output_folder="outputs/sttm_abinitio",
                    ai_analyzer=ai_analyzer
                )
                logger.info("✅ VM_Automation integrated for AbInitio STTM generation")
            except Exception as e:
                logger.warning(f"Could not initialize VM_Automation: {e}")
                self.automation_generator = None

    def extract_logic(self, graph_name: str) -> Dict[str, Any]:
        """
        Extract comprehensive logic from Ab Initio graph

        Args:
            graph_name: Name of the Ab Initio graph (.mp file or .pset)

        Returns:
            {
                'graph_name': str,
                'system': 'abinitio',
                'steps': [
                    {
                        'step_number': str,
                        'dataset': str,
                        'transformation_rules': str,
                        'components': List[str],
                        'inputs': List[str],
                        'outputs': List[str]
                    }
                ],
                'graph_flow': str,
                'dml_files': List[str],
                'total_vertices': int,
                'total_flows': int
            }
        """
        logger.info(f"📊 Extracting logic for Ab Initio graph: {graph_name}")

        # Step 1: Search for graph in vector DB
        graph_docs = self._search_graph_documents(graph_name)

        if not graph_docs:
            logger.warning(f"No documents found for graph: {graph_name}")
            return self._create_empty_result(graph_name)

        # Step 2: Get parsed JSON path from metadata
        parsed_json_path = self._get_parsed_json_path(graph_docs)

        # Step 3: Load parsed components if available
        parsed_components = self._load_parsed_components(parsed_json_path)

        # Step 4: Extract steps from components
        if parsed_components:
            steps = self._extract_steps_from_components(parsed_components)
            graph_flow = self._build_graph_flow(parsed_components)
            dml_files = self._extract_dml_files(parsed_components)
        else:
            # Fallback: Extract from document content using AI
            steps = self._extract_steps_with_ai(graph_docs, graph_name)
            graph_flow = "Graph flow not available (no parsed components)"
            dml_files = []

        # Step 5: Generate detailed STTM using VM_Automation if available
        automation_sttm = None
        automation_excel = None
        if self.automation_generator and parsed_json_path:
            try:
                logger.info(f"   🔄 Generating detailed STTM using VM_Automation...")
                automation_result = self.automation_generator.generate_sttm_from_parsed_json(
                    parsed_json_path
                )
                if automation_result.get('success'):
                    automation_sttm = automation_result.get('mapping_json')
                    automation_excel = automation_result.get('excel_file')
                    logger.info(f"   ✅ VM_Automation STTM generated: {automation_excel}")
                else:
                    logger.warning(f"   ⚠ VM_Automation failed: {automation_result.get('error')}")
            except Exception as e:
                logger.warning(f"   ⚠ VM_Automation error: {e}")

        result = {
            'graph_name': graph_name,
            'system': 'abinitio',
            'steps': steps,
            'graph_flow': graph_flow,
            'dml_files': dml_files,
            'total_vertices': len(parsed_components.get('vertices', {})) if parsed_components else 0,
            'total_flows': len(parsed_components.get('flows', {})) if parsed_components else 0,
            'total_steps': len(steps),
            # VM_Automation outputs
            'automation_sttm_json': automation_sttm,
            'automation_sttm_excel': automation_excel,
            'parsed_json_path': parsed_json_path
        }

        logger.info(f"✅ Extracted {len(steps)} steps from Ab Initio graph: {graph_name}")
        return result

    def generate_detailed_sttm(self, graph_name: str) -> Dict[str, Any]:
        """
        Generate detailed STTM for AbInitio graph using VM_Automation pipeline

        This is the main method for production-quality STTM generation.
        Uses the 3-step pipeline:
        1. step1: Extract graph details
        2. step2: Embed DML/XFR content
        3. step3: Generate STTM mapping with AI

        Args:
            graph_name: Name of the Ab Initio graph

        Returns:
            {
                'success': bool,
                'graph_name': str,
                'excel_file': str,  # Path to generated Excel
                'mapping_json': str,  # Path to JSON mapping
                'column_count': int,
                'error': str  # If failed
            }
        """
        logger.info(f"📊 Generating detailed STTM for: {graph_name}")

        if not self.automation_generator:
            return {
                'success': False,
                'graph_name': graph_name,
                'error': 'VM_Automation not available. Initialize with ai_analyzer.'
            }

        # Step 1: Find parsed JSON path
        graph_docs = self._search_graph_documents(graph_name)
        parsed_json_path = self._get_parsed_json_path(graph_docs) if graph_docs else None

        if not parsed_json_path:
            # Try to find it directly in the output folder
            parsed_folder = Path("outputs/parsed_abinitio")
            graph_name_clean = graph_name.replace(".pset", "").replace(".mp", "")

            for pattern in [f"{graph_name_clean}_components.json", f"*{graph_name_clean}*_components.json"]:
                matches = list(parsed_folder.glob(pattern))
                if matches:
                    parsed_json_path = str(matches[0])
                    break

        if not parsed_json_path:
            return {
                'success': False,
                'graph_name': graph_name,
                'error': f'Parsed JSON not found for {graph_name}. Run indexing first.'
            }

        # Step 2: Generate STTM using VM_Automation
        result = self.automation_generator.generate_sttm_from_parsed_json(parsed_json_path)

        if result.get('success'):
            # Load mapping to get column count
            column_count = 0
            if result.get('mapping_json') and Path(result['mapping_json']).exists():
                try:
                    with open(result['mapping_json'], 'r') as f:
                        mapping_data = json.load(f)
                        column_count = len(mapping_data) if isinstance(mapping_data, list) else 0
                except:
                    pass

            return {
                'success': True,
                'graph_name': graph_name,
                'excel_file': result.get('excel_file'),
                'mapping_json': result.get('mapping_json'),
                'column_count': column_count,
                'parsed_json_path': parsed_json_path
            }
        else:
            return {
                'success': False,
                'graph_name': graph_name,
                'error': result.get('error', 'Unknown error')
            }

    def _search_graph_documents(self, graph_name: str) -> List[Dict[str, Any]]:
        """Search for graph documents in vector DB"""
        if not self.indexer:
            logger.warning("No indexer provided - cannot search for graph documents")
            return []

        try:
            # Search in abinitio_collection
            search_results = self.indexer.search_multi_collection(
                query=f"Ab Initio graph {graph_name} vertices flows components",
                collections=["abinitio_collection"],
                top_k=10
            )

            abinitio_docs = search_results.get('abinitio_collection', [])
            logger.info(f"   Found {len(abinitio_docs)} Ab Initio documents for {graph_name}")

            return abinitio_docs

        except Exception as e:
            logger.error(f"Failed to search graph documents: {e}")
            return []

    def _get_parsed_json_path(self, graph_docs: List[Dict[str, Any]]) -> Optional[str]:
        """Extract parsed JSON path from graph document metadata"""
        if not graph_docs:
            return None

        # Get the first document's metadata
        metadata = graph_docs[0].get('metadata', {})
        parsed_json_path = metadata.get('parsed_json_path', '')

        if parsed_json_path and Path(parsed_json_path).exists():
            logger.info(f"   Found parsed JSON: {parsed_json_path}")
            return parsed_json_path
        else:
            logger.warning(f"   Parsed JSON not found: {parsed_json_path}")
            return None

    def _load_parsed_components(self, parsed_json_path: Optional[str]) -> Optional[Dict[str, Any]]:
        """Load parsed components from JSON file"""
        if not parsed_json_path:
            return None

        try:
            with open(parsed_json_path, 'r') as f:
                components = json.load(f)
                logger.info(f"   ✅ Loaded parsed components: {len(components.get('vertices', {}))} vertices")
                return components
        except Exception as e:
            logger.error(f"Failed to load parsed components: {e}")
            return None

    def _extract_steps_from_components(self, components: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Extract steps from parsed Ab Initio components with DEEP AI analysis (AI PRIMARY)"""
        steps = []
        vertices = components.get('vertices', {})
        flows = components.get('flows', {})

        logger.info(f"   Analyzing {len(vertices)} vertices with DEEP AI component analysis...")

        # Process each vertex with deep analysis
        for vertex_id, vertex in vertices.items():
            vertex_name = vertex.get('name', 'Unknown')
            component_type = vertex.get('component_type', 'Unknown')
            raw_content = vertex.get('raw_content', '')

            # Determine inputs/outputs from flows
            inputs, outputs = self._get_vertex_inputs_outputs(vertex_id, flows)

            # DEEP COMPONENT ANALYSIS
            component_analysis = self._analyze_component_deeply(
                component_name=vertex_name,
                component_type=component_type,
                raw_content=raw_content,
                graph_name=components.get('graph_name', 'Unknown')
            )

            # Create step with enhanced details
            step = {
                'step_number': str(len(steps) + 1),
                'dataset': vertex_name,
                'component_type': component_type,
                'transformation_rules': component_analysis.get('transformation_rules', ''),
                'step_by_step_logic': component_analysis.get('step_by_step_logic', []),
                'inputs': inputs,
                'outputs': outputs,
                'components': [vertex_name],
                'schema_info': component_analysis.get('schema_info', {}),
                'dml_files': component_analysis.get('dml_files', []),
                'xfr_files': component_analysis.get('xfr_files', [])
            }

            steps.append(step)

        logger.info(f"   ✅ Deeply analyzed {len(steps)} components from Ab Initio graph")
        return steps

    def _analyze_component_deeply(
        self,
        component_name: str,
        component_type: str,
        raw_content: str,
        graph_name: str
    ) -> Dict[str, Any]:
        """
        DEEP AI-powered analysis of Ab Initio component using FAWN outputs

        Returns:
            {
                'transformation_rules': str,  # Summary of transformation
                'step_by_step_logic': List[str],  # 10-30 detailed steps
                'schema_info': Dict,  # DML/schema details
                'dml_files': List[str],  # Referenced DML files
                'xfr_files': List[str]  # Referenced XFR files
            }
        """
        logger.debug(f"   🔍 Deep analyzing component: {component_name}")

        # Try AI analysis first if available
        if self.ai_analyzer and self.ai_analyzer.enabled and raw_content:
            try:
                # Enhanced AI prompt for EXHAUSTIVE detail
                prompt = f"""
Analyze this Ab Initio component in EXHAUSTIVE detail.

Graph: {graph_name}
Component Name: {component_name}
Component Type: {component_type}

Component Definition:
{raw_content[:50000]}

Provide a COMPREHENSIVE analysis:

1. **Transformation Summary** (2-3 sentences describing what this component does)

2. **Step-by-Step Logic** (10-30 DETAILED steps):
   - For each transformation/operation, describe EXACTLY what happens
   - Include column names, formulas, conditions
   - Example: "Extract hospital_fk by splitting composite_id on '_' and taking first element"
   - Example: "Filter records where status_code IN ('ACTIVE', 'PENDING')"
   - Example: "Join patient_accounts with permid_lookup on account_number"
   - Be EXHAUSTIVE - aim for 10-30 steps

3. **Schema Information**:
   - Input schema/DML files referenced
   - Output schema/DML files referenced
   - Record formats
   - Key fields

4. **Referenced Files**:
   - DML files (schema definitions)
   - XFR files (transformation rules)

Return JSON format:
{{
  "transformation_rules": "Summary of what this component does...",
  "step_by_step_logic": [
    "Step 1: Detailed description...",
    "Step 2: Detailed description...",
    ...
  ],
  "schema_info": {{
    "input_dml": ["file1.dml"],
    "output_dml": ["file2.dml"],
    "record_format": "..."
  }},
  "dml_files": ["file1.dml", "file2.dml"],
  "xfr_files": ["transform1.xfr"]
}}

CRITICAL: Provide EXHAUSTIVE detail. Aim for 10-30 step-by-step logic items.
"""

                ai_response = self.ai_analyzer.analyze_code(
                    code=raw_content[:50000],  # Larger limit for Ab Initio
                    context=prompt,
                    analysis_type="deep_component_analysis"
                )

                # Parse AI response
                analysis = self._parse_component_analysis_response(ai_response)

                if analysis and analysis.get('step_by_step_logic'):
                    logger.debug(f"   ✅ AI analysis: {len(analysis['step_by_step_logic'])} steps")
                    return analysis
                else:
                    logger.warning(f"   ⚠ AI analysis incomplete for {component_name}")

            except Exception as e:
                logger.warning(f"   ❌ AI deep analysis failed: {e}")

        # FALLBACK: Basic analysis
        return self._basic_component_analysis(component_name, component_type, raw_content)

    def _parse_component_analysis_response(self, ai_response: str) -> Dict[str, Any]:
        """Parse AI component analysis response"""
        import re

        try:
            # Extract JSON from response
            json_match = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', ai_response, re.DOTALL)
            if json_match:
                json_str = json_match.group(1)
            else:
                json_match = re.search(r'\{.*\}', ai_response, re.DOTALL)
                if json_match:
                    json_str = json_match.group(0)
                else:
                    return {}

            analysis = json.loads(json_str)
            return analysis

        except Exception as e:
            logger.debug(f"Failed to parse AI component analysis: {e}")
            return {}

    def _basic_component_analysis(
        self,
        component_name: str,
        component_type: str,
        raw_content: str
    ) -> Dict[str, Any]:
        """Basic component analysis when AI is unavailable"""
        import re

        # Extract DML files
        dml_files = list(set(re.findall(r'(\w+\.dml)', raw_content, re.IGNORECASE)))

        # Extract XFR files
        xfr_files = list(set(re.findall(r'(\w+\.xfr)', raw_content, re.IGNORECASE)))

        # Basic transformation description
        transformation = self._get_transformation_description({'name': component_name}, component_type)

        return {
            'transformation_rules': transformation,
            'step_by_step_logic': [f"Execute {component_type} transformation on {component_name}"],
            'schema_info': {
                'input_dml': dml_files,
                'output_dml': [],
                'record_format': 'Unknown'
            },
            'dml_files': dml_files,
            'xfr_files': xfr_files
        }

    def _get_transformation_description_with_ai(self, vertex: Dict[str, Any], component_type: str, raw_content: str) -> Optional[str]:
        """Use AI to extract transformation description from vertex"""
        if not self.ai_analyzer or not self.ai_analyzer.enabled or not raw_content:
            return None

        try:
            # Use AI to analyze the component
            ai_response = self.ai_analyzer.analyze_code(
                code=raw_content[:2000],  # Limit content
                context=f"Ab Initio component type: {component_type}",
                analysis_type="transformation_explanation"
            )

            if ai_response and len(ai_response.strip()) > 10:
                logger.debug(f"   ✅ AI extracted transformation for {vertex.get('name', 'Unknown')}")
                return ai_response.strip()
            else:
                return None

        except Exception as e:
            logger.debug(f"   AI transformation extraction failed: {e}")
            return None

    def _get_vertex_inputs_outputs(self, vertex_id: str, flows: Dict[str, Any]) -> tuple:
        """Get inputs and outputs for a vertex from flow connections"""
        inputs = []
        outputs = []

        for flow_id, flow in flows.items():
            flow_name = flow.get('name', 'Unknown')

            # Check flow connections (this would require flow_connections data)
            # For now, use a simple heuristic
            # TODO: Use flow_connections from parsed components

            # Placeholder logic
            if 'input' in flow_name.lower():
                inputs.append(flow_name)
            elif 'output' in flow_name.lower():
                outputs.append(flow_name)

        return inputs, outputs

    def _get_transformation_description(self, vertex: Dict[str, Any], component_type: str) -> str:
        """Get transformation description for a vertex"""
        # Map component types to transformation descriptions
        type_descriptions = {
            'XXGfvertex_input': 'Read input data',
            'XXGfvertex_output': 'Write output data',
            'XXGfvertex_join': 'Join datasets',
            'XXGfvertex_filter': 'Filter records',
            'XXGfvertex_transform': 'Transform data',
            'XXGfvertex_aggregate': 'Aggregate data',
            'XXGfvertex_lookup': 'Lookup reference data',
            'XXGfvertex_sort': 'Sort records',
            'XXGfvertex_dedup': 'Remove duplicates',
        }

        # Get description from component type
        for key, desc in type_descriptions.items():
            if key in component_type:
                return desc

        # Default description
        return f"Execute {component_type} component"

    def _build_graph_flow(self, components: Dict[str, Any]) -> str:
        """Build graph flow description from components"""
        vertices = components.get('vertices', {})
        flows = components.get('flows', {})

        if not vertices:
            return "Empty graph"

        # Build simple flow description
        vertex_names = [v.get('name', 'Unknown') for v in vertices.values()]

        if len(vertex_names) <= 5:
            return " → ".join(vertex_names)
        else:
            return f"{' → '.join(vertex_names[:3])} → ... → {vertex_names[-1]} ({len(vertex_names)} total vertices)"

    def _extract_dml_files(self, components: Dict[str, Any]) -> List[str]:
        """Extract DML file references from components"""
        dml_files = []

        # Look for DML references in vertex raw content
        vertices = components.get('vertices', {})

        for vertex in vertices.values():
            raw_content = vertex.get('raw_content', '')

            # Pattern: Look for .dml file references
            import re
            dml_matches = re.findall(r'(\w+\.dml)', raw_content, re.IGNORECASE)
            dml_files.extend(dml_matches)

        return list(set(dml_files))

    def _extract_steps_with_ai(self, graph_docs: List[Dict[str, Any]], graph_name: str) -> List[Dict[str, Any]]:
        """Extract steps using AI analysis (AI PRIMARY)"""
        if not graph_docs:
            logger.warning("   No graph documents to analyze")
            return []

        # AI PRIMARY: Try AI first
        if self.ai_analyzer and self.ai_analyzer.enabled:
            try:
                # Combine document content
                combined_content = "\n\n".join([
                    f"Document: {doc.get('metadata', {}).get('file_name', 'Unknown')}\n{doc.get('content', '')}"
                    for doc in graph_docs
                ])

                # AI prompt
                prompt = f"""
Analyze this Ab Initio graph and extract transformation steps.

Graph Name: {graph_name}

Graph Content:
{combined_content[:20000]}

Extract the following for each transformation step:
1. Step number
2. Dataset/component name
3. Transformation rules
4. Input datasets
5. Output datasets

Return a structured JSON array with this format:
[
  {{
    "step_number": "1",
    "dataset": "Component_Name",
    "transformation_rules": "Description of transformation",
    "components": ["Component_Name"],
    "inputs": ["input1"],
    "outputs": ["output1"]
  }}
]
"""

                # Use analyze_code method
                ai_response = self.ai_analyzer.analyze_code(
                    code=combined_content[:20000],
                    context=f"Ab Initio graph: {graph_name}",
                    analysis_type="workflow_extraction"
                )

                steps = self._parse_ai_response_to_steps(ai_response)

                if steps:
                    logger.info(f"   ✅ AI extracted {len(steps)} steps")
                    return steps
                else:
                    logger.warning("   AI returned empty step list")

            except Exception as e:
                logger.error(f"   ❌ AI extraction failed: {e}")

        # FALLBACK: Return empty if AI fails
        logger.warning("   ⚠ AI extraction unavailable or failed - returning empty")
        return []

    def _parse_ai_response_to_steps(self, ai_response: str) -> List[Dict[str, Any]]:
        """Parse AI response into step structures"""
        import re

        try:
            # Try to extract JSON array from response
            json_match = re.search(r'```(?:json)?\s*(\[.*?\])\s*```', ai_response, re.DOTALL)
            if json_match:
                json_str = json_match.group(1)
            else:
                json_match = re.search(r'\[.*\]', ai_response, re.DOTALL)
                if json_match:
                    json_str = json_match.group(0)
                else:
                    return []

            steps = json.loads(json_str)

            if isinstance(steps, list):
                return steps
            else:
                return []

        except Exception as e:
            logger.warning(f"Failed to parse AI response as JSON: {e}")
            return []

    def _create_empty_result(self, graph_name: str) -> Dict[str, Any]:
        """Create empty result when no graph found"""
        return {
            'graph_name': graph_name,
            'system': 'abinitio',
            'steps': [],
            'graph_flow': '',
            'dml_files': [],
            'total_vertices': 0,
            'total_flows': 0,
            'total_steps': 0
        }


# Example usage
if __name__ == "__main__":
    # Test without indexer/AI
    extractor = AbInitioLogicExtractor()

    print("\n" + "=" * 80)
    print("AB INITIO LOGIC EXTRACTOR TEST")
    print("=" * 80)

    test_graph = "1300_CDD_PatientAcctsXRefPermID.pset"

    print(f"\nTesting graph: {test_graph}")
    print("Note: Without indexer/AI, this will return empty result")

    result = extractor.extract_logic(test_graph)

    print(f"\n✅ Extraction Result:")
    print(f"   Graph: {result['graph_name']}")
    print(f"   System: {result['system']}")
    print(f"   Total Steps: {result['total_steps']}")
    print(f"   Total Vertices: {result['total_vertices']}")
    print(f"   Total Flows: {result['total_flows']}")
    print(f"   Graph Flow: {result['graph_flow']}")
    print(f"   DML Files: {len(result['dml_files'])}")

    print("\n" + "=" * 80)
    print("Note: Full functionality requires indexer and AI analyzer")
    print("=" * 80)
