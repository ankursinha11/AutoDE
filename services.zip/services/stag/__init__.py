"""
STAG (System Transformation Assessment Generator) Services

Generates comprehensive Excel comparison reports between:
- Hadoop → Databricks
- Ab Initio → Databricks

Components:
- SystemMappingService: Load and query system mapping layer
- HadoopLogicExtractor: Extract logic from Hadoop workflows
- AbInitioLogicExtractor: Extract logic from Ab Initio graphs
- DatabricksLogicExtractor: Extract logic from Databricks pipelines
- BusinessStageAbstractor: Convert technical steps to business stages (AI)
- STAGSTTMGenerator: Generate column-level mappings (AI)
- ExcelGenerator: Create 5-sheet Excel comparison reports
- STAGOrchestrator: Coordinate all components
"""

from .system_mapping_service import SystemMappingService
from .hadoop_logic_extractor import HadoopLogicExtractor
from .abinitio_logic_extractor import AbInitioLogicExtractor
from .databricks_logic_extractor import DatabricksLogicExtractor
from .business_stage_abstractor import BusinessStageAbstractor
from .stag_sttm_generator import STAGSTTMGenerator
from .excel_generator import ExcelGenerator
from .stag_orchestrator import STAGOrchestrator

__all__ = [
    'SystemMappingService',
    'HadoopLogicExtractor',
    'AbInitioLogicExtractor',
    'DatabricksLogicExtractor',
    'BusinessStageAbstractor',
    'STAGSTTMGenerator',
    'ExcelGenerator',
    'STAGOrchestrator'
]
