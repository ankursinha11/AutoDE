"""
System Mapping Service

Loads and queries the system mapping layer JSON file to find
Databricks pipeline mappings for Hadoop/Ab Initio workflows.

Handles:
- N:1 consolidation (multiple source workflows → single Databricks pipeline)
- 1:N splitting (single source workflow → multiple Databricks pipelines)
- 1:1 direct mapping
"""

import json
from pathlib import Path
from typing import Dict, List, Any, Optional
from loguru import logger


class SystemMappingService:
    """Service for loading and querying system mapping layer"""

    def __init__(self, mapping_file: str = "Input Files/system_mapping_layer.json"):
        """
        Initialize System Mapping Service

        Args:
            mapping_file: Path to system_mapping_layer.json
        """
        self.mapping_file = Path(mapping_file)
        self.mappings: Dict[str, Any] = {}
        self.load_mappings()

    def load_mappings(self) -> None:
        """Load system mapping layer from JSON file"""
        if not self.mapping_file.exists():
            logger.error(f"System mapping file not found: {self.mapping_file}")
            self.mappings = {}
            return

        try:
            with open(self.mapping_file, 'r') as f:
                data = json.load(f)
                # Structure: { "hadoop_to_databricks": {...}, "abinitio_to_databricks": {...} }
                self.mappings = data
                hadoop_count = len(data.get('hadoop_to_databricks', {}))
                abinitio_count = len(data.get('abinitio_to_databricks', {}))
                total_count = hadoop_count + abinitio_count
                logger.info(f"✅ Loaded {total_count} system mappings ({hadoop_count} Hadoop, {abinitio_count} Ab Initio)")
        except Exception as e:
            logger.error(f"Failed to load system mappings: {e}")
            self.mappings = {}

    def get_databricks_mapping(self, source_system: str, source_workflow: str) -> Optional[Dict[str, Any]]:
        """
        Find Databricks pipeline mapping for a source workflow with flexible matching

        Args:
            source_system: "hadoop" or "abinitio"
            source_workflow: Workflow/graph name

        Returns:
            Mapping dictionary with:
            {
                'databricks_pipelines': List[str],
                'mapping_type': '1:1' | '1:N',
                'source_workflow': str
            }
        """
        source_system = source_system.lower()

        # Get the appropriate mapping section
        if source_system == "hadoop":
            mapping_section = self.mappings.get('hadoop_to_databricks', {})
        elif source_system == "abinitio":
            mapping_section = self.mappings.get('abinitio_to_databricks', {})
        else:
            logger.error(f"Unknown source system: {source_system}")
            return None

        # Normalize the source workflow for comparison
        source_workflow_normalized = source_workflow.lower().replace(' ', '').replace(':', '').replace('-', '').replace('_', '').strip()

        # Strategy 1: Exact match (case-insensitive)
        for workflow_key, databricks_pipelines in mapping_section.items():
            if workflow_key.lower() == source_workflow.lower() or workflow_key == source_workflow:
                logger.info(f"✅ Exact match found: '{source_workflow}' = '{workflow_key}'")
                return self._format_mapping(workflow_key, databricks_pipelines)

        # Strategy 2: Normalized match (remove spaces, colons, hyphens, underscores)
        for workflow_key, databricks_pipelines in mapping_section.items():
            workflow_key_normalized = workflow_key.lower().replace(' ', '').replace(':', '').replace('-', '').replace('_', '').strip()
            if workflow_key_normalized == source_workflow_normalized:
                logger.info(f"✅ Normalized match found: '{source_workflow}' → '{workflow_key}'")
                return self._format_mapping(workflow_key, databricks_pipelines)

        # Strategy 3: Fuzzy match using difflib (similarity > 85%)
        from difflib import SequenceMatcher
        best_match = None
        best_match_key = None
        best_ratio = 0.0

        for workflow_key in mapping_section.keys():
            workflow_key_normalized = workflow_key.lower().replace(' ', '').replace(':', '').replace('-', '').replace('_', '').strip()
            ratio = SequenceMatcher(None, source_workflow_normalized, workflow_key_normalized).ratio()
            if ratio > best_ratio:
                best_ratio = ratio
                best_match = mapping_section[workflow_key]
                best_match_key = workflow_key

        # Accept fuzzy match if similarity > 85%
        if best_ratio >= 0.85:
            logger.info(f"✅ Fuzzy match found: '{source_workflow}' → '{best_match_key}' (similarity: {best_ratio:.2%})")
            return self._format_mapping(best_match_key, best_match)

        # No match found
        logger.warning(f"❌ No mapping found for {source_system}: {source_workflow}")
        logger.debug(f"Tried matching against {len(mapping_section)} workflows in mapping file")
        return None

    def _format_mapping(self, workflow_key: str, databricks_pipelines) -> Dict[str, Any]:
        """
        Format mapping response, handling various pipeline formats

        Args:
            workflow_key: Original workflow key from mapping file
            databricks_pipelines: Databricks pipeline(s) - can be string or list

        Returns:
            Formatted mapping dictionary
        """
        # Handle different formats
        if isinstance(databricks_pipelines, str):
            # Split by newline if pipelines are newline-separated
            if '\n' in databricks_pipelines:
                databricks_pipelines = [p.strip() for p in databricks_pipelines.split('\n') if p.strip()]
            # Split by comma if comma-separated
            elif ',' in databricks_pipelines:
                databricks_pipelines = [p.strip() for p in databricks_pipelines.split(',') if p.strip()]
            else:
                databricks_pipelines = [databricks_pipelines.strip()]
        elif isinstance(databricks_pipelines, list):
            # Already a list - ensure no empty strings
            databricks_pipelines = [p.strip() for p in databricks_pipelines if p and p.strip()]
        else:
            # Unknown format
            databricks_pipelines = []

        # Determine mapping type
        num_target = len(databricks_pipelines)
        mapping_type = '1:1' if num_target == 1 else '1:N'

        return {
            'databricks_pipelines': databricks_pipelines,
            'mapping_type': mapping_type,
            'source_workflow': workflow_key
        }

    def get_source_mapping(self, databricks_pipeline: str) -> Optional[Dict[str, Any]]:
        """
        Reverse lookup: Find source workflows for a Databricks pipeline

        Args:
            databricks_pipeline: Databricks pipeline name

        Returns:
            Mapping dictionary with source system and workflows
        """
        results = []

        # Search Hadoop mappings
        hadoop_mappings = self.mappings.get('hadoop_to_databricks', {})
        for workflow, pipelines in hadoop_mappings.items():
            if isinstance(pipelines, str):
                if '\n' in pipelines:
                    pipelines = [p.strip() for p in pipelines.split('\n') if p.strip()]
                else:
                    pipelines = [pipelines]

            if databricks_pipeline in pipelines or databricks_pipeline.lower() in [p.lower() for p in pipelines]:
                results.append({
                    'source_system': 'hadoop',
                    'source_workflow': workflow,
                    'databricks_pipelines': pipelines
                })

        # Search Ab Initio mappings
        abinitio_mappings = self.mappings.get('abinitio_to_databricks', {})
        for workflow, pipelines in abinitio_mappings.items():
            if isinstance(pipelines, str):
                if '\n' in pipelines:
                    pipelines = [p.strip() for p in pipelines.split('\n') if p.strip()]
                else:
                    pipelines = [pipelines]

            if databricks_pipeline in pipelines or databricks_pipeline.lower() in [p.lower() for p in pipelines]:
                results.append({
                    'source_system': 'abinitio',
                    'source_workflow': workflow,
                    'databricks_pipelines': pipelines
                })

        if not results:
            logger.warning(f"No source mapping found for Databricks pipeline: {databricks_pipeline}")
            return None

        # If multiple source workflows map to this pipeline, return them all
        if len(results) == 1:
            return results[0]
        else:
            # Multiple source workflows (N:1 consolidation)
            return {
                'source_mappings': results,
                'mapping_type': 'N:1',
                'databricks_pipeline': databricks_pipeline
            }

    def get_all_mappings(self) -> Dict[str, Any]:
        """Get all mappings (for debugging/testing)"""
        return self.mappings

    def get_mappings_by_system(self, system: str) -> Dict[str, List[str]]:
        """
        Get all mappings for a specific source system

        Args:
            system: "hadoop" or "abinitio"

        Returns:
            Dictionary of workflow -> databricks_pipelines mappings
        """
        system = system.lower()

        if system == "hadoop":
            return self.mappings.get('hadoop_to_databricks', {})
        elif system == "abinitio":
            return self.mappings.get('abinitio_to_databricks', {})
        else:
            return {}


# Example usage
if __name__ == "__main__":
    # Test the service
    service = SystemMappingService()

    print("\n" + "=" * 80)
    print("SYSTEM MAPPING SERVICE TEST")
    print("=" * 80)

    # Test 1: Find Databricks mapping for Hadoop workflow
    print("\nTest 1: Hadoop → Databricks")
    mapping = service.get_databricks_mapping("hadoop", "cdd: bdf_download")
    if mapping:
        print(f"   Source: hadoop - cdd: bdf_download")
        print(f"   Target: {mapping['databricks_pipelines']}")
        print(f"   Type: {mapping['mapping_type']}")

    # Test 2: Find Databricks mapping for Ab Initio workflow
    print("\nTest 2: Ab Initio → Databricks")
    mapping = service.get_databricks_mapping("abinitio", "1300_CDD_PatientAcctsXRefPermID.pset")
    if mapping:
        print(f"   Source: abinitio - 1300_CDD_PatientAcctsXRefPermID.pset")
        print(f"   Target: {mapping['databricks_pipelines']}")
        print(f"   Type: {mapping['mapping_type']}")

    # Test 3: Reverse lookup
    print("\nTest 3: Databricks → Source (Reverse Lookup)")
    mapping = service.get_source_mapping("pl_cdd_bdf_download")
    if mapping:
        if 'source_system' in mapping:
            print(f"   Target: pl_cdd_bdf_download")
            print(f"   Source System: {mapping['source_system']}")
            print(f"   Source Workflow: {mapping['source_workflow']}")
        else:
            print(f"   Target: pl_cdd_bdf_download")
            print(f"   Type: {mapping['mapping_type']} (multiple sources)")
            print(f"   Source Mappings: {len(mapping['source_mappings'])} workflows")

    # Test 4: Get all Hadoop mappings
    print("\nTest 4: All Hadoop Mappings")
    hadoop_mappings = service.get_mappings_by_system("hadoop")
    print(f"   Found {len(hadoop_mappings)} Hadoop mappings")
    for i, (workflow, pipelines) in enumerate(list(hadoop_mappings.items())[:3], 1):
        print(f"   {i}. {workflow} → {pipelines}")

    print("\n" + "=" * 80)
    print("✅ System Mapping Service tests complete!")
    print("=" * 80)
