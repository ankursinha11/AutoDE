"""
Single-System Excel Generator
==============================
Generates Excel reports for a single system (Hadoop or Databricks) without comparison.

Sheets:
1. Overview - Workflow/Pipeline flow and metadata
2. Logic - Detailed step-by-step logic for all scripts/notebooks
3. STTM - Source-to-Target-Transform Mapping (column-level)

This is used when user wants documentation for one system only, not a comparison.
"""

import os
from pathlib import Path
from typing import Dict, List, Any, Optional
from loguru import logger
from datetime import datetime

try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
    OPENPYXL_AVAILABLE = True
except ImportError:
    OPENPYXL_AVAILABLE = False
    logger.warning("openpyxl not installed - Excel generation will be limited")


class SingleSystemExcelGenerator:
    """Generate Excel reports for single system (Hadoop or Databricks)"""

    def __init__(self):
        """Initialize Single System Excel Generator"""
        if not OPENPYXL_AVAILABLE:
            logger.error("openpyxl is required for Excel generation")
            raise ImportError("Please install openpyxl: pip install openpyxl")

        # Define color scheme
        self.header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
        self.header_font = Font(bold=True, color="FFFFFF", size=11)
        self.sub_header_fill = PatternFill(start_color="D9E1F2", end_color="D9E1F2", fill_type="solid")
        self.border = Border(
            left=Side(style='thin'),
            right=Side(style='thin'),
            top=Side(style='thin'),
            bottom=Side(style='thin')
        )
        self.code_font = Font(name='Consolas', size=10)

    def generate_hadoop_excel(
        self,
        workflow_name: str,
        workflow_data: Dict[str, Any],
        output_folder: str = "outputs/single_system_reports"
    ) -> str:
        """
        Generate Hadoop-only Excel report

        Args:
            workflow_name: Name of Hadoop workflow
            workflow_data: Dictionary containing:
                - workflow_flow: List of scripts in execution order
                - script_logics: Dict of script_name -> logic details
                - sttm_mappings: List of column mappings
            output_folder: Output directory

        Returns:
            Path to generated Excel file
        """
        logger.info(f"📊 Generating Hadoop Excel report for: {workflow_name}")

        # Create workbook
        wb = Workbook()
        wb.remove(wb.active)

        # Create sheets
        logger.info("   Creating Overview sheet...")
        self._create_hadoop_overview_sheet(wb, workflow_name, workflow_data)

        logger.info("   Creating Logic sheet...")
        self._create_hadoop_logic_sheet(wb, workflow_name, workflow_data)

        logger.info("   Creating STTM sheet...")
        self._create_sttm_sheet(wb, workflow_data.get('sttm_mappings', []), "hadoop")

        # Save
        return self._save_workbook(wb, f"Hadoop_{workflow_name}", output_folder)

    def generate_databricks_excel(
        self,
        pipeline_name: str,
        pipeline_data: Dict[str, Any],
        output_folder: str = "outputs/single_system_reports"
    ) -> str:
        """
        Generate Databricks-only Excel report

        Args:
            pipeline_name: Name of Databricks pipeline
            pipeline_data: Dictionary containing:
                - pipeline_flow: List of notebooks in execution order
                - notebook_logics: Dict of notebook_name -> logic details
                - sttm_mappings: List of column mappings
            output_folder: Output directory

        Returns:
            Path to generated Excel file
        """
        logger.info(f"📊 Generating Databricks Excel report for: {pipeline_name}")

        # Create workbook
        wb = Workbook()
        wb.remove(wb.active)

        # Create sheets
        logger.info("   Creating Overview sheet...")
        self._create_databricks_overview_sheet(wb, pipeline_name, pipeline_data)

        logger.info("   Creating Logic sheet...")
        self._create_databricks_logic_sheet(wb, pipeline_name, pipeline_data)

        logger.info("   Creating STTM sheet...")
        self._create_sttm_sheet(wb, pipeline_data.get('sttm_mappings', []), "databricks")

        # Save
        return self._save_workbook(wb, f"Databricks_{pipeline_name}", output_folder)

    # ============================================
    # Hadoop Sheets
    # ============================================

    def _create_hadoop_overview_sheet(
        self,
        wb: Workbook,
        workflow_name: str,
        workflow_data: Dict[str, Any]
    ):
        """Create Hadoop workflow overview sheet"""
        ws = wb.create_sheet("Overview", 0)

        # Title
        ws['A1'] = f"Hadoop Workflow: {workflow_name}"
        ws['A1'].font = Font(bold=True, size=14)
        ws.merge_cells('A1:D1')

        # Metadata
        ws['A2'] = f"System: Hadoop"
        ws['A3'] = f"Workflow: {workflow_name}"
        ws['A4'] = f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"

        # Workflow flow
        ws['A6'] = "Workflow Execution Flow"
        ws['A6'].font = Font(bold=True, size=12)

        # Headers
        headers = ['Step', 'Script/Action', 'Type', 'Description']
        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=7, column=col, value=header)
            cell.font = self.header_font
            cell.fill = self.header_fill
            cell.alignment = Alignment(horizontal='center', vertical='center')
            cell.border = self.border

        # Flow data
        workflow_flow = workflow_data.get('workflow_flow', [])
        for row_idx, step in enumerate(workflow_flow, 8):
            ws.cell(row=row_idx, column=1, value=step.get('step_number', row_idx - 7))
            ws.cell(row=row_idx, column=2, value=step.get('script_name', ''))
            ws.cell(row=row_idx, column=3, value=step.get('script_type', ''))
            ws.cell(row=row_idx, column=4, value=step.get('description', ''))

            for col in range(1, 5):
                cell = ws.cell(row=row_idx, column=col)
                cell.border = self.border
                cell.alignment = Alignment(vertical='top', wrap_text=True)

        # Column widths
        ws.column_dimensions['A'].width = 10
        ws.column_dimensions['B'].width = 40
        ws.column_dimensions['C'].width = 15
        ws.column_dimensions['D'].width = 50

        ws.freeze_panes = 'A8'

    def _create_hadoop_logic_sheet(
        self,
        wb: Workbook,
        workflow_name: str,
        workflow_data: Dict[str, Any]
    ):
        """Create Hadoop logic sheet with detailed script logic"""
        ws = wb.create_sheet("Logic", 1)

        # Title
        ws['A1'] = f"Hadoop Workflow Logic: {workflow_name}"
        ws['A1'].font = Font(bold=True, size=14)
        ws.merge_cells('A1:E1')

        row = 3
        script_logics = workflow_data.get('script_logics', {})

        for script_name, logic in script_logics.items():
            # Script header
            ws.cell(row=row, column=1, value=f"Script: {script_name}")
            ws.cell(row=row, column=1).font = Font(bold=True, size=12, color="4472C4")
            ws.merge_cells(f'A{row}:E{row}')
            row += 1

            # Metadata
            ws.cell(row=row, column=1, value="File Path:")
            ws.cell(row=row, column=2, value=logic.get('file_path', ''))
            row += 1

            ws.cell(row=row, column=1, value="Type:")
            ws.cell(row=row, column=2, value=logic.get('script_type', ''))
            row += 1

            # Logic steps header
            ws.cell(row=row, column=1, value="Logic Steps:")
            ws.cell(row=row, column=1).font = Font(bold=True)
            row += 1

            # Table headers
            headers = ['Step', 'Action', 'Input', 'Output', 'Details']
            for col, header in enumerate(headers, 1):
                cell = ws.cell(row=row, column=col, value=header)
                cell.font = self.header_font
                cell.fill = self.header_fill
                cell.alignment = Alignment(horizontal='center')
                cell.border = self.border
            row += 1

            # Logic steps
            logic_steps = logic.get('logic_steps', [])
            for step in logic_steps:
                ws.cell(row=row, column=1, value=step.get('step_number', ''))
                ws.cell(row=row, column=2, value=step.get('action', ''))
                ws.cell(row=row, column=3, value=step.get('input', ''))
                ws.cell(row=row, column=4, value=step.get('output', ''))
                ws.cell(row=row, column=5, value=step.get('details', ''))

                # Code formatting for details
                ws.cell(row=row, column=5).font = self.code_font

                for col in range(1, 6):
                    cell = ws.cell(row=row, column=col)
                    cell.border = self.border
                    cell.alignment = Alignment(vertical='top', wrap_text=True)

                row += 1

            # Add spacing
            row += 2

        # Column widths
        ws.column_dimensions['A'].width = 8
        ws.column_dimensions['B'].width = 25
        ws.column_dimensions['C'].width = 25
        ws.column_dimensions['D'].width = 25
        ws.column_dimensions['E'].width = 50

    # ============================================
    # Databricks Sheets
    # ============================================

    def _create_databricks_overview_sheet(
        self,
        wb: Workbook,
        pipeline_name: str,
        pipeline_data: Dict[str, Any]
    ):
        """Create Databricks pipeline overview sheet"""
        ws = wb.create_sheet("Overview", 0)

        # Title
        ws['A1'] = f"Databricks Pipeline: {pipeline_name}"
        ws['A1'].font = Font(bold=True, size=14)
        ws.merge_cells('A1:D1')

        # Metadata
        ws['A2'] = f"System: Databricks"
        ws['A3'] = f"Pipeline: {pipeline_name}"
        ws['A4'] = f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"

        # Pipeline flow
        ws['A6'] = "Pipeline Execution Flow"
        ws['A6'].font = Font(bold=True, size=12)

        # Headers
        headers = ['Step', 'Notebook/Task', 'Type', 'Description']
        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=7, column=col, value=header)
            cell.font = self.header_font
            cell.fill = self.header_fill
            cell.alignment = Alignment(horizontal='center', vertical='center')
            cell.border = self.border

        # Flow data
        pipeline_flow = pipeline_data.get('pipeline_flow', [])
        for row_idx, step in enumerate(pipeline_flow, 8):
            ws.cell(row=row_idx, column=1, value=step.get('step_number', row_idx - 7))
            ws.cell(row=row_idx, column=2, value=step.get('notebook_name', ''))
            ws.cell(row=row_idx, column=3, value=step.get('task_type', ''))
            ws.cell(row=row_idx, column=4, value=step.get('description', ''))

            for col in range(1, 5):
                cell = ws.cell(row=row_idx, column=col)
                cell.border = self.border
                cell.alignment = Alignment(vertical='top', wrap_text=True)

        # Column widths
        ws.column_dimensions['A'].width = 10
        ws.column_dimensions['B'].width = 40
        ws.column_dimensions['C'].width = 15
        ws.column_dimensions['D'].width = 50

        ws.freeze_panes = 'A8'

    def _create_databricks_logic_sheet(
        self,
        wb: Workbook,
        pipeline_name: str,
        pipeline_data: Dict[str, Any]
    ):
        """Create Databricks logic sheet with detailed notebook logic"""
        ws = wb.create_sheet("Logic", 1)

        # Title
        ws['A1'] = f"Databricks Pipeline Logic: {pipeline_name}"
        ws['A1'].font = Font(bold=True, size=14)
        ws.merge_cells('A1:E1')

        row = 3
        notebook_logics = pipeline_data.get('notebook_logics', {})

        for notebook_name, logic in notebook_logics.items():
            # Notebook header
            ws.cell(row=row, column=1, value=f"Notebook: {notebook_name}")
            ws.cell(row=row, column=1).font = Font(bold=True, size=12, color="4472C4")
            ws.merge_cells(f'A{row}:E{row}')
            row += 1

            # Metadata
            ws.cell(row=row, column=1, value="File Path:")
            ws.cell(row=row, column=2, value=logic.get('file_path', ''))
            row += 1

            ws.cell(row=row, column=1, value="Language:")
            ws.cell(row=row, column=2, value=logic.get('language', 'Python/SQL'))
            row += 1

            # Logic steps header
            ws.cell(row=row, column=1, value="Logic Steps:")
            ws.cell(row=row, column=1).font = Font(bold=True)
            row += 1

            # Table headers
            headers = ['Step', 'Action', 'Input', 'Output', 'Code/Details']
            for col, header in enumerate(headers, 1):
                cell = ws.cell(row=row, column=col, value=header)
                cell.font = self.header_font
                cell.fill = self.header_fill
                cell.alignment = Alignment(horizontal='center')
                cell.border = self.border
            row += 1

            # Logic steps
            logic_steps = logic.get('logic_steps', [])
            for step in logic_steps:
                ws.cell(row=row, column=1, value=step.get('step_number', ''))
                ws.cell(row=row, column=2, value=step.get('action', ''))
                ws.cell(row=row, column=3, value=step.get('input', ''))
                ws.cell(row=row, column=4, value=step.get('output', ''))
                ws.cell(row=row, column=5, value=step.get('code', ''))

                # Code formatting
                ws.cell(row=row, column=5).font = self.code_font

                for col in range(1, 6):
                    cell = ws.cell(row=row, column=col)
                    cell.border = self.border
                    cell.alignment = Alignment(vertical='top', wrap_text=True)

                row += 1

            # Add spacing
            row += 2

        # Column widths
        ws.column_dimensions['A'].width = 8
        ws.column_dimensions['B'].width = 25
        ws.column_dimensions['C'].width = 25
        ws.column_dimensions['D'].width = 25
        ws.column_dimensions['E'].width = 50

    # ============================================
    # Common STTM Sheet
    # ============================================

    def _create_sttm_sheet(
        self,
        wb: Workbook,
        sttm_mappings: List[Dict[str, Any]],
        system_type: str
    ):
        """Create STTM (Source-to-Target-Transform Mapping) sheet"""
        ws = wb.create_sheet("STTM", 2)

        # Title
        ws['A1'] = f"Source-to-Target-Transform Mapping ({system_type.capitalize()})"
        ws['A1'].font = Font(bold=True, size=14)
        ws.merge_cells('A1:H1')

        # Headers
        headers = [
            'Target Column',
            'Source Column(s)',
            'Data Type',
            'Transformation Logic',
            'Source Table',
            'Target Table',
            'Script/Notebook',
            'Notes'
        ]

        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=3, column=col, value=header)
            cell.font = self.header_font
            cell.fill = self.header_fill
            cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            cell.border = self.border

        # STTM data
        for row_idx, mapping in enumerate(sttm_mappings, 4):
            ws.cell(row=row_idx, column=1, value=mapping.get('target_column', ''))
            ws.cell(row=row_idx, column=2, value=', '.join(mapping.get('source_columns', [])))
            ws.cell(row=row_idx, column=3, value=mapping.get('data_type', ''))
            ws.cell(row=row_idx, column=4, value=mapping.get('transformation_logic', ''))
            ws.cell(row=row_idx, column=5, value=mapping.get('source_table', ''))
            ws.cell(row=row_idx, column=6, value=mapping.get('target_table', ''))
            ws.cell(row=row_idx, column=7, value=mapping.get('script_name', ''))
            ws.cell(row=row_idx, column=8, value=mapping.get('notes', ''))

            # Code formatting for transformation logic
            ws.cell(row=row_idx, column=4).font = self.code_font

            for col in range(1, 9):
                cell = ws.cell(row=row_idx, column=col)
                cell.border = self.border
                cell.alignment = Alignment(vertical='top', wrap_text=True)

        # Column widths
        ws.column_dimensions['A'].width = 25  # Target Column
        ws.column_dimensions['B'].width = 25  # Source Columns
        ws.column_dimensions['C'].width = 15  # Data Type
        ws.column_dimensions['D'].width = 40  # Transformation
        ws.column_dimensions['E'].width = 25  # Source Table
        ws.column_dimensions['F'].width = 25  # Target Table
        ws.column_dimensions['G'].width = 30  # Script/Notebook
        ws.column_dimensions['H'].width = 30  # Notes

        ws.freeze_panes = 'A4'

    # ============================================
    # Helper Methods
    # ============================================

    def _save_workbook(self, wb: Workbook, base_filename: str, output_folder: str) -> str:
        """Save workbook to file"""
        os.makedirs(output_folder, exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        # Sanitize filename
        safe_name = base_filename.replace(':', '_').replace('/', '_').replace('\\', '_').replace('|', '_')
        safe_name = safe_name.replace('?', '_').replace('*', '_').replace('<', '_').replace('>', '_').replace('"', '_').strip()

        filename = f"{safe_name}_{timestamp}.xlsx"
        output_path = os.path.join(output_folder, filename)

        try:
            wb.save(output_path)
            logger.info(f"✅ Excel file saved: {output_path}")
            return output_path
        except Exception as e:
            logger.error(f"❌ Failed to save Excel file: {e}")
            # Try fallback
            simple_filename = f"SingleSystem_{timestamp}.xlsx"
            fallback_path = os.path.join(output_folder, simple_filename)
            wb.save(fallback_path)
            logger.info(f"✅ Excel file saved (fallback): {fallback_path}")
            return fallback_path
