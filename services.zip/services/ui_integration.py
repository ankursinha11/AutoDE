"""
Streamlit UI Integration Helper
================================
Helper functions and components for integrating the enhanced RAG workflow
with Streamlit UI.

Components:
- RAG workflow initialization
- Conversation history display
- Evidence display
- Query processing with streaming
"""

import streamlit as st
from typing import Dict, List, Any, Optional
from datetime import datetime
from loguru import logger


def initialize_rag_workflow(ai_analyzer, indexer, vector_search_client=None):
    """
    Initialize RAG workflow in Streamlit session state

    Args:
        ai_analyzer: AI analyzer instance
        indexer: Multi-collection indexer
        vector_search_client: Optional vector search client

    Returns:
        RAGWorkflow instance
    """
    from services.langgraph.workflow import RAGWorkflow

    if 'rag_workflow' not in st.session_state:
        workflow = RAGWorkflow(
            ai_analyzer=ai_analyzer,
            indexer=indexer,
            vector_search_client=vector_search_client
        )
        st.session_state.rag_workflow = workflow
        logger.info("✅ RAG Workflow initialized in session")

    return st.session_state.rag_workflow


def get_or_create_session_id() -> str:
    """Get or create unique session ID"""
    if 'session_id' not in st.session_state:
        st.session_state.session_id = f"session_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

    return st.session_state.session_id


def process_query_with_rag(query: str, workflow=None) -> Dict[str, Any]:
    """
    Process query using RAG workflow

    Args:
        query: User query
        workflow: Optional workflow instance (uses session state if not provided)

    Returns:
        Query result dict
    """
    if workflow is None:
        workflow = st.session_state.get('rag_workflow')
        if not workflow:
            raise ValueError("RAG workflow not initialized. Call initialize_rag_workflow() first.")

    session_id = get_or_create_session_id()

    # Process query
    result = workflow.query(query=query, session_id=session_id)

    return result


def display_conversation_history():
    """Display conversation history in sidebar"""
    st.sidebar.markdown("### 💬 Conversation History")

    workflow = st.session_state.get('rag_workflow')
    if not workflow:
        st.sidebar.info("No conversation yet")
        return

    session_id = get_or_create_session_id()

    # Get conversation from workflow memory
    if session_id in workflow.memories:
        memory = workflow.memories[session_id]
        history = memory.get_active_context()

        if not history:
            st.sidebar.info("No conversation yet")
            return

        # Display last 5 exchanges
        for turn in history[-10:]:  # Last 10 turns (5 exchanges)
            role = turn.get('role')
            content = turn.get('content')

            if role == 'user':
                st.sidebar.markdown(f"**🧑 You:** {content[:100]}...")
            else:
                st.sidebar.markdown(f"**🤖 Assistant:** {content[:100]}...")

        # Add clear button
        if st.sidebar.button("Clear History"):
            memory.clear()
            st.sidebar.success("History cleared!")
            st.rerun()


def display_evidence(evidence: List[Dict[str, Any]]):
    """
    Display evidence sources with formatting

    Args:
        evidence: List of evidence dicts
    """
    if not evidence:
        return

    st.markdown("### 📚 Evidence Sources")

    for i, ev in enumerate(evidence, 1):
        file_path = ev.get('file_path', 'Unknown')
        relevance = ev.get('relevance_score', 0.0)
        system = ev.get('system', '')
        title = ev.get('title', '')

        with st.expander(f"**{i}. {file_path}** (Relevance: {relevance:.2%})"):
            if title:
                st.markdown(f"**Title:** {title}")

            st.markdown(f"**System:** {system}")
            st.markdown(f"**Score:** {relevance:.2%}")

            # Show file path as copyable code
            st.code(file_path, language="")

            # If line numbers available
            line_numbers = ev.get('line_numbers')
            if line_numbers:
                st.markdown(f"**Lines:** {min(line_numbers)}-{max(line_numbers)}")

            # If content snippet available
            snippet = ev.get('content_snippet')
            if snippet:
                st.markdown("**Code Snippet:**")
                st.code(snippet, language="sql")


def display_query_metadata(metadata: Dict[str, Any]):
    """
    Display query processing metadata

    Args:
        metadata: Metadata dict from query result
    """
    with st.expander("ℹ️ Query Processing Details"):
        col1, col2, col3 = st.columns(3)

        with col1:
            st.metric("Intent", metadata.get('intent', 'N/A'))

        with col2:
            systems = metadata.get('systems', [])
            st.metric("Systems", len(systems))
            if systems:
                st.caption(", ".join(systems))

        with col3:
            files = metadata.get('files_analyzed', 0)
            st.metric("Files Analyzed", files)

        # Show timestamps
        timestamps = metadata.get('timestamps', {})
        if timestamps:
            st.markdown("**Processing Timeline:**")
            for step, timestamp in timestamps.items():
                st.caption(f"{step}: {timestamp}")


def create_chat_interface():
    """Create complete chat interface with RAG"""
    st.title("🚀 Enhanced RAG Chat")

    # Display conversation history in sidebar
    display_conversation_history()

    # Main chat area
    if 'chat_messages' not in st.session_state:
        st.session_state.chat_messages = []

    # Display chat messages
    for message in st.session_state.chat_messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

            # Show evidence for assistant messages
            if message["role"] == "assistant" and "evidence" in message:
                display_evidence(message["evidence"])

            # Show metadata
            if message["role"] == "assistant" and "metadata" in message:
                display_query_metadata(message["metadata"])

    # Chat input
    if prompt := st.chat_input("Ask about your codebase..."):
        # Add user message
        st.session_state.chat_messages.append({"role": "user", "content": prompt})

        with st.chat_message("user"):
            st.markdown(prompt)

        # Process with RAG
        with st.chat_message("assistant"):
            with st.spinner("Thinking..."):
                try:
                    result = process_query_with_rag(prompt)

                    # Display response
                    st.markdown(result["response"])

                    # Display confidence
                    confidence = result.get("confidence_score", 0.0)
                    st.metric("Confidence", f"{confidence:.0%}")

                    # Display evidence
                    if result.get("evidence"):
                        display_evidence(result["evidence"])

                    # Display metadata
                    if result.get("metadata"):
                        display_query_metadata(result["metadata"])

                    # Add to chat history
                    st.session_state.chat_messages.append({
                        "role": "assistant",
                        "content": result["response"],
                        "evidence": result.get("evidence", []),
                        "metadata": result.get("metadata", {}),
                        "confidence": confidence
                    })

                except Exception as e:
                    st.error(f"Error processing query: {e}")
                    logger.error(f"Query processing error: {e}")


def display_system_status():
    """Display system status in sidebar"""
    st.sidebar.markdown("---")
    st.sidebar.markdown("### ⚙️ System Status")

    workflow = st.session_state.get('rag_workflow')

    if workflow:
        st.sidebar.success("✅ RAG Workflow Active")

        # Show component status
        st.sidebar.markdown("**Components:**")
        st.sidebar.caption("✅ Hybrid Search")
        st.sidebar.caption("✅ Query Rewriter")
        st.sidebar.caption("✅ Reranker")
        st.sidebar.caption("✅ File Reader")
        st.sidebar.caption("✅ Code Analyzer")

        # Show cache stats
        if hasattr(workflow, 'file_reader'):
            stats = workflow.file_reader.get_cache_stats()
            st.sidebar.markdown(f"**Cached Files:** {stats['cached_files']}")
            st.sidebar.markdown(f"**Cache Size:** {stats['total_mb']:.1f} MB")
    else:
        st.sidebar.warning("⚠️ RAG Workflow Not Initialized")


# ============================================
# Quick Integration Functions
# ============================================

def quick_setup(ai_analyzer, indexer):
    """
    Quick setup for RAG integration

    Call this in your Streamlit app's main():

    ```python
    from services.ui_integration import quick_setup

    # In main()
    quick_setup(ai_analyzer, indexer)
    ```

    Args:
        ai_analyzer: AI analyzer instance
        indexer: Multi-collection indexer
    """
    # Initialize workflow
    initialize_rag_workflow(ai_analyzer, indexer)

    # Display system status
    display_system_status()

    logger.info("✅ Quick setup complete")


def replace_chat_orchestrator(query: str) -> Dict[str, Any]:
    """
    Drop-in replacement for existing ChatOrchestrator.process()

    Use this to replace existing chat logic:

    ```python
    # OLD:
    result = orchestrator.process(query)

    # NEW:
    result = replace_chat_orchestrator(query)
    ```

    Args:
        query: User query

    Returns:
        Result dict compatible with existing code
    """
    workflow = st.session_state.get('rag_workflow')
    if not workflow:
        raise ValueError("RAG workflow not initialized")

    result = process_query_with_rag(query, workflow)

    # Format to match old orchestrator format
    return {
        "response": result["response"],
        "sources": result.get("evidence", []),
        "confidence": result.get("confidence_score", 0.0),
        "metadata": result.get("metadata", {})
    }
