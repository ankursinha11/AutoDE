"""
Lineage Graph Builder
====================

Builds table and column lineage graphs from indexed code and metadata.

Uses:
- Existing indexed data (no reindex required)
- AI to extract lineage from code
- Pattern matching for common transformations
- System mapping for cross-system lineage
"""

from typing import List, Dict, Any, Optional, Set, Tuple
from loguru import logger
from pathlib import Path
import re
import json

from services.lineage.enhanced_lineage_structures import (
    TableLineageGraph,
    TableLineageNode,
    ColumnMetadata,
    ColumnLineageChain,
    TransformationStep,
    TransformationType,
    qualify_column_name,
    parse_qualified_name,
    create_transformation_step
)


class LineageGraphBuilder:
    """
    Build table and column lineage graphs from existing indexed data

    No reindexing required - uses current vectors + AI extraction
    """

    def __init__(self, indexer, ai_analyzer, system_mapping_service=None):
        """
        Initialize lineage graph builder

        Args:
            indexer: MultiCollectionIndexer for vector search
            ai_analyzer: AIAnalyzer for AI-powered extraction
            system_mapping_service: Optional system mapping for cross-system lineage
        """
        self.indexer = indexer
        self.ai_analyzer = ai_analyzer
        self.system_mapping_service = system_mapping_service
        logger.info("✓ Lineage Graph Builder initialized")

    def build_table_lineage(
        self,
        workflow_name: str,
        system: str = "auto"
    ) -> TableLineageGraph:
        """
        Build complete table lineage graph for a workflow

        Args:
            workflow_name: Name of workflow/graph/pipeline
            system: System type (abinitio, hadoop, databricks, or auto)

        Returns:
            Complete table lineage graph with chronological ordering
        """
        logger.info(f"🔍 Building table lineage for: {workflow_name}")

        # Step 1: Find the workflow in indexed data
        workflow_data = self._find_workflow(workflow_name, system)

        if not workflow_data:
            logger.warning(f"Workflow not found: {workflow_name}")
            return self._create_empty_lineage(workflow_name, system)

        # Step 2: Extract table lineage using AI
        lineage_extraction = self._extract_lineage_from_workflow(workflow_data)

        # Step 3: Build graph structure
        graph = self._build_graph_from_extraction(workflow_name, system, lineage_extraction)

        # Step 4: Enrich with cross-system lineage if available
        if self.system_mapping_service:
            graph = self._enrich_with_cross_system_lineage(graph)

        logger.info(f"✅ Table lineage built: {len(graph.source_tables)} sources → {len(graph.target_tables)} targets ({graph.transformation_count} steps)")

        return graph

    def build_column_lineage(
        self,
        table_name: str,
        column_name: str,
        system: str = "auto"
    ) -> ColumnLineageChain:
        """
        Build complete lineage chain for a specific column

        Args:
            table_name: Fully qualified table name
            column_name: Column name
            system: System type

        Returns:
            Complete column lineage chain
        """
        logger.info(f"🔍 Building column lineage for: {table_name}.{column_name}")

        qualified_column = qualify_column_name(table_name, column_name)

        # Step 1: Find table definition
        table_data = self._find_table(table_name, system)

        if not table_data:
            logger.warning(f"Table not found: {table_name}")
            return self._create_empty_column_lineage(qualified_column)

        # Step 2: Extract column transformations using AI
        transformation_steps = self._extract_column_transformations(
            table_data,
            column_name
        )

        # Step 3: Trace back to source columns
        source_columns = self._trace_to_source(transformation_steps)

        # Step 4: Build lineage chain
        chain = ColumnLineageChain(
            target_column=qualified_column,
            source_columns=source_columns,
            transformation_steps=transformation_steps,
            full_journey=self._build_journey_string(source_columns, qualified_column, transformation_steps),
            confidence=self._calculate_chain_confidence(transformation_steps)
        )

        logger.info(f"✅ Column lineage built: {len(source_columns)} sources → {qualified_column} ({len(transformation_steps)} steps)")

        return chain

    def build_complete_workflow_lineage(
        self,
        workflow_name: str,
        system: str = "auto",
        include_column_lineage: bool = True
    ) -> Tuple[TableLineageGraph, List[ColumnLineageChain]]:
        """
        Build both table and column lineage for a workflow

        Args:
            workflow_name: Workflow name
            system: System type
            include_column_lineage: Whether to build column lineage for all columns

        Returns:
            (table_graph, list of column lineages)
        """
        logger.info(f"🔍 Building complete lineage for: {workflow_name}")

        # Build table lineage
        table_graph = self.build_table_lineage(workflow_name, system)

        column_lineages = []

        if include_column_lineage and table_graph.target_tables:
            # Build column lineage for each column in target tables
            for target_table in table_graph.target_tables:
                for column in target_table.columns:
                    try:
                        col_lineage = self.build_column_lineage(
                            target_table.table_name,
                            column.column_name,
                            system
                        )
                        column_lineages.append(col_lineage)
                    except Exception as e:
                        logger.warning(f"Failed to build lineage for {column.column_name}: {e}")

        logger.info(f"✅ Complete lineage: {len(column_lineages)} column lineages built")

        return table_graph, column_lineages

    # Private methods

    def _find_workflow(self, workflow_name: str, system: str) -> Optional[Dict[str, Any]]:
        """Find workflow in indexed data using vector search"""

        # Determine which collections to search
        if system == "auto":
            collections = ["abinitio_collection", "hadoop_collection", "databricks_collection"]
        else:
            collection_map = {
                "abinitio": "abinitio_collection",
                "hadoop": "hadoop_collection",
                "databricks": "databricks_collection"
            }
            collections = [collection_map.get(system, "abinitio_collection")]

        # Search for workflow
        try:
            results = self.indexer.search_multi_collection(
                query=f"workflow {workflow_name}",
                collections=collections,
                top_k=5
            )

            # Find best match
            for collection, docs in results.items():
                for doc in docs:
                    # Check if this is the workflow we're looking for
                    title = doc.get('title', '').lower()
                    content = doc.get('content', '').lower()

                    if workflow_name.lower() in title or workflow_name.lower() in content:
                        # Found it! Read full file content
                        file_path = doc.get('metadata', {}).get('absolute_file_path')
                        if file_path:
                            full_content = self._read_file_content(file_path)
                            if full_content:
                                doc['full_content'] = full_content

                        doc['detected_system'] = collection.replace('_collection', '')
                        return doc

        except Exception as e:
            logger.error(f"Error finding workflow: {e}")

        return None

    def _find_table(self, table_name: str, system: str) -> Optional[Dict[str, Any]]:
        """Find table definition in indexed data"""

        if system == "auto":
            collections = ["abinitio_collection", "hadoop_collection", "databricks_collection"]
        else:
            collection_map = {
                "abinitio": "abinitio_collection",
                "hadoop": "hadoop_collection",
                "databricks": "databricks_collection"
            }
            collections = [collection_map.get(system, "abinitio_collection")]

        try:
            results = self.indexer.search_multi_collection(
                query=f"table {table_name}",
                collections=collections,
                top_k=5
            )

            for collection, docs in results.items():
                for doc in docs:
                    if table_name.lower() in doc.get('content', '').lower():
                        file_path = doc.get('metadata', {}).get('absolute_file_path')
                        if file_path:
                            doc['full_content'] = self._read_file_content(file_path)
                        doc['detected_system'] = collection.replace('_collection', '')
                        return doc

        except Exception as e:
            logger.error(f"Error finding table: {e}")

        return None

    def _extract_lineage_from_workflow(self, workflow_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Extract table lineage from workflow using AI

        Uses advanced RAG to understand code and extract:
        - Source tables
        - Target tables
        - Transformation logic
        - Column mappings
        - Sequential order
        """

        system = workflow_data.get('detected_system', 'unknown')
        content = workflow_data.get('full_content') or workflow_data.get('content', '')

        prompt = f"""You are a data lineage expert analyzing {system} code.

Extract table-level lineage from this code:

CODE:
{content[:5000]}  # Limit to 5000 chars for token efficiency

Return JSON with this EXACT structure:
{{
    "source_tables": [
        {{
            "name": "fully_qualified_table_name",
            "database": "database_name",
            "columns": ["col1", "col2", "col3"]
        }}
    ],
    "target_tables": [
        {{
            "name": "fully_qualified_table_name",
            "database": "database_name",
            "columns": ["col1", "col2", "col3"]
        }}
    ],
    "transformations": [
        {{
            "step": 0,
            "type": "join|filter|aggregate|transform",
            "input_tables": ["table1", "table2"],
            "output_table": "result_table",
            "logic": "brief description of transformation",
            "column_mappings": [
                {{
                    "source": "table1.column1",
                    "target": "result_table.column1",
                    "transformation": "CAST|CONCAT|RENAME|etc"
                }}
            ]
        }}
    ],
    "business_logic": "What does this workflow do from a business perspective?"
}}

Focus on:
1. Identifying ALL input and output tables
2. Understanding transformation sequence
3. Extracting column-level mappings where visible
4. Understanding business purpose
"""

        try:
            result = self.ai_analyzer.analyze_code(
                code=prompt,
                context="",
                analysis_type="lineage_extraction"
            )

            # Extract JSON from response
            json_match = re.search(r'\{.*\}', result, re.DOTALL)
            if json_match:
                lineage_data = json.loads(json_match.group())
                return lineage_data
            else:
                logger.warning("No JSON found in AI response, using fallback extraction")
                return self._fallback_lineage_extraction(content, system)

        except Exception as e:
            logger.error(f"AI lineage extraction failed: {e}")
            return self._fallback_lineage_extraction(content, system)

    def _fallback_lineage_extraction(self, content: str, system: str) -> Dict[str, Any]:
        """Fallback pattern-based lineage extraction when AI fails"""

        source_tables = []
        target_tables = []
        transformations = []

        content_lower = content.lower()

        # Pattern matching based on system
        if system == "hadoop":
            # Look for CREATE TABLE, INSERT INTO
            create_matches = re.findall(r'create\s+table\s+(\w+\.?\w+)', content_lower)
            insert_matches = re.findall(r'insert\s+into\s+(\w+\.?\w+)', content_lower)
            from_matches = re.findall(r'from\s+(\w+\.?\w+)', content_lower)

            target_tables = [{'name': t, 'database': '', 'columns': []} for t in (create_matches + insert_matches)]
            source_tables = [{'name': t, 'database': '', 'columns': []} for t in from_matches]

        elif system == "databricks":
            # Look for df.write, createOrReplaceTempView
            write_matches = re.findall(r'\.write.*\.save\(["\']([^"\']+)', content)
            read_matches = re.findall(r'\.read.*\.load\(["\']([^"\']+)', content)

            target_tables = [{'name': t, 'database': '', 'columns': []} for t in write_matches]
            source_tables = [{'name': t, 'database': '', 'columns': []} for t in read_matches]

        elif system == "abinitio":
            # Look for input-table, output-table in Enhanced Parser output
            input_matches = re.findall(r'"type":\s*"input[- ]table".*?"name":\s*"([^"]+)"', content)
            output_matches = re.findall(r'"type":\s*"output[- ]table".*?"name":\s*"([^"]+)"', content)

            source_tables = [{'name': t, 'database': '', 'columns': []} for t in input_matches]
            target_tables = [{'name': t, 'database': '', 'columns': []} for t in output_matches]

        return {
            'source_tables': source_tables,
            'target_tables': target_tables,
            'transformations': transformations,
            'business_logic': 'Data transformation workflow'
        }

    def _build_graph_from_extraction(
        self,
        workflow_name: str,
        system: str,
        extraction: Dict[str, Any]
    ) -> TableLineageGraph:
        """Build TableLineageGraph from extraction result"""

        # Build source tables (step 0)
        source_tables = []
        for src in extraction.get('source_tables', []):
            columns = [
                ColumnMetadata(
                    column_name=col,
                    qualified_name=qualify_column_name(src['name'], col),
                    data_type="STRING"  # Default, will be enriched
                )
                for col in src.get('columns', [])
            ]

            table_node = TableLineageNode(
                table_name=src['name'],
                system=system,
                database=src.get('database', ''),
                table_type="source",
                columns=columns,
                transformation_step=0
            )
            source_tables.append(table_node)

        # Build target tables (step n)
        target_tables = []
        max_step = len(extraction.get('transformations', [])) + 1

        for tgt in extraction.get('target_tables', []):
            columns = [
                ColumnMetadata(
                    column_name=col,
                    qualified_name=qualify_column_name(tgt['name'], col),
                    data_type="STRING"
                )
                for col in tgt.get('columns', [])
            ]

            table_node = TableLineageNode(
                table_name=tgt['name'],
                system=system,
                database=tgt.get('database', ''),
                table_type="target",
                columns=columns,
                transformation_step=max_step
            )
            target_tables.append(table_node)

        # Build intermediate tables from transformations
        intermediate_tables = []
        for transform in extraction.get('transformations', []):
            step = transform.get('step', 0)
            output_table_name = transform.get('output_table', '')

            # Create table node for intermediate result
            table_node = TableLineageNode(
                table_name=output_table_name,
                system=system,
                database="",
                table_type="intermediate",
                columns=[],
                transformation_step=step + 1,
                created_by=workflow_name,
                created_by_logic=transform.get('logic', ''),
                input_tables=transform.get('input_tables', [])
            )
            intermediate_tables.append(table_node)

        # Build graph
        graph = TableLineageGraph(
            workflow_name=workflow_name,
            system=system,
            source_tables=source_tables,
            intermediate_tables=intermediate_tables,
            target_tables=target_tables,
            transformation_count=len(extraction.get('transformations', [])),
            systems_involved=[system],
            business_summary=extraction.get('business_logic', '')
        )

        return graph

    def _extract_column_transformations(
        self,
        table_data: Dict[str, Any],
        column_name: str
    ) -> List[TransformationStep]:
        """Extract transformation steps for a specific column using AI"""

        content = table_data.get('full_content') or table_data.get('content', '')
        system = table_data.get('detected_system', 'unknown')

        prompt = f"""Extract column-level lineage for column: {column_name}

Code:
{content[:3000]}

Return JSON array of transformation steps:
[
    {{
        "step": 0,
        "type": "source|cast|concat|join|rename|etc",
        "input_columns": ["source_table.source_col"],
        "output_column": "target_table.{column_name}",
        "logic": "transformation code/description"
    }}
]
"""

        try:
            result = self.ai_analyzer.analyze_code(
                code=prompt,
                context="",
                analysis_type="column_lineage"
            )

            json_match = re.search(r'\[.*\]', result, re.DOTALL)
            if json_match:
                steps_data = json.loads(json_match.group())

                transformation_steps = []
                for step_data in steps_data:
                    step = create_transformation_step(
                        step_number=step_data.get('step', 0),
                        transform_type=TransformationType(step_data.get('type', 'transform')),
                        input_cols=step_data.get('input_columns', []),
                        output_col=step_data.get('output_column', ''),
                        logic=step_data.get('logic', ''),
                        system=system
                    )
                    transformation_steps.append(step)

                return transformation_steps

        except Exception as e:
            logger.warning(f"AI column extraction failed: {e}")

        return []

    def _trace_to_source(self, transformation_steps: List[TransformationStep]) -> List[str]:
        """Trace transformation steps back to original source columns"""

        if not transformation_steps:
            return []

        # Get input columns from first step (should be source)
        first_step = min(transformation_steps, key=lambda s: s.step_number)
        return first_step.input_columns

    def _build_journey_string(
        self,
        source_columns: List[str],
        target_column: str,
        transformation_steps: List[TransformationStep]
    ) -> str:
        """Build human-readable journey string"""

        if not source_columns:
            return f"? → {target_column}"

        if len(source_columns) == 1:
            journey = source_columns[0]
        else:
            journey = f"[{', '.join(source_columns)}]"

        for step in sorted(transformation_steps, key=lambda s: s.step_number):
            journey += f" → {step.transformation_type.value}({step.output_column})"

        return journey

    def _calculate_chain_confidence(self, transformation_steps: List[TransformationStep]) -> float:
        """Calculate confidence in lineage chain"""

        if not transformation_steps:
            return 0.5

        # Higher confidence if we have more steps and logic
        has_logic = sum(1 for step in transformation_steps if step.logic)
        confidence = 0.7 + (has_logic / len(transformation_steps)) * 0.3

        return min(confidence, 1.0)

    def _enrich_with_cross_system_lineage(self, graph: TableLineageGraph) -> TableLineageGraph:
        """Enrich graph with cross-system lineage using system mapping"""

        # TODO: Use system_mapping_service to find cross-system mappings
        # For now, just return as-is
        return graph

    def _read_file_content(self, file_path: str) -> Optional[str]:
        """Read full file content from disk"""

        try:
            path = Path(file_path)
            if path.exists() and path.is_file():
                with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                    return f.read()
        except Exception as e:
            logger.warning(f"Could not read file {file_path}: {e}")

        return None

    def _create_empty_lineage(self, workflow_name: str, system: str) -> TableLineageGraph:
        """Create empty lineage graph"""

        return TableLineageGraph(
            workflow_name=workflow_name,
            system=system,
            source_tables=[],
            intermediate_tables=[],
            target_tables=[],
            transformation_count=0,
            systems_involved=[],
            business_summary="Workflow not found in indexed data"
        )

    def _create_empty_column_lineage(self, qualified_column: str) -> ColumnLineageChain:
        """Create empty column lineage"""

        return ColumnLineageChain(
            target_column=qualified_column,
            source_columns=[],
            transformation_steps=[],
            full_journey=f"? → {qualified_column}",
            confidence=0.0,
            warnings=["Column not found in indexed data"]
        )
