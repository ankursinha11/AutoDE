"""
Enhanced Lineage Data Structures
=================================

Complete table and column-level lineage tracking with:
- Chronological transformation ordering
- Column disambiguation (qualified names)
- Cross-system lineage tracking
- Business logic understanding
"""

from typing import List, Dict, Any, Optional, Set
from dataclasses import dataclass, field, asdict
from enum import Enum
import json


class TransformationType(Enum):
    """Types of transformations in lineage"""
    SOURCE = "source"              # Original data source
    JOIN = "join"                  # JOIN operation
    FILTER = "filter"              # WHERE/FILTER
    AGGREGATE = "aggregate"        # GROUP BY/AGGREGATE
    CAST = "cast"                  # Type conversion
    CONCAT = "concat"              # String concatenation
    SPLIT = "split"                # String split
    RENAME = "rename"              # Column rename
    DERIVE = "derive"              # Computed/derived column
    UNION = "union"                # UNION operation
    LOOKUP = "lookup"              # Lookup/reference join
    TRANSFORM = "transform"        # Generic transformation
    COPY = "copy"                  # Direct copy (no transform)
    TARGET = "target"              # Final output


@dataclass
class ColumnMetadata:
    """
    Detailed column information with full context

    Qualified names prevent confusion when multiple tables have same column names
    """
    column_name: str                           # Simple column name
    qualified_name: str                        # table.column for disambiguation
    data_type: str                             # Data type (STRING, INTEGER, etc.)
    source_column: Optional[str] = None        # Parent column (qualified)
    transformation: Optional[str] = None       # What happened (CAST, CONCAT, etc.)
    transformation_logic: Optional[str] = None # Actual SQL/code
    is_derived: bool = False                   # True if computed/derived
    derivation_expr: Optional[str] = None      # Expression used to derive
    business_meaning: Optional[str] = None     # AI-inferred business purpose
    nullable: bool = True                      # Can contain NULL
    is_key: bool = False                       # Is primary/foreign key
    description: Optional[str] = None          # User/AI-generated description

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class TransformationStep:
    """
    A single transformation in the lineage chain

    Maintains chronological order via step_number
    """
    step_number: int                          # Order in sequence (0 = source)
    transformation_type: TransformationType    # Type of transformation
    input_columns: List[str]                  # Input columns (qualified names)
    output_column: str                        # Output column (qualified)
    logic: str                                # Transformation SQL/code
    business_logic: Optional[str] = None      # AI-inferred business purpose
    created_in: str = ""                      # Job/graph/notebook name
    created_in_step: str = ""                 # Specific component/activity
    created_in_line: Optional[int] = None     # Line number in source file
    system: str = ""                          # abinitio, hadoop, databricks
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        result = asdict(self)
        result['transformation_type'] = self.transformation_type.value
        return result


@dataclass
class TableLineageNode:
    """
    Represents a table in the lineage graph

    Tables are nodes, transformations are edges
    """
    table_name: str                           # Fully qualified: system.database.table
    system: str                               # abinitio, hadoop, databricks
    database: str                             # Database/schema name
    table_type: str                           # source, intermediate, target
    columns: List[ColumnMetadata]             # All columns with metadata
    transformation_step: int                  # Order in sequence (0=source)
    created_by: str = ""                      # Job/graph/notebook that created it
    created_by_logic: str = ""                # Actual transformation code
    input_tables: List[str] = field(default_factory=list)   # Parent tables
    output_tables: List[str] = field(default_factory=list)  # Child tables
    row_count: Optional[int] = None           # Estimated row count
    business_purpose: Optional[str] = None    # AI-inferred purpose
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        result = asdict(self)
        result['columns'] = [col.to_dict() for col in self.columns]
        return result

    def get_column(self, column_name: str) -> Optional[ColumnMetadata]:
        """Get column metadata by name"""
        for col in self.columns:
            if col.column_name == column_name:
                return col
        return None


@dataclass
class ColumnLineageChain:
    """
    Complete lineage for a single column from source to target

    Shows the full journey with all transformations
    """
    target_column: str                        # Final column (qualified)
    source_columns: List[str]                 # Original source columns (qualified)
    transformation_steps: List[TransformationStep]  # Ordered steps
    full_journey: str = ""                    # Human-readable journey
    business_narrative: str = ""              # AI-generated business explanation
    confidence: float = 1.0                   # AI confidence in lineage
    warnings: List[str] = field(default_factory=list)  # Potential issues

    def to_dict(self) -> Dict[str, Any]:
        result = asdict(self)
        result['transformation_steps'] = [step.to_dict() for step in self.transformation_steps]
        return result

    def get_journey_summary(self) -> str:
        """Get concise journey summary"""
        if len(self.source_columns) == 1:
            return f"{self.source_columns[0]} → {self.target_column} ({len(self.transformation_steps)} steps)"
        else:
            sources = ", ".join(self.source_columns)
            return f"[{sources}] → {self.target_column} ({len(self.transformation_steps)} steps)"


@dataclass
class TableLineageGraph:
    """
    Complete table lineage graph for a workflow

    DAG structure: nodes are tables, edges are transformations
    """
    workflow_name: str                        # Source workflow/pipeline
    system: str                               # Primary system
    source_tables: List[TableLineageNode]     # Starting tables (step 0)
    intermediate_tables: List[TableLineageNode]  # Middle tables (steps 1..n-1)
    target_tables: List[TableLineageNode]     # Final tables (step n)
    transformation_count: int = 0             # Total transformations
    systems_involved: List[str] = field(default_factory=list)  # Systems in lineage
    business_summary: str = ""                # AI-generated workflow summary
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'workflow_name': self.workflow_name,
            'system': self.system,
            'source_tables': [t.to_dict() for t in self.source_tables],
            'intermediate_tables': [t.to_dict() for t in self.intermediate_tables],
            'target_tables': [t.to_dict() for t in self.target_tables],
            'transformation_count': self.transformation_count,
            'systems_involved': self.systems_involved,
            'business_summary': self.business_summary,
            'metadata': self.metadata
        }

    def get_all_tables(self) -> List[TableLineageNode]:
        """Get all tables in chronological order"""
        return self.source_tables + self.intermediate_tables + self.target_tables

    def get_table_by_name(self, table_name: str) -> Optional[TableLineageNode]:
        """Find table by name"""
        for table in self.get_all_tables():
            if table.table_name == table_name:
                return table
        return None

    def get_max_steps(self) -> int:
        """Get maximum transformation steps"""
        all_tables = self.get_all_tables()
        return max([t.transformation_step for t in all_tables], default=0)


@dataclass
class LineageExtractionResult:
    """
    Result of lineage extraction from code

    Used by AI lineage extractor
    """
    source_tables: List[Dict[str, Any]]       # Tables read from
    target_tables: List[Dict[str, Any]]       # Tables written to
    transformations: List[Dict[str, Any]]     # Transformation steps
    column_mappings: List[Dict[str, Any]]     # Column-level mappings
    transformation_sequence: List[int]        # Chronological order
    business_logic: str = ""                  # AI-extracted business purpose
    confidence: float = 1.0                   # Extraction confidence
    warnings: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ComprehensiveLineageReport:
    """
    Complete lineage report with AI business narrative

    This is what gets returned to the user
    """
    query: str                                # Original query
    table_lineage: Optional[TableLineageGraph] = None
    column_lineages: List[ColumnLineageChain] = field(default_factory=list)

    # AI-Generated Comprehensive Narrative
    executive_summary: str = ""               # High-level overview
    business_purpose: str = ""                # What does this workflow do?
    data_flow_narrative: str = ""             # Complete data journey
    transformation_narrative: str = ""        # Detailed transformation explanation
    key_insights: List[str] = field(default_factory=list)  # Important findings
    potential_issues: List[str] = field(default_factory=list)  # Warnings
    recommendations: List[str] = field(default_factory=list)  # Suggestions

    # Metadata
    lineage_confidence: float = 1.0
    systems_involved: List[str] = field(default_factory=list)
    total_transformations: int = 0
    created_at: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            'query': self.query,
            'table_lineage': self.table_lineage.to_dict() if self.table_lineage else None,
            'column_lineages': [cl.to_dict() for cl in self.column_lineages],
            'executive_summary': self.executive_summary,
            'business_purpose': self.business_purpose,
            'data_flow_narrative': self.data_flow_narrative,
            'transformation_narrative': self.transformation_narrative,
            'key_insights': self.key_insights,
            'potential_issues': self.potential_issues,
            'recommendations': self.recommendations,
            'lineage_confidence': self.lineage_confidence,
            'systems_involved': self.systems_involved,
            'total_transformations': self.total_transformations,
            'created_at': self.created_at
        }

    def to_json(self, indent: int = 2) -> str:
        """Convert to JSON string"""
        return json.dumps(self.to_dict(), indent=indent)


# Utility functions

def qualify_column_name(table_name: str, column_name: str) -> str:
    """Create qualified column name for disambiguation"""
    return f"{table_name}.{column_name}"


def parse_qualified_name(qualified_name: str) -> tuple[str, str]:
    """Parse qualified name into table and column"""
    if '.' in qualified_name:
        parts = qualified_name.rsplit('.', 1)
        return parts[0], parts[1]
    return "", qualified_name


def create_transformation_step(
    step_number: int,
    transform_type: TransformationType,
    input_cols: List[str],
    output_col: str,
    logic: str,
    created_in: str = "",
    system: str = ""
) -> TransformationStep:
    """Helper to create transformation step"""
    return TransformationStep(
        step_number=step_number,
        transformation_type=transform_type,
        input_columns=input_cols,
        output_column=output_col,
        logic=logic,
        created_in=created_in,
        system=system
    )
