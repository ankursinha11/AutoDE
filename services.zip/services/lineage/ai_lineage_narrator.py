"""
AI Lineage Narrator
===================

Generates comprehensive, business-focused narratives explaining:
- Complete data journey from source to target
- Business purpose of each transformation
- Logic and use case understanding
- Key insights and recommendations

Uses advanced RAG with context-rich prompts
"""

from typing import List, Dict, Any, Optional
from loguru import logger
from datetime import datetime

from services.lineage.enhanced_lineage_structures import (
    TableLineageGraph,
    ColumnLineageChain,
    TableLineageNode,
    TransformationStep,
    ComprehensiveLineageReport
)


class AILineageNarrator:
    """
    Generate comprehensive business narratives for lineage

    Uses AI to understand and explain:
    - Data flow journey
    - Business logic and purpose
    - Transformation rationale
    - Potential issues and recommendations
    """

    def __init__(self, ai_analyzer):
        """
        Initialize narrator

        Args:
            ai_analyzer: AIAnalyzer for OpenAI calls
        """
        self.ai_analyzer = ai_analyzer
        logger.info("✓ AI Lineage Narrator initialized")

    def generate_comprehensive_narrative(
        self,
        query: str,
        table_lineage: Optional[TableLineageGraph] = None,
        column_lineages: List[ColumnLineageChain] = None
    ) -> ComprehensiveLineageReport:
        """
        Generate complete lineage narrative with business insights

        This is the main entry point for creating comprehensive explanations

        Args:
            query: Original user query
            table_lineage: Table-level lineage graph
            column_lineages: Column-level lineage chains

        Returns:
            Comprehensive report with AI-generated narratives
        """
        logger.info("🤖 Generating comprehensive lineage narrative...")

        column_lineages = column_lineages or []

        report = ComprehensiveLineageReport(
            query=query,
            table_lineage=table_lineage,
            column_lineages=column_lineages,
            created_at=datetime.now().isoformat()
        )

        # Generate AI narratives
        if table_lineage:
            report.executive_summary = self._generate_executive_summary(table_lineage)
            report.business_purpose = self._generate_business_purpose(table_lineage)
            report.data_flow_narrative = self._generate_data_flow_narrative(table_lineage)
            report.transformation_narrative = self._generate_transformation_narrative(table_lineage, column_lineages)
            report.key_insights = self._extract_key_insights(table_lineage, column_lineages)
            report.potential_issues = self._identify_potential_issues(table_lineage, column_lineages)
            report.recommendations = self._generate_recommendations(table_lineage, column_lineages)

            report.systems_involved = table_lineage.systems_involved
            report.total_transformations = table_lineage.transformation_count
            report.lineage_confidence = self._calculate_confidence(table_lineage, column_lineages)

        logger.info("✅ Comprehensive narrative generated")
        return report

    def _generate_executive_summary(self, table_lineage: TableLineageGraph) -> str:
        """Generate high-level executive summary"""

        source_count = len(table_lineage.source_tables)
        target_count = len(table_lineage.target_tables)
        intermediate_count = len(table_lineage.intermediate_tables)
        systems = ", ".join(table_lineage.systems_involved)

        # Build context for AI
        context = f"""
Workflow: {table_lineage.workflow_name}
Systems: {systems}
Source Tables: {source_count}
Intermediate Tables: {intermediate_count}
Target Tables: {target_count}
Total Transformations: {table_lineage.transformation_count}

Source Tables:
{self._format_tables_for_prompt(table_lineage.source_tables)}

Target Tables:
{self._format_tables_for_prompt(table_lineage.target_tables)}
"""

        prompt = f"""You are a data engineering expert analyzing a data pipeline.

Generate a 3-4 sentence executive summary that explains:
1. What this workflow does at a high level
2. Where the data comes from and where it goes
3. The primary business value

Context:
{context}

Return only the executive summary (no labels, no formatting).
"""

        try:
            summary = self.ai_analyzer.analyze_code(
                code=prompt,
                context="",
                analysis_type="executive_summary"
            ).strip()
            return summary
        except Exception as e:
            logger.warning(f"AI summary generation failed: {e}")
            return f"This workflow processes data from {source_count} source table(s) through {intermediate_count} transformation(s) to produce {target_count} target table(s) across {systems} systems."

    def _generate_business_purpose(self, table_lineage: TableLineageGraph) -> str:
        """Generate detailed business purpose explanation"""

        # Build comprehensive context
        all_tables = table_lineage.get_all_tables()
        table_descriptions = []

        for table in all_tables:
            desc = f"- {table.table_name} ({table.table_type})"
            if table.business_purpose:
                desc += f": {table.business_purpose}"
            table_descriptions.append(desc)

        context = f"""
Workflow: {table_lineage.workflow_name}

Tables:
{chr(10).join(table_descriptions)}

Transformation Steps: {table_lineage.transformation_count}
"""

        prompt = f"""You are a business analyst explaining a data pipeline to stakeholders.

Explain the business purpose of this workflow in detail:
- What business problem does it solve?
- What business entities are involved (customers, products, orders, etc.)?
- What business value does it create?
- Who are the likely consumers of this data?

Context:
{context}

Write a comprehensive 4-6 sentence business purpose explanation.
"""

        try:
            purpose = self.ai_analyzer.analyze_code(
                code=prompt,
                context="",
                analysis_type="business_purpose"
            ).strip()
            return purpose
        except Exception as e:
            logger.warning(f"Business purpose generation failed: {e}")
            return "This workflow processes business data to support analytical and operational requirements."

    def _generate_data_flow_narrative(self, table_lineage: TableLineageGraph) -> str:
        """
        Generate complete data flow narrative

        This explains the full journey in chronological order
        """

        narrative_parts = []

        # Source section
        narrative_parts.append("## Data Journey\n")
        narrative_parts.append(f"### Stage 0: Data Sources\n")
        narrative_parts.append(f"The journey begins with {len(table_lineage.source_tables)} source table(s):\n")

        for table in table_lineage.source_tables:
            table_info = f"- **{table.table_name}** ({table.system})"
            if table.business_purpose:
                table_info += f"\n  - Purpose: {table.business_purpose}"
            if table.columns:
                col_names = [col.column_name for col in table.columns[:5]]
                table_info += f"\n  - Columns: {', '.join(col_names)}"
                if len(table.columns) > 5:
                    table_info += f" ... ({len(table.columns)} total)"
            narrative_parts.append(table_info + "\n")

        # Intermediate transformations
        for i, table in enumerate(table_lineage.intermediate_tables, 1):
            narrative_parts.append(f"\n### Stage {table.transformation_step}: {table.table_name}\n")

            # Explain what happened
            if table.input_tables:
                inputs = ", ".join([f"`{t}`" for t in table.input_tables])
                narrative_parts.append(f"Created from: {inputs}\n")

            if table.created_by:
                narrative_parts.append(f"Created by: `{table.created_by}`\n")

            # Use AI to explain transformation logic
            if table.created_by_logic:
                transformation_explanation = self._explain_transformation_with_ai(
                    table.table_name,
                    table.input_tables,
                    table.created_by_logic,
                    table.system
                )
                narrative_parts.append(f"\n**Transformation Logic:**\n{transformation_explanation}\n")

            # Column summary
            if table.columns:
                narrative_parts.append(f"\n**Resulting Columns:** {len(table.columns)} columns\n")
                key_cols = [col.column_name for col in table.columns if col.is_key]
                if key_cols:
                    narrative_parts.append(f"- Key columns: {', '.join(key_cols)}\n")

        # Target section
        narrative_parts.append(f"\n### Final Stage: Target Tables\n")
        narrative_parts.append(f"The pipeline produces {len(table_lineage.target_tables)} target table(s):\n")

        for table in table_lineage.target_tables:
            table_info = f"- **{table.table_name}** ({table.system})"
            if table.business_purpose:
                table_info += f"\n  - Purpose: {table.business_purpose}"
            if table.row_count:
                table_info += f"\n  - Estimated rows: {table.row_count:,}"
            narrative_parts.append(table_info + "\n")

        return "\n".join(narrative_parts)

    def _generate_transformation_narrative(
        self,
        table_lineage: TableLineageGraph,
        column_lineages: List[ColumnLineageChain]
    ) -> str:
        """
        Generate detailed transformation narrative

        Explains column-level transformations and business logic
        """

        narrative_parts = []

        narrative_parts.append("## Detailed Transformation Analysis\n")

        # If column lineages available, explain each
        if column_lineages:
            narrative_parts.append(f"### Column-Level Transformations\n")
            narrative_parts.append(f"Analyzing {len(column_lineages)} key column(s):\n")

            for col_lineage in column_lineages[:10]:  # Limit to top 10
                narrative_parts.append(f"\n#### {col_lineage.target_column}\n")

                # Show journey
                journey_summary = col_lineage.get_journey_summary()
                narrative_parts.append(f"**Journey:** {journey_summary}\n")

                # Show transformation steps
                if col_lineage.transformation_steps:
                    narrative_parts.append(f"\n**Transformation Steps:**\n")
                    for step in col_lineage.transformation_steps:
                        step_desc = f"{step.step_number}. **{step.transformation_type.value.upper()}**"
                        if step.business_logic:
                            step_desc += f": {step.business_logic}"
                        elif step.logic:
                            step_desc += f": `{step.logic[:100]}`"
                        if step.created_in:
                            step_desc += f" (in `{step.created_in}`)"
                        narrative_parts.append(f"   {step_desc}\n")

                # Business narrative if available
                if col_lineage.business_narrative:
                    narrative_parts.append(f"\n**Business Context:** {col_lineage.business_narrative}\n")

        # AI-powered transformation type analysis
        all_transformations = []
        for table in table_lineage.intermediate_tables:
            if table.created_by_logic:
                all_transformations.append({
                    'table': table.table_name,
                    'logic': table.created_by_logic[:500]  # Limit length
                })

        if all_transformations:
            transform_types_summary = self._analyze_transformation_types_with_ai(all_transformations)
            narrative_parts.append(f"\n### Transformation Pattern Analysis\n")
            narrative_parts.append(transform_types_summary + "\n")

        return "\n".join(narrative_parts)

    def _extract_key_insights(
        self,
        table_lineage: TableLineageGraph,
        column_lineages: List[ColumnLineageChain]
    ) -> List[str]:
        """Extract key insights using AI"""

        insights = []

        # System complexity
        if len(table_lineage.systems_involved) > 1:
            systems_str = ", ".join(table_lineage.systems_involved)
            insights.append(f"Cross-system lineage spanning {systems_str}")

        # Transformation complexity
        if table_lineage.transformation_count > 5:
            insights.append(f"Complex pipeline with {table_lineage.transformation_count} transformation steps")

        # Column transformations
        if column_lineages:
            derived_cols = [col for col in column_lineages if any(s.transformation_type.value == "derive" for s in col.transformation_steps)]
            if derived_cols:
                insights.append(f"{len(derived_cols)} derived/computed columns created")

        # AI-powered insights
        context = f"""
Workflow: {table_lineage.workflow_name}
Source tables: {len(table_lineage.source_tables)}
Target tables: {len(table_lineage.target_tables)}
Transformations: {table_lineage.transformation_count}
Systems: {', '.join(table_lineage.systems_involved)}
"""

        prompt = f"""Analyze this data pipeline and identify 2-3 key technical or business insights.

Context:
{context}

Return insights as a bulleted list (one insight per line, no bullet characters).
"""

        try:
            ai_insights = self.ai_analyzer.analyze_code(
                code=prompt,
                context="",
                analysis_type="key_insights"
            ).strip()

            # Parse AI insights
            for line in ai_insights.split('\n'):
                line = line.strip().lstrip('-*•').strip()
                if line and len(line) > 10:
                    insights.append(line)

        except Exception as e:
            logger.warning(f"AI insights extraction failed: {e}")

        return insights[:5]  # Limit to 5 insights

    def _identify_potential_issues(
        self,
        table_lineage: TableLineageGraph,
        column_lineages: List[ColumnLineageChain]
    ) -> List[str]:
        """Identify potential issues in lineage"""

        issues = []

        # Check for missing lineage
        for col_lineage in column_lineages:
            if col_lineage.confidence < 0.7:
                issues.append(f"Low confidence ({col_lineage.confidence:.0%}) in lineage for {col_lineage.target_column}")

            if col_lineage.warnings:
                issues.extend(col_lineage.warnings)

        # Check for complex transformations
        for table in table_lineage.intermediate_tables:
            if len(table.input_tables) > 5:
                issues.append(f"{table.table_name} has {len(table.input_tables)} input tables - verify join logic")

        # Check for null handling
        for col_lineage in column_lineages:
            for step in col_lineage.transformation_steps:
                if 'cast' in step.logic.lower() and 'null' not in step.logic.lower():
                    issues.append(f"CAST operation in {step.output_column} may need NULL handling")
                    break

        return issues[:5]  # Limit to 5 issues

    def _generate_recommendations(
        self,
        table_lineage: TableLineageGraph,
        column_lineages: List[ColumnLineageChain]
    ) -> List[str]:
        """Generate recommendations"""

        recommendations = []

        # Based on transformation count
        if table_lineage.transformation_count > 10:
            recommendations.append("Consider breaking this pipeline into smaller, modular components for better maintainability")

        # Based on systems
        if len(table_lineage.systems_involved) > 2:
            recommendations.append("Multi-system pipeline - ensure consistent data quality checks at system boundaries")

        # Column-level recommendations
        if column_lineages:
            type_changes = [col for col in column_lineages if any('cast' in s.logic.lower() for s in col.transformation_steps)]
            if len(type_changes) > 5:
                recommendations.append(f"Multiple type conversions detected ({len(type_changes)} columns) - validate data type compatibility")

        # AI-powered recommendations
        context = f"""
Pipeline: {table_lineage.workflow_name}
Transformations: {table_lineage.transformation_count}
Systems: {', '.join(table_lineage.systems_involved)}
"""

        prompt = f"""Suggest 1-2 actionable recommendations for this data pipeline.

Context:
{context}

Focus on: performance optimization, data quality, or maintainability.
Return as a bulleted list (one recommendation per line, no bullet characters).
"""

        try:
            ai_recs = self.ai_analyzer.analyze_code(
                code=prompt,
                context="",
                analysis_type="recommendations"
            ).strip()

            for line in ai_recs.split('\n'):
                line = line.strip().lstrip('-*•').strip()
                if line and len(line) > 10:
                    recommendations.append(line)

        except Exception as e:
            logger.warning(f"AI recommendations failed: {e}")

        return recommendations[:5]  # Limit to 5 recommendations

    # Helper methods

    def _explain_transformation_with_ai(
        self,
        table_name: str,
        input_tables: List[str],
        logic: str,
        system: str
    ) -> str:
        """Use AI to explain transformation logic in business terms"""

        prompt = f"""Explain this {system} transformation in simple business terms.

Table Created: {table_name}
Input Tables: {', '.join(input_tables)}

Code:
{logic[:1000]}  # Limit length

Explain:
1. What business operation is being performed?
2. What is the purpose of this transformation?

Return 2-3 sentences explaining the business logic.
"""

        try:
            explanation = self.ai_analyzer.analyze_code(
                code=prompt,
                context="",
                analysis_type="transformation_explanation"
            ).strip()
            return explanation
        except Exception as e:
            logger.warning(f"AI transformation explanation failed: {e}")
            return "Transforms input data to produce output table."

    def _analyze_transformation_types_with_ai(self, transformations: List[Dict[str, str]]) -> str:
        """Analyze transformation patterns using AI"""

        transform_summary = "\n".join([
            f"- {t['table']}: {t['logic'][:200]}"
            for t in transformations[:5]  # Limit to 5
        ])

        prompt = f"""Analyze these data transformations and identify the primary patterns.

Transformations:
{transform_summary}

Identify:
1. Main transformation types (JOIN, FILTER, AGGREGATE, etc.)
2. Overall data processing pattern
3. Complexity level

Return 2-3 sentences summarizing the transformation patterns.
"""

        try:
            analysis = self.ai_analyzer.analyze_code(
                code=prompt,
                context="",
                analysis_type="transformation_analysis"
            ).strip()
            return analysis
        except Exception as e:
            logger.warning(f"AI transformation analysis failed: {e}")
            return "Multiple transformation types are used to process the data."

    def _format_tables_for_prompt(self, tables: List[TableLineageNode]) -> str:
        """Format tables for AI prompt context"""
        lines = []
        for table in tables:
            line = f"- {table.table_name}"
            if table.columns:
                col_count = len(table.columns)
                line += f" ({col_count} columns)"
            lines.append(line)
        return "\n".join(lines)

    def _calculate_confidence(
        self,
        table_lineage: TableLineageGraph,
        column_lineages: List[ColumnLineageChain]
    ) -> float:
        """Calculate overall lineage confidence"""
        if not column_lineages:
            return 0.9  # High confidence for table-level only

        confidences = [col.confidence for col in column_lineages]
        return sum(confidences) / len(confidences)
