"""
Lineage Tracking Services
==========================
AI-driven lineage tracking and STTM generation

Enhanced Lineage Components:
- Enhanced data structures with disambiguation
- AI-powered lineage graph builder
- Comprehensive business narrative generator
- Table and column-level lineage tracking
"""

from services.lineage.sttm_generator import STTMGenerator, STTMMapping, create_sttm_generator
from services.lineage.lineage_agents import (
    ParsingAgent,
    LogicAgent,
    MappingAgent,
    SimilarityAgent,
    LineageAgent,
    LineageOrchestrator,
    LineageResult
)

# Enhanced Lineage Components (NEW)
from services.lineage.enhanced_lineage_structures import (
    TableLineageGraph,
    TableLineageNode,
    ColumnMetadata,
    ColumnLineageChain,
    TransformationStep,
    TransformationType,
    ComprehensiveLineageReport,
    qualify_column_name,
    parse_qualified_name
)

from services.lineage.lineage_graph_builder import LineageGraphBuilder
from services.lineage.ai_lineage_narrator import AILineageNarrator

__all__ = [
    # Legacy
    'STTMGenerator',
    'STTMMapping',
    'create_sttm_generator',
    'ParsingAgent',
    'LogicAgent',
    'MappingAgent',
    'SimilarityAgent',
    'LineageAgent',
    'LineageOrchestrator',
    'LineageResult',

    # Enhanced Lineage (NEW)
    'TableLineageGraph',
    'TableLineageNode',
    'ColumnMetadata',
    'ColumnLineageChain',
    'TransformationStep',
    'TransformationType',
    'ComprehensiveLineageReport',
    'LineageGraphBuilder',
    'AILineageNarrator',
    'qualify_column_name',
    'parse_qualified_name'
]
