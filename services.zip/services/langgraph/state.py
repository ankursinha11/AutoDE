"""
LangGraph Workflow State Schema
================================
Defines the state structure for the multi-agent RAG workflow.

State flows through all nodes and accumulates context, evidence, and results.
"""

from typing import List, Dict, Any, Optional, TypedDict, Literal
from typing_extensions import NotRequired
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum


class QueryIntent(str, Enum):
    """Query intent classification"""
    COLUMN_TRANSFORMATION = "column_transformation"
    PIPELINE_LOGIC = "pipeline_logic"
    COMPARISON = "comparison"
    EXCEL_GENERATION = "excel_generation"
    GENERAL_QUESTION = "general_question"
    LINEAGE_TRACKING = "lineage_tracking"
    CODE_SEARCH = "code_search"


class SystemType(str, Enum):
    """Supported system types"""
    HADOOP = "hadoop"
    DATABRICKS = "databricks"
    ABINITIO = "abinitio"
    AUTOSYS = "autosys"


class WorkflowState(TypedDict, total=False):
    """
    Complete state for LangGraph workflow

    This state flows through all workflow nodes and accumulates:
    - User query and intent
    - Conversation context
    - Retrieved documents
    - File contents (evidence)
    - Analysis results
    - Generated outputs
    """

    # ============================================
    # Input (from user)
    # ============================================
    query: str  # User's question
    session_id: str  # Unique session identifier

    # ============================================
    # Query Analysis
    # ============================================
    intent: QueryIntent  # Classified intent
    systems: List[SystemType]  # Systems involved (hadoop, databricks, etc.)
    entities: Dict[str, Any]  # Extracted entities (workflow names, column names, etc.)
    pipeline_filter: Optional[str]  # Pipeline/workflow name to filter by

    # ============================================
    # Conversation Context
    # ============================================
    conversation_history: List[Dict[str, str]]  # Previous exchanges
    context_summary: Optional[str]  # Summarized context for long conversations

    # ============================================
    # Retrieval Results
    # ============================================
    retrieved_docs: List[Dict[str, Any]]  # Documents from vector search
    retrieval_metadata: Dict[str, Any]  # Retrieval stats (top_k, scores, etc.)

    # ============================================
    # Evidence (File Contents)
    # ============================================
    file_contents: Dict[str, str]  # file_path -> actual file content
    file_metadata: Dict[str, Dict[str, Any]]  # file_path -> metadata

    # ============================================
    # Analysis Results
    # ============================================
    analysis_results: Dict[str, Any]  # Code understanding, logic extraction
    column_mappings: List[Dict[str, Any]]  # Column-level transformations
    logic_comparison: Optional[Dict[str, Any]]  # Cross-system comparison

    # ============================================
    # Generation Outputs
    # ============================================
    excel_path: Optional[str]  # Path to generated Excel file
    excel_metadata: Optional[Dict[str, Any]]  # Excel generation metadata

    # ============================================
    # Response
    # ============================================
    response: str  # Final answer to user
    evidence: List[Dict[str, Any]]  # Evidence citations (file paths, line numbers)
    confidence_score: float  # Confidence in the answer (0-1)

    # ============================================
    # Workflow Metadata
    # ============================================
    workflow_step: str  # Current step in workflow
    errors: List[str]  # Any errors encountered
    timestamps: Dict[str, str]  # Timestamps for each step


@dataclass
class Evidence:
    """
    Evidence for an answer

    Attributes:
        file_path: Path to source file
        line_numbers: Relevant line numbers
        content_snippet: Code snippet or text
        relevance_score: How relevant this evidence is (0-1)
        system: Which system this is from (hadoop, databricks, etc.)
    """
    file_path: str
    line_numbers: Optional[List[int]] = None
    content_snippet: Optional[str] = None
    relevance_score: float = 1.0
    system: Optional[SystemType] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "file_path": self.file_path,
            "line_numbers": self.line_numbers,
            "content_snippet": self.content_snippet,
            "relevance_score": self.relevance_score,
            "system": self.system.value if self.system else None,
            "metadata": self.metadata
        }


@dataclass
class RetrievalResult:
    """
    Result from retrieval stage

    Attributes:
        documents: Retrieved documents
        scores: Relevance scores
        method: Retrieval method used (hybrid, semantic, keyword)
        reranked: Whether results were reranked
    """
    documents: List[Dict[str, Any]]
    scores: List[float]
    method: Literal["hybrid", "semantic", "keyword"]
    reranked: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class AnalysisResult:
    """
    Result from code analysis

    Attributes:
        file_path: Analyzed file
        analysis_type: Type of analysis performed
        findings: Analysis findings
        confidence: Confidence in findings (0-1)
    """
    file_path: str
    analysis_type: str  # "logic_extraction", "column_mapping", "comparison"
    findings: Dict[str, Any]
    confidence: float = 1.0
    metadata: Dict[str, Any] = field(default_factory=dict)


def create_initial_state(
    query: str,
    session_id: str,
    conversation_history: Optional[List[Dict[str, str]]] = None
) -> WorkflowState:
    """
    Create initial workflow state

    Args:
        query: User's question
        session_id: Unique session ID
        conversation_history: Previous conversation history

    Returns:
        Initial workflow state
    """
    return WorkflowState(
        query=query,
        session_id=session_id,
        conversation_history=conversation_history or [],
        retrieved_docs=[],
        file_contents={},
        file_metadata={},
        analysis_results={},
        column_mappings=[],
        evidence=[],
        confidence_score=0.0,
        response="",
        workflow_step="initialized",
        errors=[],
        timestamps={
            "initialized": datetime.now().isoformat()
        },
        retrieval_metadata={},
        systems=[],
        entities={}
    )


def update_state_timestamp(state: WorkflowState, step: str) -> None:
    """Update timestamp for a workflow step"""
    if "timestamps" not in state:
        state["timestamps"] = {}
    state["timestamps"][step] = datetime.now().isoformat()


def add_error(state: WorkflowState, error: str) -> None:
    """Add an error to the state"""
    if "errors" not in state:
        state["errors"] = []
    state["errors"].append(error)
