"""
LangGraph RAG Workflow
======================
Multi-agent workflow for intelligent codebase querying.

Workflow Steps:
1. Query Analysis - Classify intent, extract entities
2. Retrieval - Hybrid search + reranking
3. File Reading - Load actual file contents
4. Analysis - Code understanding and logic extraction
5. Generation - Excel reports or answer synthesis
6. Response - Format and return with evidence

This replaces the existing ChatOrchestrator with a more sophisticated,
graph-based approach.
"""

from typing import Dict, List, Any, Optional, Callable
from pathlib import Path
from loguru import logger

try:
    from langgraph.graph import StateGraph, END
    from langchain_core.messages import HumanMessage, AIMessage
    LANGGRAPH_AVAILABLE = True
except ImportError:
    LANGGRAPH_AVAILABLE = False
    logger.warning("LangGraph not available - workflow will use fallback")

from services.langgraph.state import (
    WorkflowState, QueryIntent, SystemType,
    create_initial_state, update_state_timestamp, add_error
)
from services.langgraph.memory import ConversationMemory
from services.retrieval.hybrid_search import HybridSearch
from services.retrieval.query_rewriter import QueryRewriter
from services.retrieval.reranker import AdaptiveReranker
from services.analysis.file_reader import FileReader
from services.analysis.code_analyzer import CodeAnalyzer


class RAGWorkflow:
    """
    LangGraph-based RAG workflow

    This orchestrates the entire query processing pipeline.
    """

    def __init__(
        self,
        ai_analyzer,
        indexer,
        vector_search_client=None
    ):
        """
        Initialize RAG workflow

        Args:
            ai_analyzer: AI analyzer for OpenAI calls
            indexer: Multi-collection indexer
            vector_search_client: Vector search client
        """
        self.ai_analyzer = ai_analyzer
        self.indexer = indexer
        self.vector_search_client = vector_search_client

        # Initialize components
        self.query_rewriter = QueryRewriter(ai_analyzer=ai_analyzer)
        self.reranker = AdaptiveReranker()
        self.file_reader = FileReader()
        self.code_analyzer = CodeAnalyzer(
            ai_analyzer=ai_analyzer,
            file_reader=self.file_reader
        )

        # Hybrid search (if vector client available)
        self.hybrid_search = None
        if vector_search_client:
            self.hybrid_search = HybridSearch(vector_search_client)

        # Conversation memories (keyed by session_id)
        self.memories: Dict[str, ConversationMemory] = {}

        # Build workflow graph
        if LANGGRAPH_AVAILABLE:
            self.graph = self._build_graph()
        else:
            self.graph = None
            logger.warning("LangGraph unavailable - using fallback workflow")

        logger.info("Initialized RAGWorkflow")

    def _build_graph(self) -> StateGraph:
        """
        Build LangGraph workflow

        Returns:
            Compiled state graph
        """
        # Create graph
        workflow = StateGraph(WorkflowState)

        # Add nodes
        workflow.add_node("analyze_query", self._analyze_query_node)
        workflow.add_node("retrieve", self._retrieve_node)
        workflow.add_node("read_files", self._read_files_node)
        workflow.add_node("analyze_code", self._analyze_code_node)
        workflow.add_node("generate_response", self._generate_response_node)

        # Define edges
        workflow.set_entry_point("analyze_query")

        # analyze_query -> retrieve
        workflow.add_edge("analyze_query", "retrieve")

        # retrieve -> read_files
        workflow.add_edge("retrieve", "read_files")

        # read_files -> analyze_code
        workflow.add_edge("read_files", "analyze_code")

        # analyze_code -> generate_response
        workflow.add_edge("analyze_code", "generate_response")

        # generate_response -> END
        workflow.add_edge("generate_response", END)

        # Compile
        compiled = workflow.compile()

        logger.info("Built LangGraph workflow with 5 nodes")

        return compiled

    def query(
        self,
        query: str,
        session_id: str = "default",
        **kwargs
    ) -> Dict[str, Any]:
        """
        Process a query through the workflow

        Args:
            query: User's question
            session_id: Session identifier
            **kwargs: Additional parameters

        Returns:
            Response dict with answer and evidence
        """
        logger.info(f"Processing query: {query}")

        # Get or create conversation memory
        if session_id not in self.memories:
            self.memories[session_id] = ConversationMemory(
                session_id=session_id,
                ai_analyzer=self.ai_analyzer
            )
        memory = self.memories[session_id]

        # Create initial state
        state = create_initial_state(
            query=query,
            session_id=session_id,
            conversation_history=memory.get_active_context()
        )

        # Run workflow
        if self.graph:
            # Use LangGraph
            try:
                result_state = self.graph.invoke(state)
            except Exception as e:
                logger.error(f"Workflow error: {e}")
                add_error(state, str(e))
                result_state = state
        else:
            # Fallback to sequential execution
            result_state = self._execute_fallback(state)

        # Update conversation memory
        memory.add_turn("user", query)
        memory.add_turn("assistant", result_state.get("response", ""))

        # Return response
        return {
            "response": result_state.get("response", ""),
            "evidence": result_state.get("evidence", []),
            "confidence_score": result_state.get("confidence_score", 0.0),
            "metadata": {
                "intent": result_state.get("intent"),
                "systems": result_state.get("systems", []),
                "files_analyzed": len(result_state.get("file_contents", {})),
                "timestamps": result_state.get("timestamps", {})
            }
        }

    # ============================================
    # Workflow Nodes
    # ============================================

    def _analyze_query_node(self, state: WorkflowState) -> WorkflowState:
        """
        Node 1: Analyze query intent and extract entities

        Updates state with:
        - intent
        - systems
        - entities
        - pipeline_filter
        """
        logger.info("Node: Analyze Query")
        update_state_timestamp(state, "analyze_query_start")

        query = state["query"]

        try:
            # Classify intent
            intent = self._classify_intent(query)
            state["intent"] = intent

            # Extract entities
            entities = self._extract_entities(query)
            state["entities"] = entities

            # Determine systems
            systems = self._determine_systems(query, entities)
            state["systems"] = systems

            # Extract pipeline filter
            pipeline_filter = entities.get("pipeline_name") or entities.get("workflow_name")
            state["pipeline_filter"] = pipeline_filter

            logger.info(f"  Intent: {intent}, Systems: {systems}, Filter: {pipeline_filter}")

        except Exception as e:
            logger.error(f"Query analysis error: {e}")
            add_error(state, f"Query analysis failed: {e}")

        update_state_timestamp(state, "analyze_query_end")
        state["workflow_step"] = "analyze_query_complete"

        return state

    def _retrieve_node(self, state: WorkflowState) -> WorkflowState:
        """
        Node 2: Retrieve relevant documents

        Updates state with:
        - retrieved_docs
        - retrieval_metadata
        """
        logger.info("Node: Retrieve")
        update_state_timestamp(state, "retrieve_start")

        query = state["query"]
        intent = state.get("intent")
        systems = state.get("systems", [])
        pipeline_filter = state.get("pipeline_filter")

        try:
            # Rewrite query for better retrieval
            rewritten_query = self.query_rewriter.rewrite_query(
                query=query,
                intent=intent,
                context=state.get("conversation_history")
            )

            # Determine top_k based on intent
            top_k = self._get_top_k_for_intent(intent)

            # Determine collections to search
            collections = self._get_collections_for_systems(systems)

            # Perform retrieval
            all_results = []
            for collection in collections:
                results = self._search_collection(
                    collection=collection,
                    query=rewritten_query,
                    top_k=top_k,
                    pipeline_filter=pipeline_filter
                )
                all_results.extend(results)

            # Rerank results
            if all_results:
                reranked = self.reranker.rerank(
                    query=query,
                    documents=[r["document"] for r in all_results],
                    top_k=top_k,
                    query_intent=intent
                )

                state["retrieved_docs"] = [r.to_dict() for r in reranked]
            else:
                state["retrieved_docs"] = []

            state["retrieval_metadata"] = {
                "rewritten_query": rewritten_query,
                "collections_searched": collections,
                "initial_results": len(all_results),
                "final_results": len(state["retrieved_docs"]),
                "top_k": top_k
            }

            logger.info(f"  Retrieved {len(state['retrieved_docs'])} documents")

        except Exception as e:
            logger.error(f"Retrieval error: {e}")
            add_error(state, f"Retrieval failed: {e}")
            state["retrieved_docs"] = []

        update_state_timestamp(state, "retrieve_end")
        state["workflow_step"] = "retrieve_complete"

        return state

    def _read_files_node(self, state: WorkflowState) -> WorkflowState:
        """
        Node 3: Read actual file contents

        Updates state with:
        - file_contents
        - file_metadata
        """
        logger.info("Node: Read Files")
        update_state_timestamp(state, "read_files_start")

        retrieved_docs = state.get("retrieved_docs", [])

        try:
            file_contents = {}
            file_metadata = {}

            # Extract file paths from retrieved docs
            file_paths = []
            for doc in retrieved_docs:
                doc_data = doc.get("document", {})
                metadata = doc_data.get("metadata", {})

                if "file_path" in metadata:
                    file_paths.append(metadata["file_path"])

            # Remove duplicates
            file_paths = list(set(file_paths))

            # Read files
            logger.info(f"  Reading {len(file_paths)} files")

            for file_path in file_paths[:10]:  # Limit to top 10 files
                content = self.file_reader.read_file(file_path)
                if content:
                    file_contents[file_path] = content.content
                    file_metadata[file_path] = content.to_dict()

            state["file_contents"] = file_contents
            state["file_metadata"] = file_metadata

            logger.info(f"  Read {len(file_contents)} files successfully")

        except Exception as e:
            logger.error(f"File reading error: {e}")
            add_error(state, f"File reading failed: {e}")
            state["file_contents"] = {}
            state["file_metadata"] = {}

        update_state_timestamp(state, "read_files_end")
        state["workflow_step"] = "read_files_complete"

        return state

    def _analyze_code_node(self, state: WorkflowState) -> WorkflowState:
        """
        Node 4: Analyze code to extract logic

        Updates state with:
        - analysis_results
        - column_mappings
        """
        logger.info("Node: Analyze Code")
        update_state_timestamp(state, "analyze_code_start")

        file_contents = state.get("file_contents", {})
        intent = state.get("intent")

        try:
            analysis_results = {}

            # Only analyze if we have files and intent requires it
            if file_contents and intent in [
                QueryIntent.COLUMN_TRANSFORMATION,
                QueryIntent.PIPELINE_LOGIC,
                QueryIntent.COMPARISON
            ]:
                logger.info(f"  Analyzing {len(file_contents)} files")

                for file_path in list(file_contents.keys())[:5]:  # Limit to top 5
                    analysis = self.code_analyzer.analyze_file(
                        file_path=file_path,
                        analysis_type="full"
                    )

                    if analysis:
                        analysis_results[file_path] = analysis.to_dict()

                # Extract column mappings
                column_mappings = []
                for analysis in analysis_results.values():
                    column_mappings.extend(analysis.get("column_transformations", []))

                state["column_mappings"] = column_mappings
            else:
                state["column_mappings"] = []

            state["analysis_results"] = analysis_results

            logger.info(f"  Analyzed {len(analysis_results)} files")

        except Exception as e:
            logger.error(f"Code analysis error: {e}")
            add_error(state, f"Code analysis failed: {e}")
            state["analysis_results"] = {}
            state["column_mappings"] = []

        update_state_timestamp(state, "analyze_code_end")
        state["workflow_step"] = "analyze_code_complete"

        return state

    def _generate_response_node(self, state: WorkflowState) -> WorkflowState:
        """
        Node 5: Generate final response

        Updates state with:
        - response
        - evidence
        - confidence_score
        """
        logger.info("Node: Generate Response")
        update_state_timestamp(state, "generate_response_start")

        query = state["query"]
        intent = state.get("intent")
        retrieved_docs = state.get("retrieved_docs", [])
        analysis_results = state.get("analysis_results", {})

        try:
            # Build evidence
            evidence = self._build_evidence(retrieved_docs, analysis_results)
            state["evidence"] = evidence

            # Generate response based on intent
            if intent == QueryIntent.EXCEL_GENERATION:
                response = self._generate_excel_response(state)
            else:
                response = self._generate_text_response(state)

            state["response"] = response

            # Calculate confidence
            confidence = self._calculate_confidence(state)
            state["confidence_score"] = confidence

            logger.info(f"  Generated response (confidence: {confidence:.2f})")

        except Exception as e:
            logger.error(f"Response generation error: {e}")
            add_error(state, f"Response generation failed: {e}")
            state["response"] = "Sorry, I encountered an error generating the response."
            state["evidence"] = []
            state["confidence_score"] = 0.0

        update_state_timestamp(state, "generate_response_end")
        state["workflow_step"] = "complete"

        return state

    # ============================================
    # Helper Methods
    # ============================================

    def _classify_intent(self, query: str) -> QueryIntent:
        """Classify query intent"""
        query_lower = query.lower()

        if any(word in query_lower for word in ["column", "field", "transformation", "mapping"]):
            return QueryIntent.COLUMN_TRANSFORMATION
        elif any(word in query_lower for word in ["logic", "step", "process", "workflow"]):
            return QueryIntent.PIPELINE_LOGIC
        elif any(word in query_lower for word in ["compare", "difference", "vs", "versus"]):
            return QueryIntent.COMPARISON
        elif any(word in query_lower for word in ["excel", "generate", "report", "sttm"]):
            return QueryIntent.EXCEL_GENERATION
        elif any(word in query_lower for word in ["lineage", "flow", "trace"]):
            return QueryIntent.LINEAGE_TRACKING
        else:
            return QueryIntent.GENERAL_QUESTION

    def _extract_entities(self, query: str) -> Dict[str, Any]:
        """Extract entities from query"""
        # This is a simple implementation - can be enhanced with NER
        import re

        entities = {}

        # Extract quoted strings (likely entity names)
        quoted = re.findall(r'"([^"]+)"', query)
        if quoted:
            entities["workflow_name"] = quoted[0]

        return entities

    def _determine_systems(self, query: str, entities: Dict[str, Any]) -> List[SystemType]:
        """Determine which systems are involved"""
        query_lower = query.lower()
        systems = []

        if "hadoop" in query_lower or "hive" in query_lower or "pig" in query_lower:
            systems.append(SystemType.HADOOP)
        if "databricks" in query_lower or "spark" in query_lower:
            systems.append(SystemType.DATABRICKS)
        if "abinitio" in query_lower or "ab initio" in query_lower:
            systems.append(SystemType.ABINITIO)

        # Default to all if none specified
        if not systems:
            systems = [SystemType.HADOOP, SystemType.DATABRICKS]

        return systems

    def _get_top_k_for_intent(self, intent: Optional[QueryIntent]) -> int:
        """Get appropriate top-k based on intent"""
        if intent == QueryIntent.COLUMN_TRANSFORMATION:
            return 15
        elif intent == QueryIntent.COMPARISON:
            return 20
        elif intent == QueryIntent.PIPELINE_LOGIC:
            return 10
        else:
            return 5

    def _get_collections_for_systems(self, systems: List[SystemType]) -> List[str]:
        """Get collection names for systems"""
        collection_map = {
            SystemType.HADOOP: "hadoop_collection",
            SystemType.DATABRICKS: "databricks_collection",
            SystemType.ABINITIO: "abinitio_collection"
        }

        return [collection_map[sys] for sys in systems if sys in collection_map]

    def _search_collection(
        self,
        collection: str,
        query: str,
        top_k: int,
        pipeline_filter: Optional[str]
    ) -> List[Dict[str, Any]]:
        """Search a single collection"""
        # Use hybrid search if available
        if self.hybrid_search:
            results = self.hybrid_search.search(
                query=query,
                collection_name=collection,
                top_k=top_k
            )
            return [{"document": r.document, "score": r.score} for r in results]
        else:
            # Fallback to indexer search
            search_results = self.indexer.search_multi_collection(
                query=query,
                collections=[collection],
                top_k=top_k
            )
            return search_results.get(collection, [])

    def _build_evidence(
        self,
        retrieved_docs: List[Dict[str, Any]],
        analysis_results: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        """Build evidence list from docs and analysis"""
        evidence = []

        for doc in retrieved_docs[:5]:  # Top 5 docs
            doc_data = doc.get("document", {})
            metadata = doc_data.get("metadata", {})

            evidence.append({
                "file_path": metadata.get("file_path", "Unknown"),
                "title": doc_data.get("title", ""),
                "relevance_score": doc.get("rerank_score", doc.get("score", 0.0)),
                "system": metadata.get("system", "")
            })

        return evidence

    def _generate_text_response(self, state: WorkflowState) -> str:
        """Generate text response"""
        # Use AI to synthesize answer from evidence
        # This is a simplified implementation
        query = state["query"]
        evidence = state.get("evidence", [])
        analysis_results = state.get("analysis_results", {})

        response_parts = []
        response_parts.append(f"Based on my analysis of the codebase:")
        response_parts.append("")

        # Add findings
        if analysis_results:
            for file_path, analysis in list(analysis_results.items())[:3]:
                response_parts.append(f"**{Path(file_path).name}:**")
                response_parts.append(f"- {analysis.get('summary', 'N/A')}")

        # Add sources
        if evidence:
            response_parts.append("")
            response_parts.append("**Sources:**")
            for ev in evidence[:3]:
                response_parts.append(f"- {ev.get('file_path', 'Unknown')}")

        return "\n".join(response_parts)

    def _generate_excel_response(self, state: WorkflowState) -> str:
        """Generate response for Excel generation request"""
        return "Excel generation requested - this would trigger the Excel generator."

    def _calculate_confidence(self, state: WorkflowState) -> float:
        """Calculate confidence score"""
        # Simple confidence calculation
        score = 0.5

        # Boost if we have evidence
        if state.get("evidence"):
            score += 0.2

        # Boost if we analyzed files
        if state.get("analysis_results"):
            score += 0.3

        return min(score, 1.0)

    def _execute_fallback(self, state: WorkflowState) -> WorkflowState:
        """Fallback execution without LangGraph"""
        logger.info("Using fallback workflow execution")

        state = self._analyze_query_node(state)
        state = self._retrieve_node(state)
        state = self._read_files_node(state)
        state = self._analyze_code_node(state)
        state = self._generate_response_node(state)

        return state
