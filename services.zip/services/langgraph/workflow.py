"""
LangGraph RAG Workflow
======================
Multi-agent workflow for intelligent codebase querying.

Workflow Steps:
1. Query Analysis - Classify intent, extract entities
2. Retrieval - Hybrid search + reranking
3. File Reading - Load actual file contents
4. Analysis - Code understanding and logic extraction
5. Generation - Excel reports or answer synthesis
6. Response - Format and return with evidence

This replaces the existing ChatOrchestrator with a more sophisticated,
graph-based approach.
"""

from typing import Dict, List, Any, Optional, Callable
from pathlib import Path
from loguru import logger

try:
    from langgraph.graph import StateGraph, END
    from langchain_core.messages import HumanMessage, AIMessage
    LANGGRAPH_AVAILABLE = True
except ImportError:
    LANGGRAPH_AVAILABLE = False
    logger.warning("LangGraph not available - workflow will use fallback")

from services.langgraph.state import (
    WorkflowState, QueryIntent, SystemType,
    create_initial_state, update_state_timestamp, add_error
)
from services.langgraph.memory import ConversationMemory
from services.retrieval.hybrid_search import HybridSearch
from services.retrieval.query_rewriter import QueryRewriter
from services.retrieval.reranker import AdaptiveReranker
from services.analysis.file_reader import FileReader
from services.analysis.code_analyzer import CodeAnalyzer


class RAGWorkflow:
    """
    LangGraph-based RAG workflow

    This orchestrates the entire query processing pipeline.
    """

    def __init__(
        self,
        ai_analyzer,
        indexer,
        vector_search_client=None
    ):
        """
        Initialize RAG workflow

        Args:
            ai_analyzer: AI analyzer for OpenAI calls
            indexer: Multi-collection indexer
            vector_search_client: Vector search client
        """
        self.ai_analyzer = ai_analyzer
        self.indexer = indexer
        self.vector_search_client = vector_search_client

        # Initialize components
        self.query_rewriter = QueryRewriter(ai_analyzer=ai_analyzer)
        self.reranker = AdaptiveReranker()
        self.file_reader = FileReader()
        self.code_analyzer = CodeAnalyzer(
            ai_analyzer=ai_analyzer,
            file_reader=self.file_reader
        )

        # Hybrid search (if vector client available)
        self.hybrid_search = None
        if vector_search_client:
            self.hybrid_search = HybridSearch(vector_search_client)

        # Conversation memories (keyed by session_id)
        self.memories: Dict[str, ConversationMemory] = {}

        # Build workflow graph
        if LANGGRAPH_AVAILABLE:
            self.graph = self._build_graph()
        else:
            self.graph = None
            logger.warning("LangGraph unavailable - using fallback workflow")

        logger.info("Initialized RAGWorkflow")

    def _build_graph(self) -> StateGraph:
        """
        Build LangGraph workflow

        Returns:
            Compiled state graph
        """
        # Create graph
        workflow = StateGraph(WorkflowState)

        # Add nodes
        workflow.add_node("analyze_query", self._analyze_query_node)
        workflow.add_node("retrieve", self._retrieve_node)
        workflow.add_node("read_files", self._read_files_node)
        workflow.add_node("analyze_code", self._analyze_code_node)
        workflow.add_node("generate_response", self._generate_response_node)

        # Define edges
        workflow.set_entry_point("analyze_query")

        # analyze_query -> retrieve
        workflow.add_edge("analyze_query", "retrieve")

        # retrieve -> read_files
        workflow.add_edge("retrieve", "read_files")

        # read_files -> analyze_code
        workflow.add_edge("read_files", "analyze_code")

        # analyze_code -> generate_response
        workflow.add_edge("analyze_code", "generate_response")

        # generate_response -> END
        workflow.add_edge("generate_response", END)

        # Compile
        compiled = workflow.compile()

        logger.info("Built LangGraph workflow with 5 nodes")

        return compiled

    def query(
        self,
        query: str,
        session_id: str = "default",
        **kwargs
    ) -> Dict[str, Any]:
        """
        Process a query through the workflow

        Args:
            query: User's question
            session_id: Session identifier
            **kwargs: Additional parameters

        Returns:
            Response dict with answer and evidence
        """
        logger.info(f"Processing query: {query}")

        # Get or create conversation memory
        if session_id not in self.memories:
            self.memories[session_id] = ConversationMemory(
                session_id=session_id,
                ai_analyzer=self.ai_analyzer
            )
        memory = self.memories[session_id]

        # Create initial state
        state = create_initial_state(
            query=query,
            session_id=session_id,
            conversation_history=memory.get_active_context()
        )

        # Run workflow
        if self.graph:
            # Use LangGraph
            try:
                result_state = self.graph.invoke(state)
            except Exception as e:
                logger.error(f"Workflow error: {e}")
                add_error(state, str(e))
                result_state = state
        else:
            # Fallback to sequential execution
            result_state = self._execute_fallback(state)

        # Update conversation memory
        memory.add_turn("user", query)
        memory.add_turn("assistant", result_state.get("response", ""))

        # Return response with AI failure tracking
        analysis_metadata = result_state.get("analysis_metadata", {})

        return {
            "response": result_state.get("response", ""),
            "evidence": result_state.get("evidence", []),
            "confidence_score": result_state.get("confidence_score", 0.0),
            "metadata": {
                "intent": result_state.get("intent"),
                "systems": result_state.get("systems", []),
                "files_analyzed": len(result_state.get("file_contents", {})),
                "timestamps": result_state.get("timestamps", {}),
                # AI failure tracking
                "ai_success": analysis_metadata.get("ai_success", False),
                "ai_failure_reason": analysis_metadata.get("ai_failure_reason"),
                "response_quality_score": analysis_metadata.get("response_quality", 0.0),
                "retry_quality_score": analysis_metadata.get("retry_quality"),
                "files_successfully_analyzed": analysis_metadata.get("files_analyzed", 0),
                "files_failed_analysis": analysis_metadata.get("files_failed", 0),
                # File reading tracking
                "files_read_successfully": analysis_metadata.get("files_read_successfully", 0),
                "files_failed_to_read": analysis_metadata.get("files_failed_to_read", 0),
                "has_errors": (
                    analysis_metadata.get("files_failed_to_read", 0) > 0 or
                    analysis_metadata.get("files_failed", 0) > 0 or
                    analysis_metadata.get("analysis_error") is not None
                )
            }
        }

    # ============================================
    # Workflow Nodes
    # ============================================

    def _analyze_query_node(self, state: WorkflowState) -> WorkflowState:
        """
        Node 1: Analyze query intent and extract entities

        Updates state with:
        - intent
        - systems
        - entities
        - pipeline_filter
        """
        logger.info("Node: Analyze Query")
        update_state_timestamp(state, "analyze_query_start")

        query = state["query"]

        try:
            # Classify intent
            intent = self._classify_intent(query)
            state["intent"] = intent

            # Extract entities
            entities = self._extract_entities(query)
            state["entities"] = entities

            # Determine systems
            systems = self._determine_systems(query, entities)
            state["systems"] = systems

            # Extract pipeline filter
            pipeline_filter = entities.get("pipeline_name") or entities.get("workflow_name")
            state["pipeline_filter"] = pipeline_filter

            logger.info(f"  Intent: {intent}, Systems: {systems}, Filter: {pipeline_filter}")

        except Exception as e:
            logger.error(f"Query analysis error: {e}")
            add_error(state, f"Query analysis failed: {e}")

        update_state_timestamp(state, "analyze_query_end")
        state["workflow_step"] = "analyze_query_complete"

        return state

    def _retrieve_node(self, state: WorkflowState) -> WorkflowState:
        """
        Node 2: Retrieve relevant documents

        Updates state with:
        - retrieved_docs
        - retrieval_metadata
        """
        logger.info("Node: Retrieve")
        update_state_timestamp(state, "retrieve_start")

        query = state["query"]
        intent = state.get("intent")
        systems = state.get("systems", [])
        pipeline_filter = state.get("pipeline_filter")

        try:
            # Rewrite query for better retrieval
            rewritten_query = self.query_rewriter.rewrite_query(
                query=query,
                intent=intent,
                context=state.get("conversation_history")
            )

            # Determine top_k based on intent
            top_k = self._get_top_k_for_intent(intent)

            # Determine collections to search
            collections = self._get_collections_for_systems(systems)

            # Perform retrieval
            all_results = []
            for collection in collections:
                results = self._search_collection(
                    collection=collection,
                    query=rewritten_query,
                    top_k=top_k,
                    pipeline_filter=pipeline_filter
                )
                all_results.extend(results)

            # Rerank results
            if all_results:
                # Extract documents - handle both formats (hybrid search and regular)
                documents = []
                for r in all_results:
                    if "document" in r:
                        # Hybrid search format
                        documents.append(r["document"])
                    else:
                        # Regular search format - the result itself is the document
                        documents.append(r)

                reranked = self.reranker.rerank(
                    query=query,
                    documents=documents,
                    top_k=top_k,
                    query_intent=intent
                )

                state["retrieved_docs"] = [r.to_dict() for r in reranked]
            else:
                state["retrieved_docs"] = []

            state["retrieval_metadata"] = {
                "rewritten_query": rewritten_query,
                "collections_searched": collections,
                "initial_results": len(all_results),
                "final_results": len(state["retrieved_docs"]),
                "top_k": top_k
            }

            logger.info(f"  Retrieved {len(state['retrieved_docs'])} documents")

        except Exception as e:
            logger.error(f"Retrieval error: {e}")
            add_error(state, f"Retrieval failed: {e}")
            state["retrieved_docs"] = []

        update_state_timestamp(state, "retrieve_end")
        state["workflow_step"] = "retrieve_complete"

        return state

    def _read_files_node(self, state: WorkflowState) -> WorkflowState:
        """
        Node 3: Read actual file contents

        Updates state with:
        - file_contents
        - file_metadata
        """
        logger.info("Node: Read Files")
        update_state_timestamp(state, "read_files_start")

        retrieved_docs = state.get("retrieved_docs", [])

        # Track file reading errors
        if "analysis_metadata" not in state:
            state["analysis_metadata"] = {}

        file_errors = []

        try:
            file_contents = {}
            file_metadata = {}

            # Extract file paths from retrieved docs
            file_paths = []
            for doc in retrieved_docs:
                doc_data = doc.get("document", {})
                metadata = doc_data.get("metadata", {})

                if "file_path" in metadata:
                    file_paths.append(metadata["file_path"])

            # Remove duplicates
            file_paths = list(set(file_paths))

            # Read files with individual error handling
            logger.info(f"  Reading {len(file_paths)} files")

            for file_path in file_paths[:10]:  # Limit to top 10 files
                try:
                    content = self.file_reader.read_file(file_path)
                    if content:
                        file_contents[file_path] = content.content
                        file_metadata[file_path] = content.to_dict()
                    else:
                        file_errors.append({
                            "file": file_path,
                            "error": "No content returned",
                            "category": "empty_file"
                        })
                except FileNotFoundError:
                    file_errors.append({
                        "file": file_path,
                        "error": "File not found",
                        "category": "not_found"
                    })
                    logger.warning(f"  File not found: {file_path}")
                except PermissionError:
                    file_errors.append({
                        "file": file_path,
                        "error": "Permission denied",
                        "category": "permission"
                    })
                    logger.warning(f"  Permission denied: {file_path}")
                except Exception as file_error:
                    file_errors.append({
                        "file": file_path,
                        "error": str(file_error),
                        "category": "read_error"
                    })
                    logger.warning(f"  Error reading {file_path}: {file_error}")

            state["file_contents"] = file_contents
            state["file_metadata"] = file_metadata
            state["analysis_metadata"]["file_read_errors"] = file_errors
            state["analysis_metadata"]["files_read_successfully"] = len(file_contents)
            state["analysis_metadata"]["files_failed_to_read"] = len(file_errors)

            logger.info(f"  Read {len(file_contents)} files successfully ({len(file_errors)} failed)")

        except Exception as e:
            logger.error(f"File reading error: {e}")
            add_error(state, f"File reading failed: {e}")
            state["file_contents"] = {}
            state["file_metadata"] = {}
            state["analysis_metadata"]["file_reading_error"] = str(e)

        update_state_timestamp(state, "read_files_end")
        state["workflow_step"] = "read_files_complete"

        return state

    def _analyze_code_node(self, state: WorkflowState) -> WorkflowState:
        """
        Node 4: Analyze code to extract logic

        Updates state with:
        - analysis_results
        - column_mappings
        """
        logger.info("Node: Analyze Code")
        update_state_timestamp(state, "analyze_code_start")

        file_contents = state.get("file_contents", {})
        intent = state.get("intent")

        # Track analysis failures
        if "analysis_metadata" not in state:
            state["analysis_metadata"] = {}

        try:
            analysis_results = {}
            files_analyzed = 0
            files_failed = 0

            # Only analyze if we have files and intent requires it
            if file_contents and intent in [
                QueryIntent.COLUMN_TRANSFORMATION,
                QueryIntent.PIPELINE_LOGIC,
                QueryIntent.COMPARISON
            ]:
                logger.info(f"  Analyzing {len(file_contents)} files")

                for file_path in list(file_contents.keys())[:5]:  # Limit to top 5
                    try:
                        analysis = self.code_analyzer.analyze_file(
                            file_path=file_path,
                            analysis_type="full"
                        )

                        if analysis:
                            analysis_results[file_path] = analysis.to_dict()
                            files_analyzed += 1
                        else:
                            files_failed += 1
                            logger.warning(f"  No analysis result for {file_path}")
                    except Exception as file_error:
                        files_failed += 1
                        logger.error(f"  Failed to analyze {file_path}: {file_error}")

                # Extract column mappings
                column_mappings = []
                for analysis in analysis_results.values():
                    column_mappings.extend(analysis.get("column_transformations", []))

                state["column_mappings"] = column_mappings
            else:
                state["column_mappings"] = []

            state["analysis_results"] = analysis_results

            # Track success/failure counts
            state["analysis_metadata"]["files_analyzed"] = files_analyzed
            state["analysis_metadata"]["files_failed"] = files_failed

            logger.info(f"  Analyzed {files_analyzed} files ({files_failed} failed)")

        except Exception as e:
            logger.error(f"Code analysis error: {e}")
            add_error(state, f"Code analysis failed: {e}")
            state["analysis_results"] = {}
            state["analysis_metadata"]["analysis_error"] = str(e)
            state["column_mappings"] = []

        update_state_timestamp(state, "analyze_code_end")
        state["workflow_step"] = "analyze_code_complete"

        return state

    def _generate_response_node(self, state: WorkflowState) -> WorkflowState:
        """
        Node 5: Generate final response

        Updates state with:
        - response
        - evidence
        - confidence_score
        """
        logger.info("Node: Generate Response")
        update_state_timestamp(state, "generate_response_start")

        query = state["query"]
        intent = state.get("intent")
        retrieved_docs = state.get("retrieved_docs", [])
        analysis_results = state.get("analysis_results", {})

        try:
            # Build evidence
            evidence = self._build_evidence(retrieved_docs, analysis_results)
            state["evidence"] = evidence

            # Generate response based on intent
            if intent == QueryIntent.EXCEL_GENERATION:
                response = self._generate_excel_response(state)
            else:
                response = self._generate_text_response(state)

            state["response"] = response

            # Calculate confidence
            confidence = self._calculate_confidence(state)
            state["confidence_score"] = confidence

            logger.info(f"  Generated response (confidence: {confidence:.2f})")

        except Exception as e:
            logger.error(f"Response generation error: {e}")
            add_error(state, f"Response generation failed: {e}")
            state["response"] = "Sorry, I encountered an error generating the response."
            state["evidence"] = []
            state["confidence_score"] = 0.0

        update_state_timestamp(state, "generate_response_end")
        state["workflow_step"] = "complete"

        return state

    # ============================================
    # Helper Methods
    # ============================================

    def _classify_intent(self, query: str) -> QueryIntent:
        """Classify query intent"""
        query_lower = query.lower()

        # Check Excel generation FIRST (highest priority) - before other keywords
        if any(word in query_lower for word in ["excel", "sttm"]) or \
           ("generate" in query_lower and any(word in query_lower for word in ["report", "file", "document"])) or \
           ("create" in query_lower and any(word in query_lower for word in ["excel", "report", "sttm"])):
            return QueryIntent.EXCEL_GENERATION
        elif any(word in query_lower for word in ["column", "field", "transformation", "mapping"]):
            return QueryIntent.COLUMN_TRANSFORMATION
        elif any(word in query_lower for word in ["compare", "difference", "vs", "versus"]):
            return QueryIntent.COMPARISON
        elif any(word in query_lower for word in ["lineage", "flow", "trace"]):
            return QueryIntent.LINEAGE_TRACKING
        elif any(word in query_lower for word in ["logic", "step", "process", "workflow"]):
            return QueryIntent.PIPELINE_LOGIC
        else:
            return QueryIntent.GENERAL_QUESTION

    def _extract_entities(self, query: str) -> Dict[str, Any]:
        """Extract entities from query - supports both quoted and unquoted workflow names"""
        import re

        entities = {}

        # Extract quoted strings (likely entity names) - highest priority
        quoted = re.findall(r'"([^"]+)"', query)
        if quoted:
            entities["workflow_name"] = quoted[0]
            return entities

        # Extract workflow names from patterns like "for hadoop workflow_xref" or "pl_leadrepository_xref"
        # Pattern 1: "for [optional system] workflow_name" (e.g., "for hadoop workflow_xref" or "for workflow_xref")
        match = re.search(r'for\s+(?:hadoop|databricks|abinitio)?\s*([a-zA-Z0-9_-]+)', query, re.IGNORECASE)
        if match:
            potential_name = match.group(1).strip()
            # Exclude common words that aren't workflow names
            if potential_name.lower() not in ['the', 'a', 'an', 'this', 'that']:
                entities["workflow_name"] = potential_name
                return entities

        # Pattern 2: "pl_" or "workflow_" prefixed names (e.g., "pl_leadrepository_xref", "workflow_xref")
        match = re.search(r'((?:pl_|workflow_)[a-zA-Z0-9_-]+)', query, re.IGNORECASE)
        if match:
            entities["workflow_name"] = match.group(1)
            return entities

        # Pattern 3: After "excel" or "report" keywords, look for identifiers
        # (e.g., "generate excel workflow_xref", "create report for leadrepository")
        match = re.search(r'(?:excel|report|sttm)\s+(?:for\s+)?([a-zA-Z0-9_-]+)', query, re.IGNORECASE)
        if match:
            potential_name = match.group(1).strip()
            # Exclude system names and common words
            if potential_name.lower() not in ['hadoop', 'databricks', 'abinitio', 'the', 'a', 'an']:
                entities["workflow_name"] = potential_name
                return entities

        return entities

    def _determine_systems(self, query: str, entities: Dict[str, Any]) -> List[SystemType]:
        """Determine which systems are involved"""
        query_lower = query.lower()
        systems = []

        if "hadoop" in query_lower or "hive" in query_lower or "pig" in query_lower:
            systems.append(SystemType.HADOOP)
        if "databricks" in query_lower or "spark" in query_lower:
            systems.append(SystemType.DATABRICKS)
        if "abinitio" in query_lower or "ab initio" in query_lower:
            systems.append(SystemType.ABINITIO)

        # Default to all if none specified
        if not systems:
            systems = [SystemType.HADOOP, SystemType.DATABRICKS]

        return systems

    def _get_top_k_for_intent(self, intent: Optional[QueryIntent]) -> int:
        """Get appropriate top-k based on intent"""
        if intent == QueryIntent.COLUMN_TRANSFORMATION:
            return 15
        elif intent == QueryIntent.COMPARISON:
            return 20
        elif intent == QueryIntent.PIPELINE_LOGIC:
            return 10
        else:
            return 5

    def _get_collections_for_systems(self, systems: List[SystemType]) -> List[str]:
        """Get collection names for systems"""
        collection_map = {
            SystemType.HADOOP: "hadoop_collection",
            SystemType.DATABRICKS: "databricks_collection",
            SystemType.ABINITIO: "abinitio_collection"
        }

        return [collection_map[sys] for sys in systems if sys in collection_map]

    def _search_collection(
        self,
        collection: str,
        query: str,
        top_k: int,
        pipeline_filter: Optional[str]
    ) -> List[Dict[str, Any]]:
        """Search a single collection"""
        # Use hybrid search if available
        if self.hybrid_search:
            results = self.hybrid_search.search(
                query=query,
                collection_name=collection,
                top_k=top_k
            )
            return [{"document": r.document, "score": r.score} for r in results]
        else:
            # Fallback to indexer search
            search_results = self.indexer.search_multi_collection(
                query=query,
                collections=[collection],
                top_k=top_k
            )
            return search_results.get(collection, [])

    def _build_evidence(
        self,
        retrieved_docs: List[Dict[str, Any]],
        analysis_results: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        """Build evidence list from docs and analysis"""
        evidence = []

        for doc in retrieved_docs[:5]:  # Top 5 docs
            doc_data = doc.get("document", {})
            metadata = doc_data.get("metadata", {})

            evidence.append({
                "file_path": metadata.get("file_path", "Unknown"),
                "title": doc_data.get("title", ""),
                "relevance_score": doc.get("rerank_score", doc.get("score", 0.0)),
                "system": metadata.get("system", "")
            })

        return evidence

    def _validate_response_quality(self, response: str, query: str, evidence: List[Dict]) -> float:
        """
        Validate response quality and return score (0.0-1.0)

        Checks:
        - Response length (not too short)
        - Specific information (not just generic statements)
        - Evidence usage (mentions file paths or specific details)
        - Relevance to query

        Returns:
            float: Quality score (0.0 = poor, 1.0 = excellent)
        """
        score = 0.0

        # Check 1: Length (0-0.25 points)
        if len(response) > 200:
            score += 0.25
        elif len(response) > 100:
            score += 0.15
        elif len(response) > 50:
            score += 0.05

        # Check 2: Specificity - mentions file paths or code (0-0.25 points)
        specific_indicators = [
            ".py", ".hql", ".pig", ".sql", ".scala", ".java",  # File extensions
            "SELECT", "INSERT", "UPDATE", "def ", "class ",  # Code keywords
            "table", "column", "field", "function"  # Technical terms
        ]
        specific_count = sum(1 for ind in specific_indicators if ind in response)
        score += min(0.25, specific_count * 0.05)

        # Check 3: Evidence usage (0-0.25 points)
        if evidence:
            # Check if response mentions evidence files
            evidence_files = [ev.get("file_path", "") for ev in evidence]
            mentions_evidence = any(
                Path(f).stem in response or Path(f).name in response
                for f in evidence_files if f
            )
            if mentions_evidence:
                score += 0.25
            else:
                score += 0.10  # At least has evidence

        # Check 4: Query relevance (0-0.25 points)
        # Check if key query terms appear in response
        query_terms = query.lower().split()
        query_terms = [t for t in query_terms if len(t) > 3]  # Skip short words
        response_lower = response.lower()

        matching_terms = sum(1 for term in query_terms if term in response_lower)
        if query_terms:
            relevance_ratio = matching_terms / len(query_terms)
            score += relevance_ratio * 0.25

        # Penalty for generic responses
        generic_phrases = [
            "couldn't find specific information",
            "may not be indexed",
            "try re-indexing",
            "no information available"
        ]
        if any(phrase in response.lower() for phrase in generic_phrases):
            score *= 0.5  # Reduce score by half for generic responses

        return min(1.0, score)

    def _format_column_transformations(self, transformations: List[Dict[str, Any]]) -> str:
        """
        Format column transformations as a markdown table

        Args:
            transformations: List of column transformation dicts

        Returns:
            Markdown formatted table
        """
        if not transformations:
            return ""

        lines = []
        lines.append("\n**Column Transformations:**\n")
        lines.append("| Target Column | Source Column(s) | Transformation | Table |")
        lines.append("|--------------|------------------|----------------|--------|")

        for trans in transformations[:10]:  # Limit to 10
            target = trans.get("target_column", "N/A")
            source = trans.get("source_column", trans.get("source_columns", "N/A"))
            if isinstance(source, list):
                source = ", ".join(source[:3])  # Max 3 sources
            transformation = trans.get("transformation", trans.get("transformation_logic", "N/A"))[:50]  # Truncate
            table = trans.get("target_table", trans.get("table", "N/A"))

            lines.append(f"| {target} | {source} | {transformation} | {table} |")

        return "\n".join(lines)

    def _format_code_snippet(self, code: str, language: str = "", max_lines: int = 15) -> str:
        """
        Format code snippet with syntax highlighting

        Args:
            code: Code to format
            language: Language for syntax highlighting (sql, python, etc.)
            max_lines: Maximum lines to show

        Returns:
            Markdown formatted code block
        """
        if not code:
            return ""

        lines = code.strip().split("\n")
        if len(lines) > max_lines:
            lines = lines[:max_lines] + [f"... ({len(lines) - max_lines} more lines)"]

        code_text = "\n".join(lines)

        return f"```{language}\n{code_text}\n```"

    def _format_evidence_sources(self, evidence: List[Dict[str, Any]]) -> str:
        """
        Format evidence sources with file paths and relevance

        Args:
            evidence: List of evidence dicts

        Returns:
            Formatted markdown list
        """
        if not evidence:
            return ""

        lines = []
        lines.append("\n**📚 Evidence Sources:**\n")

        for i, ev in enumerate(evidence[:5], 1):  # Top 5
            file_path = ev.get("file_path", "Unknown")
            relevance = ev.get("relevance_score", 0.0)
            system = ev.get("system", "")

            # Extract filename
            filename = Path(file_path).name if file_path != "Unknown" else "Unknown"

            lines.append(f"{i}. **{filename}** (Relevance: {relevance:.0%})")
            lines.append(f"   - Path: `{file_path}`")
            if system:
                lines.append(f"   - System: {system}")
            lines.append("")

        return "\n".join(lines)

    def _generate_text_response(self, state: WorkflowState) -> str:
        """Generate text response using AI analyzer with failure detection"""
        query = state["query"]
        evidence = state.get("evidence", [])
        analysis_results = state.get("analysis_results", {})
        file_contents = state.get("file_contents", {})
        intent = state.get("intent")

        # Initialize AI failure tracking in metadata
        if "analysis_metadata" not in state:
            state["analysis_metadata"] = {}

        ai_metadata = state["analysis_metadata"]
        ai_metadata["ai_attempts"] = ai_metadata.get("ai_attempts", 0) + 1

        # Build context from evidence and analysis
        context_parts = []

        # Add file contents
        if file_contents:
            context_parts.append("=== FILE CONTENTS ===")
            for file_path, content in list(file_contents.items())[:5]:
                context_parts.append(f"\n--- {Path(file_path).name} ---")
                context_parts.append(content[:3000])  # Limit per file

        # Add analysis results
        if analysis_results:
            context_parts.append("\n=== CODE ANALYSIS ===")
            for file_path, analysis in list(analysis_results.items())[:3]:
                context_parts.append(f"\n--- Analysis of {Path(file_path).name} ---")
                context_parts.append(f"Summary: {analysis.get('summary', 'N/A')}")

                # Add transformations if available
                if analysis.get('column_transformations'):
                    context_parts.append("Transformations:")
                    for trans in analysis['column_transformations'][:5]:
                        context_parts.append(f"  - {trans.get('target_column')}: {trans.get('transformation')}")

        # Build context
        context = "\n".join(context_parts)

        # Use AI analyzer to generate response
        if self.ai_analyzer and self.ai_analyzer.enabled and context:
            try:
                prompt = f"""Answer the following question based on the codebase analysis:

Question: {query}

Context from codebase:
{context[:8000]}

Provide a detailed, specific answer with examples and evidence from the code."""

                result = self.ai_analyzer.analyze_with_context(
                    query=prompt,
                    context=context[:8000]
                )

                ai_response = result.get('analysis') or result.get('response', '')

                if ai_response and len(ai_response) > 50:
                    # Validate response quality
                    quality_score = self._validate_response_quality(ai_response, query, evidence)
                    ai_metadata["response_quality"] = quality_score

                    # If quality is low and we haven't retried yet, try with enhanced prompt
                    if quality_score < 0.4 and ai_metadata.get("ai_attempts", 1) == 1:
                        logger.warning(f"Low quality response (score: {quality_score:.2f}), retrying with enhanced prompt...")

                        # Enhanced prompt with more explicit instructions
                        enhanced_prompt = f"""You are analyzing a codebase. Provide a DETAILED, SPECIFIC answer with CONCRETE EXAMPLES from the code.

Question: {query}

Context from codebase:
{context[:8000]}

IMPORTANT:
- Reference SPECIFIC file names, functions, and code snippets
- Include CONCRETE examples from the code provided
- Mention SPECIFIC table names, column names, or transformations
- DO NOT give generic answers
- Use evidence from the files above"""

                        retry_result = self.ai_analyzer.analyze_with_context(
                            query=enhanced_prompt,
                            context=context[:8000]
                        )

                        retry_response = retry_result.get('analysis') or retry_result.get('response', '')
                        if retry_response:
                            retry_quality = self._validate_response_quality(retry_response, query, evidence)
                            ai_metadata["retry_quality"] = retry_quality

                            if retry_quality > quality_score:
                                logger.info(f"Retry improved quality: {quality_score:.2f} → {retry_quality:.2f}")
                                ai_metadata["ai_success"] = True
                                ai_metadata["ai_failure_reason"] = None
                                ai_metadata["response_quality"] = retry_quality
                                return retry_response

                    # Use original response if retry didn't help or quality is acceptable
                    if quality_score >= 0.4:
                        ai_metadata["ai_success"] = True
                        ai_metadata["ai_failure_reason"] = None
                        return ai_response
                    else:
                        ai_metadata["ai_success"] = False
                        ai_metadata["ai_failure_reason"] = f"Low quality response (score: {quality_score:.2f})"
                        logger.warning(f"Using fallback - AI response quality too low: {quality_score:.2f}")
                else:
                    # AI returned empty/short response
                    ai_metadata["ai_success"] = False
                    ai_metadata["ai_failure_reason"] = "AI returned empty or very short response"
                    ai_metadata["response_quality"] = 0.0
                    logger.warning(f"AI returned insufficient response: {len(ai_response) if ai_response else 0} chars")
            except Exception as e:
                # AI call failed
                ai_metadata["ai_success"] = False
                ai_metadata["ai_failure_reason"] = str(e)
                logger.error(f"AI response generation failed: {e}")
        else:
            # AI not available
            ai_metadata["ai_success"] = False
            ai_metadata["ai_failure_reason"] = "AI analyzer not enabled or no context available"
            if not self.ai_analyzer or not self.ai_analyzer.enabled:
                logger.warning("AI analyzer not available")
            if not context:
                logger.warning("No context available for AI analysis")

        # Fallback: Build structured response from evidence
        response_parts = []
        response_parts.append(f"## Analysis Results\n")

        # Add analysis findings with improved formatting
        if analysis_results:
            response_parts.append("### Code Analysis\n")
            for file_path, analysis in list(analysis_results.items())[:3]:
                filename = Path(file_path).name
                response_parts.append(f"#### {filename}\n")
                response_parts.append(f"{analysis.get('summary', 'N/A')}\n")

                # Add column transformations if available (for column queries)
                if analysis.get('column_transformations'):
                    trans_table = self._format_column_transformations(analysis['column_transformations'])
                    response_parts.append(trans_table)

                # Add code snippet if available
                if analysis.get('code_snippet'):
                    # Detect language from file extension
                    ext = Path(file_path).suffix.lower()
                    lang_map = {'.py': 'python', '.sql': 'sql', '.hql': 'sql',
                               '.pig': 'pig', '.scala': 'scala', '.java': 'java'}
                    language = lang_map.get(ext, '')
                    code_formatted = self._format_code_snippet(analysis['code_snippet'], language, max_lines=10)
                    response_parts.append(f"\n**Code:**\n{code_formatted}\n")

        # Add formatted evidence sources
        if evidence:
            evidence_formatted = self._format_evidence_sources(evidence)
            response_parts.append(evidence_formatted)

        # If we have nothing, say so
        if not analysis_results and not evidence:
            response_parts.append("I couldn't find specific information about this in the indexed codebase.")
            response_parts.append("\nPossible reasons:")
            response_parts.append("- The files may not be indexed yet")
            response_parts.append("- The query may need to be more specific")
            response_parts.append("- Try re-indexing the repositories from the Database tab")

        # Add AI failure warning if applicable
        if not ai_metadata.get("ai_success", False):
            response_parts.append("\n")
            response_parts.append("⚠️ **AI Analysis Unavailable**")
            failure_reason = ai_metadata.get("ai_failure_reason", "Unknown reason")
            response_parts.append(f"The AI analyzer could not generate a detailed response: {failure_reason}")
            response_parts.append("Showing basic evidence-based information instead.")

        # Add error summary if there were errors
        error_summary = self._build_error_summary(ai_metadata)
        if error_summary:
            response_parts.append("\n" + error_summary)

        return "\n".join(response_parts)

    def _build_error_summary(self, metadata: Dict[str, Any]) -> str:
        """
        Build user-friendly error summary from metadata

        Args:
            metadata: Analysis metadata with error information

        Returns:
            Formatted error summary or empty string
        """
        errors = []

        # File reading errors
        file_read_errors = metadata.get("file_read_errors", [])
        if file_read_errors:
            error_count = len(file_read_errors)
            errors.append(f"- **File Reading**: {error_count} file(s) could not be read")

            # Categorize errors
            categories = {}
            for err in file_read_errors:
                cat = err.get("category", "unknown")
                categories[cat] = categories.get(cat, 0) + 1

            if "not_found" in categories:
                errors.append(f"  - {categories['not_found']} file(s) not found (may have been moved/deleted)")
            if "permission" in categories:
                errors.append(f"  - {categories['permission']} file(s) had permission issues")
            if "empty_file" in categories:
                errors.append(f"  - {categories['empty_file']} file(s) were empty")

        # Analysis errors
        files_failed = metadata.get("files_failed", 0)
        if files_failed > 0:
            errors.append(f"- **Code Analysis**: {files_failed} file(s) could not be analyzed")

        # General analysis error
        if metadata.get("analysis_error"):
            errors.append(f"- **System Error**: {metadata['analysis_error']}")

        if not errors:
            return ""

        summary = ["\n### ⚠️ Issues Encountered\n"]
        summary.extend(errors)
        summary.append("\n**Troubleshooting:**")
        summary.append("- Verify files exist at expected paths")
        summary.append("- Check file permissions")
        summary.append("- Re-index repositories if files were recently added/modified")

        return "\n".join(summary)

    def _generate_excel_response(self, state: WorkflowState) -> str:
        """Generate Excel report using STAG orchestrator"""
        logger.info("Generating Excel report...")

        try:
            from services.stag.stag_orchestrator import STAGOrchestrator
            import os

            # Extract parameters from state
            entities = state.get("entities", {})
            systems = state.get("systems", [])
            query = state["query"]

            # Extract workflow/pipeline name
            workflow_name = (entities.get("pipeline_name") or
                           entities.get("workflow_name") or
                           state.get("pipeline_filter"))

            # Determine source system
            source_system = None
            is_databricks_only = False

            if "hadoop" in systems:
                source_system = "hadoop"
            elif "databricks" in systems:
                # Check if user wants Databricks-only documentation or comparison
                if len(systems) == 1 or "only" in query.lower() or "documentation" in query.lower():
                    is_databricks_only = True
                    source_system = "databricks"
                else:
                    source_system = "databricks"
            elif "abinitio" in systems or "ab initio" in query.lower():
                source_system = "abinitio"

            # Validate parameters
            if not workflow_name:
                return """❌ **Workflow/Pipeline name not specified**

Please provide the workflow name. Examples:
- "Generate Excel for Databricks pl_leadservicebase_famc"
- "Create STTM for Hadoop MEDICARELEADS workflow"
- "Generate Excel documentation for Databricks pl_leadrepo_xref"

Try rephrasing your question to include the specific workflow name."""

            if not source_system:
                return f"""❌ **System not specified**

Please specify the source system. Examples:
- "Generate Excel for **Hadoop** {workflow_name}"
- "Create STTM for **Databricks** {workflow_name}"
- "Generate Excel documentation for **Databricks** {workflow_name}"

Supported systems: Hadoop, Databricks, Ab Initio"""

            # Handle Databricks-only documentation (no comparison)
            if is_databricks_only:
                return self._generate_databricks_documentation_excel(
                    workflow_name=workflow_name,
                    state=state
                )

            # Initialize STAG orchestrator for cross-system comparison
            stag = STAGOrchestrator(
                indexer=self.indexer,
                ai_analyzer=self.ai_analyzer
            )

            # Generate comparison
            result = stag.generate_comparison(
                source_system=source_system,
                source_workflow=workflow_name,
                databricks_pipeline=None  # Optional: for cross-system comparison
            )

            if result.get('success'):
                excel_path = result.get('excel_file', '')
                file_size = os.path.getsize(excel_path) / 1024 if excel_path and os.path.exists(excel_path) else 0

                return f"""✅ **Excel Report Generated!**

**Workflow:** {workflow_name}
**System:** {source_system.title()}

**📊 Report Contents:**
- Business Stages: {len(result.get('business_stages', []))}
- STTM Mappings: {result.get('sttm_count', 0)}
- Differences: {result.get('differences_count', 0)}

**📁 Output:**
- Path: `{excel_path}`
- Size: {file_size:.1f} KB
- Sheets: 5 (Overview, Logic, Comparison, STTM)

Download from: `{os.path.dirname(excel_path)}`"""
            else:
                errors = result.get('errors', ['Unknown error'])
                return f"❌ Excel generation failed: {', '.join(errors)}"

        except Exception as e:
            logger.error(f"Excel generation error: {e}", exc_info=True)
            return f"❌ Error: {str(e)}\n\nCheck workflow name and ensure repository is indexed."

    def _generate_databricks_documentation_excel(
        self,
        workflow_name: str,
        state: WorkflowState
    ) -> str:
        """
        Generate single-system Databricks documentation Excel (no comparison)

        Args:
            workflow_name: Databricks pipeline/workflow name
            state: Current workflow state with file contents and analysis

        Returns:
            Formatted response message
        """
        logger.info(f"Generating Databricks-only documentation Excel for: {workflow_name}")

        try:
            from services.stag.databricks_logic_extractor import DatabricksLogicExtractor
            from services.stag.excel_generator import ExcelGenerator
            import os
            from datetime import datetime

            # Extract Databricks logic
            logger.info("Extracting Databricks logic...")
            databricks_extractor = DatabricksLogicExtractor(
                indexer=self.indexer,
                ai_analyzer=self.ai_analyzer
            )

            databricks_logic = databricks_extractor.extract_logic(
                pipeline_name=workflow_name
            )

            if not databricks_logic or not databricks_logic.get('activities'):
                return f"""⚠️  **No logic found for Databricks pipeline: {workflow_name}**

Please check:
1. Pipeline name is correct
2. Pipeline has been indexed in databricks_collection
3. ADF JSON or notebook files exist for this pipeline

Try searching for similar pipelines with a query like:
"What Databricks pipelines are indexed?"
"""

            activities = databricks_logic.get('activities', [])
            logger.info(f"Extracted {len(activities)} activities from Databricks pipeline")

            # Generate business stages using AI
            logger.info("Generating business-level documentation...")
            from services.stag.business_stage_abstractor import BusinessStageAbstractor

            abstractor = BusinessStageAbstractor(
                ai_analyzer=self.ai_analyzer
            )

            # For single-system, pass Databricks logic as both source and target
            business_stages = abstractor.abstract_to_business_stages(
                source_logic=databricks_logic,
                databricks_logic=databricks_logic  # Same as source for single-system
            )

            # Generate Excel
            logger.info("Creating Excel documentation...")
            excel_gen = ExcelGenerator()

            output_folder = "outputs/databricks_documentation"
            os.makedirs(output_folder, exist_ok=True)

            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            excel_path = excel_gen.generate_databricks_documentation_excel(
                pipeline_name=workflow_name,
                databricks_logic=databricks_logic,
                business_stages=business_stages,
                output_folder=output_folder,
                timestamp=timestamp
            )

            file_size = os.path.getsize(excel_path) / 1024 if os.path.exists(excel_path) else 0

            return f"""✅ **Databricks Documentation Excel Generated!**

**Pipeline:** {workflow_name}
**Type:** Databricks-Only Documentation (No Comparison)

**📊 Contents:**
- Activities: {len(activities)}
- Business Stages: {len(business_stages)}
- Notebooks/Scripts: {databricks_logic.get('notebooks_count', 0)}

**📁 Output:**
- Path: `{excel_path}`
- Size: {file_size:.1f} KB
- Sheets: 3 (Overview, Logic, STTM)

**📋 Sheets Included:**
1. **Overview**: Pipeline flow and architecture
2. **Logic**: Detailed activity-by-activity breakdown
3. **STTM**: Source-to-Target column mappings

Download from: `{output_folder}`"""

        except Exception as e:
            logger.error(f"Databricks documentation Excel generation error: {e}", exc_info=True)
            return f"""❌ **Error generating Databricks documentation**

{str(e)}

**Troubleshooting:**
1. Verify pipeline name: `{workflow_name}`
2. Check if pipeline is indexed: Query "what databricks pipelines exist?"
3. Ensure ADF JSON and notebooks are available

Try a simpler query like:
"Show me logic for databricks {workflow_name}"
"""

    def _calculate_confidence(self, state: WorkflowState) -> float:
        """Calculate confidence score"""
        # Simple confidence calculation
        score = 0.5

        # Boost if we have evidence
        if state.get("evidence"):
            score += 0.2

        # Boost if we analyzed files
        if state.get("analysis_results"):
            score += 0.3

        return min(score, 1.0)

    def _execute_fallback(self, state: WorkflowState) -> WorkflowState:
        """Fallback execution without LangGraph"""
        logger.info("Using fallback workflow execution")

        state = self._analyze_query_node(state)
        state = self._retrieve_node(state)
        state = self._read_files_node(state)
        state = self._analyze_code_node(state)
        state = self._generate_response_node(state)

        return state
