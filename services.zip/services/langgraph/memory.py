"""
Conversation Memory Manager
============================
Manages conversation history with smart context windowing and summarization.

Features:
- Rolling conversation window (last N exchanges)
- Automatic summarization for long conversations
- Context-aware query expansion
- Session management
"""

from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field
from datetime import datetime
from loguru import logger


@dataclass
class ConversationTurn:
    """A single turn in conversation"""
    role: str  # "user" or "assistant"
    content: str
    timestamp: str
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "role": self.role,
            "content": self.content,
            "timestamp": self.timestamp,
            "metadata": self.metadata
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ConversationTurn":
        """Create from dictionary"""
        return cls(
            role=data["role"],
            content=data["content"],
            timestamp=data.get("timestamp", datetime.now().isoformat()),
            metadata=data.get("metadata", {})
        )


class ConversationMemory:
    """
    Manages conversation history with smart windowing

    Attributes:
        session_id: Unique session identifier
        max_turns: Maximum turns to keep in active window (default: 10)
        summarization_threshold: Turns before triggering summarization (default: 20)
    """

    def __init__(
        self,
        session_id: str,
        max_turns: int = 10,
        summarization_threshold: int = 20,
        ai_analyzer = None
    ):
        """
        Initialize conversation memory

        Args:
            session_id: Unique session ID
            max_turns: Max turns in active window
            summarization_threshold: When to summarize
            ai_analyzer: AI analyzer for summarization
        """
        self.session_id = session_id
        self.max_turns = max_turns
        self.summarization_threshold = summarization_threshold
        self.ai_analyzer = ai_analyzer

        # Full conversation history
        self.full_history: List[ConversationTurn] = []

        # Active window (last N turns)
        self.active_window: List[ConversationTurn] = []

        # Summarized context from older turns
        self.context_summary: Optional[str] = None

        logger.info(f"Initialized conversation memory for session {session_id}")

    def add_turn(
        self,
        role: str,
        content: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Add a conversation turn

        Args:
            role: "user" or "assistant"
            content: Message content
            metadata: Optional metadata
        """
        turn = ConversationTurn(
            role=role,
            content=content,
            timestamp=datetime.now().isoformat(),
            metadata=metadata or {}
        )

        # Add to full history
        self.full_history.append(turn)

        # Add to active window
        self.active_window.append(turn)

        # Trim active window if needed
        if len(self.active_window) > self.max_turns:
            self.active_window = self.active_window[-self.max_turns:]

        # Trigger summarization if needed
        if len(self.full_history) >= self.summarization_threshold:
            self._maybe_summarize()

        logger.debug(f"Added {role} turn: {content[:50]}...")

    def get_active_context(self) -> List[Dict[str, str]]:
        """
        Get active conversation context

        Returns:
            List of recent turns as dicts
        """
        return [turn.to_dict() for turn in self.active_window]

    def get_full_history(self) -> List[Dict[str, str]]:
        """
        Get complete conversation history

        Returns:
            All turns as dicts
        """
        return [turn.to_dict() for turn in self.full_history]

    def get_context_for_query(self, current_query: str) -> Dict[str, Any]:
        """
        Get relevant context for current query

        Args:
            current_query: Current user query

        Returns:
            Dict with:
                - active_window: Recent turns
                - summary: Summarized older context
                - relevant_turns: Turns relevant to current query
        """
        context = {
            "active_window": self.get_active_context(),
            "summary": self.context_summary,
            "relevant_turns": self._find_relevant_turns(current_query)
        }

        return context

    def _find_relevant_turns(self, query: str) -> List[Dict[str, str]]:
        """
        Find turns relevant to current query using keyword matching

        Args:
            query: Current query

        Returns:
            Relevant turns
        """
        # Simple keyword-based relevance (can be enhanced with embeddings)
        query_keywords = set(query.lower().split())

        relevant = []
        for turn in self.full_history:
            turn_keywords = set(turn.content.lower().split())
            # Check overlap
            overlap = len(query_keywords & turn_keywords)
            if overlap >= 2:  # At least 2 common words
                relevant.append(turn.to_dict())

        return relevant[-5:]  # Return last 5 relevant turns

    def _maybe_summarize(self) -> None:
        """
        Summarize older conversation if threshold reached

        This uses AI to create a concise summary of older turns
        to save context window space.
        """
        if not self.ai_analyzer:
            logger.warning("No AI analyzer - skipping summarization")
            return

        # Only summarize if we have enough turns
        turns_to_summarize = len(self.full_history) - self.max_turns
        if turns_to_summarize < self.summarization_threshold // 2:
            return

        logger.info(f"Summarizing {turns_to_summarize} older turns...")

        try:
            # Get turns to summarize (exclude active window)
            older_turns = self.full_history[:-self.max_turns]

            # Format for summarization
            conversation_text = "\n\n".join([
                f"{turn.role.upper()}: {turn.content}"
                for turn in older_turns
            ])

            # Create summary prompt
            prompt = f"""Summarize this conversation concisely, focusing on:
1. Main topics discussed
2. Key information discovered
3. Systems/workflows mentioned
4. Important findings

Keep it under 200 words.

CONVERSATION:
{conversation_text}

SUMMARY:"""

            # Get summary from AI
            summary = self.ai_analyzer.analyze_code(
                code=conversation_text,
                analysis_type="conversation_summary",
                custom_prompt=prompt
            )

            self.context_summary = summary.get("summary", "").strip()

            logger.info(f"Created conversation summary: {self.context_summary[:100]}...")

        except Exception as e:
            logger.error(f"Error summarizing conversation: {e}")

    def expand_query_with_context(self, query: str) -> str:
        """
        Expand query with conversation context

        Args:
            query: Current query

        Returns:
            Expanded query with context
        """
        # Get relevant context
        context = self.get_context_for_query(query)

        # Build expanded query
        expanded_parts = [query]

        # Add summary if available
        if context["summary"]:
            expanded_parts.append(f"Previous context: {context['summary']}")

        # Add relevant entities from recent turns
        for turn in context["active_window"][-3:]:  # Last 3 turns
            if turn["role"] == "user":
                # Extract potential entity references
                content = turn["content"]
                # Add if it's short (likely contains entity names)
                if len(content.split()) < 15:
                    expanded_parts.append(f"Related to: {content}")

        expanded_query = " | ".join(expanded_parts)

        if expanded_query != query:
            logger.debug(f"Expanded query: {expanded_query[:100]}...")

        return expanded_query

    def clear(self) -> None:
        """Clear conversation memory"""
        self.full_history.clear()
        self.active_window.clear()
        self.context_summary = None
        logger.info(f"Cleared conversation memory for session {self.session_id}")

    def to_dict(self) -> Dict[str, Any]:
        """Export to dictionary for serialization"""
        return {
            "session_id": self.session_id,
            "full_history": [turn.to_dict() for turn in self.full_history],
            "context_summary": self.context_summary,
            "max_turns": self.max_turns,
            "summarization_threshold": self.summarization_threshold
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any], ai_analyzer=None) -> "ConversationMemory":
        """
        Restore from dictionary

        Args:
            data: Serialized memory
            ai_analyzer: AI analyzer for future summarization

        Returns:
            Restored ConversationMemory
        """
        memory = cls(
            session_id=data["session_id"],
            max_turns=data.get("max_turns", 10),
            summarization_threshold=data.get("summarization_threshold", 20),
            ai_analyzer=ai_analyzer
        )

        # Restore history
        memory.full_history = [
            ConversationTurn.from_dict(turn)
            for turn in data.get("full_history", [])
        ]

        # Restore summary
        memory.context_summary = data.get("context_summary")

        # Rebuild active window
        memory.active_window = memory.full_history[-memory.max_turns:]

        logger.info(f"Restored conversation memory with {len(memory.full_history)} turns")

        return memory


class SessionManager:
    """
    Manages multiple conversation sessions

    Allows multiple independent conversation threads.
    """

    def __init__(self, ai_analyzer=None):
        """Initialize session manager"""
        self.sessions: Dict[str, ConversationMemory] = {}
        self.ai_analyzer = ai_analyzer
        logger.info("Initialized session manager")

    def get_or_create_session(
        self,
        session_id: str,
        max_turns: int = 10
    ) -> ConversationMemory:
        """
        Get existing session or create new one

        Args:
            session_id: Session identifier
            max_turns: Max turns in active window

        Returns:
            ConversationMemory for this session
        """
        if session_id not in self.sessions:
            self.sessions[session_id] = ConversationMemory(
                session_id=session_id,
                max_turns=max_turns,
                ai_analyzer=self.ai_analyzer
            )
            logger.info(f"Created new session: {session_id}")

        return self.sessions[session_id]

    def delete_session(self, session_id: str) -> None:
        """Delete a session"""
        if session_id in self.sessions:
            del self.sessions[session_id]
            logger.info(f"Deleted session: {session_id}")

    def get_active_sessions(self) -> List[str]:
        """Get list of active session IDs"""
        return list(self.sessions.keys())
