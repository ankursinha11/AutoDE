"""
Cross-Encoder Reranker
======================
Reranks search results using a cross-encoder model for improved relevance.

Cross-encoders are more accurate than bi-encoders (used in initial retrieval)
but slower, so we use them for reranking top-k results.

Model: cross-encoder/ms-marco-MiniLM-L-6-v2
"""

from typing import List, Dict, Any, Tuple, Optional, Literal
from dataclasses import dataclass
from loguru import logger

try:
    from sentence_transformers import CrossEncoder
    CROSS_ENCODER_AVAILABLE = True
except ImportError:
    CROSS_ENCODER_AVAILABLE = False
    logger.warning("sentence-transformers not available - reranking disabled")


@dataclass
class RerankedResult:
    """A reranked result"""
    document: Dict[str, Any]
    original_score: float
    rerank_score: float
    original_rank: int
    new_rank: int

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "document": self.document,
            "original_score": self.original_score,
            "rerank_score": self.rerank_score,
            "original_rank": self.original_rank,
            "new_rank": self.new_rank
        }


class Reranker:
    """
    Reranks search results using cross-encoder

    Attributes:
        model_name: Cross-encoder model to use
        model: Loaded cross-encoder model
    """

    def __init__(
        self,
        model_name: str = "cross-encoder/ms-marco-MiniLM-L-6-v2"
    ):
        """
        Initialize reranker

        Args:
            model_name: HuggingFace cross-encoder model name
        """
        self.model_name = model_name
        self.model = None

        if CROSS_ENCODER_AVAILABLE:
            try:
                logger.info(f"Loading cross-encoder model: {model_name}")
                self.model = CrossEncoder(model_name)
                logger.info("Cross-encoder loaded successfully")
            except Exception as e:
                logger.error(f"Failed to load cross-encoder: {e}")
                self.model = None
        else:
            logger.warning("Cross-encoder not available - reranking will be skipped")

    def rerank(
        self,
        query: str,
        documents: List[Dict[str, Any]],
        top_k: Optional[int] = None
    ) -> List[RerankedResult]:
        """
        Rerank documents using cross-encoder

        Args:
            query: Search query
            documents: Documents to rerank
            top_k: Number of top results to return (default: all)

        Returns:
            Reranked results
        """
        if not self.model:
            # Fall back to original ranking
            logger.warning("Reranker not available - returning original ranking")
            return self._create_fallback_results(documents)

        if not documents:
            return []

        try:
            # Prepare query-document pairs
            pairs = self._prepare_pairs(query, documents)

            # Get cross-encoder scores
            rerank_scores = self.model.predict(pairs)

            # Create reranked results
            results_with_scores = [
                (doc, rerank_scores[i], i)
                for i, doc in enumerate(documents)
            ]

            # Sort by rerank score
            results_with_scores.sort(key=lambda x: x[1], reverse=True)

            # Create RerankedResult objects
            reranked = []
            for new_rank, (doc, rerank_score, original_rank) in enumerate(results_with_scores):
                reranked.append(RerankedResult(
                    document=doc,
                    original_score=doc.get("score", 0.0),
                    rerank_score=float(rerank_score),
                    original_rank=original_rank,
                    new_rank=new_rank
                ))

            # Apply top-k if specified
            if top_k:
                reranked = reranked[:top_k]

            logger.debug(f"Reranked {len(documents)} documents -> {len(reranked)} results")

            return reranked

        except Exception as e:
            logger.error(f"Reranking error: {e}")
            return self._create_fallback_results(documents)

    def _prepare_pairs(
        self,
        query: str,
        documents: List[Dict[str, Any]]
    ) -> List[List[str]]:
        """
        Prepare query-document pairs for cross-encoder

        Args:
            query: Search query
            documents: Documents

        Returns:
            List of [query, document_text] pairs
        """
        pairs = []

        for doc in documents:
            # Extract text from document
            doc_text = self._extract_text(doc)

            # Create pair
            pairs.append([query, doc_text])

        return pairs

    def _extract_text(self, document: Dict[str, Any]) -> str:
        """
        Extract text from document for reranking

        Args:
            document: Document dict

        Returns:
            Text representation
        """
        # Try different text fields
        text_parts = []

        # Title
        if "title" in document:
            text_parts.append(document["title"])

        # Content
        if "content" in document:
            content = document["content"]
            # Limit content length (cross-encoder has token limit)
            if len(content) > 512:
                content = content[:512] + "..."
            text_parts.append(content)

        # Metadata (if relevant)
        if "metadata" in document:
            metadata = document["metadata"]
            if "script_name" in metadata:
                text_parts.append(f"Script: {metadata['script_name']}")
            if "workflow_name" in metadata:
                text_parts.append(f"Workflow: {metadata['workflow_name']}")

        return " | ".join(text_parts)

    def _create_fallback_results(
        self,
        documents: List[Dict[str, Any]]
    ) -> List[RerankedResult]:
        """
        Create fallback results (original ranking) when reranker unavailable

        Args:
            documents: Original documents

        Returns:
            RerankedResult objects with original ranking
        """
        results = []

        for rank, doc in enumerate(documents):
            results.append(RerankedResult(
                document=doc,
                original_score=doc.get("score", 0.0),
                rerank_score=doc.get("score", 0.0),
                original_rank=rank,
                new_rank=rank
            ))

        return results

    def batch_rerank(
        self,
        queries: List[str],
        documents_per_query: List[List[Dict[str, Any]]],
        top_k: Optional[int] = None
    ) -> List[List[RerankedResult]]:
        """
        Rerank documents for multiple queries in batch

        Args:
            queries: List of queries
            documents_per_query: Documents for each query
            top_k: Top-k per query

        Returns:
            Reranked results per query
        """
        results = []

        for query, documents in zip(queries, documents_per_query):
            reranked = self.rerank(query, documents, top_k)
            results.append(reranked)

        return results


class AdaptiveReranker(Reranker):
    """
    Adaptive reranker that adjusts strategy based on query type

    For column transformation queries, emphasizes code snippets.
    For comparison queries, emphasizes structural similarity.
    """

    def rerank(
        self,
        query: str,
        documents: List[Dict[str, Any]],
        top_k: Optional[int] = None,
        query_intent: Optional[str] = None
    ) -> List[RerankedResult]:
        """
        Rerank with intent-aware strategy

        Args:
            query: Search query
            documents: Documents to rerank
            top_k: Number of results
            query_intent: Optional query intent

        Returns:
            Reranked results
        """
        # Adjust text extraction based on intent
        if query_intent == "column_transformation":
            # Emphasize code snippets
            self._extract_text = self._extract_text_code_focused
        elif query_intent == "comparison":
            # Emphasize structure
            self._extract_text = self._extract_text_structure_focused

        # Perform standard reranking
        return super().rerank(query, documents, top_k)

    def _extract_text_code_focused(self, document: Dict[str, Any]) -> str:
        """Extract text with focus on code"""
        parts = []

        if "content" in document:
            content = document["content"]
            # Look for code blocks
            if "```" in content or "SELECT" in content or "def " in content:
                # This looks like code - prioritize it
                parts.append(content[:512])

        if "metadata" in document:
            metadata = document["metadata"]
            if "transformation_logic" in metadata:
                parts.append(metadata["transformation_logic"])

        return " | ".join(parts) if parts else self._extract_text(document)

    def _extract_text_structure_focused(self, document: Dict[str, Any]) -> str:
        """Extract text with focus on structure"""
        parts = []

        if "title" in document:
            parts.append(document["title"])

        if "metadata" in document:
            metadata = document["metadata"]
            # Add structural information
            for key in ["workflow_name", "script_name", "component_type", "system"]:
                if key in metadata:
                    parts.append(f"{key}: {metadata[key]}")

        if "content" in document:
            # Add first 200 chars
            parts.append(document["content"][:200])

        return " | ".join(parts) if parts else self._extract_text(document)
