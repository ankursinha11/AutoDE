"""
Query Rewriter and Expander
============================
Rewrites and expands queries for better retrieval.

Features:
- Intent-based rewriting
- Synonym expansion
- Context-aware expansion from conversation history
- Pipeline-specific query enhancement
"""

from typing import List, Dict, Any, Optional
from loguru import logger
import re


class QueryRewriter:
    """
    Rewrites and expands queries for better retrieval

    Attributes:
        ai_analyzer: Optional AI analyzer for advanced rewriting
        synonym_map: Domain-specific synonym mappings
    """

    def __init__(self, ai_analyzer=None):
        """
        Initialize query rewriter

        Args:
            ai_analyzer: Optional AI analyzer for LLM-based rewriting
        """
        self.ai_analyzer = ai_analyzer

        # Domain-specific synonyms (customize for your domain)
        self.synonym_map = {
            # Common abbreviations
            "cdd": ["coverage discovery data", "cdd"],
            "sttm": ["source to target mapping", "source target transform", "sttm"],
            "etl": ["extract transform load", "data pipeline", "etl"],
            "hive": ["hive sql", "hiveql", "hive"],
            "pig": ["pig latin", "pig script", "pig"],
            "spark": ["apache spark", "pyspark", "spark"],
            "databricks": ["databricks notebook", "databricks pipeline", "databricks"],
            "hadoop": ["hadoop workflow", "hadoop script", "hadoop"],

            # Common terms
            "column": ["field", "attribute", "column"],
            "table": ["dataset", "relation", "table"],
            "transform": ["transformation", "mapping", "convert", "transform"],
            "workflow": ["pipeline", "job", "process", "workflow"],
            "script": ["notebook", "code", "file", "script"],
        }

        logger.info("Initialized QueryRewriter")

    def rewrite_query(
        self,
        query: str,
        intent: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        Rewrite query for better retrieval

        Args:
            query: Original query
            intent: Optional classified intent
            context: Optional conversation context

        Returns:
            Rewritten query
        """
        # Start with original query
        rewritten = query

        # Apply intent-based rewriting
        if intent:
            rewritten = self._rewrite_by_intent(rewritten, intent)

        # Expand synonyms
        rewritten = self._expand_synonyms(rewritten)

        # Add context if available
        if context:
            rewritten = self._add_context(rewritten, context)

        if rewritten != query:
            logger.debug(f"Rewrote query: '{query}' -> '{rewritten}'")

        return rewritten

    def _rewrite_by_intent(self, query: str, intent: str) -> str:
        """
        Rewrite based on query intent

        Args:
            query: Original query
            intent: Classified intent

        Returns:
            Rewritten query
        """
        # Intent-specific rewriting rules
        if intent == "column_transformation":
            # Enhance column queries
            if not any(word in query.lower() for word in ["select", "transformation", "logic"]):
                query = f"{query} transformation logic column mapping"

        elif intent == "pipeline_logic":
            # Enhance pipeline queries
            if not any(word in query.lower() for word in ["workflow", "pipeline", "process"]):
                query = f"{query} workflow pipeline process logic"

        elif intent == "comparison":
            # Enhance comparison queries
            if not any(word in query.lower() for word in ["compare", "difference", "mapping"]):
                query = f"{query} comparison difference mapping"

        elif intent == "code_search":
            # Enhance code search
            if not any(word in query.lower() for word in ["script", "code", "implementation"]):
                query = f"{query} script code implementation"

        return query

    def _expand_synonyms(self, query: str) -> str:
        """
        Expand query with synonyms

        Args:
            query: Original query

        Returns:
            Query with synonyms
        """
        query_lower = query.lower()
        expanded_terms = []

        # Check for known terms and add synonyms
        for term, synonyms in self.synonym_map.items():
            if term in query_lower:
                # Add synonyms
                expanded_terms.extend(synonyms)

        # Add expanded terms to query
        if expanded_terms:
            # Remove duplicates
            expanded_terms = list(set(expanded_terms))
            expanded = f"{query} {' '.join(expanded_terms)}"
            return expanded

        return query

    def _add_context(self, query: str, context: Dict[str, Any]) -> str:
        """
        Add conversation context to query

        Args:
            query: Original query
            context: Conversation context

        Returns:
            Query with context
        """
        context_parts = []

        # Add summary if available
        if "summary" in context and context["summary"]:
            summary = context["summary"]
            # Extract key entities from summary
            entities = self._extract_entities(summary)
            if entities:
                context_parts.extend(entities)

        # Add recent entities from active window
        if "active_window" in context:
            for turn in context["active_window"][-2:]:  # Last 2 turns
                if turn.get("role") == "user":
                    entities = self._extract_entities(turn.get("content", ""))
                    context_parts.extend(entities)

        # Add context to query
        if context_parts:
            # Remove duplicates
            context_parts = list(set(context_parts))
            # Limit to top 5 most relevant
            context_parts = context_parts[:5]
            contextualized = f"{query} {' '.join(context_parts)}"
            return contextualized

        return query

    def _extract_entities(self, text: str) -> List[str]:
        """
        Extract potential entity names from text

        Args:
            text: Text to extract from

        Returns:
            List of entities
        """
        entities = []

        # Extract quoted strings (often entity names)
        quoted = re.findall(r'"([^"]+)"', text)
        entities.extend(quoted)

        # Extract capitalized words (often proper nouns)
        capitalized = re.findall(r'\b[A-Z][a-zA-Z0-9_]*\b', text)
        entities.extend(capitalized)

        # Extract underscore_separated_names (often identifiers)
        identifiers = re.findall(r'\b[a-z][a-z0-9_]*_[a-z0-9_]+\b', text.lower())
        entities.extend(identifiers)

        return entities

    def generate_query_variations(self, query: str, n: int = 3) -> List[str]:
        """
        Generate multiple query variations

        Useful for multi-query retrieval strategies.

        Args:
            query: Original query
            n: Number of variations to generate

        Returns:
            List of query variations
        """
        variations = [query]  # Always include original

        # Variation 1: With synonyms
        if n >= 2:
            synonyms_query = self._expand_synonyms(query)
            if synonyms_query != query:
                variations.append(synonyms_query)

        # Variation 2: Simplified (remove stop words)
        if n >= 3:
            simplified = self._simplify_query(query)
            if simplified != query:
                variations.append(simplified)

        # Variation 3: Entity-focused
        if n >= 4:
            entities = self._extract_entities(query)
            if entities:
                entity_query = " ".join(entities)
                variations.append(entity_query)

        # Variation 4: Use AI for paraphrasing (if available)
        if n >= 5 and self.ai_analyzer:
            try:
                paraphrase = self._ai_paraphrase(query)
                if paraphrase and paraphrase != query:
                    variations.append(paraphrase)
            except Exception as e:
                logger.warning(f"AI paraphrasing failed: {e}")

        return variations[:n]

    def _simplify_query(self, query: str) -> str:
        """
        Simplify query by removing stop words

        Args:
            query: Original query

        Returns:
            Simplified query
        """
        # Common stop words
        stop_words = {
            "the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for",
            "of", "with", "by", "from", "is", "are", "was", "were", "be", "been",
            "have", "has", "had", "do", "does", "did", "will", "would", "should",
            "could", "may", "might", "can", "what", "where", "when", "how", "why",
            "which", "who", "this", "that", "these", "those"
        }

        # Tokenize and filter
        words = query.lower().split()
        filtered = [w for w in words if w not in stop_words]

        return " ".join(filtered) if filtered else query

    def _ai_paraphrase(self, query: str) -> Optional[str]:
        """
        Use AI to paraphrase query

        Args:
            query: Original query

        Returns:
            Paraphrased query or None
        """
        if not self.ai_analyzer:
            return None

        prompt = f"""Paraphrase this search query to find the same information using different words.
Keep it concise and focused.

Original query: {query}

Paraphrased query:"""

        try:
            result = self.ai_analyzer.analyze_code(
                code=query,
                analysis_type="query_paraphrase",
                custom_prompt=prompt
            )

            paraphrase = result.get("paraphrase", "").strip()
            return paraphrase if paraphrase else None

        except Exception as e:
            logger.error(f"AI paraphrase error: {e}")
            return None

    def extract_filters(self, query: str) -> Dict[str, Any]:
        """
        Extract metadata filters from query

        Args:
            query: Search query

        Returns:
            Dict of filters
        """
        filters = {}

        # Extract system type
        if "hadoop" in query.lower():
            filters["system"] = "hadoop"
        elif "databricks" in query.lower():
            filters["system"] = "databricks"
        elif "abinitio" in query.lower() or "ab initio" in query.lower():
            filters["system"] = "abinitio"

        # Extract pipeline/workflow name (quoted or capitalized)
        pipeline_match = re.search(r'"([^"]+)"', query)
        if pipeline_match:
            filters["pipeline_name"] = pipeline_match.group(1)

        # Extract file type
        for ext in [".py", ".sql", ".hql", ".pig", ".scala", ".mp"]:
            if ext in query.lower():
                filters["file_type"] = ext

        return filters
