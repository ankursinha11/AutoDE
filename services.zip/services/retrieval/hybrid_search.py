"""
Hybrid Search - BM25 + Semantic Vector Search
==============================================
Combines keyword-based BM25 with semantic vector search for better retrieval.

Benefits:
- BM25: Excellent for exact keyword matches (column names, file names)
- Semantic: Excellent for conceptual similarity
- Hybrid: Best of both worlds

Fusion strategy: Reciprocal Rank Fusion (RRF)
"""

from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass
from loguru import logger
import numpy as np

try:
    from rank_bm25 import BM25Okapi
    BM25_AVAILABLE = True
except ImportError:
    BM25_AVAILABLE = False
    logger.warning("rank-bm25 not available - falling back to semantic search only")


@dataclass
class SearchResult:
    """A single search result"""
    document: Dict[str, Any]
    score: float
    rank: int
    source: str  # "bm25", "semantic", or "hybrid"
    metadata: Dict[str, Any] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "document": self.document,
            "score": self.score,
            "rank": self.rank,
            "source": self.source,
            "metadata": self.metadata or {}
        }


class HybridSearch:
    """
    Hybrid search combining BM25 and semantic search

    Attributes:
        vector_search_client: Client for semantic vector search
        bm25_weight: Weight for BM25 scores (default: 0.3)
        semantic_weight: Weight for semantic scores (default: 0.7)
    """

    def __init__(
        self,
        vector_search_client,
        bm25_weight: float = 0.3,
        semantic_weight: float = 0.7
    ):
        """
        Initialize hybrid search

        Args:
            vector_search_client: ChromaDB or similar vector search client
            bm25_weight: Weight for BM25 (0-1)
            semantic_weight: Weight for semantic (0-1)
        """
        self.vector_search_client = vector_search_client
        self.bm25_weight = bm25_weight
        self.semantic_weight = semantic_weight

        # BM25 index (built on demand per collection)
        self.bm25_indices: Dict[str, BM25Okapi] = {}
        self.collection_documents: Dict[str, List[Dict[str, Any]]] = {}

        # Validate weights
        if not np.isclose(bm25_weight + semantic_weight, 1.0):
            logger.warning(f"Weights don't sum to 1.0: {bm25_weight} + {semantic_weight}")

        logger.info(f"Initialized HybridSearch (BM25: {bm25_weight}, Semantic: {semantic_weight})")

    def search(
        self,
        query: str,
        collection_name: str,
        top_k: int = 10,
        filters: Optional[Dict[str, Any]] = None,
        use_hybrid: bool = True
    ) -> List[SearchResult]:
        """
        Perform hybrid search

        Args:
            query: Search query
            collection_name: Collection to search
            top_k: Number of results to return
            filters: Optional metadata filters
            use_hybrid: If False, use semantic search only

        Returns:
            List of SearchResult objects
        """
        if not use_hybrid or not BM25_AVAILABLE:
            # Fall back to semantic search only
            return self._semantic_search(query, collection_name, top_k, filters)

        # Ensure BM25 index is built
        self._ensure_bm25_index(collection_name)

        # Get semantic results
        semantic_results = self._semantic_search(
            query, collection_name, top_k * 2, filters  # Get more for fusion
        )

        # Get BM25 results
        bm25_results = self._bm25_search(
            query, collection_name, top_k * 2, filters
        )

        # Fuse results using Reciprocal Rank Fusion
        fused_results = self._reciprocal_rank_fusion(
            semantic_results,
            bm25_results,
            top_k
        )

        logger.debug(f"Hybrid search returned {len(fused_results)} results")

        return fused_results

    def _semantic_search(
        self,
        query: str,
        collection_name: str,
        top_k: int,
        filters: Optional[Dict[str, Any]] = None
    ) -> List[SearchResult]:
        """
        Perform semantic vector search

        Args:
            query: Search query
            collection_name: Collection name
            top_k: Number of results
            filters: Optional filters

        Returns:
            List of SearchResult objects
        """
        try:
            # Use the vector search client (ChromaDB)
            results = self.vector_search_client.search(
                query=query,
                top_k=top_k,
                filters=filters
            )

            # Convert to SearchResult objects
            search_results = []
            for rank, (doc, score) in enumerate(zip(
                results.get("documents", []),
                results.get("scores", [])
            )):
                search_results.append(SearchResult(
                    document=doc,
                    score=score,
                    rank=rank,
                    source="semantic"
                ))

            return search_results

        except Exception as e:
            logger.error(f"Semantic search error: {e}")
            return []

    def _bm25_search(
        self,
        query: str,
        collection_name: str,
        top_k: int,
        filters: Optional[Dict[str, Any]] = None
    ) -> List[SearchResult]:
        """
        Perform BM25 keyword search

        Args:
            query: Search query
            collection_name: Collection name
            top_k: Number of results
            filters: Optional filters

        Returns:
            List of SearchResult objects
        """
        if not BM25_AVAILABLE:
            return []

        if collection_name not in self.bm25_indices:
            logger.warning(f"No BM25 index for collection: {collection_name}")
            return []

        try:
            # Tokenize query
            query_tokens = query.lower().split()

            # Get BM25 scores
            bm25_index = self.bm25_indices[collection_name]
            scores = bm25_index.get_scores(query_tokens)

            # Get documents
            documents = self.collection_documents[collection_name]

            # Apply filters if provided
            if filters:
                filtered_indices = [
                    i for i, doc in enumerate(documents)
                    if self._matches_filters(doc, filters)
                ]
                filtered_scores = [(i, scores[i]) for i in filtered_indices]
            else:
                filtered_scores = list(enumerate(scores))

            # Sort by score and get top-k
            filtered_scores.sort(key=lambda x: x[1], reverse=True)
            top_results = filtered_scores[:top_k]

            # Convert to SearchResult objects
            search_results = []
            for rank, (doc_idx, score) in enumerate(top_results):
                search_results.append(SearchResult(
                    document=documents[doc_idx],
                    score=score,
                    rank=rank,
                    source="bm25"
                ))

            return search_results

        except Exception as e:
            logger.error(f"BM25 search error: {e}")
            return []

    def _reciprocal_rank_fusion(
        self,
        semantic_results: List[SearchResult],
        bm25_results: List[SearchResult],
        top_k: int,
        k: int = 60  # RRF constant
    ) -> List[SearchResult]:
        """
        Fuse results using Reciprocal Rank Fusion

        RRF formula: score = sum(1 / (k + rank)) for each result list

        Args:
            semantic_results: Results from semantic search
            bm25_results: Results from BM25 search
            top_k: Number of final results
            k: RRF constant (default: 60)

        Returns:
            Fused and ranked results
        """
        # Build document ID -> score mapping
        doc_scores: Dict[str, float] = {}
        doc_objects: Dict[str, Dict[str, Any]] = {}

        # Add semantic scores
        for result in semantic_results:
            doc_id = self._get_doc_id(result.document)
            rrf_score = self.semantic_weight / (k + result.rank + 1)
            doc_scores[doc_id] = doc_scores.get(doc_id, 0.0) + rrf_score
            doc_objects[doc_id] = result.document

        # Add BM25 scores
        for result in bm25_results:
            doc_id = self._get_doc_id(result.document)
            rrf_score = self.bm25_weight / (k + result.rank + 1)
            doc_scores[doc_id] = doc_scores.get(doc_id, 0.0) + rrf_score
            doc_objects[doc_id] = result.document

        # Sort by fused score
        sorted_docs = sorted(
            doc_scores.items(),
            key=lambda x: x[1],
            reverse=True
        )[:top_k]

        # Create final SearchResult objects
        fused_results = []
        for rank, (doc_id, score) in enumerate(sorted_docs):
            fused_results.append(SearchResult(
                document=doc_objects[doc_id],
                score=score,
                rank=rank,
                source="hybrid",
                metadata={
                    "in_semantic": any(self._get_doc_id(r.document) == doc_id for r in semantic_results),
                    "in_bm25": any(self._get_doc_id(r.document) == doc_id for r in bm25_results)
                }
            ))

        return fused_results

    def _ensure_bm25_index(self, collection_name: str) -> None:
        """
        Ensure BM25 index is built for collection

        Args:
            collection_name: Collection to index
        """
        if collection_name in self.bm25_indices:
            return  # Already indexed

        if not BM25_AVAILABLE:
            return

        logger.info(f"Building BM25 index for collection: {collection_name}")

        try:
            # Get all documents from collection
            # This is collection-specific - adjust for your vector store
            documents = self._fetch_all_documents(collection_name)

            if not documents:
                logger.warning(f"No documents found for collection: {collection_name}")
                return

            # Tokenize documents for BM25
            tokenized_docs = [
                self._tokenize_document(doc)
                for doc in documents
            ]

            # Build BM25 index
            bm25_index = BM25Okapi(tokenized_docs)

            # Store index and documents
            self.bm25_indices[collection_name] = bm25_index
            self.collection_documents[collection_name] = documents

            logger.info(f"Built BM25 index with {len(documents)} documents")

        except Exception as e:
            logger.error(f"Error building BM25 index: {e}")

    def _fetch_all_documents(self, collection_name: str) -> List[Dict[str, Any]]:
        """
        Fetch all documents from ChromaDB collection for BM25 indexing

        Args:
            collection_name: Collection name

        Returns:
            List of documents with id, content, metadata
        """
        try:
            if not self.vector_search_client:
                logger.warning("No vector search client available - BM25 disabled")
                return []

            # Get the LocalSearchClient's collection
            if not hasattr(self.vector_search_client, 'collection') or not self.vector_search_client.collection:
                logger.warning(f"Collection not initialized - BM25 disabled for {collection_name}")
                return []

            collection = self.vector_search_client.collection

            # Fetch all documents from ChromaDB
            # ChromaDB's get() without IDs returns all documents
            results = collection.get(
                include=["documents", "metadatas"]
            )

            # Build document list
            documents = []
            doc_ids = results.get("ids", [])
            doc_texts = results.get("documents", [])
            doc_metadatas = results.get("metadatas", [])

            for i, doc_id in enumerate(doc_ids):
                content = doc_texts[i] if i < len(doc_texts) else ""
                metadata = doc_metadatas[i] if i < len(doc_metadatas) else {}

                if content:  # Only include documents with content
                    documents.append({
                        "id": doc_id,
                        "content": content,
                        "metadata": metadata,
                        "title": metadata.get("title", metadata.get("file_name", "Untitled"))
                    })

            logger.info(f"✅ Fetched {len(documents)} documents from {collection_name} for BM25 indexing")
            return documents

        except Exception as e:
            logger.error(f"Error fetching documents from {collection_name}: {e}")
            logger.warning("BM25 search disabled - falling back to semantic-only")
            return []

    def _tokenize_document(self, document: Dict[str, Any]) -> List[str]:
        """
        Tokenize document for BM25

        Args:
            document: Document to tokenize

        Returns:
            List of tokens
        """
        # Extract text content
        content = document.get("content", "")
        title = document.get("title", "")

        # Combine and tokenize
        text = f"{title} {content}"
        tokens = text.lower().split()

        return tokens

    def _get_doc_id(self, document: Dict[str, Any]) -> str:
        """
        Get unique document ID

        Args:
            document: Document

        Returns:
            Unique ID
        """
        # Try common ID fields
        for field in ["id", "doc_id", "document_id", "file_path"]:
            if field in document:
                return str(document[field])

        # Fall back to hash of content
        content = document.get("content", "")
        return str(hash(content))

    def _matches_filters(
        self,
        document: Dict[str, Any],
        filters: Dict[str, Any]
    ) -> bool:
        """
        Check if document matches filters

        Args:
            document: Document to check
            filters: Filters to apply

        Returns:
            True if matches
        """
        metadata = document.get("metadata", {})

        for key, value in filters.items():
            if metadata.get(key) != value:
                return False

        return True

    def rebuild_index(self, collection_name: str) -> None:
        """
        Rebuild BM25 index for collection

        Args:
            collection_name: Collection to rebuild
        """
        if collection_name in self.bm25_indices:
            del self.bm25_indices[collection_name]
            del self.collection_documents[collection_name]

        self._ensure_bm25_index(collection_name)
