"""
Semantic Logic Matcher
=======================
Matches scripts/notebooks between systems based on business purpose and logic,
not just name matching.

Features:
- LLM-based understanding of script purpose
- Semantic similarity matching
- Handles 1-to-many and many-to-1 mappings
- Identifies missing logic
- Explains mapping rationale
"""

from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, field
from loguru import logger


@dataclass
class LogicMatch:
    """A matched pair of scripts/notebooks"""
    source_script: str
    target_script: str
    match_score: float  # 0-1
    match_type: str  # "1-to-1", "1-to-many", "many-to-1", "partial"
    rationale: str  # Why they match
    source_purpose: str
    target_purpose: str
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "source_script": self.source_script,
            "target_script": self.target_script,
            "match_score": self.match_score,
            "match_type": self.match_type,
            "rationale": self.rationale,
            "source_purpose": self.source_purpose,
            "target_purpose": self.target_purpose,
            "metadata": self.metadata
        }


class SemanticLogicMatcher:
    """
    Matches scripts/notebooks between systems using semantic understanding

    Attributes:
        ai_analyzer: AI analyzer for LLM calls
        code_analyzer: Code analyzer for logic extraction
        similarity_threshold: Minimum score to consider a match (default: 0.6)
    """

    def __init__(
        self,
        ai_analyzer,
        code_analyzer,
        similarity_threshold: float = 0.6
    ):
        """
        Initialize semantic matcher

        Args:
            ai_analyzer: AI analyzer for LLM-based matching
            code_analyzer: Code analyzer for logic extraction
            similarity_threshold: Minimum match score (0-1)
        """
        self.ai_analyzer = ai_analyzer
        self.code_analyzer = code_analyzer
        self.similarity_threshold = similarity_threshold

        logger.info(f"Initialized SemanticLogicMatcher (threshold: {similarity_threshold})")

    def match_scripts(
        self,
        source_scripts: List[Dict[str, Any]],
        target_scripts: List[Dict[str, Any]],
        source_system: str = "hadoop",
        target_system: str = "databricks"
    ) -> List[LogicMatch]:
        """
        Match scripts between source and target systems

        Args:
            source_scripts: List of source system scripts
                Each dict should have: file_path, script_name, logic_summary (optional)
            target_scripts: List of target system scripts
            source_system: Source system name
            target_system: Target system name

        Returns:
            List of LogicMatch objects
        """
        logger.info(f"Matching {len(source_scripts)} {source_system} scripts to {len(target_scripts)} {target_system} scripts")

        matches = []

        # Step 1: Analyze purpose of all scripts
        logger.info("Step 1: Analyzing script purposes...")
        source_purposes = self._analyze_script_purposes(source_scripts, source_system)
        target_purposes = self._analyze_script_purposes(target_scripts, target_system)

        # Step 2: Find matches using LLM
        logger.info("Step 2: Finding semantic matches...")
        matches = self._find_semantic_matches(
            source_scripts, target_scripts,
            source_purposes, target_purposes
        )

        # Step 3: Identify unmapped scripts
        mapped_source = {m.source_script for m in matches}
        mapped_target = {m.target_script for m in matches}

        unmapped_source = [s for s in source_scripts if s['script_name'] not in mapped_source]
        unmapped_target = [t for t in target_scripts if t['script_name'] not in mapped_target]

        logger.info(f"  Found {len(matches)} matches")
        logger.info(f"  Unmapped source: {len(unmapped_source)}")
        logger.info(f"  Unmapped target: {len(unmapped_target)}")

        return matches

    def _analyze_script_purposes(
        self,
        scripts: List[Dict[str, Any]],
        system: str
    ) -> Dict[str, str]:
        """
        Analyze business purpose of each script

        Args:
            scripts: List of scripts
            system: System name

        Returns:
            Dict of script_name -> purpose description
        """
        purposes = {}

        for script in scripts:
            script_name = script.get('script_name')
            file_path = script.get('file_path')

            # Check if purpose already provided
            if 'logic_summary' in script:
                purposes[script_name] = script['logic_summary']
                continue

            # Use code analyzer to extract purpose
            if file_path:
                try:
                    analysis = self.code_analyzer.analyze_file(file_path, analysis_type="summary_only")
                    if analysis:
                        purposes[script_name] = analysis.summary
                        continue
                except Exception as e:
                    logger.warning(f"Could not analyze {script_name}: {e}")

            # Fallback: Use LLM to infer from name
            purposes[script_name] = self._infer_purpose_from_name(script_name, system)

        return purposes

    def _infer_purpose_from_name(self, script_name: str, system: str) -> str:
        """Infer script purpose from its name using LLM"""
        prompt = f"""Based on the script name, infer its likely business purpose.

System: {system}
Script name: {script_name}

What is the likely business purpose of this script? (1-2 sentences)

Purpose:"""

        try:
            result = self.ai_analyzer.analyze_code(
                code=script_name,
                analysis_type="purpose_inference",
                custom_prompt=prompt
            )

            return result.get("purpose", f"Script: {script_name}")

        except Exception as e:
            logger.warning(f"Purpose inference failed for {script_name}: {e}")
            return f"Script: {script_name}"

    def _find_semantic_matches(
        self,
        source_scripts: List[Dict[str, Any]],
        target_scripts: List[Dict[str, Any]],
        source_purposes: Dict[str, str],
        target_purposes: Dict[str, str]
    ) -> List[LogicMatch]:
        """
        Find semantic matches using LLM

        Args:
            source_scripts: Source scripts
            target_scripts: Target scripts
            source_purposes: Source script purposes
            target_purposes: Target script purposes

        Returns:
            List of matches
        """
        # Build matching prompt
        source_list = "\n".join([
            f"- {s['script_name']}: {source_purposes.get(s['script_name'], 'N/A')}"
            for s in source_scripts
        ])

        target_list = "\n".join([
            f"- {t['script_name']}: {target_purposes.get(t['script_name'], 'N/A')}"
            for t in target_scripts
        ])

        prompt = f"""Match scripts between source and target systems based on their business purpose and logic.

SOURCE SCRIPTS:
{source_list}

TARGET SCRIPTS:
{target_list}

For each source script, identify the best matching target script(s). Consider:
1. Business purpose similarity
2. Data transformation logic similarity
3. Input/output tables

A source script may map to:
- One target script (1-to-1)
- Multiple target scripts (1-to-many) - when logic is split
- Be part of a group mapping to one target (many-to-1) - when logic is combined

Return matches in this JSON format:
{{
    "matches": [
        {{
            "source_script": "source_name",
            "target_script": "target_name",
            "match_score": 0.9,
            "match_type": "1-to-1",
            "rationale": "Both process patient data with same transformations"
        }}
    ]
}}

Matches:"""

        try:
            result = self.ai_analyzer.analyze_code(
                code=source_list + "\n" + target_list,
                analysis_type="script_matching",
                custom_prompt=prompt
            )

            # Parse matches
            matches = []
            for match_dict in result.get("matches", []):
                source_name = match_dict.get("source_script")
                target_name = match_dict.get("target_script")

                match = LogicMatch(
                    source_script=source_name,
                    target_script=target_name,
                    match_score=match_dict.get("match_score", 0.7),
                    match_type=match_dict.get("match_type", "1-to-1"),
                    rationale=match_dict.get("rationale", ""),
                    source_purpose=source_purposes.get(source_name, ""),
                    target_purpose=target_purposes.get(target_name, "")
                )

                # Only include if above threshold
                if match.match_score >= self.similarity_threshold:
                    matches.append(match)

            return matches

        except Exception as e:
            logger.error(f"Semantic matching failed: {e}")
            # Fallback to name-based matching
            return self._fallback_name_matching(source_scripts, target_scripts, source_purposes, target_purposes)

    def _fallback_name_matching(
        self,
        source_scripts: List[Dict[str, Any]],
        target_scripts: List[Dict[str, Any]],
        source_purposes: Dict[str, str],
        target_purposes: Dict[str, str]
    ) -> List[LogicMatch]:
        """
        Fallback to simple name-based matching

        Args:
            source_scripts: Source scripts
            target_scripts: Target scripts
            source_purposes: Source purposes
            target_purposes: Target purposes

        Returns:
            List of matches based on name similarity
        """
        from difflib import SequenceMatcher

        matches = []

        for source in source_scripts:
            source_name = source['script_name']
            best_match = None
            best_score = 0.0

            for target in target_scripts:
                target_name = target['script_name']

                # Calculate name similarity
                similarity = SequenceMatcher(None, source_name.lower(), target_name.lower()).ratio()

                if similarity > best_score and similarity >= self.similarity_threshold:
                    best_score = similarity
                    best_match = target_name

            if best_match:
                matches.append(LogicMatch(
                    source_script=source_name,
                    target_script=best_match,
                    match_score=best_score,
                    match_type="1-to-1",
                    rationale=f"Name similarity: {best_score:.2%}",
                    source_purpose=source_purposes.get(source_name, ""),
                    target_purpose=target_purposes.get(best_match, "")
                ))

        logger.info(f"Fallback matching found {len(matches)} matches")
        return matches

    def compare_matched_logic(
        self,
        match: LogicMatch,
        source_file_path: str,
        target_file_path: str
    ) -> Dict[str, Any]:
        """
        Compare logic between matched scripts

        Args:
            match: LogicMatch object
            source_file_path: Path to source script
            target_file_path: Path to target script

        Returns:
            Comparison results dict
        """
        logger.info(f"Comparing logic: {match.source_script} vs {match.target_script}")

        # Use code analyzer to compare
        comparison = self.code_analyzer.compare_logic(source_file_path, target_file_path)

        # Add match info
        comparison['match_info'] = match.to_dict()

        return comparison

    def generate_mapping_report(
        self,
        matches: List[LogicMatch],
        unmapped_source: List[str],
        unmapped_target: List[str]
    ) -> str:
        """
        Generate human-readable mapping report

        Args:
            matches: List of matches
            unmapped_source: Unmapped source scripts
            unmapped_target: Unmapped target scripts

        Returns:
            Report text
        """
        report_lines = []

        report_lines.append("=" * 80)
        report_lines.append("SCRIPT MAPPING REPORT")
        report_lines.append("=" * 80)
        report_lines.append("")

        # Summary
        report_lines.append(f"Total Matches: {len(matches)}")
        report_lines.append(f"Unmapped Source: {len(unmapped_source)}")
        report_lines.append(f"Unmapped Target: {len(unmapped_target)}")
        report_lines.append("")

        # Match details
        report_lines.append("MATCHES:")
        report_lines.append("-" * 80)

        for i, match in enumerate(matches, 1):
            report_lines.append(f"\n{i}. {match.source_script} → {match.target_script}")
            report_lines.append(f"   Score: {match.match_score:.2%} | Type: {match.match_type}")
            report_lines.append(f"   Rationale: {match.rationale}")
            report_lines.append(f"   Source Purpose: {match.source_purpose}")
            report_lines.append(f"   Target Purpose: {match.target_purpose}")

        # Unmapped
        if unmapped_source:
            report_lines.append("\n" + "=" * 80)
            report_lines.append("UNMAPPED SOURCE SCRIPTS:")
            report_lines.append("-" * 80)
            for script in unmapped_source:
                report_lines.append(f"  - {script}")

        if unmapped_target:
            report_lines.append("\n" + "=" * 80)
            report_lines.append("UNMAPPED TARGET SCRIPTS:")
            report_lines.append("-" * 80)
            for script in unmapped_target:
                report_lines.append(f"  - {script}")

        report_lines.append("\n" + "=" * 80)

        return "\n".join(report_lines)
