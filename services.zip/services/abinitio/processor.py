#!/usr/bin/env python3
"""
Ab Initio Complete Processor
Orchestrates the complete processing pipeline from a single .mp file to all outputs:
1. Parse components from .mp file
2. Generate DOT visualization
3. Generate SVG visualization
4. Extract all subgraphs with simplified connections
5. Build dependency graph structure

Output files are generated in 'output' folder with timestamp to prevent overwriting.

Usage: python abinitio_processor.py <input_file>
"""

import os
import sys
from pathlib import Path
import json
import subprocess
from datetime import datetime

# Import all the processing modules
from parser import EnhancedAbInitioParser
from dot_generator import EnhancedDotGenerator
from subgraph_extractor import SubgraphExtractor
from dependency_graph_builder import DependencyGraphBuilder

class AbInitioProcessor:
    """Complete Ab Initio processing pipeline"""
    
    def __init__(self, input_file: str):
        """Initialize processor with input file"""
        self.input_file = input_file
        self.output_dir = "output"
        self.base_name = Path(input_file).stem

        # Generate timestamp for unique filenames
        timestamp = datetime.now().strftime("%Y_%m_%d_%H_%M_%S")
        self.output_prefix = f"{self.base_name}_{timestamp}"

        # Ensure output directory exists
        os.makedirs(self.output_dir, exist_ok=True)

        # Define output file paths with timestamp
        self.components_file = os.path.join(self.output_dir, f"{self.output_prefix}_components.json")
        self.dot_file = os.path.join(self.output_dir, f"{self.output_prefix}_graph.dot")
        self.svg_file = os.path.join(self.output_dir, f"{self.output_prefix}_graph.svg")
        self.subgraphs_file = os.path.join(self.output_dir, f"{self.output_prefix}_subgraphs.json")
        self.subgraph_dots_dir = os.path.join(self.output_dir, f"{self.output_prefix}_subgraph_dots")

        print(f"🎯 AB INITIO COMPLETE PROCESSOR")
        print(f"=" * 50)
        print(f"📁 Input File: {self.input_file}")
        print(f"📁 Output Directory: {self.output_dir}")
        print(f"📁 Output Prefix: {self.output_prefix}")
        print(f"📁 Timestamp: {timestamp}")
    
    def step1_parse_components(self):
        """Step 1: Parse components from .mp file"""
        print(f"\n🔍 STEP 1: PARSING COMPONENTS")
        print(f"-" * 30)
        
        try:
            parser = EnhancedAbInitioParser()
            result = parser.parse_mp_file(self.input_file, self.output_dir, f"{self.output_prefix}_components.json")
            
            if os.path.exists(self.components_file):
                print(f"✅ Components parsed successfully: {self.components_file}")
                return True
            else:
                print(f"❌ Components file not created: {self.components_file}")
                return False
                
        except Exception as e:
            print(f"❌ Error parsing components: {e}")
            return False
    
    def step2_generate_dot(self):
        """Step 2: Generate DOT visualization"""
        print(f"\n🎨 STEP 2: GENERATING DOT VISUALIZATION")
        print(f"-" * 35)
        
        try:
            if not os.path.exists(self.components_file):
                print(f"❌ Components file not found: {self.components_file}")
                return False
            
            dot_generator = EnhancedDotGenerator(self.components_file)
            dot_generator.generate_enhanced_dot(self.output_dir, f"{self.output_prefix}_graph.dot")
            
            if os.path.exists(self.dot_file):
                print(f"✅ DOT file generated successfully: {self.dot_file}")
                return True
            else:
                print(f"❌ DOT file not created: {self.dot_file}")
                return False
                
        except Exception as e:
            print(f"❌ Error generating DOT file: {e}")
            return False

    def step2b_generate_svg(self):
        """Step 2b: Generate SVG from DOT file"""
        print(f"\n🖼️  STEP 2B: GENERATING SVG VISUALIZATION")
        print(f"-" * 40)

        try:
            # Check if DOT file exists
            if not os.path.exists(self.dot_file):
                print(f"❌ DOT file not found: {self.dot_file}")
                return False

            # Run dot command to generate SVG
            result = subprocess.run(
                ['dot', '-Tsvg', self.dot_file, '-o', self.svg_file],
                capture_output=True,
                text=True,
                timeout=60
            )

            if result.returncode == 0 and os.path.exists(self.svg_file):
                svg_size = os.path.getsize(self.svg_file) / 1024
                print(f"✅ SVG file generated successfully: {self.svg_file}")
                print(f"   📏 Size: {svg_size:.1f} KB")
                return True
            else:
                print(f"❌ SVG generation failed")
                if result.stderr:
                    print(f"   Error: {result.stderr}")
                return False

        except subprocess.TimeoutExpired:
            print(f"❌ SVG generation timed out (file too large)")
            return False
        except Exception as e:
            print(f"❌ Error generating SVG: {e}")
            return False

    def step3_extract_subgraphs(self):
        """Step 3: Extract all subgraphs with simplified connections"""
        print(f"\n🔗 STEP 3: EXTRACTING SUBGRAPHS")
        print(f"-" * 30)
        
        try:
            if not os.path.exists(self.components_file):
                print(f"❌ Components file not found: {self.components_file}")
                return False
            
            extractor = SubgraphExtractor(self.components_file)
            extractor.generate_all_subgraphs_simplified(self.output_dir, f"{self.output_prefix}_subgraphs.json")
            
            if os.path.exists(self.subgraphs_file):
                print(f"✅ Subgraphs extracted successfully: {self.subgraphs_file}")
                return True
            else:
                print(f"❌ Subgraphs file not created: {self.subgraphs_file}")
                return False
                
        except Exception as e:
            print(f"❌ Error extracting subgraphs: {e}")
            return False
    
    def step4_build_dependency_graph(self):
        """Step 4: Build dependency graph structure"""
        print(f"\n🌳 STEP 4: BUILDING DEPENDENCY GRAPH")
        print(f"-" * 35)

        try:
            if not os.path.exists(self.subgraphs_file):
                print(f"❌ Subgraphs file not found: {self.subgraphs_file}")
                return False

            builder = DependencyGraphBuilder(self.subgraphs_file)
            builder.add_graph_structure_to_file(self.subgraphs_file)

            print(f"✅ Dependency graph added successfully to: {self.subgraphs_file}")
            return True

        except Exception as e:
            print(f"❌ Error building dependency graph: {e}")
            return False

    def step5_generate_subgraph_dots(self):
        """Step 5: Generate individual DOT files for each subgraph"""
        print(f"\n🎨 STEP 5: GENERATING SUBGRAPH DOT FILES")
        print(f"-" * 40)

        try:
            if not os.path.exists(self.subgraphs_file):
                print(f"❌ Subgraphs file not found: {self.subgraphs_file}")
                return False

            # Create subdirectory for subgraph DOT files
            os.makedirs(self.subgraph_dots_dir, exist_ok=True)

            # Load subgraphs data
            with open(self.subgraphs_file, 'r') as f:
                data = json.load(f)

            subgraphs = data.get('subgraphs', {})
            total_subgraphs = len(subgraphs)

            print(f"   📊 Generating DOT files for {total_subgraphs} subgraphs...")

            generated_count = 0
            failed_count = 0

            # Generate DOT file for each subgraph
            extractor = SubgraphExtractor(self.components_file)

            for subgraph_id, subgraph_data in subgraphs.items():
                try:
                    # Extract this specific subgraph with all details
                    extracted = extractor.extract_subgraph(
                        graph_id=subgraph_id,
                        include_dependencies=False,
                        dependency_depth=0
                    )

                    # Generate DOT file
                    dot_filename = f"subgraph_{subgraph_id}.dot"
                    extractor.generate_subgraph_dot(
                        extracted=extracted,
                        output_folder=self.subgraph_dots_dir,
                        output_filename=dot_filename,
                        graph_id=subgraph_id
                    )

                    generated_count += 1

                except Exception as e:
                    print(f"      ⚠️  Failed to generate DOT for subgraph {subgraph_id}: {e}")
                    failed_count += 1

            print(f"   ✅ Generated {generated_count} DOT files")
            if failed_count > 0:
                print(f"   ⚠️  Failed: {failed_count} DOT files")
            print(f"   📁 Location: {self.subgraph_dots_dir}")

            return generated_count > 0

        except Exception as e:
            print(f"❌ Error generating subgraph DOT files: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def process_complete(self):
        """Run the complete processing pipeline"""
        print(f"\n🚀 STARTING COMPLETE AB INITIO PROCESSING PIPELINE")
        print(f"=" * 60)
        
        # Track success of each step
        steps_success = []
        
        # Step 1: Parse components
        success = self.step1_parse_components()
        steps_success.append(("Parse Components", success))
        if not success:
            return self._print_final_summary(steps_success)
        
        # Step 2: Generate DOT visualization
        success = self.step2_generate_dot()
        steps_success.append(("Generate DOT", success))
        if not success:
            return self._print_final_summary(steps_success)

        # Step 2b: Generate SVG from DOT (optional, won't fail pipeline)
        svg_success = self.step2b_generate_svg()
        steps_success.append(("Generate SVG", svg_success))
        # Don't fail pipeline if SVG generation fails - continue to next steps

        # Step 3: Extract subgraphs
        success = self.step3_extract_subgraphs()
        steps_success.append(("Extract Subgraphs", success))
        if not success:
            return self._print_final_summary(steps_success)
        
        # Step 4: Build dependency graph
        success = self.step4_build_dependency_graph()
        steps_success.append(("Build Dependency Graph", success))

        return self._print_final_summary(steps_success)
    
    def _print_final_summary(self, steps_success):
        """Print final processing summary"""
        print(f"\n📊 PROCESSING SUMMARY")
        print(f"=" * 30)
        
        all_success = True
        for step_name, success in steps_success:
            status = "✅ SUCCESS" if success else "❌ FAILED"
            print(f"   • {step_name}: {status}")
            if not success:
                all_success = False
        
        if all_success:
            print(f"\n🎉 ALL STEPS COMPLETED SUCCESSFULLY!")
            print(f"\n📁 OUTPUT FILES GENERATED:")
            print(f"   • Components: {self.components_file}")
            print(f"   • DOT Graph: {self.dot_file}")
            if os.path.exists(self.svg_file):
                print(f"   • SVG Graph: {self.svg_file}")
            print(f"   • Subgraphs: {self.subgraphs_file}")

            # Show file sizes
            try:
                components_size = os.path.getsize(self.components_file) / 1024
                dot_size = os.path.getsize(self.dot_file) / 1024
                subgraphs_size = os.path.getsize(self.subgraphs_file) / 1024

                print(f"\n📏 FILE SIZES:")
                print(f"   • Components: {components_size:.1f} KB")
                print(f"   • DOT Graph: {dot_size:.1f} KB")
                if os.path.exists(self.svg_file):
                    svg_size = os.path.getsize(self.svg_file) / 1024
                    print(f"   • SVG Graph: {svg_size:.1f} KB")
                print(f"   • Subgraphs: {subgraphs_size:.1f} KB")

            except Exception as e:
                print(f"   (Could not determine file sizes: {e})")

            return True
        else:
            print(f"\n❌ PROCESSING INCOMPLETE - Some steps failed")
            return False

def main():
    """Main function with command line argument parsing"""
    
    # Parse command line arguments
    if len(sys.argv) < 2:
        print("Usage: python abinitio_processor.py <input_file>")
        print("Example: python abinitio_processor.py data/400_commGenIpa.mp")
        print("Example: python abinitio_processor.py C:\\path\\to\\file.mp")
        print("")
        print("Output files will be generated in 'output' folder with timestamp:")
        print("  1. <basename>_YYYY_MM_DD_HH_MM_SS_components.json - Parsed components")
        print("  2. <basename>_YYYY_MM_DD_HH_MM_SS_graph.dot - DOT visualization with vertex names")
        print("  3. <basename>_YYYY_MM_DD_HH_MM_SS_graph.svg - SVG visualization")
        print("  4. <basename>_YYYY_MM_DD_HH_MM_SS_subgraphs.json - Subgraphs with dependency graph & vertex_name")
        return

    input_file = sys.argv[1]
    
    # Validate input file
    if not os.path.exists(input_file):
        print(f"❌ Error: Input file '{input_file}' not found")
        return
    
    # Validate it's an .mp file
    if not input_file.lower().endswith('.mp'):
        print(f"❌ Error: Input file must be an Ab Initio .mp file")
        return
    
    try:
        # Create processor and run complete pipeline
        processor = AbInitioProcessor(input_file)
        success = processor.process_complete()

        if success:
            print(f"\n🎯 PROCESSING COMPLETED SUCCESSFULLY!")
            print(f"   All output files are available in: output")
        else:
            print(f"\n⚠️  PROCESSING COMPLETED WITH ERRORS")
            print(f"   Check the output directory: output")
            
    except Exception as e:
        print(f"❌ Fatal error during processing: {e}")
        return

if __name__ == "__main__":
    main()