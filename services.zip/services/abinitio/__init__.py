"""
Ab Initio Parsing Services

This module provides comprehensive Ab Initio .mp file parsing and analysis capabilities:

1. Enhanced Parser (from VM_gf):
   - Extracts all graph components (vertices, flows, ports)
   - Builds complete dependency graph
   - Generates DOT/SVG visualizations

2. DML/XFR Embedder (from VM_Automation):
   - AI-powered identification of DML/XFR files
   - GPT-5 embedding for referenced files
   - Smart file extraction from graph content

3. STTM Generator (from VM_Automation):
   - Column-level mapping generation
   - Phase 0 DML reduction (40-70% token optimization)
   - Output-specific STTM creation

Usage:
    from services.abinitio import EnhancedAbInitioParser

    parser = EnhancedAbInitioParser()
    result = parser.parse_mp_file("path/to/file.mp")
"""

from .enhanced_parser import EnhancedAbInitioParser

# Note: sttm_generator, dml_xfr_embedder, and processor are scripts/modules
# that can be imported directly if needed but are not part of the main API

__all__ = ['EnhancedAbInitioParser']
