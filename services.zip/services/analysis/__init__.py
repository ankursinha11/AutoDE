"""
Code Analysis Module
====================
File reading and code understanding for evidence-based answers.
"""

from services.analysis.file_reader import FileReader, FileContent
from services.analysis.code_analyzer import (
    CodeAnalyzer,
    CodeAnalysisResult,
    ColumnTransformation
)

__all__ = [
    "FileReader",
    "FileContent",
    "CodeAnalyzer",
    "CodeAnalysisResult",
    "ColumnTransformation"
]
