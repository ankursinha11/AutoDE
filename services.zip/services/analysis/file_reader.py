"""
File Content Reader
===================
Reads actual file contents from disk for evidence-based analysis.

Supports:
- Python (.py)
- SQL (.sql, .hql)
- Pig (.pig)
- Scala (.scala)
- Hive (.hql)
- JSON (ADF pipelines)
- XML (Ab Initio .mp files)

Features:
- Smart chunking for large files
- Syntax highlighting markers
- Line number tracking
- Caching for session
"""

from typing import Dict, List, Optional, Any, Tuple
from pathlib import Path
from dataclasses import dataclass, field
from loguru import logger
import os


@dataclass
class FileContent:
    """File content with metadata"""
    file_path: str
    content: str
    lines: List[str]
    file_type: str
    size_bytes: int
    line_count: int
    encoding: str = "utf-8"
    metadata: Dict[str, Any] = field(default_factory=dict)

    def get_lines_range(self, start: int, end: int) -> str:
        """
        Get specific line range

        Args:
            start: Start line (1-indexed)
            end: End line (1-indexed)

        Returns:
            Lines as string
        """
        if start < 1:
            start = 1
        if end > self.line_count:
            end = self.line_count

        # Convert to 0-indexed
        start_idx = start - 1
        end_idx = end

        selected_lines = self.lines[start_idx:end_idx]

        # Add line numbers
        numbered = [
            f"{i + start:4d} | {line}"
            for i, line in enumerate(selected_lines)
        ]

        return "\n".join(numbered)

    def search_lines(self, pattern: str, case_sensitive: bool = False) -> List[Tuple[int, str]]:
        """
        Search for pattern in lines

        Args:
            pattern: Search pattern
            case_sensitive: Case sensitive search

        Returns:
            List of (line_number, line_content) tuples
        """
        results = []

        search_pattern = pattern if case_sensitive else pattern.lower()

        for line_num, line in enumerate(self.lines, 1):
            search_line = line if case_sensitive else line.lower()

            if search_pattern in search_line:
                results.append((line_num, line))

        return results

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "file_path": self.file_path,
            "file_type": self.file_type,
            "size_bytes": self.size_bytes,
            "line_count": self.line_count,
            "encoding": self.encoding,
            "metadata": self.metadata
        }


class FileReader:
    """
    Reads file contents with caching and smart handling

    Attributes:
        cache: In-memory cache for session
        max_file_size_mb: Max file size to read (default: 10MB)
        max_lines: Max lines to read (default: 10000)
    """

    def __init__(
        self,
        max_file_size_mb: int = 10,
        max_lines: int = 10000
    ):
        """
        Initialize file reader

        Args:
            max_file_size_mb: Maximum file size to read
            max_lines: Maximum lines to read
        """
        self.cache: Dict[str, FileContent] = {}
        self.max_file_size_bytes = max_file_size_mb * 1024 * 1024
        self.max_lines = max_lines

        # Supported file extensions
        self.supported_extensions = {
            ".py": "python",
            ".sql": "sql",
            ".hql": "hive",
            ".pig": "pig",
            ".scala": "scala",
            ".java": "java",
            ".json": "json",
            ".yaml": "yaml",
            ".yml": "yaml",
            ".xml": "xml",
            ".mp": "abinitio",
            ".sh": "shell",
            ".ksh": "shell",
            ".txt": "text",
            ".md": "markdown",
        }

        logger.info(f"Initialized FileReader (max: {max_file_size_mb}MB, {max_lines} lines)")

    def read_file(
        self,
        file_path: str,
        use_cache: bool = True,
        line_range: Optional[Tuple[int, int]] = None
    ) -> Optional[FileContent]:
        """
        Read file content

        Args:
            file_path: Path to file
            use_cache: Use cached content if available
            line_range: Optional (start_line, end_line) to read

        Returns:
            FileContent or None if error
        """
        # Normalize path
        file_path = os.path.abspath(file_path)

        # Check cache
        if use_cache and file_path in self.cache:
            logger.debug(f"Using cached content for: {file_path}")
            cached = self.cache[file_path]

            # If line range requested, return subset
            if line_range:
                return self._create_range_content(cached, line_range)

            return cached

        # Check if file exists
        if not os.path.isfile(file_path):
            logger.error(f"File not found: {file_path}")
            return None

        # Check file size
        file_size = os.path.getsize(file_path)
        if file_size > self.max_file_size_bytes:
            logger.warning(f"File too large ({file_size / 1024 / 1024:.1f}MB): {file_path}")
            # Try to read anyway but with line limit
            return self._read_large_file(file_path, file_size)

        # Determine file type
        file_type = self._get_file_type(file_path)

        try:
            # Read file with encoding detection
            content, encoding = self._read_with_encoding(file_path)

            if content is None:
                return None

            # Split into lines
            lines = content.splitlines()

            # Apply line limit if needed
            if len(lines) > self.max_lines:
                logger.warning(f"File has {len(lines)} lines, truncating to {self.max_lines}")
                lines = lines[:self.max_lines]
                content = "\n".join(lines)

            # Create FileContent
            file_content = FileContent(
                file_path=file_path,
                content=content,
                lines=lines,
                file_type=file_type,
                size_bytes=file_size,
                line_count=len(lines),
                encoding=encoding
            )

            # Cache it
            self.cache[file_path] = file_content

            logger.debug(f"Read file: {file_path} ({len(lines)} lines, {file_type})")

            # If line range requested, return subset
            if line_range:
                return self._create_range_content(file_content, line_range)

            return file_content

        except Exception as e:
            logger.error(f"Error reading file {file_path}: {e}")
            return None

    def read_multiple_files(
        self,
        file_paths: List[str],
        use_cache: bool = True
    ) -> Dict[str, FileContent]:
        """
        Read multiple files

        Args:
            file_paths: List of file paths
            use_cache: Use cached content

        Returns:
            Dict of file_path -> FileContent
        """
        results = {}

        for file_path in file_paths:
            content = self.read_file(file_path, use_cache)
            if content:
                results[file_path] = content

        logger.info(f"Read {len(results)}/{len(file_paths)} files successfully")

        return results

    def _read_with_encoding(self, file_path: str) -> Tuple[Optional[str], str]:
        """
        Read file with encoding detection

        Args:
            file_path: Path to file

        Returns:
            (content, encoding) or (None, "")
        """
        # Try common encodings
        encodings = ["utf-8", "latin-1", "cp1252", "iso-8859-1"]

        for encoding in encodings:
            try:
                with open(file_path, "r", encoding=encoding) as f:
                    content = f.read()
                return content, encoding
            except (UnicodeDecodeError, LookupError):
                continue

        logger.error(f"Could not read file with any encoding: {file_path}")
        return None, ""

    def _read_large_file(self, file_path: str, file_size: int) -> Optional[FileContent]:
        """
        Read large file with line limit

        Args:
            file_path: Path to file
            file_size: File size in bytes

        Returns:
            FileContent with truncated content
        """
        try:
            lines = []
            encoding = "utf-8"

            with open(file_path, "r", encoding=encoding) as f:
                for i, line in enumerate(f):
                    if i >= self.max_lines:
                        break
                    lines.append(line.rstrip("\n"))

            content = "\n".join(lines)
            file_type = self._get_file_type(file_path)

            file_content = FileContent(
                file_path=file_path,
                content=content,
                lines=lines,
                file_type=file_type,
                size_bytes=file_size,
                line_count=len(lines),
                encoding=encoding,
                metadata={"truncated": True}
            )

            logger.info(f"Read large file (truncated to {len(lines)} lines): {file_path}")

            return file_content

        except Exception as e:
            logger.error(f"Error reading large file {file_path}: {e}")
            return None

    def _get_file_type(self, file_path: str) -> str:
        """
        Get file type from extension

        Args:
            file_path: Path to file

        Returns:
            File type
        """
        ext = Path(file_path).suffix.lower()
        return self.supported_extensions.get(ext, "unknown")

    def _create_range_content(
        self,
        full_content: FileContent,
        line_range: Tuple[int, int]
    ) -> FileContent:
        """
        Create FileContent for a line range

        Args:
            full_content: Full file content
            line_range: (start_line, end_line)

        Returns:
            FileContent with subset of lines
        """
        start, end = line_range

        # Adjust bounds
        if start < 1:
            start = 1
        if end > full_content.line_count:
            end = full_content.line_count

        # Get lines (convert to 0-indexed)
        lines = full_content.lines[start - 1:end]
        content = "\n".join(lines)

        return FileContent(
            file_path=full_content.file_path,
            content=content,
            lines=lines,
            file_type=full_content.file_type,
            size_bytes=len(content.encode("utf-8")),
            line_count=len(lines),
            encoding=full_content.encoding,
            metadata={
                "line_range": line_range,
                "full_file": False
            }
        )

    def search_in_file(
        self,
        file_path: str,
        pattern: str,
        context_lines: int = 3
    ) -> List[Dict[str, Any]]:
        """
        Search for pattern in file and return matches with context

        Args:
            file_path: Path to file
            pattern: Search pattern
            context_lines: Lines of context around match

        Returns:
            List of match dicts with context
        """
        content = self.read_file(file_path)
        if not content:
            return []

        # Search lines
        matches = content.search_lines(pattern)

        # Add context
        results = []
        for line_num, line in matches:
            # Get context
            start = max(1, line_num - context_lines)
            end = min(content.line_count, line_num + context_lines)

            context = content.get_lines_range(start, end)

            results.append({
                "file_path": file_path,
                "line_number": line_num,
                "line_content": line,
                "context": context,
                "pattern": pattern
            })

        return results

    def clear_cache(self) -> None:
        """Clear file cache"""
        self.cache.clear()
        logger.info("Cleared file cache")

    def get_cache_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        total_files = len(self.cache)
        total_lines = sum(fc.line_count for fc in self.cache.values())
        total_bytes = sum(fc.size_bytes for fc in self.cache.values())

        return {
            "cached_files": total_files,
            "total_lines": total_lines,
            "total_bytes": total_bytes,
            "total_mb": total_bytes / 1024 / 1024
        }
