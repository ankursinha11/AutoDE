# VM_FAWN Quick Start Guide

## 🎯 What is VM_FAWN Integration?

VM_FAWN extracts **detailed transformation logic** from Ab Initio .mp files, enabling STAG to answer questions about:
- ✅ Transformation rules and business logic
- ✅ DML (Data Manipulation Language) definitions
- ✅ Component keys and partitioning
- ✅ File layouts and dataset paths

**Before**: GraphFlow had structure but empty data (0/1295 vertices with DML)
**After**: GraphFlow has actual data (36/36 vertices with Layout, proper DML extraction)

---

## 🚀 Quick Start (3 Steps)

### 1. Run VM_FAWN Parser (Manual)

```bash
# Run VM_FAWN on your .mp file
# Output saved to: Input Files/VM_FAWN/bbi_preprocessing_output/
```

**Expected output**: `{filename}_YYYY_MM_DD_HH_MM_SS.xlsx`

Example: `265_fileTransferToHadoopServer_2025_11_20_14_18_33.xlsx`

### 2. Index with STAG (Automatic)

1. Open STAG UI
2. Go to **Indexing & Management** → **Ab Initio Graphs**
3. Upload your .mp file
4. Check options: ✅ Generate GraphFlow
5. Click **Index Graph**

**Look for**: `"📊 Found VM_FAWN Excel - Using detailed transformation extraction"`

### 3. Verify Output

Check GraphFlow Excel has data:

```bash
# Check output file
ls outputs/graphflows/{filename}_graphflow.xlsx

# Verify data columns are populated
python3 -c "
import pandas as pd
df = pd.read_excel('outputs/graphflows/{filename}_graphflow.xlsx', sheet_name='Vertices')
print(f'Vertices with data: {df[\"Layout\"].notna().sum()} / {len(df)}')
"
```

**Expected**: Most vertices have Layout, Type populated ✅

---

## 📁 File Locations

| What | Where |
|------|-------|
| VM_FAWN Parser | `Input Files/VM_FAWN/` |
| VM_FAWN Output | `Input Files/VM_FAWN/bbi_preprocessing_output/*.xlsx` |
| Source .mp files | `Input Files/blade/mp/*.mp` |
| Converter | `parsers/abinitio/vm_fawn_excel_converter.py` |
| Enhanced JSON | `outputs/parsed_abinitio/*_components.json` |
| GraphFlow Excel | `outputs/graphflows/*_graphflow.xlsx` |

---

## 🔍 How It Works

```mermaid
graph LR
    A[.mp file] -->|VM_FAWN manual| B[Excel with 4 sheets]
    B -->|STAG auto-detects| C[VMFAWNExcelConverter]
    C --> D[Enhanced JSON with attributes]
    D --> E[GraphFlow Excel with data]
    D --> F[Vector DB indexing]
    E --> G[Answer detailed questions]
    F --> G
```

**4 Excel Sheets from VM_FAWN**:
1. **DataSet** - File info, DML definitions
2. **Component&Fields** - Transformation rules, keys, component details
3. **GraphParameters** - Graph-level parameters
4. **GraphFlow** - Data flow connections (often empty, generated separately)

---

## ⚙️ CLI Usage (Testing)

### Test Converter Directly

```bash
python3 parsers/abinitio/vm_fawn_excel_converter.py \
  "Input Files/VM_FAWN/bbi_preprocessing_output/265_fileTransferToHadoopServer_2025_11_20_14_18_33.xlsx" \
  "Input Files/blade/mp/265_fileTransferToHadoopServer.mp" \
  "outputs/test/265_components.json"
```

**Output**:
```
🔄 Converting VM_FAWN Excel to Enhanced JSON
   Vertices: 36 (Transforms: 35, Datasets: 1)
   Flows: 0
   ✅ Saved to: outputs/test/265_components.json
```

---

## 🛠️ Troubleshooting

### ❌ "No VM_FAWN Excel found"

**Problem**: STAG can't find VM_FAWN output for your .mp file

**Solution**:
1. Verify VM_FAWN ran successfully
2. Check file exists: `ls "Input Files/VM_FAWN/bbi_preprocessing_output/"`
3. Verify naming: `{mp_basename}_*.xlsx`

**Fallback**: STAG uses basic parser (structure only, no transformation details)

### ❌ GraphFlow has empty data columns

**Problem**: VM_FAWN Excel not being used

**Check STAG UI message**:
- ✅ Good: "Found VM_FAWN Excel - Using detailed transformation extraction"
- ❌ Bad: "No VM_FAWN Excel found - Using Enhanced Parser (basic extraction)"

**Solution**: Ensure VM_FAWN Excel exists with correct naming

### ❌ Converter fails with FileNotFoundError

**Problem**: Path issues

**Verify**:
```bash
# Check files exist
ls "Input Files/VM_FAWN/bbi_preprocessing_output/265_*.xlsx"
ls "Input Files/blade/mp/265_*.mp"

# Check working directory (should be repo root)
pwd
# Should show: /Users/ankurshome/Desktop/Hadoop_Parser
```

---

## 📊 What Gets Extracted?

### From Component&Fields Sheet:
- `transform_component` - Component type (Reformat, Join, Sort, etc.)
- `transform_rule` - Full transformation logic
- `trans_location` - File layout/path
- `keys` - Partitioning/sorting keys
- `dml` - Extracted from transform_rule
- `subgraph_hierarchy` - Nested graph structure

### From DataSet Sheet:
- `dataset_names` - Dataset file paths
- `dml` - DML definitions
- `key_parameter` - Key parameters
- `component_type` - Input File/Output File/etc.

### From GraphParameters Sheet:
- Graph-level parameters (name, value pairs)

---

## 🎓 Examples

### Query Before VM_FAWN:
**User**: "What transformations happen in the Reformat component?"
**STAG**: "I found a Reformat component but don't have details on its transformation logic."

### Query After VM_FAWN:
**User**: "What transformations happen in the Reformat component?"
**STAG**: "The Reformat component performs the following transformations:
- Transform Rule: `let string input_field = ...; output_field = transform(input_field);`
- DML: `InputDML`
- Keys: `customer_id, transaction_date`
- Layout: `/data/input/customer_transactions.dat`"

---

## 📈 Performance

| Graph Size | Conversion Time | JSON Size | GraphFlow Time |
|------------|----------------|-----------|----------------|
| Small (35 components) | ~1 second | 100 KB | Instant |
| Medium (200 components) | ~3 seconds | 300 KB | Instant |
| Large (1000+ components) | ~10 seconds | 500 KB | Instant |

**Note**: STTM generation may hit rate limits on large graphs (use cautiously)

---

## ✅ Validation Checklist

After indexing with VM_FAWN, verify:

- [ ] STAG showed "Found VM_FAWN Excel" message
- [ ] GraphFlow Excel generated successfully
- [ ] Vertices sheet has Layout values (most rows)
- [ ] Vertices sheet has Type values (all rows)
- [ ] Vertices sheet has some DML values (not all rows will have DML)
- [ ] Enhanced JSON has `attributes` field in vertices
- [ ] Enhanced JSON has `transform_rule` in attributes
- [ ] Can query STAG about transformation details

---

## 🔗 Resources

- **Full Documentation**: [VM_FAWN_INTEGRATION_GUIDE.md](VM_FAWN_INTEGRATION_GUIDE.md)
- **Converter Code**: [vm_fawn_excel_converter.py](vm_fawn_excel_converter.py)
- **STAG Integration**: [stag_app.py:2454](../../stag_app.py#L2454)
- **GraphFlow Generator**: [graph_flow/excel_generator.py](graph_flow/excel_generator.py)

---

## 💡 Pro Tips

1. **Batch Processing**: Run VM_FAWN on all .mp files first, then index with STAG
2. **Large Graphs**: Uncheck "Generate STTM" to avoid rate limits
3. **Re-indexing**: Old graphs need re-indexing to get VM_FAWN benefits
4. **Verification**: Always check GraphFlow Excel has actual data, not just structure
5. **Fallback**: If VM_FAWN fails, STAG automatically falls back to basic parser

---

## 📞 Support

Issues? Check:
1. ✅ VM_FAWN Excel exists in correct folder
2. ✅ File naming matches pattern: `{mp_basename}_*.xlsx`
3. ✅ STAG shows "Found VM_FAWN Excel" message
4. ✅ GraphFlow has data in Layout/Type/DML columns
5. ✅ Working directory is repository root

Still stuck? Check full guide: [VM_FAWN_INTEGRATION_GUIDE.md](VM_FAWN_INTEGRATION_GUIDE.md)
