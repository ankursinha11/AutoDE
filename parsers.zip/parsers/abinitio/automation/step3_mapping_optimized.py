"""
Step 3: Generate Source-to-Target Attribute Mapping for AbInitio Graph (HYBRID OPTIMIZED)

This script:
1. Loads detailed_graph_1_with_files.json
2. Processes subgraphs HIERARCHICALLY (deepest first) using GPT-5 LLM
3. For each subgraph: Extract detailed functional logic (inputs, transformations, outputs)
4. Saves subgraph logic to subgraph_logic_optimized.json
5. Processes main graph (ID 1) with HYBRID OPTIMIZATION:
   - Phase 0: DML Reduction (LLM identifies required sections, extract only those)
   - Phase 2.5: Identify all outputs dynamically (LLM-driven)
   - Phase 3: Process EACH output separately (one LLM call per output)
6. Generates attribute-level mapping with datatypes and detailed transformation logic
7. Outputs professional Excel file with multiple tabs (one per output)

KEY OPTIMIZATIONS:
- Input reduction: Only pass required DML sections (40-70% size reduction)
- Output splitting: Process one output at a time (scalable for any number of outputs)
- No hardcoding: All processing is dynamic based on graph structure
"""

import json
import sys
import time
from openai import AzureOpenAI
from pathlib import Path
from typing import Dict, List, Any, Optional
import re
from collections import defaultdict
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# Azure OpenAI Configuration
AZURE_ENDPOINT = "https://modelcodex.cognitiveservices.azure.com/"
MODEL_NAME = "gpt-5"
DEPLOYMENT = "gpt-5"
SUBSCRIPTION_KEY = "E1YX4tsaRg9dYYToH05rUCi3EiikWM4irps35RUGxzZsKKTnMiSyJQQJ99BKACHYHv6XJ3w3AAABACOGXJQu"
API_VERSION = "2024-12-01-preview"
LLM_MAX_TOKENS = 16000


class GPTLLM:
    """Wrapper for GPT-5 LLM via Azure OpenAI"""

    def __init__(self):
        """Initialize Azure OpenAI client"""
        print("🔧 Initializing GPT-5 LLM...")
        self.client = AzureOpenAI(
            api_version=API_VERSION,
            azure_endpoint=AZURE_ENDPOINT,
            api_key=SUBSCRIPTION_KEY,
        )
        self.deployment = DEPLOYMENT
        print(f"✅ GPT-5 LLM initialized (Model: {MODEL_NAME})\n")

    def invoke(self, prompt: str, max_tokens: int = 16000, retry_count: int = 3) -> str:
        """
        Invoke GPT-5 model with a prompt (with retry logic)

        Args:
            prompt: The prompt to send to GPT-5
            max_tokens: Maximum tokens in response (default: 16000)
            retry_count: Number of retries on failure

        Returns:
            Response text from GPT-5
        """
        for attempt in range(retry_count):
            try:
                response = self.client.chat.completions.create(
                    messages=[
                        {
                            "role": "system",
                            "content": "You are an AbInitio ETL expert."
                        },
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ],
                    max_completion_tokens=max_tokens,
                    model=self.deployment
                )

                return response.choices[0].message.content

            except Exception as e:
                print(f"   ⚠️  Attempt {attempt + 1}/{retry_count} failed: {str(e)}")
                if attempt == retry_count - 1:
                    print(f"   ❌ All retry attempts exhausted")
                    raise

        return ""


class STAGLLMWrapper:
    """Wrapper to make STAG's AI analyzer compatible with GPTLLM interface"""

    def __init__(self, ai_analyzer):
        """
        Initialize wrapper with STAG's AI analyzer

        Args:
            ai_analyzer: STAG's AIScriptAnalyzer instance
        """
        self.ai_analyzer = ai_analyzer
        print("🔧 Using STAG's AI analyzer for STTM generation...")
        print(f"✅ AI analyzer initialized\n")

    def invoke(self, prompt: str, max_tokens: int = 16000, retry_count: int = 3) -> str:
        """
        Invoke STAG's AI analyzer with a prompt

        Args:
            prompt: The prompt to send
            max_tokens: Maximum tokens in response (may not be used by all analyzers)
            retry_count: Number of retries on failure

        Returns:
            Response text
        """
        if not self.ai_analyzer or not self.ai_analyzer.enabled:
            return "AI analysis not available"

        for attempt in range(retry_count):
            try:
                # Use STAG's analyze_with_context method
                result = self.ai_analyzer.analyze_with_context(
                    query=prompt,
                    context=""
                )

                # Extract response from result
                if isinstance(result, dict):
                    return result.get('analysis', result.get('response', ''))
                else:
                    return str(result)

            except Exception as e:
                print(f"   ⚠️  Attempt {attempt + 1}/{retry_count} failed: {str(e)}")
                if attempt == retry_count - 1:
                    print(f"   ❌ All retry attempts exhausted")
                    raise

        return ""


class MappingGenerator:
    """Generates source-to-target attribute mapping for AbInitio graphs (OPTIMIZED)"""

    def __init__(self, detailed_graph_path: str, output_folder: Path = None, base_filename: str = None, ai_analyzer=None):
        """
        Initialize mapping generator

        Args:
            detailed_graph_path: Path to detailed_graph_1_with_files.json
            output_folder: Folder to save all outputs
            base_filename: Base filename for output files
            ai_analyzer: Optional STAG AI analyzer (if None, creates own GPTLLM)
        """
        self.detailed_graph_path = Path(detailed_graph_path)
        self.output_folder = output_folder if output_folder else Path(".")
        self.base_filename = base_filename if base_filename else "output"

        # Use STAG's AI analyzer if provided, otherwise create own LLM
        if ai_analyzer:
            self.llm = STAGLLMWrapper(ai_analyzer)
        else:
            self.llm = GPTLLM()

        self.graph_data = None
        self.main_graph_id = "1"  # Always process graph ID 1 as main
        self.processed_subgraphs = {}  # Store COMPACT subgraph logic: {graph_id: logic}
        self.dependency_tree = None
        self.processing_order = []  # List of (graph_id, level) tuples

    def load_graph_data(self):
        """Load detailed_graph_1_with_files.json"""
        print(f"📖 Loading graph data from: {self.detailed_graph_path}")

        if not self.detailed_graph_path.exists():
            raise FileNotFoundError(f"File not found: {self.detailed_graph_path}")

        with open(self.detailed_graph_path, 'r', encoding='utf-8') as f:
            self.graph_data = json.load(f)

        print(f"✅ Loaded successfully!\n")

    def build_dependency_tree(self, graph: Dict) -> Dict:
        """
        Build dependency tree (graph_id and name only)

        Args:
            graph: Graph dictionary

        Returns:
            Simplified dependency tree
        """
        tree = {
            "graph_id": graph.get("graph_id"),
            "name": graph.get("name"),
            "level": graph.get("level"),
            "dependencies": []
        }

        for dep in graph.get("dependencies", []):
            tree["dependencies"].append(self.build_dependency_tree(dep))

        return tree

    def get_processing_order(self, graph: Dict, order_list: List):
        """
        Build processing order (deepest first, excluding main graph)

        Args:
            graph: Graph dictionary
            order_list: List to append (graph_id, name, level) tuples
        """
        # First process all dependencies (deepest first)
        for dep in graph.get("dependencies", []):
            self.get_processing_order(dep, order_list)

        # Add current graph (but NOT the main graph)
        if graph.get("graph_id") != self.main_graph_id:
            order_list.append({
                "graph_id": graph.get("graph_id"),
                "name": graph.get("name"),
                "level": graph.get("level")
            })

    def extract_subgraph_data(self, graph_id: str, full_graph: Dict) -> Optional[Dict]:
        """
        Extract subgraph data by graph_id from full hierarchy

        Args:
            graph_id: Graph ID to find
            full_graph: Full graph hierarchy

        Returns:
            Subgraph data or None
        """
        if full_graph.get("graph_id") == graph_id:
            return full_graph

        for dep in full_graph.get("dependencies", []):
            result = self.extract_subgraph_data(graph_id, dep)
            if result:
                return result

        return None

    def process_subgraph(self, graph_id: str, name: str, level: int) -> Dict:
        """
        Process a single subgraph using GPT-5 LLM (COMPACT OUTPUT)

        Args:
            graph_id: Subgraph ID
            name: Subgraph name
            level: Subgraph level

        Returns:
            Compact subgraph logic dictionary with attribute mappings
        """
        print(f"\n{'='*80}")
        print(f"🔄 Processing Subgraph {graph_id}: {name} (Level {level})")
        print(f"{'='*80}")

        # Extract subgraph data
        subgraph_data = self.extract_subgraph_data(graph_id, self.graph_data['graph'])

        if not subgraph_data:
            print(f"   ❌ Subgraph {graph_id} not found in hierarchy")
            return {}

        # Prepare data package for LLM
        data_package = {
            "graph_id": subgraph_data.get("graph_id"),
            "name": subgraph_data.get("name"),
            "level": subgraph_data.get("level"),
            "raw_content": subgraph_data.get("raw_content"),
            "vertices": subgraph_data.get("vertices", {}),
            "referenced_files": subgraph_data.get("referenced_files", {}),
            "statistics": subgraph_data.get("statistics", {}),
            "subgraph_references": subgraph_data.get("subgraph_references", [])
        }

        # Get child subgraph logic (COMPACT - attribute mappings only)
        child_logic = {}
        for subgraph_ref in data_package["subgraph_references"]:
            if subgraph_ref in self.processed_subgraphs:
                child_logic[subgraph_ref] = self.processed_subgraphs[subgraph_ref]

        # Create LLM prompt (requesting COMPACT output)
        prompt = self._create_subgraph_prompt(data_package, child_logic)

        # Call LLM
        print(f"   🤖 Calling GPT-5 LLM to analyze subgraph...")
        response = self.llm.invoke(prompt)
        

        # Parse JSON response
        response_debug_file = self.output_folder / f"subgraph_{graph_id}_response.txt"
        logic = self._parse_json_response(response, save_debug=True, debug_filename=str(response_debug_file))

        if logic:
            print(f"   ✅ Successfully analyzed subgraph {graph_id}")
            # Validate required fields
            if "detailed_logic" in logic:
                print(f"   📊 Extracted detailed functional logic")
        else:
            print(f"   ⚠️  Failed to parse LLM response for subgraph {graph_id}")
            logic = {
                "graph_id": graph_id,
                "name": name,
                "level": level,
                "error": "Failed to parse LLM response",
                "detailed_logic": {}
            }

        return logic

    def _create_subgraph_prompt(self, data_package: Dict, child_logic: Dict) -> str:
        """
        Create LLM prompt for subgraph analysis (FUNCTIONAL LOGIC extraction)

        Args:
            data_package: Subgraph data
            child_logic: Already-processed child subgraph logic

        Returns:
            Prompt string
        """
        prompt = f"""You are an AbInitio ETL expert with deep knowledge of graph processing, DML, XFR, and component types.

**TASK:** Analyze this AbInitio subgraph and extract its DETAILED FUNCTIONAL LOGIC.

**INPUT DATA:**
```json
{json.dumps(data_package, indent=2)}
```

**CHILD SUBGRAPH LOGIC (if applicable):**
```json
{json.dumps(child_logic, indent=2) if child_logic else "No child subgraphs"}
```

**INSTRUCTIONS:**
Provide a DETAILED explanation of what this subgraph does. Focus on:

1. **FUNCTIONALITY:** What is the purpose of this subgraph? What business logic does it implement?

2. **INPUTS:** What data does it expect as input?
   - Describe the input structure
   - Key fields/attributes expected
   - Data sources (if identifiable)

3. **TRANSFORMATIONS:** What processing/transformations does it perform? Be VERY DETAILED:
   - Parse raw_content to extract transform logic (transform0, transform1, etc.)
   - Explain lookups: which lookup tables, what keys, what data retrieved
   - Explain filters: what conditions, what records excluded/included
   - Explain reformats: how data is reshaped, calculated fields, derivations
   - Explain joins: what datasets joined, on what keys
   - Include actual DML code snippets where relevant
   - If child subgraphs exist, explain how their logic is used

4. **OUTPUTS:** What data does it produce?
   - Describe the output structure
   - Key fields/attributes produced
   - How inputs are transformed into outputs

**OUTPUT FORMAT (JSON only, no markdown):**
{{
  "graph_id": "{data_package['graph_id']}",
  "name": "{data_package['name']}",
  "level": {data_package['level']},
  "functional_summary": "Brief 1-2 sentence summary",
  "detailed_logic": {{
    "functionality": "Detailed explanation of what this subgraph does and why",
    "inputs": "Detailed description of expected inputs, their structure, and key attributes",
    "transformations": "DETAILED explanation of all transformations, lookups, filters, reformats, calculations. Include DML code snippets. Explain step-by-step what happens to the data.",
    "outputs": "Detailed description of outputs produced, their structure, and key attributes"
  }}
}}

**IMPORTANT:**
- Return ONLY valid JSON (no markdown, no code blocks, no extra text)
- Be VERY DETAILED in the transformations section - include actual DML code
- Focus on functional logic, not attribute-level mappings
- Explain what happens to the data as it flows through the subgraph
"""

        return prompt

    def optimize_referenced_files(self, data_package: Dict, subgraph_context: Dict) -> Dict:
        """
        Phase 0: Analyze graph logic deeply and extract ONLY required DML content for attribute mapping

        Args:
            data_package: Main graph data with full referenced_files
            subgraph_context: Processed subgraph functional logic

        Returns:
            Optimized referenced_files with only required complete type definitions
        """
        print(f"\n{'='*80}")
        print(f"📦 PHASE 0: CONTEXT-AWARE DML OPTIMIZATION")
        print(f"{'='*80}")

        # If no referenced files, return empty
        if not data_package.get("referenced_files"):
            print(f"   ℹ️  No referenced files to optimize")
            return {}

        print(f"   📊 Original referenced files: {len(data_package['referenced_files'])} files")

        # Calculate original size
        original_size = sum(len(str(content)) for content in data_package['referenced_files'].values())
        print(f"   📏 Original DML content size: {original_size:,} characters")

        # Create prompt to deeply analyze what's needed for mapping
        prompt = f"""You are an AbInitio ETL expert. Analyze Graph 1 and its subgraphs to identify which DML type definitions are ACTUALLY NEEDED for attribute mapping.

**GRAPH 1 DATA:**
```json
{json.dumps(data_package, indent=2)}
```

**SUBGRAPH LOGIC (already processed):**
```json
{json.dumps(subgraph_context, indent=2)}
```

**YOUR TASK AS AN ABINITIO EXPERT:**
Deeply analyze the data flow to identify which type definitions are needed for complete attribute mapping.

1. **Analyze Graph 1 Vertices:**
   - Look at EACH vertex's raw_content
   - Identify input/output metadata (read_metadata, out_metadata, in_metadata, etc.)
   - Identify transforms (transform0, transform1, etc.) and what types they reference
   - Identify lookups and what types they use
   - Identify filters and select_expr logic

2. **Understand Subgraph Usage:**
   - Review subgraph functional logic provided above
   - Understand what transformations subgraphs perform
   - Identify what types/fields subgraphs expect as input
   - Identify what types/fields subgraphs produce as output

3. **Trace Data Flow for Mapping:**
   - For attribute mapping, we need ALL type definitions that appear in:
     * Source file metadata (input components)
     * Intermediate transformation metadata
     * Subgraph input/output structures
     * Target file metadata (output components)
   - Include types that define record structures used in transforms
   - Include nested types (if typeA uses typeB, include both)

4. **Identify Required Types:**
   - Extract the TYPE NAMES (not field names, but type definition names)
   - For example: "uTypePatientAccts", "typeEdiGenSettings", "typeLkpFoundCoverage"
   - Include ALL types needed to understand complete attribute lineage

**OUTPUT FORMAT (JSON only, no markdown):**
{{
  "required_sections": {{
    "ediComGenUserDefinedTypes.dml": [
      {{
        "type_name": "uTypePatientAccts",
        "required_fields": [
          "decimal(\\"\\\\x01\\") hospitalfk",
          "decimal(\\"\\\\x01\\") patientacctipk",
          "string(\\"\\\\x01\\", charset=\\"windows-1252\\", maximum_length=38) patientacctpk",
          "string(\\"\\\\x01\\", charset=\\"windows-1252\\", maximum_length=50) firstname"
        ]
      }},
      {{
        "type_name": "typeEdiGenSettings",
        "required_fields": [
          "decimal(1) familyClusteringEnabledFlag = NULL",
          "decimal(1) isCobHospital = NULL"
        ]
      }}
    ]
  }}
}}

**CRITICAL INSTRUCTIONS:**
1. Analyze graph flow to identify which DML types and fields are ACTUALLY USED
2. Return array of objects with "type_name" and "required_fields"
3. List required fields WITH COMPLETE DATATYPE DEFINITIONS
4. Field format: "datatype(params) fieldname" or "datatype(params) fieldname = default"
   Examples:
   - "decimal(\\"\\\\x01\\") hospitalfk"
   - "string(\\"\\\\x01\\", charset=\\"windows-1252\\", maximum_length=50) firstname = NULL(\\"\\")"
   - "datetime(\\"YYYY-MM-DD HH24:MI:SS.NNNNNN\\")(\\"\\\\x01\\") admitdate"
5. Include ONLY fields referenced in transforms/lookups/filters/metadata
6. Be COMPREHENSIVE - trace all vertices + subgraph logic for complete field coverage
7. Return ONLY .dml files in required_sections
8. DO NOT add "analysis_summary" or any extra fields - ONLY "required_sections"
"""

        print(f"   🤖 Asking LLM to identify required DML sections...")
        response = self.llm.invoke(prompt, max_tokens=16000)

        # Parse response
        required_sections = self._parse_json_response(response, save_debug=True, debug_filename=str(self.output_folder / "dml_optimization_response.txt"))

        if not required_sections or "required_sections" not in required_sections:
            print(f"   ⚠️  Failed to identify required sections, using full DML content")
            return data_package.get("referenced_files", {})

        # Build optimized_files: reduced .dml from LLM + full .xfr from original
        optimized_files = {}

        # Add reduced .dml files from LLM response
        for filename, type_list in required_sections["required_sections"].items():
            if filename in data_package["referenced_files"]:
                optimized_files[filename] = type_list
                original_lines = len(data_package["referenced_files"][filename].split('\n'))
                total_fields = sum(len(t.get("required_fields", [])) for t in type_list if isinstance(t, dict))
                print(f"   ✂️  {filename}: {len(type_list)} types, {total_fields} fields (JSON format)")

        # Add any .xfr files from original data_package as-is (full content, not reduced)
        for filename, content in data_package["referenced_files"].items():
            if filename.endswith('.xfr'):
                optimized_files[filename] = content
                original_lines = len(content.split('\n'))
                print(f"   ✅ {filename}: Using full content ({original_lines} lines, XFR not reduced)")

        # Calculate optimized size
        optimized_size = sum(len(str(content)) for content in optimized_files.values())
        reduction_pct = ((original_size - optimized_size) / original_size * 100) if original_size > 0 else 0

        print(f"   📏 Optimized DML content size: {optimized_size:,} characters")
        print(f"   ✅ Reduction: {reduction_pct:.1f}% ({original_size - optimized_size:,} chars saved)")

        return optimized_files

    def _build_reduced_dml(self, full_content: str, type_list: List) -> str:
        """
        Build reduced DML from type definitions with complete field datatypes

        Args:
            full_content: Full DML content
            type_list: List of dicts with type_name and required_fields (with datatypes)
                      Example: [{"type_name": "uTypePatientAccts",
                                 "required_fields": ["decimal(\"\\x01\") hospitalfk", ...]}]

        Returns:
            Reduced DML content with only required types and fields
        """
        lines = full_content.split('\n')
        reduced_blocks = []

        # Extract include statements from full content
        include_lines = []
        for line in lines:
            if line.strip().startswith('include '):
                include_lines.append(line)

        if include_lines:
            reduced_blocks.append('\n'.join(include_lines))

        # Build each type definition from LLM response
        for type_info in type_list:
            if not isinstance(type_info, dict):
                continue

            type_name = type_info.get("type_name", "")
            required_fields = type_info.get("required_fields", [])

            if not type_name or not required_fields:
                continue

            # Construct the type definition
            type_block = []
            type_block.append(f"type {type_name} =")
            type_block.append("record")

            # Add each field (already includes datatype from LLM)
            for field_def in required_fields:
                type_block.append(f"  {field_def};")

            type_block.append("end;")

            reduced_blocks.append('\n'.join(type_block))

        # Combine all blocks
        reduced_content = '\n\n'.join(reduced_blocks)

        return reduced_content

    def _extract_dml_sections(self, full_content: str, section_list: List) -> str:
        """
        Extract specific type definitions with FIELD-LEVEL filtering from DML/XFR content

        Args:
            full_content: Full DML/XFR content
            section_list: List of dicts with type_name and required_fields
                         Example: [{"type_name": "uTypePatientAccts", "required_fields": ["hospitalfk", "firstname"]}, ...]

        Returns:
            Extracted content with ONLY specified types and ONLY specified fields within each type
        """
        if not section_list:
            return full_content

        # DML Parser: Extract type definitions with field-level filtering
        lines = full_content.split('\n')
        extracted_blocks = []

        # First, extract include statements (needed for DML compilation)
        include_lines = []
        for line in lines:
            if line.strip().startswith('include '):
                include_lines.append(line)

        if include_lines:
            extracted_blocks.append('\n'.join(include_lines))

        # Build lookup map: type_name → required_fields
        type_field_map = {}
        for section in section_list:
            if isinstance(section, dict):
                type_name = section.get("type_name", "")
                required_fields = section.get("required_fields", [])
                type_field_map[type_name] = required_fields
            elif isinstance(section, str):
                # Fallback: if old format (just type names), extract entire type
                type_field_map[section] = []

        # Now extract each required type definition with field filtering
        i = 0
        while i < len(lines):
            line = lines[i].strip()

            # Check if this line starts a type definition
            if line.startswith('type ') and '=' in line:
                # Extract type name (e.g., "type uTypePatientAccts =" → "uTypePatientAccts")
                type_name = line.split('type ')[1].split('=')[0].strip()

                # Check if this type is in our required list
                matching_type = None
                for req_type in type_field_map.keys():
                    if req_type in type_name:
                        matching_type = req_type
                        break

                if matching_type:
                    required_fields = type_field_map[matching_type]

                    # Extract type with field-level filtering
                    type_block = [lines[i]]  # Start with "type ... ="
                    i += 1

                    # Check next line for "record"
                    if i < len(lines) and lines[i].strip() == 'record':
                        type_block.append(lines[i])
                        i += 1

                        # If no specific fields required, extract all fields
                        if not required_fields:
                            # Extract entire type definition
                            while i < len(lines):
                                type_block.append(lines[i])
                                if lines[i].strip().startswith('end;'):
                                    break
                                i += 1
                        else:
                            # Field-level filtering: extract only required fields
                            while i < len(lines):
                                current_line = lines[i].strip()

                                # Check if we've reached the end of the type
                                if current_line.startswith('end;'):
                                    type_block.append(lines[i])
                                    break

                                # Check if this line defines a field
                                # DML field format: decimal(...) fieldname; or string(...) fieldname;
                                is_field_line = False
                                field_name = None

                                # Parse field name from line
                                if ';' in current_line:
                                    # Extract field name (last identifier before semicolon)
                                    parts = current_line.replace(';', '').split()
                                    if len(parts) > 0:
                                        field_name = parts[-1]
                                        is_field_line = True

                                # Include this field if it's in required_fields
                                if is_field_line and field_name:
                                    if any(req_field in field_name for req_field in required_fields):
                                        type_block.append(lines[i])
                                else:
                                    # Not a field line (comment, blank line, etc.) - skip
                                    pass

                                i += 1
                    else:
                        # Not a record type, extract as-is
                        while i < len(lines):
                            type_block.append(lines[i])
                            if lines[i].strip().startswith('end;'):
                                break
                            i += 1

                    extracted_blocks.append('\n'.join(type_block))
                else:
                    i += 1
            else:
                i += 1

        # Combine all extracted blocks
        extracted_content = '\n\n'.join(extracted_blocks)

        # Safety check
        if len(extracted_content.strip()) < 50:
            print(f"   ⚠️  Warning: Extracted content is very small ({len(extracted_content)} chars)")

        print(f"   ✂️  DML reduction: {len(full_content)} → {len(extracted_content)} chars ({100 - (len(extracted_content)/len(full_content)*100):.1f}% reduction)")

        return extracted_content

    def identify_outputs(self, optimized_data_package: Dict, subgraph_context: Dict) -> List[Dict]:
        """
        Phase 2.5: Ask LLM to identify all output components in Graph 1

        Args:
            optimized_data_package: Graph data with optimized DML
            subgraph_context: Subgraph logic

        Returns:
            List of output components: [{output_name, output_id, output_dataset}, ...]
        """
        print(f"\n{'='*80}")
        print(f"🔍 PHASE 2.5: IDENTIFY OUTPUT COMPONENTS")
        print(f"{'='*80}")

        # Create prompt to identify outputs
        prompt = f"""You are an AbInitio ETL expert. Analyze this graph hierarchy and identify ALL OUTPUT components.

**MAIN GRAPH DATA:**
```json
{json.dumps(optimized_data_package, indent=2)}
```

**SUBGRAPH CONTEXT:**
```json
{json.dumps(subgraph_context, indent=2)}
```

**TASK:**
Identify ALL output file components in this graph. Look for:
- Vertices with type "XXGfvertex"
- Vertices with file_type "Output_File"
- Components that write final output datasets

For each output, extract:
- output_name: The vertex_name
- output_component_id: The vertex ID
- output_dataset: The file path/dataset name (from file_name or Layout field in raw_content)

**OUTPUT FORMAT (JSON only, no markdown):**
{{
  "total_outputs": <number>,
  "outputs": [
    {{
      "output_name": "component name",
      "output_component_id": "vertex_id",
      "output_dataset": "file path or dataset name"
    }}
  ]
}}

Return ALL outputs found in the graph."""

        print(f"   🤖 Asking LLM to identify all outputs...")
        response = self.llm.invoke(prompt, max_tokens=16000)

        # Parse response
        outputs_data = self._parse_json_response(response, save_debug=True, debug_filename=str(self.output_folder / "identify_outputs_response.txt"))

        if not outputs_data or "outputs" not in outputs_data:
            print(f"   ⚠️  Failed to identify outputs from LLM response")
            return []

        outputs_list = outputs_data.get("outputs", [])
        total_outputs = outputs_data.get("total_outputs", len(outputs_list))

        print(f"   ✅ Identified {total_outputs} output(s):")
        for idx, output in enumerate(outputs_list, 1):
            print(f"      {idx}. {output.get('output_name')} (ID: {output.get('output_component_id')})")

        return outputs_list

    def generate_graph_summary(self, optimized_data_package: Dict, subgraph_context: Dict, outputs_list: List[Dict]) -> Dict:
        """
        Generate executive summary of what Main Graph does and its business value

        Args:
            optimized_data_package: Graph data with optimized DML
            subgraph_context: Subgraph logic
            outputs_list: List of identified outputs

        Returns:
            Summary dictionary with graph_name, summary, inputs, outputs
        """
        print(f"\n{'='*80}")
        print(f"📋 PHASE 2.7: GENERATE MAIN GRAPH SUMMARY")
        print(f"{'='*80}")

        # Create prompt for summary generation
        prompt = f"""You are an AbInitio ETL expert. Analyze Main Graph 1 and provide a business-focused summary.

**MAIN GRAPH DATA:**
```json
{json.dumps(optimized_data_package, indent=2)}
```

**SUBGRAPH LOGIC:**
```json
{json.dumps(subgraph_context, indent=2)}
```

**IDENTIFIED OUTPUTS:**
```json
{json.dumps(outputs_list, indent=2)}
```

**TASK:**
Provide a concise business summary of what this graph does and its business value.

1. **Summary**: Explain in 2-4 sentences what this graph does and its business value
   - Focus on business purpose, not technical details
   - Explain the value it delivers

2. **Inputs**: List all input files/datasets (look for vertices with file_type "Input_File")
   - Provide file paths and brief description

3. **Outputs**: List all output files/datasets (from outputs_list provided)
   - Provide file paths and brief description

**OUTPUT FORMAT (JSON only, no markdown):**
{{
  "graph_name": "{optimized_data_package.get('name', 'Unknown')}",
  "summary": "2-4 sentence business summary of what this graph does and its business value",
  "inputs": [
    {{
      "input_name": "component name",
      "input_dataset": "file path",
      "description": "brief description"
    }}
  ],
  "outputs": [
    {{
      "output_name": "component name",
      "output_dataset": "file path",
      "description": "brief description"
    }}
  ]
}}

**IMPORTANT:**
- Focus on BUSINESS VALUE in the summary
- Keep it concise and non-technical
- Return ONLY the JSON above, nothing else"""

        print(f"   🤖 Calling GPT-5 LLM to generate graph summary...")
        response = self.llm.invoke(prompt, max_tokens=3000)

        # Parse response
        summary = self._parse_json_response(response, save_debug=True, debug_filename=str(self.output_folder / "graph_summary_response.txt"))

        if summary:
            print(f"   ✅ Graph summary generated successfully")
            return summary
        else:
            print(f"   ⚠️  Failed to generate summary, using default")
            return {
                "graph_name": optimized_data_package.get('name', 'Unknown'),
                "summary": "Graph summary unavailable",
                "inputs": [],
                "outputs": []
            }

    def process_single_output(self, output_info: Dict, optimized_data_package: Dict,
                              subgraph_context: Dict, output_index: int, total_outputs: int) -> Dict:
        """
        Phase 3: Process a single output to generate its attribute mappings

        Args:
            output_info: Output component info {output_name, output_component_id, output_dataset}
            optimized_data_package: Graph data with optimized DML
            subgraph_context: Subgraph logic
            output_index: Current output index (1-based)
            total_outputs: Total number of outputs

        Returns:
            Output mapping dictionary
        """
        output_name = output_info.get("output_name", "Unknown")
        output_id = output_info.get("output_component_id", "Unknown")

        print(f"\n{'='*80}")
        print(f"📋 Processing Output {output_index}/{total_outputs}: {output_name} (ID: {output_id})")
        print(f"{'='*80}")

        # Create prompt for this specific output
        prompt = self._create_single_output_prompt(output_info, optimized_data_package,
                                                    subgraph_context, self.dependency_tree)

        # Save prompt for debugging
        debug_filename = self.output_folder / f"output_{output_index}_prompt.txt"
        with open(debug_filename, 'w', encoding='utf-8') as f:
            f.write(prompt)

        prompt_size = len(prompt)
        print(f"   📝 Prompt saved to: {debug_filename} (Length: {prompt_size:,} chars)")

        # Call LLM
        print(f"   🤖 Calling GPT-5 LLM for attribute mapping...")
        response = self.llm.invoke(prompt)

        # Parse response
        debug_response_filename = self.output_folder / f"output_{output_index}_response.txt"
        output_mapping = self._parse_json_response(response, save_debug=True,
                                                   debug_filename=str(debug_response_filename))

        if output_mapping and "mappings" in output_mapping:
            mapping_count = len(output_mapping.get("mappings", []))
            print(f"   ✅ Generated {mapping_count} attribute mapping(s) for {output_name}")
            return output_mapping
        else:
            print(f"   ⚠️  Failed to parse mapping for {output_name}")
            return {
                "output_name": output_name,
                "output_component_id": output_id,
                "output_dataset": output_info.get("output_dataset", ""),
                "error": "Failed to parse LLM response",
                "mappings": []
            }

    def process_main_graph(self) -> Dict:
        """
        Process main graph with HYBRID OPTIMIZATION:
        - Phase 0: Reduce DML to only required sections
        - Phase 2.5: Identify all outputs
        - Phase 3: Process each output separately

        Returns:
            Final mapping dictionary with all outputs
        """
        main_graph = self.graph_data['graph']
        graph_id = main_graph.get('graph_id')
        name = main_graph.get('name')

        print(f"\n{'='*80}")
        print(f"🎯 Processing Main Graph {graph_id}: {name}")
        print(f"{'='*80}")

        # Prepare initial data package (with full DML)
        data_package = {
            "graph_id": main_graph.get("graph_id"),
            "name": main_graph.get("name"),
            "raw_content": main_graph.get("raw_content"),
            "vertices": main_graph.get("vertices", {}),
            "referenced_files": main_graph.get("referenced_files", {}),
            "subgraph_references": main_graph.get("subgraph_references", [])
        }

        # Collect subgraph functional logic
        subgraph_context = {}
        for subgraph_ref in data_package["subgraph_references"]:
            if subgraph_ref in self.processed_subgraphs:
                sg_logic = self.processed_subgraphs[subgraph_ref]
                subgraph_context[subgraph_ref] = {
                    "graph_id": sg_logic.get("graph_id"),
                    "name": sg_logic.get("name"),
                    "functional_summary": sg_logic.get("functional_summary"),
                    "detailed_logic": sg_logic.get("detailed_logic", {})
                }

        # Add delay before DML optimization to avoid rate limits
        print(f"   ⏳ Waiting 60 seconds to avoid rate limit...")
        time.sleep(60)

        # PHASE 0: Optimize DML content (reduce to only required sections)
        optimized_referenced_files = self.optimize_referenced_files(data_package, subgraph_context)

        # Add delay after DML optimization to avoid rate limits
        print(f"   ⏳ Waiting 60 seconds to avoid rate limit...")
        time.sleep(60)

        # Create optimized data package
        optimized_data_package = {
            "graph_id": data_package["graph_id"],
            "name": data_package["name"],
            "raw_content": data_package["raw_content"],
            "vertices": data_package["vertices"],
            "referenced_files": optimized_referenced_files,  # ← Optimized DML only
            "subgraph_references": data_package["subgraph_references"]
        }

        # PHASE 2.5: Identify all outputs
        outputs_list = self.identify_outputs(optimized_data_package, subgraph_context)

        if not outputs_list:
            print(f"   ⚠️  No outputs identified, cannot generate mappings")
            return {
                "main_graph_id": graph_id,
                "main_graph_name": name,
                "error": "No outputs identified",
                "outputs": []
            }

        # PHASE 2.7: Generate Main Graph Summary
        graph_summary = self.generate_graph_summary(optimized_data_package, subgraph_context, outputs_list)

        # Add delay after graph summary to avoid rate limits
        print(f"   ⏳ Waiting 60 seconds to avoid rate limit...")
        time.sleep(60)

        # PHASE 3: Process each output separately
        print(f"\n{'='*80}")
        print(f"🔄 PHASE 3: GENERATE MAPPINGS FOR EACH OUTPUT")
        print(f"{'='*80}")

        all_output_mappings = []
        total_outputs = len(outputs_list)

        for idx, output_info in enumerate(outputs_list, 1):
            output_mapping = self.process_single_output(
                output_info,
                optimized_data_package,
                subgraph_context,
                idx,
                total_outputs
            )
            all_output_mappings.append(output_mapping)

            # Add delay after each output to avoid rate limits (TPM: 150K)
            if idx < total_outputs:
                print(f"   ⏳ Waiting 60 seconds to avoid rate limit...")
                time.sleep(60)

        # Combine all results
        final_mapping = {
            "main_graph_id": graph_id,
            "main_graph_name": name,
            "total_outputs": total_outputs,
            "graph_summary": graph_summary,
            "outputs": all_output_mappings
        }

        print(f"\n{'='*80}")
        print(f"✅ MAIN GRAPH PROCESSING COMPLETE")
        print(f"   Total outputs processed: {total_outputs}")
        print(f"{'='*80}")

        return final_mapping

    def _create_single_output_prompt(self, output_info: Dict, data_package: Dict,
                                     subgraph_context: Dict, dependency_tree: Dict) -> str:
        """
        Create LLM prompt for SINGLE output mapping

        Args:
            output_info: Target output info {output_name, output_component_id, output_dataset}
            data_package: Main graph data (optimized)
            subgraph_context: Dict of subgraph logic
            dependency_tree: Dependency tree structure

        Returns:
            Prompt string
        """
        output_name = output_info.get("output_name", "Unknown")
        output_id = output_info.get("output_component_id", "Unknown")
        output_dataset = output_info.get("output_dataset", "Unknown")

        prompt = f"""You are an AbInitio ETL expert. Generate SOURCE-TO-TARGET attribute-level mapping for ONE SPECIFIC OUTPUT.

**WHAT IS DML (Data Manipulation Language):**
DML is AbInitio's metadata format that defines record structures and field datatypes.
- Each "type" defines a record structure
- Each field has: datatype(parameters) fieldname
- Example: decimal("\\x01") hospitalfk means: numeric field with delimiter \\x01, named hospitalfk

**TARGET OUTPUT:**
- Output Component: {output_name}
- Component ID: {output_id}
- Output Dataset: {output_dataset}

**MAIN GRAPH DATA:**
Below is Graph 1 structure. The "referenced_files" contains:
- **.dml files**: REDUCED in JSON format (only required types/fields)
  Format: [
    {{
      "type_name": "type definition name",
      "required_fields": ["complete field definition with datatype", ...]
    }}
  ]
- **.xfr files**: FULL CONTENT as string (complete function library, not reduced)
  Format: "full XFR file content as string"

This structure provides optimized data for attribute mapping.

```json
{json.dumps(data_package, indent=2)}
```

**SUBGRAPH LOGIC:**
```json
{json.dumps(subgraph_context, indent=2)}
```

**DEPENDENCY TREE:**
```json
{json.dumps(dependency_tree, indent=2)}
```

**TASK:**
Generate attribute-level mappings ONLY for the target output component: {output_name} (ID: {output_id})

1. Identify ALL input sources (files/datasets) - look for vertices with type "XXGfvertex" and file_type "Input_File"
2. For the TARGET OUTPUT ({output_name}), trace EVERY attribute FROM SOURCE TO TARGET:
   - Start from input file (source)
   - Follow data_out connections to trace forward through components
   - Build transformation_chain step-by-step from SOURCE → TARGET
   - Document each component the attribute flows through
3. Extract datatypes from DML metadata (read_metadata, out0_metadata, etc.)
4. Document the complete transformation chain with detailed logic for each step

**HOW TO TRACE FLOW (SOURCE → TARGET):**
- Start from INPUT vertices (type "XXGfvertex" with file_type "Input_File")
- Parse read_metadata to get source attributes
- Follow data_out to see where data flows next
- For each vertex in the flow path:
  - If type is "XXGpvertex" (Reformat/Filter/etc):
    * Parse raw_content for transform0, filters, select_expr
    * Document transformations applied
  - If type is "XXGgraph" (Subgraph):
    * Look up vertex_id in subgraph_context
    * Read the detailed_logic (functionality, inputs, transformations, outputs)
    * Understand and document what transformations the subgraph applies
  - If vertex_id matches target output ID ({output_id}):
    * You've reached the target
    * Parse out_metadata to get target attributes
- Build transformation chain from SOURCE to TARGET (step1, step2, step3...)

**MAPPING RULES:**
- **DML files (.dml) in referenced_files are in JSON format**:
  * Each .dml file has array of types: [{{"type_name": "X", "required_fields": ["datatype fieldname", ...]}}]
  * Extract field names and datatypes from "required_fields" array
  * Example: "decimal(\\"\\\\x01\\") hospitalfk" → field: hospitalfk, datatype: decimal
- **XFR files (.xfr) in referenced_files are FULL STRING CONTENT**:
  * Parse .xfr content directly (it's the complete function library)
  * Look for function definitions and transform logic
- Parse vertex raw_content for metadata references (read_metadata, out_metadata, etc.)
- Match metadata references to DML type names in referenced_files
- Trace each target attribute to its source(s)
- When vertex type is "XXGgraph" (subgraph):
  * Use the detailed_logic to understand transformations
  * Explain in transformation_chain what the subgraph does based on its functional logic
  * Trace how attributes flow through based on the transformation description
- If attribute is derived/calculated in Reformat/Join/etc, explain logic with DML code snippets from raw_content
- If attribute passes unchanged, mark as "Direct Mapping"
- Include component names and IDs where transformations occur
- Capture filter conditions, lookup logic, reformat expressions IN DETAIL

**OUTPUT FORMAT (JSON only, no markdown):**
{{
  "output_name": "{output_name}",
  "output_component_id": "{output_id}",
  "output_dataset": "{output_dataset}",
  "mappings": [
    {{
      "source_dataset": "input file/dataset path",
      "source_component": "input component name",
      "source_component_id": "vertex id",
      "source_attribute": "attribute name",
      "source_datatype": "decimal|string|datetime|etc",
      "target_dataset": "{output_dataset}",
      "target_component": "{output_name}",
      "target_component_id": "{output_id}",
      "target_attribute": "attribute name",
      "target_datatype": "decimal|string|datetime|etc",
      "transformation_chain": {{
        "step1": "In component 'component_name' (ID: vertex_id, Type: component_type), the attribute flows from previous_component. Transformation: detailed explanation of what happens with DML code snippets, lookups, calculations.",
        "step2": "In component 'next_component' (ID: vertex_id, Type: component_type), data flows from component_name through data_out connection. Transformation: explain the transformation logic applied here."
      }}

      OR for direct mapping (no transformations):

      "transformation_chain": {{
        "step1": "Direct Mapping"
      }}
    }}
  ]
}}

**IMPORTANT:**
- Return ONLY valid JSON (no markdown, no code blocks, no extra text)
- Map ONLY attributes that end up in the TARGET output: {output_name} (ID: {output_id})
- Ignore flows to other outputs
- Capture ALL attributes in the target output
- Include datatypes for both source and target
- transformation_chain format:
  * Must be an OBJECT with step keys: {{"step1": "text", "step2": "text", ...}}
  * Each step is a NARRATIVE STRING combining component info, flow, and transformation logic
  * Write like: "In component 'XXX' (ID: YYY, Type: ZZZ), data flows from AAA. Transformation: [detailed logic]"
  * **For DIRECT MAPPINGS (no transformation):** Just use {{"step1": "Direct Mapping"}}
  * Do NOT create multiple steps for direct mappings
- Start tracing from SOURCE (input file) to TARGET (output file)
- Use step1, step2, step3... as keys in sequential order
"""

        return prompt

    def _create_main_graph_prompt(self, data_package: Dict, subgraph_context: Dict, dependency_tree: Dict) -> str:
        """
        Create LLM prompt for main graph mapping (OPTIMIZED)

        Args:
            data_package: Main graph data (compact vertices)
            subgraph_context: Dict of subgraph interfaces + attribute mappings
            dependency_tree: Dependency tree structure

        Returns:
            Prompt string
        """
        prompt = f"""You are an AbInitio ETL expert. Generate SOURCE-TO-TARGET attribute-level mapping for this main graph.

**WHAT YOU'RE RECEIVING:**

1. **MAIN GRAPH (Graph ID 1) - Complete Structure:**
   - Graph's own raw_content: Graph-level parameters (fileNamePrefix, dates, paths, etc.)
   - All vertices (components) AS-IS from JSON, including:
     * type: Component type (XXGfvertex, XXGpvertex, XXGgraph, etc.)
     * raw_content: Full AbInitio format string with DML metadata, transforms, filters, etc.
     * vertex_name: Component name
     * data_in/data_out: Flow connections showing which vertex flows to which
     * config_in/config_out: Configuration connections
     * keys, major_key, minor_key: Sort keys
     * file_type, file_name: File information (if applicable)
   - Referenced DML/XFR files (record structures, functions)

2. **LEVEL 1 SUBGRAPHS - Detailed Functional Logic (Direct Children Only):**
   - These are already-processed subgraphs referenced in Graph 1
   - Each has detailed_logic containing:
     * functionality: What the subgraph does
     * inputs: What input structure/attributes it expects
     * transformations: DETAILED transformation logic with DML code
     * outputs: What output structure/attributes it produces
   - Use this logic to understand what happens when data flows through the subgraph
   - Trace attributes through based on the transformation logic provided

3. **DEPENDENCY TREE:**
   - Shows graph hierarchy (for context)

**MAIN GRAPH DATA:**
```json
{json.dumps(data_package, indent=2)}
```

**LEVEL 1 SUBGRAPH LOGIC (treat as black boxes):**
```json
{json.dumps(subgraph_context, indent=2)}
```

**DEPENDENCY TREE:**
```json
{json.dumps(dependency_tree, indent=2)}
```

**TASK:**
1. Identify ALL input sources (files/datasets) - look for vertices with type "XXGfvertex" and file_type "Input_File"
2. Identify ALL output targets (files/datasets) - look for vertices with type "XXGfvertex" and file_type "Output_File"
3. For EACH output target, trace EVERY attribute FROM SOURCE TO TARGET:
   - Start from input file (source)
   - Follow data_out connections to trace forward through components
   - Build transformation_chain step-by-step from SOURCE → TARGET
   - Document each component the attribute flows through
4. Extract datatypes from DML metadata (read_metadata, out0_metadata, etc.)
5. Document the complete transformation chain with detailed logic for each step

**HOW TO TRACE FLOW (SOURCE → TARGET):**
- Start from INPUT vertices (type "XXGfvertex" with file_type "Input_File")
- Parse read_metadata to get source attributes
- Follow data_out to see where data flows next
- For each vertex in the flow path:
  - If type is "XXGpvertex" (Reformat/Filter/etc):
    * Parse raw_content for transform0, filters, select_expr
    * Document transformations applied
  - If type is "XXGgraph" (Subgraph):
    * Look up vertex_id in subgraph_context
    * Read the detailed_logic (functionality, inputs, transformations, outputs)
    * Understand and document what transformations the subgraph applies
  - If type is "XXGfvertex" with file_type "Output_File":
    * You've reached the target
    * Parse out_metadata to get target attributes
- Build transformation chain from SOURCE to TARGET (step1, step2, step3...)

**HOW TO PARSE raw_content:**
- raw_content is a pipe-delimited string in AbInitio format
- Look for patterns like: {{30001002|XXparameter|field_name|field_value|...}}
- Key fields to extract:
  * read_metadata: DML record definition for input
  * out_metadata or out0_metadata: DML record definition for output
  * transform0, transform1: DML transformation logic
  * select_expr: Filter condition
  * Layout: File path
- Parse DML syntax: record ... decimal("\\x01") fieldname; string("\\x01", maximum_length=N) fieldname; end;

**MAPPING RULES:**
- Parse DML metadata from raw_content to extract field names and datatypes
- Trace each target attribute to its source(s)
- When vertex type is "XXGgraph" (subgraph):
  * Use the detailed_logic to understand transformations
  * Explain in transformation_chain what the subgraph does based on its functional logic
  * Trace how attributes flow through based on the transformation description
- If attribute is derived/calculated in Reformat/Join/etc, explain logic with DML code snippets from raw_content
- If attribute passes unchanged, mark as "DIRECT_MAPPING"
- Include component names and IDs where transformations occur
- Capture filter conditions, lookup logic, reformat expressions IN DETAIL
- Extract datatypes: decimal, string, datetime, etc.

**OUTPUT FORMAT (JSON only, no markdown):**
{{
  "main_graph_id": "{data_package['graph_id']}",
  "main_graph_name": "{data_package['name']}",
  "outputs": [
    {{
      "output_name": "Output component name",
      "output_component_id": "vertex id",
      "output_dataset": "file path or dataset name",
      "mappings": [
        {{
          "source_dataset": "input file/dataset path",
          "source_component": "input component name",
          "source_component_id": "vertex id",
          "source_attribute": "attribute name",
          "source_datatype": "decimal|string|datetime|etc",
          "target_dataset": "output file/dataset path",
          "target_component": "output component name",
          "target_component_id": "vertex id",
          "target_attribute": "attribute name",
          "target_datatype": "decimal|string|datetime|etc",
          "transformation_chain": {{
            "step1": "In component 'component_name' (ID: vertex_id, Type: component_type), the attribute flows from previous_component. Transformation: detailed explanation of what happens with DML code snippets, lookups, calculations.",
            "step2": "In component 'next_component' (ID: vertex_id, Type: component_type), data flows from component_name through data_out connection. Transformation: explain the transformation logic applied here."
          }}

          OR for direct mapping (no transformations):

          "transformation_chain": {{
            "step1": "Direct Mapping"
          }}
        }}
      ]
    }}
  ]
}}

**IMPORTANT:**
- Return ONLY valid JSON (no markdown, no code blocks, no extra text)
- Capture ALL source attributes and ALL target attributes
- Include datatypes for both source and target
- transformation_chain format:
  * Must be an OBJECT with step keys: {{"step1": "text", "step2": "text", ...}}
  * Each step is a NARRATIVE STRING combining component info, flow, and transformation logic
  * Write like: "In component 'XXX' (ID: YYY, Type: ZZZ), data flows from AAA. Transformation: [detailed logic]"
  * **For DIRECT MAPPINGS (no transformation):** Just use {{"step1": "Direct Mapping"}}
  * Do NOT create multiple steps for direct mappings
- Start tracing from SOURCE (input file) to TARGET (output file)
- Use step1, step2, step3... as keys in sequential order
- If multiple outputs exist, include all in "outputs" array
- Each output will become a separate Excel tab
"""

        return prompt

    def _parse_json_response(self, response: str, save_debug: bool = False, debug_filename: str = "llm_response_debug.txt") -> Optional[Dict]:
        """
        Parse JSON from LLM response (handles markdown code blocks)

        Args:
            response: LLM response text
            save_debug: Whether to save raw response for debugging
            debug_filename: Debug file name

        Returns:
            Parsed JSON dictionary or None
        """
        # Save raw response for debugging
        if save_debug:
            with open(debug_filename, 'w', encoding='utf-8') as f:
                f.write("="*80 + "\n")
                f.write("RAW LLM RESPONSE\n")
                f.write("="*80 + "\n")
                f.write(response)
            print(f"   📝 Raw response saved to: {debug_filename}")

        # Check if response is empty
        if not response or not response.strip():
            print(f"   ⚠️  Empty response from LLM")
            return None

        print(f"   📊 Response length: {len(response)} characters")

        try:
            # Try to extract JSON from markdown code blocks
            json_match = re.search(r'```json\s*([\s\S]*?)\s*```', response)
            if json_match:
                json_str = json_match.group(1).strip()
                print(f"   ✓ Found JSON in markdown block")
                return json.loads(json_str)

            # Try to parse entire response as JSON
            print(f"   ✓ Attempting to parse entire response as JSON")
            return json.loads(response.strip())

        except json.JSONDecodeError as e:
            print(f"   ⚠️  JSON parse error: {e}")
            print(f"   📄 First 500 chars of response: {response[:500]}")

            # Try to find any JSON-like structure
            try:
                # Find first { and last }
                start = response.find('{')
                end = response.rfind('}')
                if start != -1 and end != -1:
                    json_str = response[start:end+1]
                    print(f"   ✓ Attempting to extract JSON from position {start} to {end}")
                    return json.loads(json_str)
            except Exception as e2:
                print(f"   ⚠️  Failed to extract JSON: {e2}")

            return None

    def save_subgraph_logic(self):
        """
        Save all subgraph logic to JSON file
        """
        output_file = self.output_folder / f"{self.base_filename}_subgraph_logic_optimized.json"

        print(f"\n💾 Saving subgraph logic to: {output_file}")

        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(self.processed_subgraphs, f, indent=2, ensure_ascii=False)

        file_size = output_file.stat().st_size / 1024
        print(f"✅ Saved successfully! File size: {file_size:.2f} KB")

    def save_final_mapping(self, mapping: Dict):
        """
        Save final mapping to JSON file

        Args:
            mapping: Mapping dictionary
        """
        output_file = self.output_folder / f"{self.base_filename}_final_mapping_optimized.json"

        print(f"\n💾 Saving final mapping to: {output_file}")

        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(mapping, f, indent=2, ensure_ascii=False)

        file_size = output_file.stat().st_size / 1024
        print(f"✅ Saved successfully! File size: {file_size:.2f} KB")

    def generate_excel(self, mapping: Dict):
        """
        Generate professional Excel file with multiple tabs (WITH DATATYPES)

        Args:
            mapping: Final mapping dictionary
        """
        output_file = self.output_folder / f"{self.base_filename}_source_to_target_mapping.xlsx"

        print(f"\n📊 Generating Excel file: {output_file}")

        # Create workbook
        wb = openpyxl.Workbook()
        wb.remove(wb.active)  # Remove default sheet

        # Define styles
        header_font = Font(name='Calibri', size=11, bold=True, color='FFFFFF')
        header_fill = PatternFill(start_color='366092', end_color='366092', fill_type='solid')
        header_alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)

        cell_font = Font(name='Calibri', size=10)
        cell_alignment = Alignment(vertical='top', wrap_text=True)

        border_style = Border(
            left=Side(style='thin', color='000000'),
            right=Side(style='thin', color='000000'),
            top=Side(style='thin', color='000000'),
            bottom=Side(style='thin', color='000000')
        )

        # CREATE SUMMARY TAB (FIRST SHEET)
        graph_summary = mapping.get('graph_summary', {})
        print(f"   📄 Creating Summary sheet")

        ws_summary = wb.create_sheet("Summary", 0)  # Create as first sheet

        # Title row
        ws_summary['A1'] = "GRAPH SUMMARY"
        ws_summary['A1'].font = Font(name='Calibri', size=16, bold=True, color='FFFFFF')
        ws_summary['A1'].fill = PatternFill(start_color='366092', end_color='366092', fill_type='solid')
        ws_summary['A1'].alignment = Alignment(horizontal='center', vertical='center')
        ws_summary.merge_cells('A1:B1')

        row = 3
        # Graph Name
        ws_summary[f'A{row}'] = "Graph Name:"
        ws_summary[f'A{row}'].font = Font(name='Calibri', size=11, bold=True)
        ws_summary[f'B{row}'] = graph_summary.get('graph_name', 'Unknown')
        ws_summary[f'B{row}'].font = cell_font
        row += 2

        # Summary
        ws_summary[f'A{row}'] = "Summary:"
        ws_summary[f'A{row}'].font = Font(name='Calibri', size=11, bold=True)
        ws_summary[f'B{row}'] = graph_summary.get('summary', 'Summary unavailable')
        ws_summary[f'B{row}'].font = cell_font
        ws_summary[f'B{row}'].alignment = Alignment(vertical='top', wrap_text=True)
        row += 2

        # Inputs
        ws_summary[f'A{row}'] = "Inputs:"
        ws_summary[f'A{row}'].font = Font(name='Calibri', size=11, bold=True)
        row += 1
        for inp in graph_summary.get('inputs', []):
            input_text = f"{inp.get('input_name', '')} - {inp.get('input_dataset', '')} - {inp.get('description', '')}"
            ws_summary[f'B{row}'] = input_text
            ws_summary[f'B{row}'].font = cell_font
            ws_summary[f'B{row}'].alignment = Alignment(vertical='top', wrap_text=True)
            row += 1
        row += 1

        # Outputs
        ws_summary[f'A{row}'] = "Outputs:"
        ws_summary[f'A{row}'].font = Font(name='Calibri', size=11, bold=True)
        row += 1
        for out in graph_summary.get('outputs', []):
            output_text = f"{out.get('output_name', '')} - {out.get('output_dataset', '')} - {out.get('description', '')}"
            ws_summary[f'B{row}'] = output_text
            ws_summary[f'B{row}'].font = cell_font
            ws_summary[f'B{row}'].alignment = Alignment(vertical='top', wrap_text=True)
            row += 1

        # Set column widths for Summary sheet
        ws_summary.column_dimensions['A'].width = 20
        ws_summary.column_dimensions['B'].width = 100

        # Column headers (WITH DATATYPES)
        headers = [
            "Source Dataset/File",
            "Source Component",
            "Source Attribute",
            "Source Datatype",
            "Target Dataset/File",
            "Target Component",
            "Target Attribute",
            "Target Datatype",
            "Transformation Logic Applied",
            "Components Involved"
        ]

        # Process each output
        outputs = mapping.get('outputs', [])

        if not outputs:
            print("   ⚠️  No outputs found in mapping")
            # Create a placeholder sheet
            ws = wb.create_sheet("No Outputs Found")
            ws['A1'] = "No output mappings were generated"
        else:
            for output_idx, output in enumerate(outputs):
                output_name = output.get('output_name', f'Output_{output_idx+1}')
                output_dataset = output.get('output_dataset', '')

                # Create sheet name (Excel limit: 31 chars)
                sheet_name = f"{output_name[:25]}"
                if len(outputs) > 1:
                    sheet_name = f"Output_{output_idx+1}_{output_name[:20]}"

                print(f"   📄 Creating sheet: {sheet_name}")

                ws = wb.create_sheet(sheet_name)

                # Write headers
                for col_idx, header in enumerate(headers, start=1):
                    cell = ws.cell(row=1, column=col_idx, value=header)
                    cell.font = header_font
                    cell.fill = header_fill
                    cell.alignment = header_alignment
                    cell.border = border_style

                # Write data rows
                mappings = output.get('mappings', [])
                row_idx = 2

                for mapping_entry in mappings:
                    # Build transformation chain text
                    # transformation_chain is now an object: {"step1": "text", "step2": "text", ...}
                    transformation_chain = mapping_entry.get('transformation_chain', {})
                    transformation_text = ""
                    components_involved = []

                    # Sort step keys (step1, step2, step3...) to maintain order
                    step_keys = sorted(transformation_chain.keys(), key=lambda x: int(x.replace('step', '')))

                    for step_key in step_keys:
                        step_text = transformation_chain[step_key]
                        step_num = step_key.replace('step', '')

                        # Check for direct mapping
                        if step_text.strip().lower() == "direct mapping":
                            transformation_text = "Direct Mapping"
                            break  # No need to process more steps

                        # Each step is now a narrative string with all details
                        if len(step_keys) > 1:
                            transformation_text += f"Step {step_num}:\n{step_text}\n\n"
                        else:
                            transformation_text += step_text

                        # Try to extract component name from text for "Components Involved" column
                        # Look for pattern: "In component 'component_name' (ID: ..."
                        comp_match = re.search(r"In component ['\"]([^'\"]+)['\"]", step_text)
                        if comp_match:
                            comp_name = comp_match.group(1).strip()
                            if comp_name and comp_name not in components_involved:
                                components_involved.append(comp_name)

                    if not transformation_text:
                        transformation_text = "No transformation logic available"

                    components_text = ", ".join(components_involved)

                    # Write row data (WITH DATATYPES)
                    row_data = [
                        mapping_entry.get('source_dataset', ''),
                        mapping_entry.get('source_component', ''),
                        mapping_entry.get('source_attribute', ''),
                        mapping_entry.get('source_datatype', ''),
                        mapping_entry.get('target_dataset', ''),
                        mapping_entry.get('target_component', ''),
                        mapping_entry.get('target_attribute', ''),
                        mapping_entry.get('target_datatype', ''),
                        transformation_text.strip(),
                        components_text
                    ]

                    for col_idx, value in enumerate(row_data, start=1):
                        cell = ws.cell(row=row_idx, column=col_idx, value=value)
                        cell.font = cell_font
                        cell.alignment = cell_alignment
                        cell.border = border_style

                    row_idx += 1

                # Auto-fit columns
                for col_idx in range(1, len(headers) + 1):
                    column_letter = get_column_letter(col_idx)

                    # Set specific widths for better readability
                    if col_idx in [1, 5]:  # Dataset columns
                        ws.column_dimensions[column_letter].width = 35
                    elif col_idx in [2, 6]:  # Component columns
                        ws.column_dimensions[column_letter].width = 25
                    elif col_idx in [3, 7]:  # Attribute columns
                        ws.column_dimensions[column_letter].width = 20
                    elif col_idx in [4, 8]:  # Datatype columns
                        ws.column_dimensions[column_letter].width = 15
                    elif col_idx == 9:  # Transformation logic
                        ws.column_dimensions[column_letter].width = 60
                    elif col_idx == 10:  # Components involved
                        ws.column_dimensions[column_letter].width = 40

                # Freeze first row
                ws.freeze_panes = 'A2'

                # Enable filters
                ws.auto_filter.ref = ws.dimensions

                print(f"   ✅ Added {len(mappings)} mapping entries")

        # Save workbook
        wb.save(output_file)

        file_size = output_file.stat().st_size / 1024
        print(f"✅ Excel file saved! File size: {file_size:.2f} KB")

    def run(self):
        """Main execution flow (HYBRID OPTIMIZED)"""
        print("""
╔════════════════════════════════════════════════════════════════════════════╗
║    STEP 3: SOURCE-TO-TARGET ATTRIBUTE MAPPING GENERATOR (HYBRID)          ║
║                                                                            ║
║  Processing Strategy:                                                      ║
║    - Phase 0: DML Optimization (LLM identifies required sections)         ║
║    - Phase 1: Load graph data & build dependency tree                     ║
║    - Phase 2: Extract detailed functional logic from subgraphs            ║
║    - Phase 2.5: Identify all output components (LLM-driven)               ║
║    - Phase 3: Process EACH output separately (one LLM call per output)    ║
║    - Phase 4: Generate Excel with all outputs                             ║
║  Flow: SOURCE → TARGET (trace forward from inputs to outputs)             ║
║  Output: Excel file with detailed attribute-level mapping + datatypes      ║
╚════════════════════════════════════════════════════════════════════════════╝
        """)

        # Phase 1: Load and analyze structure
        print("\n" + "="*80)
        print("PHASE 1: LOAD GRAPH DATA & BUILD DEPENDENCY TREE")
        print("="*80)

        self.load_graph_data()

        main_graph = self.graph_data['graph']
        self.dependency_tree = self.build_dependency_tree(main_graph)

        print(f"📊 Main Graph: {main_graph.get('name')} (ID: {main_graph.get('graph_id')})")
        print(f"📊 Total graphs in hierarchy: {len(self.graph_data['extraction_metadata']['extracted_graph_ids'])}")

        # Build processing order
        self.get_processing_order(main_graph, self.processing_order)

        print(f"📊 Subgraphs to process: {len(self.processing_order)}")
        processing_order_str = [f"{g['graph_id']}:{g['name']}" for g in self.processing_order]
        print(f"   Processing order: {processing_order_str}")

        # Phase 2: Process subgraphs bottom-up (FUNCTIONAL LOGIC)
        print("\n" + "="*80)
        print("PHASE 2: PROCESS SUBGRAPHS (BOTTOM-UP)")
        print("         Extract: detailed functional logic (inputs, transformations, outputs)")
        print("="*80)

        for subgraph_info in self.processing_order:
            graph_id = subgraph_info['graph_id']
            name = subgraph_info['name']
            level = subgraph_info['level']

            logic = self.process_subgraph(graph_id, name, level)
            self.processed_subgraphs[graph_id] = logic

        # Save subgraph logic
        self.save_subgraph_logic()

        # Phase 3: Process main graph (HYBRID APPROACH)
        # - Phase 0: DML optimization (inside process_main_graph)
        # - Phase 2.5: Identify outputs (inside process_main_graph)
        # - Phase 3: Process each output separately (inside process_main_graph)
        print("\n" + "="*80)
        print("PHASE 3: PROCESS MAIN GRAPH (HYBRID OPTIMIZATION)")
        print("         - DML reduction to required sections only")
        print("         - Identify all outputs dynamically")
        print("         - Generate mapping for each output separately")
        print("="*80)

        final_mapping = self.process_main_graph()

        # Save final mapping
        self.save_final_mapping(final_mapping)

        # Phase 4: Generate Excel
        print("\n" + "="*80)
        print("PHASE 4: GENERATE EXCEL OUTPUT")
        print("="*80)

        self.generate_excel(final_mapping)

        # Summary
        print("\n" + "="*80)
        print("📋 EXECUTION SUMMARY")
        print("="*80)
        print(f"Main Graph ID: {self.main_graph_id}")
        print(f"Main Graph Name: {main_graph.get('name')}")
        print(f"Subgraphs Processed: {len(self.processed_subgraphs)}")
        print(f"Output Files Generated:")
        print(f"  - {self.base_filename}_subgraph_logic_optimized.json")
        print(f"  - {self.base_filename}_final_mapping_optimized.json")
        print(f"  - {self.base_filename}_source_to_target_mapping.xlsx")
        print(f"All files saved in: {self.output_folder}")
        print("="*80)
        print("\n✅ STEP 3 COMPLETE!\n")


def main():
    """Main execution"""
    # Get input JSON file path from user
    detailed_graph_path = input("Enter the path to the detailed graph with files JSON from Step 2: ").strip()

    # Extract output folder and base filename from input path
    input_path = Path(detailed_graph_path)
    output_folder = input_path.parent

    # Extract base filename (remove "_detailed_graph1_with_files" suffix)
    base_filename = input_path.stem.replace("_detailed_graph1_with_files", "")

    print(f"\n📁 All outputs will be saved to: {output_folder}")
    print(f"📁 Base filename: {base_filename}\n")

    try:
        generator = MappingGenerator(
            detailed_graph_path=detailed_graph_path,
            output_folder=output_folder,
            base_filename=base_filename
        )

        generator.run()

        return 0

    except Exception as e:
        print(f"\n❌ ERROR: {str(e)}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
