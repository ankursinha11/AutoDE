"""
AbInitio Automation Module for STTM Generation

Provides automated STTM generation for AbInitio graphs using:
1. step1_extract_graph1_details.py - Extract graph details
2. step2_embed_dml_xfr.py - Embed DML/XFR content
3. step3_mapping_optimized.py - Generate STTM mapping

Usage:
    from parsers.abinitio.automation import AbInitioSTTMGenerator

    generator = AbInitioSTTMGenerator(
        blade_path="Input Files/blade",
        ai_analyzer=st.session_state.ai_analyzer
    )
    result = generator.generate_sttm_from_parsed_json(parsed_json_path)
"""

from .abinitio_sttm_generator import AbInitioSTTMGenerator
from .step3_mapping_optimized import MappingGenerator, STAGLLMWrapper

__all__ = ["AbInitioSTTMGenerator", "MappingGenerator", "STAGLLMWrapper"]
