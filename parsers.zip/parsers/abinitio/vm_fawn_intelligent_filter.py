"""
Intelligent VM_FAWN Filter
Reduces Component&Fields rows by 95%+ while preserving all business logic

Based on filtering patterns from Ab Initio developers:
- Original: 1,209 rows
- Filtered: ~40 rows (96.7% reduction)
- Preserves: All transformation logic, keys, filters, data structures
- Removes: Metadata boilerplate, error handling, logging, infrastructure settings
"""

import re
import pandas as pd
from pathlib import Path
from typing import Dict, Any, List, Optional
import logging
from .vm_fawn_filter_config import FilterConfig, DEFAULT_FILTER_CONFIG

logger = logging.getLogger(__name__)


class VMFAWNIntelligentFilter:
    """
    Intelligently filters VM_FAWN Excel output to remove noise
    while preserving all business-critical transformation logic
    """

    def __init__(self, config: Optional[FilterConfig] = None):
        self.config = config or DEFAULT_FILTER_CONFIG
        self.stats = {
            'total_rows': 0,
            'rows_kept': 0,
            'rows_removed': 0,
            'reasons_kept': {},
            'reasons_removed': {}
        }

    def filter_excel(
        self,
        excel_path: str,
        output_path: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Filter VM_FAWN Excel file

        Args:
            excel_path: Path to original VM_FAWN Excel
            output_path: Path to save filtered Excel (optional)

        Returns:
            Dict with filtered data and statistics
        """
        try:
            excel_path = Path(excel_path)

            if not excel_path.exists():
                return {
                    'success': False,
                    'error': f'Excel file not found: {excel_path}'
                }

            logger.info(f"Filtering VM_FAWN Excel: {excel_path.name}")

            # Read all sheets
            xl = pd.ExcelFile(excel_path)
            sheets = {}

            for sheet_name in xl.sheet_names:
                df = pd.read_excel(xl, sheet_name=sheet_name)

                if sheet_name == 'Component&Fields':
                    # Apply intelligent filtering
                    logger.info(f"  Filtering Component&Fields: {len(df)} rows")
                    df_filtered = self._filter_component_fields(df)
                    sheets[sheet_name] = df_filtered
                    reduction_pct = (1 - len(df_filtered)/len(df)) * 100
                    logger.info(f"  After filtering: {len(df_filtered)} rows ({reduction_pct:.1f}% reduction)")
                else:
                    # Keep other sheets as-is
                    sheets[sheet_name] = df

            # Save filtered Excel if output path provided
            if output_path:
                output_path = Path(output_path)
                output_path.parent.mkdir(parents=True, exist_ok=True)

                with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
                    for sheet_name, df in sheets.items():
                        df.to_excel(writer, sheet_name=sheet_name, index=False)

                logger.info(f"✅ Filtered Excel saved: {output_path}")

            return {
                'success': True,
                'sheets': sheets,
                'statistics': self.stats,
                'output_path': str(output_path) if output_path else None
            }

        except Exception as e:
            logger.error(f"Filter error: {e}", exc_info=True)
            return {
                'success': False,
                'error': str(e)
            }

    def _filter_component_fields(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Filter Component&Fields sheet using intelligent rules
        """
        self.stats['total_rows'] = len(df)
        self.stats['rows_kept'] = 0
        self.stats['rows_removed'] = 0
        self.stats['reasons_kept'] = {}
        self.stats['reasons_removed'] = {}

        # Create mask for rows to keep
        keep_mask = pd.Series([False] * len(df), index=df.index)

        for idx, row in df.iterrows():
            reason = self._should_keep_row(row)
            if reason:
                keep_mask[idx] = True
                self._record_reason('kept', reason)
            else:
                removal_reason = self._get_removal_reason(row)
                self._record_reason('removed', removal_reason)

        df_filtered = df[keep_mask].copy()
        self.stats['rows_kept'] = len(df_filtered)
        self.stats['rows_removed'] = self.stats['total_rows'] - self.stats['rows_kept']

        return df_filtered

    def _should_keep_row(self, row: pd.Series) -> Optional[str]:
        """
        Determine if row should be kept
        Returns reason string if keep, None if remove
        """
        component_type = str(row.get('Transform Component', ''))
        translocation = str(row.get('TransLocation', ''))
        transform_rule = str(row.get('Transform Rule', ''))
        keys = str(row.get('Keys', ''))
        component_name = str(row.get('Component Name', ''))

        # Handle NaN values
        if component_type == 'nan':
            component_type = ''
        if translocation == 'nan':
            translocation = ''
        if transform_rule == 'nan':
            transform_rule = ''
        if keys == 'nan':
            keys = ''

        # Rule 0: Check component name for business context
        # REMOVE if component name matches noise patterns
        for pattern in self.config.NOISE_COMPONENT_NAME_PATTERNS:
            if re.search(pattern, component_name, re.IGNORECASE):
                return None  # Skip this component (infrastructure/utility)

        # KEEP if component name has business context
        for pattern in self.config.CRITICAL_COMPONENT_NAME_PATTERNS:
            if re.search(pattern, component_name, re.IGNORECASE):
                if translocation in self.config.KEEP_TRANSLOCATION or transform_rule:
                    return f"critical_component_name:{pattern}"

        # Rule 1: Critical component types (Input/Output/Lookup) - ALWAYS keep at least one row
        if component_type in self.config.CRITICAL_COMPONENT_TYPES:
            # Keep if it's a meaningful row (has dataset name, DML, or keys)
            if translocation in ['DataSet Names', 'DML', 'Key Parameter Value'] or \
               translocation in self.config.KEEP_TRANSLOCATION:
                return f"critical_component:{component_type}"

        # Rule 2: TransLocation is in KEEP list (business logic)
        if translocation in self.config.KEEP_TRANSLOCATION:
            return f"keep_translocation:{translocation}"

        # Rule 3: Transform Rule contains critical patterns (transformation logic)
        if transform_rule and len(transform_rule) > 5:
            for pattern in self.config.CRITICAL_PATTERNS:
                if re.search(pattern, transform_rule, re.IGNORECASE):
                    return f"critical_pattern:{pattern}"

        # Rule 4: Has meaningful keys
        if keys and len(keys.strip()) > 2:
            return "has_keys"

        # Rule 5: TransLocation is NOT in REMOVE list and has meaningful content
        if translocation and translocation not in self.config.REMOVE_TRANSLOCATION:
            # Check if transform rule is meaningful (not just noise)
            if transform_rule and len(transform_rule) > 5:
                if not self._is_noise_pattern(transform_rule):
                    return f"unknown_translocation_with_logic:{translocation}"

        return None

    def _get_removal_reason(self, row: pd.Series) -> str:
        """Get reason for removing this row"""
        translocation = str(row.get('TransLocation', ''))
        transform_rule = str(row.get('Transform Rule', ''))

        if translocation == 'nan':
            translocation = ''
        if transform_rule == 'nan':
            transform_rule = ''

        if translocation in self.config.REMOVE_TRANSLOCATION:
            return f"noise_translocation:{translocation}"

        if self._is_noise_pattern(transform_rule):
            return "noise_pattern_in_transform"

        if not transform_rule or len(transform_rule) <= 5:
            return "empty_or_trivial_transform"

        return "no_business_value"

    def _is_noise_pattern(self, transform_rule: str) -> bool:
        """Check if transform rule is just noise (boilerplate)"""
        if not transform_rule or transform_rule == 'nan':
            return True

        transform_rule = transform_rule.strip()

        if len(transform_rule) <= 5:
            return True

        for pattern in self.config.NOISE_PATTERNS:
            if re.search(pattern, transform_rule):
                return True

        return False

    def _record_reason(self, category: str, reason: str):
        """Record statistics by reason"""
        stat_key = f'reasons_{category}'
        if reason not in self.stats[stat_key]:
            self.stats[stat_key][reason] = 0
        self.stats[stat_key][reason] += 1

    def get_statistics_report(self) -> str:
        """Generate human-readable statistics report"""
        report = []
        report.append("=" * 80)
        report.append("VM_FAWN INTELLIGENT FILTERING STATISTICS")
        report.append("=" * 80)
        report.append(f"Total rows:    {self.stats['total_rows']:>6}")
        report.append(f"Rows kept:     {self.stats['rows_kept']:>6} ({self._pct(self.stats['rows_kept'], self.stats['total_rows'])}%)")
        report.append(f"Rows removed:  {self.stats['rows_removed']:>6} ({self._pct(self.stats['rows_removed'], self.stats['total_rows'])}%)")
        report.append("")

        report.append("TOP REASONS FOR KEEPING ROWS:")
        report.append("-" * 80)
        for reason, count in sorted(self.stats['reasons_kept'].items(), key=lambda x: -x[1])[:10]:
            report.append(f"  {reason:<60} {count:>5}")

        report.append("")
        report.append("TOP REASONS FOR REMOVING ROWS:")
        report.append("-" * 80)
        for reason, count in sorted(self.stats['reasons_removed'].items(), key=lambda x: -x[1])[:10]:
            report.append(f"  {reason:<60} {count:>5}")

        report.append("=" * 80)
        return "\n".join(report)

    @staticmethod
    def _pct(numerator: int, denominator: int) -> str:
        """Calculate percentage as string"""
        if denominator == 0:
            return "0.0"
        return f"{(numerator / denominator * 100):.1f}"
