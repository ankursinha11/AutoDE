#!/usr/bin/env python3
"""
Subgraph Extractor for Ab Initio Components
Extracts a specific subgraph with all its components and dependencies
"""

import json
import os
from pathlib import Path
from collections import defaultdict, deque
from typing import Dict, List, Set, Any, Optional, Tuple

class SubgraphExtractor:
    """Extract subgraphs with all components and dependencies"""
    
    def __init__(self, components_file: str):
        """Initialize with components JSON file"""
        with open(components_file, 'r') as f:
            self.components = json.load(f)
        
        # Build lookup indices for efficient searching
        self._build_indices()
    
    def _build_indices(self):
        """Build lookup indices for components"""
        print("🔍 Building component indices...")
        
        # Graph ID to graph data mapping
        self.graphs_by_id = {}
        for graph_key, graph_data in self.components.get('graphs', {}).items():
            graph_id = graph_data['component_id']
            self.graphs_by_id[graph_id] = {
                'key': graph_key,
                'data': graph_data
            }
        
        # Vertex ID to vertex data mapping
        self.vertices_by_id = {}
        for vertex_key, vertex_data in self.components.get('vertices', {}).items():
            vertex_id = vertex_data['component_id']
            self.vertices_by_id[vertex_id] = {
                'key': vertex_key,
                'data': vertex_data
            }
        
        # Flow ID to flow data mapping
        self.flows_by_id = {}
        for flow_key, flow_data in self.components.get('flows', {}).items():
            flow_id = flow_data['component_id']
            self.flows_by_id[flow_id] = {
                'key': flow_key,
                'data': flow_data
            }
        
        # Port ID to port data mapping
        self.ports_by_id = {}
        for port_key, port_data in self.components.get('ports', {}).items():
            port_id = port_data['component_id']
            self.ports_by_id[port_id] = {
                'key': port_key,
                'data': port_data
            }
        
        # Build graph-vertex relationships
        self.vertices_by_graph = defaultdict(list)
        self.graph_by_vertex = {}
        for link_key, link_data in self.components.get('graph_vertex_links', {}).items():
            graph_id = link_data['graph_id']
            vertex_id = link_data['vertex_id']
            self.vertices_by_graph[graph_id].append(vertex_id)
            self.graph_by_vertex[vertex_id] = graph_id
        
        # Build flow connections mapping
        self.flow_connections_by_vertex = defaultdict(list)
        self.flow_connections_by_flow = defaultdict(list)
        for conn_key, conn_data in self.components.get('flow_connections', {}).items():
            port_id = conn_data['port_id']
            flow_id = conn_data['flow_id']
            
            # Find vertex for this port
            if port_id in self.ports_by_id:
                vertex_id = self.ports_by_id[port_id]['data'].get('vertex_id')
                if vertex_id:
                    self.flow_connections_by_vertex[vertex_id].append({
                        'flow_id': flow_id,
                        'port_id': port_id,
                        'is_source': conn_data['is_source'],
                        'conn_key': conn_key
                    })
                    self.flow_connections_by_flow[flow_id].append({
                        'vertex_id': vertex_id,
                        'port_id': port_id,
                        'is_source': conn_data['is_source'],
                        'conn_key': conn_key
                    })
        
        print(f"   • Indexed {len(self.graphs_by_id)} graphs")
        print(f"   • Indexed {len(self.vertices_by_id)} vertices")
        print(f"   • Indexed {len(self.flows_by_id)} flows")
        print(f"   • Indexed {len(self.ports_by_id)} ports")

    def _extract_vertex_name(self, raw_content: str, vertex_id: str = "") -> str:
        """
        Extract vertex name (component name) from raw_content

        Args:
            raw_content: The raw_content field from a vertex
            vertex_id: The vertex ID (optional)

        Returns:
            The extracted component name or empty string if not found
        """
        if not raw_content:
            return ""

        # Break down the block into sections
        start_section, middle_section, end_section = self._break_down_block(raw_content)

        if not end_section:
            return ""

        # Extract details from end section
        details = self._extract_end_section_details(end_section, vertex_id)

        # Return component_name if found
        return details.get("component_name", "")

    def _extract_file_metadata(self, raw_content: str, vertex_type: str) -> Dict[str, str]:
        """
        Extract file metadata from raw_content
        - For XXGfvertex: file_type, file_name, keys
        - For all vertices: keys

        Args:
            raw_content: The raw_content field from a vertex
            vertex_type: The vertex type (XXGfvertex or XXGpvertex)

        Returns:
            Dictionary with file_type, file_name, and keys
        """
        import re

        metadata = {
            "keys": ""
        }

        # Only add file_type and file_name for functional vertices
        if vertex_type == "XXGfvertex":
            metadata["file_type"] = ""
            metadata["file_name"] = ""

        if not raw_content:
            return metadata

        # Extract parameter blocks using the pattern
        parameter_section_pattern = r'@@@@\{(.*?)\}\}@'
        match = re.search(parameter_section_pattern, raw_content, re.DOTALL)

        if not match:
            return metadata

        parameter_section = match.group(1)

        # Extract individual parameter blocks
        # Pattern captures: {ID|XXparameter|param_name|param_value|...}
        parameter_pattern = r'\{(\d+)\|XXparameter\|([^|]*)\|(.*?)\|[^|]*\|[^|]*\|[^|]*\|'
        param_matches = re.finditer(parameter_pattern, parameter_section, re.DOTALL)

        for param_match in param_matches:
            param_name = param_match.group(2)
            param_value = param_match.group(3)

            # Extract file_type from !prototype_path (only for functional vertices)
            if vertex_type == "XXGfvertex" and param_name == "!prototype_path":
                # Extract last part before .mdc
                # Example: $AB_COMPONENTS/Datasets/Lookup_File.mdc -> Lookup_File
                if param_value:
                    # Split by / and get last part
                    last_part = param_value.split('/')[-1]
                    # Remove .mdc extension
                    file_type = last_part.split('.')[0]
                    metadata["file_type"] = file_type

            # Extract file_name from Layout parameter (only for functional vertices)
            elif vertex_type == "XXGfvertex" and param_name == "Layout":
                metadata["file_name"] = param_value

            # Extract keys from key parameter (for all vertices)
            elif param_name == "key":
                metadata["keys"] = param_value

        return metadata

    def _break_down_block(self, block: str) -> Tuple[str, str, str]:
        """
        Break down a vertex raw_content block into start, middle, and end sections

        Args:
            block: The raw_content string from a vertex

        Returns:
            Tuple of (start_section, middle_section, end_section)
        """
        import re

        # Pattern for parameter_set blocks
        internal_pattern = r'(\{\d+\|XXparameter_set\|@@@@\{)'
        internal_match = re.search(internal_pattern, block, re.DOTALL)

        if internal_match:
            start_index = internal_match.start()
            stack = []
            end_index = -1

            for i in range(start_index, len(block)):
                if block[i] == "{":
                    stack.append("{")
                elif block[i] == "}":
                    if stack:
                        stack.pop()
                    if not stack:
                        end_index = i + 1
                        break

            if end_index != -1:
                return (
                    block[:start_index].strip(),
                    block[start_index:end_index].strip(),
                    block[end_index:].strip()
                )
        else:
            # Alternative pattern for graphs
            start_match = re.match(r'\{(\d+)\|', block)
            if start_match:
                no_match = re.search(r'\\', block)
                end_match = re.search(r'\{\}', block)
                start_index = no_match.start() if no_match else 0
                end_index = end_match.start() if end_match else -1

                if end_index != -1:
                    return (
                        block[:start_index].strip(),
                        "",  # No middle section
                        block[end_index:].strip()
                    )

        return "", "", ""

    def _extract_end_section_details(self, end_section: str, vertex_id: str = "") -> Dict[str, str]:
        """
        Extract component name and other details from end section

        Args:
            end_section: The end section of the raw_content block
            vertex_id: The vertex ID (optional, for context)

        Returns:
            Dictionary with extracted details including component_name
        """
        split_end = end_section.split('|')
        end_dict = {}

        END_SECTION_MIN_LENGTH = 8
        COMPONENT_NAME_MARKER = "Ab Initio"

        if len(split_end) >= END_SECTION_MIN_LENGTH:
            end_dict["component_phase"] = split_end[0].strip('@')
            end_dict["disable_check"] = 0
            end_dict["graph_name"] = split_end[8] if len(split_end) > 8 else ""

            # Extract component name using the logic from the user's code
            if COMPONENT_NAME_MARKER in split_end:
                component_index = split_end.index(COMPONENT_NAME_MARKER)
                end_dict["component_name"] = split_end[component_index - 1]
            else:
                # Alternative extraction method
                if len(split_end) > 8:
                    position_8_value = split_end[8].strip()

                    if position_8_value.isdigit():
                        end_dict["component_name"] = split_end[9] if len(split_end) > 9 else ""
                    else:
                        end_dict["component_name"] = position_8_value

        return end_dict
    
    def extract_subgraph(self, graph_id: str, include_dependencies: bool = True, 
                        dependency_depth: int = 1) -> Dict[str, Any]:
        """
        Extract a subgraph with all its components and optionally dependencies
        
        Args:
            graph_id: ID of the graph to extract
            include_dependencies: Whether to include dependent graphs
            dependency_depth: How many levels of dependencies to include (1 = direct only)
        
        Returns:
            Dictionary containing the extracted subgraph data
        """
        print(f"🎯 EXTRACTING SUBGRAPH {graph_id}")
        print("=" * 50)
        
        if graph_id not in self.graphs_by_id:
            raise ValueError(f"Graph {graph_id} not found")
        
        # Initialize extraction result
        extracted = {
            'target_graph_id': graph_id,
            'target_graph_name': self.graphs_by_id[graph_id]['data']['name'],
            'include_dependencies': include_dependencies,
            'dependency_depth': dependency_depth,
            'graphs': {},
            'vertices': {},
            'flows': {},
            'ports': {},
            'flow_connections': {},
            'config_flows': {},
            'port_bindings': {},
            'graph_vertex_links': {},
            'graph_flow_links': {},
            'statistics': {}
        }
        
        # Start with target graph
        graphs_to_process = {graph_id}
        processed_graphs = set()
        
        # Find all graphs to include based on dependencies
        if include_dependencies:
            graphs_to_process.update(
                self._find_dependent_graphs(graph_id, dependency_depth)
            )
        
        print(f"📊 Processing {len(graphs_to_process)} graphs:")
        for gid in sorted(graphs_to_process):
            if gid in self.graphs_by_id:
                print(f"   • Graph {gid}: {self.graphs_by_id[gid]['data']['name']}")
        
        # Extract all components for selected graphs
        all_vertices = set()
        all_flows = set()
        all_ports = set()
        
        for gid in graphs_to_process:
            if gid in self.graphs_by_id:
                # Add graph
                graph_info = self.graphs_by_id[gid]
                extracted['graphs'][graph_info['key']] = graph_info['data']
                
                # Add vertices in this graph
                for vertex_id in self.vertices_by_graph.get(gid, []):
                    all_vertices.add(vertex_id)
                    if vertex_id in self.vertices_by_id:
                        # Regular vertex
                        vertex_info = self.vertices_by_id[vertex_id]
                        extracted['vertices'][vertex_info['key']] = vertex_info['data']
                    elif vertex_id in self.graphs_by_id:
                        # Subgraph acting as a vertex
                        graph_info = self.graphs_by_id[vertex_id]
                        extracted['vertices'][graph_info['key']] = graph_info['data']
                
                # Add graph-vertex links
                for link_key, link_data in self.components.get('graph_vertex_links', {}).items():
                    if link_data['graph_id'] == gid:
                        extracted['graph_vertex_links'][link_key] = link_data
        
        # Find all flows connected to these vertices
        for vertex_id in all_vertices:
            for flow_conn in self.flow_connections_by_vertex.get(vertex_id, []):
                flow_id = flow_conn['flow_id']
                all_flows.add(flow_id)
                
                # Add flow connection
                conn_key = flow_conn['conn_key']
                for fc_key, fc_data in self.components.get('flow_connections', {}).items():
                    if fc_key == conn_key:
                        extracted['flow_connections'][fc_key] = fc_data
                        break
                
                # Add port
                port_id = flow_conn['port_id']
                all_ports.add(port_id)
        
        # Add all flows
        for flow_id in all_flows:
            if flow_id in self.flows_by_id:
                flow_info = self.flows_by_id[flow_id]
                extracted['flows'][flow_info['key']] = flow_info['data']
                
                # Add graph-flow links
                for link_key, link_data in self.components.get('graph_flow_links', {}).items():
                    if link_data['flow_id'] == flow_id:
                        extracted['graph_flow_links'][link_key] = link_data
        
        # Add all ports
        for port_id in all_ports:
            if port_id in self.ports_by_id:
                port_info = self.ports_by_id[port_id]
                extracted['ports'][port_info['key']] = port_info['data']
        
        # Add config flows for included flows
        for config_key, config_data in self.components.get('config_flows', {}).items():
            config_flow_id = config_data['component_id']
            if config_flow_id in all_flows:
                extracted['config_flows'][config_key] = config_data
        
        # Add port bindings that involve included ports
        for binding_key, binding_data in self.components.get('port_bindings', {}).items():
            source_port = binding_data.get('source_port_id')
            target_port = binding_data.get('target_port_id')
            if source_port in all_ports or target_port in all_ports:
                extracted['port_bindings'][binding_key] = binding_data
        
        # Generate statistics
        extracted['statistics'] = {
            'total_graphs': len(extracted['graphs']),
            'total_vertices': len(extracted['vertices']),
            'total_flows': len(extracted['flows']),
            'total_ports': len(extracted['ports']),
            'total_flow_connections': len(extracted['flow_connections']),
            'total_config_flows': len(extracted['config_flows']),
            'total_port_bindings': len(extracted['port_bindings']),
            'total_graph_vertex_links': len(extracted['graph_vertex_links']),
            'total_graph_flow_links': len(extracted['graph_flow_links'])
        }
        
        self._print_extraction_statistics(extracted)
        
        return extracted
    
    def _find_dependent_graphs(self, graph_id: str, depth: int) -> Set[str]:
        """Find graphs that are dependencies of the target graph"""
        if depth <= 0:
            return set()
        
        dependent_graphs = set()
        queue = deque([(graph_id, 0)])
        visited = {graph_id}
        
        while queue:
            current_graph, current_depth = queue.popleft()
            
            if current_depth >= depth:
                continue
            
            # Find vertices in current graph
            vertices_in_graph = self.vertices_by_graph.get(current_graph, [])
            
            # Find flows connected to these vertices
            connected_flows = set()
            for vertex_id in vertices_in_graph:
                for flow_conn in self.flow_connections_by_vertex.get(vertex_id, []):
                    connected_flows.add(flow_conn['flow_id'])
            
            # Find other graphs that share these flows
            for flow_id in connected_flows:
                for flow_conn in self.flow_connections_by_flow.get(flow_id, []):
                    vertex_id = flow_conn['vertex_id']
                    other_graph = self.graph_by_vertex.get(vertex_id)
                    
                    if other_graph and other_graph not in visited:
                        dependent_graphs.add(other_graph)
                        visited.add(other_graph)
                        queue.append((other_graph, current_depth + 1))
        
        return dependent_graphs
    
    def _print_extraction_statistics(self, extracted: Dict[str, Any]):
        """Print extraction statistics"""
        stats = extracted['statistics']
        
        print(f"\n📊 EXTRACTION STATISTICS:")
        print(f"   • Target Graph: {extracted['target_graph_id']} - {extracted['target_graph_name']}")
        print(f"   • Include Dependencies: {extracted['include_dependencies']}")
        print(f"   • Dependency Depth: {extracted['dependency_depth']}")
        print(f"   • Total Graphs: {stats['total_graphs']}")
        print(f"   • Total Vertices: {stats['total_vertices']}")
        print(f"   • Total Flows: {stats['total_flows']}")
        print(f"   • Total Ports: {stats['total_ports']}")
        print(f"   • Total Flow Connections: {stats['total_flow_connections']}")
        print(f"   • Total Config Flows: {stats['total_config_flows']}")
        print(f"   • Total Port Bindings: {stats['total_port_bindings']}")
    
    def save_extracted_subgraph(self, extracted: Dict[str, Any], output_folder: str = "output", output_filename: str = None, graph_id: str = None):
        """Save extracted subgraph to JSON file"""
        # Generate output filename if not provided
        if output_filename is None:
            if graph_id:
                output_filename = f"subgraph_{graph_id}_extracted.json"
            else:
                output_filename = "extracted_subgraph.json"
        
        # Ensure output folder exists
        os.makedirs(output_folder, exist_ok=True)
        
        # Save to file
        output_path = os.path.join(output_folder, output_filename)
        with open(output_path, 'w') as f:
            json.dump(extracted, f, indent=2)
        
        print(f"\n💾 Extracted subgraph saved to: {output_path}")
        return output_path
    
    def list_available_graphs(self) -> List[Dict[str, str]]:
        """List all available graphs"""
        graphs = []
        for graph_id, graph_info in self.graphs_by_id.items():
            graphs.append({
                'id': graph_id,
                'name': graph_info['data']['name'],
                'vertex_count': len(self.vertices_by_graph.get(graph_id, []))
            })
        
        return sorted(graphs, key=lambda x: x['name'])
    
    def print_available_graphs(self):
        """Print all available graphs"""
        print("📋 AVAILABLE GRAPHS:")
        print("=" * 50)
        
        graphs = self.list_available_graphs()
        for graph in graphs:
            print(f"   • ID: {graph['id']:>4} | Vertices: {graph['vertex_count']:>3} | Name: {graph['name']}")
        
        print(f"\nTotal: {len(graphs)} graphs available")
    
    def generate_simplified_connections(self, extracted: Dict[str, Any]) -> Dict[str, Any]:
        """Generate simplified vertex connections with embedded connection arrays"""
        print(f"🔗 Generating simplified vertex connections...")
        
        # Build port to vertex mapping
        port_to_vertex = {}
        for port_key, port_data in extracted['ports'].items():
            port_id = port_data['component_id']
            vertex_id = port_data.get('vertex_id')
            if vertex_id:
                port_to_vertex[port_id] = vertex_id
        
        # Initialize vertex info mapping with connection arrays
        vertex_info = {}
        for vertex_key, vertex_data in extracted['vertices'].items():
            vertex_id = vertex_data['component_id']
            vertex_type = vertex_data.get('component_type', 'XXGpvertex')
            raw_content = vertex_data.get('raw_content', '')

            # Extract vertex name from raw_content
            vertex_name = self._extract_vertex_name(raw_content, vertex_id)

            # Extract file metadata (file_type, file_name, keys)
            file_metadata = self._extract_file_metadata(raw_content, vertex_type)

            # Build vertex info with metadata
            vertex_info[vertex_id] = {
                'type': vertex_type,
                'raw_content': raw_content,
                'vertex_name': vertex_name,
                'data_in': [],
                'data_out': [],
                'config_in': [],
                'config_out': []
            }

            # Add file_type and file_name for functional vertices
            if vertex_type == "XXGfvertex":
                vertex_info[vertex_id]['file_type'] = file_metadata.get('file_type', '')
                vertex_info[vertex_id]['file_name'] = file_metadata.get('file_name', '')

            # Add keys for all vertices
            vertex_info[vertex_id]['keys'] = file_metadata.get('keys', '')
        
        # Extract data connections and populate vertex arrays
        flows_by_id = defaultdict(list)
        
        for conn_key, conn_data in extracted['flow_connections'].items():
            port_id = conn_data['port_id']
            flow_id = conn_data['flow_id']
            is_source = conn_data['is_source']
            
            if port_id in port_to_vertex:
                vertex_id = port_to_vertex[port_id]
                flows_by_id[flow_id].append({
                    'vertex_id': vertex_id,
                    'is_source': is_source
                })
        
        # Create direct vertex connections and populate arrays
        for flow_id, connections in flows_by_id.items():
            sources = [c['vertex_id'] for c in connections if not c['is_source']]  # Output ports
            targets = [c['vertex_id'] for c in connections if c['is_source']]      # Input ports
            
            for source_vertex in sources:
                for target_vertex in targets:
                    if source_vertex != target_vertex:
                        # Add to data_out of source vertex
                        if source_vertex in vertex_info and target_vertex not in vertex_info[source_vertex]['data_out']:
                            vertex_info[source_vertex]['data_out'].append(target_vertex)
                        
                        # Add to data_in of target vertex
                        if target_vertex in vertex_info and source_vertex not in vertex_info[target_vertex]['data_in']:
                            vertex_info[target_vertex]['data_in'].append(source_vertex)
        
        # Extract config connections and populate arrays
        for config_key, config_data in extracted['config_flows'].items():
            source_id = config_data.get('source_component_id')
            target_id = config_data.get('target_component_id')
            
            if source_id and target_id and source_id != target_id:
                # Add to config_out of source vertex
                if source_id in vertex_info and target_id not in vertex_info[source_id]['config_out']:
                    vertex_info[source_id]['config_out'].append(target_id)
                
                # Add to config_in of target vertex
                if target_id in vertex_info and source_id not in vertex_info[target_id]['config_in']:
                    vertex_info[target_id]['config_in'].append(source_id)
        
        # Sort all connection arrays for consistency
        for vertex_id, vertex_data in vertex_info.items():
            vertex_data['data_in'].sort()
            vertex_data['data_out'].sort()
            vertex_data['config_in'].sort()
            vertex_data['config_out'].sort()
        
        # Calculate summary statistics
        total_data_connections = sum(len(v['data_out']) for v in vertex_info.values())
        total_config_connections = sum(len(v['config_out']) for v in vertex_info.values())
        
        simplified = {
            'vertices': vertex_info,
            'summary': {
                'total_vertices': len(vertex_info),
                'total_data_connections': total_data_connections,
                'total_config_connections': total_config_connections
            }
        }
        
        return simplified
    

    
    def print_simplified_connections(self, simplified: Dict[str, Any]):
        """Print simplified connections in a concise format"""
        print(f"\n🔗 SIMPLIFIED VERTEX CONNECTIONS")
        print("=" * 50)
        
        # Print vertex summary with connections
        vertices = simplified['vertices']
        print(f"📊 Vertices ({len(vertices)}):")
        for vertex_id, info in sorted(vertices.items()):
            vertex_type = info['type']
            type_indicator = 'F' if vertex_type == 'XXGfvertex' else 'P'

            # Build connection summary
            data_in_count = len(info['data_in'])
            data_out_count = len(info['data_out'])
            config_in_count = len(info['config_in'])
            config_out_count = len(info['config_out'])

            conn_summary = f"D:{data_in_count}→{data_out_count} C:{config_in_count}→{config_out_count}"
            print(f"   • {vertex_id}({type_indicator}): {vertex_type} [{conn_summary}]")
        
        # Print detailed connections for vertices with connections
        vertices_with_connections = {vid: vdata for vid, vdata in vertices.items() 
                                   if vdata['data_in'] or vdata['data_out'] or vdata['config_in'] or vdata['config_out']}
        
        if vertices_with_connections:
            print(f"\n🔄 Vertex Connection Details:")
            for vertex_id, info in sorted(vertices_with_connections.items()):
                type_indicator = 'F' if info['type'] == 'XXGfvertex' else 'P'
                print(f"   • {vertex_id}({type_indicator}):")

                if info['data_in']:
                    print(f"     📥 Data In:  {', '.join(info['data_in'])}")
                if info['data_out']:
                    print(f"     📤 Data Out: {', '.join(info['data_out'])}")
                if info['config_in']:
                    print(f"     ⚙️  Config In:  {', '.join(info['config_in'])}")
                if info['config_out']:
                    print(f"     🔧 Config Out: {', '.join(info['config_out'])}")
        
        # Print summary
        summary = simplified['summary']
        print(f"\n📊 Summary:")
        print(f"   • Vertices: {summary['total_vertices']}")
        print(f"   • Data Connections: {summary['total_data_connections']}")
        print(f"   • Config Connections: {summary['total_config_connections']}")
    
    def save_simplified_connections(self, simplified: Dict[str, Any], output_folder: str = "output", output_filename: str = None):
        """Save simplified connections to JSON file"""
        # Generate output filename if not provided
        if output_filename is None:
            output_filename = "simplified_connections.json"
        
        # Ensure output folder exists
        os.makedirs(output_folder, exist_ok=True)
        
        # Save to file
        output_path = os.path.join(output_folder, output_filename)
        with open(output_path, 'w') as f:
            json.dump(simplified, f, indent=2)
        
        print(f"💾 Simplified connections saved to: {output_path}")
        return output_path
    
    def generate_subgraph_dot(self, extracted: Dict[str, Any], output_folder: str = "output", output_filename: str = None, graph_id: str = None):
        """Generate DOT visualization for extracted subgraph"""
        print(f"🎨 Generating DOT visualization for subgraph...")
        
        # Generate output filename if not provided
        if output_filename is None:
            if graph_id:
                output_filename = f"subgraph_{graph_id}_graph.dot"
            else:
                output_filename = "extracted_subgraph.dot"
        
        # Ensure output folder exists
        os.makedirs(output_folder, exist_ok=True)
        
        dot_content = []
        dot_content.append("digraph ExtractedSubgraph {")
        dot_content.append("    rankdir=LR;")
        dot_content.append("    node [fontname=\"Arial\", fontsize=10];")
        dot_content.append("    edge [fontname=\"Arial\", fontsize=8];")
        dot_content.append("")
        
        # Add title
        target_name = extracted['target_graph_name']
        target_id = extracted['target_graph_id']
        dot_content.append(f"    labelloc=\"t\";")
        dot_content.append(f"    label=\"Extracted Subgraph: {target_name} (ID: {target_id})\";")
        dot_content.append("")
        
        # Generate clusters for each graph
        for graph_key, graph_data in extracted['graphs'].items():
            graph_id = graph_data['component_id']
            graph_name = graph_data['name']
            
            # Find vertices in this graph
            vertices_in_graph = []
            for link_key, link_data in extracted['graph_vertex_links'].items():
                if link_data['graph_id'] == graph_id:
                    vertices_in_graph.append((link_data['vertex_id'], link_data['vertex_name']))
            
            if vertices_in_graph:
                dot_content.append(f"    subgraph cluster_{graph_id} {{")
                dot_content.append(f"        label=\"{graph_name} (ID: {graph_id})\";")
                dot_content.append("        style=filled;")
                
                # Use different colors for target vs dependency graphs
                if graph_id == target_id:
                    dot_content.append("        fillcolor=lightblue;")
                    dot_content.append("        color=blue;")
                else:
                    dot_content.append("        fillcolor=lightgray;")
                    dot_content.append("        color=gray;")
                
                dot_content.append("")
                
                # Add vertices
                for vertex_id, vertex_name in vertices_in_graph:
                    # Get vertex type and extract component name
                    vertex_type = "XXGpvertex"  # default
                    component_name = ""
                    raw_content = ""

                    for v_key, v_data in extracted['vertices'].items():
                        if v_data['component_id'] == vertex_id:
                            vertex_type = v_data['component_type']
                            raw_content = v_data.get('raw_content', '')
                            # Extract component name from raw_content
                            component_name = self._extract_vertex_name(raw_content, vertex_id)
                            break

                    # Use component_name if available, otherwise fall back to cleaned link name
                    if component_name:
                        clean_name = component_name
                    else:
                        clean_name = self._extract_clean_vertex_name_from_link(vertex_name, vertex_id)

                    # Extract file metadata (file_type, file_name, keys)
                    file_metadata = self._extract_file_metadata(raw_content, vertex_type)

                    # Build label with metadata
                    label_parts = [f"v{vertex_id}", clean_name]

                    # Add file_type and file_name for functional vertices
                    if vertex_type == "XXGfvertex":
                        if file_metadata.get('file_type'):
                            label_parts.append(f"Type: {file_metadata['file_type']}")
                        if file_metadata.get('file_name'):
                            label_parts.append(f"File: {file_metadata['file_name']}")

                    # Add keys for all vertices if present
                    if file_metadata.get('keys'):
                        label_parts.append(f"Keys: {file_metadata['keys']}")

                    # Check if this vertex is also a subgraph
                    is_subgraph = vertex_id in [g['component_id'] for g in extracted['graphs'].values()]

                    # Add vertex type indicator
                    if vertex_type == "XXGfvertex":
                        label_parts.append("(Functional)")
                    else:
                        label_parts.append("(Parameter)")

                    label = "\\n".join(label_parts)

                    # Style based on type
                    if vertex_type == "XXGfvertex":
                        shape = "cylinder"
                        fillcolor = "#ffe5cc" if is_subgraph else "white"
                        dot_content.append(f"        v{vertex_id} [label=\"{label}\", shape=\"{shape}\", fillcolor=\"{fillcolor}\", style=\"filled\"];")
                    else:
                        shape = "box"
                        fillcolor = "#ffe5cc" if is_subgraph else "#C8E6C9"
                        dot_content.append(f"        v{vertex_id} [label=\"{label}\", shape=\"{shape}\", fillcolor=\"{fillcolor}\", style=\"rounded,filled\"];")

                dot_content.append("    }")
                dot_content.append("")
        
        # Add data flow connections
        dot_content.append("    // Data Flow Connections")
        port_to_vertex = {}
        for port_key, port_data in extracted['ports'].items():
            port_id = port_data['component_id']
            vertex_id = port_data.get('vertex_id')
            if vertex_id:
                port_to_vertex[port_id] = vertex_id
        
        # Group flow connections by flow
        flows_by_id = defaultdict(list)
        for conn_key, conn_data in extracted['flow_connections'].items():
            port_id = conn_data['port_id']
            flow_id = conn_data['flow_id']
            is_source = conn_data['is_source']
            
            if port_id in port_to_vertex:
                vertex_id = port_to_vertex[port_id]
                flows_by_id[flow_id].append({
                    'vertex_id': vertex_id,
                    'is_source': is_source,
                    'port_id': port_id
                })
        
        # Create edges
        for flow_id, connections in flows_by_id.items():
            sources = [c for c in connections if not c['is_source']]  # Output ports
            targets = [c for c in connections if c['is_source']]      # Input ports
            
            for source in sources:
                for target in targets:
                    source_vertex = source['vertex_id']
                    target_vertex = target['vertex_id']
                    
                    if source_vertex != target_vertex:
                        dot_content.append(f"    v{source_vertex} -> v{target_vertex} [color=\"blue\", label=\"f{flow_id}\"];")
        
        dot_content.append("")
        
        # Add config flow connections
        dot_content.append("    // Config Flow Connections")
        for config_key, config_data in extracted['config_flows'].items():
            source_id = config_data.get('source_component_id')
            target_id = config_data.get('target_component_id')
            
            if source_id and target_id and source_id != target_id:
                config_id = config_data.get('component_id', 'c')
                dot_content.append(f"    v{source_id} -> v{target_id} [color=\"red\", style=\"dashed\", label=\"cf{config_id}\"];")
        
        dot_content.append("")
        dot_content.append("}")
        
        # Write to file
        output_path = os.path.join(output_folder, output_filename)
        with open(output_path, 'w') as f:
            f.write('\n'.join(dot_content))
        
        print(f"✅ DOT visualization saved to: {output_path}")
        return output_path
    
    def _extract_clean_vertex_name_from_link(self, vertex_name: str, vertex_id: str) -> str:
        """Extract clean vertex name from graph-vertex link data"""
        import re
        
        # vertex_name from link contains raw text, try to extract meaningful name
        name_match = re.search(r'\{([^|}]+)', vertex_name)
        if name_match:
            clean_name = name_match.group(1)
            # Remove common prefixes
            clean_name = re.sub(r'^_\d+_', '', clean_name)
            return clean_name
        
        # Fallback
        return f"vertex_{vertex_id}"
    
    def _find_subgraph_references(self, graph_id: str) -> List[str]:
        """Find subgraph references within a graph using XXGgraph_vertex_vertex entries"""
        subgraph_refs = []
        
        # Look for XXGgraph_vertex_vertex entries where graph_id matches
        for link_key, link_data in self.components.get('graph_vertex_links', {}).items():
            if (link_data.get('graph_id') == graph_id and 
                link_data.get('vertex_id') != graph_id):  # vertex_id is actually a subgraph reference
                
                # Check if the vertex_id is actually another graph
                referenced_vertex_id = link_data.get('vertex_id')
                if referenced_vertex_id in self.graphs_by_id:
                    subgraph_refs.append(referenced_vertex_id)
        
        return list(set(subgraph_refs))  # Remove duplicates
    
    def generate_all_subgraphs_simplified(self, output_folder: str = "output", output_filename: str = None):
        """Generate simplified connections for ALL subgraphs in a single JSON file"""
        print(f"🔗 GENERATING ALL SUBGRAPHS SIMPLIFIED CONNECTIONS")
        print("=" * 60)
        
        # Generate output filename if not provided
        if output_filename is None:
            output_filename = "all_subgraphs_simplified.json"
        
        # Ensure output folder exists
        os.makedirs(output_folder, exist_ok=True)
        
        all_subgraphs = {}
        
        # Get all available graphs
        available_graphs = self.list_available_graphs()
        total_graphs = len(available_graphs)
        
        print(f"📊 Processing {total_graphs} subgraphs...")
        
        for i, graph_info in enumerate(available_graphs, 1):
            graph_id = graph_info['id']
            graph_name = graph_info['name']
            
            print(f"   [{i:2d}/{total_graphs}] Processing graph {graph_id}: {graph_name}")
            
            try:
                # Extract subgraph without dependencies first to get core structure
                extracted = self.extract_subgraph(
                    graph_id=graph_id,
                    include_dependencies=False,
                    dependency_depth=0
                )
                
                # Generate simplified connections
                simplified = self.generate_simplified_connections(extracted)
                
                # Find subgraph references (actual subgraphs referenced within this graph)
                dependencies = self._find_subgraph_references(graph_id)
                
                # Get the raw_content of the graph definition
                graph_raw_content = ""
                for graph_key, graph_data in extracted['graphs'].items():
                    if graph_data['component_id'] == graph_id:
                        graph_raw_content = graph_data.get('raw_content', '')
                        break
                
                # Create subgraph entry
                subgraph_entry = {
                    'id': graph_id,
                    'name': graph_name,
                    'raw_content': graph_raw_content,
                    'vertices': simplified['vertices'],
                    'subgraph_references': dependencies,
                    'statistics': {
                        'vertex_count': len(simplified['vertices']),
                        'data_connection_count': simplified['summary']['total_data_connections'],
                        'config_connection_count': simplified['summary']['total_config_connections'],
                        'subgraph_reference_count': len(dependencies)
                    }
                }
                
                # Use graph ID as key
                all_subgraphs[graph_id] = subgraph_entry
                
            except Exception as e:
                print(f"      ❌ Failed to process graph {graph_id}: {e}")
                
                # Try to get raw_content even for failed graphs
                graph_raw_content = ""
                if graph_id in self.graphs_by_id:
                    graph_raw_content = self.graphs_by_id[graph_id]['data'].get('raw_content', '')
                
                # Add minimal entry for failed graphs
                all_subgraphs[graph_id] = {
                    'id': graph_id,
                    'name': graph_name,
                    'raw_content': graph_raw_content,
                    'error': str(e),
                    'vertices': {},
                    'subgraph_references': [],
                    'statistics': {
                        'vertex_count': 0,
                        'data_connection_count': 0,
                        'config_connection_count': 0,
                        'subgraph_reference_count': 0
                    }
                }
        
        # Create final structure
        final_structure = {
            'metadata': {
                'total_subgraphs': len(all_subgraphs),
                'successful_extractions': len([sg for sg in all_subgraphs.values() if 'error' not in sg]),
                'failed_extractions': len([sg for sg in all_subgraphs.values() if 'error' in sg]),
                'generation_timestamp': self._get_timestamp()
            },
            'subgraphs': all_subgraphs
        }
        
        # Save to file
        output_path = os.path.join(output_folder, output_filename)
        with open(output_path, 'w') as f:
            json.dump(final_structure, f, indent=2)
        
        print(f"\n✅ All subgraphs simplified connections generated!")
        print(f"   📁 Output file: {output_path}")
        print(f"   📊 Total subgraphs: {final_structure['metadata']['total_subgraphs']}")
        print(f"   ✅ Successful: {final_structure['metadata']['successful_extractions']}")
        print(f"   ❌ Failed: {final_structure['metadata']['failed_extractions']}")
        
        return final_structure
    
    def _find_subgraph_dependencies(self, graph_id: str) -> List[Dict[str, str]]:
        """Find other subgraphs that this subgraph depends on through flow connections"""
        dependencies = []
        
        # Get vertices in this graph
        vertices_in_graph = self.vertices_by_graph.get(graph_id, [])
        
        # Find flows connected to these vertices
        connected_flows = set()
        for vertex_id in vertices_in_graph:
            for flow_conn in self.flow_connections_by_vertex.get(vertex_id, []):
                connected_flows.add(flow_conn['flow_id'])
        
        # Find other graphs that share these flows
        dependent_graphs = set()
        for flow_id in connected_flows:
            for flow_conn in self.flow_connections_by_flow.get(flow_id, []):
                vertex_id = flow_conn['vertex_id']
                other_graph = self.graph_by_vertex.get(vertex_id)
                
                if other_graph and other_graph != graph_id:
                    dependent_graphs.add(other_graph)
        
        # Convert to list of dependency info
        for dep_graph_id in dependent_graphs:
            if dep_graph_id in self.graphs_by_id:
                dep_graph_name = self.graphs_by_id[dep_graph_id]['data']['name']
                dependencies.append({
                    'graph_id': dep_graph_id,
                    'graph_name': dep_graph_name
                })
        
        return sorted(dependencies, key=lambda x: x['graph_id'])
    
    def _get_timestamp(self) -> str:
        """Get current timestamp"""
        from datetime import datetime
        return datetime.now().isoformat()
    
    def print_all_subgraphs_summary(self, all_subgraphs_data: Dict[str, Any]):
        """Print summary of all subgraphs"""
        print(f"\n📊 ALL SUBGRAPHS SUMMARY")
        print("=" * 50)
        
        metadata = all_subgraphs_data['metadata']
        subgraphs = all_subgraphs_data['subgraphs']
        
        print(f"Total Subgraphs: {metadata['total_subgraphs']}")
        print(f"Successful Extractions: {metadata['successful_extractions']}")
        print(f"Failed Extractions: {metadata['failed_extractions']}")
        
        # Show top subgraphs by vertex count
        successful_subgraphs = [(sg_id, sg_data) for sg_id, sg_data in subgraphs.items() if 'error' not in sg_data]
        top_subgraphs = sorted(successful_subgraphs, key=lambda x: x[1]['statistics']['vertex_count'], reverse=True)[:10]
        
        print(f"\n🔝 Top 10 Subgraphs by Vertex Count:")
        for i, (sg_id, sg_data) in enumerate(top_subgraphs, 1):
            stats = sg_data['statistics']
            print(f"   {i:2d}. ID: {sg_id:>4} | V: {stats['vertex_count']:>2} | DC: {stats['data_connection_count']:>2} | CC: {stats['config_connection_count']:>2} | {sg_data['name']}")
        
        # Show subgraphs with most connections
        top_connections = sorted(successful_subgraphs, key=lambda x: x[1]['statistics']['data_connection_count'], reverse=True)[:5]
        
        print(f"\n🔗 Top 5 Subgraphs by Data Connections:")
        for i, (sg_id, sg_data) in enumerate(top_connections, 1):
            stats = sg_data['statistics']
            print(f"   {i:2d}. ID: {sg_id:>4} | DC: {stats['data_connection_count']:>2} | V: {stats['vertex_count']:>2} | {sg_data['name']}")
        
        # Show failed extractions if any
        failed_subgraphs = [(sg_id, sg_data) for sg_id, sg_data in subgraphs.items() if 'error' in sg_data]
        if failed_subgraphs:
            print(f"\n❌ Failed Extractions ({len(failed_subgraphs)}):")
            for sg_id, sg_data in failed_subgraphs[:5]:  # Show first 5 failures
                print(f"   • ID: {sg_id:>4} | {sg_data['name']} | Error: {sg_data['error']}")
            if len(failed_subgraphs) > 5:
                print(f"   ... and {len(failed_subgraphs) - 5} more failures")

def main():
    """Main function for testing"""
    import sys
    
    print("🚀 SUBGRAPH EXTRACTOR")
    print("=" * 50)
    
    # Parse command line arguments
    if len(sys.argv) < 2:
        print("Usage: python subgraph_extractor.py <components_file> [output_folder]")
        print("Example: python subgraph_extractor.py enhanced_components.json")
        print("Example: python subgraph_extractor.py enhanced_components.json output")
        return
    
    components_file = sys.argv[1]
    output_folder = sys.argv[2] if len(sys.argv) > 2 else "output"
    
    try:
        # Initialize extractor
        extractor = SubgraphExtractor(components_file)
        
        # Generate ALL subgraphs simplified connections
        print("🔗 Generating simplified connections for ALL subgraphs...")
        
        # Generate filename for all subgraphs
        input_name = Path(components_file).stem
        # Remove "_components" suffix if present to avoid redundant naming
        if input_name.endswith("_components"):
            input_name = input_name[:-11]  # Remove "_components"
        all_subgraphs_filename = f"{input_name}_subgraphs.json"
        
        all_subgraphs_data = extractor.generate_all_subgraphs_simplified(output_folder, all_subgraphs_filename)
        extractor.print_all_subgraphs_summary(all_subgraphs_data)
        
        print(f"\n✅ Subgraph extraction complete!")
        print(f"   🌐 All subgraphs: {os.path.join(output_folder, all_subgraphs_filename)}")
        
    except Exception as e:
        print(f"❌ Error during subgraph extraction: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()