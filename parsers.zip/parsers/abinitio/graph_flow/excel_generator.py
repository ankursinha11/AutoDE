"""
GraphFlow Excel Generator
Generates Excel representation of parsed AbInitio graph components
"""

import json
from pathlib import Path
from typing import Dict, Any
import pandas as pd


class GraphFlowExcelGenerator:
    """Generates Excel files from parsed AbInitio JSON"""

    def __init__(self):
        pass

    def generate_from_parsed_json(
        self,
        parsed_json_path: str,
        output_folder: str = "outputs/graphflows",
        base_filename: str = None
    ) -> Dict[str, Any]:
        """
        Generate GraphFlow Excel from parsed JSON

        Args:
            parsed_json_path: Path to parsed components JSON
            output_folder: Output folder for Excel file
            base_filename: Base name for output file (optional)

        Returns:
            Dict with success status and file paths
        """
        try:
            parsed_json_path = Path(parsed_json_path)
            output_folder = Path(output_folder)
            output_folder.mkdir(parents=True, exist_ok=True)

            # Load parsed JSON
            with open(parsed_json_path, 'r', encoding='utf-8') as f:
                data = json.load(f)

            # Extract components
            vertices = data.get('vertices', {})
            flows = data.get('flows', {})
            ports = data.get('ports', {})
            graphs = data.get('graphs', {})

            # Prepare output filename
            if not base_filename:
                base_filename = parsed_json_path.stem.replace('_components', '')
            excel_file = output_folder / f"{base_filename}_graphflow.xlsx"

            # Create Excel file with multiple sheets
            with pd.ExcelWriter(str(excel_file), engine='openpyxl') as writer:

                # Sheet 1: Vertices
                vertices_data = []
                for vid, vdata in vertices.items():
                    vertices_data.append({
                        'Vertex ID': vid,
                        'Name': vdata.get('name', ''),
                        'Type': vdata.get('type', ''),
                        'Layout': vdata.get('attributes', {}).get('layout', ''),
                        'DML': str(vdata.get('attributes', {}).get('dml', ''))[:100],  # Truncate long DML
                        'Subgraph ID': vdata.get('attributes', {}).get('subgraph_id', '')
                    })

                if vertices_data:
                    df_vertices = pd.DataFrame(vertices_data)
                    df_vertices.to_excel(writer, sheet_name='Vertices', index=False)

                # Sheet 2: Flows
                flows_data = []
                for fid, fdata in flows.items():
                    flows_data.append({
                        'Flow ID': fid,
                        'From Vertex': fdata.get('from_vertex', ''),
                        'From Port': fdata.get('from_port', ''),
                        'To Vertex': fdata.get('to_vertex', ''),
                        'To Port': fdata.get('to_port', ''),
                        'Connection': f"{fdata.get('from_vertex', '')}:{fdata.get('from_port', '')} → {fdata.get('to_vertex', '')}:{fdata.get('to_port', '')}"
                    })

                if flows_data:
                    df_flows = pd.DataFrame(flows_data)
                    df_flows.to_excel(writer, sheet_name='Flows', index=False)

                # Sheet 3: Ports
                ports_data = []
                for pid, pdata in ports.items():
                    ports_data.append({
                        'Port ID': pid,
                        'Name': pdata.get('name', ''),
                        'Type': pdata.get('type', ''),
                        'Vertex': pdata.get('vertex', ''),
                        'Layout': pdata.get('layout', '')
                    })

                if ports_data:
                    df_ports = pd.DataFrame(ports_data)
                    df_ports.to_excel(writer, sheet_name='Ports', index=False)

                # Sheet 4: Graphs/Subgraphs
                graphs_data = []
                for gid, gdata in graphs.items():
                    graphs_data.append({
                        'Graph ID': gid,
                        'Name': gdata.get('name', ''),
                        'Type': gdata.get('type', ''),
                        'Vertices Count': len(gdata.get('vertices', [])),
                        'Flows Count': len(gdata.get('flows', []))
                    })

                if graphs_data:
                    df_graphs = pd.DataFrame(graphs_data)
                    df_graphs.to_excel(writer, sheet_name='Graphs', index=False)

                # Sheet 5: Summary
                summary_data = [{
                    'Graph Name': base_filename,
                    'Total Vertices': len(vertices),
                    'Total Flows': len(flows),
                    'Total Ports': len(ports),
                    'Total Graphs': len(graphs),
                    'Parsed JSON': str(parsed_json_path)
                }]
                df_summary = pd.DataFrame(summary_data)
                df_summary.to_excel(writer, sheet_name='Summary', index=False)

            return {
                'success': True,
                'excel_file': str(excel_file),
                'vertices_count': len(vertices),
                'flows_count': len(flows),
                'ports_count': len(ports)
            }

        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }


# For backward compatibility
class GraphFlowGenerator(GraphFlowExcelGenerator):
    """Alias for GraphFlowExcelGenerator"""
    pass
