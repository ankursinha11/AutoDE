#!/usr/bin/env python3
"""
Enhanced DOT generator that includes config flows and binding connections with graph IDs in labels
"""

import json
import os
import re
from pathlib import Path
from collections import defaultdict
from typing import Tuple, Dict

class EnhancedDotGenerator:
    """Enhanced DOT generator with config flow support"""
    
    def __init__(self, components_file):
        with open(components_file, 'r') as f:
            self.components = json.load(f)
    
    def generate_enhanced_dot(self, output_folder: str = "output", output_filename: str = None, input_filename: str = None):
        """Generate enhanced DOT file with config flows"""
        print("🎨 GENERATING ENHANCED DOT WITH CONFIG FLOWS AND GRAPH IDS")
        
        # Generate output filename if not provided
        if output_filename is None:
            if input_filename:
                input_name = Path(input_filename).stem
                # Remove "_components" suffix if present to avoid redundant naming
                if input_name.endswith("_components"):
                    input_name = input_name[:-11]  # Remove "_components"
                output_filename = f"{input_name}_graph.dot"
            else:
                output_filename = "enhanced_graph.dot"
        
        # Ensure output folder exists
        os.makedirs(output_folder, exist_ok=True)
        
        dot_content = []
        dot_content.append("digraph AbInitioFlowEnhanced {")
        dot_content.append("    rankdir=LR;")
        dot_content.append("    ranksep=1.5;")
        dot_content.append("    nodesep=0.5;")
        dot_content.append("    node [fontname=\"Arial\", fontsize=10];")
        dot_content.append("    edge [fontname=\"Arial\", fontsize=9];")
        dot_content.append("")
        
        # Generate graph clusters
        self._generate_graph_clusters(dot_content)
        
        # Generate data flow connections
        self._generate_data_flow_connections(dot_content)

        # Generate config flow connections (no ports shown)
        self._generate_config_flow_connections(dot_content)

        # Generate binding connections
        self._generate_binding_connections(dot_content)
        
        dot_content.append("}")
        
        # Write to file with UTF-8 encoding to support Unicode characters
        output_path = os.path.join(output_folder, output_filename)
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(dot_content))
        
        print(f"✅ Enhanced DOT file generated: {output_path}")
        return output_path
        
        # Generate statistics
        self._print_statistics()
    
    def _generate_graph_clusters(self, dot_content):
        """Generate graph clusters with vertices"""
        print("   📊 Generating graph clusters with IDs...")
        
        # Group vertices by graph
        vertices_by_graph = defaultdict(list)
        
        # Use graph_vertex_links to determine which vertices belong to which graphs
        for link_key, link_data in self.components.get('graph_vertex_links', {}).items():
            graph_id = link_data['graph_id']
            vertex_id = link_data['vertex_id']
            vertex_name = link_data['vertex_name']
            vertices_by_graph[graph_id].append((vertex_id, vertex_name))
        
        # Generate clusters
        for graph_key, graph_data in self.components.get('graphs', {}).items():
            graph_id = graph_data['component_id']
            graph_name = graph_data['name']
            
            if graph_id in vertices_by_graph:
                dot_content.append(f"    subgraph cluster_{graph_id} {{")
                # Add graph ID to the label
                dot_content.append(f"        label=\"{graph_name} (ID: {graph_id})\";")
                dot_content.append("        style=filled;")
                dot_content.append("        fillcolor=lightgray;")
                dot_content.append("        color=gray;")
                dot_content.append("")
                
                # Add vertices to cluster
                for vertex_id, vertex_name in vertices_by_graph[graph_id]:
                    # Get vertex data to extract component name from raw_content
                    vertex_data = self._get_vertex_data(vertex_id)

                    if vertex_data:
                        raw_content = vertex_data.get('raw_content', '')
                        # Extract component name from raw_content
                        component_name = self._extract_component_name(raw_content, vertex_id)

                        # Use component_name if available, otherwise fall back to cleaned link name
                        if component_name:
                            clean_name = component_name
                        else:
                            clean_name = self._extract_clean_vertex_name(vertex_name, vertex_id)
                    else:
                        clean_name = self._extract_clean_vertex_name(vertex_name, vertex_id)
                        raw_content = ""

                    # Determine vertex type and styling
                    vertex_type = self._get_vertex_type(vertex_id)

                    # Extract file metadata (file_type, file_name, keys)
                    file_metadata = self._extract_file_metadata(raw_content, vertex_type)

                    # Build label with metadata
                    label_parts = [f"v{vertex_id}", clean_name]

                    # Add file_type and file_name for functional vertices
                    if vertex_type == "XXGfvertex":
                        if file_metadata.get('file_type'):
                            label_parts.append(f"Type: {file_metadata['file_type']}")
                        if file_metadata.get('file_name'):
                            label_parts.append(f"File: {file_metadata['file_name']}")

                    # Add keys for all vertices if present
                    if file_metadata.get('keys'):
                        label_parts.append(f"Keys: {file_metadata['keys']}")

                    # Add major_key for all vertices if present
                    if file_metadata.get('major_key'):
                        label_parts.append(f"Major Key: {file_metadata['major_key']}")

                    # Add minor_key for all vertices if present
                    if file_metadata.get('minor_key'):
                        label_parts.append(f"Minor Key: {file_metadata['minor_key']}")

                    # Add select for all vertices if present
                    if file_metadata.get('select'):
                        label_parts.append(f"Select: {file_metadata['select']}")

                    # Check if this vertex is also a subgraph
                    is_subgraph = vertex_id in self.components.get('graphs', {}).values() or any(g['component_id'] == vertex_id for g in self.components.get('graphs', {}).values())

                    # Add vertex type indicator
                    if vertex_type == "XXGfvertex":
                        label_parts.append("(Functional)")
                        shape = "cylinder"
                        fillcolor = "#ffe5cc" if is_subgraph else "lightblue"
                    else:  # XXGpvertex
                        label_parts.append("(Parameter)")
                        shape = "box"
                        fillcolor = "#ffe5cc" if is_subgraph else "#C8E6C9"
                        style = "rounded,filled"

                    label = "\\n".join(label_parts)

                    if vertex_type == "XXGfvertex":
                        dot_content.append(f"        v{vertex_id} [label=\"{label}\", shape=\"{shape}\", color=\"black\", fillcolor=\"{fillcolor}\", style=\"filled\"];")
                    else:
                        dot_content.append(f"        v{vertex_id} [label=\"{label}\", shape=\"{shape}\", color=\"black\", fillcolor=\"{fillcolor}\", style=\"{style}\"];")

                dot_content.append("    }")
                dot_content.append("")
    
    def _get_vertex_type(self, vertex_id):
        """Get vertex type by ID"""
        for vertex_key, vertex_data in self.components.get('vertices', {}).items():
            if vertex_data['component_id'] == vertex_id:
                return vertex_data['component_type']
        return "XXGpvertex"  # Default

    def _get_vertex_data(self, vertex_id):
        """Get vertex data by ID"""
        for vertex_key, vertex_data in self.components.get('vertices', {}).items():
            if vertex_data['component_id'] == vertex_id:
                return vertex_data
        return None

    def _extract_component_name(self, raw_content: str, vertex_id: str = "") -> str:
        """
        Extract component name from raw_content using the same logic as subgraph_extractor

        Args:
            raw_content: The raw_content field from a vertex
            vertex_id: The vertex ID (optional)

        Returns:
            The extracted component name or empty string if not found
        """
        if not raw_content:
            return ""

        # Break down the block into sections
        start_section, middle_section, end_section = self._break_down_block(raw_content)

        if not end_section:
            return ""

        # Extract details from end section
        details = self._extract_end_section_details(end_section, vertex_id)

        # Return component_name if found
        return details.get("component_name", "")

    def _break_down_block(self, block: str) -> Tuple[str, str, str]:
        """
        Break down a vertex raw_content block into start, middle, and end sections

        Args:
            block: The raw_content string from a vertex

        Returns:
            Tuple of (start_section, middle_section, end_section)
        """
        # Pattern for parameter_set blocks
        internal_pattern = r'(\{\d+\|XXparameter_set\|@@@@\{)'
        internal_match = re.search(internal_pattern, block, re.DOTALL)

        if internal_match:
            start_index = internal_match.start()
            stack = []
            end_index = -1

            for i in range(start_index, len(block)):
                if block[i] == "{":
                    stack.append("{")
                elif block[i] == "}":
                    if stack:
                        stack.pop()
                    if not stack:
                        end_index = i + 1
                        break

            if end_index != -1:
                return (
                    block[:start_index].strip(),
                    block[start_index:end_index].strip(),
                    block[end_index:].strip()
                )
        else:
            # Alternative pattern for graphs
            start_match = re.match(r'\{(\d+)\|', block)
            if start_match:
                no_match = re.search(r'\\', block)
                end_match = re.search(r'\{\}', block)
                start_index = no_match.start() if no_match else 0
                end_index = end_match.start() if end_match else -1

                if end_index != -1:
                    return (
                        block[:start_index].strip(),
                        "",  # No middle section
                        block[end_index:].strip()
                    )

        return "", "", ""

    def _extract_end_section_details(self, end_section: str, vertex_id: str = "") -> Dict[str, str]:
        """
        Extract component name and other details from end section

        Args:
            end_section: The end section of the raw_content block
            vertex_id: The vertex ID (optional, for context)

        Returns:
            Dictionary with extracted details including component_name
        """
        split_end = end_section.split('|')
        end_dict = {}

        END_SECTION_MIN_LENGTH = 8
        COMPONENT_NAME_MARKER = "Ab Initio"

        if len(split_end) >= END_SECTION_MIN_LENGTH:
            end_dict["component_phase"] = split_end[0].strip('@')
            end_dict["disable_check"] = 0
            end_dict["graph_name"] = split_end[8] if len(split_end) > 8 else ""

            # Extract component name using the logic from the user's code
            if COMPONENT_NAME_MARKER in split_end:
                component_index = split_end.index(COMPONENT_NAME_MARKER)
                end_dict["component_name"] = split_end[component_index - 1]
            else:
                # Alternative extraction method
                if len(split_end) > 8:
                    position_8_value = split_end[8].strip()

                    if position_8_value.isdigit():
                        end_dict["component_name"] = split_end[9] if len(split_end) > 9 else ""
                    else:
                        end_dict["component_name"] = position_8_value

        return end_dict

    def _extract_file_metadata(self, raw_content: str, vertex_type: str) -> Dict[str, str]:
        """
        Extract file metadata from raw_content
        - For XXGfvertex: file_type, file_name, keys, major_key, minor_key, select
        - For all vertices: keys, major_key, minor_key, select
        """
        metadata = {
            "keys": "",
            "major_key": "",
            "minor_key": "",
            "select": ""
        }

        # Only add file_type and file_name for functional vertices
        if vertex_type == "XXGfvertex":
            metadata["file_type"] = ""
            metadata["file_name"] = ""

        if not raw_content:
            return metadata

        # Extract parameter blocks using the pattern
        parameter_section_pattern = r'@@@@\{(.*?)\}\}@'
        match = re.search(parameter_section_pattern, raw_content, re.DOTALL)

        if not match:
            return metadata

        parameter_section = match.group(1)

        # Extract individual parameter blocks
        # Pattern captures: {ID|XXparameter|param_name|param_value|...}
        parameter_pattern = r'\{(\d+)\|XXparameter\|([^|]*)\|(.*?)\|[^|]*\|[^|]*\|[^|]*\|'
        param_matches = re.finditer(parameter_pattern, parameter_section, re.DOTALL)

        for param_match in param_matches:
            param_name = param_match.group(2)
            param_value = param_match.group(3)

            # Extract file_type from !prototype_path (only for functional vertices)
            if vertex_type == "XXGfvertex" and param_name == "!prototype_path":
                if param_value:
                    last_part = param_value.split('/')[-1]
                    file_type = last_part.split('.')[0]
                    metadata["file_type"] = file_type

            # Extract file_name from Layout parameter (only for functional vertices)
            elif vertex_type == "XXGfvertex" and param_name == "Layout":
                metadata["file_name"] = param_value

            # Extract keys from key parameter (for all vertices)
            elif param_name == "key":
                metadata["keys"] = param_value

            # Extract major_key from major_key parameter (for all vertices)
            elif param_name == "major_key":
                metadata["major_key"] = param_value

            # Extract minor_key from minor_key parameter (for all vertices)
            elif param_name == "minor_key":
                metadata["minor_key"] = param_value

            # Extract select from select parameter (for all vertices)
            elif param_name == "select":
                metadata["select"] = param_value

        return metadata
    
    def _extract_clean_vertex_name(self, vertex_name, vertex_id):
        """Extract clean vertex name from raw vertex_name"""
        # vertex_name contains raw text like: "2010601001|XXGgraph_vertex_vertex|1024|0|1646|0|{_135_AES_Decrypt|"
        # Extract the component name from the curly braces
        import re
        
        # Try to extract name from {name} pattern
        name_match = re.search(r'\{([^|}]+)', vertex_name)
        if name_match:
            clean_name = name_match.group(1)
            # Remove common prefixes like "_135_", "_140_", etc.
            clean_name = re.sub(r'^_\d+_', '', clean_name)
            return clean_name
        
        # Fallback to vertex ID
        return f"vertex_{vertex_id}"

    def _get_port_label(self, port_id):
        """Get port label like 'out[0]' or 'in[1]' from port_id"""
        for port_key, port_data in self.components.get('ports', {}).items():
            if port_data['component_id'] == port_id:
                port_name = port_data.get('port_name', '').replace('|', '').strip()
                port_index = port_data.get('port_index', '0')
                return f"{port_name}[{port_index}]"
        return "port"

    def _generate_data_flow_connections(self, dot_content):
        """Generate data flow connections"""
        print("   🔄 Generating data flow connections...")
        
        dot_content.append("    // Data Flow Connections")
        
        # Build port to vertex mapping
        port_to_vertex = {}
        for port_key, port_data in self.components.get('ports', {}).items():
            port_id = port_data['component_id']
            vertex_id = port_data.get('vertex_id')  # Use .get() to handle missing vertex_id
            if vertex_id:  # Only add if vertex_id exists
                port_to_vertex[port_id] = vertex_id
        
        # Generate flow connections
        flow_connections = []
        for conn_key, conn_data in self.components.get('flow_connections', {}).items():
            port_id = conn_data['port_id']
            flow_id = conn_data['flow_id']
            is_source = conn_data['is_source']
            
            if port_id in port_to_vertex:
                vertex_id = port_to_vertex[port_id]
                flow_connections.append({
                    'vertex_id': vertex_id,
                    'flow_id': flow_id,
                    'is_source': is_source,
                    'port_id': port_id
                })
        
        # Group by flow to create edges
        flows_by_id = defaultdict(list)
        for conn in flow_connections:
            flows_by_id[conn['flow_id']].append(conn)
        
        # Create edges for each flow
        for flow_id, connections in flows_by_id.items():
            sources = [c for c in connections if not c['is_source']]  # Output ports
            targets = [c for c in connections if c['is_source']]      # Input ports
            
            for source in sources:
                for target in targets:
                    source_vertex = source['vertex_id']
                    target_vertex = target['vertex_id']
                    source_port_id = source['port_id']
                    target_port_id = target['port_id']

                    if source_vertex != target_vertex:  # Avoid self-loops
                        # Get port labels
                        source_port_label = self._get_port_label(source_port_id)
                        target_port_label = self._get_port_label(target_port_id)

                        # Position ports BELOW arrow line at both ends
                        dot_content.append(
                            f'    v{source_vertex} -> v{target_vertex} ['
                            f'color="blue", '
                            f'xlabel="f{flow_id}", '
                            f'taillabel=<<FONT POINT-SIZE="9" COLOR="dodgerblue"><B>{source_port_label}</B></FONT>>, '
                            f'headlabel=<<FONT POINT-SIZE="9" COLOR="darkblue"><B>{target_port_label}</B></FONT>>, '
                            f'labeldistance=1.5'
                            f'];'
                        )

        dot_content.append("")
    
    def _generate_config_flow_connections(self, dot_content):
        """Generate config flow connections"""
        print("   ⚙️  Generating config flow connections...")
        
        dot_content.append("    // Config Flow Connections")
        
        for config_key, config_data in self.components.get('config_flows', {}).items():
            source_id = config_data.get('source_component_id')
            target_id = config_data.get('target_component_id')
            
            # Config flows already contain vertex IDs, not port IDs
            if source_id and target_id and source_id != target_id:
                config_id = config_data.get('component_id', 'c')
                dot_content.append(f"    v{source_id} -> v{target_id} [color=\"red\", style=\"dashed\", label=\"cf{config_id}\"];")
        
        dot_content.append("")
    
    def _generate_binding_connections(self, dot_content):
        """Generate binding connections"""
        print("   🔗 Generating binding connections...")
        
        dot_content.append("    // Binding Connections")
        
        for binding_key, binding_data in self.components.get('binding_connections', {}).items():
            source_port_id = binding_data['source_port_id']
            target_port_id = binding_data['target_port_id']
            is_input = binding_data['is_input_binding']

            # Try to map port IDs to vertex IDs
            source_vertex = self._port_to_vertex(source_port_id)
            target_vertex = self._port_to_vertex(target_port_id)

            if source_vertex and target_vertex and source_vertex != target_vertex:
                style = "dotted"
                color = "orange" if is_input else "purple"
                binding_id = binding_data.get('component_id', '')
                binding_label = f"b{binding_id}" if binding_id else ("ib" if is_input else "ob")

                # Get port labels
                source_port_label = self._get_port_label(source_port_id)
                target_port_label = self._get_port_label(target_port_id)

                # Set port colors based on line color
                if is_input:  # Orange line
                    source_port_color = "darkorange"
                    target_port_color = "orangered"
                else:  # Purple line
                    source_port_color = "darkviolet"
                    target_port_color = "purple"

                # Add binding connection with port labels BELOW arrow
                dot_content.append(
                    f'    v{source_vertex} -> v{target_vertex} ['
                    f'color="{color}", '
                    f'style="{style}", '
                    f'xlabel="{binding_label}", '
                    f'taillabel=<<FONT POINT-SIZE="9" COLOR="{source_port_color}"><B>{source_port_label}</B></FONT>>, '
                    f'headlabel=<<FONT POINT-SIZE="9" COLOR="{target_port_color}"><B>{target_port_label}</B></FONT>>, '
                    f'labeldistance=1.5'
                    f'];'
                )

        dot_content.append("")
    
    def _port_to_vertex(self, port_id):
        """Map port ID to vertex ID"""
        # Check regular ports
        for port_key, port_data in self.components.get('ports', {}).items():
            if port_data['component_id'] == port_id:
                return port_data['vertex_id']
        
        # Check individual ports (might need different mapping)
        for port_key, port_data in self.components.get('individual_ports', {}).items():
            if port_data['component_id'] == port_id:
                # Individual ports might not have direct vertex mapping
                # This would need more sophisticated logic
                return None
        
        return None
    
    def _print_statistics(self):
        """Print generation statistics"""
        print("\n📊 ENHANCED DOT GENERATION STATISTICS:")
        
        total_graphs = len(self.components.get('graphs', {}))
        total_vertices = len(self.components.get('vertices', {}))
        total_flows = len(self.components.get('flows', {}))
        total_config_flows = len(self.components.get('config_flows', {}))
        total_bindings = len(self.components.get('binding_connections', {}))
        
        print(f"   • Graphs: {total_graphs}")
        print(f"   • Vertices: {total_vertices}")
        print(f"   • Data Flows: {total_flows}")
        print(f"   • Config Flows: {total_config_flows}")
        print(f"   • Binding Connections: {total_bindings}")

def main():
    import sys
    
    print("🚀 ENHANCED DOT GENERATOR WITH CONFIG FLOWS AND GRAPH IDS")
    print("=" * 60)
    
    # Parse command line arguments
    if len(sys.argv) < 2:
        print("Usage: python dot_generator.py <components_file> [output_folder] [output_filename]")
        print("Example: python dot_generator.py enhanced_components.json")
        print("Example: python dot_generator.py enhanced_components.json output")
        print("Example: python dot_generator.py enhanced_components.json output custom_graph.dot")
        return
    
    components_file = sys.argv[1]
    output_folder = sys.argv[2] if len(sys.argv) > 2 else "output"
    output_filename = sys.argv[3] if len(sys.argv) > 3 else None
    
    try:
        generator = EnhancedDotGenerator(components_file)
        output_path = generator.generate_enhanced_dot(output_folder, output_filename, components_file)
        
        print("\n✅ Enhanced DOT generation complete!")
        print(f"   📁 Output file: {output_path}")
        print("   🎨 Includes: Data flows (blue), Config flows (red dashed), Bindings (orange/purple dotted)")
        print("   🆔 Graph labels now include IDs: 'Graph Name (ID: 123)'")
        
    except Exception as e:
        print(f"❌ Error during DOT generation: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()