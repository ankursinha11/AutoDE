#!/usr/bin/env python3
"""
Dependency Graph Builder for Subgraphs
Creates a tree-like dependency structure from subgraph references
"""

import json
import os
from collections import defaultdict, deque
from typing import Dict, List, Set, Any
import networkx as nx

class DependencyGraphBuilder:
    """Build dependency graph from subgraph references"""
    
    def __init__(self, subgraphs_file: str):
        """Initialize with subgraphs JSON file"""
        with open(subgraphs_file, 'r') as f:
            self.data = json.load(f)
        
        self.subgraphs = self.data.get('subgraphs', {})
        self.dependency_map = {}
        self.reverse_dependency_map = defaultdict(list)
        
        self._build_dependency_maps()
    
    def _build_dependency_maps(self):
        """Build forward and reverse dependency maps"""
        print("🔍 Building dependency maps...")
        
        for subgraph_id, subgraph_data in self.subgraphs.items():
            references = subgraph_data.get('subgraph_references', [])
            self.dependency_map[subgraph_id] = references
            
            # Build reverse map (who depends on this subgraph)
            for ref_id in references:
                self.reverse_dependency_map[ref_id].append(subgraph_id)
        
        print(f"   • Processed {len(self.subgraphs)} subgraphs")
        print(f"   • Found {sum(len(refs) for refs in self.dependency_map.values())} total dependencies")
    
    def build_dependency_tree(self, root_id: str, visited: Set[str] = None) -> Dict[str, Any]:
        """Build dependency tree starting from a root subgraph"""
        if visited is None:
            visited = set()
        
        if root_id in visited:
            # Circular dependency detected
            return {
                "id": root_id,
                "name": self.subgraphs.get(root_id, {}).get('name', 'Unknown'),
                "circular_reference": True,
                "dependencies": []
            }
        
        visited.add(root_id)
        
        subgraph_info = self.subgraphs.get(root_id, {})
        dependencies = self.dependency_map.get(root_id, [])
        
        tree_node = {
            "id": root_id,
            "name": subgraph_info.get('name', 'Unknown'),
            "vertex_count": subgraph_info.get('statistics', {}).get('vertex_count', 0),
            "dependency_count": len(dependencies),
            "dependencies": []
        }
        
        # Recursively build dependency trees for each dependency
        for dep_id in dependencies:
            if dep_id in self.subgraphs:  # Only include if dependency exists
                dep_tree = self.build_dependency_tree(dep_id, visited.copy())
                tree_node["dependencies"].append(dep_tree)
        
        return tree_node
    
    def find_root_subgraphs(self) -> List[str]:
        """Find subgraphs that are not dependencies of any other subgraph"""
        all_dependencies = set()
        for deps in self.dependency_map.values():
            all_dependencies.update(deps)
        
        root_subgraphs = []
        for subgraph_id in self.subgraphs.keys():
            if subgraph_id not in all_dependencies:
                root_subgraphs.append(subgraph_id)
        
        return root_subgraphs
    
    def build_full_dependency_graph(self) -> Dict[str, Any]:
        """Build complete dependency graph structure"""
        print("🌳 Building dependency graph structure...")
        
        # Find root subgraphs (those not referenced by others)
        root_subgraphs = self.find_root_subgraphs()
        print(f"   • Found {len(root_subgraphs)} root subgraphs: {root_subgraphs}")
        
        # Build dependency trees for each root
        dependency_trees = []
        for root_id in root_subgraphs:
            tree = self.build_dependency_tree(root_id)
            dependency_trees.append(tree)
        
        # Calculate statistics
        total_dependencies = sum(len(deps) for deps in self.dependency_map.values())
        max_depth = self._calculate_max_depth(dependency_trees)
        circular_deps = self._find_circular_dependencies()
        
        graph_structure = {
            "metadata": {
                "total_subgraphs": len(self.subgraphs),
                "total_dependencies": total_dependencies,
                "root_subgraphs_count": len(root_subgraphs),
                "max_dependency_depth": max_depth,
                "circular_dependencies_count": len(circular_deps),
                "generation_timestamp": self.data.get('metadata', {}).get('generation_timestamp', '')
            },
            "root_subgraphs": root_subgraphs,
            "dependency_trees": dependency_trees,
            "circular_dependencies": circular_deps,
            "dependency_summary": self._build_dependency_summary()
        }
        
        return graph_structure
    
    def _calculate_max_depth(self, trees: List[Dict[str, Any]], current_depth: int = 0) -> int:
        """Calculate maximum depth of dependency trees"""
        if not trees:
            return current_depth
        
        max_depth = current_depth
        for tree in trees:
            if tree.get("dependencies"):
                depth = self._calculate_max_depth(tree["dependencies"], current_depth + 1)
                max_depth = max(max_depth, depth)
        
        return max_depth
    
    def _find_circular_dependencies(self) -> List[Dict[str, Any]]:
        """Find circular dependencies in the graph"""
        circular_deps = []
        visited = set()
        rec_stack = set()
        
        def has_cycle(node_id: str, path: List[str]) -> bool:
            if node_id in rec_stack:
                # Found cycle
                cycle_start = path.index(node_id)
                cycle = path[cycle_start:] + [node_id]
                circular_deps.append({
                    "cycle": cycle,
                    "cycle_length": len(cycle) - 1,
                    "description": " -> ".join(cycle)
                })
                return True
            
            if node_id in visited:
                return False
            
            visited.add(node_id)
            rec_stack.add(node_id)
            
            for dep_id in self.dependency_map.get(node_id, []):
                if has_cycle(dep_id, path + [node_id]):
                    return True
            
            rec_stack.remove(node_id)
            return False
        
        for subgraph_id in self.subgraphs.keys():
            if subgraph_id not in visited:
                has_cycle(subgraph_id, [])
        
        return circular_deps
    
    def _build_dependency_summary(self) -> Dict[str, Any]:
        """Build summary of dependencies per subgraph"""
        summary = {}
        
        for subgraph_id, subgraph_data in self.subgraphs.items():
            dependencies = self.dependency_map.get(subgraph_id, [])
            dependents = self.reverse_dependency_map.get(subgraph_id, [])
            
            summary[subgraph_id] = {
                "name": subgraph_data.get('name', 'Unknown'),
                "depends_on": dependencies,
                "depends_on_count": len(dependencies),
                "depended_by": dependents,
                "depended_by_count": len(dependents),
                "is_root": subgraph_id in self.find_root_subgraphs(),
                "is_leaf": len(dependencies) == 0
            }
        
        return summary
    
    def add_graph_structure_to_file(self, output_file: str):
        """Add graph_structure to the subgraphs file"""
        
        print("📊 Generating dependency graph structure...")
        graph_structure = self.build_full_dependency_graph()
        
        # Add to existing data
        self.data["graph_structure"] = graph_structure
        
        # Save updated file
        with open(output_file, 'w') as f:
            json.dump(self.data, f, indent=2)
        
        print(f"✅ Graph structure added to {output_file}")
        
        # Print summary
        self._print_graph_summary(graph_structure)
        
        return graph_structure
    
    def _print_graph_summary(self, graph_structure: Dict[str, Any]):
        """Print summary of the dependency graph"""
        metadata = graph_structure["metadata"]
        
        print(f"\n📊 DEPENDENCY GRAPH SUMMARY:")
        print(f"   • Total Subgraphs: {metadata['total_subgraphs']}")
        print(f"   • Total Dependencies: {metadata['total_dependencies']}")
        print(f"   • Root Subgraphs: {metadata['root_subgraphs_count']}")
        print(f"   • Max Dependency Depth: {metadata['max_dependency_depth']}")
        print(f"   • Circular Dependencies: {metadata['circular_dependencies_count']}")
        
        if graph_structure["circular_dependencies"]:
            print(f"\n⚠️  CIRCULAR DEPENDENCIES DETECTED:")
            for circ in graph_structure["circular_dependencies"]:
                print(f"   • {circ['description']}")
        
        print(f"\n🌳 ROOT SUBGRAPHS:")
        for tree in graph_structure["dependency_trees"]:
            self._print_tree(tree, indent="   ")
    
    def _print_tree(self, tree: Dict[str, Any], indent: str = ""):
        """Print dependency tree structure"""
        name = tree["name"]
        subgraph_id = tree["id"]
        dep_count = tree["dependency_count"]
        vertex_count = tree["vertex_count"]
        
        circular_marker = " [CIRCULAR]" if tree.get("circular_reference") else ""
        print(f"{indent}• {subgraph_id}: {name} (V:{vertex_count}, D:{dep_count}){circular_marker}")
        
        for dep in tree.get("dependencies", []):
            self._print_tree(dep, indent + "  ")
    
    def load_to_networkx(self) -> nx.DiGraph:
        """Load subgraphs into NetworkX graph for analysis and selection"""
        print("🔍 Loading subgraphs into NetworkX...")
        
        # Create NetworkX directed graph
        G = nx.DiGraph()
        
        # Add nodes (subgraphs) with their attributes
        for subgraph_id, subgraph_data in self.subgraphs.items():
            vertex_count = subgraph_data.get('statistics', {}).get('vertex_count', 0)
            subgraph_name = subgraph_data.get('name', 'Unknown')
            
            G.add_node(subgraph_id, 
                      name=subgraph_name,
                      vertex_count=vertex_count,
                      data_connection_count=subgraph_data.get('statistics', {}).get('data_connection_count', 0),
                      config_connection_count=subgraph_data.get('statistics', {}).get('config_connection_count', 0))
        
        # Add edges (dependencies) from subgraph_references
        for subgraph_id, subgraph_data in self.subgraphs.items():
            dependencies = subgraph_data.get('subgraph_references', [])
            for dep_id in dependencies:
                if dep_id in G.nodes:  # Only add edge if dependency exists
                    G.add_edge(subgraph_id, dep_id)
        
        print(f"   • NetworkX Graph: {G.number_of_nodes()} nodes, {G.number_of_edges()} edges")
        return G
    
    def select_subgraphs_by_vertex_limit(self, max_vertices: int, strategy: str = 'topological') -> tuple:
        """Select subgraphs that fit within vertex limit using different strategies"""
        G = self.load_to_networkx()
        
        print(f"🎯 Selecting subgraphs (Max vertices: {max_vertices}, Strategy: {strategy})")
        
        selected_subgraphs = []
        total_vertices = 0
        
        if strategy == 'topological':
            # Process in topological order (dependencies first)
            try:
                order = list(nx.topological_sort(G))
            except nx.NetworkXError:
                # If not a DAG, use arbitrary order
                order = list(G.nodes())
        elif strategy == 'largest_first':
            # Process largest subgraphs first
            order = sorted(G.nodes(), key=lambda x: G.nodes[x]['vertex_count'], reverse=True)
        elif strategy == 'smallest_first':
            # Process smallest subgraphs first
            order = sorted(G.nodes(), key=lambda x: G.nodes[x]['vertex_count'])
        elif strategy == 'root_first':
            # Process root nodes first, then their dependencies
            root_nodes = [node for node in G.nodes() if G.in_degree(node) == 0]
            remaining_nodes = [node for node in G.nodes() if node not in root_nodes]
            order = root_nodes + remaining_nodes
        else:
            order = list(G.nodes())
        
        # Select subgraphs that fit within the limit
        for node in order:
            vertex_count = G.nodes[node]['vertex_count']
            if total_vertices + vertex_count <= max_vertices:
                selected_subgraphs.append(node)
                total_vertices += vertex_count
        
        print(f"   • Selected {len(selected_subgraphs)} subgraphs")
        print(f"   • Total vertices: {total_vertices}/{max_vertices} ({(total_vertices/max_vertices)*100:.1f}%)")
        
        return selected_subgraphs, total_vertices, G
    
    def export_selection_for_llm(self, selected_nodes: List[str], output_file: str, strategy: str = 'topological'):
        """Export selected subgraphs in a format suitable for LLM processing"""
        print(f"💾 Exporting selection for LLM processing...")
        
        G = self.load_to_networkx()
        
        # Create filtered data structure
        filtered_data = {
            'metadata': {
                'source_file': 'filtered_selection',
                'total_subgraphs': len(selected_nodes),
                'selection_strategy': strategy,
                'total_vertices': sum(G.nodes[node]['vertex_count'] for node in selected_nodes),
                'generation_timestamp': self.data.get('metadata', {}).get('generation_timestamp', '')
            },
            'subgraphs': {},
            'selection_info': {
                'selected_nodes': selected_nodes,
                'node_details': []
            }
        }
        
        # Add selected subgraphs
        for node in selected_nodes:
            if node in self.subgraphs:
                filtered_data['subgraphs'][node] = self.subgraphs[node]
                
                # Add selection info
                filtered_data['selection_info']['node_details'].append({
                    'id': node,
                    'name': G.nodes[node]['name'],
                    'vertex_count': G.nodes[node]['vertex_count'],
                    'dependencies': list(G.successors(node)),
                    'dependents': list(G.predecessors(node))
                })
        
        # Save to file
        with open(output_file, 'w') as f:
            json.dump(filtered_data, f, indent=2)
        
        print(f"   ✅ Exported to: {output_file}")
        print(f"   • {len(selected_nodes)} subgraphs, {filtered_data['metadata']['total_vertices']} vertices")
        
        return filtered_data
    
    def generate_llm_selections(self, vertex_limits: List[int] = None, output_folder: str = "output"):
        """Generate multiple selections for different LLM context window sizes"""
        if vertex_limits is None:
            vertex_limits = [50, 100, 200, 500]
        
        print(f"🤖 GENERATING LLM SELECTIONS")
        print("=" * 40)
        
        strategies = ['topological', 'largest_first', 'smallest_first', 'root_first']
        results = {}
        
        for limit in vertex_limits:
            print(f"\n📊 Vertex Limit: {limit}")
            results[limit] = {}
            
            for strategy in strategies:
                selected_nodes, total_vertices, G = self.select_subgraphs_by_vertex_limit(limit, strategy)
                
                if selected_nodes:
                    # Export selection
                    output_file = os.path.join(output_folder, f"llm_selection_{limit}v_{strategy}.json")
                    filtered_data = self.export_selection_for_llm(selected_nodes, output_file, strategy)
                    
                    results[limit][strategy] = {
                        'selected_count': len(selected_nodes),
                        'total_vertices': total_vertices,
                        'utilization': (total_vertices/limit)*100,
                        'output_file': output_file
                    }
        
        # Generate summary
        summary_file = os.path.join(output_folder, "llm_selections_summary.json")
        with open(summary_file, 'w') as f:
            json.dump(results, f, indent=2)
        
        print(f"\n✅ LLM selections generated!")
        print(f"   • Summary: {summary_file}")
        print(f"   • Individual files in: {output_folder}")
        
        return results

def main():
    """Main function to build and add dependency graph"""
    import sys
    
    # Parse command line arguments
    if len(sys.argv) < 2:
        print("Usage: python dependency_graph_builder.py <subgraphs_json_file>")
        print("Example: python dependency_graph_builder.py output/400_commGenIpa_2_subgraphs.json")
        print("Note: The dependency graph will be added to the same input file")
        return
    
    input_file = sys.argv[1]
    
    # Validate input file exists
    if not os.path.exists(input_file):
        print(f"❌ Error: Input file '{input_file}' not found")
        return
    
    # Validate it's a JSON file
    if not input_file.lower().endswith('.json'):
        print(f"❌ Error: Input file must be a JSON file")
        return
    
    print(f"🔍 Processing subgraphs file: {input_file}")
    
    try:
        builder = DependencyGraphBuilder(input_file)
        builder.add_graph_structure_to_file(input_file)  # Output to same file as input
        print(f"✅ Dependency graph structure added to: {input_file}")
        
        # Generate LLM selections
        output_dir = os.path.dirname(input_file) if os.path.dirname(input_file) else "output"
        print(f"\n🤖 Generating LLM selections in: {output_dir}")
        builder.generate_llm_selections(output_folder=output_dir)
        
    except Exception as e:
        print(f"❌ Error processing file: {e}")
        return

if __name__ == "__main__":
    main()