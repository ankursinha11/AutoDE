"""
Ab Initio Graph Flow Diagram Generator
Generates visual flow diagrams from parsed components using Graphviz

Output: PNG/SVG/PDF diagrams showing data flow with:
- Components color-coded by type
- Flow connections
- Port labels
"""

import graphviz
from pathlib import Path
from typing import Dict, Any, Optional
import logging
import json

logger = logging.getLogger(__name__)


class AbInitioFlowDiagramGenerator:
    """
    Generates visual flow diagrams from Ab Initio parsed JSON
    """

    # Component type to shape mapping
    COMPONENT_SHAPES = {
        'Input_File': 'cylinder',
        'Output_File': 'cylinder',
        'Lookup_File': 'box3d',
        'Join': 'diamond',
        'Reformat': 'box',
        'Filter_by_Expression': 'trapezium',
        'Sort': 'invtrapezium',
        'Dedup_Sorted': 'hexagon',
        'Aggregate': 'octagon',
        'Rollup': 'octagon',
        'Broadcast': 'triangle',
        'Gather': 'invtriangle',
        'Scan': 'box',
        'Normalize': 'parallelogram',
        'Partition_by_Key': 'house'
    }

    # Component type to color mapping
    COMPONENT_COLORS = {
        'Input_File': 'lightblue',
        'Output_File': 'lightgreen',
        'Lookup_File': 'lightyellow',
        'Join': 'lightcoral',
        'Reformat': 'wheat',
        'Filter_by_Expression': 'plum',
        'Sort': 'lightgray',
        'Dedup_Sorted': 'lightcyan',
        'Aggregate': 'lightpink',
        'Rollup': 'lightpink',
        'Broadcast': 'lavender',
        'Gather': 'lavender',
        'Scan': 'white',
        'Normalize': 'peachpuff',
        'Partition_by_Key': 'thistle'
    }

    def __init__(self):
        pass

    def generate_diagram(
        self,
        parsed_json_path: str,
        output_folder: str = "outputs/diagrams",
        format: str = "png",
        layout_engine: str = "dot"
    ) -> Dict[str, Any]:
        """
        Generate flow diagram from parsed JSON

        Args:
            parsed_json_path: Path to parsed components JSON
            output_folder: Output folder for diagram
            format: Output format (png, svg, pdf)
            layout_engine: Graphviz layout engine (dot, neato, fdp, circo)

        Returns:
            Dict with success status and diagram path
        """
        try:
            parsed_json_path = Path(parsed_json_path)
            output_folder = Path(output_folder)
            output_folder.mkdir(parents=True, exist_ok=True)

            if not parsed_json_path.exists():
                return {
                    'success': False,
                    'error': f'Parsed JSON not found: {parsed_json_path}'
                }

            logger.info(f"Generating flow diagram from: {parsed_json_path.name}")

            # Load parsed JSON
            with open(parsed_json_path, 'r', encoding='utf-8') as f:
                data = json.load(f)

            graph_name = parsed_json_path.stem.replace('_components', '')

            # Create Graphviz digraph
            dot = graphviz.Digraph(
                name=graph_name,
                comment=f'Ab Initio Flow Diagram: {graph_name}',
                format=format,
                engine=layout_engine
            )

            # Set graph attributes for better layout
            dot.attr(rankdir='LR')  # Left to Right layout
            dot.attr('node', shape='box', style='filled', fontname='Helvetica', fontsize='10')
            dot.attr('edge', fontname='Helvetica', fontsize='8', color='gray40')
            dot.attr('graph',
                     splines='ortho',  # Orthogonal edges
                     nodesep='0.5',
                     ranksep='1.0',
                     bgcolor='white',
                     pad='0.5')

            # Add vertices (components)
            vertices = data.get('vertices', {})
            logger.info(f"  Adding {len(vertices)} vertices...")

            for vid, vdata in vertices.items():
                component_type = vdata.get('type', 'Unknown')
                component_name = vdata.get('name', vid)

                # Get shape and color
                shape = self.COMPONENT_SHAPES.get(component_type, 'box')
                color = self.COMPONENT_COLORS.get(component_type, 'white')

                # Create label (truncate if too long)
                label = self._create_node_label(component_name, component_type)

                # Add transform rule snippet to tooltip if available
                transform_rule = vdata.get('attributes', {}).get('transform_rule', '')
                tooltip = self._create_tooltip(component_name, component_type, transform_rule)

                dot.node(
                    vid,
                    label=label,
                    shape=shape,
                    fillcolor=color,
                    tooltip=tooltip
                )

            # Add flows (edges)
            flows = data.get('flows', {})
            logger.info(f"  Adding {len(flows)} flows...")

            for fid, fdata in flows.items():
                from_vertex = fdata.get('from_vertex')
                to_vertex = fdata.get('to_vertex')
                from_port = fdata.get('from_port', '')
                to_port = fdata.get('to_port', '')

                if from_vertex and to_vertex:
                    # Create edge label (port names)
                    edge_label = ''
                    if from_port or to_port:
                        if from_port and to_port:
                            edge_label = f"{from_port} → {to_port}"
                        elif from_port:
                            edge_label = from_port
                        elif to_port:
                            edge_label = to_port

                    # Truncate long port names
                    if len(edge_label) > 20:
                        edge_label = edge_label[:17] + '...'

                    dot.edge(
                        from_vertex,
                        to_vertex,
                        label=edge_label,
                        fontsize='8'
                    )

            # Render diagram
            output_file = output_folder / f"{graph_name}_flow_diagram"
            logger.info(f"  Rendering diagram to: {output_file}.{format}")

            diagram_path = dot.render(
                filename=str(output_file),
                cleanup=True,  # Remove intermediate .dot file
                view=False  # Don't auto-open
            )

            logger.info(f"✅ Flow diagram generated: {diagram_path}")

            return {
                'success': True,
                'diagram_path': diagram_path,
                'format': format,
                'vertices_count': len(vertices),
                'flows_count': len(flows),
                'layout_engine': layout_engine
            }

        except Exception as e:
            logger.error(f"Diagram generation failed: {e}", exc_info=True)
            return {
                'success': False,
                'error': str(e)
            }

    def _create_node_label(self, name: str, type: str) -> str:
        """Create node label (truncate if needed)"""
        max_len = 25

        if len(name) > max_len:
            name = name[:max_len-3] + '...'

        # Multi-line label for better readability
        return f"{name}\\n[{type}]"

    def _create_tooltip(self, name: str, type: str, transform_rule: str) -> str:
        """Create tooltip with additional info"""
        tooltip = f"{name}\\nType: {type}"

        if transform_rule and len(transform_rule) > 10:
            # Truncate transform rule for tooltip
            rule_snippet = transform_rule[:100]
            if len(transform_rule) > 100:
                rule_snippet += '...'
            tooltip += f"\\nLogic: {rule_snippet}"

        return tooltip

    def generate_legend(self, output_folder: str = "outputs/diagrams") -> Optional[str]:
        """
        Generate a legend diagram showing component types and colors

        Args:
            output_folder: Output folder for legend

        Returns:
            Path to legend diagram or None if failed
        """
        try:
            output_folder = Path(output_folder)
            output_folder.mkdir(parents=True, exist_ok=True)

            dot = graphviz.Digraph(
                name='legend',
                comment='Ab Initio Component Types Legend',
                format='png'
            )

            dot.attr(rankdir='TB')
            dot.attr('node', shape='box', style='filled', fontname='Helvetica', fontsize='10')

            # Add each component type as a node
            for component_type, color in self.COMPONENT_COLORS.items():
                shape = self.COMPONENT_SHAPES.get(component_type, 'box')
                dot.node(
                    component_type,
                    label=component_type,
                    shape=shape,
                    fillcolor=color
                )

            # Render legend
            legend_path = dot.render(
                filename=str(output_folder / 'component_types_legend'),
                cleanup=True,
                view=False
            )

            logger.info(f"✅ Legend generated: {legend_path}")
            return legend_path

        except Exception as e:
            logger.error(f"Legend generation failed: {e}")
            return None
