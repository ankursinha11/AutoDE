"""
VM_FAWN Integrated Parser for STAG
====================================

Integrates VM_FAWN parser (detailed transformation extraction) with STAG's Enhanced Parser format.

This parser:
1. Calls VM_FAWN to parse .mp files and generate detailed Excel
2. Reads VM_FAWN's Excel output (DataSet, Component&Fields, GraphParameters sheets)
3. Converts to Enhanced Parser JSON format with proper attributes
4. Output works with existing GraphFlow generator and STAG indexing

Author: Integration wrapper for STAG
"""

import os
import sys
import json
import pandas as pd
from pathlib import Path
from typing import Dict, Any, List, Optional
import subprocess
import tempfile
import shutil

# Add VM_FAWN to path
VM_FAWN_DIR = Path(__file__).parent / "vm_fawn"
sys.path.insert(0, str(VM_FAWN_DIR))

try:
    from vm_fawn import parser as vm_fawn_parser
    from vm_fawn import config as vm_fawn_config
    from vm_fawn import utils as vm_fawn_utils
except ImportError:
    print("⚠️  VM_FAWN modules not found. Ensure vm_fawn directory is properly set up.")
    vm_fawn_parser = None


class VMFAWNIntegratedParser:
    """Integrated parser using VM_FAWN for detailed extraction"""

    def __init__(self):
        self.vm_fawn_available = vm_fawn_parser is not None

    def parse_mp_file(
        self,
        file_path: str,
        output_folder: str = "outputs/parsed_abinitio",
        output_filename: str = None
    ) -> Dict[str, Any]:
        """
        Parse .mp file using VM_FAWN and convert to Enhanced Parser format

        Args:
            file_path: Path to .mp file
            output_folder: Output folder for JSON
            output_filename: Output JSON filename

        Returns:
            Dictionary in Enhanced Parser format with VM_FAWN's detailed data
        """
        file_path = Path(file_path)
        output_folder = Path(output_folder)
        output_folder.mkdir(parents=True, exist_ok=True)

        if output_filename is None:
            output_filename = f"{file_path.stem}_components.json"

        print(f"🔍 VM_FAWN INTEGRATED PARSER")
        print(f"=" * 60)
        print(f"   Input: {file_path.name}")

        # Step 1: Run VM_FAWN parser to generate Excel
        print(f"\\n📊 Step 1: Running VM_FAWN parser...")
        vm_fawn_excel = self._run_vm_fawn_parser(file_path)

        if not vm_fawn_excel or not vm_fawn_excel.exists():
            print(f"   ❌ VM_FAWN parsing failed, falling back to basic parser")
            return self._fallback_basic_parse(file_path)

        print(f"   ✅ VM_FAWN generated: {vm_fawn_excel}")

        # Step 2: Read VM_FAWN Excel and convert to Enhanced Parser format
        print(f"\\n🔄 Step 2: Converting VM_FAWN Excel to Enhanced Parser JSON...")
        result = self._convert_vm_fawn_to_enhanced_format(
            vm_fawn_excel=vm_fawn_excel,
            source_mp_file=file_path
        )

        # Step 3: Save to JSON
        output_path = output_folder / output_filename
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(result, f, indent=2)

        print(f"\\n✅ INTEGRATED PARSING COMPLETE")
        print(f"   Output: {output_path}")
        print(f"   Vertices: {len(result.get('vertices', {}))}")
        print(f"   Flows: {len(result.get('flows', {}))}")
        print(f"   Components with transformations: {result.get('summary', {}).get('components_with_transforms', 0)}")

        return result

    def _run_vm_fawn_parser(self, mp_file_path: Path) -> Optional[Path]:
        """
        Run VM_FAWN parser on .mp file

        Returns:
            Path to generated Excel file, or None if failed
        """
        # Create temporary directory for VM_FAWN output
        temp_output = Path(tempfile.mkdtemp(prefix="vm_fawn_"))

        try:
            # Change to VM_FAWN directory (it expects to run from there)
            original_dir = os.getcwd()
            os.chdir(str(VM_FAWN_DIR))

            # Set output folder in config
            output_folder = temp_output

            # Load patterns
            patterns, pattern_file = vm_fawn_parser.load_patterns()

            # Convert MP to TXT
            file_path, sandbox_file_path, original_filename = vm_fawn_utils.mp_to_txt(
                upload_folder=str(temp_output / "upload"),
                text_folder=str(temp_output / "text"),
                sandbox_file_path=str(mp_file_path),
                timestamp="integrated_parse"
            )

            # Read and parse
            content = vm_fawn_utils.read_file(file_path)
            blockset = vm_fawn_parser.extract_blocks(content)
            block_with_internal, blocks_by_graph = vm_fawn_parser.extract_and_store_blocks(content, patterns)
            unique_id_blocks = {gid: blocks for gid, blocks in blocks_by_graph.items()}
            block_dicts = vm_fawn_parser.parse_blocks(unique_id_blocks, patterns)
            flattened_data = vm_fawn_parser.flatten_data(block_dicts)
            df = pd.DataFrame(flattened_data)

            # Process and save
            dataset_df, component_df, graph_param_df, csv_file = vm_fawn_parser.process_and_save_data(
                df=df,
                sandbox_file_path=str(mp_file_path),
                patterns=patterns,
                output_folder=str(output_folder),
                base_filename=original_filename,
                timestamp="integrated"
            )

            graph_csv_input = vm_fawn_parser.generate_csv_from_dataframe(
                graph_param_df, str(output_folder), original_filename, "integrated"
            )

            tracking_df = pd.DataFrame()  # No tracking file

            saved_file = vm_fawn_parser.update_transform_rule_and_save(
                dataset_df, component_df, graph_param_df, tracking_df,
                csv_file, graph_csv_input, str(output_folder),
                original_filename, "integrated"
            )

            # Cleanup pattern file
            if pattern_file and os.path.exists(pattern_file):
                os.remove(pattern_file)

            # Return to original directory
            os.chdir(original_dir)

            if saved_file:
                return Path(output_folder) / saved_file
            else:
                return None

        except Exception as e:
            print(f"   ❌ VM_FAWN parsing error: {e}")
            os.chdir(original_dir)
            return None

    def _convert_vm_fawn_to_enhanced_format(
        self,
        vm_fawn_excel: Path,
        source_mp_file: Path
    ) -> Dict[str, Any]:
        """
        Convert VM_FAWN Excel output to Enhanced Parser JSON format

        Args:
            vm_fawn_excel: Path to VM_FAWN generated Excel
            source_mp_file: Original .mp file

        Returns:
            Dictionary in Enhanced Parser format
        """
        # Read VM_FAWN Excel sheets
        excel_data = pd.ExcelFile(vm_fawn_excel)

        # Read sheets
        dataset_df = pd.read_excel(vm_fawn_excel, sheet_name='DataSet') if 'DataSet' in excel_data.sheet_names else pd.DataFrame()
        component_df = pd.read_excel(vm_fawn_excel, sheet_name='Component&Fields') if 'Component&Fields' in excel_data.sheet_names else pd.DataFrame()
        graph_param_df = pd.read_excel(vm_fawn_excel, sheet_name='GraphParameters') if 'GraphParameters' in excel_data.sheet_names else pd.DataFrame()
        graphflow_df = pd.read_excel(vm_fawn_excel, sheet_name='GraphFlow') if 'GraphFlow' in excel_data.sheet_names else pd.DataFrame()

        # Read raw .mp content
        with open(source_mp_file, 'r', encoding='latin-1') as f:
            raw_content = f.read()

        # Build vertices from Component&Fields sheet
        vertices = {}
        components_with_transforms = 0

        for idx, row in component_df.iterrows():
            vertex_id = f"component_{idx}"
            comp_name = str(row.get('Component Name', f'component_{idx}'))
            transform_comp = str(row.get('Transform Component', ''))
            transform_rule = str(row.get('Transform Rule', ''))
            trans_location = str(row.get('TransLocation', ''))
            keys = str(row.get('Keys', ''))

            has_transform = (transform_rule and transform_rule != 'nan' and len(transform_rule) > 0)
            if has_transform:
                components_with_transforms += 1

            vertices[vertex_id] = {
                'component_id': str(idx),
                'component_type': 'XXGfvertex',  # Generic type
                'name': comp_name,
                'attributes': {
                    'transform_component': transform_comp,
                    'transform_rule': transform_rule,
                    'trans_location': trans_location,
                    'keys': keys,
                    'subgraph_hierarchy': str(row.get('subgraph_hierarchy', '')),
                    'final_subgraph': str(row.get('final_subgraph', '')),
                    'component_phase': str(row.get('component_phase', '')),
                    'disable_check': str(row.get('disable_check', ''))
                },
                'raw_content': f"Component: {comp_name}, Transform: {transform_comp}"
            }

        # Build dataset vertices from DataSet sheet
        for idx, row in dataset_df.iterrows():
            vertex_id = f"dataset_{idx}"
            comp_label = str(row.get('CompDisplay Label', f'dataset_{idx}'))
            comp_type = str(row.get('Component Type', ''))
            dataset_names = str(row.get('DataSet Names', ''))
            dml = str(row.get('DML', ''))
            key_param = str(row.get('Key Parameter Value', ''))

            vertices[vertex_id] = {
                'component_id': f"ds_{idx}",
                'component_type': comp_type,
                'name': comp_label,
                'attributes': {
                    'layout': dataset_names,
                    'dml': dml,
                    'key_parameter': key_param,
                    'dataset_type': comp_type
                },
                'raw_content': f"Dataset: {comp_label}, DML: {dml[:100]}"
            }

        # Build flows (we don't have flow connections from VM_FAWN, so create placeholders)
        flows = {}
        # VM_FAWN doesn't extract flow connections, this would need GraphFlow generator

        # Build ports (placeholder)
        ports = {}

        # Build graphs
        graphs = {}
        for idx, row in graph_param_df.iterrows():
            graph_name = str(row.get('graph_name', 'main_graph'))
            if graph_name not in graphs:
                graphs[graph_name] = {
                    'component_id': graph_name,
                    'component_type': 'XXGgraph',
                    'name': graph_name,
                    'parameters': {}
                }

            param_name = str(row.get('parameter_name', ''))
            param_value = str(row.get('parameter_value', ''))
            if param_name:
                graphs[graph_name]['parameters'][param_name] = param_value

        # Build result
        result = {
            'metadata': {
                'source_file': str(source_mp_file),
                'parser_version': 'vm_fawn_integrated_v1',
                'extraction_timestamp': str(source_mp_file.stat().st_mtime)
            },
            'raw_content': raw_content,
            'vertices': vertices,
            'flows': flows,
            'ports': ports,
            'graphs': graphs,
            'summary': {
                'total_vertices': len(vertices),
                'total_flows': len(flows),
                'total_ports': len(ports),
                'total_graphs': len(graphs),
                'components_with_transforms': components_with_transforms,
                'vm_fawn_excel_source': str(vm_fawn_excel)
            }
        }

        return result

    def _fallback_basic_parse(self, file_path: Path) -> Dict[str, Any]:
        """Fallback to basic parsing if VM_FAWN fails"""
        with open(file_path, 'r', encoding='latin-1') as f:
            raw_content = f.read()

        return {
            'metadata': {
                'source_file': str(file_path),
                'parser_version': 'fallback_basic',
                'extraction_timestamp': str(file_path.stat().st_mtime)
            },
            'raw_content': raw_content,
            'vertices': {},
            'flows': {},
            'ports': {},
            'graphs': {},
            'summary': {
                'total_vertices': 0,
                'total_flows': 0,
                'total_ports': 0,
                'total_graphs': 0,
                'error': 'VM_FAWN parsing failed, using fallback'
            }
        }


# Test function
if __name__ == "__main__":
    parser = VMFAWNIntegratedParser()

    test_file = Path("Input Files/blade/mp/265_fileTransferToHadoopServer.mp")
    if test_file.exists():
        result = parser.parse_mp_file(
            file_path=str(test_file),
            output_folder="outputs/test_vm_fawn_integrated"
        )
        print(f"\\n✅ Test complete: {result['summary']}")
    else:
        print(f"❌ Test file not found: {test_file}")
