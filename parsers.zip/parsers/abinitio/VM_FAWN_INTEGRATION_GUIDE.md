# VM_FAWN Integration Guide for STAG

## Overview

VM_FAWN (detailed Ab Initio parser) is now integrated with STAG to extract comprehensive transformation details from .mp files. This enables STAG to answer detailed questions about DMLs, transformation rules, and data flows.

## Architecture

### Before Integration (Problem)
```
.mp file → EnhancedAbInitioParser → JSON with only:
  - component_id, component_type, name, raw_content
  - Missing: DML, transformation rules, layout paths

Result: GraphFlow Excel had structure but EMPTY data columns
        STAG couldn't answer transformation questions
```

### After Integration (Solution)
```
.mp file → VM_FAWN parser (manual) → Excel with sheets:
           - DataSet (file info, DML)
           - Component&Fields (transformation rules, keys)
           - GraphParameters (graph parameters)
           - GraphFlow (data flows)

Excel → VMFAWNExcelConverter → Enhanced JSON with:
        - Proper attributes.dml
        - attributes.transform_rule
        - attributes.layout
        - attributes.keys

JSON → GraphFlow Generator → Excel with ACTUAL data
JSON → STAG Vector DB → Answer detailed questions
```

## Workflow

### Step 1: Run VM_FAWN Parser (Manual)

VM_FAWN must be run separately to generate Excel files:

**Location**: `/Users/ankurshome/Desktop/Hadoop_Parser/CodebaseIntelligence/Input Files/VM_FAWN`

**Output folder**: `Input Files/VM_FAWN/bbi_preprocessing_output/`

**Expected output**: `{filename}_YYYY_MM_DD_HH_MM_SS.xlsx`

Example:
```
265_fileTransferToHadoopServer.mp
  → 265_fileTransferToHadoopServer_2025_11_20_14_18_33.xlsx
```

### Step 2: Index with STAG (Automatic)

Once VM_FAWN Excel exists, STAG automatically detects and uses it:

1. Open STAG UI
2. Go to "Indexing & Management" → "Ab Initio Graphs"
3. Upload/Select .mp file (e.g., `265_fileTransferToHadoopServer.mp`)
4. Check options:
   - ✅ Generate GraphFlow Excel
   - ✅ Generate STTM Mappings (optional, may hit rate limits)
5. Click "Index Graph"

**What happens**:
```
STAG checks: Does VM_FAWN Excel exist for this .mp file?

  YES → Use VMFAWNExcelConverter
        ℹ️ Display: "📊 Found VM_FAWN Excel - Using detailed transformation extraction"

  NO  → Use EnhancedAbInitioParser (fallback)
        ℹ️ Display: "📋 No VM_FAWN Excel found - Using Enhanced Parser (basic extraction)"
```

### Step 3: Verify Output

Check that GraphFlow Excel has actual data:

**Location**: `outputs/graphflows/{filename}_graphflow.xlsx`

**Verify**:
- Vertices sheet → Type, Layout, DML columns should have values
- Before: 0/1295 vertices with DML, 0/1295 with Layout
- After:  36/36 vertices with Layout, 1/36 with DML (expected)

## File Structure

```
CodebaseIntelligence/
├── parsers/abinitio/
│   ├── vm_fawn/                          # Copied VM_FAWN parser
│   │   ├── parser.py                     # Main parsing logic
│   │   ├── config.py                     # Configuration
│   │   ├── utils.py                      # Utility functions
│   │   └── .ip/                          # Encryption keys
│   ├── vm_fawn_excel_converter.py        # 🆕 Excel → JSON converter
│   ├── vm_fawn_integrated_parser.py      # (unused) Attempted full integration
│   ├── enhanced_parser.py                # Fallback basic parser
│   └── graph_flow/
│       └── excel_generator.py            # GraphFlow Excel generator
├── Input Files/
│   ├── VM_FAWN/
│   │   └── bbi_preprocessing_output/     # VM_FAWN Excel outputs
│   └── blade/mp/                         # Source .mp files
├── outputs/
│   ├── parsed_abinitio/                  # Enhanced JSON outputs
│   └── graphflows/                       # GraphFlow Excel outputs
└── stag_app.py                           # 🔧 Updated with VM_FAWN detection
```

## Key Functions

### `_find_vm_fawn_excel_for_mp(mp_file_path: Path)`
**Location**: [stag_app.py:2364](stag_app.py#L2364)

Searches for VM_FAWN Excel matching pattern: `{mp_basename}_*.xlsx`

Returns most recent Excel if multiple exist.

### `VMFAWNExcelConverter.convert_excel_to_json()`
**Location**: [vm_fawn_excel_converter.py:22](vm_fawn_excel_converter.py#L22)

Converts VM_FAWN Excel sheets to Enhanced Parser JSON format:
- Reads 4 sheets: DataSet, Component&Fields, GraphParameters, GraphFlow
- Builds vertices with proper attributes (dml, transform_rule, layout, keys)
- Extracts DML from transform_rule via regex
- Truncates long transformation rules (500 char limit)

### Enhanced JSON Format
```json
{
  "metadata": {
    "source_file": "265_fileTransferToHadoopServer.mp",
    "parser_version": "vm_fawn_excel_converter_v1"
  },
  "vertices": {
    "transform_0": {
      "component_id": "0",
      "component_type": "Reformat",
      "name": "Reformat",
      "type": "Reformat",
      "attributes": {
        "transform_component": "Reformat",
        "transform_rule": "let string ...",
        "trans_location": "!prototype_path",
        "keys": "",
        "dml": "extracted_dml_value",
        "layout": "!prototype_path",
        "subgraph_hierarchy": "main",
        "final_subgraph": "main"
      }
    }
  },
  "summary": {
    "total_vertices": 36,
    "components_with_transforms": 35,
    "datasets_count": 1
  }
}
```

## Testing

### Test VM_FAWN Detection
```bash
python3 -c "
from pathlib import Path

def _find_vm_fawn_excel_for_mp(mp_file_path: Path):
    mp_basename = mp_file_path.stem
    vm_fawn_folder = Path('Input Files/VM_FAWN/bbi_preprocessing_output')
    matching_files = list(vm_fawn_folder.glob(f'{mp_basename}_*.xlsx'))
    return max(matching_files, key=lambda p: p.stat().st_mtime) if matching_files else None

test_mp = Path('Input Files/blade/mp/265_fileTransferToHadoopServer.mp')
result = _find_vm_fawn_excel_for_mp(test_mp)
print(f'VM_FAWN Excel: {result}')
"
```

### Test Converter
```bash
python3 parsers/abinitio/vm_fawn_excel_converter.py \
  "Input Files/VM_FAWN/bbi_preprocessing_output/265_fileTransferToHadoopServer_2025_11_20_14_18_33.xlsx" \
  "Input Files/blade/mp/265_fileTransferToHadoopServer.mp" \
  "outputs/test_vm_fawn_integration/265_components.json"
```

### Test GraphFlow Generation
```python
from parsers.abinitio.graph_flow.excel_generator import GraphFlowExcelGenerator

gen = GraphFlowExcelGenerator()
result = gen.generate_from_parsed_json(
    parsed_json_path='outputs/test_vm_fawn_integration/265_components.json',
    output_folder='outputs/test_vm_fawn_integration',
    base_filename='265_test'
)

# Check result
print(f"Vertices: {result['vertices_count']}")
print(f"Success: {result['success']}")
```

## Troubleshooting

### "No VM_FAWN Excel found" Warning

**Cause**: VM_FAWN parser hasn't been run on this .mp file yet

**Solution**:
1. Run VM_FAWN parser manually on the .mp file
2. Ensure output Excel is in `Input Files/VM_FAWN/bbi_preprocessing_output/`
3. File naming must match: `{mp_basename}_*.xlsx`

**Fallback**: STAG will use EnhancedAbInitioParser (basic extraction)

### GraphFlow Excel has empty data columns

**Cause**: Using EnhancedAbInitioParser (not VM_FAWN converter)

**Verify**: Check STAG UI message:
- ✅ "📊 Found VM_FAWN Excel - Using detailed transformation extraction"
- ❌ "📋 No VM_FAWN Excel found - Using Enhanced Parser (basic extraction)"

**Solution**: Ensure VM_FAWN Excel exists and is properly named

### Converter fails with "FileNotFoundError"

**Cause**: Path issue or file doesn't exist

**Verify paths**:
```bash
ls "Input Files/VM_FAWN/bbi_preprocessing_output/"
ls "Input Files/blade/mp/"
```

**Check working directory**: Converter expects to run from repository root

### DML extraction returns empty string

**Cause**: transform_rule doesn't contain `dml:` or `dml=` pattern

**This is expected**: Not all components have DML in their transformation rules

**DML sources**:
1. Extracted from transform_rule via regex: `dml\s*[:=]\s*["']?([^"';\\s]+)`
2. From DataSet sheet's DML column (for dataset vertices)

## Benefits

### Before VM_FAWN Integration

STAG could answer:
- ❌ "What transformations happen in component X?"
- ❌ "What is the DML for dataset Y?"
- ❌ "Show me all Reformat components with keys"
- ✅ "List all components" (basic structure only)

### After VM_FAWN Integration

STAG can answer:
- ✅ "What transformations happen in component X?" → Shows transform_rule
- ✅ "What is the DML for dataset Y?" → Shows DML
- ✅ "Show me all Reformat components with keys" → Filters by type and keys
- ✅ "Compare transformation logic between graphs"
- ✅ "Find components with partitioning keys"
- ✅ "What are the input/output layouts?"

## Performance

### Conversion Speed
- Small graph (35 components): ~1 second
- Large graph (1000+ components): ~5-10 seconds

### Storage
- VM_FAWN Excel: 50-200 KB per graph
- Enhanced JSON: 100-500 KB per graph (includes raw_content)
- GraphFlow Excel: 100-300 KB per graph

### Rate Limits
- GraphFlow: No API calls, instant generation
- STTM: Uses OpenAI API, may hit rate limits on large graphs (>200 vertices)
- Recommendation: Uncheck "Generate STTM" for large graphs

## Known Limitations

1. **VM_FAWN must be run manually** - Not automated in STAG workflow yet
2. **No flow connections** - VM_FAWN GraphFlow sheet is empty, need GraphFlow generator
3. **DML extraction incomplete** - Regex-based, may miss complex DML syntax
4. **Transform rule truncation** - Rules >500 chars truncated to avoid context overflow
5. **Backward compatibility** - Old indexed graphs need re-indexing with VM_FAWN

## Future Enhancements

- [ ] Automate VM_FAWN parser execution from STAG
- [ ] Extract flow connections from transformation rules
- [ ] Improve DML extraction with AST parsing
- [ ] Batch processing for multiple graphs
- [ ] Progress tracking for large graphs
- [ ] Comparison reports: VM_FAWN vs Enhanced Parser output

## Support

For issues or questions:
1. Check STAG UI messages for parser selection
2. Verify VM_FAWN Excel exists and is recent
3. Test converter with CLI to isolate issues
4. Check logs: STAG prints detailed conversion summary
5. Compare output: Check if GraphFlow has actual data

## Example: Full Workflow

```bash
# Step 1: Run VM_FAWN parser (manual, external tool)
# Output: Input Files/VM_FAWN/bbi_preprocessing_output/265_fileTransferToHadoopServer_2025_11_20_14_18_33.xlsx

# Step 2: Index with STAG (automatic detection)
# Opens STAG UI → Indexing → Upload 265_fileTransferToHadoopServer.mp
# STAG shows: "📊 Found VM_FAWN Excel - Using detailed transformation extraction"
# Output: outputs/parsed_abinitio/265_fileTransferToHadoopServer_components.json
#         outputs/graphflows/265_fileTransferToHadoopServer_graphflow.xlsx

# Step 3: Verify GraphFlow has data
python3 -c "
import pandas as pd
df = pd.read_excel('outputs/graphflows/265_fileTransferToHadoopServer_graphflow.xlsx',
                   sheet_name='Vertices')
print(f'Vertices with Layout: {df[\"Layout\"].notna().sum()} / {len(df)}')
print(f'Vertices with DML: {df[\"DML\"].notna().sum()} / {len(df)}')
"
# Output: Vertices with Layout: 36 / 36  ✅
#         Vertices with DML: 1 / 36      ✅ (expected)

# Step 4: Query STAG
# Chat: "What transformations happen in the Reformat component?"
# STAG retrieves from vector DB with actual transform_rule, DML, layout data
```

## Conclusion

VM_FAWN integration transforms STAG from a structure-only parser to a comprehensive transformation analyzer. This enables detailed Q&A about Ab Initio logic, DMLs, and data flows - critical for migration and comparison tasks.
