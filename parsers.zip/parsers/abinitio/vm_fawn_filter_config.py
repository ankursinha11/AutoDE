"""
VM_FAWN Intelligent Filter Configuration
Based on real Ab Initio developer filtering patterns from graph 1500_CDD_TUSourcedFamilyMemberLink

This configuration reduces Component&Fields rows by 95%+ while preserving all business logic.
"""

from typing import Set, List
from dataclasses import dataclass, field


@dataclass
class FilterConfig:
    """Configuration for VM_FAWN intelligent filtering"""

    # TransLocation values to KEEP (business logic)
    KEEP_TRANSLOCATION: Set[str] = field(default_factory=lambda: {
        # Core transformation logic
        'transform',
        'transform0',
        'transform1',
        'transform2',

        # Filter conditions (WHERE clauses)
        'select_expr',

        # Keys (join, lookup, sort, partition)
        'key',
        'keys',
        'major_key',
        'minor_key',
        'override_key1',
        'override_key2',

        # Data structures
        'RecordFormat',
        'write_metadata',
        'dml',

        # Component layout (needed for diagram generation)
        'Layout',

        # Operation modes
        'mode',

        # Additional business logic indicators
        'partition',
        'rollup',
        'aggregate',
        'having_expr',
    })

    # TransLocation values to REMOVE (noise - infrastructure/boilerplate)
    REMOVE_TRANSLOCATION: Set[str] = field(default_factory=lambda: {
        # Metadata boilerplate (most common noise)
        'out0_metadata',
        'out1_metadata',
        'out2_metadata',
        'out_metadata',
        'in_metadata',
        'in0_metadata',
        'in1_metadata',
        'error_metadata',
        'error0_metadata',
        'error1_metadata',
        'error2_metadata',
        'log_metadata',
        'fileerror_metadata',

        # Component library paths
        '!prototype_path',

        # Internal Ab Initio flags
        '_propagate_through',
        'condition_interpretation',
        'eme_dataset_mapping',

        # Infrastructure settings
        'max_core',
        'max_memory',
        'passphrase',
        'commandline',
        'command_line',
        'num_records',
        'checkpoint',
        'checkpoint_threshold',
        'disable',
        'enable',

        # Test/debug settings
        'keep',
        'drop',
    })

    # Component types to ALWAYS keep (regardless of TransLocation)
    CRITICAL_COMPONENT_TYPES: Set[str] = field(default_factory=lambda: {
        # Input/Output
        'Input_File',
        'Output_File',
        'Lookup_File',

        # Transformations
        'Join',
        'Reformat',
        'Filter_by_Expression',
        'Normalize',

        # Data operations
        'Dedup_Sorted',
        'Sort',
        'Aggregate',
        'Rollup',
        'Scan',

        # Flow control
        'Broadcast',
        'Gather',
        'Partition_by_Key',
    })

    # Patterns in Transform Rule that indicate NOISE (remove)
    NOISE_PATTERNS: List[str] = field(default_factory=lambda: [
        r'\$AB_HOME/include/error-info\.dml',
        r'\$AB_HOME/include/log-info\.dml',
        r'metadata type: out = in',
        r'metadata type: in = out',
        r'^file:\.$',  # Just "file:."
        r'^\d+$',  # Just a number
        r'^string\([\'"]?\w*[\'"]?\)$',  # Just string('n') or similar
        r'^void\(\d+\)$',  # void(1)
        r'^record\s*end;?$',  # Empty record definition
    ])

    # Component name patterns that indicate NOISE (infrastructure/utility components)
    NOISE_COMPONENT_NAME_PATTERNS: List[str] = field(default_factory=lambda: [
        r'splitStringToFilePath',
        r'splitStringTo',
        r'filterInputDataBase',
        r'filterInputData(?!.*\w)',  # Generic filterInputData
        r'filterOutputData',
        r'filterBasedOnDateInFile',
        r'filterBasedOnFile',
    ])

    # Component name patterns that indicate CRITICAL LOGIC (business components)
    CRITICAL_COMPONENT_NAME_PATTERNS: List[str] = field(default_factory=lambda: [
        r'\(.*\)',  # Any component with parenthetical description like "(PermID)" or "(Family Linking)"
        r'PermID',
        r'Family',
        r'Linking',
        r'Filter Out',
        r'Drop',
        r'Match',
    ])

    # Patterns in Transform Rule that indicate CRITICAL LOGIC (keep)
    CRITICAL_PATTERNS: List[str] = field(default_factory=lambda: [
        # Transformation syntax
        r'out::',
        r'in\d*\.',

        # Operations
        r'join\s*\(',
        r'lookup\s*\(',
        r'aggregate\s*\(',
        r'rollup\s*\(',
        r'normalize\s*\(',

        # DML references
        r'\.dml',
        r'include\s+',

        # SQL-like syntax
        r'where\s+',
        r'select\s+',
        r'case\s+when',
        r'if\s+.*\s+then',

        # Expressions
        r'let\s+',
        r':=',
        r'::',

        # Functions
        r'string_split',
        r'string_concat',
        r'substring',
        r'decimal_',
        r'date_',
        r'length_of',
    ])


# Global default configuration
DEFAULT_FILTER_CONFIG = FilterConfig()
