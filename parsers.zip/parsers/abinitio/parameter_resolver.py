"""
Ab Initio Parameter Resolver
Resolves ${VARIABLE} references using .pset files

Example:
    ${outputMfsFilePath} → /data/mfs/output
    ${fileNamePrefix} → CDD_
"""

import re
from pathlib import Path
from typing import Dict, Optional
import logging

logger = logging.getLogger(__name__)


class AbInitioParameterResolver:
    """
    Resolves Ab Initio parameter references
    """

    def __init__(self):
        self.parameters = {}
        self.pset_files_loaded = []

    def load_pset(self, pset_path: str) -> int:
        """
        Load parameters from .pset file

        Args:
            pset_path: Path to .pset file

        Returns:
            Number of parameters loaded
        """
        pset_path = Path(pset_path)

        if not pset_path.exists():
            logger.warning(f"PSET file not found: {pset_path}")
            return 0

        try:
            with open(pset_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()

            # Parse parameter assignments
            # Format: VARIABLE_NAME : value
            # Can be multi-line
            pattern = r'(\w+)\s*:\s*(.+?)(?=\n\w+\s*:|$)'
            matches = re.findall(pattern, content, re.DOTALL)

            count = 0
            for var_name, var_value in matches:
                var_name = var_name.strip()
                var_value = var_value.strip()

                # Clean up value (remove quotes, trailing semicolons, etc.)
                var_value = var_value.strip('"\'').strip(';')

                self.parameters[var_name] = var_value
                count += 1

            self.pset_files_loaded.append(str(pset_path))
            logger.info(f"Loaded {count} parameters from: {pset_path.name}")
            return count

        except Exception as e:
            logger.error(f"Error loading pset {pset_path}: {e}")
            return 0

    def load_multiple_psets(self, pset_paths: list) -> int:
        """
        Load parameters from multiple .pset files

        Args:
            pset_paths: List of .pset file paths

        Returns:
            Total number of parameters loaded
        """
        total = 0
        for pset_path in pset_paths:
            total += self.load_pset(pset_path)
        return total

    def resolve(self, text: str) -> str:
        """
        Resolve ${VAR} references in text

        Args:
            text: Text containing ${VAR} references

        Returns:
            Text with variables resolved
        """
        if not text or text == 'nan':
            return text

        # Find all ${VAR} patterns
        pattern = r'\$\{(\w+)\}'

        def replace_var(match):
            var_name = match.group(1)
            if var_name in self.parameters:
                resolved_value = self.parameters[var_name]
                logger.debug(f"Resolved ${{{var_name}}} → {resolved_value}")
                return resolved_value
            else:
                # Keep original if not found
                return match.group(0)

        resolved = re.sub(pattern, replace_var, text)

        # Also handle $VAR format (without braces)
        pattern_no_braces = r'\$(\w+)'

        def replace_var_no_braces(match):
            var_name = match.group(1)
            if var_name in self.parameters:
                return self.parameters[var_name]
            else:
                return match.group(0)

        resolved = re.sub(pattern_no_braces, replace_var_no_braces, resolved)

        return resolved

    def get_parameter(self, name: str) -> Optional[str]:
        """
        Get parameter value by name

        Args:
            name: Parameter name

        Returns:
            Parameter value or None if not found
        """
        return self.parameters.get(name)

    def has_parameter(self, name: str) -> bool:
        """Check if parameter exists"""
        return name in self.parameters

    def get_all_parameters(self) -> Dict[str, str]:
        """Get all loaded parameters"""
        return self.parameters.copy()

    def get_statistics(self) -> Dict[str, any]:
        """Get loading statistics"""
        return {
            'total_parameters': len(self.parameters),
            'pset_files_loaded': len(self.pset_files_loaded),
            'pset_files': self.pset_files_loaded
        }
