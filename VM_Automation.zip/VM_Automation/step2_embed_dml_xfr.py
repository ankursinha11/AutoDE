"""
Step 2: Embed DML/XFR Content Using GPT-5 LLM (Hierarchical Processing)

This script:
1. Reads detailed_graph_1.json
2. Processes graphs in HIERARCHICAL ORDER (deepest level first)
3. For each vertex in a graph, uses GPT-5 LLM to extract .dml and .xfr filenames from raw_content
4. Reads the actual file content from data/ folder
5. Embeds the file content into the vertex JSON as "referenced_files": {"filename.dml": "content"}
6. Outputs detailed_graph_1_with_files.json
"""

import json
import sys
import os
from openai import AzureOpenAI
from pathlib import Path
from typing import Dict, List, Any, Optional
import re

# Azure OpenAI Configuration
AZURE_ENDPOINT = "https://modelcodex.cognitiveservices.azure.com/"
MODEL_NAME = "gpt-5"
DEPLOYMENT = "gpt-5"
SUBSCRIPTION_KEY = "E1YX4tsaRg9dYYToH05rUCi3EiikWM4irps35RUGxzZsKKTnMiSyJQQJ99BKACHYHv6XJ3w3AAABACOGXJQu"
API_VERSION = "2024-12-01-preview"


class GPTLLM:
    """Wrapper for GPT-5 LLM via Azure OpenAI"""

    def __init__(self):
        """Initialize Azure OpenAI client"""
        print("🔧 Initializing GPT-5 LLM...")
        self.client = AzureOpenAI(
            api_version=API_VERSION,
            azure_endpoint=AZURE_ENDPOINT,
            api_key=SUBSCRIPTION_KEY,
        )
        self.deployment = DEPLOYMENT
        print(f"✅ GPT-5 LLM initialized (Model: {MODEL_NAME})\n")

    def invoke(self, prompt: str, max_tokens: int = 2000) -> str:
        """
        Invoke GPT-5 model with a prompt

        Args:
            prompt: The prompt to send to GPT-5
            max_tokens: Maximum tokens in response

        Returns:
            Response text from GPT-5
        """
        try:
            response = self.client.chat.completions.create(
                messages=[
                    {
                        "role": "system",
                        "content": "You are an AbInitio ETL expert."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                max_completion_tokens=max_tokens,
                model=self.deployment
            )

            return response.choices[0].message.content

        except Exception as e:
            print(f"❌ Error invoking GPT-5: {str(e)}")
            raise


class DMLXFREmbedder:
    """Embeds DML/XFR file content into graph vertices using hierarchical processing"""

    def __init__(self, detailed_graph_path: str, data_folder: str = "data"):
        """
        Initialize embedder

        Args:
            detailed_graph_path: Path to detailed_graph_1.json
            data_folder: Folder containing .dml and .xfr files
        """
        self.detailed_graph_path = Path(detailed_graph_path)
        self.data_folder = Path(data_folder)
        self.llm = GPTLLM()
        self.file_cache = {}  # Cache for file contents
        self.processed_count = 0

        # Load all .dml and .xfr files
        self._load_files()

    def _load_files(self):
        """Load all .dml and .xfr files from data folder into cache (recursive search in all subfolders)"""
        print(f"📂 Loading files from: {self.data_folder} (including all subfolders)")

        for ext in ['.dml', '.xfr']:
            # Use **/* for recursive search in all subfolders
            files = list(self.data_folder.glob(f"**/*{ext}"))
            for file_path in files:
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                        # Store with just filename (assumption: one file can only be in one folder)
                        self.file_cache[file_path.name] = content
                        # Show which subfolder it came from
                        relative_path = file_path.relative_to(self.data_folder)
                        print(f"   ✅ {file_path.name} (from {relative_path.parent}/)")
                except Exception as e:
                    print(f"   ❌ Failed to load {file_path.name}: {e}")

        print(f"\n✅ Total files loaded: {len(self.file_cache)}")
        print(f"   Available files: {sorted(self.file_cache.keys())}\n")

    def extract_file_references_from_graph(self, graph_data: Dict) -> List[str]:
        """
        Use Claude LLM to extract .dml and .xfr filenames from entire graph
        (graph raw_content + all vertices raw_content)

        Args:
            graph_data: Graph dictionary with raw_content and vertices

        Returns:
            List of unique filenames (e.g., ["file1.dml", "file2.xfr"])
        """
        graph_id = graph_data.get('graph_id', 'Unknown')
        graph_name = graph_data.get('name', 'Unknown')
        graph_raw_content = graph_data.get('raw_content', '')
        vertices = graph_data.get('vertices', {})

        # Build complete raw content block
        vertices_raw_blocks = []
        for vertex_id, vertex_data in vertices.items():
            vertex_raw = vertex_data.get('raw_content', '')
            if vertex_raw:
                vertices_raw_blocks.append(f"Vertex {vertex_id} ({vertex_data.get('vertex_name', 'Unknown')}):\n{vertex_raw}")

        all_raw_content = f"""Graph Raw Content:
{graph_raw_content}

Vertices Raw Content:
{chr(10).join(vertices_raw_blocks)}
"""

        # Create prompt for Claude
        prompt = f"""You are an AbInitio ETL expert. Extract ALL .dml and .xfr filenames referenced in this graph.

Graph ID: {graph_id}
Graph Name: {graph_name}

{all_raw_content}

Instructions:
1. Look for .dml and .xfr file references in BOTH graph raw_content and ALL vertices raw_content
2. Common patterns:
   - include "~$AI_DML/filename.dml"
   - include "filename.xfr"
   - Metadata references (read_metadata, out_metadata, etc.)
   - Transform references (transform0, etc.)
3. Extract ONLY the base filename (e.g., "eScanCommonFunctions.xfr", "ediComGenUserDefinedTypes.dml")
4. Do NOT include paths or prefixes like "~$AI_DML/"
5. Return unique filenames only (no duplicates)

Return EXACTLY this format (nothing else):
```json
["filename1.dml", "filename2.xfr"]
```

If no .dml or .xfr files found, return:
```json
[]
```
"""

        try:
            print(f"   🤖 Calling GPT-5 to extract files from Graph {graph_id}...")
            response = self.llm.invoke(prompt, max_tokens=2000)

            # Extract JSON from response
            json_match = re.search(r'```json\s*([\s\S]*?)\s*```', response)
            if json_match:
                json_str = json_match.group(1).strip()
                filenames = json.loads(json_str)
            else:
                # Try to parse entire response as JSON
                filenames = json.loads(response.strip())

            if not isinstance(filenames, list):
                print(f"   ⚠️  Expected list, got {type(filenames)}")
                return []

            # Remove duplicates
            filenames = list(set(filenames))
            return filenames

        except Exception as e:
            print(f"   ❌ Error extracting files: {e}")
            return []

    def process_graph_hierarchical(self, graph_data: Dict, level: int = 0) -> Dict:
        """
        Process a graph hierarchically (deepest first)

        Args:
            graph_data: Graph dictionary
            level: Current level in hierarchy

        Returns:
            Updated graph data with embedded files at graph level
        """
        graph_id = graph_data.get('graph_id')
        graph_name = graph_data.get('name')
        indent = "  " * level

        print(f"\n{indent}{'='*60}")
        print(f"{indent}📊 Graph {graph_id}: {graph_name} (Level {level})")
        print(f"{indent}{'='*60}")

        # FIRST: Process dependencies (deepest first - REVERSE ORDER)
        dependencies = graph_data.get('dependencies', [])
        if dependencies:
            print(f"{indent}🔽 Processing {len(dependencies)} dependencies first...\n")
            for i, dep in enumerate(dependencies):
                graph_data['dependencies'][i] = self.process_graph_hierarchical(dep, level + 1)

        # THEN: Process current graph - extract files from entire graph
        print(f"\n{indent}🔄 Processing Graph {graph_id}...")
        print(f"{indent}   Vertices: {len(graph_data.get('vertices', {}))}")

        # Extract filenames from entire graph (graph raw + all vertices raw)
        filenames = self.extract_file_references_from_graph(graph_data)

        if filenames:
            print(f"{indent}   📄 Found {len(filenames)} unique file(s): {filenames}")

            # Build referenced_files dictionary with content
            referenced_files = {}
            for filename in filenames:
                if filename in self.file_cache:
                    referenced_files[filename] = self.file_cache[filename]
                    print(f"{indent}      ✅ {filename} (content embedded)")
                else:
                    print(f"{indent}      ⚠️  {filename} NOT FOUND in data/ folder")

            if referenced_files:
                # Add referenced_files at GRAPH level, not vertex level
                graph_data['referenced_files'] = referenced_files
                self.processed_count += len(referenced_files)
                print(f"{indent}   ✅ Embedded {len(referenced_files)} file(s) at graph level")
        else:
            print(f"{indent}   ➖ No .dml/.xfr files referenced")

        print(f"\n{indent}✅ Graph {graph_id} processing complete!")

        return graph_data

    def embed_files(self, output_path: str = "detailed_graph_1_with_files.json"):
        """
        Main function to embed files into detailed graph using hierarchical order

        Args:
            output_path: Output JSON file path
        """
        print(f"\n{'='*80}")
        print("STEP 2: EMBED DML/XFR FILES (HIERARCHICAL PROCESSING)")
        print(f"{'='*80}\n")

        # Load detailed_graph_1.json
        print(f"📖 Loading: {self.detailed_graph_path}")
        with open(self.detailed_graph_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        print(f"✅ Loaded successfully!\n")

        # Process main graph hierarchically (deepest first)
        print("🔄 Starting hierarchical processing (deepest level first)...\n")
        data['graph'] = self.process_graph_hierarchical(data['graph'], level=0)

        # Save output
        output_file = Path(output_path)
        print(f"\n{'='*80}")
        print(f"💾 Saving to: {output_file}")

        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        file_size = output_file.stat().st_size / 1024
        print(f"✅ Saved successfully! File size: {file_size:.2f} KB")

        print(f"\n{'='*80}")
        print("📊 SUMMARY")
        print(f"{'='*80}")
        print(f"Total file references embedded: {self.processed_count}")
        print(f"Output file: {output_file}")
        print(f"{'='*80}")
        print("\n✅ STEP 2 COMPLETE!\n")


def main():
    """Main execution"""
    print("🚀 Starting Step 2...")
    print("""
╔════════════════════════════════════════════════════════════════════════════╗
║         STEP 2: EMBED DML/XFR FILES WITH GPT-5 LLM (HIERARCHICAL)          ║
║                                                                            ║
║  Processing order: DEEPEST LEVEL FIRST (reverse hierarchy)                ║
║                                                                            ║
║  For each vertex:                                                          ║
║  1. Pass vertex raw_content to GPT-5 LLM                                   ║
║  2. Extract .dml and .xfr filenames                                        ║
║  3. Read file content from data/ folder                                    ║
║  4. Embed as "referenced_files": {"filename": "content"}                   ║
╚════════════════════════════════════════════════════════════════════════════╝
    """)

    # Get input JSON file path from user
    detailed_graph_path = input("Enter the path to the detailed graph JSON file from Step 1: ").strip()

    # Extract output folder and base filename from input path
    input_path = Path(detailed_graph_path)
    output_folder = input_path.parent

    # Extract base filename (remove "_detailed_graph_1" suffix)
    base_filename = input_path.stem.replace("_detailed_graph_1", "")

    # Set output file path
    output_path = output_folder / f"{base_filename}_detailed_graph1_with_files.json"

    print(f"\n📁 Output will be saved to: {output_path}\n")

    try:
        embedder = DMLXFREmbedder(
            detailed_graph_path=detailed_graph_path,
            data_folder="data"
        )

        embedder.embed_files(output_path=str(output_path))

        return 0

    except Exception as e:
        print(f"\n❌ ERROR: {str(e)}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
