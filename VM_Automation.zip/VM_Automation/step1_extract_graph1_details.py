"""
Step 1: Extract Detailed Graph 1 Hierarchy from Subgraph JSON

This script extracts the complete hierarchy for graph ID 1 including:
- Main graph metadata and raw content
- All vertices with their data_in/data_out connections
- All dependent subgraphs (recursive)
- Outputs detailed_graph_1.json
"""

import json
import sys
from pathlib import Path
from typing import Dict, List, Set, Any
from collections import deque


class GraphExtractor:
    """Extracts and builds detailed hierarchy for a specific graph ID"""

    def __init__(self, subgraph_json_path: str):
        """
        Initialize extractor with subgraph JSON file

        Args:
            subgraph_json_path: Path to the subgraph JSON file
        """
        self.subgraph_json_path = Path(subgraph_json_path)
        self.subgraphs_data = None
        self.visited_graphs: Set[str] = set()

    def load_subgraph_json(self) -> Dict:
        """Load the subgraph JSON file"""
        print(f"📂 Loading subgraph JSON from: {self.subgraph_json_path}")

        if not self.subgraph_json_path.exists():
            raise FileNotFoundError(f"Subgraph JSON not found: {self.subgraph_json_path}")

        with open(self.subgraph_json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        self.subgraphs_data = data.get('subgraphs', {})
        print(f"✅ Loaded {len(self.subgraphs_data)} subgraphs from JSON")

        return data

    def find_graph_by_id(self, graph_id: str) -> Dict:
        """
        Find a graph by its ID in the subgraphs data

        Args:
            graph_id: The graph ID to search for

        Returns:
            Graph data dictionary or None if not found
        """
        if graph_id in self.subgraphs_data:
            return self.subgraphs_data[graph_id]

        # If not found directly, search by ID field
        for sg_id, sg_data in self.subgraphs_data.items():
            if sg_data.get('id') == graph_id:
                return sg_data

        return None

    def extract_subgraph_dependencies(self, vertices: Dict) -> List[str]:
        """
        Extract all subgraph IDs referenced in vertices

        Args:
            vertices: Dictionary of vertices

        Returns:
            List of subgraph IDs that are referenced
        """
        subgraph_ids = []

        for vertex_id, vertex_data in vertices.items():
            vertex_type = vertex_data.get('type', '')

            # XXGgraph type indicates a subgraph reference
            if vertex_type == 'XXGgraph':
                # The vertex_id itself is the subgraph ID
                subgraph_ids.append(vertex_id)

        return subgraph_ids

    def calculate_statistics(self, vertices: Dict) -> Dict:
        """
        Calculate statistics for vertices in a graph

        Args:
            vertices: Dictionary of vertices

        Returns:
            Statistics dictionary with exact format required
        """
        data_connection_count = 0
        config_connection_count = 0
        subgraph_reference_count = 0

        for vertex_id, vertex_data in vertices.items():
            vertex_type = vertex_data.get('type', '')

            # Count subgraph references
            if vertex_type == 'XXGgraph':
                subgraph_reference_count += 1

            # Count data connections
            data_in = vertex_data.get('data_in', [])
            data_out = vertex_data.get('data_out', [])
            data_connection_count += len(data_in) + len(data_out)

            # Count config connections
            config_in = vertex_data.get('config_in', [])
            config_out = vertex_data.get('config_out', [])
            config_connection_count += len(config_in) + len(config_out)

        stats = {
            "vertex_count": len(vertices),
            "data_connection_count": data_connection_count,
            "config_connection_count": config_connection_count,
            "subgraph_reference_count": subgraph_reference_count
        }

        return stats

    def build_subgraph_references(self, vertices: Dict) -> List[str]:
        """
        Build list of subgraph IDs referenced in this graph

        Args:
            vertices: Dictionary of vertices

        Returns:
            List of subgraph IDs (as strings)
        """
        references = []

        for vertex_id, vertex_data in vertices.items():
            vertex_type = vertex_data.get('type', '')

            # XXGgraph type indicates a subgraph reference
            if vertex_type == 'XXGgraph':
                references.append(vertex_id)

        return references

    def build_graph_hierarchy(self, graph_id: str, level: int = 0) -> Dict:
        """
        Recursively build complete hierarchy for a graph

        Args:
            graph_id: The graph ID to process
            level: Current depth level (for logging)

        Returns:
            Dictionary containing graph data with all dependencies
        """
        indent = "  " * level
        print(f"{indent}🔍 Processing graph ID: {graph_id} (Level {level})")

        # Prevent infinite loops
        if graph_id in self.visited_graphs:
            print(f"{indent}⚠️  Graph {graph_id} already visited, skipping")
            return None

        self.visited_graphs.add(graph_id)

        # Find graph data
        graph_data = self.find_graph_by_id(graph_id)

        if not graph_data:
            print(f"{indent}❌ Graph ID {graph_id} not found in subgraphs")
            return None

        vertices = graph_data.get('vertices', {})

        # Calculate statistics
        statistics = self.calculate_statistics(vertices)

        # Build subgraph references
        subgraph_refs = self.build_subgraph_references(vertices)

        # Extract basic graph info
        graph_info = {
            "graph_id": graph_id,
            "id": graph_data.get('id'),
            "name": graph_data.get('name'),
            "raw_content": graph_data.get('raw_content'),
            "vertices": vertices,
            "subgraph_references": subgraph_refs,
            "statistics": statistics,
            "dependencies": [],
            "level": level
        }

        print(f"{indent}📊 Graph: {graph_info['name']}")
        print(f"{indent}   Vertices: {len(vertices)}")
        print(f"{indent}   Subgraph refs: {subgraph_refs}")
        print(f"{indent}   Stats: {statistics}")

        # Find all subgraph dependencies
        subgraph_ids = self.extract_subgraph_dependencies(vertices)

        if subgraph_ids:
            print(f"{indent}   Dependencies: {subgraph_ids}")

        # Recursively process each dependency
        for dep_id in subgraph_ids:
            dep_graph = self.build_graph_hierarchy(dep_id, level + 1)
            if dep_graph:
                graph_info['dependencies'].append(dep_graph)

        return graph_info

    def extract_detailed_graph(self, target_graph_id: str = "1") -> Dict:
        """
        Extract complete detailed hierarchy for target graph

        Args:
            target_graph_id: The main graph ID to extract (default: "1")

        Returns:
            Detailed graph hierarchy dictionary
        """
        print(f"\n{'='*80}")
        print(f"🎯 Extracting detailed hierarchy for Graph ID: {target_graph_id}")
        print(f"{'='*80}\n")

        # Load subgraph JSON
        metadata = self.load_subgraph_json()

        # Build complete hierarchy
        detailed_graph = self.build_graph_hierarchy(target_graph_id)

        if not detailed_graph:
            raise ValueError(f"Graph ID {target_graph_id} not found or could not be processed")

        # Add metadata
        result = {
            "extraction_metadata": {
                "source_file": str(self.subgraph_json_path),
                "target_graph_id": target_graph_id,
                "total_graphs_extracted": len(self.visited_graphs),
                "extracted_graph_ids": list(self.visited_graphs),
                "original_metadata": metadata.get('metadata', {})
            },
            "graph": detailed_graph
        }

        print(f"\n{'='*80}")
        print(f"✅ Extraction Complete!")
        print(f"   Total graphs in hierarchy: {len(self.visited_graphs)}")
        print(f"   Graph IDs: {sorted(self.visited_graphs)}")
        print(f"{'='*80}\n")

        return result

    def save_to_file(self, data: Dict, output_path: str):
        """
        Save detailed graph to JSON file

        Args:
            data: Graph data dictionary
            output_path: Output file path
        """
        output_file = Path(output_path)

        print(f"💾 Saving detailed graph to: {output_file}")

        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        file_size = output_file.stat().st_size / 1024  # KB
        print(f"✅ Saved successfully! File size: {file_size:.2f} KB")


def main():
    """Main execution function"""

    print("""
╔════════════════════════════════════════════════════════════════════════════╗
║                    STEP 1: EXTRACT DETAILED GRAPH 1                        ║
║                                                                            ║
║  This script extracts the complete hierarchy for Graph ID 1 including:    ║
║  - Main graph metadata and raw content                                    ║
║  - All vertices with data_in/data_out connections                         ║
║  - All dependent subgraphs (recursive traversal)                          ║
╚════════════════════════════════════════════════════════════════════════════╝
    """)

    # Get input JSON file path from user
    SUBGRAPH_JSON = input("Enter the path to the subgraph JSON file: ").strip()
    TARGET_GRAPH_ID = "1"

    # Extract filename without extension from input path
    input_filename = Path(SUBGRAPH_JSON).stem

    # Create output folder with timestamp: filename_output_timestamp
    from datetime import datetime
    timestamp = datetime.now().strftime("%Y_%m_%d_%H_%M_%S")
    output_folder = Path(f"{input_filename}_output_{timestamp}")
    output_folder.mkdir(exist_ok=True)

    # Set output file path
    OUTPUT_FILE = output_folder / f"{input_filename}_detailed_graph_1.json"

    print(f"\n📁 Output folder created: {output_folder}")
    print(f"📁 Output file will be saved as: {OUTPUT_FILE}\n")

    try:
        # Initialize extractor
        extractor = GraphExtractor(SUBGRAPH_JSON)

        # Extract detailed graph
        detailed_graph = extractor.extract_detailed_graph(TARGET_GRAPH_ID)

        # Save to file
        extractor.save_to_file(detailed_graph, str(OUTPUT_FILE))

        # Print summary
        print("\n" + "="*80)
        print("📋 EXTRACTION SUMMARY")
        print("="*80)
        print(f"Main Graph ID:        {detailed_graph['graph']['graph_id']}")
        print(f"Main Graph Name:      {detailed_graph['graph']['name']}")
        print(f"Main Graph Vertices:  {len(detailed_graph['graph']['vertices'])}")
        print(f"Total Dependencies:   {len(detailed_graph['extraction_metadata']['extracted_graph_ids']) - 1}")
        print(f"Output File:          {OUTPUT_FILE}")
        print("="*80)

        # Show dependency tree
        print("\n📊 DEPENDENCY TREE:")
        print_dependency_tree(detailed_graph['graph'], indent=0)

        return 0

    except Exception as e:
        print(f"\n❌ ERROR: {str(e)}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        return 1


def print_dependency_tree(graph: Dict, indent: int = 0):
    """
    Print a visual dependency tree

    Args:
        graph: Graph data dictionary
        indent: Current indentation level
    """
    prefix = "  " * indent
    connector = "├─ " if indent > 0 else ""

    print(f"{prefix}{connector}Graph {graph['graph_id']}: {graph['name']}")
    print(f"{prefix}   Vertices: {len(graph['vertices'])}, Level: {graph['level']}")

    for i, dep in enumerate(graph.get('dependencies', [])):
        print_dependency_tree(dep, indent + 1)


if __name__ == "__main__":
    sys.exit(main())
