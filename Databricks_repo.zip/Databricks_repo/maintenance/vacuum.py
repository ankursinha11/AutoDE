# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user") 

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("input_path", "")
dbutils.widgets.getArgument("input_path")
input_path = getArgument("input_path")

dbutils.widgets.text("current_path", "")
dbutils.widgets.getArgument("current_path")
current_path = getArgument("current_path")

dbutils.widgets.text("config_path", "")
dbutils.widgets.getArgument("config_path")
config_path = getArgument("config_path")

dbutils.widgets.text("key", "")
dbutils.widgets.getArgument("key")
key = getArgument("key")

dbutils.widgets.text("vaccum_retention", "")
dbutils.widgets.getArgument("vaccum_retention")
vaccum_retention = getArgument("vaccum_retention")

# COMMAND ----------

if user == 'na' or user =='': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

config_path = baseurl + config_path
input_path = baseurl + input_path
current_path = current_path
print("current_path : ",current_path)
print("config_path : ",config_path)
print("input_path : ",input_path)

# COMMAND ----------

from delta.tables import *

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------


import pyspark.sql.functions as f

df = spark.read.option("multiline","true").json(config_path)
tbl_list = df.filter(f"key == '{key}'").groupby("key").agg(f.concat_ws(", ", f.collect_list(df.tablename)).alias("tablename")).select("tablename").collect()[0][0].split(",")
tbl_list

# COMMAND ----------

spark.sql("SET spark.databricks.delta.retentionDurationCheck.enabled = false")

# COMMAND ----------

for table in tbl_list:
    # path = f"{input_path}{table.strip()}/current/20991231/"
    path = f"{input_path}{table.strip()}" +current_path
    print(path)
    df_raw = DeltaTable.forPath(spark, path)
    df_raw.vacuum(vaccum_retention)
    df_raw.optimize().executeCompaction()
    print("DONE")

# COMMAND ----------


