# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql import Row, column
import datetime
from pyspark.sql import functions as F

# COMMAND ----------

# DBTITLE 1,PROD
# container = "prod-icd-adls"
# storageaccount = "prodicddls"
# user = "na"
# cosmosEndpoint = "https://prod-icd-cosmos.documents.azure.com:443/"
# cosmosDatabaseName = "insleads"
# cosmosContainerName = "chc_tracker"
# chc_lr_transaction = "/data/leadrepo/publish/cooked/chc_lr_transaction/"
# chc_publish = "/data/chc/publish/current/20991231/"
# chc_lr_xref_permid_transaction = "/data/leadrepo/publish/cooked/chc_lr_xref_permid_transaction/"
# chc_lr_xref_gmrnid_transaction = "/data/leadrepo/publish/cooked/chc_lr_xref_gmrnid_transaction"
# write_container = "icdleadsreports"
# write_storageaccount = "prodicdst"

# COMMAND ----------

# DBTITLE 1,STAGE
# container="prod-icd-stg-adls"
# storageaccount="prodicdstgdls"
# user="maxc"
# cosmosEndpoint="https://prod-icd-stg-cosmos.documents.azure.com:443/"
# cosmosDatabaseName="insleads"
# cosmosContainerName="chc_tracker"
# chc_lr_transaction="/data/leadrepo/publish/cooked/chc_lr_transaction/"
# chc_publish="/data/chc/publish/current/20991231/"
# chc_lr_xref_permid_transaction="/data/leadrepo/publish/cooked/chc_lr_xref_permid_transaction/"
# chc_lr_xref_gmrnid_transaction="/data/leadrepo/publish/cooked/chc_lr_xref_gmrnid_transaction"
# write_container="icdleadsreports"
# write_storageaccount="prodicdst"

# COMMAND ----------

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("write_container","")
dbutils.widgets.getArgument("write_container")
write_container= getArgument("write_container")

dbutils.widgets.text("write_storageaccount","")
dbutils.widgets.getArgument("write_storageaccount")
write_storageaccount= getArgument("write_storageaccount")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("cosmosEndpoint", "")
dbutils.widgets.getArgument("cosmosEndpoint")
cosmosEndpoint = getArgument("cosmosEndpoint")

dbutils.widgets.text("cosmosDatabaseName", "")
dbutils.widgets.getArgument("cosmosDatabaseName")
cosmosDatabaseName= getArgument("cosmosDatabaseName")

dbutils.widgets.text("cosmosContainerName", "")
dbutils.widgets.getArgument("cosmosContainerName")
cosmosContainerName = getArgument("cosmosContainerName")

dbutils.widgets.text("chc_lr_transaction", "")
dbutils.widgets.getArgument("chc_lr_transaction")
chc_lr_transaction = getArgument("chc_lr_transaction")

dbutils.widgets.text("chc_publish", "")
dbutils.widgets.getArgument("chc_publish")
chc_publish = getArgument("chc_publish")

dbutils.widgets.text("chc_lr_xref_permid_transaction", "")
dbutils.widgets.getArgument("chc_lr_xref_permid_transaction")
chc_lr_xref_permid_transaction = getArgument("chc_lr_xref_permid_transaction")

dbutils.widgets.text("chc_lr_xref_gmrnid_transaction", "")
dbutils.widgets.getArgument("chc_lr_xref_gmrnid_transaction")
chc_lr_xref_gmrnid_transaction = getArgument("chc_lr_xref_gmrnid_transaction")


# COMMAND ----------


#read storage acct
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

#write storage acct
spark.conf.set("fs.azure.account.key."+write_storageaccount+".blob.core.windows.net","IEfzxj47CMO5j8WXNcugYeiCG5Ip/pypR+apR+/eQUOUxA9wapX8oK6rIdn+K87Dvyezcix8wcSK+AStM0qxww==")

#read base url
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 


#write base url
if user == 'na': #defualt value
    # wasbs://icdleadsreports@prodicdst.blob.core.windows.net/
    write_baseurl ='wasbs://'+write_container+'@'+write_storageaccount+'.blob.core.windows.net'
else:
    write_baseurl ='wasbs://'+write_container+'@'+write_storageaccount+'.blob.core.windows.net/'+user+"/" 

path_chc_lr_transaction = baseurl+chc_lr_transaction
path_chc_publish = baseurl+chc_publish
path_chc_permid_transaction = baseurl+chc_lr_xref_permid_transaction
path_chc_gmrnid_transaction = baseurl+chc_lr_xref_gmrnid_transaction

print("path_chc_lr_transaction     : " + path_chc_lr_transaction)
print("path_chc_publish            : " + path_chc_publish)
print("path_chc_permid_transaction : " + path_chc_permid_transaction)
print("path_chc_gmrnid_transaction : " + path_chc_gmrnid_transaction)

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/cosmos_util

# COMMAND ----------

cosmosMasterKey = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-cosmos-insleads-kvsecret")
print("cosmosEndpoint :" + str(cosmosEndpoint))
print("cosmosMasterKey :" + str(cosmosMasterKey))
print("cosmosDatabaseName :" + str(cosmosDatabaseName))
print("cosmosContainerName :" + str(cosmosContainerName))
cosmosMasterKey = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-cosmos-insleads-kvsecret")

config = cosmosconfig(cosmosEndpoint, cosmosDatabaseName, cosmosContainerName)

def readFromCosmos(Endpoint,MasterKey,DatabaseName,ContainerName):
    readConf = {
    "spark.cosmos.accountEndpoint" : Endpoint,
    "spark.cosmos.accountKey" : MasterKey,
    "spark.cosmos.database" : DatabaseName,
    "spark.cosmos.container" : ContainerName
}
    df_read = spark.read.format("cosmos.oltp").options(**readConf).option("spark.cosmos.read.inferSchema.enabled", "true").load()
    return df_read

# COMMAND ----------

from datetime import datetime
currYear = datetime.now().year
filterExprYEAR = "lr_creatingmodule LIKE '" + str(currYear) + "%'"
print("filterExprYEAR : " + filterExprYEAR)

# COMMAND ----------

chc_tracker = readFromCosmos(cosmosEndpoint,cosmosMasterKey,cosmosDatabaseName,cosmosContainerName)
chc_tracker=chc_tracker.selectExpr("bc as lr_creatingmodule","bcsupload","bcsdownload","permid","gmrnid").filter(filterExprYEAR).dropDuplicates()
chc_tracker.write.mode("overwrite").parquet(write_baseurl + "/dashboard_run/chc/chc_tracker/")
chc_tracker.unpersist()
chc_tracker=spark.read.parquet(write_baseurl + "/dashboard_run/chc/chc_tracker/")
chc_tracker.createOrReplaceTempView("chc_tracker")

# COMMAND ----------

chc_transaction=spark.read.parquet(path_chc_lr_transaction)
chc_transaction=chc_transaction.selectExpr("lr_creatingmodule","transactionkey","coverageid","firstname","lastname","dob","ssn").filter(filterExprYEAR)

for column in chc_transaction.columns:
    chc_transaction = chc_transaction.withColumn(column, trim(col(column)))
    chc_transaction = chc_transaction.withColumn(column, when(col(column) == '', None).otherwise(col(column)))
    chc_transaction = chc_transaction.withColumn(column, when(col(column).isNull(), None).otherwise(col(column)))
    chc_transaction = chc_transaction.withColumn(column, when(upper(col(column)) == 'NULL',None).otherwise(col(column)))

chc_transaction.createOrReplaceTempView("chc_transaction")

chc_transaction=spark.sql("""
SELECT *,
       CASE
         WHEN (firstname IS NULL AND lastname IS NULL AND dob IS NULL AND ssn IS NULL) THEN '0'
         ELSE '1'
       END AS demo_valid
FROM chc_transaction
WHERE (coverageid IS NOT NULL
OR    TRIM(coverageid) <> '')
""")
# chc_transaction = chc_transaction.filter("demo_valid=='1'").drop("demo_valid").drop("transactionkey").dropDuplicates()
chc_transaction = chc_transaction.filter("demo_valid=='1'").drop("demo_valid").selectExpr("lr_creatingmodule","ssn","dob","firstname","lastname").dropDuplicates()
chc_transaction.createOrReplaceTempView("chc_transaction")
chc_transaction=spark.sql("""SELECT lr_creatingmodule,count(*) as trans_row_count FROM chc_transaction GROUP BY lr_creatingmodule""")

chc_transaction.write.mode("overwrite").parquet(write_baseurl + "/dashboard_run/chc/chc_transaction/")
chc_transaction.unpersist()
chc_transaction=spark.read.parquet(write_baseurl + "/dashboard_run/chc/chc_transaction/")
chc_transaction.createOrReplaceTempView("chc_transaction")

# COMMAND ----------

chc_gmrnid=spark.read.format("delta").load(path_chc_gmrnid_transaction).selectExpr("lr_creatingmodule","gmrnid").filter(filterExprYEAR)

for column in chc_gmrnid.columns:
    chc_gmrnid = chc_gmrnid.withColumn(column, trim(col(column)))
    chc_gmrnid = chc_gmrnid.withColumn(column, when(col(column) == '', None).otherwise(col(column)))
    chc_gmrnid = chc_gmrnid.withColumn(column, when(col(column).isNull(), None).otherwise(col(column)))
    chc_gmrnid = chc_gmrnid.withColumn(column, when(upper(col(column)) == 'NULL',None).otherwise(col(column)))

chc_gmrnid.createOrReplaceTempView("chc_gmrnid")

chc_gmrnid=spark.sql("""
SELECT lr_creatingmodule,
       gmrnid
FROM chc_gmrnid
WHERE (gmrnid IS NOT NULL
OR    TRIM(gmrnid) <> '')
""").dropDuplicates()

chc_gmrnid.createOrReplaceTempView("chc_gmrnid")

chc_gmrnid=spark.sql(""" SELECT lr_creatingmodule,count(*) as distinct_gmrnid_count FROM chc_gmrnid GROUP BY lr_creatingmodule""")
# chc_gmrnid.display()

chc_gmrnid.write.mode("overwrite").parquet(write_baseurl + "/dashboard_run/chc/chc_gmrnid/")
chc_gmrnid.unpersist()
chc_gmrnid=spark.read.parquet(write_baseurl + "/dashboard_run/chc/chc_gmrnid/")
chc_gmrnid.createOrReplaceTempView("chc_gmrnid")

# COMMAND ----------

chc_permid=spark.read.format("delta").load(path_chc_permid_transaction).filter(filterExprYEAR)
chc_permid=chc_permid.selectExpr("lr_creatingmodule","permid")

for column in chc_permid.columns:
    chc_permid = chc_permid.withColumn(column, trim(col(column)))
    chc_permid = chc_permid.withColumn(column, when(col(column) == '', None).otherwise(col(column)))
    chc_permid = chc_permid.withColumn(column, when(col(column).isNull(), None).otherwise(col(column)))
    chc_permid = chc_permid.withColumn(column, when(upper(col(column)) == 'NULL',None).otherwise(col(column)))

chc_permid.createOrReplaceTempView("chc_permid")
chc_permid=spark.sql("""
SELECT lr_creatingmodule,
       permid
FROM chc_permid
WHERE (permid IS NOT NULL
OR    TRIM(permid) <> '')
""").dropDuplicates()
chc_permid.createOrReplaceTempView("chc_permid")
chc_permid=spark.sql(""" SELECT lr_creatingmodule,count(*) as distinct_permid_count FROM chc_permid GROUP BY lr_creatingmodule""")

chc_permid.write.mode("overwrite").parquet(write_baseurl + "/dashboard_run/chc/chc_permid/")
chc_permid.unpersist()

chc_permid=spark.read.parquet(write_baseurl + "/dashboard_run/chc/chc_permid/")
chc_permid.createOrReplaceTempView("chc_permid")

# COMMAND ----------

from pyspark.sql.functions import collect_set, size, col, array_join

chc_publish=spark.read.parquet(path_chc_publish).selectExpr("lr_creatingmodule","CONCAT(eid,'_',carrier) as eid_carrier","bpe","basefilename_state").dropDuplicates()
chc_publish = chc_publish.groupBy("lr_creatingmodule","eid_carrier","bpe").agg(collect_set("basefilename_state").alias("state")).filter(filterExprYEAR)
chc_publish = chc_publish.withColumn("stateCount", size(col("state")))
chc_publish = chc_publish.withColumn("state",array_join(col("state"),","))
chc_publish.write.mode("overwrite").parquet(write_baseurl + "/dashboard_run/chc/chc_publish/")
chc_publish.unpersist()

chc_publish=spark.read.parquet(write_baseurl + "/dashboard_run/chc/chc_publish/")
chc_publish.createOrReplaceTempView("chc_publish")

# COMMAND ----------

chc_leads = spark.read.format("delta").load(baseurl + "/data/leaddiscovery/publish/patientacctxlead/").filter("breadcrumb like '%CH%'")
chc_leads = chc_leads.selectExpr("breadcrumb as lr_creatingmodule","patientacctifk","lsb_coverageid","lsb_edipartnerfk").filter(filterExprYEAR).dropDuplicates()
# chc_leads = chc_leads.selectExpr("breadcrumb as lr_creatingmodule","patientacctifk","lsb_coverageid","lsb_edipartnerfk").dropDuplicates()
chc_leads.createOrReplaceTempView("chc_leads")
chc_leads = spark.sql("""SELECT lr_creatingmodule,COUNT(*) as leads_count FROM chc_leads GROUP BY lr_creatingmodule""")
chc_leads.write.mode("overwrite").parquet(write_baseurl + "/dashboard_run/chc/chc_leads/")
chc_leads.unpersist()

chc_leads = spark.read.parquet(write_baseurl + "/dashboard_run/chc/chc_leads/")
chc_leads.createOrReplaceTempView("chc_leads")

# COMMAND ----------

chc_ingest_stats = spark.sql("""
    SELECT chc_tracker.*,
           chc_transaction.trans_row_count,
           chc_publish.eid_carrier,
           chc_publish.bpe,
           chc_publish.stateCount,
           chc_publish.state
    FROM chc_tracker
    LEFT JOIN chc_transaction 
        ON chc_tracker.lr_creatingmodule = chc_transaction.lr_creatingmodule
    LEFT JOIN chc_publish  
        ON chc_tracker.lr_creatingmodule = chc_publish.lr_creatingmodule
""")
chc_ingest_stats.createOrReplaceTempView("chc_ingest_stats")

chc_ingest_stats=spark.sql("""SELECT chc_ingest_stats.*,
       chc_gmrnid.distinct_gmrnid_count,
       chc_permid.distinct_permid_count
FROM chc_ingest_stats
  LEFT JOIN chc_gmrnid ON chc_ingest_stats.lr_creatingmodule = chc_gmrnid.lr_creatingmodule
  LEFT JOIN chc_permid ON  chc_ingest_stats.lr_creatingmodule = chc_permid.lr_creatingmodule
  """)
chc_ingest_stats.createOrReplaceTempView("chc_ingest_stats")

from pyspark.sql.functions import to_timestamp, col
chc_xref_tracker = readFromCosmos(cosmosEndpoint,cosmosMasterKey,cosmosDatabaseName,"runstatus").filter("notificationtype=='chc_xref'")
chc_xref_tracker=chc_xref_tracker.selectExpr("bc as lr_creatingmodule","processed as xref_status","processedon","createdon")
chc_xref_tracker=chc_xref_tracker.withColumn('processedon',to_timestamp(col('processedon')))
chc_xref_tracker=chc_xref_tracker.withColumn('createdon',to_timestamp(col('createdon')))
chc_xref_tracker=chc_xref_tracker.withColumn('xref_duration',col("processedon").cast("long") - col('createdon').cast("long")).dropDuplicates()
chc_xref_tracker=chc_xref_tracker.selectExpr("lr_creatingmodule","xref_status","xref_duration")
chc_xref_tracker.createOrReplaceTempView("chc_xref_tracker")

chc_ingest_stats=spark.sql("""
SELECT chc_ingest_stats.*,
       chc_leads.leads_count
FROM chc_ingest_stats
  LEFT JOIN chc_leads ON CONCAT (chc_ingest_stats.lr_creatingmodule,'-CH') = chc_leads.lr_creatingmodule
  """)
 
chc_ingest_stats.createOrReplaceTempView("chc_ingest_stats")

chc_ingest_stats=spark.sql("""
SELECT c.lr_creatingmodule,
       c.bpe,
       CAST(c.eid_carrier AS STRING) AS eid_carrier,
       c.stateCount,
       c.state,
       c.bcsupload,
       c.bcsdownload,
       c.trans_row_count,
       x.xref_status,
       c.distinct_permid_count,
       c.distinct_gmrnid_count,
       c.leads_count
FROM chc_ingest_stats c
  LEFT JOIN chc_xref_tracker x ON c.lr_creatingmodule = x.lr_creatingmodule
ORDER BY lr_creatingmodule DESC
""" )
chc_ingest_stats.createOrReplaceTempView("chc_ingest_stats")

chc_lsb_tracker = readFromCosmos(cosmosEndpoint,cosmosMasterKey,cosmosDatabaseName,"runstatus").filter("notificationtype=='chc_xref_lsb'")
chc_lsb_tracker=chc_lsb_tracker.selectExpr("bc as lr_creatingmodule","processed as lsb_status","processedon","createdon")
chc_lsb_tracker=chc_lsb_tracker.withColumn('processedon',to_timestamp(col('processedon')))
chc_lsb_tracker=chc_lsb_tracker.withColumn('createdon',to_timestamp(col('createdon')))
chc_lsb_tracker=chc_lsb_tracker.withColumn('lsb_duration',col("processedon").cast("long") - col('createdon').cast("long")).dropDuplicates()
chc_lsb_tracker=chc_lsb_tracker.selectExpr("lr_creatingmodule","lsb_status","lsb_duration")
chc_lsb_tracker.createOrReplaceTempView("chc_lsb_tracker")

chc_ingest_stats.createOrReplaceTempView("chc_ingest_stats")

chc_ingest_stats=spark.sql("""SELECT c.*, x.lsb_status
FROM chc_ingest_stats c
  LEFT JOIN chc_lsb_tracker x ON c.lr_creatingmodule = x.lr_creatingmodule
ORDER BY lr_creatingmodule DESC """ )

chc_ingest_stats.createOrReplaceTempView("chc_ingest_stats")

chc_propagation_tracker = readFromCosmos(cosmosEndpoint,cosmosMasterKey,cosmosDatabaseName,"runstatus").filter("notificationtype=='chc_xref_lsb_propagation'")
chc_propagation_tracker=chc_propagation_tracker.selectExpr("bc as lr_creatingmodule","processed as lead_propagation_status","processedon","createdon")
chc_propagation_tracker=chc_propagation_tracker.withColumn('processedon',to_timestamp(col('processedon')))
chc_propagation_tracker=chc_propagation_tracker.withColumn('createdon',to_timestamp(col('createdon')))
chc_propagation_tracker=chc_propagation_tracker.withColumn('lead_propagation_duration',col("processedon").cast("long") - col('createdon').cast("long")).dropDuplicates()
chc_propagation_tracker=chc_propagation_tracker.selectExpr("lr_creatingmodule","lead_propagation_status","lead_propagation_duration")
chc_propagation_tracker.createOrReplaceTempView("chc_propagation_tracker")
chc_ingest_stats.createOrReplaceTempView("chc_ingest_stats")
import pyspark.sql.functions as F
from pyspark.sql.functions import col, to_timestamp, trim

chc_ingest_stats=spark.sql("""SELECT c.*, x.lead_propagation_status
FROM chc_ingest_stats c
  LEFT JOIN chc_propagation_tracker x ON c.lr_creatingmodule = x.lr_creatingmodule
ORDER BY lr_creatingmodule DESC """ )



chc_ingest_stats.createOrReplaceTempView("chc_ingest_stats")

import pyspark.sql.functions as F
chc_ingest_stats = (
    chc_ingest_stats.withColumn("trans_row_count", F.format_number("trans_row_count", 0))
                    .withColumn("distinct_permid_count", F.format_number("distinct_permid_count", 0))
                    .withColumn("distinct_gmrnid_count", F.format_number("distinct_gmrnid_count", 0))
                    .withColumn("leads_count", F.format_number("leads_count", 0))
)

for column in chc_ingest_stats.columns:
    chc_ingest_stats = chc_ingest_stats.withColumn(column, trim(col(column)))

chc_ingest_stats.createOrReplaceTempView("chc_ingest_stats")

# COMMAND ----------

def file_exists(path):
  try:
    dbutils.fs.ls(path)
    return 1
  except Exception as e:
    if 'java.io.FileNotFoundException' in str(e):
      return 0
    else:
      raise
from pyspark.sql.types import StructField, StringType, StructType
field = [
    StructField("bc", StringType(), True),
    StructField("step_01", StringType(), True),
    StructField("step_02", StringType(), True),
    StructField("step_03", StringType(), True),
    StructField("step_04", StringType(), True),
    StructField("step_05", StringType(), True),
    StructField("step_06", StringType(), True),
    StructField("step_07", StringType(), True),
]
schema = StructType(field)
all_step_stats = spark.createDataFrame(sc.emptyRDD(), schema)
stats = spark.read.option("mergeSchema", "true").parquet(baseurl +"/data/leaddiscovery/transform/scratch/leadpropagation/*/all_step_stats/")
stats = all_step_stats.union(stats)
# if file_exists(baseurl +"/data/leaddiscovery/transform/scratch/leadpropagation/all_step_stats/"):
#   stats = spark.read.parquet(baseurl +"/data/leaddiscovery/transform/scratch/leadpropagation/*/all_step_stats/")
#   stats = all_step_stats.union(stats)
# else:
#   stats=all_step_stats

stats.createOrReplaceTempView("stats")
# stats.display()

# COMMAND ----------

chc_ingest_stats=spark.sql("""
SELECT chc_ingest_stats.lr_creatingmodule,
       chc_ingest_stats.eid_carrier,
       chc_ingest_stats.bpe,
       chc_ingest_stats.stateCount,
       chc_ingest_stats.state,
       chc_ingest_stats.trans_row_count AS distn_valid_trans,
       CASE
         WHEN chc_ingest_stats.distinct_permid_count IS NULL THEN 'pending'
         ELSE chc_ingest_stats.distinct_permid_count
       END AS distn_permid,
       CASE
         WHEN chc_ingest_stats.distinct_gmrnid_count IS NULL THEN 'pending'
         ELSE chc_ingest_stats.distinct_gmrnid_count
       END AS distn_gmrnid,
       CASE
         WHEN (chc_ingest_stats.leads_count IS NULL AND chc_ingest_stats.lead_propagation_status IS NULL) THEN 'pending'
         WHEN (chc_ingest_stats.leads_count IS NULL AND chc_ingest_stats.lead_propagation_status IS NOT NULL) THEN '0'
         ELSE chc_ingest_stats.leads_count
       END AS leads_count,
       stats.*,
       CONCAT("upload : ",chc_ingest_stats.bcsupload," download : ",chc_ingest_stats.bcsdownload) AS bcs_status,
       CASE
         WHEN chc_ingest_stats.xref_status IS NULL THEN 'pending'
         ELSE chc_ingest_stats.xref_status
       END AS xref_status,
       CASE
         WHEN chc_ingest_stats.lsb_status IS NULL THEN 'pending'
         ELSE chc_ingest_stats.lsb_status
       END AS lsb_status,
       CASE
         WHEN chc_ingest_stats.lead_propagation_status IS NULL THEN 'pending'
         ELSE chc_ingest_stats.lead_propagation_status
       END AS leadprop_status
FROM chc_ingest_stats
  LEFT JOIN stats ON chc_ingest_stats.lr_creatingmodule = stats.bc
ORDER BY chc_ingest_stats.lr_creatingmodule DESC
""")

from pyspark.sql import functions as F

chc_ingest_stats = (
    chc_ingest_stats.withColumn("step_01", F.format_number(F.col("step_01").cast("double"), 0))
    .withColumn("step_02", F.format_number(F.col("step_02").cast("double"), 0))
    .withColumn("step_03", F.format_number(F.col("step_03").cast("double"), 0))
    .withColumn("step_04", F.format_number(F.col("step_04").cast("double"), 0))
    .withColumn("step_05", F.format_number(F.col("step_05").cast("double"), 0))
    .withColumn("step_06", F.format_number(F.col("step_06").cast("double"), 0))
    .withColumn("step_07", F.format_number(F.col("step_07").cast("double"), 0))
)
chc_ingest_stats.createOrReplaceTempView("chc_ingest_stats")

# COMMAND ----------

results=spark.sql("""
SELECT lr_creatingmodule,
       CONCAT(bpe,"_",eid_carrier) as eid_carrier,
       bcs_status,
       xref_status,
       lsb_status,
       leadprop_status,
       distn_valid_trans,
       distn_permid,
       distn_gmrnid,
       leads_count,
       stateCount,
       state,
       concat(
       " all_leads : "             ,step_01,
       " all_leads_filtered : "    ,step_02,
       " all_leads_postwalling : " ,step_03,
       " all_leads_postedisrcfk : ",step_04,
       " all_leads_postohichk : "  ,step_05,
       " all_leads_precleanse : "  ,step_06,
       " all_leads_postcleanse : " ,step_07
       ) AS steps
FROM chc_ingest_stats WHERE lr_creatingmodule LIKE '2025%'
""").dropDuplicates()

# COMMAND ----------

results.write.format('parquet').mode('overwrite').save(write_baseurl + "/dashboard_run/chc_tracker_temp_parquet/")
results.unpersist()

# COMMAND ----------

results=spark.read.parquet(write_baseurl + "/dashboard_run/chc_tracker_temp_parquet/")
results.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + "/dashboard_run/chc_tracker_temp/", header = 'true')

# COMMAND ----------

chc_temp_path = write_baseurl + "/dashboard_run/chc_tracker_temp/"
chc_output_path = write_baseurl + "/dashboard_run/chc_tracker/"
fileNames = dbutils.fs.ls(chc_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(chc_temp_path + name, chc_output_path + '/chc_tracker.csv')

# COMMAND ----------


