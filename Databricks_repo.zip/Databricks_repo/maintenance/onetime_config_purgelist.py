# Databricks notebook source
# ================================================================================================================================ #
# IMPLEMENTATION                                                                                                                   #
#   OWNERSHIP     : FinThrive ICD RougeOnes                                                                                        #
#   AUTHOR        : Max Chatterjee [max.chatterjee@finthrive.com]                                                                  #
#   SCRIPTNAME    : onetime_config_purgelist                                                                                       #
# ================================================================================================================================ #
# HISTORY                                                                                                                          #
#     YYYY-MM-DD: AUTHOR         : VERSION : REQID       : DESCRIPTION                                                             #
#     2025-07-14: Max Chatterjee : 1.0     : IDPRO-13600 : One time directory master list                                          #
# JIRA                                                                                                                             #
# https://finthrive.atlassian.net/browse/IDPRO-13600                                                                               #
# ================================================================================================================================ #

# COMMAND ----------

import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
from pyspark import SparkContext
from pyspark.conf import SparkConf
import subprocess
from pyspark.sql.functions import input_file_name
from pyspark.sql.functions import row_number
import datetime
import pytz
from pyspark.sql.functions import size
from pyspark.sql.functions import udf, col, collect_set, array_distinct, sort_array
from pyspark.sql.types import IntegerType
from pyspark.sql.types import StructType, StructField, StringType, IntegerType

# COMMAND ----------

# MAGIC %md
# MAGIC ### **CAUTION
# MAGIC

# COMMAND ----------

# -----------STAGE PARAM-------------#
container = "prod-icd-stg-adls"
storageaccount = "prodicdstgdls"
user = "maxc"
container = str(container)
storageaccount = str(storageaccount)
user = str(user)

# -------------PROD PARAM-------------#
# container = "prod-icd-adls"
# storageaccount = "prodicddls"
# user = "na"
# container = str(container)
# storageaccount = str(storageaccount)
# user = str(user)

# COMMAND ----------

spark.conf.set("fs.azure.account.key." + storageaccount + ".dfs.core.windows.net",dbutils.secrets.get(scope="icd-insleads-dbwscope", key="icd-adls-insleads-kvsecret"),)

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

path_cleanup_config = baseurl+"/data/maintenance/cleanup_config/"
path_cleanup_config_filename = baseurl+"/data/maintenance/cleanup_config/cleanup_config.csv"

print(baseurl)
print(path_cleanup_config)
print(path_cleanup_config_filename)

# COMMAND ----------

data_str = """
appName|path|bcPersistCount
cdd|data/cdd/transform/es_swift/bdf/|30
cdd|data/cdd/transform/es_swift/bdf_validated/|30
cdd|data/cdd/transform/es_swift/package_bdf/|30
cdd|data/cdd/transform/es/trackpatientacctbcs/patientaccts/|30
cdd|data/cdd/transform/output/ie/rejected/|30
cdd|data/cdd/transform/output/ie/wBadChars/|30
cdd|data/cdd/transform/output/ie/filtered/|30
cdd|data/cdd/transform/output/ie/bdf_pipe/|30
cdd|data/cdd/transform/output/ie/bdf_parquet/|30
cdd|data/cdd/transform/output/ie/bdf_deduped/|30
cdd|data/cdd/transform/output/ie/bdf/|30
cdd|data/cdd/transform/output/ie/package_bdf/|30
cdd|data/cdd/transform/output/es_cm2/ieAllOnlyDemoSubset/|30
cdd|data/cdd/transform/output/es_cm2/matched_1/|30
cdd|data/cdd/transform/output/es_cm2/matched_2/|30
cdd|data/cdd/transform/output/es_cm2/matched_3/|30
cdd|data/cdd/transform/output/es_cm2/matched_4/|30
cdd|data/cdd/transform/output/es_cm2/matched_5/|30
cdd|data/cdd/transform/output/es_cm2/matched_6/|30
cdd|data/cdd/transform/output/ie_cm2/ieAllOnlyDemoSubset/|30
cdd|data/cdd/transform/output/ie_cm2/matched_1/|30
cdd|data/cdd/transform/output/ie_cm2/matched_2/|30
cdd|data/cdd/transform/output/ie_cm2/matched_3/|30
cdd|data/cdd/transform/output/ie_cm2/matched_4/|30
cdd|data/cdd/transform/output/ie_cm2/matched_5/|30
cdd|data/cdd/transform/output/ie_cm2/matched_6/|30
cdd|data/cdd/transform/tusourcedfamilymemberlink/|30
cdd|data/cdd/staging/scratch/ie_cm2_ieallparsed/|30
cdd|data/cdd/staging/scratch/ie_cm2_esScrubbedPath/|30
cdd|data/cdd/staging/scratch/ie_cm2_esm2candidateswithdemo/|30
cdd|data/cdd/staging/scratch/es_cm2_ieallparsed/|30
cdd|data/cdd/staging/scratch/es_cm2_esScrubbedPath/|30
cdd|data/cdd/staging/scratch/es_cm2_esm2candidateswithdemo/|30
cdd|data/cdd/staging/scratch/es_swift_postbdf/|30
cdd|data/cdd/staging/input/es_swift_bdf/|30
cdd|data/cdd/staging/input/ie_bdf/|30
cdd|data/cdd/staging/input/chc_bdf/|30
leaddiscovery|data/leaddiscovery/transform/scratch/globalmrn_assign/minmaxbyhospital/|30
leaddiscovery|data/leaddiscovery/transform/scratch/globalmrn_assign/minmaxbyedipartnerfk/|30
leaddiscovery|data/leaddiscovery/transform/scratch/globalmrn_assign/leadstatus/|30
leaddiscovery|data/leaddiscovery/transform/scratch/globalmrn_assign/candidatepa/|30
leaddiscovery|data/leaddiscovery/transform/scratch/globalmrn_assign/candidatepaxlsb/|30
leaddiscovery|data/leaddiscovery/transform/scratch/globalmrn_assign/candidatepaleads/|30
leaddiscovery|data/leaddiscovery/transform/scratch/globalmrn_assign/candidatepaleadsmerged/|30
leaddiscovery|data/leaddiscovery/transform/scratch/globalmrn_assign/candidatepaleadspost/|30
leaddiscovery|data/leaddiscovery/transform/scratch/leadpropagation/minmaxbyhospital/|30
leaddiscovery|data/leaddiscovery/transform/scratch/leadpropagation/minmaxbyedipartnerfk/|30
leaddiscovery|data/leaddiscovery/transform/scratch/leadpropagation/candidatepaleadspost/|30
leaddiscovery|data/leaddiscovery/transform/scratch/leadpropagation/|30
leaddiscovery|data/leaddiscovery/transform/scratch/medicaidleads/minmaxbyhospital/|30
leaddiscovery|data/leaddiscovery/transform/scratch/medicaidleads/minmaxbyedipartnerfk/|30
leaddiscovery|data/leaddiscovery/transform/scratch/medicaidleads/leadstatus/|30
leaddiscovery|data/leaddiscovery/transform/scratch/medicaidleads/candidatepa/|30
leaddiscovery|data/leaddiscovery/transform/scratch/medicaidleads/candidatepaxlsb/|30
leaddiscovery|data/leaddiscovery/transform/scratch/medicaidleads/candidatepaleads/|30
leaddiscovery|data/leaddiscovery/transform/scratch/medicaidleads/candidatepaleadsmerged/|30
leaddiscovery|data/leaddiscovery/transform/scratch/medicaidleads/candidatepaleadspost/|30
leaddiscovery|data/leaddiscovery/transform/scratch/medicareleads/minmaxbyhospital/|30
leaddiscovery|data/leaddiscovery/transform/scratch/medicareleads/minmaxbyedipartnerfk/|30
leaddiscovery|data/leaddiscovery/transform/scratch/medicareleads/candidatepa/|30
leaddiscovery|data/leaddiscovery/transform/scratch/medicareleads/candidatepaxpermid/|30
leaddiscovery|data/leaddiscovery/transform/scratch/medicareleads/candidatepaxglobalmrnifk/|30
leaddiscovery|data/leaddiscovery/transform/scratch/medicareleads/candidatepaxssn/|30
leaddiscovery|data/leaddiscovery/transform/scratch/medicareleads/candidatepaxmedicalrecnum/|30
leaddiscovery|data/leaddiscovery/transform/scratch/medicareleads/candidatepaxclusteredacctfk/|30
leaddiscovery|data/leaddiscovery/transform/scratch/medicareleads/candidatepaleads/|30
leaddiscovery|data/leaddiscovery/transform/scratch/medicareleads/leadstatus/|30
leaddiscovery|data/leaddiscovery/transform/scratch/medicareleads/candidatepaleadspost/|30
leaddiscovery|data/leaddiscovery/transform/scratch/medicareleads/output/|30
leaddiscovery|data/leaddiscovery/transform/scratch/leadverify/minmaxbyhospital/|30
leaddiscovery|data/leaddiscovery/transform/scratch/leadverify/minmaxbyedipartnerfk/|30
leaddiscovery|data/leaddiscovery/transform/scratch/leadverify/processleads/|30
leaddiscovery|data/leaddiscovery/transform/scratch/leadverify/|30
leaddiscovery|data/leaddiscovery/transform/scratch/subscriber_dob/|30
leaddiscovery|data/leaddiscovery/transform/scratch/birthmonth_process/leadstatus/|30
leaddiscovery|data/leaddiscovery/transform/scratch/birthmonth_process/candidatepaleadsmerged/|30
leaddiscovery|data/leaddiscovery/transform/scratch/birthmonth_process/candidatepaleadspost/|30
leaddiscovery|data/leaddiscovery/transform/scratch/birthmonth_process/candidatepaleads/|30
leaddiscovery|data/leaddiscovery/transform/scratch/birthmonth_process/candidatepaxlsb/|30
leaddiscovery|data/leaddiscovery/transform/scratch/birthmonth_process/candidatepa/|30
leaddiscovery|data/leaddiscovery/transform/scratch/birthmonth_process/minmaxbyhospital/|30
leaddiscovery|data/leaddiscovery/transform/scratch/birthmonth_process/minmaxbyedipartnerfk/|30
leadrepo|data/leadrepo/staging/input/raw/patientaccts/|30
leadrepo|data/leadrepo/staging/input/raw/foundcoverage/|30
leadrepo|data/leadrepo/staging/input/raw/helperfoundcoverages/|30
leadrepo|data/leadrepo/staging/input/raw/medicarecoverage/|30
leadrepo|data/leadrepo/staging/famc/candidate_permid_transactions/es_xref_famc/|30
leadrepo|data/leadrepo/staging/famc/candidate_permid_transactions/fc_xref_famc/|30
leadrepo|data/leadrepo/staging/famc/candidate_permid_transactions/ie_xref_famc/|30
leadrepo|data/leadrepo/staging/famc/famc_lr_xref_permid_transaction/es_xref_famc/|30
leadrepo|data/leadrepo/staging/famc/famc_lr_xref_permid_transaction/fc_xref_famc/|30
leadrepo|data/leadrepo/staging/famc/famc_lr_xref_permid_transaction/ie_xref_famc/|30
leadrepo|data/leadrepo/transform/scratch/hfc/|30
leadrepo|data/leadrepo/transform/scratch/mh/|30
leadrepo|data/leadrepo/publish/toserve/gmrn/|30
leadrepo|data/leadrepo/publish/toserve/ich_import/es_postbdf/|30
leadrepo|data/leadrepo/publish/toserve/ich_import/ie_postbdf/|30
leadrepo|data/leadrepo/publish/toserve/fc_import/|30
leadrepo|data/leadrepo/publish/toserve/hfc_import/|30
leadrepo|data/leadrepo/publish/toserve/mh_import/|30
leadrepo|data/leadrepo/publish/toserve/chc_import/|30
leadservicebase|data/leadservicebase/staging/famc/es_lsb_famc/|30
leadservicebase|data/leadservicebase/staging/famc/fc_lsb_famc/|30
leadservicebase|data/leadservicebase/staging/famc/ie_lsb_famc/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/joinedf/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/joinedf_stage2_temp/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/bad_record/fc/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/bad_record/ich/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/bad_record/hfc/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/bad_record/mh/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/bad_record/chc/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/new_gmrnid_fc_lsb_join/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/new_gmrnid_fc_map_op/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/new_permid_fc_lsb_join/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/new_permid_fc_map_op/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/new_ssn_fc_lsb_join/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/new_ssn_fc_map_op/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/new_medicalrecnum_fc_lsb_join/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/new_medicalrecnum_fc_map_op/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/new_clusteredacctfk_fc_lsb_join/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/new_clusteredacctfk_fc_map_op/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/new_gmrnid_ich_lsb_join/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/new_gmrnid_ich_map_op/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/new_permid_ich_lsb_join/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/new_permid_ich_map_op/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/new_gmrnid_hfc_lsb_join/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/new_gmrnid_hfc_map_op/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/famc/bad_record/fc/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/famc/bad_record/ich/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/famc/new_permid_fc_lsb_join/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/famc/new_permid_fc_map_op/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/famc/new_permid_ich_lsb_join/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/famc/new_permid_ich_map_op/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/new_gmrnid_mh_lsb_join/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/new_gmrnid_mh_map_op/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/new_permid_mh_lsb_join/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/new_permid_mh_map_op/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/new_ssn_mh_lsb_join/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/new_ssn_mh_map_op/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/new_ssn_mh_map_op/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/new_medicalrecnum_mh_lsb_join/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/new_medicalrecnum_mh_map_op/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/new_clusteredacctfk_mh_lsb_join/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/new_clusteredacctfk_mh_map_op/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/new_gmrnid_chc_lsb_join/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/new_gmrnid_chc_map_op/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/new_permid_chc_lsb_join/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/new_permid_chc_map_op/|30
gmrn|data/gmrn/staging/scratch/globalmrn/|30
gmrn|data/gmrn/publish/mergedecisions/|30
gmrn|data/gmrn/publish/graphx/|30
gmrn|data/gmrn/staging/sot/tmp_op/gdemo_update/|30
gmrn|data/gmrn/staging/sot/tmp_op/globalmrn/|30
gmrn|data/gmrn/staging/sot/tmp_op/globalmrnxpacct/|30
gmrn|data/gmrn/staging/sot/tmp_op/globalxdemo/|30
gmrn|data/gmrn/staging/sot/intermediate_tmp/globalmrnxhospinsurancecodes/|30
gmrn|data/gmrn/staging/sot/intermediate_tmp/globalmrn/|30
gmrn|data/gmrn/staging/sot/intermediate_tmp/globalmrnxpacct/|30
gmrn|data/gmrn/staging/sot/intermediate_tmp/globalmrndemographics/|30
gmrn|data/gmrn/staging/sot/prepublish_op/globalmrndemographics/|30
gmrn|data/gmrn/staging/sot/prepublish_op/globalmrn/|30
gmrn|data/gmrn/staging/sot/prepublish_op/globalmrnxpacct/|30
gmrn|data/gmrn/staging/matches/merge/|30
gmrn|data/gmrn/publish/globalmrn/archive/|30
gmrn|data/gmrn/publish/globalmrnxpacct/archive/|30
gmrn|data/gmrn/publish/globalmrndemographics/archive/|30
dataingestion|data/dataingestion/staging/input/clusteredaccts/|30
dataingestion|data/dataingestion/staging/input/demographics/|30
dataingestion|data/dataingestion/staging/input/ediqueries/|30
dataingestion|data/dataingestion/staging/input/ediqueryhitsandmisses/|30
dataingestion|data/dataingestion/staging/input/edisubscriberdobsearch/|30
dataingestion|data/dataingestion/staging/input/foundcoverage/|30
dataingestion|data/dataingestion/staging/input/foundcoverageentities/|30
dataingestion|data/dataingestion/staging/input/foundcoveragesegments/|30
dataingestion|data/dataingestion/staging/input/helperfoundcoverages/|30
dataingestion|data/dataingestion/staging/input/hintfoundcoverage/|30
dataingestion|data/dataingestion/staging/input/hospfinclasscodes/|30
dataingestion|data/dataingestion/staging/input/hospinsurancecodes/|30
dataingestion|data/dataingestion/staging/input/hospitalimportpayment/|30
dataingestion|data/dataingestion/staging/input/hosppaymentcodes/|30
dataingestion|data/dataingestion/staging/input/medicarecoverage/|30
dataingestion|data/dataingestion/staging/input/patientacctcommercialhelpers/|30
dataingestion|data/dataingestion/staging/input/patientaccteligibilitysubmittals/|30
dataingestion|data/dataingestion/staging/input/patientaccts/|30
dataingestion|data/dataingestion/staging/input/patientacctscodes/|30
dataingestion|data/dataingestion/staging/input/patientacctsguarantors/|30
dataingestion|data/dataingestion/staging/input/patientacctspayercob/|30
dataingestion|data/dataingestion/staging/input/patientacctstatestatus/|30
dataingestion|data/dataingestion/staging/input/reportwarehousemedicaideligiblepaes/|30
dataingestion|data/dataingestion/staging/input/tprcoverage/|30
dataingestion|data/dataingestion/staging/input/tusourcedfamilymemberlink/|30
dataingestion|data/dataingestion/staging/input/vendorknownohicoverages/|30
dataingestion|data/dataingestion/staging/input/vsnapglobalmrnfamilyhelperaccounts/|30
dataingestion|data/dataingestion/staging/input/vsnappatientacctsflags/|30
leaddiscovery|data/leaddiscovery/transform/output/leadpropagation/|30
leaddiscovery|data/leaddiscovery/transform/output/globalmrn_assign/|30
leaddiscovery|data/leaddiscovery/transform/scratch/knowncommercial/boundary_condition_02_03/|30
leaddiscovery|data/leaddiscovery/transform/scratch/knowncommercial/candidatepaleadsmerged/|30
leaddiscovery|data/leaddiscovery/transform/scratch/knowncommercial/leadstatus/|30
leaddiscovery|data/leaddiscovery/transform/scratch/knowncommercial/kc_unfiltered/|30
leaddiscovery|data/leaddiscovery/transform/scratch/knowncommercial/candidatepaleads/|30
leaddiscovery|data/leaddiscovery/transform/scratch/knowncommercial/patientacctscodes_cross_others/|30
leaddiscovery|data/leaddiscovery/transform/output/knowncommercial/|30
leaddiscovery|data/leaddiscovery/transform/scratch/knowncommercial/boundary_condition_01/|30
leaddiscovery|data/leaddiscovery/transform/scratch/knowncommercial/candidatepaleadspost/|30
leaddiscovery|data/leaddiscovery/transform/output/birthmonth_process/|30
leaddiscovery|data/leaddiscovery/transform/output/medicaidleads/|30
leaddiscovery|data/leaddiscovery/transform/output/subscriber_dob/|30
leadrepo|data/leadrepo/transform/scratch/ie_output/lr_ich_xml_parsed/transaction/|30
leadrepo|data/leadrepo/staging/famc/permid_relations/|30
leadservicebase|data/leadservicebase/transform/scratch/ich/|30
leadservicebase|data/leadservicebase/transform/scratch/fc/|30
leadservicebase|data/leadservicebase/transform/scratch/chc/|30
leadservicebase|data/leadservicebase/transform/scratch/hfc/|30
leadservicebase|data/leadservicebase/transform/scratch/mh/|30
leadservicebase|data/leadservicebase/transform/scratch/leadservicebase/updateLsbLeadsRef/gmrnid/lsb_leads/|30
leadservicebase|data/leadservicebase/transform/scratch/gmrn_update/gmrn_merge/|30
leadservicebase|data/leadservicebase/transform/scratch/gmrn_update/ready_to_load_lsb/|30
leadservicebase|data/leadservicebase/transform/scratch/gmrn_update/ready_to_delete_lsb/|30
chc|data/chc/transform/frombcs_fixed/|30
chc|data/chc/transform/frombcs_parquet/|30
chc|data/chc/transform/temp/|30
chc|data/chc/transform/tobcs_csv/|30
chc|data/chc/transform/tobcs_fixed/|30
chc|data/chc/transform/tobcs_zipped/|30
chc|data/chc/staging/matches/merge|30
chc|data/chc/staging/phonetics|30
chc|data/chc/staging/scratch|30
chc|data/chc/staging/input|30
dataingestion|data/dataingestion/staging/intermediate/clusteredaccts/|30
dataingestion|data/dataingestion/staging/intermediate/edisubscriberdobsearch/|30
dataingestion|data/dataingestion/staging/intermediate/foundcoverage/|30
dataingestion|data/dataingestion/staging/intermediate/foundcoveragesegments/|30
dataingestion|data/dataingestion/staging/intermediate/helperfoundcoverages/|30
dataingestion|data/dataingestion/staging/intermediate/hintfoundcoverage/|30
dataingestion|data/dataingestion/staging/intermediate/hospinsurancecodes/|30
dataingestion|data/dataingestion/staging/intermediate/medicarecoverage/|30
dataingestion|data/dataingestion/staging/intermediate/patientaccteligibilitysubmittals/|30
dataingestion|data/dataingestion/staging/intermediate/patientaccts/|30
dataingestion|data/dataingestion/staging/intermediate/patientacctscodes/|30
dataingestion|data/dataingestion/staging/intermediate/patientacctsguarantors/|30
dataingestion|data/dataingestion/staging/intermediate/patientacctspayercob/|30
dataingestion|data/dataingestion/staging/intermediate/patientacctstatestatus/|30
dataingestion|data/dataingestion/staging/intermediate/reportwarehousemedicaideligiblepaes/|30
dataingestion|data/dataingestion/staging/intermediate/tprcoverage/|30
dataingestion|data/dataingestion/staging/intermediate/vsnapglobalmrnfamilyhelperaccounts/|30
dataingestion|data/dataingestion/staging/intermediate/vsnappatientacctsflags/|30
gmrn|data/gmrn/staging/phonetics|30
coveragehelpers|/data/coveragehelpers/transform/medicaidhelper/|30
hintsdiscovery|/data/hintsdiscovery/transform/scratch/commercial_hints/|30
leaddiscovery|data/leaddiscovery/transform/scratch/globalmrn_assign/minmaxbyhospital/aid/|30
leaddiscovery|data/leaddiscovery/transform/scratch/globalmrn_assign/minmaxbyedipartnerfk/aid/|30
leaddiscovery|data/leaddiscovery/transform/scratch/globalmrn_assign/leadstatus/aid/|30
leaddiscovery|data/leaddiscovery/transform/scratch/globalmrn_assign/candidatepa/aid/|30
leaddiscovery|data/leaddiscovery/transform/scratch/globalmrn_assign/candidatepaxlsb/aid/|30
leaddiscovery|data/leaddiscovery/transform/scratch/globalmrn_assign/candidatepaleads/aid/|30
leaddiscovery|data/leaddiscovery/transform/scratch/globalmrn_assign/candidatepaleadsmerged/aid/|30
leaddiscovery|data/leaddiscovery/transform/scratch/globalmrn_assign/candidatepaleadspost/aid/|30
gmrn|data/gmrn/staging/sqoop-data/globalmrn/|30
gmrn|data/gmrn/staging/sqoop-data/globalmrndemo/|30
gmrn|data/gmrn/staging/sqoop-data/globalmrnxpacct/|30
gmrn|data/gmrn/staging/sqoop-stage/globalmrndemographics/|30
gmrn|data/gmrn/staging/sqoop-stage/globalmrndemo/|30
gmrn|data/gmrn/staging/scratch/|30
gmrn|data/gmrn/staging/sot/gmrndemo_update/globalmrndemographics/|30
gmrn|data/gmrn/staging/sot/gmrnassign/new-key/|30
cdd|data/cdd/staging/input/ie/|30
cdd|data/cdd/transform/output/ie/aaa_segment/|30
cdd|data/cdd/transform/output/ie/eb_segment/|30
cdd|data/cdd/transform/output/ie/ie-parse-dtp/|30
"""

# COMMAND ----------

lines = [l for l in data_str.strip().split("\n") if l]
header = lines[0].split("|")
rows = [l.split("|") for l in lines[1:]]

schema = StructType(
    [
        StructField("appName", StringType(), True),
        StructField("path", StringType(), True),
        StructField("bcPersistCount", IntegerType(), True),
    ]
)

data = spark.createDataFrame([(r[0], r[1], int(r[2])) for r in rows], schema=schema)
data.dropDuplicates().repartition(1).write.mode("overwrite").format("csv").option("header", "true").save(path_cleanup_config)

# COMMAND ----------

fileNames = dbutils.fs.ls(path_cleanup_config)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.mv(path_cleanup_config + name, path_cleanup_config + '/cleanup_config.csv')

# COMMAND ----------

try:
    dbutils.fs.ls(path_cleanup_config + "/cleanup_config.csv")
    print(f"{path_cleanup_config}/cleanup_config.csv")
except Exception as e:
    print(f"An error occurred: {e} : file not found or created")

# COMMAND ----------

data_check = spark.read.format("csv").option("header", "true").load(path_cleanup_config+"/cleanup_config.csv")
data_check.display()
