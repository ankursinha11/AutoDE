# Databricks notebook source
# DBTITLE 1,Initializing Variables
environment = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-dbx-workspace-env")
src_storageaccount = f"{environment.replace('_','').strip()}dls"
dest_storageaccount = f"{environment.replace('_','').strip()}archivest"
src_container = f"{environment.replace('_','-').strip()}-adls"
dest_container = "ftlzbackup"
spark.conf.set("fs.azure.account.key."+src_storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))
spark.conf.set("fs.azure.account.key."+dest_storageaccount+".blob.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-archivest-insleads-kvsecret"))

src_base_path = f"abfss://{src_container}@{src_storageaccount}.dfs.core.windows.net"
dest_base_path = f"wasbs://{dest_container}@{dest_storageaccount}.blob.core.windows.net"

src_path = f"{src_base_path}/data/cdd/staging/ie/sqoop"
dest_path = f"{dest_base_path}/icd_new/archived_ich_raw_xmls"
data_retention_in_days = 45

# COMMAND ----------

print(src_storageaccount)
print(dest_storageaccount)
print(src_container)
print(src_base_path)
print(dest_base_path)

# COMMAND ----------

# DBTITLE 1,Archiving Paths which are older than 45 days
import re
from datetime import datetime, timedelta
from pyspark.sql import Row

# List all the BC folders
folders = dbutils.fs.ls(src_path)
# BC format - ddMMMyyyy-hh 
pattern = re.compile(r"^\d{2}(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\d{4}-\d{2}$", re.IGNORECASE)
archived_folders = []

# Archive folders older than 45 days
today = datetime.today().replace(hour=0, minute=0, second=0, microsecond=0)
archive_folder_name = today.strftime('%d%b%Y').upper()
cutoff_date = today - timedelta(days=data_retention_in_days)
print(f"Cutoff date - {cutoff_date}")

for folder in folders:
    match = pattern.fullmatch(folder.name[:-1])
    if match:
        date_str = folder.name[:-4]
        folder_date = datetime.strptime(date_str, "%d%b%Y")
        #  folder.name in ["01APR2024-13/", "01APR2025-23/"] and
        if folder_date <= cutoff_date:
            year = datetime.strptime(date_str, "%d%b%Y").strftime("%Y")
            src_folder_path = folder.path
            dest_sub_path = f"{dest_path}/{year}/{folder.name}"
            # print(f"Source path - {src_folder_path}")
            # print(f"Destination path - {dest_sub_path}")
            df = spark.read.option("recursiveFileLookup", "true").text(src_folder_path)
            df.write.mode("overwrite").option("compression", "gzip").text(dest_sub_path)

            ## Adding logs of the archived folders for validation purpose
            validation = {
                "src_folder_path": src_folder_path,
                "dest_folder_path": dest_sub_path,
                "src_count": df.count(),
                "dest_count": spark.read.text(dest_sub_path).count()
            }
            archived_folders.append(validation)

if len(archived_folders) == 0:
    print("No folders to archive")
else:
    # adding folders archived to a log file
    rows = [Row(**v) for v in archived_folders]
    archived_folders_log_df = spark.createDataFrame(rows)
    archived_folders_log_df.repartition(1).write.mode("overwrite").parquet(f"{dest_path}/archive_logs/{archive_folder_name}")

# COMMAND ----------

# DBTITLE 1,Removing the archived paths from the source
# Removing the paths that have been archived successfully where in the count matches in both source and target
archived_folders_log_df = archived_folders_log_df.where(archived_folders_log_df.src_count == archived_folders_log_df.dest_count)
paths_to_delete = [row.src_folder_path for row in archived_folders_log_df.select("src_folder_path").collect()]
# print(paths_to_delete)
for path in paths_to_delete:
    dbutils.fs.rm(path, True)

# COMMAND ----------

# DBTITLE 1,Archival status
total_paths = len(folders)
total_paths_to_archived = len(archived_folders)
total_paths_deleted = len(paths_to_delete)
archived_folders_list = [f['src_folder_path'] for f in archived_folders]

print(f"Total paths in source - {total_paths}")
print(f"Total paths archived - {total_paths_to_archived}")
print(f"Total paths deleted from Source - {total_paths_deleted}")
if total_paths_to_archived == total_paths_deleted:
    print("All paths have been archived successfully")
else:
    print("Some paths have not been archived successfully")
    print(f"Paths not archived due to count mismatch - {[item for item in archived_folders_list if item not in paths_to_delete]}")
