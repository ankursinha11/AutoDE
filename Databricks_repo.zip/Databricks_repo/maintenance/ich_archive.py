# Databricks notebook source
# MAGIC %md
# MAGIC This notebook archive ich data older than the number of days specified in the parameter. Move the data from prod storage staging folder to prod archivest storage account. 

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from datetime import datetime, timedelta, date

# COMMAND ----------

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("dest_container","")
dbutils.widgets.getArgument("dest_container")
dest_container= getArgument("dest_container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("file_path", "")
dbutils.widgets.getArgument("file_path")
file_path = getArgument("file_path")

dbutils.widgets.text("dest_file_path", "")
dbutils.widgets.getArgument("dest_file_path")
dest_file_path = getArgument("dest_file_path")

dbutils.widgets.text("number_of_days", "")
dbutils.widgets.getArgument("number_of_days")
number_of_days = getArgument("number_of_days")

dbutils.widgets.text("run_mode", "")
dbutils.widgets.getArgument("run_mode")
run_mode = getArgument("run_mode")

dbutils.widgets.text("dest_storageaccount","")
dbutils.widgets.getArgument("dest_storageaccount")
dest_storageaccount= getArgument("dest_storageaccount")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+dest_storageaccount+".blob.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-archivest-insleads-kvsecret"))

# COMMAND ----------

# MAGIC %md
# MAGIC generates base url

# COMMAND ----------

if user == 'na' or user =='': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

dest_full_file_path ='wasbs://'+dest_container+'@'+dest_storageaccount+'.blob.core.windows.net'+dest_file_path

# COMMAND ----------


# reads the current date and substract the number_of_days parameter.
curr_date=datetime.now().date()
numdays=int(number_of_days)
prev_start_date=curr_date-timedelta(numdays)
print(prev_start_date)
path1=baseurl+file_path
print(path1)
filelist=dbutils.fs.ls(path1)
print(dest_full_file_path)
# print(filelist)
months_list = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC']
#looping through all the folders in the filelist
for file in filelist:
    # if ((len(file.name))==13 and file.name != 'query_logs/'):
    # name should be of format is 01MAR2024-**/
    if ((len(file.name))==13):
        name=file.name[:-4]
        checkmonth=file.name
        # mmonth = file.name[2:5]
        # print(mmonth)    
        # print(len(file.name))
        # 2 to 5 characters of name should be a month
        if any(ele in file.name for ele in months_list):    
            list_date = datetime.strptime(name, '%d%b%Y')
            # print(str(res))
            list_date1=list_date.date()
            if(list_date1<prev_start_date):
                if(run_mode=='list'):
                    print(name)
                    print(file.path)
                    print(dest_full_file_path)
                if(run_mode=='copy'):
                    # print(name)
                    # print(file.path)            
                    dest_path=dest_full_file_path+file.name
                    folder_list = ["rttransactionstore","rttransactionstore_ds1","rttransactionstore_ds2"]
                    for folder in folder_list:
                        source_path=file.path+folder
                        dest_path1=dest_path+folder
                        print(source_path)
                        print(dest_path1)
                        # read data and write to the archivest folder
                        df= spark.read.option("recursiveFileLookup", "true").text(source_path)
                        df.write.format("text").option("header", "false").mode("append").save(dest_path1)
                        # dbutils.fs.cp(source_path, dest_path1, True)
                        # dbutils.fs.rm(file.path, True)