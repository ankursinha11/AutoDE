# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *
import pyspark.sql.functions as f

# COMMAND ----------

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("hdfs_output","")
dbutils.widgets.getArgument("hdfs_output")
hdfs_output= getArgument("hdfs_output")

dbutils.widgets.text("hdfs_output_temp","")
dbutils.widgets.getArgument("hdfs_output_temp")
hdfs_output_temp= getArgument("hdfs_output_temp")

dbutils.widgets.text("hospitalList","")
dbutils.widgets.getArgument("hospitalList")
hospitalList= getArgument("hospitalList")

dbutils.widgets.text("write_container","")
dbutils.widgets.getArgument("write_container")
write_container= getArgument("write_container")

dbutils.widgets.text("write_storageaccount","")
dbutils.widgets.getArgument("write_storageaccount")
write_storageaccount= getArgument("write_storageaccount")


# COMMAND ----------

#read storage acct
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

#write storage acct
spark.conf.set("fs.azure.account.key."+write_storageaccount+".blob.core.windows.net","IEfzxj47CMO5j8WXNcugYeiCG5Ip/pypR+apR+/eQUOUxA9wapX8oK6rIdn+K87Dvyezcix8wcSK+AStM0qxww==")

# COMMAND ----------


#read base url
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 


#write base url
if user == 'na': #defualt value
    # wasbs://icdleadsreports@prodicdst.blob.core.windows.net/
    write_baseurl ='wasbs://'+write_container+'@'+write_storageaccount+'.blob.core.windows.net'
else:
    write_baseurl ='wasbs://'+write_container+'@'+write_storageaccount+'.blob.core.windows.net/'+user 

# COMMAND ----------

spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)

# COMMAND ----------

dataingestion_publish_path = baseurl+'/data/dataingestion/publish/'
pa_path=dataingestion_publish_path+'patientaccts/current/20991231/'
pac_path=dataingestion_publish_path+'patientacctscodes/current/20991231/'

("--------------------------------------------------------------------------------")
print("container="+str(container))
print("storageaccount="+str(storageaccount))
print("user="+str(user))
print("hospitalList="+str(hospitalList))
hosp_arr = hospitalList.split(",")
print("hosp_arr="+str(hosp_arr))

print("dataingestion_publish_path="+str(dataingestion_publish_path))
print("hdfs_output="+str(hdfs_output))
print("hdfs_output_temp="+str(hdfs_output_temp))
print("--------------------------------------------------------------------------------")
print("pa_path="+str(pa_path))
print("pac_path="+str(pac_path))


# COMMAND ----------

# DBTITLE 1,Read PA Counts
pa = spark.read.format("delta").load(pa_path)#2,722,912,691
pa.createOrReplaceTempView('pa')


pa1 = pa.filter((pa.hospitalfk.isin(hosp_arr)) & (pa.referraldate.between('2022-01-01', '2099-12-31')))
# print("Counts of PA in given hospitals: " + str(pa1.count()))

pa1.createOrReplaceTempView('pa1')

#Get the counts of the PA generated per month
pa_reveived=spark.sql("""select hospitalfk, substring(referraldate,1,7) as Month, count(*) as pa_received from pa1
            group by hospitalfk, substring(referraldate,1,7)
            order by hospitalfk, substring(referraldate,1,7) desc
             """)

# COMMAND ----------

# DBTITLE 1,Get LSB data and split all 5 IDs
lsb = spark.read.format("delta").load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/leadservicebase/publish/served/leadservicebase/")
lsb_g =lsb.filter(col("_id").startswith('G'))
lsb_p =lsb.filter(col("_id").startswith('P'))
lsb_s =lsb.filter(col("_id").startswith('S'))
lsb_m =lsb.filter(col("_id").startswith('MH'))
lsb_c =lsb.filter(col("_id").startswith('CH'))

# print("Counts of GMRNID Leads in LSB: " + str(lsb_g.count()))
# print("Counts of GMRNID Leads in LSB: " + str(lsb_p.count()))
# print("Counts of GMRNID Leads in LSB: " + str(lsb_s.count()))
# print("Counts of GMRNID Leads in LSB: " + str(lsb_m.count()))
# print("Counts of GMRNID Leads in LSB: " + str(lsb_c.count()))

# COMMAND ----------

# DBTITLE 1,Total leads in LSB on all ids
# Matching accounts on gmrnid
gxp = spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/gmrn/publish/globalmrnxpacct/current/*/")

pag = pa1.join(
    gxp,
    (pa1.patientacctipk == gxp.patientacctifk) & (pa1.hospitalfk == gxp.hospitalfk)
).select(pa1['*'], gxp.globalmrnifk).dropDuplicates()

pag2 = pag.withColumn('id', concat(lit('G_'), pag.globalmrnifk)).drop('globalmrnifk')
pa_gmrn_leads = pag2.join(lsb_g, (pag2.id == lsb_g.identity))
# print("Count of matching leads on gmrnid: " + str(pa_gmrn_leads.count()))

# Matching accounts on permid
pp=spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/cdd/publish/permidpatientacctid/*")
pp=pp.filter("matchind in('IM','M1')").dropDuplicates()


pap = pa1.join(
    pp,
    (pa1.patientacctipk == pp.patientacctifk) & (pa1.hospitalfk == pp.hospitalfk)
).select(pa1['*'], pp.permid).dropDuplicates()

pap2 = pap.withColumn('id', concat(lit('P_'), pap.permid)).drop('permid')
pa_perm_leads = pap2.join(lsb_p, (pap2.id == lsb_p.identity))
# print("Count of matching leads on permid :" + str(pa_perm_leads.count()))

# Matching accounts on ssn
pas2=spark.sql("""select * from pa1
            where ssn is not null
             """) # 758,573

pas3 = pas2.withColumn('id', concat(lit('S_'), pas2.ssn))
pa_ssn_leads = pas3.join(lsb_s, (pas3.id == lsb_s.identity))
# print("Count of matching leads on ssn: " + str(pa_ssn_leads.count()))

# Matching accounts on clusteredacctid
pac2 = pa1.select('clusteredacctfk').dropDuplicates()
pac2=spark.sql("""select * from pa1
            where clusteredacctfk is not null
             """) 
pac3 = pac2.withColumn('id', concat(lit('CH_'), pac2.hospitalfk, lit('_'), pa1.clusteredacctfk))
pa_clstract_leads = pac3.join(lsb_c, (pac3.id == lsb_c.identity))
# print("Count of matching leads on clusteredacctid: " + str(pa_clstract_leads.count()))

# Matching accounts on mrn
pam2 = pa1.select('medicalrecnum').dropDuplicates()
pam2=spark.sql("""select * from pa1
            where medicalrecnum is not null
             """) # 758,573
pam3 = pam2.withColumn('id', concat(lit('MH_'), pam2.hospitalfk, lit('_'), pa1.medicalrecnum))
pa_mrn_leads = pam3.join(lsb_m, (pam3.id == lsb_m.identity))
# print("Count of matching leads on mrn: " + str(pa_mrn_leads.count()))

# COMMAND ----------

paids = pa_gmrn_leads.union(pa_perm_leads).union(pa_ssn_leads).union(pa_clstract_leads).union(pa_mrn_leads)
# paids.count()#7,072,603

paids1=paids.select('hospitalfk','patientacctipk','referraldate').dropDuplicates()
# paids1.count()#613,781

paids1.createOrReplaceTempView('paids1')
allIds_leads=spark.sql("""select hospitalfk, substring(referraldate,1,7) as Month, count(*) as all_leads_in_LSB from paids1
            group by  hospitalfk, substring(referraldate,1,7)
            order by  hospitalfk, substring(referraldate,1,7) desc
             """)
# allIds_leads.show(100,False)

allIds_leads = pa_reveived.join(allIds_leads, (pa_reveived.hospitalfk == allIds_leads.hospitalfk) & (pa_reveived.Month == allIds_leads.Month)) \
                          .select(pa_reveived["*"],allIds_leads["all_leads_in_LSB"]) \
                          .withColumn("leadsInLSB%", (f.col('all_leads_in_LSB')/f.col('pa_received')*100).cast(DecimalType(4,2)))

# COMMAND ----------

# DBTITLE 1,Get the generated leads counts
pxl = spark.read.format("delta").load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/leaddiscovery/publish/patientacctxlead/")
p1 = pxl.filter(pxl.hospitalfk.isin(hosp_arr)).select(pxl.patientacctifk, pxl.hospitalfk, pxl.breadcrumb)

#leads generated

leads_gen = p1.join(
    pa1,
    (p1.patientacctifk == pa1.patientacctipk) & (p1.hospitalfk == pa1.hospitalfk)
).select(p1["*"], pa1.referraldate)


leads_gen.createOrReplaceTempView('leads_gen')

leads_gen=spark.sql("""select hospitalfk, substring(referraldate,1,7) as Month, count(*) leads_gen from leads_gen 
            group by hospitalfk, substring(referraldate,1,7)
            order by hospitalfk, substring(referraldate,1,7) desc
             """)

# leads_gen.show(500,False)

leads_gen = allIds_leads.join(leads_gen, (allIds_leads.hospitalfk == leads_gen.hospitalfk) & (allIds_leads.Month == leads_gen.Month)) \
                          .select(allIds_leads["*"],leads_gen["leads_gen"])

# COMMAND ----------

#leads not generated

leads_not_gen = pa1.join(
    p1,
    (pa1.patientacctipk == p1.patientacctifk) & (pa1.hospitalfk == p1.hospitalfk),
    'leftanti'
)

leads_not_gen.createOrReplaceTempView('leads_not_gen')

leads_not_gen=spark.sql("""select hospitalfk, substring(referraldate,1,7) as Month, count(*) pa_leads_not_gen from leads_not_gen 
            group by hospitalfk, substring(referraldate,1,7)
            order by hospitalfk, substring(referraldate,1,7) desc
             """)

# leads_not_gen.show(500,False)

leads_not_gen = leads_gen.join(leads_not_gen, (leads_gen.hospitalfk == leads_not_gen.hospitalfk) & (leads_gen.Month == leads_not_gen.Month)) \
                          .select(leads_gen["*"],leads_not_gen["pa_leads_not_gen"]) \
                          .withColumn("pa_generated", f.col('pa_received') - f.col('pa_leads_not_gen')) \
                          .withColumn("pa_generated%", (f.col('pa_generated')/f.col('pa_received')*100) .cast(DecimalType(4,2)))

# display(leads_not_gen)

# COMMAND ----------

df=spark.read.format("delta").load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/dataingestion/publish/foundcoverage/current/20991231/")

df=df.filter(col("hitstatus").isin(1))


pa_fc = pa1.join(
    df,
    (pa1.patientacctipk == df.patientacctifk) & (pa1.hospitalfk == df.hospitalfk),
    'leftanti'
)


pa_fc.createOrReplaceTempView('pa_fc')
pa_notin_FC=spark.sql("""select hospitalfk, substring(referraldate,1,7) as Month, count(*) as pa_not_in_FC  from pa_fc 
            group by hospitalfk, substring(referraldate,1,7)
            order by hospitalfk, substring(referraldate,1,7) desc
             """)

# pa_notin_FC.show(500,False)

fc_accounts = leads_not_gen.join(pa_notin_FC, (leads_not_gen.hospitalfk == pa_notin_FC.hospitalfk) & (leads_not_gen.Month == pa_notin_FC.Month)) \
                          .select(leads_not_gen["*"],pa_notin_FC["pa_not_in_FC"]) \
                          .withColumn("pa_in_fc", f.col('pa_received') - f.col('pa_not_in_FC')) \
                          .withColumn("%pa_in_fc", (f.col('pa_in_fc')/f.col('pa_received')*100).cast(DecimalType(4,2)))

# display(fc_accounts)

# COMMAND ----------

# DBTITLE 1,Get CHC Leads counts
pxl_chc = spark.read.format("delta").load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/leaddiscovery/publish/patientacctxlead/").filter(col("breadcrumb").contains("CH"))

# pxl_chc = pxl2.filter(col("breadcrumb").contains("CH"))

#total leads for for chc for those pa 
pa_chc=pa1.join(pxl_chc, (pa1.patientacctipk == pxl_chc.patientacctifk) & (pa1.hospitalfk == pxl_chc.hospitalfk), "left").select(pa1.hospitalfk, pa1.referraldate, pxl_chc.edidatasourcetablekey)

pa_chc.createOrReplaceTempView('pa_chc')
pa_chc=spark.sql("""select hospitalfk, substring(referraldate,1,7) as Month, count(edidatasourcetablekey) as chc_leads  from pa_chc 
            group by hospitalfk, substring(referraldate,1,7)
            order by hospitalfk, substring(referraldate,1,7) desc
             """)

# display(pa_chc)

#pa not genderated for chc
pa_not_gen_chc=pa1.join(pxl_chc, (pa1.patientacctipk == pxl_chc.patientacctifk) & (pa1.hospitalfk == pxl_chc.hospitalfk),  'leftanti')

pa_not_gen_chc.createOrReplaceTempView('pa_not_gen_chc')

pa_not_gen_chc=spark.sql("""select hospitalfk, substring(referraldate,1,7) as Month, count(*) pa_not_gen_chc from pa_not_gen_chc 
            group by hospitalfk, substring(referraldate,1,7)
            order by hospitalfk, substring(referraldate,1,7) desc
             """)

# display(pa_not_gen_chc)

pa_chc_final = fc_accounts.join(pa_not_gen_chc, (fc_accounts.hospitalfk == pa_not_gen_chc.hospitalfk) & (fc_accounts.Month == pa_not_gen_chc.Month)) \
                          .select(fc_accounts["*"],pa_not_gen_chc["pa_not_gen_chc"]) \
                          .withColumn("pa_gen_chc", f.col('pa_received') - f.col('pa_not_gen_chc')) \
                          .withColumn("pa_gen_others", (f.col('pa_generated') - f.col('pa_gen_chc'))) \
                          .sort("hospitalfk", "Month", ascending=[False, True]) 


# display(pa_chc_final)
# pa_chc_final.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp + "/all_leads/")

# #move the data from temp path to actual path
# all_leads_temp_path = write_baseurl + hdfs_output_temp + "/all_leads/"
# all_leads_output_path = write_baseurl + hdfs_output+ "/all_leads/"
# fileNames = dbutils.fs.ls(all_leads_temp_path)
# name = ''
# for filename in fileNames:
#     if filename.name.endswith('.csv'):
#         name=filename.name

# dbutils.fs.cp(all_leads_temp_path + name, all_leads_output_path + '/all_leads_count.csv')

# COMMAND ----------

# DBTITLE 1,CHC Leads Per Payer
#chc counts per payer

pxl_chc2 = spark.read.format("delta").load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/leaddiscovery/publish/patientacctxlead/").filter(col("breadcrumb").contains("CH"))
edi_partners = spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/dataingestion/publish/edipartners/current/20991231/*")
edi_payer = spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/dataingestion/publish/edipayers/current/20991231/*")


#total leads for chc per partner
chc_partner=pxl_chc2.join(edi_partners, (pxl_chc2.lsb_edipartnerfk == edi_partners.edipartnerpk), "left").select(pxl_chc2.breadcrumb, pxl_chc2.
patientacctifk, pxl_chc2.hospitalfk,edi_partners.edipartnerpk, edi_partners.partnername, edi_partners.edipayerfk)

chc_payer = chc_partner.join(edi_payer, (chc_partner.edipayerfk == edi_payer.edipayerpk), "left").select(chc_partner["*"], edi_payer.payername)

chc_payer.createOrReplaceTempView('chc_payer')
chc_payer=spark.sql("""select hospitalfk, payername, to_date(Substr(breadcrumb, 1, 8), 'yyyyMMdd') as bc_date from chc_payer 
                              where to_date(Substr(breadcrumb, 1, 8), 'yyyyMMdd') >= '2023-01-01' """)


# COMMAND ----------

# DBTITLE 1,CHC_Payer_Per_Year
chc_payer.createOrReplaceTempView('chc_payer')
chc_payer_per_year=spark.sql("""select hospitalfk, payername, YEAR(bc_date) as Year, count(payername) as leads_count from chc_payer 
            group by hospitalfk, payername, YEAR(bc_date)
            order by hospitalfk, payername, YEAR(bc_date) desc
             """)

# display(chc_payer_per_year)

chc_payer_per_year.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp + "/chc_payer_counts/yearly/")

#move the data from temp path to actual path
chc_payer_per_year_temp_path = write_baseurl + hdfs_output_temp + "/chc_payer_counts/yearly/"
chc_payer_per_year_output_path = write_baseurl + hdfs_output+ "/chc_payer_counts/yearly/"
fileNames = dbutils.fs.ls(chc_payer_per_year_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(chc_payer_per_year_temp_path + name, chc_payer_per_year_output_path + '/chc_payer_per_year.csv')

# COMMAND ----------

# DBTITLE 1,CHC_Payer_Per_Month
chc_payer.createOrReplaceTempView('chc_payer')
chc_payer_per_month=spark.sql("""select hospitalfk, payername, CONCAT(YEAR(bc_date),"-",MONTH(bc_date)) as YearMonth, count(payername) as leads_count from chc_payer 
            group by hospitalfk, payername, CONCAT(YEAR(bc_date),"-",MONTH(bc_date))
            order by hospitalfk, payername, CONCAT(YEAR(bc_date),"-",MONTH(bc_date)) desc
             """)

# display(chc_payer_per_month)

chc_payer_per_month.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp + "/chc_payer_counts/monthly/")

#move the data from temp path to actual path
chc_payer_per_month_temp_path = write_baseurl + hdfs_output_temp + "/chc_payer_counts/monthly/"
chc_payer_per_month_output_path = write_baseurl + hdfs_output+ "/chc_payer_counts/monthly/"
fileNames = dbutils.fs.ls(chc_payer_per_month_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(chc_payer_per_month_temp_path + name, chc_payer_per_month_output_path + '/chc_payer_per_month.csv')

# COMMAND ----------

# DBTITLE 1,Get PA Ingested Counts
paccts=spark.read.format('delta').load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/dataingestion/publish/patientaccts/current/20991231/")
paccts=paccts.selectExpr("PatientAcctIPK","HospitalFK","referraldate","updatedate")
paccts.createOrReplaceTempView("paccts")

paccts_res=spark.sql("""select HospitalFK,CONCAT(YEAR(referraldate),"-",MONTH(referraldate)) as YearMonth, count(*) as leads_count from paccts 
                     where DATE(referraldate) >= '2022-01-01' 
                     group by HospitalFK,CONCAT(YEAR(referraldate),"-",MONTH(referraldate))
                     order by HospitalFK,CONCAT(YEAR(referraldate),"-",MONTH(referraldate)) desc
                     """)

# display(paccts_res)

paccts_res.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp + "/patientaccts_ingested/")

#move the data from temp path to actual path
paccts_temp_path = write_baseurl + hdfs_output_temp + "/patientaccts_ingested/"
paccts_output_path = write_baseurl + hdfs_output+ "/patientaccts_ingested/"
fileNames = dbutils.fs.ls(paccts_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(paccts_temp_path + name, paccts_output_path + '/patientaccts_ingested_count.csv')

# COMMAND ----------

# DBTITLE 1,Birth Month Process Counts
#birthmonth counts 
pxl_bm = spark.read.format("delta").load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/leaddiscovery/publish/patientacctxlead/").filter(col("breadcrumb").contains("BM"))
# edi_partners = spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/dataingestion/publish/edipartners/current/20991231/*")
# edi_payer = spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/dataingestion/publish/edipayers/current/20991231/*")


#total leads for chc per partner
bm_partner=pxl_bm.join(edi_partners, (pxl_bm.lsb_edipartnerfk == edi_partners.edipartnerpk), "left").select(pxl_bm.breadcrumb, pxl_bm.
patientacctifk, pxl_bm.hospitalfk,edi_partners.edipartnerpk, edi_partners.partnername, edi_partners.edipayerfk)

bm_payer = bm_partner.join(edi_payer, (bm_partner.edipayerfk == edi_payer.edipayerpk), "left").select(bm_partner["*"], edi_payer.payername)

bm_payer.createOrReplaceTempView('bm_payer')
bm_payer=spark.sql("""select hospitalfk, payername, to_date(Substr(breadcrumb, 1, 8), 'yyyyMMdd') as bc_date, count(*) as LeadsSent from bm_payer 
                     group by hospitalfk, payername, bc_date
                     order by hospitalfk, payername, bc_date desc
                     """)


# display(bm_payer)


# COMMAND ----------

bm_payer.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp + "/bm_payer/")

#move the data from temp path to actual path
bm_payer_temp_path = write_baseurl + hdfs_output_temp + "/bm_payer/"
bm_payer_output_path = write_baseurl + hdfs_output+ "/bm_payer/"
fileNames = dbutils.fs.ls(bm_payer_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(bm_payer_temp_path + name, bm_payer_output_path + '/bm_payer_leads_count.csv')

# COMMAND ----------

# DBTITLE 1,Hospital FK - Name
hospitals = spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/dataingestion/publish/hospitals/current/20991231/*").select("hospitalpk", "hospitalname")

# hospitals = spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/dataingestion/publish/hospitals/current/20991231/*").select("hospitalpk", "hospitalname").filter(col("hospitalpk").isin(hosp_arr))

hospitals.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp + "/hospitals/")

#move the data from temp path to actual path
hospitals_temp_path = write_baseurl + hdfs_output_temp + "/hospitals/"
hospitals_output_path = write_baseurl + hdfs_output+ "/hospitals/"
fileNames = dbutils.fs.ls(hospitals_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(hospitals_temp_path + name, hospitals_output_path + '/hospitals_names.csv')
