# Databricks notebook source
# ================================================================================================================================ #
# IMPLEMENTATION                                                                                                                   #
#   OWNERSHIP     : FinThrive ICD RougeOnes                                                                                        #
#   AUTHOR        : Vishnu Patel                                                                                                   #
#   SCRIPTNAME    : generate_directory_clean_up_config_file                                                                        #
# ================================================================================================================================ #
# HISTORY                                                                                                                          #
#     YYYY-MM-DD: AUTHOR         : VERSION : REQID       : DESCRIPTION                                                             #
#     2025-07-14: Max Chatterjee : 1.1     : IDPRO-13600 : Enhance the list and retention peroid = 30 from 60                      #
# JIRA                                                                                                                             #
# https://finthrive.atlassian.net/browse/IDPRO-13600                                                                               #
# ================================================================================================================================ #

# COMMAND ----------

import os
from datetime import datetime
from pyspark.sql.functions import *
from pyspark.sql.types import IntegerType

# COMMAND ----------

dbutils.widgets.text("adlsBasePath","")
adlsBasePath = dbutils.widgets.get("adlsBasePath")

dbutils.widgets.text("cleanupConfigPath","")
cleanupConfigPath = dbutils.widgets.get("cleanupConfigPath")

dbutils.widgets.text("storageAccountName","")
storageAccountName = dbutils.widgets.get("storageAccountName")

spark.conf.set("fs.azure.account.key."+storageAccountName+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# adlsBasePath = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/"
# cleanupConfigPath = "data/maintenance/cleanup_config"

# COMMAND ----------

appNameList = ["audit", "cdd", "chc", "coveragehelpers", "dataingestion", "gmrn", "leaddiscovery", "leadrepo", "leadservicebase", "maintenance", "ops_hints","hintsdiscovery"]
validAppSubDirectories = ["staging", "transform"]

# COMMAND ----------

# data/audit/staging/           - Valid
# data/gmrn/publish/            - Valid
# data/leadrepo/transform/      - Valid
# data/ops_hints/publish/       - Invalid
# data/unknown_app/staging/     - Invalid
# data/gmrn/invalid_sub_dir/    - Invalid
# data/cdd/publish/             - Invalid
# data/leadrepo/publish         - Valid

# """
# :param appName - this parameter comes from config file to validate if the path has valid app name and sub directory.
# :param path - the path to validate. Also. comes from config file.  
# :return: Returns True if the path is valid, False otherwise. 
# """
def isValidPath(appName, path):
   
    parts = path.strip('/').split('/')
    
    # Check basic structure
    if len(parts) < 3 or parts[0] != 'data':
        return False
    
    app = parts[1]
    subDir = parts[2]
    
    # Validate app name
    if app not in appNameList or appName not in appNameList or appName != app:
        return False
    
    # Validate subdirectory
    if subDir in validAppSubDirectories:
        return True
    # Exception case for these two apps
    elif subDir == "publish" and app in ["gmrn", "leadrepo"]:
        return True
    
    return False

# COMMAND ----------

import re
def isValidBC(bc):
    error = 0
    bc = bc.strip('/') # Checking the breadcrumb passed to be a valid breadcrumb
    if len(bc) >= 14: # Handling the cases for breadcrumbs with '-' & '_' like 20250410T06-MA, 20250410T06-IX, 20250409T12_PARQ_RECON, 20250409T12_temp
        bc=bc.split('-')[0]
        bc=bc.split('_')[0]
    else:
        bc=bc
    if not bc:  # proceeds when bc value empty
        error = 1
    else:
        if not (re.match(r"^\d{2}[A-Z]{3}\d{4}(-)\d{2}$", bc) or re.match(r"^\d{8}T\d{2}$", bc)):  # checks if bc value matches to yyyymmddThh or ddMMMyyyy-hh format
            error = 1
        else:
            if re.match(r"^\d{2}[A-Z]{3}\d{4}(-)\d{2}$", bc):  # ddMMMyyyy-hh
                month = bc[2:5]
                day = bc[0:2]
                year = bc[5:9]
                hh = bc[10:12]
                months = ["INVALID", "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"]
                imonth = months.index(month)
                try:
                    datetime(int(year), int(imonth), int(day), int(hh))
                except ValueError:
                    error = 1
            elif re.match(r"^\d{8}T\d{2}$", bc):  # yyyymmddThh
                imonth = bc[4:6]
                day = bc[6:8]
                year = bc[0:4]
                hh = bc[9:11]
                try:
                    datetime(int(year), int(imonth), int(day), int(hh))
                except ValueError:
                    error = 1
    return error

# COMMAND ----------

validBC = udf(isValidBC, IntegerType())

# COMMAND ----------

try:
    # Read the config file
    configPath = os.path.join(adlsBasePath, cleanupConfigPath, 'cleanup_config.csv')
    df_clean_up_config = spark.read.csv(configPath, header=True, inferSchema=True)
except Exception as e:
    raise Exception("Error reading config file: {}".format(e))

# COMMAND ----------

try:
    # Get the list of directories to be cleaned up which has BCs
    directoryListWithBC = [{'appName': row.appName, 'path':row.path, 'bcPersistCount':row.bcPersistCount} for row in df_clean_up_config.filter(df_clean_up_config.bcPersistCount.isNotNull()).select("appName", "path", "bcPersistCount").collect()]
except Exception as e:
    raise Exception("Error getting the directory list with BC: {}".format(e))

# COMMAND ----------

try:
    finalDirectoriesToBeDeleted = []
    for item in directoryListWithBC:
        # print(f"{item['path']} has {item['bcPersistCount']}")
        appName = item['appName']
        path = item['path'].strip('/')

        if not isValidPath(appName, path):
            raise Exception(f"Invalid path found for deletion. Please rectify the config file and retry. Path: {path}")
        
        bcPath = os.path.join(adlsBasePath, path)
        try :
            bcPathInfo = dbutils.fs.ls(bcPath)
            bcPathInfo = dbutils.fs.ls(bcPath)
            df_bc_path_info = spark.createDataFrame(bcPathInfo)
            df_bc_path_info = df_bc_path_info.withColumn("isValidBC", validBC(col("name")))
            df_bc_path_info = df_bc_path_info.filter(df_bc_path_info.isValidBC == 0).drop("isValidBC")

            # Get the BCs to be deleted based on modification time of the folder thus persisting top N BCs based on bcPersistCount value got from config file for a given directory
        
            # df_bc_delete = df_bc_path_info.subtract(df_bc_path_info.orderBy(col("modificationTime").desc()).limit(item['bcPersistCount']))
            # To delete the BCs based on modification time. Deleting the breadcrumbs having modificationtime less tha 60 days from current time
            df_bc_path_info1=df_bc_path_info.withColumn("modificationTime_date",col("modificationTime")/1000)
            df_bc_path_info2=df_bc_path_info1.withColumn("current_time",unix_timestamp(current_date()-30))
            df_bc_delete=df_bc_path_info2.filter(df_bc_path_info2.modificationTime_date<df_bc_path_info2.current_time).drop("modificationTime_date","current_time")  
            finalDirectoriesToBeDeleted = finalDirectoriesToBeDeleted + [row.path.replace(adlsBasePath, '') for row in df_bc_delete.collect()]
        except Exception as e: print(f"Path does not exist: {bcPath}")
except Exception as e:
    raise Exception("Error getting the list of BCs to be deleted based on bcPersistCount: {}".format(e))

# COMMAND ----------

try:
    # removing duplicate directories if any
    finalDirectoriesToBeDeleted = list(dict.fromkeys(finalDirectoriesToBeDeleted))
    cleanupDirectoryConfigPath = ""
    
    if finalDirectoriesToBeDeleted:
        # BC format - 20240626T19
        # saving the directories to be deleted in csv path for logging purpose
        cleanupDirectoryConfigPath = f"{cleanupConfigPath}/cleanup_directories/{datetime.now().strftime('%Y%m%dT%H')}"
        deleteFilePath = os.path.join(adlsBasePath, cleanupDirectoryConfigPath)
        df_final_directories = spark.createDataFrame([(path,) for path in finalDirectoriesToBeDeleted], ["path"])
        df_final_directories.coalesce(1).write.csv(deleteFilePath, header=True, mode="overwrite")
        # display(df_final_directories)
        # print(finalDirectoriesToBeDeleted)
    dbutils.notebook.exit({"cleanupDirectoryConfigPath": cleanupDirectoryConfigPath})
except Exception as e:
    raise Exception("Error creating a csv file having directories for deletion: {}".format(e))

# COMMAND ----------

# data = spark.read.format("csv").option("header", "true").load(deleteFilePath)
# paths = [row['path'] for row in data.collect()]

# url_path = f"{adlsBasePath}/"
# for p in paths:
#     print(url_path + p)
#     dbutils.fs.rm(url_path + p, True)

# COMMAND ----------


