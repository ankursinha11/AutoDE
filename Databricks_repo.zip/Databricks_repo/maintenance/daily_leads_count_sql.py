# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *
from datetime import datetime, timedelta, date
from datetime import datetime, timedelta
today = datetime.today()
date_list = [(today - timedelta(days=i)).strftime("%Y%m%d") for i in range(3)]
date_list_sql = ', '.join(f"'{date}'" for date in date_list)
check_list = [(today - timedelta(days=i)).strftime("%Y%m%d") for i in range(7)]
check_list_sql = ', '.join(f"'{date}'" for date in check_list)


# COMMAND ----------

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("write_container","")
dbutils.widgets.getArgument("write_container")
write_container= getArgument("write_container")

dbutils.widgets.text("write_storageaccount","")
dbutils.widgets.getArgument("write_storageaccount")
write_storageaccount= getArgument("write_storageaccount")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("hdfs_output","")
dbutils.widgets.getArgument("hdfs_output")
hdfs_output= getArgument("hdfs_output")

dbutils.widgets.text("hdfs_output_temp","")
dbutils.widgets.getArgument("hdfs_output_temp")
hdfs_output_temp= getArgument("hdfs_output_temp")

dbutils.widgets.text("hdfs_leads_sent","")
dbutils.widgets.getArgument("hdfs_leads_sent")
hdfs_leads_sent= getArgument("hdfs_leads_sent")

dbutils.widgets.text("hdfs_patient_accts","")
dbutils.widgets.getArgument("hdfs_patient_accts")
hdfs_patient_accts= getArgument("hdfs_patient_accts")

dbutils.widgets.text("hdfs_hosp_path","")
dbutils.widgets.getArgument("hdfs_hosp_path")
hdfs_hosp_path= getArgument("hdfs_hosp_path")

# COMMAND ----------

# #read storage acct
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

#write storage acct
spark.conf.set("fs.azure.account.key."+write_storageaccount+".blob.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-prodicdst-insleads-kvsecret"))

path_conn_file = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-transport-sql-insleads-cs")

# COMMAND ----------

#read base url
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 


#write base url
if user == 'na': #defualt value
    # wasbs://icdleadsreports@prodicdst.blob.core.windows.net/
    write_baseurl ='wasbs://'+write_container+'@'+write_storageaccount+'.blob.core.windows.net'
else:
    write_baseurl ='wasbs://'+write_container+'@'+write_storageaccount+'.blob.core.windows.net/'+user 

# COMMAND ----------

spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)

# COMMAND ----------

hdfs_leads_sent = baseurl + hdfs_leads_sent
hdfs_patient_accts = baseurl + hdfs_patient_accts
hdfs_hosp_path = baseurl + hdfs_hosp_path
hdfs_output = write_baseurl + hdfs_output
hdfs_output_temp = write_baseurl + hdfs_output_temp

# COMMAND ----------

data = [("", "Commercial Generation","1"), 
        ("-MC", "Medicare Leads Generation","2"),
        ("-MA", "Medicaid Leads Generation","3"),
        ("-KC", "Known Commercial Leads Generation","14"),
        ("-LV", "Lead Verify","13"),
        ("-GM", "Lead Propagation due to GMRN Merge","12"),
        ("-FM", "Perm id based Family Clustering after new Patient Acounts","9"),
        ("-FF", "Perm id based Family Clustering on new Found Coverage Leads","10"),
        ("-FI", "Perm id based Family Clustering on new ICH Leads","11"),
        ("-FC", "Lead Propagation due to new FC Leads","6"), 
        ("-ES", "Lead Propagation due to new PatientacctsXICH leads","4"),
        ("-CH", "Lead Propagation due to new CHC Leads","7"),
        ("-IX", "Lead Propagation due to new ICH Leads","5"),
        ("-GH", "Lead Propagation due to GMRN Family Associations","8")]
names_df = spark.createDataFrame(data, ["breadcrumb1", "description", "order"])
# display(names_df)

# COMMAND ----------

# Add new columns dynamically
for date in date_list:
    names_df = names_df.withColumn(f"{date}_col", concat_ws("", expr(f"'{date}'"), col("breadcrumb1")))
# display(names_df)
# Transpose columns to rows using stack()
stack_expr = "stack({0}, {1}) as (date, value)".format(
    len(date_list), ", ".join([f"'{date}', {date}_col" for date in date_list])
)

transposed_df = names_df.selectExpr("description","breadcrumb1","order", stack_expr).drop("date")
transposed_df=transposed_df.withColumnRenamed("value", "breadcrumb2")
# Show the result
# display(transposed_df)

# COMMAND ----------

query = """
    SELECT 
        breadcrumb, 
        COUNT(1) AS count  
    FROM [ICDTransport].[dbo].[HDPPatientAcctXLead]
    WHERE breadcrumb BETWEEN FORMAT((DATEADD(DAY, -2, CAST(GETDATE() AS DATE))),'yyyyMMdd') AND FORMAT((DATEADD(DAY, 1, CAST(GETDATE() AS DATE))),'yyyyMMdd') 
    GROUP BY breadcrumb
"""
df_leads = spark.read.format("jdbc").option("url", path_conn_file).option("query", query).load()
df_leads.createOrReplaceTempView("pax")
# df_leads.display()

# COMMAND ----------

leads_df = spark.sql(""" Select * from pax """)
leads_df=leads_df.withColumn("breadcrumb_cleaned", expr("concat(substring(breadcrumb, 1, 8), substring(breadcrumb, 12, length(breadcrumb)))"))
# display(leads_df)

# COMMAND ----------

joined_df = transposed_df.join(leads_df, transposed_df.breadcrumb2 == leads_df.breadcrumb_cleaned, "left_outer")
updated_leads_df = joined_df.withColumn(
    "breadcrumb_modified",
    when(col("breadcrumb").isNull(),expr("concat(substring(breadcrumb2, 1, 8), 'T00', substring(breadcrumb2, 9, length(breadcrumb2)))")).otherwise(col("breadcrumb"))
).withColumn("leaddate",substring(col("breadcrumb2"), 1, 8))
# display(updated_leads_df)

updated_leads_df = updated_leads_df.withColumn(
    "status", 
    when(col("count").isNull(), lit("Missing")).otherwise(lit(""))
)
updated_leads_df=updated_leads_df.fillna({"count": 0})

updated_leads_df=updated_leads_df.select(col("breadcrumb_modified").alias("breadcrumb"), "description","order", "count", "status",  col("leaddate").alias("CreateDate") )
# display(updated_leads_df)

updated_leads_df.repartition(1).write.format('csv').mode('overwrite').save(hdfs_output_temp + "/leads_count/")

#move the data from temp path to actual path
updated_leads_temp_path = hdfs_output_temp + "/leads_count/"
updated_leads_output_path = hdfs_output+ "/leads_count/"
fileNames = dbutils.fs.ls(updated_leads_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(updated_leads_temp_path + name, updated_leads_output_path + '/leads_count_sql.csv')

# COMMAND ----------

hosp_df = spark.read.parquet(hdfs_hosp_path).select('hospitalpk', 'hospitalname')

# COMMAND ----------

leads_hosp_query = f"""
SELECT CreateDate, HospitalFK, count FROM (
    SELECT 
        B.CreateDate AS CreateDate,
        P.HospitalFK AS HospitalFK,
        COUNT(*) AS count,
        ROW_NUMBER() OVER (PARTITION BY B.CreateDate ORDER BY COUNT(*) DESC) AS rank
    FROM (
        SELECT HospitalFK, Breadcrumb, CONVERT(VARCHAR(8), Breadcrumb, 112) AS BreadcrumbDate
        FROM ICDTransport.dbo.HDPPatientAcctXLead
    ) P
    JOIN (
        SELECT Breadcrumb, CONVERT(VARCHAR(8), Breadcrumb, 112) AS BreadcrumbDate,
               CONVERT(VARCHAR(8), CreateDate, 112) AS CreateDate
        FROM ICDTransport.dbo.HDPPatientAcctXLeadBatch
        WHERE CONVERT(VARCHAR(8), Breadcrumb, 112) IN ({check_list_sql})
    ) B 
    ON P.Breadcrumb = B.Breadcrumb
    WHERE CreateDate IN ({date_list_sql})
    GROUP BY B.CreateDate, P.HospitalFK
) AggregatedData
WHERE rank <= 5 AND rank IS NOT NULL
"""
leads_hosp_df = spark.read.format("jdbc").option("url", path_conn_file).option("query", leads_hosp_query).load()

leads_hosp_df=leads_hosp_df.join(hosp_df, leads_hosp_df.HospitalFK == hosp_df.hospitalpk, "left_outer").select("hospitalfk", "hospitalname", "count", "CreateDate")
# display(leads_hosp_df)
leads_hosp_df.repartition(1).write.format('csv').mode('overwrite').save(hdfs_output_temp + "/leads_hosp_count/")

#move the data from temp path to actual path
leads_hosp_temp_path = hdfs_output_temp + "/leads_hosp_count/"
leads_hosp_output_path = hdfs_output+ "/leads_hosp_count/"
fileNames = dbutils.fs.ls(leads_hosp_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(leads_hosp_temp_path + name, leads_hosp_output_path + '/leads_hosp_count_sql.csv')

# COMMAND ----------

leads_sum_query = f"""
    SELECT 
        B.CreateDate AS CreateDate,
        COUNT(*) AS count
    FROM (
        SELECT Breadcrumb, CONVERT(VARCHAR(8), Breadcrumb, 112) AS BreadcrumbDate
        FROM ICDTransport.dbo.HDPPatientAcctXLead
    ) P
    JOIN (
        SELECT Breadcrumb, CONVERT(VARCHAR(8), Breadcrumb, 112) AS BreadcrumbDate,
               CONVERT(VARCHAR(8), CreateDate, 112) AS CreateDate
        FROM ICDTransport.dbo.HDPPatientAcctXLeadBatch
        WHERE CONVERT(VARCHAR(8), Breadcrumb, 112) IN ({check_list_sql})
    ) B 
    ON P.Breadcrumb = B.Breadcrumb
    WHERE CreateDate IN ({date_list_sql})
    GROUP BY B.CreateDate
"""
leads_hosp_sum_df = spark.read.format("jdbc").option("url", path_conn_file).option("query", leads_sum_query).load()
# leads_hosp_sum_df.display()
leads_hosp_sum_df.repartition(1).write.format('csv').mode('overwrite').save(hdfs_output_temp + "/leads_hosp_sum_count/")

#move the data from temp path to actual path
leads_hosp_temp_path = hdfs_output_temp + "/leads_hosp_sum_count/"
leads_hosp_output_path = hdfs_output+ "/leads_hosp_sum_count/"
fileNames = dbutils.fs.ls(leads_hosp_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(leads_hosp_temp_path + name, leads_hosp_output_path + '/leads_hosp_sum_count_sql.csv')

# COMMAND ----------

patient_df = spark.read.format("delta").load(hdfs_patient_accts)
patient_df.createOrReplaceTempView("patientaccts")
patient_acct_df = spark.sql(f""" Select hospitalfk, trgupdatedate, date_format(trgupdatedate, 'yyyyMMdd') as trgdate from patientaccts order by trgupdatedate desc""")
patient_acct_df.createOrReplaceTempView("patientaccts")

# COMMAND ----------

patient_query = f"""
WITH RankedData AS (
    SELECT 
        hospitalfk,
        trgdate, 
        COUNT(*) AS cnt,
        ROW_NUMBER() OVER (PARTITION BY trgdate ORDER BY COUNT(*) DESC) AS rank
    FROM patientaccts
    WHERE trgdate IN ({", ".join(f"'{date}'" for date in date_list)})  
    GROUP BY hospitalfk, trgdate
)
SELECT hospitalfk, trgdate, cnt
FROM RankedData
WHERE rank <= 5
ORDER BY trgdate DESC, cnt DESC
"""

patient_hosp_df = spark.sql(patient_query)


patient_hosp_df=patient_hosp_df.join(hosp_df, patient_hosp_df.hospitalfk == hosp_df.hospitalpk, "left_outer").select(patient_hosp_df.hospitalfk, hosp_df.hospitalname, "cnt", patient_hosp_df.trgdate.alias("RecDate")).orderBy(col("RecDate").desc(), col("cnt").desc())
# display(patient_hosp_df)
patient_hosp_df.repartition(1).write.format('csv').mode('overwrite').save(hdfs_output_temp + "/patient_hosp_count/")

#move the data from temp path to actual path
patient_hosp_temp_path = hdfs_output_temp + "/patient_hosp_count/"
patient_hosp_output_path = hdfs_output+ "/patient_hosp_count/"
fileNames = dbutils.fs.ls(patient_hosp_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(patient_hosp_temp_path + name, patient_hosp_output_path + '/patient_hosp_count.csv')

# COMMAND ----------

patient_sum_query = f"""
WITH RankedData AS (
    SELECT 
        trgdate, 
        COUNT(*) AS cnt
    FROM patientaccts
    WHERE trgdate IN ({", ".join(f"'{date}'" for date in date_list)})  
    GROUP BY trgdate
)
SELECT cnt,trgdate
FROM RankedData
"""

# Single SQL query
patient_hosp_sum_df = spark.sql(patient_sum_query)
# display(patient_hosp_sum_df)
patient_hosp_sum_df.repartition(1).write.format('csv').mode('overwrite').save(hdfs_output_temp + "/patient_hosp_sum_count/")

#move the data from temp path to actual path
patient_hosp_temp_path = hdfs_output_temp + "/patient_hosp_sum_count/"
patient_hosp_output_path = hdfs_output+ "/patient_hosp_sum_count/"
fileNames = dbutils.fs.ls(patient_hosp_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(patient_hosp_temp_path + name, patient_hosp_output_path + '/patient_hosp_sum_count.csv')
