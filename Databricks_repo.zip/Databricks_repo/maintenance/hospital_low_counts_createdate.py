# Databricks notebook source
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql.window import Window
import sys
import datetime
import getpass
import os
import pyspark.sql.functions as f

# COMMAND ----------

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("write_container","")
dbutils.widgets.getArgument("write_container")
write_container= getArgument("write_container")

dbutils.widgets.text("write_storageaccount","")
dbutils.widgets.getArgument("write_storageaccount")
write_storageaccount= getArgument("write_storageaccount")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("hdfs_output","")
dbutils.widgets.getArgument("hdfs_output")
hdfs_output= getArgument("hdfs_output")

dbutils.widgets.text("hdfs_output_temp","")
dbutils.widgets.getArgument("hdfs_output_temp")
hdfs_output_temp= getArgument("hdfs_output_temp")

dbutils.widgets.text("hospitalList","")
dbutils.widgets.getArgument("hospitalList")
hospitalList= getArgument("hospitalList")

dbutils.widgets.text("hcsystemList","")
dbutils.widgets.getArgument("hcsystemList")
hcsystemList= getArgument("hcsystemList")

# COMMAND ----------

#read storage acct
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

#write storage acct
spark.conf.set("fs.azure.account.key."+write_storageaccount+".blob.core.windows.net","IEfzxj47CMO5j8WXNcugYeiCG5Ip/pypR+apR+/eQUOUxA9wapX8oK6rIdn+K87Dvyezcix8wcSK+AStM0qxww==")

# COMMAND ----------

#read base url
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 


#write base url
if user == 'na': #defualt value
    # wasbs://icdleadsreports@prodicdst.blob.core.windows.net/
    write_baseurl ='wasbs://'+write_container+'@'+write_storageaccount+'.blob.core.windows.net'
else:
    write_baseurl ='wasbs://'+write_container+'@'+write_storageaccount+'.blob.core.windows.net/'+user 

# COMMAND ----------

spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)

# COMMAND ----------

print("container: "+str(container))
print("storageaccount: "+str(storageaccount))
print("user: "+str(user))
print("hospitalList: "+str(hospitalList))
hosp_arr = hospitalList.split(",")
print("hosp_arr: "+str(hosp_arr))
print("hcsystemList: "+str(hcsystemList))
hcsystem_arr = hcsystemList.split(",")
print("hcsystem_arr: "+str(hcsystem_arr))
print("hdfs_output: "+str(hdfs_output))
print("hdfs_output_temp: "+str(hdfs_output_temp))

# COMMAND ----------

dataingestion_publish_path = baseurl + '/data/dataingestion/publish/'
pa_path = dataingestion_publish_path+'patientaccts/current/20991231/'
hosp_path = dataingestion_publish_path+'hospitals/current/20991231/'
pac_path = dataingestion_publish_path+'patientacctscodes/current/20991231/'
gmrnxpa_path = baseurl+'/data/gmrn/publish/globalmrnxpacct/current/'
lsb_path = baseurl+'/data/leadservicebase/publish/served/leadservicebase/'
permid_pa_path = baseurl + '/data/cdd/publish/permidpatientacctid/'
paxl_path = baseurl + '/data/leaddiscovery/publish/patientacctxlead/'

print("dataingestion_publish_path: "+str(dataingestion_publish_path))
print("pa_path: "+str(pa_path))
print("hosp_path: "+str(hosp_path))
print("pac_path: "+str(pac_path))
print("gmrnxpa_path: "+str(gmrnxpa_path))
print("lsb_path: "+str(lsb_path))
print("permid_pa_path: "+str(permid_pa_path))
print("paxl_path: "+str(paxl_path))

# COMMAND ----------

# DBTITLE 1,Read PA and Hosp
pa = spark.read.format("delta").load(pa_path).select('patientacctpk','createdate', 'patientacctipk','hospitalfk', 'ssn', 'clusteredacctfk', 'medicalrecnum')
hosp = spark.read.parquet(hosp_path).select('hospitalpk', 'hcsystemfk').filter(col("active") == 1)

paxhosp = pa.join(hosp, (pa.hospitalfk == hosp.hospitalpk))
paxhosp1 = paxhosp.filter((paxhosp.hospitalfk.isin(hosp_arr)) | ((paxhosp.hcsystemfk.isin(hcsystem_arr)))) 
paxhosp2 = paxhosp1.filter(paxhosp1.createdate.between('2023-01-01', '2099-12-31')).withColumn("Month", paxhosp1.createdate.substr(1, 7))


# COMMAND ----------

# DBTITLE 1,PA received by Month
paxhosp2.createOrReplaceTempView('paxhosp2')

#Get the counts of the PA generated per month

pa_reveived=spark.sql("""select hospitalfk, hcsystemfk, substring(createdate,1,7) as Month, count(*) as pa_received from paxhosp2
            group by hospitalfk, hcsystemfk, substring(createdate,1,7)
            order by hospitalfk, hcsystemfk, substring(createdate,1,7) desc
             """)

# COMMAND ----------

# DBTITLE 1,Get LSB data and split all 5 IDs
lsb = spark.read.format("delta").load(lsb_path).select("_id", "hcsystemfk_source", "identity", "leadcreatedate", "leadupdatedate", "lsbcreatedate")
lsb_g =lsb.filter(col("_id").startswith('G'))
lsb_p =lsb.filter(col("_id").startswith('P'))
lsb_s =lsb.filter(col("_id").startswith('S'))
lsb_m =lsb.filter(col("_id").startswith('MH'))
lsb_c =lsb.filter(col("_id").startswith('CH'))

# COMMAND ----------

# DBTITLE 1,Get GMRNID counts
gxp = spark.read.parquet(gmrnxpa_path + "/*/")
# pag= paxhosp2.join(gxp, (col('patientacctipk') == col('patientacctifk'))).select(paxhosp2['*'], gxp.globalmrnifk).dropDuplicates()
pag = paxhosp2.join(
    gxp,
    (paxhosp2["patientacctipk"] == gxp["patientacctifk"]) & 
    (paxhosp2["hospitalfk"] == gxp["hospitalfk"])
).select(
    paxhosp2["*"],
    gxp["globalmrnifk"]
).dropDuplicates()
#Get the counts of the GMRNID generated per month
pag.createOrReplaceTempView('pag')
from pyspark.sql.types import DecimalType

gmrnid_df=spark.sql("""select hospitalfk, hcsystemfk, substring(createdate,1,7) as Month, count(*) as GMRNID from pag
            group by hospitalfk, hcsystemfk, substring(createdate,1,7)
            order by hospitalfk, hcsystemfk, substring(createdate,1,7) desc
             """)

leads_gmrn = pa_reveived.join(gmrnid_df, (pa_reveived.hospitalfk == gmrnid_df.hospitalfk) & (pa_reveived.Month == gmrnid_df.Month)) \
                          .select(pa_reveived["*"],gmrnid_df["GMRNID"]) \
                          .withColumn("GMRNID%", (f.col('GMRNID')/f.col('pa_received')*100).cast(DecimalType(4,2)))


# COMMAND ----------

# DBTITLE 1,Match GMRNID based leads not in LSB
pagl = pag.join(lsb_g, concat(lit('G'), lit('_'), pag.globalmrnifk) == lsb_g.identity, 'leftanti')

# GMRN ID Not in LSB
pagl.createOrReplaceTempView('pagl')
leadsNotinLSB_g=spark.sql("""select hospitalfk, hcsystemfk, substring(createdate,1,7) as Month, count(*) as GMRNId_NotinLSB  from pagl
            group by hospitalfk, hcsystemfk, substring(createdate,1,7)
            order by hospitalfk, hcsystemfk, substring(createdate,1,7) desc
             """)


leads_gmrn2 = leads_gmrn.join(leadsNotinLSB_g, (leads_gmrn.hospitalfk == leadsNotinLSB_g.hospitalfk) & (leads_gmrn.Month == leadsNotinLSB_g.Month)) \
                            .select(leads_gmrn["*"],leadsNotinLSB_g["GMRNId_NotinLSB"]) \
                            .withColumn("GMRNId_InLSB", f.col('GMRNID') - f.col('GMRNId_NotinLSB')) \
                            .withColumn("GMRN% Leads in LSB",  (f.col('GMRNId_InLSB')/f.col('pa_received')*100).cast(DecimalType(4,2)))

# COMMAND ----------

# DBTITLE 1,Get PremId Counts
pp = spark.read.parquet(f"{permid_pa_path}/*/")
pp = pp.filter("matchind in('IM','M1')").select("patientacctifk", "permid", "hospitalfk").dropDuplicates()

# pap= paxhosp2.join(pp, (col('patientacctipk') == col('patientacctifk'))).select(paxhosp2['*'], pp.permid).dropDuplicates()

pap = paxhosp2.join(
    pp,
    (paxhosp2.patientacctipk == pp.patientacctifk) & (paxhosp2.hospitalfk == pp.hospitalfk)
).select(paxhosp2['*'], pp.permid).dropDuplicates()

pap.createOrReplaceTempView('pap')
permid_df=spark.sql("""select hospitalfk, hcsystemfk, substring(createdate,1,7) as Month, count(*) as PermID  from pap
            group by hospitalfk, hcsystemfk, substring(createdate,1,7)
            order by hospitalfk, hcsystemfk, substring(createdate,1,7) desc
             """)

leads_permid = leads_gmrn2.join(permid_df, (leads_gmrn2.hospitalfk == permid_df.hospitalfk) & (leads_gmrn2.Month == permid_df.Month)) \
                          .select(leads_gmrn2["*"],permid_df["PermID"]) \
                          .withColumn("PermID%", (f.col('PermID')/f.col('pa_received')*100).cast(DecimalType(4,2)))

# COMMAND ----------

# DBTITLE 1,Match PERMID based leads not in LSB
papl = pap.join(lsb_p, concat(lit('P'), lit('_'), pap.permid) == lsb_p.identity, 'leftanti')

papl.createOrReplaceTempView('papl')
leadsNotinLSB_p=spark.sql("""select hospitalfk, hcsystemfk, substring(createdate,1,7) as Month, count(*) as PERMID_NotinLSB from papl
            group by hospitalfk, hcsystemfk, substring(createdate,1,7)
            order by hospitalfk, hcsystemfk, substring(createdate,1,7) desc
             """)

leads_permid2 = leads_permid.join(leadsNotinLSB_p, (leads_permid.hospitalfk == leadsNotinLSB_p.hospitalfk) & (leads_permid.Month == leadsNotinLSB_p.Month)) \
                            .select(leads_permid["*"],leadsNotinLSB_p["PERMID_NotinLSB"]) \
                            .withColumn("PERMID_inLSB", f.col('PermID') - f.col('PERMID_NotinLSB')) \
                            .withColumn("PERM% Leads in LSB",  (f.col('PERMID_inLSB')/f.col('pa_received')*100).cast(DecimalType(4,2)))



# COMMAND ----------

# DBTITLE 1,Get SSN counts
pas2 = paxhosp2.filter(col('ssn').isNotNull())

pas2.createOrReplaceTempView('pas2')
ssn_df=spark.sql("""select hospitalfk, hcsystemfk, substring(createdate,1,7) as Month, count(*) as SSN  from pas2
            group by  hospitalfk, hcsystemfk, substring(createdate,1,7)
            order by  hospitalfk, hcsystemfk, substring(createdate,1,7) desc
             """)
# ssn_df.show(500,False)

leads_ssn = leads_permid2.join(ssn_df, (leads_permid2.hospitalfk == ssn_df.hospitalfk) & (leads_permid2.Month == ssn_df.Month)) \
                          .select(leads_permid2["*"],ssn_df["SSN"]) \
                          .withColumn("SSN%", (f.col('SSN')/f.col('pa_received')*100).cast(DecimalType(4,2)))

# COMMAND ----------

# DBTITLE 1,Match SSN based leads not in LSB
pasl = pas2.join(lsb_s, concat(lit('S'), lit('_'), pas2.ssn) == lsb_s.identity, 'leftanti')

pasl.createOrReplaceTempView('pasl')
leadsNotinLSB_s=spark.sql("""select hospitalfk, hcsystemfk, substring(createdate,1,7) as Month,  count(*) as SSN_NotInLSB from pasl
            group by hospitalfk, hcsystemfk, substring(createdate,1,7)
            order by hospitalfk, hcsystemfk, substring(createdate,1,7) desc
             """)

leads_ssn2 = leads_ssn.join(leadsNotinLSB_s, (leads_ssn.hospitalfk == leadsNotinLSB_s.hospitalfk) & (leads_ssn.Month == leadsNotinLSB_s.Month)) \
                            .select(leads_ssn["*"],leadsNotinLSB_s["SSN_NotInLSB"]) \
                            .withColumn("SSN_InLSB", f.col('SSN') - f.col('SSN_NotInLSB')) \
                            .withColumn("SSN% Leads in LSB",  (f.col('SSN_InLSB')/f.col('pa_received')*100).cast(DecimalType(6,2)))

# COMMAND ----------

# DBTITLE 1,Get Clusteredacctid 
pac2 = paxhosp2.filter(col('clusteredacctfk').isNotNull())

pac2.createOrReplaceTempView('pac2')
clusterdact_df=spark.sql("""select hospitalfk, hcsystemfk, substring(createdate,1,7) as Month, count(*) as Clusteredacctfk  from pac2
            group by hospitalfk, hcsystemfk, substring(createdate,1,7)
            order by hospitalfk, hcsystemfk, substring(createdate,1,7) desc
             """)

leads_clusteredacct = leads_ssn2.join(clusterdact_df, (leads_ssn2.hospitalfk == clusterdact_df.hospitalfk) & (leads_ssn2.Month == clusterdact_df.Month)) \
                          .select(leads_ssn2["*"],clusterdact_df["Clusteredacctfk"]) \
                          .withColumn("Clusteredacctfk%", (f.col('Clusteredacctfk')/f.col('pa_received')*100).cast(DecimalType(6,2)))

# COMMAND ----------

# DBTITLE 1,Match Clusteredacctid based leads not in LSB
pacl = pac2.join(lsb_c, concat(lit('CH'), lit('_'), pac2.hospitalfk, lit('_'), pac2.clusteredacctfk) == lsb_c.identity, 'leftanti')

pacl.createOrReplaceTempView('pacl')
leadsNotinLSB_c=spark.sql("""select hospitalfk, hcsystemfk, substring(createdate,1,7) as Month, count(*) as clusteredact_NotinLSB  from pacl
            group by hospitalfk, hcsystemfk, substring(createdate,1,7)
            order by hospitalfk, hcsystemfk, substring(createdate,1,7) desc
             """)

leads_clusteredacct2 = leads_clusteredacct.join(leadsNotinLSB_c, (leads_clusteredacct.hospitalfk == leadsNotinLSB_c.hospitalfk) & (leads_clusteredacct.Month == leadsNotinLSB_c.Month)) \
                            .select(leads_clusteredacct["*"],leadsNotinLSB_c["clusteredact_NotinLSB"]) \
                            .withColumn("clusteredact_inLSB", f.col('Clusteredacctfk') - f.col('clusteredact_NotinLSB')) \
                            .withColumn("ClusteredAcct% Leads in LSB",  (f.col('clusteredact_inLSB')/f.col('pa_received')*100).cast(DecimalType(4,2)))

# COMMAND ----------

# DBTITLE 1,Get MRN counts
pam2 = paxhosp2.filter(col('medicalrecnum').isNotNull())
             
pam2.createOrReplaceTempView('pam2')
mrn_df=spark.sql("""select hospitalfk, hcsystemfk, substring(createdate,1,7) as Month, count(*) as MRN  from pam2
            group by hospitalfk, hcsystemfk, substring(createdate,1,7)
            order by hospitalfk, hcsystemfk, substring(createdate,1,7) desc
             """)
# mrn_df.show(500,False)

leads_mrn = leads_clusteredacct2.join(mrn_df, (leads_clusteredacct2.hospitalfk == mrn_df.hospitalfk) & (leads_clusteredacct2.Month == mrn_df.Month)) \
                          .select(leads_clusteredacct2["*"],mrn_df["MRN"]) \
                          .withColumn("MRN%", (f.col('MRN')/f.col('pa_received')*100).cast(DecimalType(6,2)))

# COMMAND ----------

# DBTITLE 1,Match mrn based leads not in LSB
paml = pam2.join(lsb_m, concat(lit('MH'), lit('_'), pam2.hospitalfk, lit('_'), pam2.medicalrecnum) == lsb_m.identity, 'leftanti')

paml.createOrReplaceTempView('paml')
leadsNotinLSB_m=spark.sql("""select hospitalfk, hcsystemfk, substring(createdate,1,7) as Month, count(*) MRN_NotInLSB  from paml
            group by hospitalfk, hcsystemfk, substring(createdate,1,7)
            order by hospitalfk, hcsystemfk, substring(createdate,1,7) desc
             """)

leads_mrn2 = leads_mrn.join(leadsNotinLSB_m, (leads_mrn.hospitalfk == leadsNotinLSB_m.hospitalfk) & (leads_clusteredacct.Month == leadsNotinLSB_m.Month)) \
                            .select(leads_mrn["*"],leadsNotinLSB_m["MRN_NotInLSB"]) \
                            .withColumn("MRN_InLSB", f.col('MRN') - f.col('MRN_NotInLSB')) \
                            .withColumn("MRN% Leads in LSB",  (f.col('MRN_InLSB')/f.col('pa_received')*100).cast(DecimalType(4,2))) \
                            .orderBy(["Month","hospitalfk"])

leads_mrn2.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp + "/leadsByID_createdate/")

# COMMAND ----------

#move the data from temp path to actual path
leadsByID_temp_path = write_baseurl + hdfs_output_temp + "/leadsByID_createdate/"
leadsByID_output_path = write_baseurl + hdfs_output+ "/leadsByID_createdate/"
fileNames = dbutils.fs.ls(leadsByID_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(leadsByID_temp_path + name, leadsByID_output_path + '/leadsByID_createdate_count.csv')

# COMMAND ----------

# DBTITLE 1,Total leads in LSB on all ids
# Matching accounts on gmrnid
pag2 = pag.withColumn('id', concat(lit('G_'), pag.globalmrnifk)).drop('globalmrnifk')
pa_gmrn_leads = pag2.join(lsb_g, (pag2.id == lsb_g.identity))

# Matching accounts on permid
pap2 = pap.withColumn('id', concat(lit('P_'), pap.permid)).drop('permid')
pa_perm_leads = pap2.join(lsb_p, (pap2.id == lsb_p.identity))

# Matching accounts on ssn
pas3 = pas2.withColumn('id', concat(lit('S_'), pas2.ssn))
pa_ssn_leads = pas3.join(lsb_s, (pas3.id == lsb_s.identity))

# Matching accounts on clusteredacctid
pac3 = pac2.withColumn('id', concat(lit('CH_'), pac2.hospitalfk, lit('_'), paxhosp2.clusteredacctfk))
pa_clstract_leads = pac3.join(lsb_c, (pac3.id == lsb_c.identity))

# Matching accounts on mrn
pam3 = pam2.withColumn('id', concat(lit('MH_'), pam2.hospitalfk, lit('_'), paxhosp2.medicalrecnum))
pa_mrn_leads = pam3.join(lsb_m, (pam3.id == lsb_m.identity))

# COMMAND ----------

paids = pa_gmrn_leads.union(pa_perm_leads).union(pa_ssn_leads).union(pa_clstract_leads).union(pa_mrn_leads)

paids1=paids.select('hospitalfk','hcsystemfk','patientacctipk','createdate').dropDuplicates()

paids1.createOrReplaceTempView('paids1')
allIds_leads=spark.sql("""select hospitalfk, hcsystemfk, substring(createdate,1,7) as Month, count(*) as all_leads_in_LSB from paids1
            group by  hospitalfk, hcsystemfk, substring(createdate,1,7)
            order by  hospitalfk, hcsystemfk, substring(createdate,1,7) desc
             """)

allIds_leads = pa_reveived.join(allIds_leads, (pa_reveived.hospitalfk == allIds_leads.hospitalfk) & (pa_reveived.Month == allIds_leads.Month)) \
                          .select(pa_reveived["*"],allIds_leads["all_leads_in_LSB"]) \
                          .withColumn("leadsInLSB%", (f.col('all_leads_in_LSB')/f.col('pa_received')*100).cast(DecimalType(4,2)))

# COMMAND ----------

# DBTITLE 1,Get the generated leads counts
pxl_df = spark.read.format("delta").load(paxl_path)
pxlxhosp = pxl_df.join(hosp, (pxl_df.hospitalfk == hosp.hospitalpk)).select("patientacctifk", "hospitalfk", "hcsystemfk", "breadcrumb","edidatasourcefk","edidatasourcetablekey","lsb_coverageid","lsb_edipartnerfk") 
pxlxhosp1 = pxlxhosp.filter((pxlxhosp.hospitalfk.isin(hosp_arr)) | ((pxlxhosp.hcsystemfk.isin(hcsystem_arr))))

#leads generated or sent leads
# leads_gen=pxlxhosp1.join(paxhosp2, (pxlxhosp1.patientacctifk == paxhosp2.patientacctipk)).select(pxlxhosp1["*"], paxhosp2.createdate)

leads_gen = pxlxhosp1.join(
    paxhosp2,
    (pxlxhosp1.patientacctifk == paxhosp2.patientacctipk) & (pxlxhosp1.hospitalfk == paxhosp2.hospitalfk)
).select(pxlxhosp1["*"], paxhosp2.createdate)

leads_gen.createOrReplaceTempView('leads_gen')

leads_gen=spark.sql("""select hospitalfk, hcsystemfk, substring(createdate,1,7) as Month, count(*) leads_gen from leads_gen 
            group by hospitalfk, hcsystemfk, substring(createdate,1,7)
            order by hospitalfk, hcsystemfk, substring(createdate,1,7) desc
             """)

leads_gen_df = allIds_leads.join(leads_gen, (allIds_leads.hospitalfk == leads_gen.hospitalfk) & (allIds_leads.Month == leads_gen.Month)) \
                          .select(allIds_leads["*"],leads_gen["leads_gen"])

# COMMAND ----------

# DBTITLE 1,Get the generated unique leads counts
#unique sent leads
# leads_gen_unique=pxlxhosp1.join(paxhosp2, (pxlxhosp1.patientacctifk == paxhosp2.patientacctipk))
leads_gen_unique=pxlxhosp1.join(paxhosp2, (pxlxhosp1.patientacctifk == paxhosp2.patientacctipk) & (pxlxhosp1.hospitalfk == paxhosp2.hospitalfk))

leads_gen_unique1 = leads_gen_unique.select(pxlxhosp1.hospitalfk, pxlxhosp1.hcsystemfk, pxlxhosp1.patientacctifk, paxhosp2.createdate).distinct()
leads_gen_unique1.createOrReplaceTempView('leads_gen_unique1')

leads_gen_unique2=spark.sql("""select hospitalfk, hcsystemfk, substring(createdate,1,7) as Month, count(*) leads_gen_unique from leads_gen_unique1 
            group by hospitalfk, hcsystemfk, substring(createdate,1,7)
            order by hospitalfk, hcsystemfk, substring(createdate,1,7) desc
             """)

leads_gen_unique_df = leads_gen_df.join(leads_gen_unique2, (leads_gen_df.hospitalfk == leads_gen.hospitalfk) & (leads_gen_df.Month == leads_gen_unique2.Month)) \
                          .select(leads_gen_df["*"],leads_gen_unique2["leads_gen_unique"])\
                          .withColumn("leads_gen_unique%", (f.col('leads_gen_unique')/f.col('pa_received')*100).cast(DecimalType(4,2)))


# COMMAND ----------

# #leads not generated
# leads_not_gen=paxhosp2.join(pxlxhosp1, (paxhosp2.patientacctipk == pxlxhosp1.patientacctifk),  'leftanti')

# leads_not_gen.createOrReplaceTempView('leads_not_gen')

# leads_not_gen=spark.sql("""select hospitalfk, hcsystemfk, substring(createdate,1,7) as Month, count(*) pa_leads_not_gen from leads_not_gen 
#             group by hospitalfk, hcsystemfk, substring(createdate,1,7)
#             order by hospitalfk, hcsystemfk, substring(createdate,1,7) desc
#              """)

# # leads_not_gen.show(500,False)

# leads_not_gen = leads_gen.join(leads_not_gen, (leads_gen.hospitalfk == leads_not_gen.hospitalfk) & (leads_gen.Month == leads_not_gen.Month)) \
#                           .select(leads_gen["*"],leads_not_gen["pa_leads_not_gen"]) \
#                           .withColumn("pa_generated", f.col('pa_received') - f.col('pa_leads_not_gen')) \
#                           .withColumn("pa_generated%", (f.col('pa_generated')/f.col('pa_received')*100) .cast(DecimalType(4,2)))

# # display(leads_not_gen)

# COMMAND ----------

# DBTITLE 1,EDI Queries for FC counts
ediqueries = spark.read.format("delta").load(dataingestion_publish_path + "/ediqueries/current/20991231/")
ediqueries=ediqueries.selectExpr("hospitalfk", "patientacctifk","policyid as edi_coverageid","edipartnerfk","ediquerypk","trn","edi270querycomboifk")
ediqueries.createOrReplaceTempView("ediqueries")
ediqueries=spark.sql(""" SELECT * FROM ediqueries WHERE edi_coverageid IS NOT NULL """).dropDuplicates()
ediqueries.createOrReplaceTempView("ediqueries")

ediqueryhitsandmisses = spark.read.format("delta").load(dataingestion_publish_path + "/ediqueryhitsandmisses/current/20991231/")
ediqueryhitsandmisses=ediqueryhitsandmisses.selectExpr("ediqueryfk", "edipartnerfk","hospitalfk","result","edi270querycomboifk").dropDuplicates()
ediqueryhitsandmisses.createOrReplaceTempView("ediqueryhitsandmisses")
ediqueryhitsandmisses=spark.sql(""" SELECT * FROM ediqueryhitsandmisses WHERE trim(result) <> 'EB:V' """)
ediqueryhitsandmisses.createOrReplaceTempView("ediqueryhitsandmisses")
ediqueryhitsandmisses=spark.sql(""" SELECT *,CASE WHEN ediqueryhitsandmisses.result LIKE '%EB%' THEN 'Y' ELSE 'N' END AS isEdiQueryHit FROM ediqueryhitsandmisses """)
ediqueryhitsandmisses=ediqueryhitsandmisses.filter("isEdiQueryHit=='Y'")
ediqueryhitsandmisses.createOrReplaceTempView("ediqueryhitsandmisses")

# ediqueryhitsandmisses1=spark.sql(""" SELECT *,CASE WHEN ediqueryhitsandmisses.result LIKE '%EB:1%' THEN 'Y' ELSE 'N' END AS isEdiQueryHit1 FROM ediqueryhitsandmisses """)
ediqueryhitsandmisses1=spark.sql(""" SELECT *,CASE WHEN ediqueryhitsandmisses.result LIKE '%EB:1%' OR ediqueryhitsandmisses.result LIKE '%EB:2%' OR ediqueryhitsandmisses.result LIKE '%EB:3%' OR ediqueryhitsandmisses.result LIKE '%EB:4%' OR ediqueryhitsandmisses.result LIKE '%EB:5%' THEN 'Y' ELSE 'N' END AS isEdiQueryHit1 FROM ediqueryhitsandmisses """)
ediqueryhitsandmisses1=ediqueryhitsandmisses1.filter("isEdiQueryHit1=='Y'")
ediqueryhitsandmisses1.createOrReplaceTempView("ediqueryhitsandmisses1")


ediqueries_ediqueryhitsandmisses1=spark.sql("""
SELECT 
       ediqueries.hospitalfk,
       ediqueries.patientacctifk,
       ediqueries.edipartnerfk,
       ediqueries.edi_coverageid,
       ediqueryhitsandmisses1.isEdiQueryHit
FROM ediqueries 
  INNER JOIN ediqueryhitsandmisses1
          ON ediqueries.edi270querycomboifk = ediqueryhitsandmisses1.edi270querycomboifk
         AND ediqueries.ediquerypk = ediqueryhitsandmisses1.ediqueryfk
""").dropDuplicates()

# COMMAND ----------

egsd = spark.read.format('delta').load(dataingestion_publish_path+"/ediglobalsourceddata/current/20991231/")
egsd.createOrReplaceTempView("egsd")

# COMMAND ----------

join_df1 = pxlxhosp1.join(ediqueries, (ediqueries.patientacctifk == pxlxhosp1.patientacctifk) &
                                  (ediqueries.hospitalfk == pxlxhosp1.hospitalfk) & 
                                  (ediqueries.edipartnerfk == pxlxhosp1.lsb_edipartnerfk)
                                  ).select(pxlxhosp1["*"], ediqueries.ediquerypk, ediqueries.trn, ediqueries.edi270querycomboifk)

#verified hits
join_df2 = join_df1.join(ediqueryhitsandmisses, (join_df1.edi270querycomboifk == ediqueryhitsandmisses.edi270querycomboifk) &
                                                        (join_df1.ediquerypk == ediqueryhitsandmisses.ediqueryfk)
                                                        ).drop(ediqueryhitsandmisses.hospitalfk, ediqueryhitsandmisses.ediqueryfk, ediqueryhitsandmisses.edipartnerfk,"result",ediqueryhitsandmisses.isEdiQueryHit).dropDuplicates()
#join with ediglobaldatasource - verified hits
ediglobal=join_df2.join(egsd,(join_df2.hospitalfk == egsd.HospitalFK)&
                                   (join_df2.trn == egsd.TRN)&
                                   (join_df2.lsb_edipartnerfk == egsd.EDIPartnerFK)&
                                   (join_df2.patientacctifk == egsd.PatientAcctIFK)&
                                   (join_df2.edidatasourcefk == egsd.EDIDataSourceFK)).select(join_df2.hospitalfk,join_df2.patientacctifk,"lsb_edipartnerfk","lsb_coverageid",join_df2.edidatasourcefk).dropDuplicates()


#active hits
join_df3 = ediqueries_ediqueryhitsandmisses1.join(ediglobal, (ediglobal.patientacctifk == ediqueries_ediqueryhitsandmisses1.patientacctifk) & 
                              (ediglobal.hospitalfk == ediqueries_ediqueryhitsandmisses1.hospitalfk) &
                              (ediglobal.lsb_coverageid == ediqueries_ediqueryhitsandmisses1.edi_coverageid) &
                              (ediglobal.lsb_edipartnerfk == ediqueries_ediqueryhitsandmisses1.edipartnerfk), 
                           how='inner').drop(ediqueries_ediqueryhitsandmisses1.hospitalfk,ediqueries_ediqueryhitsandmisses1.patientacctifk, ediqueries_ediqueryhitsandmisses1.edi_coverageid, ediqueries_ediqueryhitsandmisses1.edipartnerfk)

# COMMAND ----------

def transform_coverageid(dffinal):
    dffinal = dffinal.withColumn("coverageid",when((dffinal.coverageid.contains(dffinal.groupnumber))& (dffinal.groupnumber != '') \
                      ,substring_index(dffinal.coverageid,'-',1)).otherwise(dffinal.coverageid))
    return dffinal

fc = spark.read.format('delta').load(dataingestion_publish_path+"/foundcoverage/current/20991231/")#4831838552
fc = fc.filter("hitstatus == 1")
fc = transform_coverageid(fc)

pa_fc = paxhosp2.join(fc, (paxhosp2.patientacctipk == fc.patientacctifk) & (paxhosp2.hospitalfk == fc.hospitalfk)).select("patientacctipk","hcsystemfk",paxhosp2.createdate,paxhosp2.hospitalfk,"coverageid","edipartnerfk").dropDuplicates()

# COMMAND ----------

# DBTITLE 1,FC Verified hits counts
fc_verified_hits = pa_fc.join(ediglobal, (pa_fc.patientacctipk == ediglobal.patientacctifk) &
                              (pa_fc.hospitalfk == ediglobal.hospitalfk) &
                              (pa_fc.coverageid == ediglobal.lsb_coverageid) & 
                              (pa_fc.edipartnerfk == ediglobal.lsb_edipartnerfk)).select("patientacctipk",pa_fc.hcsystemfk,"createdate",ediglobal.hospitalfk,"coverageid","edipartnerfk").dropDuplicates()

fc_verified_hits.createOrReplaceTempView('fc_verified_hits')
pa_in_FC=spark.sql("""select hospitalfk, hcsystemfk, substring(createdate,1,7) as Month, count(*) as fc_verified_hits  from fc_verified_hits 
            group by hospitalfk, hcsystemfk, substring(createdate,1,7)
            order by hospitalfk, hcsystemfk, substring(createdate,1,7) desc
             """)

fc_verified_accounts = leads_gen_unique_df.join(pa_in_FC, (leads_gen_unique_df.hospitalfk == pa_in_FC.hospitalfk) & (leads_gen_unique_df.Month == pa_in_FC.Month)) \
                          .select(leads_gen_unique_df["*"],pa_in_FC["fc_verified_hits"]) 

# COMMAND ----------

# DBTITLE 1,FC Active hits counts
fc_active_hits = pa_fc.join(join_df3, (pa_fc.patientacctipk == join_df3.patientacctifk) & 
                              (pa_fc.hospitalfk == ediglobal.hospitalfk) &
                              (pa_fc.coverageid == join_df3.lsb_coverageid) & 
                              (pa_fc.edipartnerfk == join_df3.lsb_edipartnerfk)).select("patientacctipk",pa_fc.hcsystemfk,"createdate",join_df3.hospitalfk,"coverageid","edipartnerfk").dropDuplicates()

fc_active_hits.createOrReplaceTempView('fc_active_hits')
pa_in_FC2=spark.sql("""select hospitalfk, hcsystemfk, substring(createdate,1,7) as Month, count(*) as fc_active_hits  from fc_active_hits 
            group by hospitalfk, hcsystemfk, substring(createdate,1,7)
            order by hospitalfk, hcsystemfk, substring(createdate,1,7) desc
             """)

fc_active_accounts = fc_verified_accounts.join(pa_in_FC2, (fc_verified_accounts.hospitalfk == pa_in_FC2.hospitalfk) & (fc_verified_accounts.Month == pa_in_FC2.Month)) \
                          .select(fc_verified_accounts["*"],pa_in_FC2["fc_active_hits"]) 


# COMMAND ----------

fc_active_accounts.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp + "/all_leads_createdate/")

# COMMAND ----------

# DBTITLE 1,Get CHC Leads counts
# # pxl_chc = spark.read.format("delta").load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/leaddiscovery/publish/patientacctxlead/").filter(col("breadcrumb").contains("CH"))

# pxl_chc = pxlxhosp.filter(col("breadcrumb").contains("CH"))

# #total leads for for chc for those pa 
# pa_chc=paxhosp2.join(pxl_chc, (paxhosp2.patientacctipk == pxl_chc.patientacctifk) & (paxhosp2.hospitalfk == pxl_chc.hospitalfk), "left").select(paxhosp2.hospitalfk, paxhosp2.hcsystemfk, paxhosp2.createdate, pxl_chc.edidatasourcetablekey)

# pa_chc.createOrReplaceTempView('pa_chc')
# pa_chc=spark.sql("""select hospitalfk, hcsystemfk, substring(createdate,1,7) as Month, count(edidatasourcetablekey) as chc_leads  from pa_chc 
#             group by hospitalfk, hcsystemfk, substring(createdate,1,7)
#             order by hospitalfk, hcsystemfk, substring(createdate,1,7) desc
#              """)

# # display(pa_chc)

# #pa not genderated for chc
# pa_not_gen_chc=paxhosp2.join(pxl_chc, (paxhosp2.patientacctipk == pxl_chc.patientacctifk) & (paxhosp2.hospitalfk == pxl_chc.hospitalfk),  'leftanti')

# pa_not_gen_chc.createOrReplaceTempView('pa_not_gen_chc')

# pa_not_gen_chc=spark.sql("""select hospitalfk, hcsystemfk, substring(createdate,1,7) as Month, count(*) pa_not_gen_chc from pa_not_gen_chc 
#             group by hospitalfk, hcsystemfk, substring(createdate,1,7)
#             order by hospitalfk, hcsystemfk, substring(createdate,1,7) desc
#              """)

# # display(pa_not_gen_chc)

# pa_chc_final = fc_accounts.join(pa_not_gen_chc, (fc_accounts.hospitalfk == pa_not_gen_chc.hospitalfk) & (fc_accounts.Month == pa_not_gen_chc.Month)) \
#                           .select(fc_accounts["*"],pa_not_gen_chc["pa_not_gen_chc"]) \
#                           .withColumn("pa_gen_chc", f.col('pa_received') - f.col('pa_not_gen_chc')) \
#                           .withColumn("pa_gen_others", (f.col('pa_generated') - f.col('pa_gen_chc'))) \
#                           .sort("hospitalfk", "Month", ascending=[False, True]) 


# # display(pa_chc_final)
# pa_chc_final.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp + "/all_leads_createdate/")

# COMMAND ----------

#move the data from temp path to actual path
all_leads_temp_path = write_baseurl + hdfs_output_temp + "/all_leads_createdate/"
all_leads_output_path = write_baseurl + hdfs_output+ "/all_leads_createdate/"
fileNames = dbutils.fs.ls(all_leads_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(all_leads_temp_path + name, all_leads_output_path + '/all_leads_createdate_count.csv')

# COMMAND ----------

vendorknownohi_path=dataingestion_publish_path+'vendorknownohicoverages/current/20991231'
print("vendorknownohi_path="+str(vendorknownohi_path))

vndr_knwn_ohi = spark.read.format("delta").load(vendorknownohi_path)

# vko1 = vndr_knwn_ohi.filter((vndr_knwn_ohi.hospitalfk.isin(hosp_arr)) & (vndr_knwn_ohi.createdate.between('2023-01-01', '2099-12-31')))
vko1 = vndr_knwn_ohi.filter(vndr_knwn_ohi.createdate.between('2023-01-01', '2099-12-31'))

# vko1.createOrReplaceTempView('vko1')
# pxlxhosp1.createOrReplaceTempView('pxlxhosp1')


# COMMAND ----------

paxl_vko=vko1.join(pxlxhosp1, (vko1.patientacctifk == pxlxhosp1.patientacctifk) & 
                   (vko1.hospitalfk == pxlxhosp1.hospitalfk) & 
                   (vko1.subscriberpolicynumber == pxlxhosp1.lsb_coverageid) & 
                   (vko1.edipartnerfk == pxlxhosp1.lsb_edipartnerfk),  'inner').select(pxlxhosp1.hospitalfk, pxlxhosp1.hcsystemfk, pxlxhosp1.patientacctifk, vko1.createdate, vko1.subscriberpolicynumber, pxlxhosp1.lsb_coverageid)

paxl_vko.createOrReplaceTempView('paxl_vko')

#Get the counts of the VendorKnownOhi leads counts generated per month
VendorKnownOhi =spark.sql("""select hospitalfk, hcsystemfk, substring(createdate,1,7) as Month, count(*) as vndr_knwn_ohi_counts from paxl_vko
            group by hospitalfk, hcsystemfk, substring(createdate,1,7)
            order by hospitalfk, hcsystemfk, substring(createdate,1,7) desc
             """)

# COMMAND ----------

VendorKnownOhi.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp + "/VendorKnownOhi/")

#move the data from temp path to actual path
VendorKnownOhi_temp_path = write_baseurl + hdfs_output_temp + "/VendorKnownOhi/"
VendorKnownOhi_output_path = write_baseurl + hdfs_output+ "/VendorKnownOhi/"
fileNames = dbutils.fs.ls(VendorKnownOhi_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(VendorKnownOhi_temp_path + name, VendorKnownOhi_output_path + '/VendorKnownOhi_count.csv')

# COMMAND ----------


