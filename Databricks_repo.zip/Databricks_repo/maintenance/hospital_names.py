# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
import datetime
import getpass
import os
import sys
import subprocess
import pyspark.sql.functions as f

# COMMAND ----------

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("write_container","")
dbutils.widgets.getArgument("write_container")
write_container= getArgument("write_container")

dbutils.widgets.text("write_storageaccount","")
dbutils.widgets.getArgument("write_storageaccount")
write_storageaccount= getArgument("write_storageaccount")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("hdfs_output","")
dbutils.widgets.getArgument("hdfs_output")
hdfs_output= getArgument("hdfs_output")

dbutils.widgets.text("hdfs_output_temp","")
dbutils.widgets.getArgument("hdfs_output_temp")
hdfs_output_temp= getArgument("hdfs_output_temp")

# COMMAND ----------

#read storage acct
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

#write storage acct
spark.conf.set("fs.azure.account.key."+write_storageaccount+".blob.core.windows.net","IEfzxj47CMO5j8WXNcugYeiCG5Ip/pypR+apR+/eQUOUxA9wapX8oK6rIdn+K87Dvyezcix8wcSK+AStM0qxww==")

# COMMAND ----------


#read base url
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 


#write base url
if user == 'na': #defualt value
    # wasbs://icdleadsreports@prodicdst.blob.core.windows.net/
    write_baseurl ='wasbs://'+write_container+'@'+write_storageaccount+'.blob.core.windows.net'
else:
    write_baseurl ='wasbs://'+write_container+'@'+write_storageaccount+'.blob.core.windows.net/'+user 

# COMMAND ----------

spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)

# COMMAND ----------

dataingestion_publish_path = baseurl+'/data/dataingestion/publish/'
hosp_path=dataingestion_publish_path+'hospitals/current/20991231'

print("hosp_path="+str(hosp_path))

# COMMAND ----------

hosp = spark.read.parquet(hosp_path).select('hospitalpk', 'hospitalname')

hosp.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp + "/hospital_names")
# leads_mrn2.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp + "/leadsByID_referraldate/")
# display(hosp)

# COMMAND ----------

# DBTITLE 1,Match mrn based leads not in LSB
#move the data from temp path to actual path
hosp_temp_path = write_baseurl + hdfs_output_temp + "/hospital_names/"
hosp_output_path = write_baseurl + hdfs_output+ "/hospital_names/"
fileNames = dbutils.fs.ls(hosp_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(hosp_temp_path + name, hosp_output_path + '/hospitals.csv')

# COMMAND ----------

