# Databricks notebook source
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql import Row,column
import datetime
from pyspark.sql import *
from pyspark.sql import functions as F
from pyspark.sql.readwriter import *
import os
import subprocess

# COMMAND ----------

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("hdfs_output","")
dbutils.widgets.getArgument("hdfs_output")
hdfs_output= getArgument("hdfs_output")

dbutils.widgets.text("hdfs_output_temp","")
dbutils.widgets.getArgument("hdfs_output_temp")
hdfs_output_temp= getArgument("hdfs_output_temp")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)

# COMMAND ----------

# edipartner = spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/dataingestion/publish/edipartners/current/20991231/*")
# edipartner.createOrReplaceTempView("edipartner")
# df=spark.sql("""select edipartnerpk, partnername, partnerabbr, IsEnabledFlag , UpdateNote,CreateDate, edipayerfk from edipartner where partnername like '%FIRST%'""")
# df.show(100,False)

# COMMAND ----------

# paccts = "abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/dataingestion/publish/patientaccts/current/20991231/"
# patientaccts = spark.read.format('delta').load(paccts)
# patientaccts.printSchema()

# COMMAND ----------

paccts = "abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/dataingestion/publish/patientaccts/current/20991231/"
patientaccts = spark.read.format('delta').load(paccts)
patientaccts.createOrReplaceTempView("patientaccts")
 
globalmrnxpacct=spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/gmrn/publish/globalmrnxpacct/current/*")
globalmrnxpacct.createOrReplaceTempView("globalmrnxpacct")
 
out=spark.sql(""" SELECT  to_date(patientaccts.createdate,'yyyy-MM-dd') as createdt, patientaccts.patientacctipk,patientaccts.hospitalfk
FROM patientaccts
  LEFT JOIN globalmrnxpacct
         ON patientaccts.hospitalfk = globalmrnxpacct.hospitalfk
        AND patientaccts.patientacctipk = globalmrnxpacct.patientacctifk
WHERE globalmrnxpacct.globalmrnifk IS NULL and patientaccts.createdate like "2023-1%" and patientaccts.totalcharges is not Null """)

# COMMAND ----------

out.repartition(1).write.mode('overwrite').parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/apundir/gmrn_missing/")
df=spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/apundir/gmrn_missing/*")
df.show()
df.createOrReplaceTempView("df")
output= spark.sql("""SELECT createdt, count(*) from df group by createdt Having count(*) > 0 order by createdt  DESC """)

# COMMAND ----------

output.show(100,False)

# COMMAND ----------

out.show(100, False)

# COMMAND ----------

gm=spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/gmrn/publish/globalmrnxpacct/current/*")
a= gm.filter(gm.patientacctifk == "3747083789").filter(gm.hospitalfk == "3335")
a.show(2,False)

# COMMAND ----------

gm=spark.read.format('csv').options(delimiter='\x01').load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/gmrn/staging/sqoop-data/globalmrn/*")
a= gm.filter(gm._c3 == "3747083789")
a.show(2,False)