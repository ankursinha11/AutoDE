# Databricks notebook source
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql import Row,column
import datetime
from pyspark.sql import *
from pyspark.sql import functions as F
from pyspark.sql.readwriter import *
import os
import subprocess

# COMMAND ----------

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("write_container","")
dbutils.widgets.getArgument("write_container")
write_container= getArgument("write_container")

dbutils.widgets.text("write_storageaccount","")
dbutils.widgets.getArgument("write_storageaccount")
write_storageaccount= getArgument("write_storageaccount")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("hdfs_output","")
dbutils.widgets.getArgument("hdfs_output")
hdfs_output= getArgument("hdfs_output")

dbutils.widgets.text("hdfs_output_temp","")
dbutils.widgets.getArgument("hdfs_output_temp")
hdfs_output_temp= getArgument("hdfs_output_temp")

# COMMAND ----------

#read storage acct
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

#write storage acct
spark.conf.set("fs.azure.account.key."+write_storageaccount+".blob.core.windows.net","IEfzxj47CMO5j8WXNcugYeiCG5Ip/pypR+apR+/eQUOUxA9wapX8oK6rIdn+K87Dvyezcix8wcSK+AStM0qxww==")

# COMMAND ----------


#read base url
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 


#write base url
if user == 'na': #defualt value
    # wasbs://icdleadsreports@prodicdst.blob.core.windows.net/
    write_baseurl ='wasbs://'+write_container+'@'+write_storageaccount+'.blob.core.windows.net'
else:
    write_baseurl ='wasbs://'+write_container+'@'+write_storageaccount+'.blob.core.windows.net/'+user 

# COMMAND ----------

spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)

# COMMAND ----------

# DBTITLE 1,Read patientacctxlead
hdfs_leads_sent = "abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/leaddiscovery/publish/patientacctxlead/"
# df = spark.read.parquet(hdfs_leads_sent)
df = spark.read.format("delta").load(hdfs_leads_sent)
df.createOrReplaceTempView("pax")

# COMMAND ----------

# DBTITLE 1,Get GMRN ASSIGN Leads Counts
gmrn_assign= spark.sql(""" Select pax.breadcrumb, count(*) as cnt from pax 
                       where (pax.breadcrumb not like "%-FC" and pax.breadcrumb not like "%-ES" and pax.breadcrumb not like "%-IX" and pax.breadcrumb not like "%-GM" and pax.breadcrumb not like "%-KC" and pax.breadcrumb not like "%-LV" and pax.breadcrumb not like "%-MA" and pax.breadcrumb not like "%-MC" and pax.breadcrumb not like "%-CH" ) and to_date(Substr(pax.breadcrumb, 1, 8), 'yyyyMMdd') >= date_sub(CURRENT_DATE() , 120) 
                       group by breadcrumb having count(*) > 1 order by breadcrumb desc """)

gmrn_assign.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp + "/gmrn_assign/")

#move the data from temp path to actual path
gmrn_assign_temp_path = write_baseurl + hdfs_output_temp + "/gmrn_assign/"
gmrn_assign_output_path = write_baseurl + hdfs_output+ "/gmrn_assign/"
fileNames = dbutils.fs.ls(gmrn_assign_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(gmrn_assign_temp_path + name, gmrn_assign_output_path + '/gmrn_assign_leads_count.csv')

# COMMAND ----------

# DBTITLE 1,Get ES Leads Counts
es = spark.sql(""" Select pax.breadcrumb, count(*) as cnt from pax 
               where pax.breadcrumb like "%-ES" and to_date(Substr(pax.breadcrumb, 1, 8), 'yyyyMMdd') >= date_sub(CURRENT_DATE() , 120) 
               group by breadcrumb having count(*) > 1 order by breadcrumb desc  """)

es.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp + "/es/")

#move the data from temp path to actual path
es_temp_path = write_baseurl + hdfs_output_temp + "/es/"
es_output_path = write_baseurl + hdfs_output+ "/es/"
fileNames = dbutils.fs.ls(es_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(es_temp_path + name, es_output_path + '/es_leads_count.csv')

# COMMAND ----------

# DBTITLE 1,Get FC Leads Counts
fc= spark.sql(""" Select pax.breadcrumb, count(*) as cnt from pax 
              where pax.breadcrumb like "%-FC" and to_date(Substr(pax.breadcrumb, 1, 8), 'yyyyMMdd') >= date_sub(CURRENT_DATE() , 120) 
              group by breadcrumb having count(*) > 1 order by breadcrumb desc  """)
              
fc.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp + "/fc/")

#move the data from temp path to actual path
fc_temp_path = write_baseurl + hdfs_output_temp + "/fc/"
fc_output_path = write_baseurl + hdfs_output+ "/fc/"
fileNames = dbutils.fs.ls(fc_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(fc_temp_path + name, fc_output_path + '/fc_leads_count.csv')

# COMMAND ----------

# DBTITLE 1,Get GMRN Leads Count
gm= spark.sql(""" Select pax.breadcrumb, count(*) as cnt from pax 
              where pax.breadcrumb like "%-GM" and to_date(Substr(pax.breadcrumb, 1, 8), 'yyyyMMdd') >= date_sub(CURRENT_DATE() , 120   ) 
              group by breadcrumb having count(*) > 1 order by breadcrumb desc  """)

gm.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp + "/gm/")

#move the data from temp path to actual path
gm_temp_path = write_baseurl + hdfs_output_temp + "/gm/"
gm_output_path = write_baseurl + hdfs_output+ "/gm/"
fileNames = dbutils.fs.ls(gm_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(gm_temp_path + name, gm_output_path + '/gm_leads_count.csv')

# COMMAND ----------

# DBTITLE 1,Get ICH Leads Count
ix= spark.sql(""" Select pax.breadcrumb, count(*) as cnt from pax 
              where pax.breadcrumb like "%-IX" and to_date(Substr(pax.breadcrumb, 1, 8), 'yyyyMMdd') >= date_sub(CURRENT_DATE() , 120) 
              group by breadcrumb having count(*) > 1 order by breadcrumb desc  """)

ix.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp + "/ix/")

#move the data from temp path to actual path
ix_temp_path = write_baseurl + hdfs_output_temp + "/ix/"
ix_output_path = write_baseurl + hdfs_output+ "/ix/"
fileNames = dbutils.fs.ls(ix_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(ix_temp_path + name, ix_output_path + '/ix_leads_count.csv')

# COMMAND ----------

# DBTITLE 1,Get Medicare leads counts
mc= spark.sql(""" Select pax.breadcrumb, count(*) as cnt from pax 
              where pax.breadcrumb like "%-MC" and to_date(Substr(pax.breadcrumb, 1, 8), 'yyyyMMdd') >= date_sub(CURRENT_DATE() , 365) 
              group by breadcrumb having count(*) > 1 order by breadcrumb desc  """)
              
mc.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp + "/mc/")

#move the data from temp path to actual path
mc_temp_path = write_baseurl + hdfs_output_temp + "/mc/"
mc_output_path = write_baseurl + hdfs_output+ "/mc/"
fileNames = dbutils.fs.ls(mc_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(mc_temp_path + name, mc_output_path + '/mc_leads_count.csv')

# COMMAND ----------

# DBTITLE 1,Medicaid leads counts
ma= spark.sql(""" Select pax.breadcrumb, count(*) as cnt from pax 
              where pax.breadcrumb like "%-MA" and to_date(Substr(pax.breadcrumb, 1, 8), 'yyyyMMdd') >= date_sub(CURRENT_DATE() , 365) 
              group by breadcrumb having count(*) > 1 order by breadcrumb desc  """)
              
ma.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp + "/ma/")

#move the data from temp path to actual path
ma_temp_path = write_baseurl + hdfs_output_temp + "/ma/"
ma_output_path = write_baseurl + hdfs_output+ "/ma/"
fileNames = dbutils.fs.ls(ma_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(ma_temp_path + name, ma_output_path + '/ma_leads_count.csv')

# COMMAND ----------

# dbutils.fs.ls("wasbs://icdleadsreports@prodicdst.blob.core.windows.net/dashboard_run/leads_sent/")

# COMMAND ----------

# print(write_baseurl + hdfs_output)

# COMMAND ----------

# DBTITLE 1,ICH Audit Report

hdfs_ich = "abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/audit/ieprebdf/missing_trace/*/*"
df = spark.read.parquet(hdfs_ich)
# df.display()
df.createOrReplaceTempView("ich")
ich= spark.sql(""" Select ich.breadcrumb, count(*) as cnt from ich 
                       group by breadcrumb having count(*) > 1 order by breadcrumb desc """)
# ich.display()
ich.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp + "/ich/")

ich_temp_path = write_baseurl + hdfs_output_temp + "/ich/"
ich_output_path = write_baseurl + hdfs_output+ "/ich/"
fileNames = dbutils.fs.ls(ich_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(ich_temp_path + name, ich_output_path + '/ich_leads_count.csv')

hdfs_ich_db = "abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/audit/ieprebdf/missing_trace_numbers_count/*/*"
df_db = spark.read.parquet(hdfs_ich_db).select('breadcrumb','databasename','count')
# df_db.display()
df_db.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp+ "/ich_db/")

ich_db_temp_path = write_baseurl + hdfs_output_temp + "/ich_db/"
ich_db_output_path = write_baseurl + hdfs_output+ "/ich_db/"
fileNames = dbutils.fs.ls(ich_db_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(ich_db_temp_path + name, ich_db_output_path + '/ich_db_leads_count.csv')


hdfs_ich_buc = "abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/audit/ieprebdf/missing_bucket_count/*/*"
df_buc = spark.read.parquet(hdfs_ich_buc).select('breadcrumb','bucket','count')
# df_buc.display()
df_buc.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp + "/ich_buc/")

ich_buc_temp_path = write_baseurl + hdfs_output_temp + "/ich_buc/"
ich_buc_output_path = write_baseurl + hdfs_output+ "/ich_buc/"
fileNames = dbutils.fs.ls(ich_buc_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(ich_buc_temp_path + name, ich_buc_output_path + '/ich_buc_leads_count.csv')

# COMMAND ----------

# DBTITLE 1,Get Lead Verify Leads Count
lv= spark.sql(""" Select pax.breadcrumb, count(*) as cnt from pax 
              where pax.breadcrumb like "%-LV" and to_date(Substr(pax.breadcrumb, 1, 8), 'yyyyMMdd') >= date_sub(CURRENT_DATE() , 120) 
              group by breadcrumb having count(*) > 1 order by breadcrumb desc  """)

lv.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp + "/lv/")

#move the data from temp path to actual path
lv_temp_path = write_baseurl + hdfs_output_temp + "/lv/"
lv_output_path = write_baseurl + hdfs_output+ "/lv/"
fileNames = dbutils.fs.ls(lv_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(lv_temp_path + name, lv_output_path + '/lv_leads_count.csv')

# COMMAND ----------

# DBTITLE 1,Get KC Leads Count
kc= spark.sql(""" Select pax.breadcrumb, count(*) as cnt from pax 
              where pax.breadcrumb like "%-KC" and to_date(Substr(pax.breadcrumb, 1, 8), 'yyyyMMdd') >= date_sub(CURRENT_DATE() , 120) 
              group by breadcrumb having count(*) > 1 order by breadcrumb desc  """)
              
kc.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp + "/kc/")

#move the data from temp path to actual path
kc_temp_path = write_baseurl + hdfs_output_temp + "/kc/"
kc_output_path = write_baseurl + hdfs_output+ "/kc/"
fileNames = dbutils.fs.ls(kc_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(kc_temp_path + name, kc_output_path + '/kc_leads_count.csv')

# COMMAND ----------

# DBTITLE 1,Get PA Ingested Data - Recon - Do not use
#Recon has two days data - change it to pa using trigger update date
# data=spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/dataingestion/staging/input/patientaccts/*RECON/").withColumn("filename", input_file_name())
# data=data.selectExpr("PatientAcctPK","HospitalFK","IsDeleted","filename as bc")
# data.createOrReplaceTempView("data")
# data=spark.sql(""" SELECT PatientAcctPK,HospitalFK,IsDeleted, regexp_replace(SPLIT(SPLIT(bc,'patientaccts')[1],'_')[0],'/','') AS bc from data""")
# data.createOrReplaceTempView("data")
# result=spark.sql(""" SELECT bc,IsDeleted,count(*) AS row_count FROM data GROUP BY bc,IsDeleted ORDER BY bc DESC """)
# result.repartition(1).write.format('csv').mode('overwrite').save(baseurl + hdfs_output_temp + "/patientaccts_ingested/")

# res = spark.sql("""Select to_date(Substr(paccts.trgupdatedate, 1, 8), 'yyyyMMdd') as trgupdatedate, count(*) as cnt
#                from paccts 
#                where to_date(Substr(paccts.trgupdatedate, 1, 8), 'yyyyMMdd') <= date_sub(CURRENT_DATE() , 120) 
#                group by to_date(Substr(paccts.trgupdatedate, 1, 8), 'yyyyMMdd') 
#                order by trgupdatedate desc  """)
# res.show(100,False)

# COMMAND ----------

# DBTITLE 1,Get PA Ingested Counts
paccts=spark.read.format('delta').load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/dataingestion/publish/patientaccts/current/20991231/")
paccts=paccts.selectExpr("PatientAcctIPK","HospitalFK","trgupdatedate","updatedate")
paccts.createOrReplaceTempView("paccts")
# paccts.show(10,False)

paccts_res = spark.sql("""Select CAST(paccts.trgupdatedate AS DATE), count(*) as cnt
               from paccts 
               where CAST(paccts.trgupdatedate AS DATE) >= date_sub(CURRENT_DATE() , 120) 
               group by CAST(paccts.trgupdatedate AS DATE)
               order by CAST(paccts.trgupdatedate AS DATE) desc  """)

# paccts_res = spark.sql("""Select CAST(paccts.trgupdatedate AS DATE), count(*) as cnt
#                from paccts 
#                where CAST(paccts.trgupdatedate AS DATE) >= '2022-01-01' 
#                group by CAST(paccts.trgupdatedate AS DATE)
#                order by CAST(paccts.trgupdatedate AS DATE) desc  """)

# paccts_res.show(20,False)
paccts_res.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp + "/patientaccts_ingested/")

#move the data from temp path to actual path
paccts_temp_path = write_baseurl + hdfs_output_temp + "/patientaccts_ingested/"
paccts_output_path = write_baseurl + hdfs_output+ "/patientaccts_ingested/"
fileNames = dbutils.fs.ls(paccts_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(paccts_temp_path + name, paccts_output_path + '/patientaccts_ingested_count.csv')

# COMMAND ----------

# DBTITLE 1,Get FC Ingested Data - Recon - Do not use
# #change from RECON to FC table using the update date column
# data=spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/dataingestion/staging/input/foundcoverage/*RECON/").withColumn("filename", input_file_name())
# data=data.selectExpr("FoundCoverageipk","HospitalFK","IsDeleted","filename as bc")
# data.createOrReplaceTempView("data")
# data=spark.sql(""" SELECT FoundCoverageipk,HospitalFK,IsDeleted, regexp_replace(SPLIT(SPLIT(bc,'foundcoverage')[1],'_')[0],'/','') AS bc from data""")
# data.createOrReplaceTempView("data")
# result=spark.sql(""" SELECT bc,IsDeleted,count(*) AS row_count FROM data GROUP BY bc,IsDeleted ORDER BY bc DESC """)

# result.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp + "/foundcoverage_ingested/")

# fcIngest_temp_path = write_baseurl + hdfs_output_temp + "/foundcoverage_ingested/"
# fcIngest_output_path = write_baseurl + hdfs_output+ "/foundcoverage_ingested/"
# fileNames = dbutils.fs.ls(fcIngest_temp_path)
# name = ''
# for filename in fileNames:
#     if filename.name.endswith('.csv'):
#         name=filename.name

# dbutils.fs.cp(fcIngest_temp_path + name, fcIngest_output_path + '/foundcoverage_ingested_count.csv')

# COMMAND ----------

# DBTITLE 1,MBI Helper - Schema
mbi_schema=StructType([StructField('patientacctpk', StringType(), True),
                    StructField('patientacctifk', StringType(), True),
                    StructField('hospitalfk', IntegerType(), True),
                    StructField('admitdate', StringType(), True), 
                    StructField('dischargedate', StringType(), True), 
                    StructField('firstname', StringType(), True), 
                    StructField('middlename', StringType(), True), 
                    StructField('lastname', StringType(), True), 
                    StructField('dob', StringType(), True), 
                    StructField('ssn', StringType(), True), 
                    StructField('gender', StringType(), True), 
                    StructField('state', StringType(), True), 
                    StructField('clusteredacctfk', StringType(), True), 
                    StructField('demographicschecksum', StringType(), True), 
                    StructField('demographicsupdatedate', StringType(), True), 
                    StructField('coverageid', StringType(), True), 
                    StructField('edipartnerfk', IntegerType(), True), 
                    StructField('repodate', StringType(), True), 
                    StructField('lastgenerateddate', StringType(), True), 
                    StructField('edisourcedateforpasscomparison', StringType(), True)])

# COMMAND ----------

# DBTITLE 1,Get MBI Helper Leads
mbi = spark.read.format('csv').options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="\x01").schema(mbi_schema).load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/coveragehelpers/publish/mbihelperaccounts/*").withColumn("filename", input_file_name())

mbi=mbi.selectExpr("patientacctifk","HospitalFK","filename as bc")
mbi.createOrReplaceTempView("mbi")

mbi=spark.sql(""" SELECT patientacctifk,HospitalFK, SPLIT(SPLIT(bc,'mbihelperaccounts')[1],'/')[1] as bc from mbi""")
mbi.createOrReplaceTempView("mbi")

result=spark.sql(""" SELECT bc,count(*) AS row_count FROM mbi GROUP BY bc ORDER BY bc DESC """)
result.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp + "/mbihelperaccount/")

#move the data from temp path to actual path
mbihelper_temp_path = write_baseurl + hdfs_output_temp + "/mbihelperaccount/"
mbihelper_output_path = write_baseurl + hdfs_output+ "/mbihelperaccount/"
fileNames = dbutils.fs.ls(mbihelper_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(mbihelper_temp_path + name, mbihelper_output_path + '/mbihelper_count.csv')

# COMMAND ----------

lsb= spark.read.format("delta").load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/leadservicebase/publish/served/leadservicebase/").selectExpr("_id","lsbupdatedate","lsbcreatedate")

lsb.createOrReplaceTempView("lsb")

lsb_create=spark.sql(""" SELECT Substr(lsb.lsbcreatedate, 1, 10) as lsb_createdate , count(*) AS row_count from lsb where Substr(lsb.lsbcreatedate, 1, 10)  >= date_sub(CURRENT_DATE() , 120) GROUP BY lsbcreatedate  """)

lsb_create.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp + "/lsbbycreatedate/")

lsb_update=spark.sql(""" SELECT Substr(lsb.lsbupdatedate, 1, 10) as lsb_updatedate, count(*) AS row_count from lsb where Substr(lsb.lsbupdatedate, 1, 10) >= date_sub(CURRENT_DATE() , 120) GROUP BY lsbupdatedate """)

lsb_update.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp + "/lsbbyupdatedate/")

# COMMAND ----------

lsb_create_temp_path = write_baseurl + hdfs_output_temp + "/lsbbycreatedate/"
lsb_create_output_path = write_baseurl + hdfs_output+ "/lsbbycreatedate/"
fileNames = dbutils.fs.ls(lsb_create_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(lsb_create_temp_path + name, lsb_create_output_path + '/lsbbycreatedate.csv')

# COMMAND ----------

lsb_update_temp_path = write_baseurl + hdfs_output_temp + "/lsbbyupdatedate/"
lsb_update_output_path = write_baseurl + hdfs_output+ "/lsbbyupdatedate/"
fileNames = dbutils.fs.ls(lsb_update_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(lsb_update_temp_path + name, lsb_update_output_path + '/lsbbyupdatedate.csv')

# COMMAND ----------

gmrn_xref= spark.read.format('delta').load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/leadrepo/publish/cooked/lr_xref_gmrnid_transaction/")
gmrn_xref.createOrReplaceTempView("gmrn_xref")
gmrn_xref=spark.sql(""" SELECT Substr(gmrn_xref.lr_createdate, 1, 10) as createdate, count(*) AS row_count from gmrn_xref where Substr(gmrn_xref.lr_createdate, 1, 10)  >= date_sub(CURRENT_DATE() , 120) GROUP BY lr_createdate """)
gmrn_xref.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp + "/gmrn_xref/")

# COMMAND ----------

gmrn_xref_temp_path = write_baseurl + hdfs_output_temp + "/gmrn_xref/"
gmrn_xref_output_path = write_baseurl + hdfs_output+ "/gmrn_xref/"
fileNames = dbutils.fs.ls(gmrn_xref_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(gmrn_xref_temp_path + name, gmrn_xref_output_path + '/gmrn_xref.csv')

# COMMAND ----------

permid_xref= spark.read.format('delta').load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/leadrepo/publish/cooked/lr_xref_permid_transaction/")
permid_xref.createOrReplaceTempView("permid_xref")
permid_xref=spark.sql(""" SELECT Substr(permid_xref.lr_createdate, 1, 10) as createdate, count(*) AS row_count from permid_xref  where Substr(permid_xref.lr_createdate, 1, 10)  >= date_sub(CURRENT_DATE() , 120) GROUP BY lr_createdate """)
permid_xref.show(20,False)
permid_xref.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp + "/permid_xref/")

# COMMAND ----------

permid_xref_temp_path = write_baseurl + hdfs_output_temp + "/permid_xref/"
permid_xref_output_path = write_baseurl + hdfs_output+ "/permid_xref/"
fileNames = dbutils.fs.ls(permid_xref_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(permid_xref_temp_path + name, permid_xref_output_path + '/permid_xref.csv')

# COMMAND ----------

fc_xref= spark.read.format('delta').load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/leadrepo/publish/cooked/lr_xref_ssn_mrn_cluster_transaction/")
fc_xref.createOrReplaceTempView("fc_xref")
fc_xref=spark.sql(""" SELECT Substr(fc_xref.lr_createdate, 1, 10) as createdate, count(*) AS row_count from fc_xref where Substr(fc_xref.lr_createdate, 1, 10)  >= date_sub(CURRENT_DATE() , 120) GROUP BY lr_createdate """)
fc_xref.show(20,False)
fc_xref.repartition(1).write.format('csv').mode('overwrite').save(write_baseurl + hdfs_output_temp + "/fc_xref/")

# COMMAND ----------

fc_xref_temp_path = write_baseurl + hdfs_output_temp + "/fc_xref/"
fc_xref_output_path = write_baseurl + hdfs_output+ "/fc_xref/"
fileNames = dbutils.fs.ls(fc_xref_temp_path)
name = ''
for filename in fileNames:
    if filename.name.endswith('.csv'):
        name=filename.name

dbutils.fs.cp(fc_xref_temp_path + name, fc_xref_output_path + '/fc_xref.csv')

# COMMAND ----------

globalmrn= spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/gmrn/publish/globalmrn/current/*")
globalmrnxpacct= spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/gmrn/publish/globalmrnxpacct/current/*")
globalmrndemographics= spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/gmrn/publish/globalmrndemographics/current/*")
globalmrnxhospinsurancecodes= spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/gmrn/publish/globalmrnxhospinsurancecodes/current/*")

# globalmrn.show()

# COMMAND ----------


