# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
from pyspark.sql.functions import when, col, lit
from pyspark.sql.functions import regexp_replace

# COMMAND ----------

def lowercase_all_columns(data):
    for column in data.columns:
        new_column = column.lower()
        data = data.withColumnRenamed(column, new_column)
    return data

def path_exists(path):
    try:
        dbutils.fs.ls(path)
        return True
    except Exception:
        return False

# COMMAND ----------

def get_shard_server_list():
    """
    Retrieve a list of Nexus eScan server connection strings that are enabled and have the eScan feature enabled,
    excluding those associated with active hospitals. Adds 'serverscope' and 'serverkey' columns for downstream use.
    Returns a Spark DataFrame with only the 'servername', 'serverscope', and 'serverkey' columns in lowercase.
    """
    # query = (
    #     """
    #     SELECT s.ConnectionString AS servername
    #     FROM dbo.NexusServers AS s WITH (NOLOCK)
    #     INNER JOIN dbo.NexusConfig AS c WITH (NOLOCK)
    #         ON s.ServerId = c.ServerId AND c.EnableFlag = 1
    #     INNER JOIN dbo.NexusFeatures AS f WITH (NOLOCK)
    #         ON c.FeatureId = f.FeatureId AND f.EnableFlag = 1
    #     LEFT JOIN config.Hospitals AS h WITH (NOLOCK)
    #         ON c.ScopeValue = h.HospitalPK AND h.Active = 1
    #     WHERE s.EnableFlag = 1
    #       AND f.FeatureName COLLATE SQL_Latin1_General_CP1_CI_AS = 'eScan'
    #       AND h.HospitalPK IS NULL
    #     """
    # )
    query =(""" SELECT connectionstring as servername FROM dbo.vwnexuslookupdistinctibl""")
    nexus_conn_file = dbutils.secrets.get(scope="icd-insleads-dbwscope", key="icd-dbx-nexusdb-connection")
    jdbc_options = {"url": nexus_conn_file, "numPartitions": 1}
    data = (
        spark.read.format("jdbc")
        .options(**jdbc_options)
        .option("query", query)
        .load()
        .withColumn("serverscope", lit("icd-insleads-dbwscope"))
        .withColumn("serverkey", lit("icd-iblsql3-app-databricks-pwd"))
        .dropDuplicates(["servername", "serverscope", "serverkey"])
        .select("servername", "serverscope", "serverkey")
    )
    data = lowercase_all_columns(data)
    #HACK : mute others but iblsql3
    # data = data.filter(data.servername.startswith("iblsql3"))
    data = data.withColumn("servername", regexp_replace(col("servername"), "-stg", ""))
    return data

# COMMAND ----------

# shard=get_shard_server_list()
# display(shard)

# COMMAND ----------

def get_shard_data(shard, query, op_dir):
    """
    Mega Max Brutal Doc (Complexity: 2/5)

    Purpose:
        Extracts data from a list of SQL Server shards, writing results to a specified Parquet directory.
        Only shards with valid secret scopes and keys are processed. 
        Hardcoded connection string for 'iblsql3' servers is a hack and should be removed before deployment.

    Parameters:
        shard (DataFrame): Spark DataFrame with columns ['servername', 'serverscope', 'serverkey'].
        query (str): SQL query to execute on each shard.
        op_dir (str): Output directory path for Parquet files.

    Returns:
        bool: True if all eligible shards were processed and written successfully, False otherwise.

    Behavior:
        - Iterates over each shard row.
        - Skips shards with missing/invalid secret scope.
        - Retrieves JDBC connection string from Databricks secrets.
        - For 'iblsql3' servers, uses a hardcoded connection string (remove this hack, Mad Max!).
        - Reads data using the provided query and writes to Parquet in append mode.
        - Logs success/failure for each shard.
        - Returns True only if all eligible shards succeeded.
    Example:
        get_shard_data(shard_df, "SELECT * FROM mytable", "/mnt/output/parquet/")
    """
    shard_rows = shard.select("servername", "serverscope", "serverkey").collect()
    shard_count = len(shard_rows)
    write_count = 0
    for idx, row in enumerate(shard_rows):
        servername = row.servername
        serverscope = row.serverscope
        serverkey = row.serverkey
        print("servername:", servername)
        print("serverscope:", serverscope)
        print("serverkey:", serverkey)
        if not serverscope or str(serverscope).strip().lower() == 'none':
            print(f"[SKIP] No valid secret for server '{servername}' (row {idx})")
            continue
        try:
            leadgen_sqldb_pwd = dbutils.secrets.get(scope=serverscope, key=serverkey)
            path_conn_file = f"jdbc:sqlserver://{servername};user=app_databricks;password={leadgen_sqldb_pwd};trustServerCertificate=true"
            # if servername.startswith('iblsql3'):
            #     print(f"jdbc_options: {path_conn_file}")
            # else:
            #     print(f"[ERROR] Invalid server name '{servername}' (row {idx}). Exiting.")
            #     return False
            jdbc_options = {"url": path_conn_file, "numPartitions": 1}
            try:
                df = spark.read.format("jdbc").options(**jdbc_options).option("query", query).load()
                df = lowercase_all_columns(df)
                for column in df.columns:
                    df = df.withColumn(column, trim(col(column)))
                    df = df.withColumn(column, when(col(column).isNull(), None).otherwise(col(column)))
                    df = df.withColumn(column, when(col(column) == 'null', None).otherwise(col(column)))
                    df = df.withColumn(column, when(col(column) == '', None).otherwise(col(column)))
                    df = df.withColumn(column, when(col(column) == 'true', '1').when(col(column) == 'false', '0').otherwise(col(column)))
                print(f"read data from server '{servername}' (row {idx}). SUCCESS")
                df.write.mode("append").format("parquet").save(op_dir)
                print(f"write data from server '{servername}' (row {idx}). SUCCESS")
                write_count += 1
            except Exception as e:
                print(f"[ERROR] Failed to load or process data for server '{servername}' (row {idx}). Error: {str(e)}")
                continue
        except Exception as e:
            print(f"[ERROR] Failed to load data for server '{servername}' (row {idx}). Error: {str(e)}")
    return write_count == shard_count

# COMMAND ----------

def process_shard_data(table_name, query, output_path):
    if table_name == '' or table_name is None:
        print(f"NO : {table_name or 'table'}")
        return True
    print(f"YES : {table_name}")
    return get_shard_data(shard, query, output_path)

# COMMAND ----------

def process_extracted_table(out_flag, op_path, table_name, label):
    if out_flag is True and table_name and path_exists(op_path):
        df = spark.read.format("parquet").load(op_path)
        df = lowercase_all_columns(df)
        print(f"Count : {label} : {df.count():,}")
        df.createOrReplaceTempView(table_name)
        return df
    else:
        print(f"{label} table extraction failed or N/A")
        return None

# COMMAND ----------

def overWriteUcTables(tablename,user,data_df) :
    data_df = data_df.withColumn("bc", lit(bc))
    data_df = data_df.withColumn("bcupdated", lit(bc))
    if user == 'na':
        catalog_name = "prod_icd_leadgen_catalog"
    else :
        catalog_name = "prod_icd_stg_leadgen_catalog"
    print("catalog_name : "+str(catalog_name))
    publish_schema = 'dataingestion'
    publish_table = catalog_name + "." + publish_schema + "." + tablename
    print("publish_table : "+str(publish_table))
    # Ensure the schema of the DataFrame matches the schema of the target table
    target_schema = spark.table(publish_table).schema
    data_df = data_df.select(*[col for col in data_df.columns if col in target_schema.fieldNames()])
    # Cast columns to match the target schema
    for field in target_schema:
        if field.name in data_df.columns:
            data_df = data_df.withColumn(field.name, data_df[field.name].cast(field.dataType))
    data_df.write.mode("overwrite").saveAsTable(publish_table)
