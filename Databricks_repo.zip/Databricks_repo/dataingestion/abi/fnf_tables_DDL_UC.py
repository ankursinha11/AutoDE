# Databricks notebook source
# Databricks notebook source
dbutils.widgets.text("catalog_name","")
catalog_name=dbutils.widgets.get("catalog_name")

# COMMAND ----------

spark.sql(f"""CREATE TABLE IF NOT EXISTS {catalog_name}.dataingestion.NexusConfig
(
    configid int,
    featureid int,
    serverid int,
    scopeid int,
    scopevalue int,
    enableflag string,
    description string,
    createdate timestamp,
    createdby string
)
TBLPROPERTIES('vacuum'='72 hours')
""")

# COMMAND ----------

spark.sql(f"""CREATE TABLE IF NOT EXISTS {catalog_name}.dataingestion.NexusFeatures
(
    featureid int,
    featurename string,
    enableflag string,
    description string,
    createdate timestamp,
    createdby string,
    displayflag string
)
TBLPROPERTIES('vacuum'='72 hours')
""")

# COMMAND ----------

spark.sql(f"""CREATE TABLE IF NOT EXISTS {catalog_name}.dataingestion.NexusServers
(
    serverid int,
    servername string,
    connectionstring string,
    enableflag string,
    description string,
    createdate timestamp,
    createdby string,
    userkeyvault string,
    passkeyvault string,
    servertypeid int
)
TBLPROPERTIES('vacuum'='72 hours')
""")

# COMMAND ----------

spark.sql(f"""CREATE TABLE IF NOT EXISTS {catalog_name}.dataingestion.NexusScope
(
    scopeid int,
    scopename string,
    enableflag string,
    description string,
    createdate timestamp,
    createdby string,
    displayflag string
)
TBLPROPERTIES('vacuum'='72 hours')
""")
