# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window

# COMMAND ----------

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

# COMMAND ----------

# STAGE Parameters
# container= "prod-icd-stg-adls"
# storageaccount= "prodicdstgdls"
# user= "suhas"

# PROD Parameters
# container= "prod-icd-adls"
# storageaccount= "prodicddls"
# user= "na"

# COMMAND ----------

container = str(container)
storageaccount = str(storageaccount)
user = str(user)

if user == "na":
    username = ""
    print("username: "+"**PROD**")
else:
    username = user
    print("username: "+username)
    
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))
spark.conf.set("spark.sql.shuffle.partitions", "auto")

base_url = (f"abfss://{container}@{storageaccount}.dfs.core.windows.net/{username}/")
path_metadata = base_url + "/data/dataingestion/publish/" + "metadata" + "/current/20991231/"
print("base_url      : "+base_url)
print("path_metadata : "+path_metadata)

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/schema_util" 

# COMMAND ----------

schema = StructType(
    [
        StructField("table_loadtype", StringType(), True),
        StructField("table_threads", StringType(), True),
        StructField("table_shardtype", StringType(), True),
        StructField("table_primary", StringType(), True),
        StructField("table_primary_query", StringType(), True),
        StructField("table_secondary", StringType(), True),
        StructField("table_secondary_query", StringType(), True),
        StructField("table_tertiary", StringType(), True),
        StructField("table_tertiary_query", StringType(), True),
        StructField("table_view_upsert", StringType(), True),
        StructField("table_view_delete", StringType(), True),
    ]
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### # **GROUP : FNF : Tables : Definition**

# COMMAND ----------

# DBTITLE 1,FNF tables
patientacctsaccesscoordinator = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "Y",
    "table_primary"         : "patientacctsaccesscoordinator",
    "table_primary_query"   : "SELECT * FROM escan.dbo.patientacctsaccesscoordinator (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : "",
    "table_view_delete"     : "",
}

hospitalpurge = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "hospitalpurge",
    "table_primary_query"   : "SELECT * FROM nexus.config.hospitalpurge (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : "",
    "table_view_delete"     : "",
}

hospitals = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "hospitals",
    "table_primary_query"   : "SELECT * FROM nexus.config.hospitals (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : "",
    "table_view_delete"     : "",
}

hospitalprovidernums = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "Y",
    "table_primary"         : "hospitalprovidernums",
    "table_primary_query"   : "SELECT * FROM escan.dbo.hospitalprovidernums (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}

hospitalattributevalues = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "hospitalattributevalues",
    "table_primary_query"   : "SELECT * FROM nexus.config.hospitalattributevalues (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}


hospitalattributes = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "hospitalattributes",
    "table_primary_query"   : "SELECT * FROM nexus.config.hospitalattributes (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}

edipayers = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "edipayers",
    "table_primary_query"   : "SELECT * FROM nexus.config.edipayers (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}

edipartners = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "edipartners",
    "table_primary_query"   : "SELECT * FROM nexus.config.edipartners (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}

opsedipayershospitals = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "opsedipayershospitals",
    "table_primary_query"   : "SELECT * FROM nexus.config.opsedipayershospitals (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}


edipayeropsoutofregionconfig = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "edipayeropsoutofregionconfig",
    "table_primary_query"   : "SELECT * FROM nexus.config.edipayeropsoutofregionconfig (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}

edipayeropslottoconfig = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "edipayeropslottoconfig",
    "table_primary_query"   : "SELECT * FROM nexus.config.edipayeropslottoconfig (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}

edipayerzipcodelookup = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "edipayerzipcodelookup",
    "table_primary_query"   : "SELECT * FROM nexus.config.edipayerzipcodelookup (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}

edipayersxstateinsurancenames = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "edipayersxstateinsurancenames",
    "table_primary_query"   : "SELECT * FROM nexus.config.edipayersxstateinsurancenames (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}

hcsystems = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "hcsystems",
    "table_primary_query"   : "SELECT * FROM nexus.config.hcsystems (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}

edipayers_tupayeridmapping = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "edipayers_tupayeridmapping",
    "table_primary_query"   : "SELECT * FROM nexus.config.edipayers_tupayeridmapping (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}

edi270querycombos = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "edi270querycombos",
    "table_primary_query"   : "SELECT * FROM nexus.config.edi270querycombos (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}


edidatasources = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "edidatasources",
    "table_primary_query"   : "SELECT * FROM nexus.config.edidatasources (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}

edipartner270settings = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "edipartner270settings",
    "table_primary_query"   : "SELECT * FROM nexus.config.edipartner270settings (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}

edipartnerattributes = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "edipartnerattributes",
    "table_primary_query"   : "SELECT * FROM nexus.config.edipartnerattributes (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}

edipartnerattributevalues = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "edipartnerattributevalues",
    "table_primary_query"   : "SELECT * FROM nexus.config.edipartnerattributevalues (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}


edipartnerhospital270settingsoverrides = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "edipartnerhospital270settingsoverrides",
    "table_primary_query"   : "SELECT * FROM nexus.config.edipartnerhospital270settingsoverrides (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}


edipartnersubmittersoverrides = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "edipartnersubmittersoverrides",
    "table_primary_query"   : "SELECT * FROM nexus.config.edipartnersubmittersoverrides (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}

edipartnertype = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "Y",
    "table_primary"         : "edipartnertype",
    "table_primary_query"   : "SELECT * FROM escan.dbo.edipartnertype (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}

edisubmitters = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "edisubmitters",
    "table_primary_query"   : "SELECT * FROM nexus.config.edisubmitters (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}


edisubscriberdobresponse = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "Y",
    "table_primary"         : "edisubscriberdobresponse",
    "table_primary_query"   : "SELECT * FROM escan.dbo.edisubscriberdobresponse (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}

escanglobalparameters = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "escanglobalparameters",
    "table_primary_query"   : "SELECT * FROM nexus.config.escanglobalparameters (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}


foundcoverageinferredsourcemethodcodes = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "foundcoverageinferredsourcemethodcodes",
    "table_primary_query"   : "SELECT * FROM nexus.config.foundcoverageinferredsourcemethodcodes (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}

hospitalnpioverrides = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "Y",
    "table_primary"         : "hospitalnpioverrides",
    "table_primary_query"   : "SELECT * FROM escan.dbo.hospitalnpioverrides (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}

hospitalpayercob = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "hospitalpayercob",
    "table_primary_query"   : "SELECT * FROM nexus.config.hospitalpayercob (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}

partnerpolicyidblacklists = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "Y",
    "table_primary"         : "partnerpolicyidblacklists",
    "table_primary_query"   : "SELECT * FROM escan.dbo.partnerpolicyidblacklists (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}

zipcodes = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "zipcodes",
    "table_primary_query"   : "SELECT * FROM nexus.config.zipcodes (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}

hospphysicians = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "Y",
    "table_primary"         : "hospphysicians",
    "table_primary_query"   : "SELECT * FROM escan.dbo.hospphysicians (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}

edipartnershospitalbilldlrules = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "Y",
    "table_primary"         : "edipartnershospitalbilldlrules",
    "table_primary_query"   : "SELECT * FROM escan.dbo.edipartnershospitalbilldlrules (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}

#exceptions
edileadsourcetransition = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "edileadsourcetransition",
    "table_primary_query"   : "SELECT * FROM AbInitio.dbo.edileadsourcetransition (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}

hpdhospitalpartnerlastrespstatus = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "hpdhospitalpartnerlastrespstatus",
    "table_primary_query"   : "SELECT * FROM AbInitio.dbo.hpdhospitalpartnerlastrespstatus (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """""",
    "table_view_delete"     : """""",
}

patientmatchingblockallowgmrn = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "Y",
    "table_primary"         : "patientmatchingblockallowgmrn",
    "table_primary_query"   : "SELECT * FROM escan.dbo.patientmatchingblockallowgmrn (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : "",
    "table_view_delete"     : "",
}

dontreportdatafromlegalteam = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "Y",
    "table_primary"         : "dontreportdatafromlegalteam",
    "table_primary_query"   : "SELECT * FROM escan.dbo.dontreportdatafromlegalteam (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : "",
    "table_view_delete"     : "",
}

birthmonthrequeryhospitals = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "Y",
    "table_primary"         : "birthmonthrequeryhospitals",
    "table_primary_query"   : "SELECT * FROM Insights.dbo.birthmonthrequeryhospitals (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : "",
    "table_view_delete"     : "",
}

nexusconfig = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "nexusconfig",
    "table_primary_query"   : "SELECT * FROM dbo.nexusconfig (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : "",
    "table_view_delete"     : "",
}

nexusfeatures = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "nexusfeatures",
    "table_primary_query"   : "SELECT * FROM dbo.nexusfeatures (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : "",
    "table_view_delete"     : "",
}

nexusservers = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "nexusservers",
    "table_primary_query"   : "SELECT * FROM dbo.nexusservers (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : "",
    "table_view_delete"     : "",
}

nexusscope = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "nexusscope",
    "table_primary_query"   : "SELECT * FROM dbo.nexusscope (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : "",
    "table_view_delete"     : "",
}

bcbsprefixtopayermappings = {
    "table_loadtype"        : "fnf",
    "table_threads"         : "1",
    "table_shardtype"       : "N",
    "table_primary"         : "bcbsprefixtopayermappings",
    "table_primary_query"   : "SELECT * FROM escanrpts.dbo.bcbsprefixtopayermappings (NOLOCK)",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : "",
    "table_view_delete"     : "",
}

# COMMAND ----------

# MAGIC %md
# MAGIC ### # **GROUP : 01 : Tables : Definition**

# COMMAND ----------

# DBTITLE 1,GRP-1
foundcoverage = {
    "table_loadtype"        : "upsert",
    "table_threads"         : "15",
    "table_shardtype"       : "Y",
    "table_primary"         : "foundcoverage",
    "table_primary_query"   : "SELECT * FROM escan.dbo.foundcoverage (NOLOCK) WHERE UpdateDate >= ",
    "table_secondary"       : "foundcoveragehistory",
    "table_secondary_query" : "SELECT * FROM escan.dbo.foundcoveragehistory (NOLOCK) WHERE createdatetrigger >= ",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """SELECT f.foundcoveragepk, f.patientaccountfk, f.edipartnerfk, f.coverageid, f.firstname, f.middlename, f.lastname, f.gender, f.addr, f.city, f.state, f.zip, f.county, f.dob, f.ssn, f.firstfoundedimessagefk, f.lastfoundedimessagefk, f.edi270querycombofk, f.createdate, f.updatedate, f.hitstatus, f.hospitalfk, f.patientacctifk, f.foundcoverageipk, f.suffix, f.ediprocessmethodfk, f.foundcoveragesourcefk, f.inferredsourcefoundcoverageifk, f.currentinferredsourcemethodcode, f.inferredsourcemethodcode, f.usefordsh, f.clusteredacctfk, f.sufficientcoverageflag, f.groupnumber, f.pmscore, f.patientmatchingscorefk, f.pmscoredate, f.pmscore_2ndlevel, f.pmscoredate_2ndlevel, f.patientmatchingscore_2ndlevelfk, f.foundcoveragecurrentstandingfk, f.edi271dependantrelationshipcode, f.edipartnergroupinfofk, CAST(0 AS INT) isdeleted FROM hospitals h INNER JOIN foundcoverage f ON f.hospitalfk = h.hospitalpk""",
    "table_view_delete"     : """SELECT foundcoveragepk, patientaccountfk, edipartnerfk, coverageid, firstname, middlename, lastname, gender, addr, city, state, zip, county, dob, ssn, firstfoundedimessagefk, lastfoundedimessagefk, edi270querycombofk, createdate, createdatetrigger AS updatedate, hitstatus, hospitalfk, patientacctifk, foundcoverageipk, suffix, ediprocessmethodfk, foundcoveragesourcefk, inferredsourcefoundcoverageifk, currentinferredsourcemethodcode, inferredsourcemethodcode, usefordsh, clusteredacctfk, sufficientcoverageflag, groupnumber, pmscore, patientmatchingscorefk, pmscoredate, pmscore_2ndlevel, pmscoredate_2ndlevel, patientmatchingscore_2ndlevelfk, foundcoveragecurrentstandingfk, edi271dependantrelationshipcode, edipartnergroupinfofk, CAST(1 AS INT) isdeleted FROM foundcoveragehistory WHERE dmltype = 'D'""",
}

helperfoundcoverages = {
    "table_loadtype"        : "upsert",
    "table_threads"         : "15",
    "table_shardtype"       : "Y",
    "table_primary"         : "helperfoundcoverages",
    "table_primary_query"   : "SELECT * FROM escan.dbo.helperfoundcoverages (NOLOCK) WHERE UpdateDate >= ",
    "table_secondary"       : "helperfoundcoverageshistory",
    "table_secondary_query" : "SELECT * FROM escan.dbo.helperfoundcoverageshistory (NOLOCK) WHERE createdatetrigger >= ",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : "select helperfoundcoverageipk, hospitalfk, patientacctifk, edipayerfk, coverageid, firstname, middlename, lastname, suffix, gender, addr, city, state, zip, county, dob, ssn, sufficienttorunhitstatus, inferredsourcemethodcode, inferredsourcehelperfoundcoverageifk, foundcoveragecurrentstandingfk, createdate, updatedate, edidatasourcefk, charlotte271datafk, sourcefoundcoverageifk, sourcefoundcoveragehospitalfk, charlotte271familydatafk, charlotte271gmrndatafk, clientid, tu_escan_sourcepolicyinforawrefid, CAST(0 AS INT) isdeleted from helperfoundcoverages",
    "table_view_delete"     : "SELECT helperfoundcoverageipk, hospitalfk, patientacctifk, edipayerfk, coverageid, firstname, middlename, lastname, suffix, gender, addr, city, state, zip, county, dob, ssn, sufficienttorunhitstatus, inferredsourcemethodcode, inferredsourcehelperfoundcoverageifk, foundcoveragecurrentstandingfk, createdate, createdatetrigger AS updatedate, edidatasourcefk, charlotte271datafk, sourcefoundcoverageifk, sourcefoundcoveragehospitalfk, charlotte271familydatafk, charlotte271gmrndatafk, clientid, tu_escan_sourcepolicyinforawrefid, CAST(1 AS INT) isdeleted FROM helperfoundcoverageshistory WHERE dmltype = 'D'",
}

vsnappatientacctsflags = {
    "table_loadtype"        : "upsert",
    "table_threads"         : "15",
    "table_shardtype"       : "Y",
    "table_primary"         : "vsnappatientacctsflags",
    "table_primary_query"   : """SELECT * FROM escandm.dbo.vsnappatientacctsflags (NOLOCK) WHERE CreateDate >= """,
    "table_secondary"       : "vsnappatientacctsflagshistory",
    "table_secondary_query" : "SELECT * FROM escandm.dbo.vsnappatientacctsflagshistory (NOLOCK) WHERE createdatetrigger >= ",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : """SELECT vsnappatientacctsflagspk, hospitalfk, patientacctifk, patientacctscodesupdatedate, insurancecodeupdatedate, finclasscodeupdatedate, knownmcaidflag, pendingmcaidflag, primarymcaidflag, primarymcaid_charityflag, primarymcaid_baddebtflag, primarymcaid_arflag, secondarymcaidflag, secondarymcaid_afterworkcompflag, secondarymcaid_aftermcareflag, secondarymcaid_afterinsuranceflag, createdate, hasmedicareflag, acctlocatorcodeupdatedate, agencycodeupdatedate, outofstatemcaidflag, collectionagencycodeupdatedate, charitytransflag, paymentcodeupdatedate, hasrelatedpendingmcaidacct, baddebttransflag, mcaidtransflag, knowntricareflag, tricaretransflag, mcaretransflag, hasbillablerevcode, mcarecrossoverdate, billingindicatorcodeupdatedate, CAST(0 AS INT) isdeleted FROM vsnappatientacctsflags""",
    "table_view_delete"     : """SELECT vsnappatientacctsflagspk, hospitalfk, patientacctifk, patientacctscodesupdatedate, insurancecodeupdatedate, finclasscodeupdatedate, knownmcaidflag, pendingmcaidflag, primarymcaidflag, primarymcaid_charityflag, primarymcaid_baddebtflag, primarymcaid_arflag, secondarymcaidflag, secondarymcaid_afterworkcompflag, secondarymcaid_aftermcareflag, secondarymcaid_afterinsuranceflag, createdatetrigger AS createdate, hasmedicareflag, acctlocatorcodeupdatedate, agencycodeupdatedate, outofstatemcaidflag, collectionagencycodeupdatedate, charitytransflag, paymentcodeupdatedate, hasrelatedpendingmcaidacct, baddebttransflag, mcaidtransflag, knowntricareflag, tricaretransflag, mcaretransflag, hasbillablerevcode, mcarecrossoverdate, billingindicatorcodeupdatedate, CAST(1 AS INT) isdeleted FROM vsnappatientacctsflagshistory WHERE dmltype = 'D'""",
}

patientaccts = {
    "table_loadtype"        : "upsert",
    "table_threads"         : "15",
    "table_shardtype"       : "Y",
    "table_primary"         : "patientaccts",
    "table_primary_query"   : """SELECT * FROM escan.dbo.patientaccts (NOLOCK) WHERE TrgUpdateDate >= """,
    "table_secondary"       : "patientacctshistorybatch",
    "table_secondary_query" : "SELECT * FROM escan.dbo.patientacctshistorybatch (NOLOCK) WHERE CreateDate >= ",
    "table_tertiary"        : "patientacctshistoryinsertdeletes",
    # "table_tertiary_query"  : "SELECT * FROM escanArchHistory.dbo.patientacctshistoryinsertdeletes (NOLOCK) WHERE TrgUpdateDate >= """,
    "table_tertiary_query"  : "SELECT A.* FROM (SELECT * FROM escan.dbo.patientacctshistoryinsertdeletes (NOLOCK) UNION SELECT * FROM escanArchHistory.dbo.patientacctshistoryinsertdeletes (NOLOCK)) A WHERE A.CreateDate >= ",
    "table_view_upsert"     : """SELECT patientacctpk, hospitalfk, acctnum, admitdate, dischargedate, referraldate, firstname, lastname, middlename, suffix, addr1, addr2, CASE WHEN patientacctipk = 7132665 THEN 'LONGVIEW' ELSE city END AS city, state, zip, county, phone1, phone2, dob, ssn, gender, dod, medicalrecnum, medicaidnum, totalcharges, currentbalance, currentstatus, createdate, updatedate, statusdate, patientacctipk, clusteredacctfk, demographicschecksum, demographicsupdatedate, trgupdatedate, momsacctnum, updatepatientacctsimportfilepartfk, facilitycode, totalpayments, totaladjustments, medicarehic, hospitalfacilitycodefk, CAST(0 AS INT) isdeleted FROM patientaccts""",
    "table_view_delete"     : """SELECT patientacctpk, hospitalfk, acctnum, admitdate, dischargedate, referraldate, firstname, lastname, middlename, suffix, addr1, addr2, city, state, zip, county, phone1, phone2, dob, ssn, gender, dod, medicalrecnum, medicaidnum, totalcharges, currentbalance, currentstatus, pahid.createdate, pahb.createdate AS updatedate, statusdate, patientacctipk, clusteredacctfk, demographicschecksum, demographicsupdatedate, trgupdatedate, momsacctnum, updatepatientacctsimportfilepartfk, facilitycode, totalpayments, totaladjustments, medicarehic, hospitalfacilitycodefk, CAST(1 AS INT) isdeleted FROM patientacctshistoryinsertdeletes pahid JOIN patientacctshistorybatch pahb ON pahid.batchid = pahb.batchid WHERE pahid.dmltype = 'DB' UNION SELECT patientacctpk, hospitalfk, acctnum, admitdate, dischargedate, referraldate, firstname, lastname, middlename, suffix, addr1, addr2, city, state, zip, county, phone1, phone2, dob, ssn, gender, dod, medicalrecnum, medicaidnum, totalcharges, currentbalance, currentstatus, pahid1.createdate, pahb1.createdate AS updatedate, statusdate, patientacctipk, clusteredacctfk, demographicschecksum, demographicsupdatedate, trgupdatedate, momsacctnum, updatepatientacctsimportfilepartfk, facilitycode, totalpayments, totaladjustments, medicarehic, hospitalfacilitycodefk, CAST(1 AS INT) isdeleted FROM patientacctshistoryinsertdeletes pahid1 JOIN patientacctshistorybatch pahb1 ON pahid1.batchid = pahb1.batchid WHERE pahid1.dmltype = 'DB' """,
}

patientacctscodes = {
    "table_loadtype"        : "upsert",
    "table_threads"         : "15",
    "table_shardtype"       : "Y",
    "table_primary"         : "patientacctscodes",
    "table_primary_query"   : """SELECT * FROM escan.dbo.patientacctscodes (NOLOCK) WHERE TrgUpdateDate >= """,
    "table_secondary"       : "escan_patientacctscodeshistoryinsertdeletes",
    "table_secondary_query" : "SELECT * FROM escan.dbo.patientacctscodeshistoryinsertdeletes (NOLOCK) WHERE TrgUpdateDate >= ",
    "table_tertiary"        : "escanhist_patientacctscodeshistoryinsertdeletes",
    "table_tertiary_query"  : "SELECT * FROM escanarchhistory.dbo.patientacctscodeshistoryinsertdeletes (NOLOCK) WHERE TrgUpdateDate >= """,
    "table_view_upsert"     : """SELECT p.hospitalfk, p.patientacctifk, p.active, p.patientacctfk, p.ifccodefk, p.mcaid, p.mcaidpending, p.visittypefk, p.source, p.acctlocator, p.admitdiagnosis, p.admitsource, p.admittype, p.agency, p.dischargedesttype, '' AS dischargediagnosis, p.finclassreferred, p.finclasscurrent, p.insurancecode1, p.insurancecode2, p.insurancecode3, p.insurancecode4, p.maritalstatus, p.patienttype, p.primarydiagnosis, p.race, p.servicetype, p.collector, p.alien, p.baddebt, p.charity, p.createdate, p.updatedate, p.firstimportdate, p.lastimportdate, p.ifcdate, p.useractive, p.usermcaid, p.usermcaidpending, p.createpatientacctsimportfilepartfk, p.updatepatientacctsimportfilepartfk, p.primarycptcode, p.paidamt, p.paymentadjamt, p.trgupdatedate, p.hospsourcesystemname, p.diagnosiscode2, p.diagnosiscode3, p.diagnosiscode4, p.diagnosiscode5, p.diagnosiscode6, p.diagnosiscode7, p.diagnosiscode8, p.diagnosiscode9, p.diagnosiscode10, p.diagnosiscode11, p.diagnosiscode12, p.diagnosiscode13, p.diagnosiscode14, p.acctexclusionreasonfk, p.collectionagencycode, p.usermcare, p.usermcarecoversservice, p.insurancecode5, p.insurancecode6, p.insurancecode7, p.ins1policyid, p.ins2policyid, p.ins3policyid, p.ins4policyid, p.ins5policyid, p.ins6policyid, p.ins7policyid, p.attendingphynname, p.workingdrg, p.finaldrg, p.hospitalfacilitycodefk, CAST(0 AS INT) isdeleted FROM hospitals h INNER JOIN patientacctscodes p ON p.hospitalfk = h.hospitalpk""",
    "table_view_delete"     : """SELECT p.hospitalfk, p.patientacctifk, p.active, p.patientacctfk, p.ifccodefk, p.mcaid, p.mcaidpending, p.visittypefk, p.source, p.acctlocator, p.admitdiagnosis, p.admitsource, p.admittype, p.agency, p.dischargedesttype, '' AS dischargediagnosis, p.finclassreferred, p.finclasscurrent, p.insurancecode1, p.insurancecode2, p.insurancecode3, p.insurancecode4, p.maritalstatus, p.patienttype, p.primarydiagnosis, p.race, p.servicetype, p.collector, p.alien, p.baddebt, p.charity, p.createdate, p.trgupdatedate AS updatedate, p.firstimportdate, p.lastimportdate, p.ifcdate, p.useractive, p.usermcaid, p.usermcaidpending, p.createpatientacctsimportfilepartfk, p.updatepatientacctsimportfilepartfk, p.primarycptcode, p.paidamt, p.paymentadjamt, p.trgupdatedate, p.hospsourcesystemname, p.diagnosiscode2, p.diagnosiscode3, p.diagnosiscode4, p.diagnosiscode5, p.diagnosiscode6, p.diagnosiscode7, p.diagnosiscode8, p.diagnosiscode9, p.diagnosiscode10, p.diagnosiscode11, p.diagnosiscode12, p.diagnosiscode13, p.diagnosiscode14, p.acctexclusionreasonfk, p.collectionagencycode, p.usermcare, p.usermcarecoversservice, p.insurancecode5, p.insurancecode6, p.insurancecode7, p.ins1policyid, p.ins2policyid, p.ins3policyid, p.ins4policyid, p.ins5policyid, p.ins6policyid, p.ins7policyid, p.attendingphynname, p.workingdrg, p.finaldrg, p.hospitalfacilitycodefk, CAST(1 AS INT) isdeleted FROM hospitals h INNER JOIN escan_patientacctscodeshistoryinsertdeletes p ON p.hospitalfk = h.hospitalpk WHERE p.dmltype = 'DB' UNION SELECT p.hospitalfk, p.patientacctifk, p.active, p.patientacctfk, p.ifccodefk, p.mcaid, p.mcaidpending, p.visittypefk, p.source, p.acctlocator, p.admitdiagnosis, p.admitsource, p.admittype, p.agency, p.dischargedesttype, '' AS dischargediagnosis, p.finclassreferred, p.finclasscurrent, p.insurancecode1, p.insurancecode2, p.insurancecode3, p.insurancecode4, p.maritalstatus, p.patienttype, p.primarydiagnosis, p.race, p.servicetype, p.collector, p.alien, p.baddebt, p.charity, p.createdate, p.trgupdatedate AS updatedate, p.firstimportdate, p.lastimportdate, p.ifcdate, p.useractive, p.usermcaid, p.usermcaidpending, p.createpatientacctsimportfilepartfk, p.updatepatientacctsimportfilepartfk, p.primarycptcode, p.paidamt, p.paymentadjamt, p.trgupdatedate, p.hospsourcesystemname, p.diagnosiscode2, p.diagnosiscode3, p.diagnosiscode4, p.diagnosiscode5, p.diagnosiscode6, p.diagnosiscode7, p.diagnosiscode8, p.diagnosiscode9, p.diagnosiscode10, p.diagnosiscode11, p.diagnosiscode12, p.diagnosiscode13, p.diagnosiscode14, p.acctexclusionreasonfk, p.collectionagencycode, p.usermcare, p.usermcarecoversservice, p.insurancecode5, p.insurancecode6, p.insurancecode7, p.ins1policyid, p.ins2policyid, p.ins3policyid, p.ins4policyid, p.ins5policyid, p.ins6policyid, p.ins7policyid, p.attendingphynname, p.workingdrg, p.finaldrg, p.hospitalfacilitycodefk, CAST(1 AS INT) isdeleted FROM hospitals h INNER JOIN escanhist_patientacctscodeshistoryinsertdeletes p ON p.hospitalfk = h.hospitalpk WHERE p.dmltype = 'DB' """,
}

# COMMAND ----------

# MAGIC %md
# MAGIC ### # **GROUP : 02 : Tables : Definition**

# COMMAND ----------

# DBTITLE 1,GRP-2
edisubscriberdobsearch = {
    "table_loadtype"        : "upsert",
    "table_threads"         : "15",
    "table_shardtype"       : "Y",
    "table_primary"         : "edisubscriberdobsearch",
    "table_primary_query"   : "SELECT * FROM escan.dbo.edisubscriberdobsearch (NOLOCK) WHERE UpdateDate >= ",
    "table_secondary"       : "edisubscriberdobsearchhistory",
    "table_secondary_query" : "SELECT * FROM escan.dbo.edisubscriberdobsearchhistory (NOLOCK) WHERE createdatetrigger >= ",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : "SELECT edisubscriberdobsearchpk, hospitalfk, patientacctifk, foundcoverageifk, edipartnerfk, subscriberfirstname, subscriberlastname, subscribermiddlename, subscribersuffix, subscriberdob, subscriberssn, subscriberdoblookupfk, responsesubscriberdob, edisubscriberdobresponsefk, createdate, updatedate, processflag,coverageid,CAST(0 AS INT) isdeleted FROM edisubscriberdobsearch",
    "table_view_delete"     : "SELECT edisubscriberdobsearchpk, hospitalfk, patientacctifk, foundcoverageifk, edipartnerfk, subscriberfirstname, subscriberlastname, subscribermiddlename, subscribersuffix, subscriberdob, subscriberssn, subscriberdoblookupfk, responsesubscriberdob, edisubscriberdobresponsefk, createdate, createdatetrigger AS updatedate, '' AS processflag,'' AS coverageid,CAST(1 AS INT) isdeleted FROM edisubscriberdobsearchhistory WHERE dmltype = 'D'",
}


clusteredaccts = {
    "table_loadtype"        : "upsert",
    "table_threads"         : "15",
    "table_shardtype"       : "Y",
    "table_primary"         : "clusteredaccts",
    "table_primary_query"   : "SELECT * FROM escan.dbo.clusteredaccts (NOLOCK) WHERE UpdateDate >= ",
    "table_secondary"       : "clusteredacctshistory",
    "table_secondary_query" : "SELECT * FROM escan.dbo.clusteredacctshistory (NOLOCK) WHERE createdatetrigger >= ",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : "SELECT clusteredacctpk, hospitalfk, firstname, middlename, lastname, dob, ssn, demographicschecksum, createdate, updatedate, superclusteredacctfk, CAST(0 AS INT) isdeleted FROM clusteredaccts",
    "table_view_delete"     : "SELECT clusteredacctpk, hospitalfk, firstname, middlename, lastname, dob, ssn, demographicschecksum, createdate, createdatetrigger AS updatedate, superclusteredacctfk, CAST(1 AS INT) isdeleted FROM clusteredacctshistory WHERE dmltype = 'D' ",
}



patientacctspayercob = {
    "table_loadtype"        : "upsert",
    "table_threads"         : "15",
    "table_shardtype"       : "Y",
    "table_primary"         : "patientacctspayercob",
    "table_primary_query"   : "SELECT * FROM escan.dbo.patientacctspayercob (NOLOCK) WHERE UpdateDate >= ",
    "table_secondary"       : "patientacctspayercobhistory",
    "table_secondary_query" : "SELECT * FROM escan.dbo.patientacctspayercobhistory (NOLOCK) WHERE createdatetrigger >= ",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : "SELECT hospitalfk, patientacctifk, billingnpi, claimrecieveddate, memberid, subscribermemberid, createdate, updatedate, updatedby, createdby, billingnpiname, billingnpitaxid, groupnpi, groupnpiname, groupnpitaxid, policystartdate, policyenddate, policyendreasoncode, groupid, coveragetypecode, payertypecode, optbatchid, CAST(0 AS INT) AS isdeleted FROM patientacctspayercob",
    "table_view_delete"     : "SELECT hospitalfk, patientacctifk, billingnpi, claimrecieveddate, memberid, subscribermemberid, createdate, createdatetrigger AS updatedate, updatedby, createdby, billingnpiname, billingnpitaxid, groupnpi, groupnpiname, groupnpitaxid, policystartdate, policyenddate, policyendreasoncode, groupid, coveragetypecode, payertypecode, optbatchid, CAST(1 AS INT) AS isdeleted FROM patientacctspayercobhistory WHERE dmltype = 'D'",
}

patientacctsguarantors = {
    "table_loadtype"        : "upsert",
    "table_threads"         : "15",
    "table_shardtype"       : "Y",
    "table_primary"         : "patientacctsguarantors",
    "table_primary_query"   : "SELECT * FROM escan.dbo.patientacctsguarantors (NOLOCK) WHERE UpdateDate >= ",
    "table_secondary"       : "escan_patientacctsguarantorshistoryinsertdeletes",
    "table_secondary_query" : "SELECT * FROM escan.dbo.patientacctsguarantorshistoryinsertdeletes (NOLOCK) WHERE UpdateDate >= ",
    "table_tertiary"        : "escanarchhistory_patientacctsguarantorshistoryinsertdeletes",
    "table_tertiary_query"  : "SELECT * FROM escanarchhistory.dbo.patientacctsguarantorshistoryinsertdeletes (NOLOCK) WHERE UpdateDate >=",
    "table_view_upsert"     : "SELECT hospitalfk, patientacctifk, guarfirstname, guarlastname, guarmiddle, guaraddr1, guaraddr2, guaraddrcity, guaraddrstate, guaraddrzip, guaraddrcounty, guaraddrcountry, guarhomephone1, guarhomephone2, guardob, guarssn, guargendercode, guarrelationcode, createdate, updatedate, updatepatientacctsimportfilepartfk, guarempname, guarempstatuscode, guaremplastwork, guarempaddr1, guarempaddr2, guarempaddrcity, guarempaddrstate, guarempaddrzip, guarempphone1, guarempphone2, guarempnotes, guarantormedicalrecnum, guarantorurn, guarsuffix, CAST(0 AS INT) AS isdeleted FROM patientacctsguarantors ",
    "table_view_delete"     : "SELECT hospitalfk, patientacctifk, guarfirstname, guarlastname, guarmiddle, guaraddr1, guaraddr2, guaraddrcity, guaraddrstate, guaraddrzip, guaraddrcounty, guaraddrcountry, guarhomephone1, guarhomephone2, guardob, guarssn, guargendercode, guarrelationcode, createdate, updatedate, updatepatientacctsimportfilepartfk, guarempname, guarempstatuscode, guaremplastwork, guarempaddr1, guarempaddr2, guarempaddrcity, guarempaddrstate, guarempaddrzip, guarempphone1, guarempphone2, guarempnotes, guarantormedicalrecnum, guarantorurn, guarsuffix, CAST(1 AS INT) AS isdeleted FROM escan_patientacctsguarantorshistoryinsertdeletes WHERE dmltype = 'D' UNION SELECT hospitalfk, patientacctifk, guarfirstname, guarlastname, guarmiddle, guaraddr1, guaraddr2, guaraddrcity, guaraddrstate, guaraddrzip, guaraddrcounty, guaraddrcountry, guarhomephone1, guarhomephone2, guardob, guarssn, guargendercode, guarrelationcode, createdate, updatedate, updatepatientacctsimportfilepartfk, guarempname, guarempstatuscode, guaremplastwork, guarempaddr1, guarempaddr2, guarempaddrcity, guarempaddrstate, guarempaddrzip, guarempphone1, guarempphone2, guarempnotes, guarantormedicalrecnum, guarantorurn, guarsuffix, CAST(1 AS INT) isdeleted FROM escanarchhistory_patientacctsguarantorshistoryinsertdeletes WHERE dmltype = 'D' ",
}

patientaccteligibilitysubmittals = {
    "table_loadtype"        : "upsert",
    "table_threads"         : "15",
    "table_shardtype"       : "Y",
    "table_primary"         : "patientaccteligibilitysubmittals",
    "table_primary_query"   : "SELECT * FROM escan.dbo.patientaccteligibilitysubmittals (NOLOCK) WHERE UpdateDate >= ",
    "table_secondary"       : "patientaccteligibilitysubmittalshistory",
    "table_secondary_query" : "SELECT * FROM escan.dbo.patientaccteligibilitysubmittalshistory (NOLOCK) WHERE createdatetrigger >= ",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : "SELECT patientaccteligibilitysubmittalpk, hospitalfk, patientacctifk, foundcoverageifk, patientacctfk, foundcoveragefk, submitdate, submitauthor, reportfk, reporttypefk, medicaidpending, totalcharges, balance, finclass, primaryins, secondaryins, tertiaryins, reconcilesw, adddate, billdl, reportrequestfk, markednotsent, hold, holdupdatedate, reconcileswupdatedate, createdate, createby, updatedate, updateby, acctexclusionreasonfk, suppressdate, suppressby, acctexclreasonsource, hospacctexclusionreasonfk, hospacctexclusionreasonresolutiondate, rptsortorder, suppressforinvoicedate, suppressforinvoicereasonfk, reportmetasectionfk, exclusionassessmentfk, exclusionresolutiondate, exclusionresolutionby, revoked, revokeacctexclusionreasonfk, revokeacctexclusionby, exclusionresolutionnote, revokesuppressdate, updatereconqueuefk, revocationacknowledgmentdate, exclusionassessmentdate, exclusionassessmentby, eportalexclusionsyncdate, initialacceptancedate, initialacceptanceuserfk, codeddate, pacurrentbalance, CAST(0 AS INT) AS isdeleted FROM patientaccteligibilitysubmittals ",
    "table_view_delete"     : "SELECT patientaccteligibilitysubmittalpk, hospitalfk, patientacctifk, foundcoverageifk, patientacctfk, foundcoveragefk, submitdate, submitauthor, reportfk, reporttypefk, medicaidpending, totalcharges, balance, finclass, primaryins, secondaryins, tertiaryins, reconcilesw, adddate, billdl, reportrequestfk, markednotsent, hold, holdupdatedate, reconcileswupdatedate, createdate, createby, createdatetrigger AS updatedate, updateby, acctexclusionreasonfk, suppressdate, suppressby, acctexclreasonsource, hospacctexclusionreasonfk, hospacctexclusionreasonresolutiondate, rptsortorder, suppressforinvoicedate, suppressforinvoicereasonfk, reportmetasectionfk, exclusionassessmentfk, exclusionresolutiondate, exclusionresolutionby, revoked, revokeacctexclusionreasonfk, revokeacctexclusionby, exclusionresolutionnote, revokesuppressdate, updatereconqueuefk, revocationacknowledgmentdate, exclusionassessmentdate, exclusionassessmentby, eportalexclusionsyncdate, initialacceptancedate, initialacceptanceuserfk, codeddate, pacurrentbalance, CAST(1 AS INT) AS isdeleted FROM patientaccteligibilitysubmittalshistory WHERE dmltype = 'D' ",
}

patientacctstatestatus = {
    "table_loadtype"        : "upsert",
    "table_threads"         : "15",
    "table_shardtype"       : "Y",
    "table_primary"         : "patientacctstatestatus",
    "table_primary_query"   : "SELECT * FROM escan.dbo.patientacctstatestatus (NOLOCK) WHERE UpdateDate >= ",
    "table_secondary"       : "patientacctstatestatushistory",
    "table_secondary_query" : "SELECT * FROM escan.dbo.patientacctstatestatushistory (NOLOCK) WHERE createdatetrigger >= ",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : "SELECT patientacctstatestatuspk, patientacctfk, edipartnerfk, status, updatedate, createdate, hospitalfk, patientacctifk, lastedijobfk, demographicschecksum, demographicsupdatedate, clusteredstatus, clusteredstatusupdatedate, clusteredacctfk, lastgenerateddate, lastimporteddate, lastknownmcaidflag, lastimportededimessagefk, lastabietlstartdate, CAST(0 AS INT) AS isdeleted FROM patientacctstatestatus ",
    "table_view_delete"     : "SELECT patientacctstatestatuspk, patientacctfk, edipartnerfk, status, createdatetrigger AS updatedate, createdate, hospitalfk, patientacctifk, lastedijobfk, demographicschecksum, demographicsupdatedate, clusteredstatus, clusteredstatusupdatedate, clusteredacctfk, lastgenerateddate, lastimporteddate, lastknownmcaidflag, lastimportededimessagefk, lastabietlstartdate, CAST(1 AS INT) AS isdeleted FROM patientacctstatestatushistory WHERE dmltype = 'D' ",
}


vsnapglobalmrnfamilyhelperaccounts = {
    "table_loadtype"        : "upsert",
    "table_threads"         : "15",
    "table_shardtype"       : "Y",
    "table_primary"         : "vsnapglobalmrnfamilyhelperaccounts",
    "table_primary_query"   : "SELECT * FROM escandm.dbo.vsnapglobalmrnfamilyhelperaccounts (NOLOCK) WHERE UpdateDate >= ",
    "table_secondary"       : "vsnapglobalmrnfamilyhelperaccountshistory",
    "table_secondary_query" : "SELECT * FROM escandm.dbo.vsnapglobalmrnfamilyhelperaccountshistory (NOLOCK) WHERE createdatetrigger >= ",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : "SELECT vsnapglobalmrnfamilyhelperaccountspk, hospitalfk, patientacctifk, edipartnerfk, inspolicyid, createdate, updatedate, updatedby, CAST(0 AS INT) AS isdeleted FROM vsnapglobalmrnfamilyhelperaccounts",
    "table_view_delete"     : "SELECT vsnapglobalmrnfamilyhelperaccountspk, hospitalfk, patientacctifk, edipartnerfk, inspolicyid, createdate, createdatetrigger AS updatedate, updatedby, CAST(1 AS INT) AS isdeleted FROM vsnapglobalmrnfamilyhelperaccountshistory ",
}



reportwarehousemedicaideligiblepaes = {
    "table_loadtype"        : "upsert",
    "table_threads"         : "15",
    "table_shardtype"       : "Y",
    "table_primary"         : "reportwarehousemedicaideligiblepaes",
    "table_primary_query"   : "SELECT * FROM escanrpts.dbo.reportwarehousemedicaideligiblepaes (NOLOCK) WHERE RequestDate >= ",
    "table_secondary"       : "reportwarehousemedicaideligiblepaeshistory",
    "table_secondary_query" : "SELECT * FROM escanrpts.dbo.reportwarehousemedicaideligiblepaeshistory (NOLOCK) WHERE createdatetrigger >= ",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : "SELECT requestguid, requestdate, requestauthor, reportfk, reporttypefk, reportcumulative, patientacctifk, foundcoverageifk, uniqueval, foundcoveragepk, startdate, enddate, adddate, retrodate, programtype, spenddown, coveragecode, coveragecreatedate, coverageupdatedate, coverageid, mcaidlastname, mcaidfirstname, mcaidmiddlename, mcaidssn, mcaiddob, mcaidgender, coveragecodedesc, programtypedesc, spenddowncodedesc, patientacctpk, acctnum, medicaidnum, totalcharges, currentbalance, lastname, firstname, middlename, referraldate, ssn, dob, gender, admitdate, dischargedate, acctcreatedate, acctupdatedate, patienttypecode, admittypecode, servicetypecode, finclassreferred, finclasscurr, acctlocatorcode, agencycode, primaryins, secondaryins, tertiaryins, quaternaryins, collectstatuscode, servicetypedesc, finclasscurrdesc, mcaidpending, agencydesc, billdl, sortbilldl, mcaiddaystocert, mcaiddayscertd, hospitalfk, hospitalname, softwaresyscode, pendingholddays, mcaidstate, covlmtdaylimit, covlmtdaysused, covlmtdollarlimit, covlmtdollarsused, covlmtstartdate, covlmtenddate, notenote, notedesc, custom1, custom2, custom3, customn1, customn2, displayaspasttimely, hospitalpk, placementimportstatus, segmentsource, reportrequestfk, paidamt, paymentadjamt, addr1, addr2, city, state, zip, phone1, claimdate, selectedsegment, knownmcaid, addlcoverageinfo, acctpaid, prependednoteinfo, coverageinfo, inferredsourcefoundcoverageifk, medicalrecnum, inferredsourcemethod, medicaidcoverageifk, inferredsourcemedicaidcoverageifk, inferredsourcemethodmedicaid, managedcarecoveragedetailifk, inferredsourcemanagedcarecoveragedetailifk, inferredsourcemethodmanagedcare, medicarecoverageifk, inferredsourcemedicarecoverageifk, inferredsourcemethodmedicare, patientaccteligibilitysubmittalfk, mcaidholddays, billablesubmitdate, admittypecac, pendingmcaid, primarymcaid, secondarymcaid, ifc01_knownmcaid, ifc02_pendingmcaid, ifc03_primarymcaid, ifc04_primarymcaid_charity, ifc05_primarymcaid_baddebt, ifc06_primarymcaid_ar, ifc07_secondarymcaid, ifc08_secondarymcaid_afterworkcomp, ifc09_secondarymcaid_aftermcare, ifc10_secondarymcaid_afterinsurance, ifccodefk, dsh_eligible, unbillable, reportmetasectionfk, rptmetasectionordervalue, primarydiagnosis, finclassreferredhospfinclasscodefk, finclassreferredhospfinclasscodehistoryfk, finclasscurrhospfinclasscodefk, finclasscurrhospfinclasscodehistoryfk, primaryinshospinsurancecodefk, primaryinshospinsurancecodeshistoryfk, secondaryinshospinsurancecodefk, secondaryinshospinsurancecodeshistoryfk, tertiaryinshospinsurancecodefk, tertiaryinshospinsurancecodeshistoryfk, quaternaryinshospinsurancecodefk, quaternaryinshospinsurancecodeshistoryfk, edipartnerfk, rptsortorder, knownmcaidflag, pendingmcaidflag, primarymcaidflag, primarymcaid_charityflag, primarymcaid_baddebtflag, primarymcaid_arflag, secondarymcaidflag, secondarymcaid_afterworkcompflag, secondarymcaid_aftermcareflag, secondarymcaid_afterinsuranceflag, outofstatemcaidflag, charitytransflag, hasrelatedpendingmcaidacct, pcpfirstname, pcplastname, pcpmiddlename, pcpphonenum, admitdiagnosis, dischargediagnosis, lastimportdate, collectionagencycode, baddebttransflag, mcaidtransflag, totalpayments, totaladjustments, medicarehic, insurancecode5, insurancecode6, insurancecode7, ins1policyid, ins2policyid, ins3policyid, ins4policyid, ins5policyid, ins6policyid, ins7policyid, informationonly, zipdistance, segmentcreatedate, notenotekeyinfo, attendingphynname, suppressaxiomssn, hasmedicareflag, medicaremanagedcarecoverageifk, foundcoveragebenefitsnotes, knowntricareflag, tricaretransflag, mcaretransflag, facilitycode, facilitycodedescription, tprcoverageifk, inferredsourcemedicaremanagedcarecoverageifk, inferredsourcemethodmedicaremanagedcare, hasbillablerevcode, commercialcoverageifk, inferredsourcecommercialcoverageifk, inferredsourcemethodcommercialcoverage, ediservicetypecodefk, servicetypecac, subscriberfirstname, subscribermiddlename, subscriberlastname, subscriberphonenum, payeraddress1, payeraddress2, payercity, payerstate, payerzipcode, payerphonenum, imefirstpaymentdate, imepaymentamount, outofstatepayer, subscriberaddress1, subscribercity, subscriberstate, subscriberzip, subscriberdob, subscriberssn, edi271dependantrelationshipcode, vendorcoverageexists, vendorname, sourcereportfk, externallysourcedsubscriberdobfk, hospinsurancecodefk, guarantorurn, responseaddr, responsecity, responsestate, responsezip, registrar, patientacctsplacementfilefk, payername, CAST(0 AS INT) AS isdeleted FROM reportwarehousemedicaideligiblepaes ",
    "table_view_delete"     : "SELECT requestguid, createdatetrigger AS requestdate, requestauthor, reportfk, reporttypefk, reportcumulative, patientacctifk, foundcoverageifk, uniqueval, foundcoveragepk, startdate, enddate, adddate, retrodate, programtype, spenddown, coveragecode, coveragecreatedate, coverageupdatedate, coverageid, mcaidlastname, mcaidfirstname, mcaidmiddlename, mcaidssn, mcaiddob, mcaidgender, coveragecodedesc, programtypedesc, spenddowncodedesc, patientacctpk, acctnum, medicaidnum, totalcharges, currentbalance, lastname, firstname, middlename, referraldate, ssn, dob, gender, admitdate, dischargedate, acctcreatedate, acctupdatedate, patienttypecode, admittypecode, servicetypecode, finclassreferred, finclasscurr, acctlocatorcode, agencycode, primaryins, secondaryins, tertiaryins, quaternaryins, collectstatuscode, servicetypedesc, finclasscurrdesc, mcaidpending, agencydesc, billdl, sortbilldl, mcaiddaystocert, mcaiddayscertd, hospitalfk, hospitalname, softwaresyscode, pendingholddays, mcaidstate, covlmtdaylimit, covlmtdaysused, covlmtdollarlimit, covlmtdollarsused, covlmtstartdate, covlmtenddate, notenote, notedesc, custom1, custom2, custom3, customn1, customn2, displayaspasttimely, hospitalpk, placementimportstatus, segmentsource, reportrequestfk, paidamt, paymentadjamt, addr1, addr2, city, state, zip, phone1, claimdate, selectedsegment, knownmcaid, addlcoverageinfo, acctpaid, prependednoteinfo, coverageinfo, inferredsourcefoundcoverageifk, medicalrecnum, inferredsourcemethod, medicaidcoverageifk, inferredsourcemedicaidcoverageifk, inferredsourcemethodmedicaid, managedcarecoveragedetailifk, inferredsourcemanagedcarecoveragedetailifk, inferredsourcemethodmanagedcare, medicarecoverageifk, inferredsourcemedicarecoverageifk, inferredsourcemethodmedicare, patientaccteligibilitysubmittalfk, mcaidholddays, billablesubmitdate, admittypecac, pendingmcaid, primarymcaid, secondarymcaid, ifc01_knownmcaid, ifc02_pendingmcaid, ifc03_primarymcaid, ifc04_primarymcaid_charity, ifc05_primarymcaid_baddebt, ifc06_primarymcaid_ar, ifc07_secondarymcaid, ifc08_secondarymcaid_afterworkcomp, ifc09_secondarymcaid_aftermcare, ifc10_secondarymcaid_afterinsurance, ifccodefk, dsh_eligible, unbillable, reportmetasectionfk, rptmetasectionordervalue, primarydiagnosis, finclassreferredhospfinclasscodefk, finclassreferredhospfinclasscodehistoryfk, finclasscurrhospfinclasscodefk, finclasscurrhospfinclasscodehistoryfk, primaryinshospinsurancecodefk, primaryinshospinsurancecodeshistoryfk, secondaryinshospinsurancecodefk, secondaryinshospinsurancecodeshistoryfk, tertiaryinshospinsurancecodefk, tertiaryinshospinsurancecodeshistoryfk, quaternaryinshospinsurancecodefk, quaternaryinshospinsurancecodeshistoryfk, edipartnerfk, rptsortorder, knownmcaidflag, pendingmcaidflag, primarymcaidflag, primarymcaid_charityflag, primarymcaid_baddebtflag, primarymcaid_arflag, secondarymcaidflag, secondarymcaid_afterworkcompflag, secondarymcaid_aftermcareflag, secondarymcaid_afterinsuranceflag, outofstatemcaidflag, charitytransflag, hasrelatedpendingmcaidacct, pcpfirstname, pcplastname, pcpmiddlename, pcpphonenum, admitdiagnosis, dischargediagnosis, lastimportdate, collectionagencycode, baddebttransflag, mcaidtransflag, totalpayments, totaladjustments, medicarehic, insurancecode5, insurancecode6, insurancecode7, ins1policyid, ins2policyid, ins3policyid, ins4policyid, ins5policyid, ins6policyid, ins7policyid, informationonly, zipdistance, segmentcreatedate, notenotekeyinfo, attendingphynname, suppressaxiomssn, hasmedicareflag, medicaremanagedcarecoverageifk, foundcoveragebenefitsnotes, knowntricareflag, tricaretransflag, mcaretransflag, facilitycode, facilitycodedescription, tprcoverageifk, inferredsourcemedicaremanagedcarecoverageifk, inferredsourcemethodmedicaremanagedcare, hasbillablerevcode, commercialcoverageifk, inferredsourcecommercialcoverageifk, inferredsourcemethodcommercialcoverage, ediservicetypecodefk, servicetypecac, subscriberfirstname, subscribermiddlename, subscriberlastname, subscriberphonenum, payeraddress1, payeraddress2, payercity, payerstate, payerzipcode, payerphonenum, imefirstpaymentdate, imepaymentamount, outofstatepayer, subscriberaddress1, subscribercity, subscriberstate, subscriberzip, subscriberdob, subscriberssn, edi271dependantrelationshipcode, vendorcoverageexists, vendorname, sourcereportfk, externallysourcedsubscriberdobfk, hospinsurancecodefk, guarantorurn, responseaddr, responsecity, responsestate, responsezip, registrar, patientacctsplacementfilefk, payername, CAST(1 AS INT) AS isdeleted FROM reportwarehousemedicaideligiblepaeshistory WHERE dmltype = 'D' ",
}



foundcoveragesegments = {
    "table_loadtype"        : "upsert",
    "table_threads"         : "15",
    "table_shardtype"       : "Y",
    "table_primary"         : "foundcoveragesegments",
    "table_primary_query"   : "SELECT * FROM escan.dbo.foundcoveragesegments (NOLOCK) WHERE UpdateDate >= ",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : "SELECT foundcoveragesegmentipk, foundcoverageifk, hospitalfk, coveragesegmenttypefk, edipartnerfk, patientacctifk, originalsourceflag, coveragelevelcode, servicetypecode, insurancetypecode, plancoveragedescriptionfk, groupnumber, policynumber, adddate, adddateorigintypefk, startdate, enddate, enddateorigintypefk, inferredsourcemethodcode, inferredsourcecoveragesegmentifk, currentinferredsourcemethodcode, lastimporteddate, createdate, createdby, updatedate, updatedby, programcode, benefitplancode, baseplan, spenddown, medicaidcoveragecode, CAST(0 AS INT) AS isdeleted FROM foundcoveragesegments",
    "table_view_delete"     : "",
}

hintfoundcoverage = {
    "table_loadtype"        : "upsert",
    "table_threads"         : "15",
    "table_shardtype"       : "Y",
    "table_primary"         : "hintfoundcoverage",
    "table_primary_query"   : "SELECT * FROM escan.dbo.hintfoundcoverage (NOLOCK) WHERE UpdateDate >= ",
    "table_secondary"       : "hintfoundcoveragehistory",
    "table_secondary_query" : "SELECT * FROM escan.dbo.hintfoundcoveragehistory (NOLOCK) WHERE createdatetrigger >= ",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : "SELECT hintfoundcoveragepk, patientacctifk, hospitalfk, edipayerfk, hintglobalmrnxpatientacctxpayerfk, inferredsourcemethodcode, inferredsourcehintfoundcoverageifk, edidatasourcefk, createdate, updatedate, sourcefoundcoveragehospitalfk, sourcefoundcoverageifk, sourcehelperfoundcoverageifk, CAST(0 AS INT) AS isdeleted FROM hintfoundcoverage",
    "table_view_delete"     : "SELECT hintfoundcoveragepk, patientacctifk, hospitalfk, edipayerfk, hintglobalmrnxpatientacctxpayerfk, inferredsourcemethodcode, inferredsourcehintfoundcoverageifk, edidatasourcefk, createdate, createdatetrigger AS updatedate, sourcefoundcoveragehospitalfk, sourcefoundcoverageifk, sourcehelperfoundcoverageifk, CAST(1 AS INT) AS isdeleted FROM hintfoundcoveragehistory WHERE dmltype = 'D'",
}

hospinsurancecodes = {
    "table_loadtype"        : "upsert",
    "table_threads"         : "15",
    "table_shardtype"       : "Y",
    "table_primary"         : "hospinsurancecodes",
    "table_primary_query"   : "SELECT * FROM escan.dbo.hospinsurancecodes (NOLOCK) WHERE UpdateDate >= ",
    "table_secondary"       : "hospinsurancecodeshistory",
    "table_secondary_query" : "SELECT * FROM escan.dbo.hospinsurancecodeshistory (NOLOCK) WHERE createdatetrigger >= ",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : "SELECT hospinsurancecodepk, hospitalfk, code, codedesc, mcaid, createdate, createdby, updatedate, updatedby, hospcodestatusfk, hospcodestatusupdatedate, hospcodestatusupdatedby, lastusedadmitdate, mcare, mcaidpending, commercialinsurance, workmanscomp, charity, baddebt, selfpay, secondarytomcaid, flagsupdatedate, outofstatemcaid, codedescupdatedate, codedescupdatedby, tricare, paymentoffset, medicareadvantage, medicaregap, edipayerfk, sampleacctnum, ambiguous, imegme, managedcareproviderentityfk, thirdpartyliabflag, reviewdate, reviewby, flagsupdatedby, dualeligibleflag, CAST(0 AS INT) AS isdeleted FROM hospinsurancecodes ",
    "table_view_delete"     : "SELECT hospinsurancecodepk, hospitalfk, code, codedesc, mcaid, createdate, createdby, createdatetrigger AS updatedate, updatedby, hospcodestatusfk, hospcodestatusupdatedate, hospcodestatusupdatedby, lastusedadmitdate, mcare, mcaidpending, commercialinsurance, workmanscomp, charity, baddebt, selfpay, secondarytomcaid, flagsupdatedate, outofstatemcaid, codedescupdatedate, codedescupdatedby, tricare, paymentoffset, medicareadvantage, medicaregap, edipayerfk, sampleacctnum, ambiguous, imegme, managedcareproviderentityfk, thirdpartyliabflag, reviewdate, reviewby, flagsupdatedby, dualeligibleflag, CAST(1 AS INT) AS isdeleted FROM hospinsurancecodeshistory WHERE historyupdatetype = 'D' ",
}

medicarecoverage = {
    "table_loadtype"        : "upsert",
    "table_threads"         : "15",
    "table_shardtype"       : "Y",
    "table_primary"         : "medicarecoverage",
    "table_primary_query"   : "SELECT * FROM escan.dbo.medicarecoverage (NOLOCK) WHERE UpdateDate >= ",
    "table_secondary"       : "medicarecoveragehistory",
    "table_secondary_query" : "SELECT * FROM escan.dbo.medicarecoveragehistory (NOLOCK) WHERE createdatetrigger >= ",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : "SELECT m.medicarecoveragepk, m.foundcoveragefk, m.adddate, m.startdate, m.enddate, m.medicaretype, m.medicarehic, m.createdate, m.updatedate, m.hospitalfk, m.foundcoverageifk, m.medicarecoverageipk, m.ediservicetypecodefk, m.inferredsourcemedicarecoverageifk, m.currentinferredsourcemethodcode, m.inferredsourcemethodcode, m.enddateorigin, m.lastimporteddate, m.patientacctifk, CAST(0 AS INT) AS isdeleted FROM hospitals h INNER JOIN medicarecoverage m ON m.hospitalfk = h.hospitalpk ",
    "table_view_delete"     : "SELECT medicarecoveragepk, foundcoveragefk, adddate, startdate, enddate, medicaretype, medicarehic, createdate, createdatetrigger AS updatedate, hospitalfk, foundcoverageifk, medicarecoverageipk, ediservicetypecodefk, inferredsourcemedicarecoverageifk, currentinferredsourcemethodcode, inferredsourcemethodcode, enddateorigin, lastimporteddate, patientacctifk, CAST(1 AS INT) AS isdeleted FROM medicarecoveragehistory WHERE dmltype = 'D' ",
}

tprcoverage = {
    "table_loadtype"        : "upsert",
    "table_threads"         : "15",
    "table_shardtype"       : "Y",
    "table_primary"         : "tprcoverage",
    "table_primary_query"   : "SELECT * FROM escan.dbo.tprcoverage (NOLOCK) WHERE UpdateDate >= ",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : "SELECT tprcoveragepk, foundcoveragefk, coveragetype, startdate, enddate, subscriberfirstname, subscribermiddlename, subscriberlastname, subscriberssn, relationship, employername, coname, policygroupnumber, contactname, addr, city, state, zip, phonenum, createdate, updatedate, hospitalfk, foundcoverageifk, policynumber, conamepayorid, tprcoverageipk, ediservicetypecodefk, enddateorigin, lastimporteddate, patientacctifk, CAST(0 AS INT) isdeleted FROM tprcoverage ",
    "table_view_delete"     : "",
}

vendorknownohibenefits = {
    "table_loadtype"        : "upsert",
    "table_threads"         : "15",
    "table_shardtype"       : "Y",
    "table_primary"         : "vendorknownohibenefits",
    "table_primary_query"   : "SELECT * FROM escan.dbo.vendorknownohibenefits (NOLOCK) WHERE UpdateDate >= ",
    "table_secondary"       : "",
    "table_secondary_query" : "",
    "table_tertiary"        : "",
    "table_tertiary_query"  : "",
    "table_view_upsert"     : "SELECT vendorknownohibenefitspk, vendorknownohicoveragesfk, hospitalfk, patientacctifk, benefitactiveflag, benefitstartdate, benefitenddate, benefittype, insurancecompanycode, insurancesourcecode, payerinsurancecompanyname, payerinsurancecompanyaddress1, payerinsurancecompanyaddress2, payerinsurancecompanycity, payerinsurancecompanystate, payerinsurancecompanyzip, payerinsurancecompanyphone, payerinsurancecompanyphone2, createimportfilepartfk, updateimportfilepartfk, createdate, createdby, updatedate, updatedby, additionaljsondata, CAST(0 AS INT) isdeleted FROM vendorknownohibenefits ",
    "table_view_delete"     : "",
}

# COMMAND ----------

# MAGIC %md
# MAGIC ### # **GROUP : 01 : Tables : Union : metadata_group_01**

# COMMAND ----------

# DBTITLE 1,metadata_group_01
meta_patientaccts = spark.createDataFrame([Row(**patientaccts)], schema)
meta_patientacctscodes = spark.createDataFrame([Row(**patientacctscodes)], schema)
meta_vsnappatientacctsflags = spark.createDataFrame([Row(**vsnappatientacctsflags)], schema)
meta_foundcoverage = spark.createDataFrame([Row(**foundcoverage)], schema)
meta_helperfoundcoverages = spark.createDataFrame([Row(**helperfoundcoverages)], schema)

metadata_group_01 = (
    meta_patientaccts
    .union(meta_patientacctscodes)
    .union(meta_vsnappatientacctsflags)
    .union(meta_foundcoverage)
    .union(meta_helperfoundcoverages)
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### # **GROUP : FNF : Tables : Union : metadata_group_fnf**

# COMMAND ----------

# DBTITLE 1,metadata_group_fnf
meta_hospitalprovidernums = spark.createDataFrame([Row(**hospitalprovidernums)], schema)
meta_hospitalattributevalues = spark.createDataFrame([Row(**hospitalattributevalues)], schema)
meta_hospitalattributes = spark.createDataFrame([Row(**hospitalattributes)], schema)
meta_hospitals = spark.createDataFrame([Row(**hospitals)], schema)
meta_edipayers = spark.createDataFrame([Row(**edipayers)], schema)
meta_edipartners = spark.createDataFrame([Row(**edipartners)], schema)
meta_opsedipayershospitals = spark.createDataFrame([Row(**opsedipayershospitals)], schema)
meta_edipayeropsoutofregionconfig = spark.createDataFrame([Row(**edipayeropsoutofregionconfig)], schema)
meta_edipayeropslottoconfig = spark.createDataFrame([Row(**edipayeropslottoconfig)], schema)
meta_edipayerzipcodelookup = spark.createDataFrame([Row(**edipayerzipcodelookup)], schema)
meta_edipayersxstateinsurancenames = spark.createDataFrame([Row(**edipayersxstateinsurancenames)], schema)
meta_hcsystems = spark.createDataFrame([Row(**hcsystems)], schema)
meta_edipayers_tupayeridmapping = spark.createDataFrame([Row(**edipayers_tupayeridmapping)], schema)
meta_edi270querycombos = spark.createDataFrame([Row(**edi270querycombos)], schema)
meta_edidatasources = spark.createDataFrame([Row(**edidatasources)], schema)
meta_edipartner270settings = spark.createDataFrame([Row(**edipartner270settings)], schema)
meta_edipartnerattributes = spark.createDataFrame([Row(**edipartnerattributes)], schema)
meta_edipartnerattributevalues = spark.createDataFrame([Row(**edipartnerattributevalues)], schema)
meta_edipartnerhospital270settingsoverrides = spark.createDataFrame([Row(**edipartnerhospital270settingsoverrides)], schema)
meta_edipartnersubmittersoverrides = spark.createDataFrame([Row(**edipartnersubmittersoverrides)], schema)
meta_edipartnertype = spark.createDataFrame([Row(**edipartnertype)], schema)
meta_edisubmitters = spark.createDataFrame([Row(**edisubmitters)], schema)
meta_edisubscriberdobresponse = spark.createDataFrame([Row(**edisubscriberdobresponse)], schema)
meta_escanglobalparameters = spark.createDataFrame([Row(**escanglobalparameters)], schema)
meta_foundcoverageinferredsourcemethodcodes = spark.createDataFrame([Row(**foundcoverageinferredsourcemethodcodes)], schema)
meta_hospitalnpioverrides = spark.createDataFrame([Row(**hospitalnpioverrides)], schema)
meta_hospitalpayercob = spark.createDataFrame([Row(**hospitalpayercob)], schema)
meta_partnerpolicyidblacklists = spark.createDataFrame([Row(**partnerpolicyidblacklists)], schema)
meta_zipcodes = spark.createDataFrame([Row(**zipcodes)], schema)
meta_hospphysicians = spark.createDataFrame([Row(**hospphysicians)], schema)
meta_edipartnershospitalbilldlrules = spark.createDataFrame([Row(**edipartnershospitalbilldlrules)], schema)
meta_edileadsourcetransition = spark.createDataFrame([Row(**edileadsourcetransition)], schema)
meta_hpdhospitalpartnerlastrespstatus = spark.createDataFrame([Row(**hpdhospitalpartnerlastrespstatus)], schema)
meta_patientacctsaccesscoordinator = spark.createDataFrame([Row(**patientacctsaccesscoordinator)], schema)
meta_hospitalpurge = spark.createDataFrame([Row(**hospitalpurge)], schema)
meta_patientmatchingblockallowgmrn = spark.createDataFrame([Row(**patientmatchingblockallowgmrn)], schema)
meta_birthmonthrequeryhospitals = spark.createDataFrame([Row(**birthmonthrequeryhospitals)], schema)
meta_nexusconfig = spark.createDataFrame([Row(**nexusconfig)], schema)
meta_nexusfeatures = spark.createDataFrame([Row(**nexusfeatures)], schema)
meta_nexusservers = spark.createDataFrame([Row(**nexusservers)], schema)
meta_nexusscope = spark.createDataFrame([Row(**nexusscope)], schema)
meta_dontreportdatafromlegalteam = spark.createDataFrame([Row(**dontreportdatafromlegalteam)], schema)
meta_bcbsprefixtopayermappings = spark.createDataFrame([Row(**bcbsprefixtopayermappings)], schema)


metadata_group_fnf = (
    meta_hospitalprovidernums
    .union(meta_hospitalattributevalues)
    .union(meta_hospitalattributes)
    .union(meta_hospitals)
    .union(meta_edipayers)
    .union(meta_edipartners)
    .union(meta_opsedipayershospitals)
    .union(meta_edipayeropsoutofregionconfig)
    .union(meta_edipayeropslottoconfig)
    .union(meta_edipayerzipcodelookup)
    .union(meta_edipayersxstateinsurancenames)
    .union(meta_hcsystems)
    .union(meta_edipayers_tupayeridmapping)
    .union(meta_edi270querycombos)
    .union(meta_edidatasources)
    .union(meta_edipartner270settings)
    .union(meta_edipartnerattributes)
    .union(meta_edipartnerattributevalues)
    .union(meta_edipartnerhospital270settingsoverrides)
    .union(meta_edipartnersubmittersoverrides)
    .union(meta_edipartnertype)
    .union(meta_edisubmitters)
    .union(meta_edisubscriberdobresponse)
    .union(meta_escanglobalparameters)
    .union(meta_foundcoverageinferredsourcemethodcodes)
    .union(meta_hospitalnpioverrides)
    .union(meta_hospitalpayercob)
    .union(meta_partnerpolicyidblacklists)
    .union(meta_zipcodes)
    .union(meta_hospphysicians)
    .union(meta_edipartnershospitalbilldlrules)
    # .union(meta_edileadsourcetransition)
    # .union(meta_hpdhospitalpartnerlastrespstatus)
    .union(meta_patientacctsaccesscoordinator)
    .union(meta_hospitalpurge)
    .union(meta_patientmatchingblockallowgmrn)
    .union(meta_birthmonthrequeryhospitals)
    .union(meta_nexusconfig)
    .union(meta_nexusfeatures)
    .union(meta_nexusservers)
    .union(meta_nexusscope)
    .union(meta_dontreportdatafromlegalteam)
    .union(meta_bcbsprefixtopayermappings)
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### # **GROUP : 02 : Tables : Union : metadata_group_02**

# COMMAND ----------

# DBTITLE 1,metadata_group_02
meta_edisubscriberdobsearch = spark.createDataFrame([Row(**edisubscriberdobsearch)], schema)
meta_clusteredaccts = spark.createDataFrame([Row(**clusteredaccts)], schema)
meta_patientacctspayercob = spark.createDataFrame([Row(**patientacctspayercob)], schema)
meta_patientacctsguarantors = spark.createDataFrame([Row(**patientacctsguarantors)], schema)
meta_patientaccteligibilitysubmittals = spark.createDataFrame([Row(**patientaccteligibilitysubmittals)], schema)
meta_patientacctstatestatus = spark.createDataFrame([Row(**patientacctstatestatus)], schema)
meta_vsnapglobalmrnfamilyhelperaccounts = spark.createDataFrame([Row(**vsnapglobalmrnfamilyhelperaccounts)], schema)
meta_reportwarehousemedicaideligiblepaes = spark.createDataFrame([Row(**reportwarehousemedicaideligiblepaes)], schema)
meta_foundcoveragesegments = spark.createDataFrame([Row(**foundcoveragesegments)], schema)
meta_hintfoundcoverage = spark.createDataFrame([Row(**hintfoundcoverage)], schema)
meta_hospinsurancecodes = spark.createDataFrame([Row(**hospinsurancecodes)], schema)
meta_medicarecoverage = spark.createDataFrame([Row(**medicarecoverage)], schema)
meta_tprcoverage = spark.createDataFrame([Row(**tprcoverage)], schema)
meta_vendorknownohibenefits = spark.createDataFrame([Row(**vendorknownohibenefits)], schema)

metadata_group_02 = (
    meta_edisubscriberdobsearch
    .union(meta_clusteredaccts)
    .union(meta_patientacctspayercob)
    .union(meta_patientacctsguarantors)
    .union(meta_patientaccteligibilitysubmittals)
    .union(meta_patientacctstatestatus)
    .union(meta_vsnapglobalmrnfamilyhelperaccounts)
    .union(meta_reportwarehousemedicaideligiblepaes)
    .union(meta_foundcoveragesegments)
    .union(meta_hintfoundcoverage)
    .union(meta_hospinsurancecodes)
    .union(meta_medicarecoverage)
    .union(meta_tprcoverage)
    .union(meta_vendorknownohibenefits)
)


# COMMAND ----------

# DBTITLE 1,HOURS
metadata_group_fnf = metadata_group_fnf.withColumn("table_extract_hour",lit('0')).withColumn("table_group_name",lit('fnf'))
metadata_group_01  = metadata_group_01.withColumn("table_extract_hour",lit('30')).withColumn("table_group_name",lit('grp1'))
metadata_group_02  = metadata_group_02.withColumn("table_extract_hour",lit('30')).withColumn("table_group_name",lit('grp2'))

# COMMAND ----------

print("Count of tables in GROUP : FNF : metadata_group_fnf : ",metadata_group_fnf.count())
print("Count of tables in GROUP : 01  : metadata_group_01  : ",metadata_group_01.count())
print("Count of tables in GROUP : 02  : metadata_group_02  : ",metadata_group_02.count())

# COMMAND ----------

# MAGIC %md
# MAGIC ### # **GROUP : ALL : Tables Keys : Definition**

# COMMAND ----------

table_keys_data = [
    ("clusteredaccts","hospitalfk,clusteredacctpk","","",""),
    ("edi270querycombos","","","",""),
    ("edidatasources","","","",""),
    ("edileadsourcetransition","","","",""),
    ("edipartner270settings","","","",""),
    ("edipartnerattributes","","","",""),
    ("edipartnerattributevalues","","","",""),
    ("edipartnerhospital270settingsoverrides","","","",""),
    ("edipartners","edipartnerpk","","",""),
    ("edipartnershospitalbilldlrules","","","",""),
    ("edipartnersubmittersoverrides","","","",""),
    ("edipartnertype","","","",""),
    ("edipayeropslottoconfig","edipayerfk","","",""),
    ("edipayeropsoutofregionconfig","edipayerfk","","",""),
    ("edipayers","edipayerpk","","",""),
    ("edipayers_tupayeridmapping","","","",""),
    ("edipayersxstateinsurancenames","edipayersxstateinsurancenameipk","","",""),
    ("edipayerzipcodelookup","edipayerzipcodelookuppk","","",""),
    ("edisubmitters","","","",""),
    ("edisubscriberdobresponse","","","",""),
    ("edisubscriberdobsearch","hospitalfk,edisubscriberdobsearchpk","","",""),
    ("escanglobalparameters","","","",""),
    ("foundcoverage","hospitalfk,foundcoverageipk","","",""),
    ("foundcoverageinferredsourcemethodcodes","","","",""),
    ("foundcoveragesegments","hospitalfk,foundcoveragesegmentipk","","",""),
    ("globalmrnbadassociations","hospitalfk,globalmrnbadassociationpk","","",""),
    ("globalmrnxpacct","hospitalfk,globalmrnxpacctipk","","",""),
    ("hcsystems","hcsystempk","","",""),
    ("helperfoundcoverages","hospitalfk,helperfoundcoverageipk","","",""),
    ("hintfoundcoverage","hospitalfk,hintfoundcoveragepk","","",""),
    ("hospinsurancecodes","hospitalfk,hospinsurancecodepk","","",""),
    ("hospitalattributes","hospitalattributepk","","",""),
    ("hospitalattributevalues","hospitalattributevaluepk,hospitalfk","","",""),
    ("hospitalnpioverrides","","","",""),
    ("hospitalpayercob","","","",""),
    ("hospitalprovidernums","hospitalprovidernumpk,hospitalfk","","",""),
    ("hospitals","hospitalpk","","",""),
    ("hospphysicians","","","",""),
    ("hpdhospitalpartnerlastrespstatus","hospitalfk,edipartnerfk","","",""),
    ("medicarecoverage","hospitalfk,foundcoverageifk,medicarecoverageipk","","",""),
    ("opsedipayershospitals","opsedipayershospitalpk","","",""),
    ("partnerpolicyidblacklists","","","",""),
    ("patientacctsaccesscoordinator","","","",""),
    ("patientaccteligibilitysubmittals","hospitalfk,patientacctifk,patientaccteligibilitysubmittalpk","","",""),
    ("patientaccts","hospitalfk,patientacctipk","","",""),
    ("patientacctscodes","hospitalfk,patientacctifk","","",""),
    ("patientacctsguarantors","hospitalfk,patientacctifk","","",""),
    ("patientacctspayercob","hospitalfk,patientacctifk","","",""),
    ("patientacctstatestatus","hospitalfk,patientacctstatestatuspk","","",""),
    ("reportwarehousemedicaideligiblepaes","hospitalfk,patientacctifk,patientaccteligibilitysubmittalfk","","",""),
    ("tprcoverage","hospitalfk,tprcoveragepk","","",""),
    ("vendorknownohibenefits","hospitalfk,vendorknownohibenefitspk","","",""),
    ("vsnapglobalmrnfamilyhelperaccounts","hospitalfk,vsnapglobalmrnfamilyhelperaccountspk","","",""),
    ("vsnappatientacctsflags","hospitalfk,patientacctifk","","",""),
    ("zipcodes","","","",""),
    ("hospitalpurge","","","",""),
    ("birthmonthrequeryhospitals","","","",""),
    ("patientmatchingblockallowgmrn","","","",""),
    ("nexusconfig","","","",""),
    ("nexusfeatures","","","",""),
    ("nexusservers","","","",""),
    ("nexusscope","","","",""),
    ("bcbsprefixtopayermappings","","","","")

]
schema = StructType([
    StructField("table_primary", StringType(), True),
    StructField("table_primary_keys", StringType(), True),
    StructField("table_range_keys", StringType(), True),
    StructField("table_reconcile_keys", StringType(), True),
    StructField("table_orderby_keys", StringType(), True),
])

table_keys = spark.createDataFrame(table_keys_data, schema)
table_keys.createOrReplaceTempView("table_keys")

table_keys.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### # **GROUP : ALL : Tables : Union : metadata**

# COMMAND ----------

metadata = metadata_group_fnf.union(metadata_group_01).union(metadata_group_02)
metadata = metadata.withColumn("id", col("table_primary"))
metadata = metadata.withColumn("table_active", lit("Y"))
from pyspark.sql.functions import when
# disable table lists - add tables one by one to deactivate
metadata = metadata.withColumn("table_active",when(col("id") == "hpdhospitalpartnerlastrespstatus", "N").otherwise(col("table_active")))
metadata = metadata.withColumn("table_active",when(col("id") == "hintfoundcoverage", "N").otherwise(col("table_active")))
metadata = metadata.withColumn("table_active",when(col("id") == "helperfoundcoverages", "N").otherwise(col("table_active")))


metadata.createOrReplaceTempView("metadata")
metadata = spark.sql(
    """
SELECT metadata.id,
       metadata.table_group_name,
       metadata.table_active,
       metadata.table_shardtype,
       metadata.table_loadtype,
       metadata.table_extract_hour,
       metadata.table_threads,
       metadata.table_primary,
       table_keys.table_primary_keys,
       table_keys.table_range_keys,
       table_keys.table_reconcile_keys,
       table_keys.table_orderby_keys,
       metadata.table_primary_query,
       metadata.table_secondary,
       metadata.table_secondary_query,
       metadata.table_tertiary,
       metadata.table_tertiary_query,
       metadata.table_view_upsert,
       metadata.table_view_delete
FROM metadata
  LEFT JOIN table_keys ON metadata.table_primary = table_keys.table_primary
"""
)

metadata.display()

# COMMAND ----------

metadata.filter("table_loadtype=='fnf'").selectExpr("table_shardtype","table_loadtype","table_primary_query as table_query").dropDuplicates().display()

# COMMAND ----------

try:
    if dbutils.fs.ls(path_metadata):
        print("path exists  : " + path_metadata)
        dbutils.fs.rm(path_metadata, recurse=True)
        print("path deleted : "+ path_metadata)
        metadata.repartition(1).write.mode("overwrite").format("delta").save(path_metadata)
        print("path repopulated : " + path_metadata)
except Exception as e:
    if "java.io.FileNotFoundException" in str(e):
        print("path does not exist : " + path_metadata)
        metadata.repartition(1).write.mode("overwrite").format("delta").save(path_metadata)
        print("path repopulated : " + path_metadata)
    else:
        raise e
