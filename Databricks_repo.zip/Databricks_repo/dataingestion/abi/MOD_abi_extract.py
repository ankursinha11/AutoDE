# Databricks notebook source
from pyspark.sql.functions import *

# COMMAND ----------

# DBTITLE 1,Input Parameters
dbutils.widgets.text("tablename","")
dbutils.widgets.getArgument("tablename")
tablename= getArgument("tablename")

dbutils.widgets.text("path_conn_file", "")
dbutils.widgets.getArgument("path_conn_file")
path_conn_file= getArgument("path_conn_file")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("publishpath","")
dbutils.widgets.getArgument("publishpath")
publishpath= getArgument("publishpath")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("extractdays","")
dbutils.widgets.getArgument("extractdays")
extractdays= getArgument("extractdays")

# COMMAND ----------

# DBTITLE 1,SAMPLE CODE
# bc="20240905T06"
# container="prod-icd-stg-adls"
# path_conn_file="jdbc:sqlserver://iblsql3.nthrive.nthcrp.com;user=app_databricks;password=XXXXXXXX;trustServerCertificate=true"
# publishpath="/data/dataingestion/staging/input/"
# storageaccount="prodicdstgdls"
# tablename="helperfoundcoverages"
# user="maxc"
# extractdays="48"

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user
print("baseurl : "+baseurl)

output=baseurl+"/"+publishpath+"/"+tablename+"/"+bc
print("output : "+output)


# COMMAND ----------

def get_table_min_max_value(path_conn_file,table_query_min_max,thread):
    df_min_max = spark.read.format("jdbc").option("url", path_conn_file).option("query", table_query_min_max).option("numPartitions", thread).load()
    for column in df_min_max.columns:
        df_min_max = df_min_max.withColumn(column, trim(col(column)))
        df_min_max = df_min_max.withColumn(column, when(col(column).isNull(), '0').otherwise(col(column)))
        df_min_max = df_min_max.withColumn(column, when(col(column) == 'null', '0').otherwise(col(column)))
        df_min_max = df_min_max.withColumn(column, when(col(column) == '', '0').otherwise(col(column)))
    # minval = str(df_min_max.collect()[0]['MINVAL'])
    # maxval = str(df_min_max.collect()[0]['MAXVAL'])
    list = df_min_max.collect()[0]
    minval = str(list['MINVAL'])
    maxval = str(list['MAXVAL'])
    df_min_max.unpersist()
    min_max=minval+"~"+maxval
    return min_max

# COMMAND ----------

partition_column_lookup = {
    "patientacctscodes": "patientacctifk",
    "patientaccts": "patientacctipk",
    "foundcoverage": "foundcoverageipk",
    "vsnappatientacctsflags": "patientacctifk",
    "helperfoundcoverages": "patientacctifk",
    "reportwarehousemedicaideligiblepaes": "foundcoverageifk",
    "patientacctstatestatus": "patientacctifk",
    "patientacctspayercob": "patientacctifk",
    "foundcoveragesegments": "foundcoverageifk",
    "hospinsurancecodes": "hospinsurancecodepk",
    "hintfoundcoverage": "patientacctifk",
    "tprcoverage": "foundcoverageifk",
    "medicarecoverage": "MedicareCoverageIPK",
    "clusteredaccts": "clusteredacctpk",
    "edisubscriberdobsearch": "patientacctifk",
    "vsnapglobalmrnfamilyhelperaccounts": "patientacctifk",
    "patientacctsguarantors": "hospitalfk",
    "patientaccteligibilitysubmittals": "patientacctifk",
}

# COMMAND ----------

partition_column = str(partition_column_lookup.get(tablename))

if partition_column == "None":
    print("INVALID tablename : " + tablename+" NO partition_column FOUND")
    exit(1)
else:
    print("tablename : " + tablename + " partition_column : " + partition_column)

# COMMAND ----------

table_query_primary=""
table_query_secondary=""
table_query_primary_min_max=""
table_query_secondary_min_max=""
isSecondaryPresent=""
thread=0
pat_pat=0

if tablename in ['patientaccts','patientacctscodes']:
    thread=30
    pat_pat=1
    #table_query_primary="SELECT * FROM Abinitio.dbo."+tablename+" (NOLOCK) WHERE TrgUpdateDate >= CURRENT_TIMESTAMP-"+extractdays
    table_query_primary="SELECT * FROM Abinitio.dbo."+tablename+" (NOLOCK) WHERE TrgUpdateDate >= dateadd(HOUR,-"+extractdays+",CURRENT_TIMESTAMP)"
    table_query_secondary="SELECT * FROM Abinitio.dbo."+tablename+ "_Deleted"" (NOLOCK) WHERE TrgUpdateDate >= dateadd(HOUR,-"+extractdays+",CURRENT_TIMESTAMP)"
    table_query_primary_min_max="SELECT MIN(A." + partition_column + ") AS MINVAL,MAX(A."+ partition_column + ") AS MAXVAL FROM (" + table_query_primary  +" ) A"
    table_query_secondary_min_max="SELECT MIN(A." + partition_column + ") AS MINVAL,MAX(A."+ partition_column + ") AS MAXVAL FROM (" + table_query_secondary  +" ) A"
    isSecondaryPresent="1"
elif tablename in ['tprcoverage','foundcoveragesegments','patientacctstatestatus']:
    thread=15
    table_query_primary = "SELECT * from Abinitio.dbo." + tablename + " (NOLOCK) where UpdateDate >= dateadd(HOUR,-"+extractdays+",CURRENT_TIMESTAMP)"
    table_query_primary_min_max="SELECT MIN(A." + partition_column + ") AS MINVAL,MAX(A."+ partition_column + ") AS MAXVAL FROM (" + table_query_primary  +" ) A"
    isSecondaryPresent="0"
elif tablename in ['vsnappatientacctsflags']:
    thread=15
    table_query_primary="SELECT * FROM Abinitio.dbo."+tablename+" (NOLOCK) WHERE CreateDate >= dateadd(HOUR,-"+extractdays+",CURRENT_TIMESTAMP)"
    table_query_secondary="SELECT * FROM Abinitio.dbo."+tablename+ "_Deleted"" (NOLOCK) WHERE CreateDate >= dateadd(HOUR,-"+extractdays+",CURRENT_TIMESTAMP)"
    table_query_primary_min_max="SELECT MIN(A." + partition_column + ") AS MINVAL,MAX(A."+ partition_column + ") AS MAXVAL FROM (" + table_query_primary  +" ) A"
    table_query_secondary_min_max="SELECT MIN(A." + partition_column + ") AS MINVAL,MAX(A."+ partition_column + ") AS MAXVAL FROM (" + table_query_secondary  +" ) A"
    isSecondaryPresent="1"
elif tablename in ['reportwarehousemedicaideligiblepaes']:
    thread=15
    table_query_primary="SELECT * FROM Abinitio.dbo."+tablename+" (NOLOCK) WHERE RequestDate >= dateadd(HOUR,-"+extractdays+",CURRENT_TIMESTAMP)"
    table_query_secondary="SELECT * FROM Abinitio.dbo."+tablename+ "_Deleted"" (NOLOCK) WHERE RequestDate >= dateadd(HOUR,-"+extractdays+",CURRENT_TIMESTAMP)"
    table_query_primary_min_max="SELECT MIN(A." + partition_column + ") AS MINVAL,MAX(A."+ partition_column + ") AS MAXVAL FROM (" + table_query_primary  +" ) A"
    table_query_secondary_min_max="SELECT MIN(A." + partition_column + ") AS MINVAL,MAX(A."+ partition_column + ") AS MAXVAL FROM (" + table_query_secondary  +" ) A"
    isSecondaryPresent="1"
elif tablename in ['hintfoundcoverage','foundcoverage','helperfoundcoverages','patientacctspayercob','hospinsurancecodes','medicarecoverage','clusteredaccts','edisubscriberdobsearch','vsnapglobalmrnfamilyhelperaccounts','patientacctsguarantors','patientaccteligibilitysubmittals']:
    thread=30
    table_query_primary="SELECT * FROM Abinitio.dbo."+tablename+" (NOLOCK) WHERE UpdateDate >= dateadd(HOUR,-"+extractdays+",CURRENT_TIMESTAMP)"
    table_query_secondary="SELECT * FROM Abinitio.dbo."+tablename+ "_Deleted"" (NOLOCK) WHERE UpdateDate >= dateadd(HOUR,-"+extractdays+",CURRENT_TIMESTAMP)"
    table_query_primary_min_max="SELECT MIN(A." + partition_column + ") AS MINVAL,MAX(A."+ partition_column + ") AS MAXVAL FROM (" + table_query_primary  +" ) A"
    table_query_secondary_min_max="SELECT MIN(A." + partition_column + ") AS MINVAL,MAX(A."+ partition_column + ") AS MAXVAL FROM (" + table_query_secondary  +" ) A"
    isSecondaryPresent="1"
    pat_pat=1
else :
    thread=20
    table_query_primary = "SELECT * from Abinitio.dbo." + tablename + " (NOLOCK) where UpdateDate >= dateadd(HOUR,-"+extractdays+",CURRENT_TIMESTAMP)"
    table_query_primary_min_max="SELECT MIN(A." + partition_column + ") AS MINVAL,MAX(A."+ partition_column + ") AS MAXVAL FROM (" + table_query_primary  +" ) A"
    isSecondaryPresent="0"    


print("table_query_primary : "+table_query_primary)
print("table_query_primary_min_max : "+table_query_primary_min_max)

print("                                                 ")

print("table_query_secondary : "+table_query_secondary)
print("table_query_secondary_min_max : "+table_query_secondary_min_max)

print("isSecondaryPresent : "+isSecondaryPresent)
print("thread : "+str(thread))
print("pat_pat : "+str(pat_pat))
print("tablename : " + tablename + " partition_column : " + partition_column)

# COMMAND ----------

isSecondaryPull=""

if isSecondaryPresent =='0':
    print("ONLY PRIMARY PULL")
    print("tablename : " + tablename + " partition_column : " + partition_column)
    primary_min_max=get_table_min_max_value(path_conn_file,table_query_primary_min_max,thread)
    primary_minval=primary_min_max.split("~")[0]
    primary_maxval=primary_min_max.split("~")[1]
    print("primary_minval : " + primary_minval)
    print("primary_maxval : " + primary_maxval)
    table_query_primary_optimized="("+table_query_primary+") AS A"
    print("table_query_primary_optimized "+table_query_primary_optimized)
    isSecondaryPull="0"
    print("isSecondaryPull : "+isSecondaryPull)
else :
    print("BOTH PRIMARY AND SECONDARY PULL")
    print("tablename : " + tablename + " partition_column : " + partition_column)
    primary_min_max=get_table_min_max_value(path_conn_file,table_query_primary_min_max,thread)
    primary_minval=primary_min_max.split("~")[0]
    primary_maxval=primary_min_max.split("~")[1]
    print("primary_minval : " + primary_minval)
    print("primary_maxval : " + primary_maxval)
    if pat_pat == 0:
        print("NON PA TABLE "+tablename)
        print("tablename : " + tablename+"_Deleted" + " partition_column : " + partition_column)
        secondary_min_max=get_table_min_max_value(path_conn_file,table_query_secondary_min_max,thread)
        secondary_minval=secondary_min_max.split("~")[0]
        secondary_maxval=secondary_min_max.split("~")[1]
        print("secondary_minval : " + secondary_minval)
        print("secondary_maxval : " + secondary_maxval)
    else :
        print("PA TABLE "+tablename+"_Deleted"+" NO INDEX : Straight Pull")
    table_query_primary_optimized="("+table_query_primary+") AS A"
    print("table_query_primary_optimized "+table_query_primary_optimized)
    table_query_secondary_optimized="("+table_query_secondary+") AS A"
    print("table_query_secondary_optimized "+table_query_secondary_optimized)
    isSecondaryPull="1"
    print("isSecondaryPull : "+isSecondaryPull)

# COMMAND ----------

if isSecondaryPull=='1':
    print("isSecondaryPull : "+isSecondaryPull)
    data_primary = spark.read.format("jdbc").option("url", path_conn_file) \
    .option("dbtable", table_query_primary_optimized) \
    .option("numPartitions", thread) \
    .option("lowerBound", primary_minval) \
    .option("upperBound", primary_maxval) \
    .option("partitionColumn", partition_column) \
    .option("fetchsize", 1000) \
    .load()
    print("READ : data_primary")
    if pat_pat == 0:
        data_secondary = spark.read.format("jdbc").option("url", path_conn_file) \
        .option("dbtable", table_query_secondary_optimized) \
        .option("numPartitions", thread) \
        .option("lowerBound", secondary_minval) \
        .option("upperBound", secondary_maxval) \
        .option("partitionColumn", partition_column) \
        .option("fetchsize", 1000) \
        .load()
        print("READ : data_secondary")
    else :
        print("PA TABLE SECONDARY")
        data_secondary = spark.read.format("jdbc").option("url", path_conn_file).option("dbtable", table_query_secondary_optimized).option("fetchsize", 1000).option("numPartitions", thread).load()
        print("READ : data_secondary")
elif isSecondaryPull =='0':
    print("isSecondaryPull : "+isSecondaryPull)
    data_primary = spark.read.format("jdbc").option("url", path_conn_file) \
    .option("dbtable", table_query_primary_optimized) \
    .option("numPartitions", thread) \
    .option("lowerBound", primary_minval) \
    .option("upperBound", primary_maxval) \
    .option("partitionColumn", partition_column) \
    .load()
    print("READ : data_primary")
else :
    print("isSecondaryPull INVALID"+isSecondaryPull)

# COMMAND ----------

print("output : "+output)
output_temp=output+"_temp"
print("output_temp : "+output_temp)

# COMMAND ----------

if isSecondaryPull == "1":
    if tablename in ['reportwarehousemedicaideligiblepaes']: #hot fix for prod failure
        data_primary = data_primary.withColumn("MedicaidCoverageIFK", col("MedicaidCoverageIFK").cast("string"))
        data_primary.write.mode("overwrite").parquet(output_temp)
        data_primary.unpersist()
        print("WRITING DONE : data_primary")
        data_secondary = data_secondary.withColumn("MedicaidCoverageIFK", col("MedicaidCoverageIFK").cast("string"))
        data_secondary.write.mode("append").parquet(output_temp)
        data_secondary.unpersist()
        print("WRITING DONE : data_secondary")
    elif tablename in ['patientaccteligibilitysubmittals']:
        data_primary = data_primary.withColumn("PatientAcctEligibilitySubmittalPK", col("PatientAcctEligibilitySubmittalPK").cast("string"))
        data_primary.write.mode("overwrite").parquet(output_temp)
        data_primary.unpersist()
        print("WRITING DONE : data_primary")
        data_secondary = data_secondary.withColumn("PatientAcctEligibilitySubmittalPK", col("PatientAcctEligibilitySubmittalPK").cast("string"))
        data_secondary.write.mode("append").parquet(output_temp)
        data_secondary.unpersist()
        print("WRITING DONE : data_secondary")
    else:
        data_primary.write.mode("overwrite").parquet(output_temp)
        data_primary.unpersist()
        print("WRITING DONE : data_primary")
        data_secondary.write.mode("append").parquet(output_temp)
        data_secondary.unpersist()
        print("WRITING DONE : data_secondary")        
elif isSecondaryPull == "0":
    data_primary.write.mode("overwrite").parquet(output_temp)
    data_primary.unpersist()
    print("WRITING DONE : data_primary")
else:
    print("INVALID isSecondaryPull")

# COMMAND ----------

if tablename in ['reportwarehousemedicaideligiblepaes']:
    print("reportwarehousemedicaideligiblepaes")
    data = spark.read.parquet(output_temp)
    data = data.withColumn(
        "IsDeleted",
        when(col("IsDeleted") == True, '1')
        .when(col("IsDeleted") == False, '0')
        .otherwise(col("IsDeleted").cast("string"))
    )
    data.dropDuplicates().repartition(25).write.mode("overwrite").parquet(output)
    data.unpersist()
    data = spark.read.parquet(output)
    print("COUNT " + str(data.count()))
    data.unpersist()
else:
    data = spark.read.parquet(output_temp)
    for column in data.columns:
        data = data.withColumn(column, trim(col(column)))
        data = data.withColumn(column, when(col(column).isNull(), None).otherwise(col(column)))
        data = data.withColumn(column, when(col(column) == 'null', None).otherwise(col(column)))
        data = data.withColumn(column, when(col(column) == '', None).otherwise(col(column)))
        data = data.withColumn(column, when(col(column) == 'true', '1').when(col(column) == 'false', '0').otherwise(col(column)))
    data.dropDuplicates().repartition(25).write.mode("overwrite").parquet(output)
    data.unpersist()
    data = spark.read.parquet(output)
    data.printSchema()
    print("COUNT " + str(data.count()))
    data.unpersist()