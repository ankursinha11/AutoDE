# Databricks notebook source
# MAGIC %run "/Insleads-code/dataingestion/abi/dataingestion_sharding" 

# COMMAND ----------

import sys
import os
import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import datetime
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
from pyspark import SparkContext
from pyspark.conf import SparkConf
import subprocess
from delta import *
from pyspark.sql.functions import collect_list
from pyspark.sql.functions import col
from pyspark.sql.types import TimestampType

# aid_hospitalattributefk = ["139", "145"]
aid_hospitalattributefk = ["145"]

# COMMAND ----------

def get_participating_hospitals(path_hospitalattributevalues,path_hospitalattributes) :
  hospitalattributes = spark.read.format("parquet").load(path_hospitalattributes)
  hospitalattributes = hospitalattributes.selectExpr("hospitalattributepk as hospitalattributefk","attributename","attributedescription").dropDuplicates()
  hospitalattributes = hospitalattributes.filter(col("hospitalattributefk").isin(aid_hospitalattributefk))
  hospitalattributevalues = spark.read.format("parquet").load(path_hospitalattributevalues)
  hospitalattributevalues = hospitalattributevalues.selectExpr("hospitalattributefk","hospitalfk","hospitalattributevalue").dropDuplicates()
  hospitalattributevalues = hospitalattributevalues.filter(col("hospitalattributefk").isin(aid_hospitalattributefk))
  participating_hospitals = hospitalattributes.join(hospitalattributevalues, ["hospitalattributefk"]).select(
    hospitalattributes.hospitalattributefk,
    hospitalattributes.attributename,
    hospitalattributes.attributedescription,
    hospitalattributevalues.hospitalattributevalue,
    hospitalattributevalues.hospitalfk,
)
  return participating_hospitals


def get_aidpatientaccts(path_aidpatientaccts) :
    try:
        aidpatientaccts = spark.read.format("delta").load(path_aidpatientaccts)
    except:
        schema = StructType(
        [
            StructField("patientacctipk", StringType(), True),
            StructField("patientacctifk", StringType(), True),
            StructField("hospitalfk", StringType(), True),
            StructField("hospitalattributefk", StringType(), True),
            StructField("admitdate", StringType(), True),
            StructField("trgupdatedate", StringType(), True),
            StructField("bccreated", StringType(), True),
            StructField("bcupdated", StringType(), True),
        ]
    )
        aidpatientaccts = spark.createDataFrame([], schema)
    return aidpatientaccts

def list_to_string(lst):
    return ','.join(map(str, lst))


# COMMAND ----------

def getColumnOrder(tablename):
    if tablename == 'patientaccts':
        cols = [
            'patientacctpk', 'acctnum', 'admitdate', 'dischargedate', 'referraldate', 'firstname', 'lastname', 'middlename', 'suffix',
            'addr1', 'addr2', 'city', 'state', 'zip', 'county', 'phone1', 'phone2', 'dob', 'ssn', 'gender', 'dod', 'medicalrecnum',
            'medicaidnum', 'totalcharges', 'currentbalance', 'currentstatus', 'createdate', 'updatedate', 'statusdate', 'patientacctipk',
            'clusteredacctfk', 'demographicschecksum', 'demographicsupdatedate', 'trgupdatedate', 'momsacctnum', 'updatepatientacctsimportfilepartfk',
            'facilitycode', 'totalpayments', 'totaladjustments', 'medicarehic', 'hospitalfacilitycodefk', 'hospitalfk'
        ]
    elif tablename == 'patientacctscodes':
        cols = [
            'patientacctifk', 'active', 'patientacctfk', 'ifccodefk', 'mcaid', 'mcaidpending', 'visittypefk', 'source', 'acctlocator',
            'admitdiagnosis', 'admitsource', 'admittype', 'agency', 'dischargedesttype', 'dischargediagnosis', 'finclassreferred',
            'finclasscurrent', 'insurancecode1', 'insurancecode2', 'insurancecode3', 'insurancecode4', 'maritalstatus', 'patienttype',
            'primarydiagnosis', 'race', 'servicetype', 'collector', 'alien', 'baddebt', 'charity', 'createdate', 'updatedate',
            'firstimportdate', 'lastimportdate', 'ifcdate', 'useractive', 'usermcaid', 'usermcaidpending', 'createpatientacctsimportfilepartfk',
            'updatepatientacctsimportfilepartfk', 'primarycptcode', 'paidamt', 'paymentadjamt', 'trgupdatedate', 'hospsourcesystemname',
            'diagnosiscode2', 'diagnosiscode3', 'diagnosiscode4', 'diagnosiscode5', 'diagnosiscode6', 'diagnosiscode7', 'diagnosiscode8',
            'diagnosiscode9', 'diagnosiscode10', 'diagnosiscode11', 'diagnosiscode12', 'diagnosiscode13', 'diagnosiscode14',
            'acctexclusionreasonfk', 'collectionagencycode', 'usermcare', 'usermcarecoversservice', 'insurancecode5', 'insurancecode6',
            'insurancecode7', 'ins1policyid', 'ins2policyid', 'ins3policyid', 'ins4policyid', 'ins5policyid', 'ins6policyid', 'ins7policyid',
            'attendingphynname', 'workingdrg', 'finaldrg', 'hospitalfacilitycodefk', 'hospitalfk'
        ]
    elif tablename == 'vsnappatientacctsflags':
        cols = [
            'vsnappatientacctsflagspk', 'hospitalfk', 'patientacctifk', 'patientacctscodesupdatedate', 'insurancecodeupdatedate',
            'finclasscodeupdatedate', 'knownmcaidflag', 'pendingmcaidflag', 'primarymcaidflag', 'primarymcaid_charityflag',
            'primarymcaid_baddebtflag', 'primarymcaid_arflag', 'secondarymcaidflag', 'secondarymcaid_afterworkcompflag',
            'secondarymcaid_aftermcareflag', 'secondarymcaid_afterinsuranceflag', 'createdate', 'hasmedicareflag',
            'acctlocatorcodeupdatedate', 'agencycodeupdatedate', 'outofstatemcaidflag', 'collectionagencycodeupdatedate',
            'charitytransflag', 'paymentcodeupdatedate', 'hasrelatedpendingmcaidacct', 'baddebttransflag', 'mcaidtransflag',
            'knowntricareflag', 'tricaretransflag', 'mcaretransflag', 'hasbillablerevcode', 'mcarecrossoverdate', 'billingindicatorcodeupdatedate'
        ]
    else:
        cols = []
    return cols

# COMMAND ----------

# aidpatientaccts = spark.read.format("delta").load(path_aidpatientaccts)
# aidpatientaccts = aidpatientaccts.withColumn("bccreated",lit('20251016T10')).withColumn("bcupdated",lit('20251016T10'))
# aidpatientaccts = aidpatientaccts.limit(12)
# aidpatientaccts.write.mode("overwrite").format("delta").save(path_aidpatientaccts)

# COMMAND ----------

def aid_cdc(fetched_data_combined,epic_hospitalattributevalues):
    print("Count : fetched_data_combined : "+ "{:,}".format(fetched_data_combined.count()))
    aidpatientaccts = get_aidpatientaccts(path_aidpatientaccts)
    today = (
       fetched_data_combined
       .select("patientacctipk", "hospitalfk", "admitdate", "trgupdatedate")
       .withColumn("patientacctifk", col("patientacctipk"))
       .join(epic_hospitalattributevalues.select("hospitalfk", "hospitalattributefk"), on="hospitalfk", how="left")
       .withColumn(
           "hospitalattributefk",
           when(col("hospitalattributefk").isNull(), lit("PCORD")).otherwise(lit("EPIC"))
       )
       .select("patientacctipk", "patientacctifk", "hospitalfk", "hospitalattributefk", "admitdate", "trgupdatedate")
       .dropDuplicates()
)
    print("Count : today : "+ "{:,}".format(today.count()))

    today_deleted = aidpatientaccts.join(
        today,
        (aidpatientaccts.hospitalfk == today.hospitalfk) &
        (aidpatientaccts.patientacctipk == today.patientacctipk),
        "leftanti"
    ).select(*[aidpatientaccts[col] for col in aidpatientaccts.columns])
    print("Count : today_deleted : "+ "{:,}".format(today_deleted.count()))

    today_intact = today.join(
        aidpatientaccts,
        (today.hospitalfk == aidpatientaccts.hospitalfk) &
        (today.patientacctipk == aidpatientaccts.patientacctipk) &
        (today.trgupdatedate.cast("timestamp") == aidpatientaccts.trgupdatedate.cast("timestamp")),
        "inner"
    ).select(*[today[col] for col in today.columns], aidpatientaccts.bccreated, aidpatientaccts.bcupdated)
    print("Count : today_intact : "+ "{:,}".format(today_intact.count()))

    today_update = today.join(
        aidpatientaccts,
        (today.hospitalfk == aidpatientaccts.hospitalfk) &
        (today.patientacctipk == aidpatientaccts.patientacctipk) &
        (today.trgupdatedate.cast("timestamp") > aidpatientaccts.trgupdatedate.cast("timestamp")),
        "inner"
    ).select(*[today[col] for col in today.columns], aidpatientaccts.bccreated).withColumn("bcupdated", lit(bc))
    print("Count : today_update : "+ "{:,}".format(today_update.count()))

    today_insert = today.join(
        aidpatientaccts,
        (today.hospitalfk == aidpatientaccts.hospitalfk) &
        (today.patientacctipk == aidpatientaccts.patientacctipk),
        "leftanti"
    ).select(*[today[col] for col in today.columns]).withColumn("bccreated", lit(bc)).withColumn("bcupdated", lit(bc))
    print("Count : today_insert : "+ "{:,}".format(today_insert.count()))

    today_whole = today_deleted.union(today_update).union(today_insert).union(today_intact)
    return today_whole

# COMMAND ----------

# bc = "20251016T13"
# container = "prod-icd-stg-adls"
# path_conn_file = "jdbc:sqlserver://iblsql3.nthrive.nthcrp.com;user=app_databricks;password=XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX;trustServerCertificate=true"
# publishpath = "/data/dataingestion/staging/input/"
# storageaccount = "prodicdstgdls"
# tablename = "patientaccts"
# user = "maxc"
# extractdays = "48"
# patientaccts_check ="1"

# bc = "20250430T21"
# container = "prod-icd-stg-adls"
# path_conn_file = "jdbc:sqlserver://iblsql3.nthrive.nthcrp.com;user=app_databricks;password=XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX;trustServerCertificate=true"
# publishpath = "/data/dataingestion/staging/input/"
# storageaccount = "prodicdstgdls"
# tablename = "patientacctscodes"
# user = "maxc"
# extractdays = "48"
# patientaccts_check ="1"

# COMMAND ----------

dbutils.widgets.text("tablename","")
dbutils.widgets.getArgument("tablename")
tablename= getArgument("tablename")

dbutils.widgets.text("path_conn_file", "")
dbutils.widgets.getArgument("path_conn_file")
path_conn_file= getArgument("path_conn_file")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("publishpath","")
dbutils.widgets.getArgument("publishpath")
publishpath= getArgument("publishpath")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("extractdays","")
dbutils.widgets.getArgument("extractdays")
extractdays= getArgument("extractdays")

dbutils.widgets.text("patientaccts_check","")
dbutils.widgets.getArgument("patientaccts_check")
patientaccts_check= getArgument("patientaccts_check")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

output = baseurl+"/"+publishpath+"/"+tablename+"/"+bc
path_patientacctsaccesscoordinator = baseurl + "/data/dataingestion/publish/patientacctsaccesscoordinator/current/20991231/"
path_patientaccts = baseurl + "/data/dataingestion/publish/patientaccts/current/20991231/"
path_hospitalattributevalues = baseurl + "/data/dataingestion/publish/hospitalattributevalues/current/20991231/"
path_hospitalattributes = baseurl + "/data/dataingestion/publish/hospitalattributes/current/20991231/"
path_aidpatientaccts = baseurl + "/data/dataingestion/publish/aidpatientaccts/current/20991231/"
output_temp = output+"_temp"
patientaccts_check=str(patientaccts_check)
output_aid_temp = output+"_aid_temp"


print("baseurl                            : "+baseurl)
print("tablename                          : "+tablename)
print("path_patientacctsaccesscoordinator : "+path_patientacctsaccesscoordinator)
print("path_patientaccts                  : "+path_patientaccts)
print("bc                                 : "+str(bc))
print("output_temp                        : "+output_temp)
print("output                             : "+output)
print("patientaccts_check                 : "+patientaccts_check)
print("output_aid_temp                    : "+output_aid_temp)
print("path_hospitalattributevalues       : "+path_hospitalattributevalues)
print("path_hospitalattributes            : "+path_hospitalattributes)
print("path_aidpatientaccts               : "+path_aidpatientaccts)
print("extractdays                        : "+str(extractdays))

spark.conf.set("spark.sql.shuffle.partitions","auto")

# COMMAND ----------

# DBTITLE 1,HOSP LIST
patientacctsaccesscoordinator = spark.read.format("parquet").load(path_patientacctsaccesscoordinator).selectExpr("patientacctifk", "patientacctifk as patientacctipk", "hospitalfk").dropDuplicates().cache()
patientacctsaccesscoordinator_hospital_list = patientacctsaccesscoordinator.select("hospitalfk").distinct().agg(collect_list("hospitalfk").alias("hospitalfk_list")).first()["hospitalfk_list"]



epic_hospitalattributevalues = get_participating_hospitals(path_hospitalattributevalues, path_hospitalattributes).filter(col("hospitalattributevalue") == "1").select("hospitalfk", "hospitalattributefk").dropDuplicates()
epic_hospitalattributevalues = epic_hospitalattributevalues.select("hospitalfk", "hospitalattributefk").dropDuplicates()
epic_hospitals_list = epic_hospitalattributevalues.select("hospitalfk").distinct().agg(collect_list("hospitalfk").alias("hospitalfk_list")).first()["hospitalfk_list"]



aid_hospital_list = list(set(patientacctsaccesscoordinator_hospital_list) | set(epic_hospitals_list))


epic_hospitals_list = list_to_string(epic_hospitals_list)
patientacctsaccesscoordinator_hospital_list = list_to_string(patientacctsaccesscoordinator_hospital_list)
aid_hospital_list = list_to_string(aid_hospital_list)

print("epic_hospitals_list : " + str(epic_hospitals_list))
print("patientacctsaccesscoordinator_hospital_list : " + str(patientacctsaccesscoordinator_hospital_list))
print("aid_hospital_list : " + str(aid_hospital_list))

# COMMAND ----------

table_extract_hour = 48

valid_tables = {
    'patientaccts': ('escan.dbo.patientaccts', 'TrgUpdateDate'),
    'vsnappatientacctsflags': ('escandm.dbo.vsnappatientacctsflags', 'CreateDate'),
    'patientacctscodes': ('escan.dbo.patientacctscodes', 'CreateDate')
}

if tablename in valid_tables:
    table, date_col = valid_tables[tablename]
    query = (
        f"SELECT * FROM {table} (NOLOCK) "
        f"WHERE hospitalfk IN ({aid_hospital_list}) "
        f"AND {date_col} >= dateadd(HOUR,-{table_extract_hour},CURRENT_TIMESTAMP)"
    )
else:
    print(f"tablename : {tablename} : invalid")
    print("query : not found")
    print("reconciliation flag set to false : 0")
    reconcile_flag = 0
    dbutils.notebook.exit(reconcile_flag)

print("query : " + str(query))

# COMMAND ----------

shard = get_shard_server_list()
shard.display()
if shard.rdd.isEmpty():
    print("No shard servers found. Exiting.")
    dbutils.notebook.exit(1)

# COMMAND ----------

print("output_temp : " + output_temp)
process_shard_data(tablename, query, output_temp)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Divide the dataframe in epicAid and cordinatorAid

# COMMAND ----------

fetched_data = spark.read.parquet(output_temp)
epic_hospitals_set = set(epic_hospitals_list.split(","))
coordinator_hospitals_set = set(patientacctsaccesscoordinator_hospital_list.split(","))
all_hospitals_set = epic_hospitals_set | coordinator_hospitals_set

if tablename == 'patientaccts':
    fetched_data = fetched_data.filter(col("hospitalfk").isin(list(all_hospitals_set))).withColumn("admitdate_ts", col("admitdate").cast("timestamp"))
    fetched_data_epic = fetched_data.filter((col("hospitalfk").isin(list(epic_hospitals_set))) & (col("admitdate_ts") > current_timestamp()))
    fetched_data_cordinator = fetched_data.filter(col("hospitalfk").isin(list(coordinator_hospitals_set)))
    fetched_data_cordinator = fetched_data_cordinator.join(patientacctsaccesscoordinator, ["hospitalfk", "patientacctipk"],"inner").select(*[fetched_data_cordinator[col] for col in fetched_data_cordinator.columns])
    fetched_data_combined = fetched_data_epic.unionByName(fetched_data_cordinator).drop("admitdate_ts").dropDuplicates()
    fetched_data_cdc = aid_cdc(fetched_data_combined,epic_hospitalattributevalues)
    # Updating the AID PA table 
    fetched_data_cdc.write.mode("overwrite").format("delta").save(path_aidpatientaccts)
    # Fetching updated Records from AID PA table 
    fetched_data_cdc = spark.read.format("delta").load(path_aidpatientaccts).filter(col("bcupdated") == lit(bc)).selectExpr("hospitalfk", "patientacctipk")
    if fetched_data_cdc.count() > 0 :
        print("New AID PA found : reconcile_flag : 1")
        reconcile_flag = 1
        fetched_data_combined_write = fetched_data_combined.join(fetched_data_cdc,["hospitalfk", "patientacctipk"],"inner").select(*[fetched_data_combined[col] for col in fetched_data_combined.columns])
        orderedCols=getColumnOrder(tablename)
        fetched_data_combined_write = fetched_data_combined_write.selectExpr(orderedCols).drop("isdeleted").withColumn("IsDeleted",lit('0'))
        fetched_data_combined_write.write.mode("append").format("parquet").save(output)
    else:
        print("No new AID PA found : reconcile_flag : 0")
        reconcile_flag = 0
else:
    fetched_data = fetched_data.filter(col("hospitalfk").isin(list(all_hospitals_set)))
    orderedCols=getColumnOrder(tablename)
    fetched_data = fetched_data.selectExpr(orderedCols).drop("isdeleted").withColumn("IsDeleted",lit('0'))
    if fetched_data.count() > 0:
        print("New Records found : reconcile_flag : 1")
        reconcile_flag = 1
        fetched_data.write.mode("append").format("parquet").save(output)
    else:
        print("No new Records found : reconcile_flag : 0")
        reconcile_flag = 0

# COMMAND ----------

dbutils.notebook.exit(reconcile_flag)

# COMMAND ----------


