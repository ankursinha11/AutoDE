# Databricks notebook source
# MAGIC %run "/Insleads-code/dataingestion/abi/dataingestion_sharding" 

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
from pyspark.sql.functions import when, col, lit
from pyspark.sql.functions import regexp_replace

spark.conf.set("spark.sql.shuffle.partitions", "auto")
spark.conf.set("spark.databricks.io.cache.enabled", "true")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Input Params Capturing

# COMMAND ----------

dbutils.widgets.text("tablename", "")
dbutils.widgets.getArgument("tablename")
tablename = getArgument("tablename")

dbutils.widgets.text("container", "")
dbutils.widgets.getArgument("container")
container = getArgument("container")

dbutils.widgets.text("storageaccount", "")
dbutils.widgets.getArgument("storageaccount")
storageaccount = getArgument("storageaccount")

dbutils.widgets.text("user", "")
dbutils.widgets.getArgument("user")
user = getArgument("user")

dbutils.widgets.text("bc", "")
dbutils.widgets.getArgument("bc")
bc = getArgument("bc")

# COMMAND ----------

# STAGE

# tablename = "patientaccts"
# container = "prod-icd-stg-adls"
# storageaccount = "prodicdstgdls"
# user = "maxc"
# bc = "20250922T16"

# COMMAND ----------

# MAGIC %md
# MAGIC ### User Config Settings & Intiliazation

# COMMAND ----------

container = str(container)
storageaccount = str(storageaccount)
user = str(user)

username = "" if user == "na" else user
print(f"username                  : {'**PROD**' if user == 'na' else username}")

base_url = f"abfss://{container}@{storageaccount}.dfs.core.windows.net/{username}/"
path_metadata = f"{base_url}data/dataingestion/publish/metadata/current/20991231/"
path_staging_intermediate = f"{base_url}data/dataingestion/staging/intermediate/{tablename}/{bc}/"
path_staging_input = f"{base_url}data/dataingestion/staging/input/{tablename}/{bc}/"
path_publish = f"{base_url}data/dataingestion/publish/{tablename}/current/20991231/"

spark.conf.set(
    f"fs.azure.account.key.{storageaccount}.dfs.core.windows.net",
    dbutils.secrets.get(scope="icd-insleads-dbwscope", key="icd-adls-insleads-kvsecret")
)

if tablename.lower() in {"nexusconfig", "nexusfeatures", "nexusservers", "nexusscope"}:
    path_conn_file = dbutils.secrets.get(scope="icd-insleads-dbwscope", key="icd-dbx-nexusdb-connection")
else:
    path_conn_file = dbutils.secrets.get(scope="icd-insleads-dbwscope", key="icd-dataingestion-sql-insleads-cs")

print(f"base_url                  : {base_url}")
print(f"path_metadata             : {path_metadata}")
print(f"path_staging_intermediate : {path_staging_intermediate}")
print(f"path_staging_input        : {path_staging_input}")
print(f"path_publish              : {path_publish}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Extract SHARD info

# COMMAND ----------

shard = get_shard_server_list()
shard.display()
if shard.rdd.isEmpty():
    print("No shard servers found. Exiting.")
    dbutils.notebook.exit(1)

# COMMAND ----------

metadata = spark.read.format("delta").load(path_metadata)
meta_row = metadata.filter(col("table_primary") == tablename).limit(1).collect()

if meta_row:
    meta = meta_row[0]
    print("Valid table_primary             : " + str(tablename))
else:
    dbutils.notebook.exit("Invalid table_primary : " + str(tablename))

# COMMAND ----------

# DBTITLE 1,READING CONFIG
def print_table_info(
    table_primary, table_active, table_loadtype, table_shardtype, table_threads,
    table_extract_hour, table_primary_keys, table_range_keys, table_primary_query, op_primary,
    table_secondary, table_secondary_query, op_secondary,
    table_tertiary, table_tertiary_query, op_tertiary,
    table_view_upsert, table_view_delete
):
    print(f"table_primary         : {table_primary}")
    print(f"table_active          : {table_active}")
    print(f"table_loadtype        : {table_loadtype}")
    print(f"table_shardtype       : {table_shardtype}")
    print(f"table_threads         : {table_threads}")
    print(f"table_extract_hour    : {table_extract_hour}")
    print(f"table_primary_keys    : {table_primary_keys}")
    print(f"table_range_keys      : {table_range_keys}")
    print(f"table_primary_query   : {table_primary_query}")
    print(f"op_primary            : {op_primary}\n")

    if table_secondary:
        print(f"table_secondary       : {table_secondary}")
        print(f"table_secondary_query : {table_secondary_query}")
        print(f"op_secondary          : {op_secondary}\n")
    else:
        print("table_secondary       : N/A\n")

    if table_tertiary:
        print(f"table_tertiary        : {table_tertiary}")
        print(f"table_tertiary_query  : {table_tertiary_query}")
        print(f"op_tertiary           : {op_tertiary}\n")
    else:
        print("table_tertiary        : N/A\n")

    print(f"table_view_upsert     : {table_view_upsert if table_view_upsert else 'N/A'}\n")
    print(f"table_view_delete     : {table_view_delete if table_view_delete else 'N/A'}\n")

table_primary         = meta["table_primary"]
table_active          = meta["table_active"]
table_loadtype        = meta["table_loadtype"]
table_shardtype       = meta["table_shardtype"]
table_primary_keys    = meta["table_primary_keys"]
table_primary_query   = meta["table_primary_query"]
table_view_upsert     = meta["table_view_upsert"]
table_view_delete     = meta["table_view_delete"]
table_threads         = meta["table_threads"]
table_secondary       = meta["table_secondary"]
table_secondary_query = meta["table_secondary_query"]
table_tertiary        = meta["table_tertiary"]
table_tertiary_query  = meta["table_tertiary_query"]
table_extract_hour    = meta["table_extract_hour"]
table_range_keys      = meta["table_range_keys"]

jdbc_options = {"url": path_conn_file, "numPartitions": table_threads}

extractExpression = "" if table_loadtype == 'fnf' else f" dateadd(HOUR,-{table_extract_hour},CURRENT_TIMESTAMP)"

table_primary_query = table_primary_query + extractExpression
op_primary = f"{path_staging_intermediate}/{table_primary}/"

op_secondary = ""
if table_secondary:
    table_secondary_query = table_secondary_query + extractExpression
    op_secondary = f"{path_staging_intermediate}/{table_secondary}/"

op_tertiary = ""
if table_tertiary:
    table_tertiary_query = table_tertiary_query + extractExpression
    op_tertiary = f"{path_staging_intermediate}/{table_tertiary}/"

print_table_info(
    table_primary, table_active, table_loadtype, table_shardtype, table_threads,
    table_extract_hour, table_primary_keys, table_range_keys, table_primary_query, op_primary,
    table_secondary, table_secondary_query, op_secondary,
    table_tertiary, table_tertiary_query, op_tertiary,
    table_view_upsert, table_view_delete
)

# COMMAND ----------

if table_active=='Y':
    print("Table is active : "+str(table_primary))
else :
    print("Table is NOT active : "+str(table_primary))
    dbutils.notebook.exit(0)

# COMMAND ----------

# def getLiveData(tablename) :
#     query ="SELECT * FROM escan.dbo."+tablename
#     #pointing to Nexus
#     # path_conn_file = dbutils.secrets.get(scope="icd-insleads-dbwscope", key="icd-dbx-nexusdb-connection")
#     # jdbc_options = {"url": path_conn_file, "numPartitions": 1}
#     # query = query.replace("escan.dbo", "nexus.config")
#     path_conn_file = dbutils.secrets.get(scope="icd-insleads-dbwscope", key="icd-dataingestion-sql-insleads-cs")
#     jdbc_options={"url": path_conn_file, "numPartitions": 1}
#     data = spark.read.format("jdbc").options(**jdbc_options).option("query", query).load()
#     for column in data.columns:
#         data = data.withColumn(column, trim(col(column)))
#         data = data.withColumn(column, when(col(column).isNull(), None).otherwise(col(column)))
#         data = data.withColumn(column, when(col(column) == 'null', None).otherwise(col(column)))
#         data = data.withColumn(column, when(col(column) == '', None).otherwise(col(column)))
#         data = data.withColumn(column, when(col(column) == 'true', '1').when(col(column) == 'false', '0').otherwise(col(column)))
#     data = lowercase_all_columns(data)
#     return data

# COMMAND ----------

def overWriteUcTables(tablename,user,data_df) :
    data_df = data_df.withColumn("bc", lit(bc))
    data_df = data_df.withColumn("bcupdated", lit(bc))
    if user == 'na':
        catalog_name = "prod_icd_leadgen_catalog"
    else :
        catalog_name = "prod_icd_stg_leadgen_catalog"
    print("catalog_name : "+str(catalog_name))
    publish_schema = 'dataingestion'
    publish_table = catalog_name + "." + publish_schema + "." + tablename
    print("publish_table : "+str(publish_table))
    # Ensure the schema of the DataFrame matches the schema of the target table
    target_schema = spark.table(publish_table).schema
    data_df = data_df.select(*[col for col in data_df.columns if col in target_schema.fieldNames()])
    # Cast columns to match the target schema
    for field in target_schema:
        if field.name in data_df.columns:
            data_df = data_df.withColumn(field.name, data_df[field.name].cast(field.dataType))
    data_df.write.mode("overwrite").saveAsTable(publish_table)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Handling patientacctsaccesscoordinator

# COMMAND ----------

if table_loadtype == "fnf" and table_primary == "patientacctsaccesscoordinator":
    extract_query = table_primary_query
    try:
        dbutils.fs.rm(path_publish, True)
        print(f"Deleted {table_primary} from {path_publish}")
    except Exception:
        dbutils.fs.mkdirs(path_publish)
    print(f"Extracting shard data for {table_primary}")
    try:
        process_shard_data(table_primary, extract_query, path_publish)
        data = spark.read.parquet(path_publish)
        if data.rdd.isEmpty():
            raise Exception("DataFrame is empty. Both shards empty.")
        print(f"SUCCESS {table_primary} with shard data")
        dbutils.notebook.exit(0)
    except Exception as e:
        print(f"Error processing shard data for {table_primary}: {e}")

# COMMAND ----------

# DBTITLE 1,FNF
if table_loadtype == "fnf" :
    nexus_conn_file = dbutils.secrets.get(scope="icd-insleads-dbwscope", key="icd-dbx-nexusdb-connection")
    jdbc_options = {"url": nexus_conn_file, "numPartitions": 1}
    print("table_primary_query : "+str(table_primary_query))
    data=spark.read.format("jdbc").options(**jdbc_options).option("query", table_primary_query).load()
    for column in data.columns:
        data = data.withColumn(column, trim(col(column)))
        data = data.withColumn(column, when(col(column).isNull(), None).otherwise(col(column)))
        data = data.withColumn(column, when(col(column) == 'null', None).otherwise(col(column)))
        data = data.withColumn(column, when(col(column) == '', None).otherwise(col(column)))
        data = data.withColumn(column, when(col(column) == 'true', '1').when(col(column) == 'false', '0').otherwise(col(column)))
    data = lowercase_all_columns(data)    
    if "hospitalfk" in data.columns and tablename != 'hospitalpurge':
        print("hospitalfk in dataframe absolute_view : hospital purge check : true")
        hospitalpurge = spark.read.format("parquet").load(base_url + "/data/dataingestion/publish/hospitalpurge/current/20991231/").filter("active=='1'").selectExpr("hospitalfk").dropDuplicates()
        # hospitalpurge = getLiveData("hospitalpurge").filter("active=='1'").selectExpr("hospitalfk").dropDuplicates()
        data = data.join(hospitalpurge, "hospitalfk", "leftanti").select(*[data[col] for col in data.columns])
    data.repartition(1).write.mode("overwrite").format("parquet").save(path_publish)
    data.unpersist()
    # adding UC writes for FNF
    data=spark.read.format("parquet").load(path_publish)
    if tablename in ["patientmatchingblockallowgmrn", "nexusconfig", "nexusfeatures", "nexusservers", "nexusscope"]:
        overWriteUcTables(tablename,user,data)
        print("FNF table : "+str(table_primary) + "PUBLISHED + UC Published")
    else :
        print("FNF table : "+str(table_primary) + "PUBLISHED")
    dbutils.notebook.exit(0)
else :
    print("NON FNF table : "+str(table_primary))
    hospitals = spark.read.format("parquet").load(base_url + "/data/dataingestion/publish/hospitals/current/20991231/")
    # hospitals = getLiveData("hospitals")
    hospitalpurge = spark.read.format("parquet").load(base_url + "/data/dataingestion/publish/hospitalpurge/current/20991231/").filter("active=='1'").selectExpr("hospitalfk").dropDuplicates()
    # hospitalpurge = getLiveData("hospitalpurge").filter("active=='1'").selectExpr("hospitalfk").dropDuplicates()
    hospitals.createOrReplaceTempView("hospitals")
    hospitalpurge.createOrReplaceTempView("hospitalpurge")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Extract data : primary + secondary + **tertiary**

# COMMAND ----------

from concurrent.futures import ThreadPoolExecutor

with ThreadPoolExecutor(max_workers=3) as executor:
    future_primary = executor.submit(process_shard_data, table_primary, table_primary_query, op_primary)
    future_secondary = executor.submit(process_shard_data, table_secondary, table_secondary_query, op_secondary)
    future_tertiary = executor.submit(process_shard_data, table_tertiary, table_tertiary_query, op_tertiary)

    out_primary = future_primary.result()
    out_secondary = future_secondary.result()
    out_tertiary = future_tertiary.result()

# COMMAND ----------

data_primary = process_extracted_table(out_primary, op_primary, table_primary, "data_primary")
data_secondary = process_extracted_table(out_secondary, op_secondary, table_secondary, "data_secondary")
data_tertiary = process_extracted_table(out_tertiary, op_tertiary, table_tertiary, "data_tertiary")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Absolute View Generation : UPSERT + DELETE

# COMMAND ----------

# DBTITLE 1,table_view_upsert
if table_view_upsert == '':
    print("table_view_upsert     : "+"N/A")
else :
    print("table_view_upsert     : GENERATED")
    view_upsert = spark.sql(table_view_upsert)

if table_view_delete == '':
    print("table_view_delete      : "+"N/A")
    absolute_view = view_upsert
    print("table_view_absolute    : GENERATED w UPSERT")
else :
    print("table_view_delete      : GENERATED")
    view_delete = spark.sql(table_view_delete)
    absolute_view = view_upsert.union(view_delete)
    print("table_view_absolute    : GENERATED w UPSERT & DELETE")

# COMMAND ----------

if tablename in ['reportwarehousemedicaideligiblepaes'] :
    absolute_view = absolute_view.select([col(c).cast("string") for c in absolute_view.columns])
else :
    for column in absolute_view.columns:
        absolute_view = absolute_view.withColumn(column, trim(col(column)))
        absolute_view = absolute_view.withColumn(column, when(col(column).isNull(), None).otherwise(col(column)))
        absolute_view = absolute_view.withColumn(column, when(col(column) == 'null', None).otherwise(col(column)))
        absolute_view = absolute_view.withColumn(column, when(col(column) == '', None).otherwise(col(column)))
        absolute_view = absolute_view.withColumn(column, when(col(column) == 'true', '1').when(col(column) == 'false', '0').otherwise(col(column)))

absolute_view = absolute_view.withColumnRenamed("isdeleted", "IsDeleted")

# COMMAND ----------

# DBTITLE 1,hospitalpurge
if "hospitalfk" in absolute_view.columns :
    print("hospitalfk in dataframe absolute_view : hospital purge check : true")
    absolute_view = absolute_view.join(hospitalpurge, "hospitalfk", "leftanti").select(*[absolute_view[col] for col in absolute_view.columns])

# COMMAND ----------

# DBTITLE 1,totalcharges
if "totalcharges" in absolute_view.columns :
    print("totalcharges in dataframe absolute_view")
    absolute_view = absolute_view.withColumn('totalcharges', absolute_view.totalcharges.cast("decimal(32,2)").cast("string"))

# COMMAND ----------

# DBTITLE 1,WRITE
absolute_view.dropDuplicates().repartition(25).write.mode("overwrite").parquet(path_staging_input)
absolute_view.unpersist()

# COMMAND ----------

absolute_view = spark.read.parquet(path_staging_input)
# print("Count : absolute_view : " + "{:,}".format(absolute_view.count()))
absolute_view.unpersist()
