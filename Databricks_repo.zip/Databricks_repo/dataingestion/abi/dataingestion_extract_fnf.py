# Databricks notebook source
# ================================================================================================================================ #
# IMPLEMENTATION                                                                                                                   #
#   OWNERSHIP     : FinThrive ICD RougeOnes                                                                                        #
#   AUTHOR        : Max Chatterjee [max.chatterjee@finthrive.com]                                                                  #
#   SCRIPTNAME    : dataingestion_extract_fnf                                                                                      #
# ================================================================================================================================ #
# HISTORY                                                                                                                          #
#     YYYY-MM-DD: AUTHOR         : VERSION : REQID       : DESCRIPTION                                                             #
#     2025-07-14: Max Chatterjee : 1.0     : IDPRO-13604 : Parallel Data Ingestion for FnF tables using a single cluster           #
#     2025-09-25: Max Chatterjee : 1.0.1   : IDPRO-14922 : Exit notebook if multiple retries fail for a table                      #
# JIRA                                                                                                                             #
# https://finthrive.atlassian.net/browse/IDPRO-13604                                                                               #
# ================================================================================================================================ #

# COMMAND ----------

# MAGIC %run "/Insleads-code/dataingestion/abi/dataingestion_sharding"

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
import datetime
import getpass
import os
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

# COMMAND ----------

dbutils.widgets.text("user", "")
dbutils.widgets.getArgument("user")
user = getArgument("user")

dbutils.widgets.text("bc", "")
dbutils.widgets.getArgument("bc")
bc = getArgument("bc")

dbutils.widgets.text("container", "")
dbutils.widgets.getArgument("container")
container = getArgument("container")

dbutils.widgets.text("storageaccount", "")
dbutils.widgets.getArgument("storageaccount")
storageaccount = getArgument("storageaccount")

# COMMAND ----------

# Sample Inputs STAGE
# user = "maxc"
# bc = "20250408T00"
# container = "prod-icd-stg-adls"
# storageaccount = "prodicdstgdls"

# Sample Inputs PROD
# user = "na"
# bc = "20250408T00"
# container = "prod-icd-adls"
# storageaccount = "prodicddls"

# COMMAND ----------

# Ensure container, storageaccount, and user are strings
container = str(container)
storageaccount = str(storageaccount)
user = str(user)

if user == 'na':  # default value
    base_url = 'abfss://' + container + '@' + storageaccount + '.dfs.core.windows.net/'
else:
    base_url = 'abfss://' + container + '@' + storageaccount + '.dfs.core.windows.net/' + user + "/"

path_metadata = base_url + "/data/dataingestion/publish/metadata/current/20991231/"
path_dataingestion_extract_script = "/Insleads-code/dataingestion/abi/dataingestion_extract"

print("base_url                          : " + base_url)
print("path_metadata                     : " + path_metadata)
print("path_dataingestion_extract_script : " + path_dataingestion_extract_script)

# COMMAND ----------

spark.conf.set("fs.azure.account.key." + storageaccount + ".dfs.core.windows.net",dbutils.secrets.get(scope="icd-insleads-dbwscope", key="icd-adls-insleads-kvsecret"))

# COMMAND ----------

# MAGIC %md
# MAGIC **_hospitalpurge need to be extracted before any other table_**

# COMMAND ----------

dbutils.notebook.run(path_dataingestion_extract_script, 360000, {"tablename": "hospitalpurge", "container": container, "storageaccount": storageaccount, "user": user, "bc": bc})

# COMMAND ----------

# MAGIC %md
# MAGIC **_Read the metadata table to make a list of valid fnf tables for extraction_**

# COMMAND ----------

metadata_fnf = spark.read.format("delta").load(path_metadata).filter("table_shardtype=='N'").filter("table_active=='Y'").filter("table_group_name=='fnf'").selectExpr("id as tablename").sort("tablename")
metadata_fnf = metadata_fnf.filter("tablename!='hospitalpurge'")
# removing hospitalpurge from the list cause it's been extracted in the previous step
# metadata_fnf = metadata_fnf.filter("tablename!='edipayersxstateinsurancenames'")
# msiing in STAGE Nexus but not PROD
metadata_fnf_list = [row['tablename'] for row in metadata_fnf.collect()]
for tablename in metadata_fnf_list:
    print("tablename : "+tablename)

# COMMAND ----------

# MAGIC %md
# MAGIC **_multi threading extraction logic_**

# COMMAND ----------

parallel_thread_count = 10
parallel_wait_sec = 5

def run_notebook(tablename):
    try:
        dbutils.notebook.run(path_dataingestion_extract_script, 360000, {"tablename": tablename, "container": container, "storageaccount": storageaccount, "user": user, "bc": bc})
        return True
    except Exception as e:
        print(f"Run failed for {tablename}. Error: {e}")
        return False

failed_notebooks = {}

def run_with_retry(tablename, retries=1):
    attempt = 0
    print(f"tablename {tablename} (attempt {attempt})...")
    while attempt <= retries:
        if run_notebook(tablename):
            return
        attempt += 1
        print(f"Retrying {tablename} (attempt {attempt})...")
        time.sleep(5)
    print(f"All retries failed for {tablename}.")
    failed_notebooks[tablename] = attempt

# Execute in parallel with retry
with ThreadPoolExecutor(max_workers=parallel_thread_count) as executor:
    futures = {executor.submit(run_with_retry, tablename): tablename for tablename in metadata_fnf_list}
    for future in as_completed(futures):
        tablename = futures[future]
        try:
            future.result()
        except Exception as e:
            print(f"Unhandled exception for {tablename}: {e}")
        time.sleep(parallel_wait_sec)

print("Failed notebooks with multiple attempts:", failed_notebooks)


if not failed_notebooks:
    print("All Threads : Success")
else:
    raise Exception("Multiple retries failed for notebooks")

# COMMAND ----------

shard = get_shard_server_list()
shard.display()
if shard.rdd.isEmpty():
    print("No shard servers found. Exiting.")
    dbutils.notebook.exit(1)

# COMMAND ----------

metadata_fnf = (
    spark.read.format("delta")
    .load(path_metadata)
    .filter("table_shardtype=='Y'")
    .filter("table_active=='Y'")
    .filter("table_group_name=='fnf'")
    .selectExpr("id as tablename", "table_primary_query")
    .sort("tablename")
)

# COMMAND ----------

metadata_fnf_list = metadata_fnf.collect()
for row in metadata_fnf_list:
    tablename = row['tablename']
    extract_query = row['table_primary_query']
    tablename_path = base_url + "/data/dataingestion/publish/" + tablename + "/current/20991231/"
    print("------------------------------------------------------------------------------------------")
    print(f"tablename: {tablename}, extract_query: {extract_query}")
    print("tablename_path :", tablename_path)
    print("extract_query  :", extract_query)
    try:
        dbutils.fs.rm(tablename_path, True)
        print("Deleted " + tablename + " from " + tablename_path)
    except Exception as e:
        print(f"No data to delete for {tablename} from {tablename_path} or error: {e}")
    try:
        print("Extracting shard data for " + tablename)
        result = process_shard_data(tablename, extract_query, tablename_path)
        print("result : " + str(result))
        if result is True:
            print(f"SUCCESS {tablename}")
        else:
            raise Exception("DataFrame is empty. both shard empty.")
        if tablename == "patientmatchingblockallowgmrn":
            data = spark.read.format("parquet").load(tablename_path)
            overWriteUcTables(tablename, user, data)
            print("FNF table : " + str(tablename) + " PUBLISHED + UC Published")
        else:
            print("FNF table : " + str(tablename) + " PUBLISHED")
        print("------------------------------------------------------------------------------------------")
    except Exception as e:
        print(f"Error processing shard data for {tablename}: {e}")

# COMMAND ----------

# ================================================================================================================================ #
# QA Script : To be Disabled before deployment                                                                                     #
#   OWNERSHIP     : FinThrive ICD RougeOnes                                                                                        #
# ================================================================================================================================ #

# for tablename in metadata_fnf_list:
#     tablepath = base_url + "/data/dataingestion/publish/" + tablename + "/current/20991231/"
#     data =spark.read.format("parquet").load(tablepath)
#     print("tablename     : "+tablename)
#     print("tablepath     : "+tablepath)
#     print("tablerowcount : "+str(data.count()))
#     print("=============================================")

# COMMAND ----------


