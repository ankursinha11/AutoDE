# Databricks notebook source
import sys
import os
import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import datetime
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
from pyspark import SparkContext
from pyspark.conf import SparkConf
import subprocess
from delta import *
from pyspark.sql.functions import collect_list
from pyspark.sql.functions import col
from pyspark.sql.types import TimestampType

# aid_hospitalattributefk = ["139", "145"]
aid_hospitalattributefk = ["145"]

# COMMAND ----------

# bc = "20250430T21"
# container = "prod-icd-stg-adls"
# path_conn_file = "jdbc:sqlserver://iblsql3.nthrive.nthcrp.com;user=app_databricks;password=XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX;trustServerCertificate=true"
# publishpath = "/data/dataingestion/staging/input/"
# storageaccount = "prodicdstgdls"
# tablename = "patientaccts"
# user = "maxc"
# extractdays = "48"
# patientaccts_check ="1"

# bc = "20250430T21"
# container = "prod-icd-stg-adls"
# path_conn_file = "jdbc:sqlserver://iblsql3.nthrive.nthcrp.com;user=app_databricks;password=XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX;trustServerCertificate=true"
# publishpath = "/data/dataingestion/staging/input/"
# storageaccount = "prodicdstgdls"
# tablename = "patientacctscodes"
# user = "maxc"
# extractdays = "48"
# patientaccts_check ="1"

# COMMAND ----------

dbutils.widgets.text("tablename","")
dbutils.widgets.getArgument("tablename")
tablename= getArgument("tablename")

dbutils.widgets.text("path_conn_file", "")
dbutils.widgets.getArgument("path_conn_file")
path_conn_file= getArgument("path_conn_file")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("publishpath","")
dbutils.widgets.getArgument("publishpath")
publishpath= getArgument("publishpath")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("extractdays","")
dbutils.widgets.getArgument("extractdays")
extractdays= getArgument("extractdays")

dbutils.widgets.text("patientaccts_check","")
dbutils.widgets.getArgument("patientaccts_check")
patientaccts_check= getArgument("patientaccts_check")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

output = baseurl+"/"+publishpath+"/"+tablename+"/"+bc
path_patientacctsaccesscoordinator = baseurl + "/data/dataingestion/publish/patientacctsaccesscoordinator/current/20991231/"
path_patientaccts = baseurl + "/data/dataingestion/publish/patientaccts/current/20991231/"
path_hospitalattributevalues = baseurl + "/data/dataingestion/publish/hospitalattributevalues/current/20991231/"
path_hospitalattributes = baseurl + "/data/dataingestion/publish/hospitalattributes/current/20991231/"
path_aidpatientaccts = baseurl + "/data/dataingestion/publish/aidpatientaccts/current/20991231/"
output_temp = output+"_temp"
patientaccts_check=str(patientaccts_check)
output_aid_temp = output+"_aid_temp"


print("baseurl                            : "+baseurl)
print("tablename                          : "+tablename)
print("path_patientacctsaccesscoordinator : "+path_patientacctsaccesscoordinator)
print("path_patientaccts                  : "+path_patientaccts)
print("bc                                 : "+str(bc))
print("output_temp                        : "+output_temp)
print("output                             : "+output)
print("patientaccts_check                 : "+patientaccts_check)
print("output_aid_temp                    : "+output_aid_temp)
print("path_hospitalattributevalues       : "+path_hospitalattributevalues)
print("path_hospitalattributes            : "+path_hospitalattributes)
print("path_aidpatientaccts               : "+path_aidpatientaccts)
print("extractdays                        : "+str(extractdays))

spark.conf.set("spark.sql.shuffle.partitions","auto")

# COMMAND ----------

partition_column_lookup = {
    "patientacctscodes": "patientacctifk",
    "patientaccts": "patientacctipk",
    "vsnappatientacctsflags": "patientacctifk"
}

def list_to_string(lst):
    return ','.join(map(str, lst))


def get_extraction_query(tablename,participating_hospitals, extractdays) :
    if tablename in ('patientaccts','patientacctscodes') :
        extraction_query = "SELECT * FROM escan.dbo."+tablename+" (NOLOCK) WHERE HospitalFK IN ("+participating_hospitals+") AND TrgUpdateDate >= dateadd(HOUR,-"+extractdays+",CURRENT_TIMESTAMP)"
    elif tablename =='vsnappatientacctsflags' :
        print("tablename="+str(tablename))
        extraction_query = "SELECT * FROM escandm.dbo."+tablename+" (NOLOCK) WHERE HospitalFK IN ("+participating_hospitals+") AND CreateDate >= dateadd(HOUR,-"+extractdays+",CURRENT_TIMESTAMP)"
    else:
        extraction_query = "INVALID"
    return extraction_query


def get_aidpatientaccts(path_aidpatientaccts) :
    try:
        aidpatientaccts = spark.read.format("delta").load(path_aidpatientaccts)
    except:
        schema = StructType(
        [
            StructField("patientacctipk", StringType(), True),
            StructField("patientacctifk", StringType(), True),
            StructField("hospitalfk", StringType(), True),
            StructField("hospitalattributefk", StringType(), True),
            StructField("admitdate", StringType(), True),
            StructField("trgupdatedate", StringType(), True),
            StructField("bccreated", StringType(), True),
            StructField("bcupdated", StringType(), True),
        ]
    )
        aidpatientaccts = spark.createDataFrame([], schema)
    return aidpatientaccts

def get_participating_hospitals(path_hospitalattributevalues,path_hospitalattributes) :
  hospitalattributes = spark.read.format("parquet").load(path_hospitalattributes)
  hospitalattributes = hospitalattributes.selectExpr("hospitalattributepk as hospitalattributefk","attributename","attributedescription").dropDuplicates()
  hospitalattributes = hospitalattributes.filter(col("hospitalattributefk").isin(aid_hospitalattributefk))
  hospitalattributevalues = spark.read.format("parquet").load(path_hospitalattributevalues)
  hospitalattributevalues = hospitalattributevalues.selectExpr("hospitalattributefk","hospitalfk","hospitalattributevalue").dropDuplicates()
  hospitalattributevalues = hospitalattributevalues.filter(col("hospitalattributefk").isin(aid_hospitalattributefk))
  participating_hospitals = hospitalattributes.join(hospitalattributevalues, ["hospitalattributefk"]).select(
    hospitalattributes.hospitalattributefk,
    hospitalattributes.attributename,
    hospitalattributes.attributedescription,
    hospitalattributevalues.hospitalattributevalue,
    hospitalattributevalues.hospitalfk,
)
  return participating_hospitals


def getColumnOrder(tablename) :
    if tablename=='patientaccts':
        cols = ["patientacctpk", "hospitalfk", "acctnum", "admitdate", "dischargedate", "referraldate", "firstname", "lastname", "middlename", "suffix", "addr1", "addr2", "city", "state", "zip", "county", "phone1", "phone2", "dob", "ssn", "gender", "dod", "medicalrecnum", "medicaidnum", "totalcharges", "currentbalance", "currentstatus", "createdate", "updatedate", "statusdate", "patientacctipk", "clusteredacctfk", "demographicschecksum", "demographicsupdatedate", "trgupdatedate", "momsacctnum", "updatepatientacctsimportfilepartfk", "facilitycode", "totalpayments", "totaladjustments", "medicarehic", "hospitalfacilitycodefk"]
    elif tablename=='patientacctscodes':
        cols = ["hospitalfk", "patientacctifk", "active", "patientacctfk", "ifccodefk", "mcaid", "mcaidpending", "visittypefk", "source", "acctlocator", "admitdiagnosis", "admitsource", "admittype", "agency", "dischargedesttype", "dischargediagnosis", "finclassreferred", "finclasscurrent", "insurancecode1", "insurancecode2", "insurancecode3", "insurancecode4", "maritalstatus", "patienttype", "primarydiagnosis", "race", "servicetype", "collector", "alien", "baddebt", "charity", "createdate", "updatedate", "firstimportdate", "lastimportdate", "ifcdate", "useractive", "usermcaid", "usermcaidpending", "createpatientacctsimportfilepartfk", "updatepatientacctsimportfilepartfk", "primarycptcode", "paidamt", "paymentadjamt", "trgupdatedate", "hospsourcesystemname", "diagnosiscode2", "diagnosiscode3", "diagnosiscode4", "diagnosiscode5", "diagnosiscode6", "diagnosiscode7", "diagnosiscode8", "diagnosiscode9", "diagnosiscode10", "diagnosiscode11", "diagnosiscode12", "diagnosiscode13", "diagnosiscode14", "acctexclusionreasonfk", "collectionagencycode", "usermcare", "usermcarecoversservice", "insurancecode5", "insurancecode6", "insurancecode7", "ins1policyid", "ins2policyid", "ins3policyid", "ins4policyid", "ins5policyid", "ins6policyid", "ins7policyid", "attendingphynname", "workingdrg", "finaldrg", "hospitalfacilitycodefk"]
    elif tablename=='vsnappatientacctsflags':
        cols = ["vsnappatientacctsflagspk", "hospitalfk", "patientacctifk", "patientacctscodesupdatedate", "insurancecodeupdatedate", "finclasscodeupdatedate", "knownmcaidflag", "pendingmcaidflag", "primarymcaidflag", "primarymcaid_charityflag", "primarymcaid_baddebtflag", "primarymcaid_arflag", "secondarymcaidflag", "secondarymcaid_afterworkcompflag", "secondarymcaid_aftermcareflag", "secondarymcaid_afterinsuranceflag", "createdate", "hasmedicareflag", "acctlocatorcodeupdatedate", "agencycodeupdatedate", "outofstatemcaidflag", "collectionagencycodeupdatedate", "charitytransflag", "paymentcodeupdatedate", "hasrelatedpendingmcaidacct", "baddebttransflag", "mcaidtransflag", "knowntricareflag", "tricaretransflag", "mcaretransflag", "hasbillablerevcode", "mcarecrossoverdate", "billingindicatorcodeupdatedate"]
    else :
        cols = []
    return cols

# COMMAND ----------

# DBTITLE 1,DETRMINE PARTITION Column
partition_column = str(partition_column_lookup.get(tablename))

if partition_column == "None":
    print("tablename : " + tablename + " : invalid")
    print("partition_column : not found")
    print("reconciliation flag set to false : 0")
    reconcile_flag=0
    dbutils.notebook.exit(reconcile_flag)
else:
    print("tablename : " + tablename + " : valid ")
    print("partition_column : " + partition_column)

# COMMAND ----------

# DBTITLE 1,READ : patientacctsaccesscoordinator
patientacctsaccesscoordinator=spark.read.format("parquet").load(path_patientacctsaccesscoordinator)
patientacctsaccesscoordinator=patientacctsaccesscoordinator.selectExpr("patientacctifk","patientacctifk as patientacctipk","hospitalfk").dropDuplicates()
patientacctsaccesscoordinator.createOrReplaceTempView("patientacctsaccesscoordinator")
# print("patientacctsaccesscoordinator count whole : " + str(patientacctsaccesscoordinator.count()))

# COMMAND ----------

# DBTITLE 1,DETERMINE : patientacctsaccesscoordinator_participating_hospitals
patientacctsaccesscoordinator_participating_hospitals=spark.sql("""SELECT hospitalfk AS list_hospitalfk FROM patientacctsaccesscoordinator""").dropDuplicates()
patientacctsaccesscoordinator_participating_hospitals=patientacctsaccesscoordinator_participating_hospitals.agg(collect_list("list_hospitalfk")).collect()[0][0]
patientacctsaccesscoordinator_participating_hospitals = list_to_string(patientacctsaccesscoordinator_participating_hospitals)
print("patientacctsaccesscoordinator Partcipating hospitals list : " + str(patientacctsaccesscoordinator_participating_hospitals))

# COMMAND ----------

# DBTITLE 1,READ : patientaccts with participating hospitals
patientaccts=spark.read.format("delta").load(path_patientaccts)
patientaccts=patientaccts.selectExpr("patientacctipk","patientacctipk as patientacctifk","hospitalfk","trgupdatedate","createdate")
patientaccts.createOrReplaceTempView("patientaccts")
sql_patientaccts_filter="SELECT * FROM patientaccts WHERE CAST(hospitalfk AS INT) IN ("+patientacctsaccesscoordinator_participating_hospitals+")"
print("sql_patientaccts_filter : " + str(sql_patientaccts_filter))
patientaccts=spark.sql(sql_patientaccts_filter).dropDuplicates()
# print("patientaccts participating hospitals PA count : " + str(patientaccts.count()))
patientaccts.createOrReplaceTempView("patientaccts")

# COMMAND ----------

# DBTITLE 1,READ : patientacctsaccesscoordinator to PICK MIN MAX
patientacctsaccesscoordinator_min_max = patientacctsaccesscoordinator.agg(min("patientacctifk").alias("MINVAL"),max("patientacctifk").alias("MAXVAL"))
list = patientacctsaccesscoordinator_min_max.collect()[0]
minval = str(list['MINVAL'])
maxval = str(list['MAXVAL'])
patientacctsaccesscoordinator_min_max.unpersist()
min_max=minval+"~"+maxval
min_val=min_max.split("~")[0]
max_val=min_max.split("~")[1]
print("patientacctsaccesscoordinator Partcipating records Min/Max : " + str(min_val)+" / "+str(max_val))

# COMMAND ----------

# DBTITLE 1,POST EXTRACT FILTER QUERY : sql_data_filter_trgupdatedate
# POST EXTRACT FILTER QUERY : sql_data_filter_trgupdatedate
sql_data_filter_trgupdatedate="""
SELECT data.*,
       patientaccts.trgupdatedate AS pa_trgupdatedate,
       CASE
         WHEN (CAST(data.trgupdatedate AS TIMESTAMP) > CAST(patientaccts.trgupdatedate AS TIMESTAMP) OR CAST(patientaccts.trgupdatedate AS TIMESTAMP) IS NULL) THEN '1'
         ELSE '0'
       END AS isDataPullTrue
FROM (SELECT data.*
      FROM data
        INNER JOIN patientacctsaccesscoordinator
                ON data.hospitalfk = patientacctsaccesscoordinator.hospitalfk
               AND data.patientacctipk = patientacctsaccesscoordinator.patientacctipk) data
  LEFT JOIN patientaccts
         ON data.hospitalfk = patientaccts.hospitalfk
        AND data.patientacctipk = patientaccts.patientacctipk
"""


# sql_data_filter_patientacctsaccesscoordinator
sql_data_filter_patientacctsaccesscoordinator="""
SELECT data.*
FROM data
  INNER JOIN patientacctsaccesscoordinator
          ON data.hospitalfk = patientacctsaccesscoordinator.hospitalfk
         AND data.patientacctifk = patientacctsaccesscoordinator.patientacctifk
"""

# COMMAND ----------

# DBTITLE 1,STATS PRINT
sql_data_fetch = get_extraction_query(tablename, patientacctsaccesscoordinator_participating_hospitals, extractdays)
if sql_data_fetch != "INVALID":
    print("tablename       : " + str(tablename))
    print("sql_data_fetch  : " + str(sql_data_fetch))
else:
    print("tablename : invalid")
    print("reconciliation flag set to false : 0")
    reconcile_flag = 0
    dbutils.notebook.exit(reconcile_flag)


# print("sql_data_filter_trgupdatedate : "+str(sql_data_filter_trgupdatedate))
# print("sql_data_filter_patientacctsaccesscoordinator : "+str(sql_data_filter_patientacctsaccesscoordinator))

# COMMAND ----------

# DBTITLE 1,READING DATA FROM SQL SERVER
data = (
    spark.read.format("jdbc")
    .option("url", path_conn_file)
    .option("dbtable", f"({sql_data_fetch}) as subq")
    .option("partitionColumn", partition_column)
    .option("lowerBound", min_val)
    .option("upperBound", max_val)
    .option("numPartitions", 4)
    .load()
)

for column in data.columns:
    new_column = column.lower()
    data = data.withColumnRenamed(column, new_column)

for column in data.columns:
        data = data.withColumn(column, trim(col(column)))
        data = data.withColumn(column, when(col(column).isNull(), None).otherwise(col(column)))
        data = data.withColumn(column, when(col(column) == 'null', None).otherwise(col(column)))
        data = data.withColumn(column, when(col(column) == '', None).otherwise(col(column)))
        data = data.withColumn(column, when(col(column) == 'true', '1').when(col(column) == 'false', '0').otherwise(col(column)))

cols = getColumnOrder(tablename)
data = data.selectExpr(cols)

data = data.drop("isdeleted").withColumn("IsDeleted",lit('0')) 
data.write.mode("overwrite").parquet(output_temp)
data.unpersist()

# COMMAND ----------

# DBTITLE 1,READ DATA FROM TEMP DIR
data=spark.read.parquet(output_temp).dropDuplicates()
# print("Count data : "+ "{:,}".format(data.count()))

# COMMAND ----------

# DBTITLE 1,APPLY FILTER QUERY
if tablename=='patientaccts':
    data = data.withColumn("patientacctipk",col("patientacctipk"))
    data.createOrReplaceTempView("data")
    data=spark.sql(sql_data_filter_trgupdatedate).drop("PatientAcctIFK")
else :
    data.createOrReplaceTempView("data")
    data=spark.sql(sql_data_filter_patientacctsaccesscoordinator).drop("patientacctipk")
    data.createOrReplaceTempView("data")

if tablename == "patientaccts" and patientaccts_check == "1":
    print("patientaccts_check is 1")
    data = data.filter("isDataPullTrue=='1'").drop("isDataPullTrue").drop("pa_TrgUpdateDate")

# COMMAND ----------

data.dropDuplicates().repartition(25).write.mode("append").parquet(output)
data.unpersist()
patientacctsaccesscoordinator.unpersist()
patientaccts.unpersist()

# COMMAND ----------

# MAGIC %md
# MAGIC ## **NEW AID Ingestion**

# COMMAND ----------

participating_hospitals = get_participating_hospitals(path_hospitalattributevalues,path_hospitalattributes)
# display(participating_hospitals)

hospitalattributevalues = participating_hospitals.filter("hospitalattributevalue=='1'").selectExpr("hospitalfk","hospitalattributefk").dropDuplicates()
#display(hospitalattributevalues)

participating_hospitals = participating_hospitals.filter("hospitalattributevalue=='1'").selectExpr("hospitalfk").dropDuplicates()
participating_hospitals_list = participating_hospitals.agg(collect_list("hospitalfk")).collect()[0][0]

participating_hospitals_list = list_to_string(participating_hospitals_list)
print("participating_hospitals_list : " + str(participating_hospitals_list))

# COMMAND ----------

if participating_hospitals.count() > 0 :
    new_aid_pull = 1
    print("new_aid_pull : continue")
else:
    new_aid_pull = 0
    print("NO new_aid_pull")
    previous_aid_data_count = spark.read.parquet(output).count()
    if previous_aid_data_count > 0:
        reconcile_flag = 1
        print("SQL Fetch Reconciliation Flag : " + str(reconcile_flag))
    else:
        reconcile_flag = 0
        print("SQL Fetch Reconciliation Flag : " + str(reconcile_flag))

# COMMAND ----------

if new_aid_pull == 0 and reconcile_flag in (0,1):
    dbutils.notebook.exit(reconcile_flag)
else:
    print("continue")
    extraction_query = get_extraction_query(tablename,participating_hospitals_list, extractdays)
    print("extraction_query : " + extraction_query)

# COMMAND ----------

if extraction_query != "INVALID":
    data = spark.read.format("jdbc").option("url", path_conn_file).option("dbtable", f"({extraction_query}) as subq").option("numPartitions", 10).load()
    for column in data.columns:
        new_column = column.lower()
        data = data.withColumnRenamed(column, new_column)
    for column in data.columns:
            data = data.withColumn(column, trim(col(column)))
            data = data.withColumn(column, when(col(column).isNull(), None).otherwise(col(column)))
            data = data.withColumn(column, when(col(column) == 'null', None).otherwise(col(column)))
            data = data.withColumn(column, when(col(column) == '', None).otherwise(col(column)))
            data = data.withColumn(column, when(col(column) == 'true', '1').when(col(column) == 'false', '0').otherwise(col(column)))
    cols = getColumnOrder(tablename)
    data = data.selectExpr(cols)
    data.write.mode("overwrite").parquet(output_aid_temp)
    data.unpersist()
else :
    print("extraction_query is INVALID")

# COMMAND ----------

aidpatientaccts = get_aidpatientaccts(path_aidpatientaccts).selectExpr("patientacctipk","patientacctifk","hospitalfk","trgupdatedate").dropDuplicates()
# print("Count : existing aidpatientaccts : "+ "{:,}".format(aidpatientaccts.count()))

data = spark.read.parquet(output_aid_temp).dropDuplicates()

if tablename == "patientaccts":
    # print("Count : Pre AdmitDate filter : " + "{:,}".format(data.count()))
    data= data.filter(data.admitdate.cast("timestamp") > current_timestamp())
    # print("Count : Post AdmitDate filter : " + "{:,}".format(data.count()))
    data_insert = data.join(aidpatientaccts,(data.hospitalfk == aidpatientaccts.hospitalfk) & (data.patientacctipk == aidpatientaccts.patientacctipk),"leftanti").select(*[data[col] for col in data.columns])
    # print("Count : data_insert : " + "{:,}".format(data_insert.count()))
    data_update = data.join(aidpatientaccts,(data.hospitalfk == aidpatientaccts.hospitalfk) & (data.patientacctipk == aidpatientaccts.patientacctipk) & (data.trgupdatedate.cast("timestamp") > aidpatientaccts.trgupdatedate.cast("timestamp")),"inner",).select(*[data[col] for col in data.columns])
    # print("Count : data_update : " + "{:,}".format(data_update.count()))
    data = data_insert.union(data_update)
    # print("Count : Post Update/Insert check filter : " + "{:,}".format(data.count()))
    epic_pa = data.selectExpr("hospitalfk","patientacctipk").dropDuplicates()
    epic_pa.cache()
else:
    data = spark.read.parquet(output_aid_temp)


# print("Writing tablename = "+str(tablename)+" count = "+ "{:,}".format(data.count()) +" path = "+str(output))
data = data.drop("isdeleted").withColumn("IsDeleted",lit('0'))
data.dropDuplicates().repartition(25).write.mode("append").parquet(output)
data.unpersist()
aidpatientaccts.unpersist()

# COMMAND ----------

today = spark.read.format("parquet").load(output).dropDuplicates()
# print("Count : today : " + "{:,}".format(today.count()))

if today.count() > 0:
    reconcile_flag = 1
    print("reconcile_flag : "+str(reconcile_flag))
else:
    reconcile_flag = 0
    print("reconcile_flag : "+str(reconcile_flag))

# COMMAND ----------

if reconcile_flag == 1 and tablename == "patientaccts":
    print("Reconciling : aidpatientaccts")
    aidpatientaccts = get_aidpatientaccts(path_aidpatientaccts)
    # print("Count : existing aidpatientaccts : "+ "{:,}".format(aidpatientaccts.count()))
    today = spark.read.format("parquet").load(output).selectExpr("patientacctipk","patientacctipk as patientacctifk","hospitalfk","admitdate","trgupdatedate")
    today = today.join(epic_pa,(today.hospitalfk == epic_pa.hospitalfk) & (today.patientacctipk == epic_pa.patientacctipk)).select(*[today[col] for col in today.columns])
    today = today.join(hospitalattributevalues, ["hospitalfk"]).selectExpr("patientacctipk","patientacctifk","hospitalfk","hospitalattributefk","admitdate","trgupdatedate").dropDuplicates()
    today_deleted = aidpatientaccts.join(today, \
        (aidpatientaccts.hospitalfk == today.hospitalfk) 
        & (aidpatientaccts.patientacctipk == today.patientacctipk),"leftanti") \
        .select(*[aidpatientaccts[col] for col in aidpatientaccts.columns])
    # print("Count : today_deleted : " + "{:,}".format(today_deleted.count()))

    today_intact = today.join(aidpatientaccts, \
        (today.hospitalfk == aidpatientaccts.hospitalfk) 
        & (today.patientacctipk == aidpatientaccts.patientacctipk) 
        & (today.trgupdatedate.cast("timestamp") == aidpatientaccts.trgupdatedate.cast("timestamp")),
        "inner").select(*[today[col] for col in today.columns],aidpatientaccts.bccreated,aidpatientaccts.bcupdated)
    # print("Count : today_intact : " + "{:,}".format(today_intact.count()))

    today_update = (today.join(aidpatientaccts, \
        (today.hospitalfk == aidpatientaccts.hospitalfk) & (today.patientacctipk == aidpatientaccts.patientacctipk) & (today.trgupdatedate.cast("timestamp") > aidpatientaccts.trgupdatedate.cast("timestamp")),
        "inner").select(*[today[col] for col in today.columns], aidpatientaccts.bccreated).withColumn("bcupdated", lit(bc)))
    # print("Count : today_update : " + "{:,}".format(today_update.count()))

    today_insert = (today.join(aidpatientaccts, \
        (today.hospitalfk == aidpatientaccts.hospitalfk) & (today.patientacctipk == aidpatientaccts.patientacctipk),
        "leftanti").select(*[today[col] for col in today.columns]).withColumn("bccreated", lit(bc)).withColumn("bcupdated", lit(bc)))
    # print("Count : today_insert : " + "{:,}".format(today_insert.count()))

    today_whole = (today_deleted.union(today_update).union(today_insert).union(today_intact))
    # print("Count : today_whole  : " + "{:,}".format(today_whole.count()))

    today_whole.repartition(20).write.mode("overwrite").format("delta").save(path_aidpatientaccts)
    today_whole.unpersist()
    aidpatientaccts = get_aidpatientaccts(path_aidpatientaccts).selectExpr("patientacctipk","patientacctifk","hospitalfk","trgupdatedate").dropDuplicates()
    # print("Count : final aidpatientaccts : "+ "{:,}".format(aidpatientaccts.count()))
else:
    print("No Reconciliation Required : aidpatientaccts")

# COMMAND ----------

if reconcile_flag == 1:
    print("SQL Fetch Reconciliation Flag : "+str(reconcile_flag))
    dbutils.notebook.exit(reconcile_flag)
else :
    print("SQL Fetch Reconciliation Flag : "+str(reconcile_flag))
    dbutils.notebook.exit(reconcile_flag)

# COMMAND ----------


