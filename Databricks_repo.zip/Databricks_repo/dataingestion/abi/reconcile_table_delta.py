# Databricks notebook source
#01_reconcile_table_delta.py

# COMMAND ----------

from pyspark.sql.functions import *
from delta.tables import *

# COMMAND ----------

# DBTITLE 1,input parameters
dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("ingest_type", "")
dbutils.widgets.getArgument("ingest_type")
ingest_type= getArgument("ingest_type")

dbutils.widgets.text("tablename", "")
dbutils.widgets.getArgument("tablename")
tablename= getArgument("tablename")

dbutils.widgets.text("key", "")
dbutils.widgets.getArgument("key")
key= getArgument("key")

dbutils.widgets.text("reconcilekey", "")
dbutils.widgets.getArgument("reconcilekey")
reconcilekey= getArgument("reconcilekey")

dbutils.widgets.text("orderkey", "")
dbutils.widgets.getArgument("orderkey")
orderkey= getArgument("orderkey")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

# COMMAND ----------

# DBTITLE 1,Schema util 
# MAGIC %run "/Insleads-code/Common-Util/schema_util" 

# COMMAND ----------

# DBTITLE 1,adls access
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# DBTITLE 1,set basepath
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user
print(baseurl)

# COMMAND ----------

# DBTITLE 1,set paths
hdfs_publish = baseurl+ "/data/dataingestion/publish/" + tablename + "/current/20991231/"
hdfs_input = baseurl+ "/data/dataingestion/staging/input/" + tablename + "/" + bc + "/*"
bc_parquet = bc + "_PARQ"
hdfs_input_parquet = baseurl+ "/data/dataingestion/staging/input/" + tablename + "/" + bc_parquet
bc_parquet_recon = bc + "_PARQ_RECON"
hdfs_input_parquet_recon = baseurl+ "/data/dataingestion/staging/input/" + tablename + "/" + bc_parquet_recon
hdfs_staging = baseurl+ "/data/dataingestion/staging/" + tablename + "/"
print(hdfs_publish)
print(hdfs_input)
print(hdfs_input_parquet)
print(hdfs_input_parquet_recon)
configpath = "/dbfs/FileStore/dataingestion/config/param/"
file_table_partitioned_list = configpath+"file_table_partitioned_list.list"
file_table_uniqcolumns_list = configpath+ "file_table_uniqcolumns_list.list"
file_table_deltawrites_list = configpath+ "file_table_deltawrites_list.list"
print(configpath)
print(file_table_partitioned_list)
print(file_table_uniqcolumns_list)
print(file_table_deltawrites_list)

# COMMAND ----------

p_table_dictionary = load_partioned_table_dictionary(file_table_partitioned_list)
p_table_uniqkey_dictionary = load_table_uniqkey_dictionary(file_table_uniqcolumns_list)
p_table_deltawrites_dictionary = load_delta_write_table_dictionary(file_table_deltawrites_list)

# COMMAND ----------

# pJoinExpression = ""
# pUniqueColName = p_table_uniqkey_dictionary.get(tablename)
# for column in pUniqueColName.split(","):
#     print(column)
#     pJoinExpression = pJoinExpression + "raw." + column + "=delta." + column + " AND "
# pJoinExpression = pJoinExpression.strip(" AND")
# print(pJoinExpression)   

path_metadata = baseurl + "/data/dataingestion/publish/" + "metadata" + "/current/20991231/"
filter_tablename = "id=='" + tablename + "'"
pUniqueColName = spark.read.format("delta").load(path_metadata).filter(filter_tablename).selectExpr("table_primary_keys").dropDuplicates()
pJoinExpression = ""
for column in pUniqueColName.select("table_primary_keys").collect()[0][0].split(","):
    print(column)
    pJoinExpression = pJoinExpression + "raw." + column + "=delta." + column + " AND "
pJoinExpression = pJoinExpression.strip(" AND")
print(pJoinExpression)

# COMMAND ----------

print("hdfs_input"+str(hdfs_input))
df_delta = spark.read.options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ").parquet(hdfs_input).dropDuplicates()
for column in df_delta.columns:
    df_delta = df_delta.withColumn(column, trim(col(column)))
df_delta.createOrReplaceTempView("df_delta")
# df_delta.printSchema()
# df_delta.count()

# COMMAND ----------

if not 'HospitalFK' in df_delta.columns:
    print("NO ACTION : hospitalfk missing adding to the DF :" + tablename)
else:
    print("isdeleted column present in delta")
    hospitalpurge = spark.read.parquet(baseurl+"/data/dataingestion/publish/hospitalpurge/current/20991231/").filter("active=='1'").selectExpr("hospitalfk").dropDuplicates() #publish folder from fnf
    hospitalpurge.persist()
    hospitalpurge.createOrReplaceTempView("hospitalpurge")
    df_delta = spark.sql(""" SELECT * FROM df_delta WHERE CAST(hospitalfk AS BIGINT) NOT IN (SELECT CAST(hospitalfk AS BIGINT) as hospitalfk FROM hospitalpurge) """)


# COMMAND ----------

#block_size = str(1024 * 1024 * 1024)
#spark.conf.set("spark.sql.files.maxPartitionBytes", block_size)
#df_delta.repartition(15).write.option("parquet.block.size", block_size).mode("overwrite").parquet(hdfs_input_parquet)
df_delta.repartition(15).write.mode("overwrite").parquet(hdfs_input_parquet)
df_delta.unpersist()
df_delta = spark.read.parquet(hdfs_input_parquet)

# COMMAND ----------

if not 'IsDeleted' in df_delta.columns:
    print("IsDeleted missing adding to the DF")
    df_delta = df_delta.withColumn("IsDeleted", lit(0))
else:
    print("IsDeleted column present in delta")

# COMMAND ----------

# DBTITLE 1,check and confirm hdfs_delta path
if ingest_type == 'base':
    print("BASE")
    df_delta.createOrReplaceTempView("vw_df_delta")
    delta_reconcile_sql = """
    SELECT *
    FROM ( 
      SELECT *,
         ROW_NUMBER() OVER (PARTITION BY """ + key + """ ORDER BY """ + reconcilekey + """ DESC) AS rownum
       FROM vw_df_delta
      ) a
    WHERE a.rownum=1 AND a.IsDeleted=0 
    ORDER BY """ + orderkey
    df_delta_reconciled = spark.sql(delta_reconcile_sql)
    df_delta_reconciled = df_delta_reconciled.drop("rownum").drop("IsDeleted").dropDuplicates()
    df_delta_reconciled.repartition(15).write.mode("overwrite").parquet(hdfs_input_parquet_recon)
    #df_delta_reconciled.repartition(15).write.option("parquet.block.size", block_size).mode("overwrite").parquet(hdfs_input_parquet_recon)
    df_delta_reconciled.unpersist()
    #spark.stop()
    #exit(0)
else:
    print("NON_BASE")
    df_delta.createOrReplaceTempView("vw_df_delta")
    delta_reconcile_sql = """
    SELECT *
    FROM ( 
      SELECT *,
         ROW_NUMBER() OVER (PARTITION BY """ + key + """ ORDER BY """ + reconcilekey + """ DESC) AS rownum
       FROM vw_df_delta
      ) a
    WHERE a.rownum=1
    ORDER BY """ + orderkey
    df_delta_reconciled = spark.sql(delta_reconcile_sql)
    df_delta_reconciled.repartition(15).write.mode("overwrite").parquet(hdfs_input_parquet_recon)
    #df_delta_reconciled.repartition(15).write.option("parquet.block.size", block_size).mode("overwrite").parquet(hdfs_input_parquet_recon)
    df_delta_reconciled.unpersist()
    df_delta_reconciled = spark.read.parquet(hdfs_input_parquet_recon)
    df_delta_delete = df_delta_reconciled.filter(df_delta_reconciled.IsDeleted == '1').drop("IsDeleted").drop("rownum").dropDuplicates()
    df_delta_non_delete = df_delta_reconciled.filter(df_delta_reconciled.IsDeleted == '0').drop("IsDeleted").drop("rownum").dropDuplicates()
    delta_write_flag = str(p_table_deltawrites_dictionary.get(tablename))
    if delta_write_flag == '1':
        print("Delta Writing : " + tablename + " : True")
        #hdfs_delta = "/hceleads/user/" + user + "/leadrepo/data/raw/" + tablename + "/" + bc
        hdfs_delta = baseurl + "/data/leadrepo/staging/input/raw/" + tablename + "/" + bc
        df_del_write = df_delta_delete.withColumn("IsDeleted", lit(1))
        df_del_write.repartition(10).write.mode("overwrite").parquet(hdfs_delta)
        df_upd_write = df_delta_non_delete.withColumn("IsDeleted", lit(0))
        df_upd_write.repartition(10).write.mode("append").parquet(hdfs_delta)
        print("Delta Writing : " + tablename + " : Complete")
        df_del_write.unpersist()
        df_upd_write.unpersist()
        #spark.stop()
        #exit(0)
    else:
        print("Delta Writing : " + tablename + " : False")
        print("Continue Regular Workflow")
        #spark.stop()
        #exit(0)

# COMMAND ----------

#02_reconcile_table_delta
df_delta_reconciled = spark.read.parquet(hdfs_input_parquet_recon)

# COMMAND ----------

if ingest_type == 'base':
    df_delta_reconciled.write.format("delta").mode("overwrite").save(hdfs_publish)
    #spark.stop()
    #exit(0)
else:
    print("NON_BASE : RECONCILE")
    df_delta_delete = df_delta_reconciled.filter(df_delta_reconciled.IsDeleted == '1').drop("IsDeleted").drop("rownum").dropDuplicates()
    df_delta_non_delete = df_delta_reconciled.filter(df_delta_reconciled.IsDeleted == '0').drop("IsDeleted").drop("rownum").dropDuplicates()
    df_raw = DeltaTable.forPath(spark, hdfs_publish)
    df_raw.alias("raw").merge(df_delta_delete.alias("delta"), pJoinExpression).whenMatchedDelete().execute()
    print("NON_BASE : RECONCILE : DELETE : DONE")
    df_raw.alias("raw").merge(df_delta_non_delete.alias("delta"), pJoinExpression).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()
    print("NON_BASE : RECONCILE : INSERT-UPDATE : DONE")
    #spark.stop()
    #exit(0)

# COMMAND ----------

#03_reconcile_table_delta
#table_schema = createSchemaLine(schemapath + tablename + ".schema")
#df_delta = spark.read.format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", delimiter="\x01").schema(table_schema).load(hdfs_input).dropDuplicates()
#block_size = str(1024 * 1024 * 1024)
#spark.conf.set("spark.sql.files.maxPartitionBytes", block_size)
#df_delta.repartition(15).write.option("parquet.block.size", block_size).mode("overwrite").parquet(hdfs_input_parquet)
df_delta = spark.read.format("parquet").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ").load(hdfs_input).dropDuplicates()
df_delta.repartition(15).write.mode("overwrite").parquet(hdfs_input_parquet)
df_delta.unpersist()
df_delta = spark.read.parquet(hdfs_input_parquet)

# COMMAND ----------

if not 'IsDeleted' in df_delta.columns:
    print("isdeleted missing adding to the DF")
    df_delta = df_delta.withColumn("IsDeleted", lit(0))
else:
    print("IsDeleted column present in delta")

# COMMAND ----------

if ingest_type == "base":
    print("BASE")
else:
    print("NON_BASE")
    df_raw = DeltaTable.forPath(spark, hdfs_publish).toDF()
    # print("RAW COUNT : "+str(df_raw.count()))
    df_raw.createOrReplaceTempView("df_raw")
    if not "hospitalfk" in df_raw.columns:
        print("NO ACTION : hospitalfk missing adding to the DF :" + tablename)
    else:
        print("hospitalfk column present in delta")
        hospitalpurge = (
            spark.read.parquet(
                baseurl + "/data/dataingestion/publish/hospitalpurge/current/20991231/"
            )
            .filter("active=='1'")
            .selectExpr("hospitalfk")
            .dropDuplicates()
        )
        hospitalpurge.createOrReplaceTempView("hospitalpurge")
        df_raw = spark.sql(
            """ SELECT * FROM df_raw WHERE CAST(hospitalfk AS BIGINT) NOT IN (SELECT CAST(hospitalfk AS BIGINT) as hospitalfk FROM hospitalpurge) """
        )
        # print("RAW COUNT POST PURGE: "+str(df_raw.count()))
    if tablename in [
        "hcsystems",
        "edipayersxstateinsurancenames",
        "edipayerzipcodelookup",
        "edipayeropslottoconfig",
        "edipayeropsoutofregionconfig",
        "edipartners",
        "hospitalprovidernums",
        "edipayers",
        "hospitals",
        "hospitalattributes",
        "hospitalattributevalues",
    ]:
        df_raw.repartition(5).write.option("dataChange", "true").format("delta").mode(
            "overwrite"
        ).save(hdfs_publish)
    else:
        df_raw.write.option("dataChange", "true").format("delta").mode(
            "overwrite"
        ).save(hdfs_publish)
        print("NON_BASE : RECONCILE :BLOCK R-W DONE")
    df_raw.unpersist()
    #df_raw = DeltaTable.forPath(spark, hdfs_publish)
    #df_raw.vacuum(0)
    #print("NON_BASE : RECONCILE : VACUUM : DONE")
