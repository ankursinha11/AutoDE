# Databricks notebook source
# MAGIC %run "/Insleads-code/dataingestion/abi/dataingestion_sharding" 

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.functions import regexp_replace, col

# COMMAND ----------

dbutils.widgets.text("tablename","")
dbutils.widgets.getArgument("tablename")
tablename= getArgument("tablename")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("publishpath","")
dbutils.widgets.getArgument("publishpath")
publishpath= getArgument("publishpath")

dbutils.widgets.text("fqdb","")
dbutils.widgets.getArgument("fqdb")
fqdb= getArgument("fqdb")

dbutils.widgets.text("range_column","")
dbutils.widgets.getArgument("range_column")
range_column= getArgument("range_column")

dbutils.widgets.text("bcdate","")
dbutils.widgets.getArgument("bcdate")
bcdate= getArgument("bcdate")

dbutils.widgets.text("split_by","")
dbutils.widgets.getArgument("split_by")
split_by= getArgument("split_by")

dbutils.widgets.text("target_dir","")
dbutils.widgets.getArgument("target_dir")
target_dir= getArgument("target_dir")


# COMMAND ----------

# bcdate= "20251008T15"
# container= "prod-icd-stg-adls"
# fqdb= "eScanArchEDI.dbo.EDIQueries"
# publishpath= "/data/dataingestion/publish/"
# range_column= "createdate"
# split_by= "hospitalfk"
# storageaccount= "prodicdstgdls"
# tablename= "globalmrnfamilyassociations"
# target_dir= "/data/dataingestion/staging/input/"
# user= "maxc"

# COMMAND ----------

if user == 'na':  # default value
    baseurl = f"abfss://{container}@{storageaccount}.dfs.core.windows.net"
else:
    baseurl = f"abfss://{container}@{storageaccount}.dfs.core.windows.net/{user}"
print(baseurl)

target_dir_upd = f"{baseurl}{target_dir}{tablename}/{bcdate}"
print(target_dir_upd)

spark.conf.set(
    f"fs.azure.account.key.{storageaccount}.dfs.core.windows.net",
    dbutils.secrets.get(scope="icd-insleads-dbwscope", key="icd-adls-insleads-kvsecret")
)

# COMMAND ----------

def get_extraction_query(tablename):
    table_map = {
        'hospitalimportpayment': {
            'db_table': 'escan.dbo.hospitalimportpayment',
            'date_col': 'updatedate'
        },
        'ediqueries': {
            'db_table': 'escanarchedi.dbo.ediqueries',
            'date_col': 'createdate'
        },
        'ediqueryhitsandmisses': {
            'db_table': 'escanarchedi.dbo.ediqueryhitsandmisses',
            'date_col': 'createdate'
        },
        'vendorknownohicoverages': {
            'db_table': 'escan.dbo.vendorknownohicoverages',
            'date_col': 'updatedate'
        },
        'ediglobalsourceddata': {
            'db_table': 'escan.dbo.ediglobalsourceddata',
            'date_col': 'createdate'
        },
        'hospfinclasscodes': {
            'db_table': 'escan.dbo.hospfinclasscodes',
            'date_col': 'updatedate'
        },
        'hosppaymentcodes': {
            'db_table': 'escan.dbo.hosppaymentcodes',
            'date_col': 'updatedate'
        },
        'foundcoverageentities': {
            'db_table': 'escan.dbo.foundcoverageentities',
            'date_col': 'updatedate'
        },
        'patientacctcommercialhelpers': {
            'db_table': 'escan.dbo.patientacctcommercialhelpers',
            'date_col': 'updatedate'
        },
        'globalmrnfamilyassociations': {
            'db_table': 'escan.dbo.globalmrnfamilyassociations',
            'date_col': 'updatedate'
        }
    }

    if tablename not in table_map:
        raise ValueError(f"Unsupported tablename: {tablename}")

    db_table = table_map[tablename]['db_table']
    date_col = table_map[tablename]['date_col']
    extract_query = f"SELECT * FROM {db_table} WITH (NOLOCK) WHERE {date_col} >= DATEADD(hour, -36, GETDATE())"
    return extract_query

# COMMAND ----------

if tablename.lower() == "demographics":
    lastvalue = dbutils.notebook.run("fetch_last_value", 6000, {"container": container, "path_publish": publishpath, "storageaccount": storageaccount, "tablename": tablename, "user": user})
    #extract_query = "SELECT demographicpk,firstname,middlename,lastname,dob,gender,ssn FROM {fqdb} WITH (NOLOCK) WHERE {range_column} >= '{lastvalue}'"
    extract_query = f"SELECT demographicpk,firstname,middlename,lastname,dob,gender,ssn FROM {fqdb} WITH (NOLOCK) WHERE {range_column} >= '{lastvalue}'"
else:
    extract_query = get_extraction_query(tablename)
    
print("extract_query : " + extract_query)

# COMMAND ----------

shard = get_shard_server_list()
# shard = shard.withColumn("servername", regexp_replace(col("servername"), "hsdb01", "hsdb02"))
shard.display()
if shard.rdd.isEmpty():
    print("No shard servers found. Exiting.")
    dbutils.notebook.exit(1)

# COMMAND ----------

# result = process_shard_data(tablename, extract_query, target_dir_upd)
# print("result : " + str(result))
# if result is True:
#     print(f"SUCCESS {tablename}")
#     dbutils.notebook.exit(0)
# else:
#     data = spark.read.parquet(target_dir_upd)
#     if data.rdd.isEmpty():
#         raise Exception("DataFrame is empty. both shard empty.")
#     else:
#         print(f"SUCCESS {tablename} with atleast 1 shard")

# COMMAND ----------

result = process_shard_data(tablename, extract_query, target_dir_upd)
print("result : " + str(result))
if result is True:
    print(f"SUCCESS {tablename}")
else:
    raise Exception("DataFrame is empty. both shard empty.")

