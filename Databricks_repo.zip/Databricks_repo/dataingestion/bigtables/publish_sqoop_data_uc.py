# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *
spark.sql("SET spark.sql.shuffle.partitions=auto")

# COMMAND ----------

dbutils.widgets.text("catalog_name","")
dbutils.widgets.getArgument("catalog_name")
catalog_name= getArgument("catalog_name")

dbutils.widgets.text("tablename","")
dbutils.widgets.getArgument("tablename")
tablename= getArgument("tablename")

dbutils.widgets.text("load_type","")
dbutils.widgets.getArgument("load_type")
load_type= getArgument("load_type")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

publish_schema = 'dataingestion'
staging_schema = "dataingestion_staging"

# COMMAND ----------

publish_table = catalog_name + "." + publish_schema + "." + tablename
staging_table = catalog_name + "." + staging_schema + "." + tablename
print("publish_table : " + publish_table)
print("staging_table : " + staging_table)

# COMMAND ----------

pJoinExpression_Library = {
    "demographics": "publish.demographicpk=staging.demographicpk",
    "hospitalimportpayment": "publish.hospitalfk=staging.hospitalfk AND publish.hospitalimportpaymentpk=staging.hospitalimportpaymentpk AND publish.acctnum=staging.acctnum",
    "patientacctcommercialhelpers": "publish.patientacctcommercialhelperpk=staging.patientacctcommercialhelperpk",
    "reportwarehousemedicaideligiblepaes": "publish.hospitalfk=staging.hospitalfk AND publish.patientacctifk=staging.patientacctifk AND publish.reporttypefk=staging.reporttypefk AND publish.reportrequestfk=staging.reportrequestfk",
    "vendorknownohicoverages": "publish.vendorknownohicoveragespk=staging.vendorknownohicoveragespk",
    "addresslist": "publish.addresslistpk=staging.addresslistpk",
    "globalmrnfamilyassociations": "publish.globalmrnfamilyassociationpk=staging.globalmrnfamilyassociationpk",
    "patientacctsaddress": "publish.patientacctsaddresspk=staging.patientacctsaddresspk"}

pJoinExpressionIsExists = str(pJoinExpression_Library.get(tablename))
pJoinExpression = pJoinExpression_Library.get(tablename)
print(pJoinExpression)

# COMMAND ----------

def get_hdp_demographicshash(df):
    df.createOrReplaceTempView("vw_df_delta")
    delta_reconcile_sql = """
    SELECT *
    FROM (SELECT *,
                 ROW_NUMBER() OVER (PARTITION BY patientacctcommercialhelperpk ORDER BY updatedate DESC) AS rownum
          FROM vw_df_delta
          ) a
    WHERE a.rownum = 1
    """
    df = spark.sql(delta_reconcile_sql)
    df.createOrReplaceTempView("vw_df_delta")
    sql12 = """
    select vw_df_delta.*,
    regexp_replace(demographicshash,' ','') as demographicshash_cleaned,
    sha1(
    concat(
            case when coverageid is null then '' else coverageid end,":",
            coalesce((case when firstname is null then '' else UPPER(firstname) end),''),":",
            coalesce((case when lastname is null then '' else UPPER(lastname) end),''),":",
            case when substring(regexp_replace ((case when dob is null then '' else dob end),"-",""),1,8) is null then '' else substring(regexp_replace ((case when dob is null then '' else dob end),"-",""),1,8) end,":",
            (
              case when length (regexp_replace(coalesce((case when ssn is null then '' else ssn end),''),'-','')) = 7 then concat('00',regexp_replace(coalesce((case when ssn is null then '' else ssn end),''),'-','')) 
                   when length (regexp_replace(coalesce((case when ssn is null then '' else ssn end),''),'-','')) = 8 then concat('0',regexp_replace(coalesce((case when ssn is null then '' else ssn end),''),'-',''))
                   else regexp_replace(coalesce((case when ssn is null then '' else ssn end),''),'-','') end
             )
           )
          ) as hdp_demographicshash 
    from vw_df_delta where CAST(edipartnerfk AS BIGINT) IS NOT NULL"""
    output = spark.sql(sql12).drop("demographicshash").withColumnRenamed("demographicshash_cleaned", "demographicshash")
    return output

# COMMAND ----------

if load_type == 'base':
    if tablename == 'patientacctcommercialhelpers':
        print("LOADING BASE : " + publish_table)
        base_df = spark.read.table(staging_table)
        base_df = base_df.withColumn("bcupdated", lit(bc))
        base_df = get_hdp_demographicshash(base_df)
        base_df.write.mode("overwrite").saveAsTable(publish_table)
    else:
        print("LOADING BASE : " + publish_table)
        base_df = spark.read.table(staging_table)
        base_df = base_df.withColumn("bcupdated", lit(bc))
        base_df.write.mode("overwrite").saveAsTable(publish_table)
else:
    print("LOADING DELTA : " + publish_table)
    if tablename == 'patientacctcommercialhelpers':
        delta_df = spark.read.table(staging_table).where(f"bc = '{bc}'")
        delta_df = delta_df.withColumn("bcupdated", lit(bc))
        delta_df = get_hdp_demographicshash(delta_df)
        delta_df.createOrReplaceTempView("delta_df")
        spark.sql(f"""MERGE INTO {publish_table} AS publish 
              USING (SELECT * FROM delta_df) AS staging
              ON {pJoinExpression}
              WHEN MATCHED THEN UPDATE SET {', '.join([f'publish.{col} = staging.{col}' for col in delta_df.columns if col != 'bc'])}
              WHEN NOT MATCHED THEN INSERT * """)
    else:
        delta_df = spark.read.table(staging_table).where(f"bc = '{bc}'")
        delta_df = delta_df.withColumn("bcupdated", lit(bc))
        delta_df.createOrReplaceTempView("delta_df")
        if (pJoinExpressionIsExists == "None"):
            pJoinExpression = ""
            for column in delta_df.columns:
                #delta_df = delta_df.withColumnRenamed(column, new_column)
                pJoinExpression = pJoinExpression + "publish." + column + "<=>delta." + column + " AND "
                pJoinExpression = pJoinExpression.strip(" AND")
        print(pJoinExpression)
        spark.sql(f"""MERGE INTO {publish_table} AS publish 
              USING (SELECT * FROM delta_df) AS staging
              ON {pJoinExpression}
              WHEN MATCHED THEN UPDATE SET {', '.join([f'publish.{col} = staging.{col}' for col in delta_df.columns if col != 'bc'])}
              WHEN NOT MATCHED THEN INSERT * """)
    print("Merge Completed for " + publish_table)
