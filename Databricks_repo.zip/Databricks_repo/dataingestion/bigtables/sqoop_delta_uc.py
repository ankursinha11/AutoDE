# Databricks notebook source
from pyspark.sql.functions import *
from datetime import datetime

# COMMAND ----------

dbutils.widgets.text("catalog_name","")
dbutils.widgets.getArgument("catalog_name")
catalog_name= getArgument("catalog_name")

dbutils.widgets.text("tablename","")
dbutils.widgets.getArgument("tablename")
tablename= getArgument("tablename")

dbutils.widgets.text("databasetable","")
dbutils.widgets.getArgument("databasetable")
databasetable= getArgument("databasetable")

dbutils.widgets.text("range_column","")
dbutils.widgets.getArgument("range_column")
range_column= getArgument("range_column")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

publish_schema = 'dataingestion'
staging_schema = "dataingestion_staging"

# COMMAND ----------

publish_table = catalog_name + "." + publish_schema + "." + tablename
staging_table = catalog_name + "." + staging_schema + "." + tablename
print("publish_table : " + publish_table)
print("staging_table : " + staging_table)

# COMMAND ----------

#getting path connection from the key vault
path_conn_file = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-dataingestion-sql-insleads-cs")

# COMMAND ----------

# DBTITLE 1,get maxvalue from UC table
lastvalue = dbutils.notebook.run("fetch_last_value_uc", 6000, {"catalog_name": catalog_name, "tablename": tablename})
if lastvalue == 'None':
    lastvalue = "1900-01-01 00:00:00.000000"
try:
    lastvalue = datetime.strptime(lastvalue, '%Y-%m-%d %H:%M:%S.%f')
except ValueError:
    lastvalue = datetime.strptime(lastvalue, '%Y-%m-%d %H:%M:%S')
lastvalue = lastvalue.strftime('%Y-%m-%d %H:%M:%S')
print(lastvalue)

# COMMAND ----------

def get_table_min_max_value(path_conn_file,table_query_min_max):
    df_min_max = spark.read.format("jdbc").option("url", path_conn_file).option("query", table_query_min_max).load()
    for column in df_min_max.columns:
        df_min_max = df_min_max.withColumn(column, trim(col(column)))
        df_min_max = df_min_max.withColumn(column, when(col(column).isNull(), '0').otherwise(col(column)))
        df_min_max = df_min_max.withColumn(column, when(col(column) == 'null', '0').otherwise(col(column)))
        df_min_max = df_min_max.withColumn(column, when(col(column) == '', '0').otherwise(col(column)))
    list = df_min_max.collect()[0]
    minval = str(list['MINVAL'])
    maxval = str(list['MAXVAL'])
    df_min_max.unpersist()
    min_max=minval+"~"+maxval
    return min_max

# COMMAND ----------

partition_columns_lookup = {
    "addresslist": "addresslistpk",
    "patientacctsaddress": "patientacctsaddresspk",
    "globalmrnfamilyassociations": "globalmrnfamilyassociationpk"}

partition_column = str(partition_columns_lookup.get(tablename))

if partition_column == "None":
    print("INVALID tablename : " + tablename+" NO partition_column FOUND")
    dbutils.notebook.exit(1)
else:
    print("tablename : " + tablename + " partition_column : " + partition_column)

# COMMAND ----------

if tablename == "demographics":
    col_list = "demographicpk,firstname,middlename,lastname,dob,gender,ssn"
else:
    col_list = "*"

string_query_extraction = "(SELECT " + col_list + " FROM " + databasetable + " WITH (NOLOCK) WHERE " + range_column + " >= '" + lastvalue + "') as a"
print("string_query_extraction : " + string_query_extraction)
query_min_max="SELECT MIN(A." + partition_column + ") AS MINVAL,MAX(A."+ partition_column + ") AS MAXVAL FROM " + string_query_extraction  +""
print("query_min_max : " + query_min_max)
min_max=get_table_min_max_value(path_conn_file,query_min_max)

minval=min_max.split("~")[0]
maxval=min_max.split("~")[1]
print("minval : " + minval)
print("maxval : " + maxval)

jdbc_df = spark.read.format("jdbc").option("url", path_conn_file) \
    .option("dbtable", string_query_extraction) \
    .option("numPartitions", 20) \
    .option("lowerBound", minval) \
    .option("upperBound", maxval) \
    .option("partitionColumn", partition_column) \
    .load()

# COMMAND ----------

for column in jdbc_df.columns:
    new_column = column.lower()
    jdbc_df = jdbc_df.withColumnRenamed(column, new_column)
for column in jdbc_df.columns:    
    jdbc_df = jdbc_df.withColumn(column, trim(col(column)))
    jdbc_df = jdbc_df.withColumn(column, when(col(column).isNull(), None).otherwise(col(column)))
    jdbc_df = jdbc_df.withColumn(column, when(col(column) == '', None).otherwise(col(column)))
    jdbc_df = jdbc_df.withColumn(column, when(col(column) == 'null', None).otherwise(col(column)))   
    jdbc_df = jdbc_df.withColumn(column, when(col(column) == 'true', 1).when(col(column) == 'false', 0).otherwise(col(column)))    

# COMMAND ----------

print("WRITING TO THE UC Table")
jdbc_df = jdbc_df.withColumn("bc", lit(bc))

# Ensure the schema of the DataFrame matches the schema of the target table
target_schema = spark.table(staging_table).schema
jdbc_df = jdbc_df.select(*[col for col in jdbc_df.columns if col in target_schema.fieldNames()])

# Cast columns to match the target schema
for field in target_schema:
    if field.name in jdbc_df.columns:
        jdbc_df = jdbc_df.withColumn(field.name, jdbc_df[field.name].cast(field.dataType))

# Write the DataFrame to the Delta table
jdbc_df.write.mode("overwrite").format("delta").option("replaceWhere", f"bc = '{bc}'").saveAsTable(staging_table)

print("WRITING COMPLETE")
