# Databricks notebook source
import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql import functions as F
import pyspark.sql.functions as F
from pyspark.sql.functions import max
from delta.tables import *

# COMMAND ----------

dbutils.widgets.text("path_publish","")
dbutils.widgets.getArgument("path_publish")
path_publish= getArgument("path_publish")

dbutils.widgets.text("tablename","")
dbutils.widgets.getArgument("tablename")
tablename= getArgument("tablename")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user
    
print(baseurl)

# COMMAND ----------

# ADLS access
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

path_publish = baseurl+path_publish+tablename+'/current/20991231/'
print(path_publish)

# COMMAND ----------

table_col_library = {
    "edihospitalpartnergeneratedhashesarchive": "edihospitalpartnergeneratedhashpk",
    "edihospitalpartnergeneratedhashes": "edihospitalpartnergeneratedhashpk",
    "edihospitalpartnergeneratedhashtrnsarchive": "edihospitalpartnergeneratedhashfk",
    "edihospitalpartnergeneratedhashtrns": "edihospitalpartnergeneratedhashfk",
    "icdhashdemographics": "icdhashdemographicpk",
    "demographics": "demographicpk",
    "npi": "npi",
    "hospitalimportpayment": "hospitalimportpaymentpk",
    "hospfinclasscodes": "hospfinclasscodepk",
    "hosppaymentcodes": "hosppaymentcodepk",
    "log": "logid",
    "externallysourcedsubscriberdob": "externallysourcedsubscriberdobpk",
    "vwfamilymembers": "patientacctifk",
    "tusourcedfamilymemberlink": "tusourcedfamilymemberlinkpk",
    "ofrdatapaespmt": "ofrdatapaespmtpk",
}

# COMMAND ----------

p_table_type = str(table_col_library.get(tablename))

print("p_table_type "+str(p_table_type))

# COMMAND ----------

if ((tablename == "ediqueries") | (tablename == "ediqueryhitsandmisses") | (tablename == "ediglobalsourceddata")):
    column_name = "createdate"
elif (tablename == "reportwarehousemedicaideligiblepaes"):
    column_name = "requestdate"
else:
    column_name = "updatedate"


print("tablename="+str(tablename)+" column_name="+str(column_name))

# COMMAND ----------

# DBTITLE 1,DISABLED
# if (p_table_type == "None"):
#     spark.conf.set("spark.sql.legacy.timeParserPolicy","LEGACY")
#     raw = spark.read.format("delta").load(path_publish).selectExpr(column_name).dropDuplicates() \
#         .withColumn("last_dt", to_date(col(column_name), 'yyyy-MM-dd')) \
#         .selectExpr('*', 'date_sub(last_dt, 2) as last_dt_minus_2') \
#         .drop("last_dt").drop(column_name).filter("last_dt_minus_2 is not null")
#     lastval = raw.selectExpr("MAX(last_dt_minus_2) as max_t_2")
# else:
#     column_name = table_col_library.get(tablename)
#     raw = spark.read.format("delta").load(path_publish).selectExpr(column_name).dropDuplicates().withColumn(column_name, col(column_name).cast("long"))
#     lastval = raw.select([max(column_name)])

# for column in lastval.columns:
#     new_column = "lastval"
#     lastval = lastval.withColumnRenamed(column, new_column)

# display(lastval)
# maxval = str(lastval.collect()[0]['lastval'])

# COMMAND ----------

# DBTITLE 1,MODIFIED LAST_VAL
if (p_table_type == "None"):
    print("tablename="+str(tablename)+" column_name="+str(column_name))
    print("path_publish :"+str(path_publish))
    spark.conf.set("spark.sql.legacy.timeParserPolicy","LEGACY")
    raw = spark.read.format("delta").load(path_publish).selectExpr(column_name)
    raw.createOrReplaceTempView("raw")
    fetch_sql="SELECT date_sub(MAX(to_date("+column_name+",'yyyy-MM-dd')),2) AS max_t_2 FROM raw"
    print(fetch_sql)
    lastval=spark.sql(fetch_sql)
else:
    column_name = table_col_library.get(tablename)
    print("tablename="+str(tablename)+" column_name="+str(column_name))
    print("column_name : "+str(column_name))
    print("path_publish :"+str(path_publish))
    raw = spark.read.format("delta").load(path_publish).selectExpr(column_name).withColumn(column_name, col(column_name).cast("long"))
    lastval = raw.select([max(column_name)])

for column in lastval.columns:
    new_column = "lastval"
    lastval = lastval.withColumnRenamed(column, new_column)

# display(lastval)
maxval = str(lastval.collect()[0]['lastval'])

# COMMAND ----------

dbutils.notebook.exit(maxval)

# COMMAND ----------


