# Databricks notebook source
from pyspark.sql.functions import *
spark.conf.set("spark.sql.legacy.timeParserPolicy","LEGACY")

# COMMAND ----------

dbutils.widgets.text("catalog_name","")
dbutils.widgets.getArgument("catalog_name")
catalog_name= getArgument("catalog_name")

dbutils.widgets.text("tablename","")
dbutils.widgets.getArgument("tablename")
tablename= getArgument("tablename")

schema = 'dataingestion'

# COMMAND ----------

publish_table = catalog_name + "." + schema + "." + tablename
print("publish_table : " + publish_table)

# COMMAND ----------

table_col_library = {
    "edihospitalpartnergeneratedhashesarchive": "edihospitalpartnergeneratedhashpk",
    "edihospitalpartnergeneratedhashes": "edihospitalpartnergeneratedhashpk",
    "edihospitalpartnergeneratedhashtrnsarchive": "edihospitalpartnergeneratedhashfk",
    "edihospitalpartnergeneratedhashtrns": "edihospitalpartnergeneratedhashfk",
    "icdhashdemographics": "icdhashdemographicpk",
    "demographics": "demographicpk",
    "npi": "npi",
    "hospitalimportpayment": "hospitalimportpaymentpk",
    "hospfinclasscodes": "hospfinclasscodepk",
    "hosppaymentcodes": "hosppaymentcodepk",
    "log": "logid",
    "externallysourcedsubscriberdob": "externallysourcedsubscriberdobpk",
    "vwfamilymembers": "patientacctifk",
    "tusourcedfamilymemberlink": "tusourcedfamilymemberlinkpk",
    "ofrdatapaespmt": "ofrdatapaespmtpk"
}
p_table_type = str(table_col_library.get(tablename))
print("p_table_type "+str(p_table_type))

# COMMAND ----------

if tablename in ["ediqueries","ediqueryhitsandmisses","ediglobalsourceddata"]:
    column_name = "createdate"
elif (tablename == "reportwarehousemedicaideligiblepaes"):
    column_name = "requestdate"
else:
    column_name = "updatedate"
    
print("tablename="+str(tablename)+" column_name="+str(column_name))

# COMMAND ----------

# DBTITLE 1,LAST_VAL
if (p_table_type == "None"):
    print("tablename="+str(tablename)+" column_name="+str(column_name))
    table_df = spark.read.table(publish_table)
    fetch_sql="SELECT MAX("+column_name+")- interval 1 hour AS maxvalue FROM "+publish_table+""
    print(fetch_sql)
    lastval=spark.sql(fetch_sql)
else:
    column_name = table_col_library.get(tablename)
    print("tablename="+str(tablename)+" column_name="+str(column_name))
    table_df = spark.read.table(publish_table).selectExpr(column_name).withColumn(column_name, col(column_name).cast("long"))
    lastval = table_df.select([max(column_name)])

for column in lastval.columns:
    new_column = "lastval"
    lastval = lastval.withColumnRenamed(column, new_column)

# display(lastval)
maxval = str(lastval.collect()[0]['lastval'])

# COMMAND ----------

dbutils.notebook.exit(maxval)