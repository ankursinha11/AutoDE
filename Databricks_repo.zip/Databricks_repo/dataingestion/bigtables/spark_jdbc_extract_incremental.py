# Databricks notebook source
import sys
import os
import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
from pyspark import SparkContext
from pyspark.conf import SparkConf
import subprocess

# COMMAND ----------

dbutils.widgets.text("string_connection", "")
dbutils.widgets.getArgument("string_connection")
string_connection= getArgument("string_connection")

dbutils.widgets.text("path_output", "")
dbutils.widgets.getArgument("path_output")
path_output= getArgument("path_output")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("tablename","")
dbutils.widgets.getArgument("tablename")
tablename= getArgument("tablename")

dbutils.widgets.text("partition_column","")
dbutils.widgets.getArgument("partition_column")
partition_column= getArgument("partition_column")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("path_publish","")
dbutils.widgets.getArgument("path_publish")
path_publish= getArgument("path_publish")

# COMMAND ----------

partition_column_value = dbutils.notebook.run("fetch_last_value", 6000, {"container": container, "path_publish": path_publish, "storageaccount": storageaccount, "tablename": tablename, "user": user})
print(partition_column_value)

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user
print(baseurl)

# COMMAND ----------

path_output = baseurl+path_output+tablename+'/'+bc+'/'
print(path_output)
hospitablpurge_path = baseurl+path_publish+"hospitalpurge/current/20991231/"
print(hospitablpurge_path)

# COMMAND ----------

# ADLS access
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

string_query_maxval = "SELECT MAX(" + partition_column + ") AS MAXVAL FROM eScan.dbo." + tablename
print("DB MAXVAL QUERY : " + string_query_maxval)

# COMMAND ----------

df_jdbc_maxval = spark.read.format("jdbc").option("url", string_connection).option("query", string_query_maxval).load()

for column in df_jdbc_maxval.columns:
    df_jdbc_maxval = df_jdbc_maxval.withColumn(column, trim(col(column)))

maxval = str(df_jdbc_maxval.collect()[0]['MAXVAL'])

# COMMAND ----------

string_query_extraction = "(SELECT * FROM eScan.dbo." + tablename + " WHERE " + partition_column + " >= '" + partition_column_value + "') AS T"
print("DB EXTRACT QUERY : " + string_query_extraction)

# COMMAND ----------

df_jdbc = spark.read.format("jdbc").option("url", string_connection) \
    .option("dbtable", string_query_extraction) \
    .option("numPartitions", 20) \
    .option("lowerBound", partition_column_value) \
    .option("upperBound", maxval) \
    .option("partitionColumn", partition_column) \
    .load()

# COMMAND ----------

df_delta = df_jdbc.repartition(2567)

# COMMAND ----------

for column in df_delta.columns:
    new_column = column.lower()
    df_delta = df_delta.withColumnRenamed(column, new_column)

for column in df_delta.columns:
    df_delta = df_delta.withColumn(column, trim(col(column)))
    df_delta = df_delta.withColumn(column, when(col(column).isNull(), None).otherwise(col(column)))
    df_delta = df_delta.withColumn(column, when(col(column) == 'null', None).otherwise(col(column)))
    df_delta = df_delta.withColumn(column, when(col(column) == '', None).otherwise(col(column)))

for column in df_delta.columns:
    df_delta = df_delta.withColumn(column, when(col(column) == 'true', '1').when(col(column) == 'false', '0').otherwise(col(column)))

# COMMAND ----------

df_delta.createOrReplaceTempView("df_delta")
if not 'hospitalfk' in df_delta.columns:
    print("NO ACTION : hospitalfk missing adding to the DF :" + tablename)
else:
    print("hospitalfk column present in delta")
    hospitalpurge = spark.read.parquet(hospitablpurge_path).filter("active=='1'").selectExpr("hospitalfk").dropDuplicates()
    hospitalpurge.persist()
    hospitalpurge.createOrReplaceTempView("hospitalpurge")
    df_delta = spark.sql(""" SELECT * FROM df_delta WHERE CAST(hospitalfk AS BIGINT) NOT IN (SELECT CAST(hospitalfk AS BIGINT) as hospitalfk FROM hospitalpurge) """)

# COMMAND ----------

df_delta = df_delta.coalesce(10)
df_delta.write.mode("overwrite").parquet(path_output)
df_jdbc_maxval.unpersist()
df_jdbc.unpersist()
