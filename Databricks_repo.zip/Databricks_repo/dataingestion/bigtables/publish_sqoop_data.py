# Databricks notebook source
import sys
import os
import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
from pyspark import SparkContext
from pyspark.conf import SparkConf
import subprocess

# COMMAND ----------

dbutils.widgets.text("path_input","")
dbutils.widgets.getArgument("path_input")
path_input= getArgument("path_input")

dbutils.widgets.text("tablename","")
dbutils.widgets.getArgument("tablename")
tablename= getArgument("tablename")

dbutils.widgets.text("path_publish","")
dbutils.widgets.getArgument("path_publish")
path_publish= getArgument("path_publish")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("bcdate","")
dbutils.widgets.getArgument("bcdate")
bcdate= getArgument("bcdate")

# COMMAND ----------

from delta.tables import *

# COMMAND ----------

pJoinExpression_Library = {
    "demographics": "raw.demographicpk=delta.demographicpk",
    "hospitalimportpayment": "raw.hospitalfk=delta.hospitalfk AND raw.hospitalimportpaymentpk=delta.hospitalimportpaymentpk AND raw.acctnum=delta.acctnum",
    "patientacctcommercialhelpers": "raw.patientacctcommercialhelperpk=delta.patientacctcommercialhelperpk",
    "reportwarehousemedicaideligiblepaes": "raw.hospitalfk=delta.hospitalfk AND raw.patientacctifk=delta.patientacctifk AND raw.reporttypefk=delta.reporttypefk AND raw.reportrequestfk=delta.reportrequestfk",
    "globalmrnfamilyassociations": "publish.globalmrnfamilyassociationpk=staging.globalmrnfamilyassociationpk",
    "vendorknownohicoverages": "raw.vendorknownohicoveragespk=delta.vendorknownohicoveragespk"
}

# COMMAND ----------

def get_hdp_demographicshash(df):
    df.createOrReplaceTempView("vw_df_delta")
    delta_reconcile_sql = """
    SELECT *
    FROM (SELECT *,
                 ROW_NUMBER() OVER (PARTITION BY patientacctcommercialhelperpk ORDER BY updatedate DESC) AS rownum
          FROM vw_df_delta
          ) a
    WHERE a.rownum = 1
    """
    df = spark.sql(delta_reconcile_sql)
    df.createOrReplaceTempView("vw_df_delta")
    sql12 = """
    select vw_df_delta.*,
    regexp_replace(demographicshash,' ','') as demographicshash_cleaned,
    sha1(
    concat(
            case when coverageid is null then '' else coverageid end,":",
            coalesce((case when firstname is null then '' else UPPER(firstname) end),''),":",
            coalesce((case when lastname is null then '' else UPPER(lastname) end),''),":",
            case when substring(regexp_replace ((case when dob is null then '' else dob end),"-",""),1,8) is null then '' else substring(regexp_replace ((case when dob is null then '' else dob end),"-",""),1,8) end,":",
            (
              case when length (regexp_replace(coalesce((case when ssn is null then '' else ssn end),''),'-','')) = 7 then concat('00',regexp_replace(coalesce((case when ssn is null then '' else ssn end),''),'-','')) 
                   when length (regexp_replace(coalesce((case when ssn is null then '' else ssn end),''),'-','')) = 8 then concat('0',regexp_replace(coalesce((case when ssn is null then '' else ssn end),''),'-',''))
                   else regexp_replace(coalesce((case when ssn is null then '' else ssn end),''),'-','') end
             )
           )
          ) as hdp_demographicshash 
    from vw_df_delta where CAST(edipartnerfk AS BIGINT) IS NOT NULL"""
    output = spark.sql(sql12).drop("demographicshash").withColumnRenamed("demographicshash_cleaned", "demographicshash")
    return output

# COMMAND ----------

pJoinExpressionIsExists = str(pJoinExpression_Library.get(tablename))
pJoinExpression = pJoinExpression_Library.get(tablename)

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user
print(baseurl)

# COMMAND ----------

# ADLS access
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))
spark.sql("SET spark.sql.shuffle.partitions=auto")
spark.conf.set("spark.sql.shuffle.partitions", "auto")

# COMMAND ----------

path_publish = baseurl+path_publish+tablename+'/current/20991231/'
print(path_publish)
path_input = baseurl+path_input+tablename+'/'+bcdate+'/'
print(path_input)

# COMMAND ----------

path_publish_exists = 1
try:
    dbutils.fs.ls(path_publish)
    path_publish_exists = 1
except:
    path_publish_exists = 0
print(path_publish_exists)

# COMMAND ----------

if path_publish_exists == 0:
    if tablename == 'hospitalimportpayment':
        df_delta = spark.read.parquet(path_input)
        print("PUBLISH PATH MISSING : LOADING BASE : " + path_publish)
        df_delta.repartition(2567).write.format("delta").mode("overwrite").save(path_publish)
    else:
        print("PUBLISH PATH MISSING : LOADING BASE : " + path_publish)
        #table_schema = createSchemaLine(fs_common + "/schema/" + tablename + ".schema")
        #df_delta = spark.read.format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", delimiter="\x01").schema(table_schema).load(path_input).dropDuplicates()
        df_delta = spark.read.format("parquet").load(path_input).dropDuplicates()
        for column in df_delta.columns:
            df_delta = df_delta.withColumn(column, trim(col(column)))
            df_delta = df_delta.withColumn(column, when(col(column).isNull(), None).otherwise(col(column)))
            df_delta = df_delta.withColumn(column, when(col(column) == 'null', None).otherwise(col(column)))
            df_delta = df_delta.withColumn(column, when(col(column) == '', None).otherwise(col(column)))
            df_delta = df_delta.withColumn(column, when(col(column) == 'true', '1').when(col(column) == 'false', '0').otherwise(col(column)))
        if tablename == 'patientacctcommercialhelpers':
            df_delta = get_hdp_demographicshash(df_delta)
            df_delta.repartition(786).write.format("delta").mode("overwrite").save(path_publish)
        else:
            df_delta.repartition(786).write.format("delta").mode("overwrite").save(path_publish)
else:
    print("PUBLISH PATH FOUND   : LOADING DELTA : " + path_publish)
    if tablename == 'demographics':
        #table_schema = schema_util.createSchemaLine(fs_common + "/schema/" + tablename + ".schema")
        #df_delta = spark.read.format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", delimiter="\x01").schema(table_schema).load(path_input).dropDuplicates()
        df_delta = spark.read.format("parquet").load(path_input).dropDuplicates()
        pJoinExpression = ""
        for column in df_delta.columns:
            df_delta = df_delta.withColumn(column, when(col(column) == 'true', '1').when(col(column) == 'false', '0').otherwise(col(column)))
            df_delta = df_delta.withColumn(column, when(col(column).isNull(), '0').otherwise(col(column)))
        pJoinExpression = "raw.demographicpk=delta.demographicpk"
        print("pJoinExpression   :  " + pJoinExpression)
        df_raw = DeltaTable.forPath(spark, path_publish)
        df_raw.alias("raw").merge(df_delta.alias("delta"), pJoinExpression).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()
        #block_size = str(1024 * 1024 * 1024)
        #spark.conf.set("spark.sql.files.maxPartitionBytes", block_size)
        spark.read.format("delta").load(path_publish).dropDuplicates().repartition(100).write.option("dataChange", "false").format("delta").mode("overwrite").save(path_publish)
        #df_raw = DeltaTable.forPath(spark, path_publish)
        #spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", "false")
        #df_raw.vacuum(0)
    elif tablename == 'hospitalimportpayment':
        pJoinExpression = "raw.hospitalfk=delta.hospitalfk AND raw.hospitalimportpaymentpk=delta.hospitalimportpaymentpk AND raw.acctnum=delta.acctnum"
        print("pJoinExpression   :  " + pJoinExpression)
        df_delta = spark.read.parquet(path_input)
        df_raw = DeltaTable.forPath(spark, path_publish)
        df_raw.alias("raw").merge(df_delta.alias("delta"), pJoinExpression).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()
        #block_size = str(1024 * 1024 * 1024)
        #spark.conf.set("spark.sql.files.maxPartitionBytes", block_size)
        #df_raw = DeltaTable.forPath(spark, path_publish)
        #df_raw.toDF().repartition(786).write.option("dataChange", "true").format("delta").mode("overwrite").save(path_publish)
        df_raw = DeltaTable.forPath(spark, path_publish)
    else:
        #table_schema = schema_util.createSchemaLine(fs_common + "/schema/" + tablename + ".schema")
        #df_delta = spark.read.format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", delimiter="\x01").schema(table_schema).load(path_input).dropDuplicates()
        df_delta = spark.read.format("parquet").load(path_input).dropDuplicates()
        pJoinExpression = ""
        for column in df_delta.columns:
            df_delta = df_delta.withColumn(column, trim(col(column)))
            df_delta = df_delta.withColumn(column, when(col(column).isNull(), None).otherwise(col(column)))
            df_delta = df_delta.withColumn(column, when(col(column) == 'null', None).otherwise(col(column)))
            df_delta = df_delta.withColumn(column, when(col(column) == '', None).otherwise(col(column)))
            df_delta = df_delta.withColumn(column, when(col(column) == 'true', '1').when(col(column) == 'false', '0').otherwise(col(column)))
            pJoinExpression = pJoinExpression + "raw." + column + "<=>delta." + column + " AND "
        pJoinExpression = pJoinExpression.strip(" AND")
        if (pJoinExpressionIsExists == "None"):
            pJoinExpression = pJoinExpression
        else:
            pJoinExpression = pJoinExpression_Library.get(tablename)
        print("pJoinExpression   :  " + pJoinExpression)
        if tablename == 'patientacctcommercialhelpers':
            df_delta = get_hdp_demographicshash(df_delta)
        else:
            df_delta = df_delta
        df_raw = DeltaTable.forPath(spark, path_publish)
        df_raw.alias("raw").merge(df_delta.alias("delta"), pJoinExpression).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()
        #block_size = str(1024 * 1024 * 1024)
        #spark.conf.set("spark.sql.files.maxPartitionBytes", block_size)
        #df_raw = DeltaTable.forPath(spark, path_publish)
        #df_raw.toDF().repartition(786).write.option("dataChange", "false").format("delta").mode("overwrite").save(path_publish)
        #df_raw = DeltaTable.forPath(spark, path_publish)
        #spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled", "false")
        #current_dt = datetime.datetime.today()
        #print(current_dt)
        #df_raw.vacuum(72)
        #current_dt = datetime.datetime.today()
        #print(current_dt)
