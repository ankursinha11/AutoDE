# Databricks notebook source
dbutils.widgets.text("tableslist","")
dbutils.widgets.getArgument("tableslist")
tableslist= getArgument("tableslist")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("publishpath","")
dbutils.widgets.getArgument("publishpath")
publishpath= getArgument("publishpath")

# COMMAND ----------

sqlmi_path_conn_file = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-transport-sql-insleads-cs")
path_conn_file = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-dataingestion-sql-insleads-cs")


# COMMAND ----------

dbutils.notebook.run("hadoop_flush_and_fill", 3600, {"tablename":"hospitalpurge", "path_conn_file":path_conn_file, "container":container, "storageaccount":storageaccount, "user":user, "publishpath":publishpath})

# COMMAND ----------

for tablename in tableslist.split(","):
    print(tablename)
    dbutils.notebook.run("hadoop_flush_and_fill", 3600, {"tablename":tablename, "path_conn_file":path_conn_file, "container":container, "storageaccount":storageaccount, "user":user, "publishpath":publishpath})

# COMMAND ----------

dbutils.notebook.run("hadoop_flush_and_fill_shards", 3600, {"tablename":"partnerxrefconfig", "path_conn_file":sqlmi_path_conn_file, "container":container, "storageaccount":storageaccount, "user":user, "publishpath":publishpath})
