# Databricks notebook source
# MAGIC %md
# MAGIC Hadoop flush and fill

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

dbutils.widgets.text("tablename","")
dbutils.widgets.getArgument("tablename")
tablename= getArgument("tablename")

dbutils.widgets.text("path_conn_file", "")
dbutils.widgets.getArgument("path_conn_file")
path_conn_file= getArgument("path_conn_file")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("publishpath","")
dbutils.widgets.getArgument("publishpath")
publishpath= getArgument("publishpath")


# COMMAND ----------

# DBTITLE 1,set basepath
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user
print(baseurl)

# COMMAND ----------

path_publish = baseurl+publishpath+tablename+'/current/20991231/'

# COMMAND ----------

# ADLS access
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if tablename in ['partnerxrefconfig']:
    string_query_extraction = "SELECT * from ICDTransport.dbo." + tablename
    print("string_query_extraction : " + string_query_extraction)
    df_data = spark.read.format("jdbc").option("url", path_conn_file).option("query", string_query_extraction).load().dropDuplicates()

# COMMAND ----------

for column in df_data.columns:
    new_column = column.lower()
    df_data = df_data.withColumnRenamed(column, new_column)

# COMMAND ----------

for column in df_data.columns:
    df_data = df_data.withColumn(column, trim(col(column)))
    df_data = df_data.withColumn(column, when(col(column).isNull(), None).otherwise(col(column)))
    df_data = df_data.withColumn(column, when(col(column) == '', None).otherwise(col(column)))
    df_data = df_data.withColumn(column, when(col(column) == 'null', None).otherwise(col(column)))

# COMMAND ----------

for column in df_data.columns:
    df_data = df_data.withColumn(column, when(col(column) == 'true', '1').when(col(column) == 'false', '0').otherwise(col(column)))

# COMMAND ----------

df_data.printSchema()
df_data.createOrReplaceTempView("df_data")

# COMMAND ----------

if not tablename == 'hospitalpurge':
    if not 'hospitalfk' in df_data.columns:
        print("NO ACTION : hospitalfk missing adding to the DF :" + tablename)
    else:
        print("hospitalfk column present in delta")
        hospitalpurge = spark.read.parquet(hospitalpurgepath).filter("active=='1'").selectExpr("hospitalfk").dropDuplicates()
        hospitalpurge.persist()
        hospitalpurge.createOrReplaceTempView("hospitalpurge")
        df_data = spark.sql(""" SELECT * FROM df_data WHERE CAST(hospitalfk AS BIGINT) NOT IN (SELECT CAST(hospitalfk AS BIGINT) as hospitalfk FROM hospitalpurge) """)

# COMMAND ----------

df_data = df_data.repartition(1)
print("WRITING TO THE ADLS : ")
# df_data.write.mode("overwrite").parquet(path_publish)
#df_data.unpersist()
df_data.write.mode("overwrite").format("delta").save(path_publish)
print("WRITING COMPLETE : ")
#spark.stop()
#exit(0)

# COMMAND ----------

#df_data.repartition(10).write.mode('overwrite').parquet(path_publish)
