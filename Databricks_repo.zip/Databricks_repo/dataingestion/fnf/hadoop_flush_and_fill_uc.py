# Databricks notebook source
# MAGIC %md
# MAGIC Hadoop flush and fill

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

dbutils.widgets.text("catalog_name","")
dbutils.widgets.getArgument("catalog_name")
catalog_name= getArgument("catalog_name")

dbutils.widgets.text("tablename","")
dbutils.widgets.getArgument("tablename")
tablename= getArgument("tablename")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

publish_schema = 'dataingestion'

# COMMAND ----------

hospitalpurge_table = catalog_name + "." + publish_schema +".hospitalpurge"
publish_table = catalog_name + "." + publish_schema + "." + tablename
print("publish_table : " + publish_table)
print("hospitalpurge_table : " + hospitalpurge_table)
path_conn_file = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-dataingestion-sql-insleads-cs")

# COMMAND ----------

if tablename not in ['edileadsourcetransition','hpdhospitalpartnerlastrespstatus']:
    string_query_extraction = "SELECT * from eScan.dbo." + tablename
    print("string_query_extraction : " + string_query_extraction)
    data_df = spark.read.format("jdbc").option("url", path_conn_file).option("query", string_query_extraction).load().dropDuplicates()
else:
    string_query_extraction = "SELECT * from Abinitio.dbo." + tablename
    print("string_query_extraction : " + string_query_extraction)
    data_df = spark.read.format("jdbc").option("url", path_conn_file).option("query", string_query_extraction).load().dropDuplicates()    

# COMMAND ----------

for column in data_df.columns:
    new_column = column.lower()
    data_df = data_df.withColumnRenamed(column, new_column)

# COMMAND ----------

for column in data_df.columns:
    data_df = data_df.withColumn(column, trim(col(column)))
    data_df = data_df.withColumn(column, when(col(column).isNull(), None).otherwise(col(column)))
    data_df = data_df.withColumn(column, when(col(column) == '', None).otherwise(col(column)))
    data_df = data_df.withColumn(column, when(col(column) == 'null', None).otherwise(col(column)))

# COMMAND ----------

for column in data_df.columns:
    data_df = data_df.withColumn(column, when(col(column) == 'true', '1').when(col(column) == 'false', '0').otherwise(col(column)))
data_df.createOrReplaceTempView("data_df")    

# COMMAND ----------

if not tablename == 'hospitalpurge':
    if not 'hospitalfk' in data_df.columns:
        print("NO ACTION : hospitalfk missing adding to the DF :" + tablename)
    else:
        print("hospitalfk column present in delta")
        hospitalpurge = spark.read.table(hospitalpurge_table).filter("active=='1'").selectExpr("hospitalfk").dropDuplicates()
        hospitalpurge.createOrReplaceTempView("hospitalpurge")
        data_df = spark.sql(f""" SELECT * FROM data_df WHERE CAST(hospitalfk AS BIGINT) NOT IN (SELECT CAST(hospitalfk AS BIGINT) as hospitalfk FROM {hospitalpurge_table} WHERE active='1') """)

# COMMAND ----------

print("WRITING TO THE UC Table")
data_df = data_df.withColumn("bc", lit(bc))
data_df = data_df.withColumn("bcupdated", lit(bc))

# Ensure the schema of the DataFrame matches the schema of the target table
target_schema = spark.table(publish_table).schema
data_df = data_df.select(*[col for col in data_df.columns if col in target_schema.fieldNames()])

# Cast columns to match the target schema
for field in target_schema:
    if field.name in data_df.columns:
        data_df = data_df.withColumn(field.name, data_df[field.name].cast(field.dataType))

data_df.write.mode("overwrite").saveAsTable(publish_table)
print("WRITING COMPLETE")
