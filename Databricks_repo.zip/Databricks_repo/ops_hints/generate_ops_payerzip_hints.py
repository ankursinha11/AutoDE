# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user = getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container = getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount = getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc = getArgument("bc")

dbutils.widgets.text("hdfs_input","")
dbutils.widgets.getArgument("hdfs_input")
hdfs_input = getArgument("hdfs_input")

dbutils.widgets.text("hdfs_output","")
dbutils.widgets.getArgument("hdfs_output")
hdfs_output = getArgument("hdfs_output")


# COMMAND ----------


if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

hdfs_input = baseurl + hdfs_input
hdfs_output = baseurl + hdfs_output + bc
print("hdfs_input: ",hdfs_input)
print("hdfs_output: ",hdfs_output)

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

#!/bin/python -e
#   Supriya Robertson
#   03/13/2019
#   This pyspark script iruns logic for OPS ZIP
#   It puts output in the publish/hints with the correct partition
#   Basically, we are taking the payer-zip lookup and applying it to patientaccts zip to get payer hint
#   This is applicable to OPS regional payers only, hence all joins into configuration tables
#   The output flows into Hinting framework in EDI


from pyspark.sql.types import *
# from pyspark.sql import SparkSession
from datetime import datetime, timedelta
from pyspark.sql.functions import col
from pyspark.sql.functions import to_date
from pyspark.sql.functions import unix_timestamp
from pyspark.sql.functions import trim
from pyspark.sql.functions import substring
from pyspark.sql.functions import rank
# from pyspark import SparkContext
# from pyspark.conf import SparkConf
# from pyspark.sql.window import Window
# import sys
edidatasourcefkzip=18
edidatasourcefklotto=19

#Step 1- configuration view with all the below tables
payers= extract_parquet_data(spark,hdfs_input+"edipayers/current/*")
partners= extract_parquet_data(spark,hdfs_input+"edipartners/current/*")
hpns= extract_parquet_data(spark,hdfs_input+"hospitalprovidernums/current/*")
attr= extract_parquet_data(spark,hdfs_input+"hospitalattributevalues/current/*")
hospattr= extract_parquet_data(spark,hdfs_input+"hospitalattributes/current/*")
payerziplookup= extract_parquet_data(spark,hdfs_input+"edipayerzipcodelookup/current/*")
opsregionconfig= extract_parquet_data(spark,hdfs_input+"edipayeropsoutofregionconfig/current/*")
opspayerhospitals= extract_parquet_data(spark,hdfs_input+"opsedipayershospitals/current/*")
hfc= extract_deltalake_data(spark,hdfs_input+"hintfoundcoverage/current/20991231/")
hosp= extract_parquet_data(spark,hdfs_input+"hospitals/current/*")
lotto= extract_parquet_data(spark,hdfs_input+"edipayeropslottoconfig/current/*")
vsnapflags = extract_deltalake_data(spark,hdfs_input+"vsnappatientacctsflags/current/20991231/")

payers.createOrReplaceTempView("edipayers")
partners.createOrReplaceTempView("edipartners")
hpns.createOrReplaceTempView("hospitalprovidernums")
attr.createOrReplaceTempView("hospitalattributevalues")
hospattr.createOrReplaceTempView("hospitalattributes")
payerziplookup.createOrReplaceTempView("edipayerzipcodelookup")
opsregionconfig.createOrReplaceTempView("edipayeropsoutofregionconfig")
opspayerhospitals.createOrReplaceTempView("opsedipayershospitals")
hfc.createOrReplaceTempView("hintfoundcoverage")
hosp.createOrReplaceTempView("hospitals")
vsnapflags.createOrReplaceTempView("vsnap")

ops_hospitals_sql="""
select hospitalpk as hospitalfk
from hospitals h cross join hospitalattributes ha
left join hospitalattributevalues hav on ha.HospitalAttributePK=hav.HospitalAttributeFK
and h.HospitalPK=hav.HospitalFK
where ha.hospitalattributepk=3
and h.active=1
and COALESCE(hav.HospitalAttributeValue, ha.attributedefaultvalue)=1
"""
spark.sql(ops_hospitals_sql).createOrReplaceTempView("ops_hospitals")


hosppayerconfig_sql="""
SELECT p.edipayerpk, o.hospitalfk,pzc.zip,porc.knownmedicaidtotalchargesmin,porc.selfpaytotalchargesmin 
FROM edipayers p  
INNER JOIN edipartners pp  ON pp.edipayerfk = p.edipayerpk   
INNER JOIN hospitalprovidernums hpn ON hpn.edipartnerfk = pp.edipartnerpk 
AND hpn.Enabled = 1    
INNER JOIN ops_hospitals o ON hpn.hospitalfk=o.hospitalfk
INNER JOIN edipayerzipcodelookup pzc  ON pzc.edipayerfk = pp.edipayerfk  AND pzc.Isenabledflag = 1    
INNER JOIN edipayeropsoutofregionconfig porc ON porc.edipayerfk = pzc.edipayerfk  AND porc.Isenabledflag = 1  
LEFT JOIN opsedipayershospitals ph  ON pzc.edipayerfk = ph.edipayerfk  AND ph.hospitalfk = hpn.hospitalfk  AND ph.enableflag = 1 
WHERE p.opsenabledflag = 1 AND ph.opsedipayershospitalpk is null"""

spark.sql(hosppayerconfig_sql).createOrReplaceTempView("hosppayerconfig")


#Step 2- patientaccts with admitdate> 1 year, totalcharges>0
################for testing we are using 2 years back data as we did not have any for 1 year back##############################
d=datetime.today()-timedelta(days=365)

# pa_1= spark.read.parquet(hdfs_input+"/patientaccts/current/*")
pa_1= spark.read.format("delta").load(hdfs_input+"/patientaccts/current/20991231/")
pa_2= pa_1.select("patientacctipk","hospitalfk","admitdate","totalcharges","zip")
pa_3= pa_2.withColumn("admitdate", to_date(pa_2.admitdate)).withColumn("totalcharges",pa_2["totalcharges"].cast("decimal(32,4)")).withColumn("zip",substring(pa_2.zip,1,5))
pa_4= pa_3.filter((pa_3.admitdate>=d) & (pa_3.totalcharges>0))
pa_4.createOrReplaceTempView("patientaccts")


#Step 3- check against current hintfoundcoverage and generate hints 

ops_zip_accts_sql="""
SELECT DISTINCT a.hospitalfk,a.patientacctipk,h.edipayerpk,'""" + str(edidatasourcefkzip) + """' as edidatasourcefk,
a.totalcharges,date_format(current_timestamp(),'yyyy-MM-dd HH:mm:ss.SSS') as createdate
FROM patientaccts a
JOIN hosppayerconfig h ON a.hospitalfk=h.hospitalfk 
AND LENGTH(a.zip)>4
AND trim(a.zip)=trim(h.zip)
JOIN vsnap v on v.hospitalfk=a.hospitalfk and v.patientacctifk = a.patientacctipk
LEFT JOIN hintfoundcoverage hf ON a.patientacctipk=hf.patientacctifk AND a.hospitalfk=hf.hospitalfk AND h.edipayerpk=hf.edipayerfk
WHERE hf.hintfoundcoveragepk IS NULL 
and (
      ((v.knownmcaidflag = 1 or v.knowntricareflag = 1)
        and a.totalcharges >= h.knownmedicaidtotalchargesmin)
      or(v.primarymcaidflag = 1 and a.totalcharges >= h.selfpaytotalchargesmin)
    )"""

ops_zip_accts=spark.sql(ops_zip_accts_sql)


lotto.createOrReplaceTempView("edipayeropslottoconfig");

lotto_payer_config_sql="select CASE WHEN knownmedicaidtotalchargesmin > selfpaytotalchargesmin then knownmedicaidtotalchargesmin else selfpaytotalchargesmin end  as configcharge,EDIPayerFK,IsEnabledFlag,knownmedicaidtotalchargesmin,selfpaytotalchargesmin from EDIPayerOPSLottoConfig"

spark.sql(lotto_payer_config_sql).createOrReplaceTempView("ediplc")

lotto_config_sql="""
select p.edipayerpk,o.hospitalfk,porc.configcharge,porc.knownmedicaidtotalchargesmin, porc.selfpaytotalchargesmin
from edipayers p
inner join edipartners pp on pp.edipayerfk = p.edipayerpk
inner join hospitalprovidernums hpn on hpn.edipartnerfk = pp.edipartnerpk and hpn.enabled = 1
inner join ops_hospitals o on hpn.hospitalfk=o.hospitalfk
inner join ediplc porc on porc.edipayerfk = p.edipayerpk and porc.isenabledflag = 1
left join opsedipayershospitals ph on p.edipayerpk = ph.edipayerfk and ph.hospitalfk = hpn.hospitalfk and ph.enableflag = 1
where p.opsenabledflag = 1 and ph.opsedipayershospitalpk is null"""


spark.sql(lotto_config_sql).createOrReplaceTempView("lottoconfig")


ops_lotto_accts_sql="""
select distinct a.hospitalfk,a.patientacctipk,h.edipayerpk,'""" + str(edidatasourcefklotto) + """' as edidatasourcefk,
totalcharges,date_format(current_timestamp(),'yyyy-MM-dd HH:mm:ss.SSS') as createdate
from patientaccts a
join lottoconfig h on a.hospitalfk=h.hospitalfk and a.totalcharges>=h.configcharge
join vsnap v on v.hospitalfk=a.hospitalfk and v.patientacctifk=a.patientacctipk
left join hintfoundcoverage hf on a.patientacctipk=hf.patientacctifk and a.hospitalfk=hf.hospitalfk and h.edipayerpk=hf.edipayerfk
where hf.hintfoundcoveragepk is null
and (
      ((v.knownmcaidflag = 1 or v.knowntricareflag = 1)
        and a.totalcharges >= h.knownmedicaidtotalchargesmin)
      or(v.primarymcaidflag = 1 and a.totalcharges >= h.selfpaytotalchargesmin)
    )"""


ops_lotto_accts=spark.sql(ops_lotto_accts_sql)
ops_accts=ops_zip_accts.union(ops_lotto_accts)


#step 4 - write to pipe delimited dataset
ops_accts.repartition(1).write.mode("overwrite").format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="|").save(hdfs_output) 


# COMMAND ----------

table_schema = StructType([
    StructField("HospitalFK", StringType(), True),
    StructField("PatientAcctIFK", StringType(), True),
    StructField("EDIPayerFK", StringType(), True),
    StructField("EDIDataSourceFK", StringType(), True),
    StructField("TotalCharges", StringType(), True),
    StructField("CreateDate", StringType(), True)
])
