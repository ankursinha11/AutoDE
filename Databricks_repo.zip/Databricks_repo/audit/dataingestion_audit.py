# Databricks notebook source
# MAGIC %pip install sendgrid

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("publishpath","")
dbutils.widgets.getArgument("publishpath")
publishpath= getArgument("publishpath")

dbutils.widgets.text("extracthours","")
dbutils.widgets.getArgument("extracthours")
extracthours= getArgument("extracthours")

dbutils.widgets.text("int_path","")
dbutils.widgets.getArgument("int_path")
int_path= getArgument("int_path")

dbutils.widgets.text("output_path","")
dbutils.widgets.getArgument("output_path")
output_path= getArgument("output_path")

dbutils.widgets.text("FROM_EMAIL","")
dbutils.widgets.getArgument("FROM_EMAIL")
FROM_EMAIL= getArgument("FROM_EMAIL")

dbutils.widgets.text("TO_EMAIL","")
dbutils.widgets.getArgument("TO_EMAIL")
TO_EMAIL= getArgument("TO_EMAIL")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))
path_conn_file = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-dataingestion-sql-insleads-cs")
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user
print("baseurl : "+baseurl)

# COMMAND ----------

from pyspark.sql.functions import *
import pandas as pd
from datetime import datetime
import pytz
import sendgrid
from sendgrid.helpers.mail import *
from pyspark.sql.window import Window

# COMMAND ----------

my_datetime = datetime.utcnow()
bc = my_datetime.astimezone(pytz.timezone("US/Central")).strftime("%Y%m%dT%H")
publishpath = baseurl + "/" + publishpath
int_path = baseurl + "/" + int_path
output_path = baseurl + "/" + output_path + bc
print("publishpath : " + publishpath)
print("int_path : " + int_path)
print("output_path : " + output_path)

# COMMAND ----------

try:
    tablename = ["patientaccts","patientacctscodes","foundcoverage","vsnappatientacctsflags","reportwarehousemedicaideligiblepaes","patientacctstatestatus","patientacctspayercob","foundcoveragesegments","hospinsurancecodes","hintfoundcoverage","tprcoverage","medicarecoverage","clusteredaccts","edisubscriberdobsearch","vsnapglobalmrnfamilyhelperaccounts","patientacctsguarantors","patientaccteligibilitysubmittals","demographics","vendorknownohicoverages","hosppaymentcodes","hospfinclasscodes","hospitalimportpayment","ediqueryhitsandmisses","ediqueries","foundcoverageentities","tusourcedfamilymemberlink","patientacctcommercialhelpers","helperfoundcoverages","hospitalpurge","hospitalprovidernums","hospitalattributevalues","hospitalattributes","hospitals","edipayers","edipartners","opsedipayershospitals","edipayeropsoutofregionconfig","edipayeropslottoconfig","edipayerzipcodelookup","edipayersxstateinsurancenames","hcsystems","edipayers_tupayeridmapping","edi270querycombos","edidatasources","edileadsourcetransition","edipartner270settings","edipartnerattributes","edipartnerattributevalues","edipartnerhospital270settingsoverrides","edipartnersubmittersoverrides","edipartnertype","edisubmitters","edisubscriberdobresponse","escanglobalparameters","foundcoverageinferredsourcemethodcodes","hospitalnpioverrides","hospitalpayercob","hpdhospitalpartnerlastrespstatus","partnerpolicyidblacklists","zipcodes","patientacctsaccesscoordinator"]

    fnf_hospitalfk_list=["hospitalprovidernums","hospitalattributevalues","opsedipayershospitals","edileadsourcetransition","edipartnerhospital270settingsoverrides","edisubscriberdobresponse","hospitalnpioverrides","hospitalpayercob","hpdhospitalpartnerlastrespstatus","patientacctsaccesscoordinator"]

    for table in tablename:
        partition_column_lookup = {
        "patientacctscodes": ["patientacctifk", "TrgUpdateDate","Abinitio.dbo.","delta","2024-01-01","abi_group1"],
        "patientaccts": ["patientacctipk", "TrgUpdateDate","Abinitio.dbo.","delta","2024-01-01","abi_group1"],
        "foundcoverage": ["patientacctifk", "UpdateDate","Abinitio.dbo.","delta","2024-01-01","abi_group1"],
        "vsnappatientacctsflags": ["patientacctifk", "CreateDate","Abinitio.dbo.","delta","2024-01-01","abi_group1"],
        "helperfoundcoverages": ["patientacctifk", "UpdateDate","Abinitio.dbo.","delta","2024-01-01","abi_group1"],
        "reportwarehousemedicaideligiblepaes": ["foundcoverageifk", "RequestDate","Abinitio.dbo.","delta","2024-01-01","abi_group2"],
        "patientacctstatestatus": ["patientacctifk", "UpdateDate","Abinitio.dbo.","delta","2024-01-01","abi_group2"],
        "patientacctspayercob": ["patientacctifk", "UpdateDate","Abinitio.dbo.","delta","2024-01-01","abi_group2"],
        "foundcoveragesegments": ["foundcoverageifk", "UpdateDate","Abinitio.dbo.","delta","2024-01-01","abi_group2"],
        "hospinsurancecodes": ["hospinsurancecodepk", "UpdateDate","Abinitio.dbo.","delta","2024-01-01","abi_group2"],
        "hintfoundcoverage": ["patientacctifk", "UpdateDate","Abinitio.dbo.","delta","2024-01-01","abi_group2"],
        "tprcoverage": ["foundcoverageifk", "UpdateDate","Abinitio.dbo.","delta","2024-01-01","abi_group2"],
        "medicarecoverage": ["MedicareCoverageIPK", "UpdateDate","Abinitio.dbo.","delta","2024-01-01","abi_group2"],
        "clusteredaccts": ["clusteredacctpk", "UpdateDate","Abinitio.dbo.","delta","2024-01-01","abi_group2"],
        "edisubscriberdobsearch": ["patientacctifk", "UpdateDate","Abinitio.dbo.","delta","2024-01-01","abi_group2"],
        "vsnapglobalmrnfamilyhelperaccounts": ["patientacctifk", "UpdateDate","Abinitio.dbo.","delta","2024-01-01","abi_group2"],
        "patientacctsguarantors": ["hospitalfk", "UpdateDate","Abinitio.dbo.","delta","2024-01-01","abi_group2"],
        "patientaccteligibilitysubmittals": ["patientacctifk", "UpdateDate","Abinitio.dbo.","delta","2024-01-01","abi_group2"],
        "demographics":["demographicpk","","eScanArchEDI.dbo.","delta","","big_tables"],
        "vendorknownohicoverages":["vendorknownohicoveragespk","updatedate","escan.dbo.","delta","2024-01-01","big_tables"],
        "hosppaymentcodes":["hosppaymentcodepk","","escan.dbo.","delta","","big_tables"],
        "hospfinclasscodes":["hospfinclasscodepk","","escan.dbo.","delta","","big_tables"],
        "hospitalimportpayment":["hospitalimportpaymentpk","","escan.dbo.","delta","","big_tables"],
        "ediqueryhitsandmisses":["ediqueryfk","createdate","eScanArchEDI.dbo.","delta","2024-01-01","big_tables"],
        "ediqueries":["ediquerypk","createdate","eScanArchEDI.dbo.","delta","2024-01-01","big_tables"],
        "foundcoverageentities":["foundcoverageentityipk","updatedate","eScan.dbo.","delta","2024-01-01","big_tables"],
        "tusourcedfamilymemberlink":["tusourcedfamilymemberlinkpk","","TUData.dbo.","delta","","big_tables"],
        "patientacctcommercialhelpers":["patientacctcommercialhelperpk","updatedate","eScan.dbo.","delta","2024-01-01","big_tables"],
        "hospitalpurge":["*","","eScan.dbo.","parquet","","fnf"],
        "hospitalprovidernums":["*","","eScan.dbo.","parquet","","fnf"],
        "hospitalattributevalues":["*","","eScan.dbo.","parquet","","fnf"],
        "hospitalattributes":["*","","eScan.dbo.","parquet","","fnf"],
        "hospitals":["*","","eScan.dbo.","parquet","","fnf"],
        "edipayers":["*","","eScan.dbo.","parquet","","fnf"],
        "edipartners":["*","","eScan.dbo.","parquet","","fnf"],
        "opsedipayershospitals":["*","","eScan.dbo.","parquet","","fnf"],
        "edipayeropsoutofregionconfig":["*","","eScan.dbo.","parquet","","fnf"],
        "edipayeropslottoconfig":["*","","eScan.dbo.","parquet","","fnf"],
        "edipayerzipcodelookup":["*","","eScan.dbo.","parquet","","fnf"],
        "edipayersxstateinsurancenames":["*","","eScan.dbo.","parquet","","fnf"],
        "hcsystems":["*","","eScan.dbo.","parquet","","fnf"],
        "edipayers_tupayeridmapping":["*","","eScan.dbo.","parquet","","fnf"],
        "edi270querycombos":["*","","eScan.dbo.","parquet","","fnf"],
        "edidatasources":["*","","eScan.dbo.","parquet","","fnf"],
        "edileadsourcetransition":["*",""," Abinitio.dbo.","parquet","","fnf"],
        "edipartner270settings":["*","","eScan.dbo.","parquet","","fnf"],
        "edipartnerattributes":["*","","eScan.dbo.","parquet","","fnf"],
        "edipartnerattributevalues":["*","","eScan.dbo.","parquet","","fnf"],
        "edipartnerhospital270settingsoverrides":["*","","eScan.dbo.","parquet","","fnf"],
        "edipartnersubmittersoverrides":["*","","eScan.dbo.","parquet","","fnf"],
        "edipartnertype":["*","","eScan.dbo.","parquet","","fnf"],
        "edisubmitters":["*","","eScan.dbo.","parquet","","fnf"],
        "edisubscriberdobresponse":["*","","eScan.dbo.","parquet","","fnf"],
        "escanglobalparameters":["*","","eScan.dbo.","parquet","","fnf"],
        "foundcoverageinferredsourcemethodcodes":["*","","eScan.dbo.","parquet","","fnf"],
        "hospitalnpioverrides":["*","","eScan.dbo.","parquet","","fnf"],
        "hospitalpayercob":["*","","eScan.dbo.","parquet","","fnf"],
        "hpdhospitalpartnerlastrespstatus":["*","","Abinitio.dbo.","parquet","","fnf"],
        "partnerpolicyidblacklists":["*","","eScan.dbo.","parquet","","fnf"],
        "zipcodes":["*","","eScan.dbo.","parquet","","fnf"],
        "patientacctsaccesscoordinator":["*","","eScan.dbo.","parquet","","fnf"],
    }
    
        list_value = partition_column_lookup.get(table)
        primary_key_column=list_value[0]
        primary_date_column=list_value[1]
        schema=list_value[2]
        load_type=list_value[3]
        start_date=list_value[4]
        category=list_value[5]
        print("tablename : " + table)
        print("primary_key_column : " + primary_key_column)
        print("primary_date_column : " + primary_date_column)
        print("schema : " + schema)
        print("category : " + category)
        print("----------------------------------")
        if primary_date_column=="" and category=='big_tables':
            table_query_primary="(SELECT min(cast("+primary_key_column+" as bigint)) as min_pk_sql ,max(cast("+primary_key_column+" as bigint)) as max_pk_sql, COUNT_BIG(*) as count_sql, '"+table+"' as tablename, '"+category+"' as category  FROM "+schema+""+table+") as a"
            # print(table_query_primary)
            print("----------------------------------")
            df_jdbc = spark.read.format("jdbc").option("url", path_conn_file) \
            .option("dbtable", table_query_primary) \
            .option("numPartitions", 20) \
            .load()
            df_jdbc.write.format("parquet").mode("overwrite").save(int_path)
            df_jdbc=spark.read.format("parquet").load(int_path)
            df_adls=spark.read.format(load_type).load(publishpath+table+"/current/20991231/")
            df_adls.createOrReplaceTempView("adls")
            adls_query = "select min(cast("+primary_key_column+" as long)) as min_pk_adls,max(cast("+primary_key_column+" as long)) as max_pk_adls,  count(*) as count_adls, '"+table+"' as tablename, '"+category+"' as category  from adls"
            print(adls_query)
            print("----------------------------------")
            df_adls = spark.sql(adls_query)

        elif primary_date_column=="" and category=="fnf":
            if table in fnf_hospitalfk_list :
                table_query_primary="(SELECT CAST('000000' as BIGINT) as min_pk_sql,CAST('000000' as BIGINT) as max_pk_sql,COUNT_BIG(*) as count_sql, '"+table+"' as tablename ,'"+category+"' as category FROM "+schema+""+table+" (NOLOCK) WHERE CAST(hospitalfk AS BIGINT) NOT IN (SELECT CAST(hospitalfk AS BIGINT) as hospitalfk FROM eScan.dbo.hospitalpurge)) as a"
                print(table_query_primary)
                print("----------------------------------")
                df_jdbc = spark.read.format("jdbc").option("url", path_conn_file) \
                .option("dbtable", table_query_primary) \
                .option("numPartitions", 20) \
                .load()
                df_jdbc.write.format("parquet").mode("overwrite").save(int_path)
                df_jdbc=spark.read.format("parquet").load(int_path)
                df_adls=spark.read.format(load_type).load(publishpath+table+"/current/20991231/")
                df_adls.createOrReplaceTempView("adls")
                adls_query = "select CAST('000000' as BIGINT) as min_pk_adls,CAST('000000' as BIGINT) as max_pk_adls,count(*) as count_adls, '"+table+"' as tablename, '"+category+"' as category   from adls "
                print(adls_query)
                print("----------------------------------")
                df_adls = spark.sql(adls_query)

            else:
                table_query_primary="(SELECT CAST('000000' as BIGINT)  as min_pk_sql, CAST('000000' as BIGINT)  as max_pk_sql,COUNT_BIG(*) as count_sql, '"+table+"' as tablename ,'"+category+"' as category FROM "+schema+""+table+" (NOLOCK)) as a"
                # print(table_query_primary)
                print("----------------------------------")
                df_jdbc = spark.read.format("jdbc").option("url", path_conn_file) \
                .option("dbtable", table_query_primary) \
                .option("numPartitions", 20) \
                .load()
                df_jdbc.write.format("parquet").mode("overwrite").save(int_path)
                df_jdbc=spark.read.format("parquet").load(int_path)
                df_adls=spark.read.format(load_type).load(publishpath+table+"/current/20991231/")
                df_adls.createOrReplaceTempView("adls")
                adls_query = "select CAST('000000' as BIGINT) as min_pk_adls,CAST('000000' as BIGINT)  as max_pk_adls,count(*) as count_adls, '"+table+"' as tablename, '"+category+"' as category   from adls "
                print(adls_query)
                print("----------------------------------")
                df_adls = spark.sql(adls_query)
        elif primary_date_column!="" : 
            table_query_primary="(SELECT min(cast("+primary_key_column+" as bigint)) as min_pk_sql ,max(cast("+primary_key_column+" as bigint)) as max_pk_sql, COUNT_BIG(*) as count_sql, '"+table+"' as tablename, '"+category+"' as category  FROM "+schema+""+table+" (NOLOCK) WHERE  cast("+primary_date_column+" as date) >= '"+start_date+"'  AND cast("+primary_date_column+" as date) <= dateadd(HOUR,-"+extracthours+",CURRENT_TIMESTAMP)) as a"
            # print(table_query_primary)
            print("----------------------------------")
            df_jdbc = spark.read.format("jdbc").option("url", path_conn_file) \
            .option("dbtable", table_query_primary) \
            .option("numPartitions", 20) \
            .load()
            df_jdbc.write.format("parquet").mode("overwrite").save(int_path)
            df_jdbc=spark.read.format("parquet").load(int_path)
            df_adls=spark.read.format(load_type).load(publishpath+table+"/current/20991231/")
            df_adls.createOrReplaceTempView("adls")
            adls_query = "select min(cast("+primary_key_column+" as long)) as min_pk_adls,max(cast("+primary_key_column+" as long)) as max_pk_adls,  count(*) as count_adls, '"+table+"' as tablename,'"+category+"' as category  from adls  where cast("+primary_date_column+" as date) >= '"+start_date+"'  AND cast("+primary_date_column+" as date) <= dateadd(HOUR,-"+extracthours+",CURRENT_TIMESTAMP)"
            print(adls_query)
            print("----------------------------------")
            df_adls = spark.sql(adls_query)
        
        df_result = df_jdbc.join(
            df_adls, df_jdbc["tablename"] == df_adls["tablename"], "inner"
        ).select(
            df_jdbc["category"].alias("Category"),
            df_jdbc["tablename"].alias("TableName"),
            df_jdbc["min_pk_sql"], df_adls["min_pk_adls"], df_jdbc["max_pk_sql"], df_adls["max_pk_adls"], 
            df_jdbc["count_sql"], df_adls["count_adls"], 
            (df_adls["count_adls"] - df_jdbc["count_sql"]).alias("diff"), 
            round(((df_adls["count_adls"] - df_jdbc["count_sql"]) / df_adls["count_adls"]) * 100, 2).alias("diff_prct")
            
        )

        df_result.write.format("parquet").mode("append").save(output_path)
        df_jdbc.unpersist()
        df_adls.unpersist()
        #dbutils.fs.rm(int_path, True)
except Exception as e:
    raise Exception("Error fetching the data from sql: {}".format(e))

# COMMAND ----------

try:
    df=spark.read.format("parquet").load(output_path)
    windowSpec= Window.orderBy("Category","TableName")
    df_1=df.withColumn("SNo",row_number().over(windowSpec))
    df_final = df_1.select(col("SNo").alias("S.No"), *df_1.columns).drop("SNo")
    df = df_final.toPandas().applymap(lambda x:str(x)[0:150])
    bodyhtml = ""
    bodyhtml = bodyhtml + '<br><p class = "TableTitle">Data Ingestion Audit</p></br> '+df.to_html(index=False,justify="center")+'</p>'
except Exception as e:
    raise Exception("Error generating a Table: {}".format(e))

# COMMAND ----------

try:
    sg= sendgrid.SendGridAPIClient(api_key=dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-email-sendgrid-api-key"))
    email =Mail(
        from_email=FROM_EMAIL,
        to_emails=TO_EMAIL,
        subject='Data Ingestion Audit',
        html_content=bodyhtml
    )
    response = sg.send(email)
    
except Exception as e:
    raise Exception("Error sending a Email: {}".format(e))
