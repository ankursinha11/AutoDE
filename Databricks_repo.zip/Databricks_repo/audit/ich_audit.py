# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *
from datetime import datetime, timedelta, date

# COMMAND ----------

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("db_name1","")
dbutils.widgets.getArgument("db_name1")
db_name1 = getArgument("db_name1")

dbutils.widgets.text("db_name2","")
dbutils.widgets.getArgument("db_name2")
db_name2 = getArgument("db_name2")

dbutils.widgets.text("db_name3","")
dbutils.widgets.getArgument("db_name3")
db_name3 = getArgument("db_name3")

dbutils.widgets.text("table_name","")
dbutils.widgets.getArgument("table_name")
table_name = getArgument("table_name")

dbutils.widgets.text("conn_string", "")
dbutils.widgets.getArgument("conn_string")
conn_string = getArgument("conn_string")

dbutils.widgets.text("file_path", "")
dbutils.widgets.getArgument("file_path")
file_path = getArgument("file_path")

dbutils.widgets.text("max_received_date_path", "")
dbutils.widgets.getArgument("max_received_date_path")
max_received_date_path = getArgument("max_received_date_path")

dbutils.widgets.text("number_of_days", "")
dbutils.widgets.getArgument("number_of_days")
number_of_days = getArgument("number_of_days")

# COMMAND ----------


spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user == 'na' or user =='': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

curr_date=datetime.now().date()
bc=curr_date.strftime("%Y%m%d")
adlspath=baseurl+"/data/audit/ieprebdf/"+bc
sqlpath_rm=baseurl+"/data/audit/ieprebdf/sql/"
sqlpath=baseurl+"/data/audit/ieprebdf/sql/"+bc+"/*/*"
sqlpath1=baseurl+"/data/audit/ieprebdf/sql/"+bc+"/"+db_name1
sqlpath2=baseurl+"/data/audit/ieprebdf/sql/"+bc+"/"+db_name2
sqlpath3=baseurl+"/data/audit/ieprebdf/sql/"+bc+"/"+db_name3
missing_trace=baseurl+"/data/audit/ieprebdf/missing_trace/"+bc
missing_trace_count=baseurl+"/data/audit/ieprebdf/missing_trace_numbers_count/"+bc
missing_bucket_count=baseurl+"/data/audit/ieprebdf/missing_bucket_count/"+bc
print(sqlpath)
print(missing_trace)
print(missing_trace_count)
print(missing_bucket_count)

# COMMAND ----------

# diff_count="43195790"
# db_data=spark.read.parquet(missing_trace)
# db_data=db_data.groupBy("databasename").count()
# dblist=db_data.collect()
# dblist_count1=dblist[0][1]
# dblist_count2=dblist[1][1]
# dblist_count3=dblist[2][1]
# df = spark.read.parquet(missing_trace)
# df=df.groupBy("bucket").count()
# bucket_info=''
# for row in df.rdd.collect():
#     bucket_info= bucket_info + row[0] + ' of Missing Count: '+ str(row[1])+ ',  ' 

# success_info = ''
# if diff_count == 0:
#     success_info="succeeded" 
# else:
#     success_info = f"Mismatch of Count: {diff_count}"
# print(success_info)
# dbutils.notebook.exit({"diff_count": diff_count, "db1": dblist_count1, "db2": dblist_count2, "db3": dblist_count3, "bucket":bucket_info, "success":success_info})

# COMMAND ----------


end_date=curr_date-timedelta(5)
end_date_adls=curr_date
numdays=int(number_of_days)
start_date_adls=end_date_adls-timedelta(60)
start_date=end_date-timedelta(30)
dateparam=start_date_adls.strftime("%d%b%Y")
dateparam=dateparam.upper()
path=f"{baseurl}{file_path}/{dateparam}-*/*"
run_date=start_date_adls
print(start_date)
print(start_date_adls)
print(end_date)
print(end_date_adls)
dfstart=spark.read.text(path).selectExpr("substring_index(value,',',1) as transactionkey") 

while run_date < end_date_adls:
    run_date = run_date+timedelta(days=1)
    dateparam=run_date.strftime("%d%b%Y")
    dateparam=dateparam.upper()
    path=f"{baseurl}{file_path}/{dateparam}-*/*"
    try:
        df_mid = spark.read.text(path).selectExpr("substring_index(value,',',1) as transactionkey") 
        dfstart = dfstart.union(df_mid)
    except Exception as e:
        if 'java.io.FileNotFoundException' in str(e):
            print(f'File does not exists: {path}')
dfstart.write.mode("overwrite").parquet(adlspath)

# COMMAND ----------

db1=db_name1.lower()
conn_string1=conn_string.replace("{db}",db_name1)
max_received_date_path1 = max_received_date_path
received_date_path1 = f"{baseurl}{max_received_date_path}{db1}"
trace_df1 = spark.read.csv(received_date_path1)
max_received_adls1 = trace_df1.select("_c0").collect()[0][0]
max_query_string_DB1 = f"""(select   min(tracenumber) as mintracevalue,
                                    max(tracenumber) as maxtracevalue, 
                                    max(received) as maxreceiveddate 
                            from 
                                    oltp.MessageXmlExtended as msgxml with (nolock)  
                            where  
                                    received > convert(datetime, substring('{max_received_adls1}',0,20))) as T"""
df_db1 = spark.read.format("jdbc").option("url", conn_string1).option("dbtable", max_query_string_DB1).load()
df_db1=df_db1.cache()
min_tracenumber_DB1=df_db1.select("mintracevalue").collect()[0][0]
max_tracenumber_DB1 = df_db1.select("maxtracevalue").collect()[0][0]
max_received_date_DB1 = df_db1.select("maxreceiveddate").collect()[0][0]

# COMMAND ----------


fd_query_string1 = """(select bucket, tracenumber, received from {0}.{1} as msgxml with (nolock)  where received >= '{2}' and received <= '{3}') as x""".format(db_name1,table_name,start_date,end_date)
print(fd_query_string1)
# df_data1 = spark.read.format("jdbc").option("url", conn_string1).option("dbtable", fd_query_string1).load()
df_data1 = spark.read.format("jdbc").option("url", conn_string1).option("fetchsize",2000).option("numPartitions",16).option("dbtable", fd_query_string1).option("lowerBound", min_tracenumber_DB1).option("upperBound", max_tracenumber_DB1).option("partitionColumn","tracenumber").load()
df_data1=df_data1.withColumn("databasename", lit(db1))
df_data1.write.mode("overwrite").parquet(sqlpath1)

# COMMAND ----------

db2=db_name2.lower()
conn_string2=conn_string.replace("{db}",db_name2)
max_received_date_path2 = max_received_date_path
received_date_path2 = f"{baseurl}{max_received_date_path}{db2}"
trace_df2 = spark.read.csv(received_date_path2)
max_received_adls2 = trace_df2.select("_c0").collect()[0][0]
max_query_string_DB2 = f"""(select   min(tracenumber) as mintracevalue,
                                    max(tracenumber) as maxtracevalue, 
                                    max(received) as maxreceiveddate 
                            from 
                                    oltp.MessageXmlExtended as msgxml with (nolock)  
                            where  
                                    received > convert(datetime, substring('{max_received_adls2}',0,20))) as T"""
df_db2 = spark.read.format("jdbc").option("url", conn_string2).option("dbtable", max_query_string_DB2).load()
df_db2=df_db2.cache()
min_tracenumber_DB2=df_db2.select("mintracevalue").collect()[0][0]
max_tracenumber_DB2 = df_db2.select("maxtracevalue").collect()[0][0]
max_received_date_DB2 = df_db2.select("maxreceiveddate").collect()[0][0]

# COMMAND ----------


fd_query_string2 = """(select bucket, tracenumber, received from {0}.{1} as msgxml with (nolock)  where received >= '{2}' and received <= '{3}') as x""".format(db_name2,table_name,start_date,end_date)
print(fd_query_string2)
df_data2 = spark.read.format("jdbc").option("url", conn_string2).option("fetchsize",2000).option("numPartitions",16).option("dbtable", fd_query_string2).option("lowerBound", min_tracenumber_DB2).option("upperBound", max_tracenumber_DB2).option("partitionColumn","tracenumber").load()
df_data2=df_data2.withColumn("databasename", lit(db2))
df_data2.write.mode("overwrite").parquet(sqlpath2)

# COMMAND ----------

db3=db_name3.lower()
conn_string3=conn_string.replace("{db}",db_name3)
max_received_date_path3 = max_received_date_path
received_date_path3 = f"{baseurl}{max_received_date_path}{db3}"
trace_df3 = spark.read.csv(received_date_path3)
# max_tracenumber = trace_df.select("_c0").collect()[0][0]
max_received_adls3 = trace_df3.select("_c0").collect()[0][0]
max_query_string_DB3 = f"""(select   min(tracenumber) as mintracevalue,
                                    max(tracenumber) as maxtracevalue, 
                                    max(received) as maxreceiveddate 
                            from 
                                    oltp.MessageXmlExtended as msgxml with (nolock)  
                            where  
                                    received > convert(datetime, substring('{max_received_adls3}',0,20))) as T"""
df_db3 = spark.read.format("jdbc").option("url", conn_string3).option("dbtable", max_query_string_DB3).load()
df_db3=df_db3.cache()
min_tracenumber_DB3=df_db3.select("mintracevalue").collect()[0][0]
max_tracenumber_DB3 = df_db3.select("maxtracevalue").collect()[0][0]
max_received_date_DB3 = df_db3.select("maxreceiveddate").collect()[0][0]

# COMMAND ----------


fd_query_string3 = """(select bucket, tracenumber, received from {0}.{1} as msgxml with (nolock)  where received >= '{2}' and received <= '{3}') as x""".format(db_name3,table_name,start_date,end_date)
print(fd_query_string3)
df_data3 = spark.read.format("jdbc").option("url", conn_string3).option("fetchsize",2000).option("numPartitions",16).option("dbtable", fd_query_string3).option("lowerBound", min_tracenumber_DB3).option("upperBound", max_tracenumber_DB3).option("partitionColumn","tracenumber").load()
df_data3=df_data3.withColumn("databasename", lit(db3))
df_data3.write.mode("overwrite").parquet(sqlpath3)

# COMMAND ----------

df_data=spark.read.parquet(sqlpath).dropDuplicates()
df_adls=spark.read.parquet(adlspath).dropDuplicates()



# COMMAND ----------

diff_count = 0
diff= df_data.join(df_adls, df_data.tracenumber==df_adls.transactionkey, "left")\
    .where(col("transactionkey").isNull())
diff=diff.withColumn("breadcrumb", lit(curr_date))
diff.write.mode("overwrite").parquet(missing_trace)   
diff_count = diff.count() 

# COMMAND ----------

# missing_trace="abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/audit/ieprebdf/missing_trace/20240512"
# diff_count=0
db_data=spark.read.parquet(missing_trace)
# db_data.display()
db_data=db_data.groupBy("databasename").count()
db_data=db_data.withColumn("breadcrumb", lit(curr_date))
# db_data.display()
db_data.write.format("parquet").mode("overwrite").save(missing_trace_count)

# COMMAND ----------

dblist_count1=0
dblist_count2=0
dblist_count3=0
dblist=db_data.collect()
print(dblist)
if dblist:
    for row in dblist:
        if row[0] == 'rttransactionstore':
            dblist_count1=row[1]
        if row[0] == 'rttransactionstore_ds1':
            dblist_count2=row[1]
        if row[0] == 'rttransactionstore_ds2':
            dblist_count3=row[1]

dbutils.fs.rm(adlspath, True)
dbutils.fs.rm(sqlpath_rm, True)


# COMMAND ----------

df = spark.read.parquet(missing_trace)
df=df.groupBy("bucket").count()
df=df.withColumn("breadcrumb", lit(curr_date))
df.write.format("parquet").mode("overwrite").save(missing_bucket_count)

bucket_info=''
for row in df.rdd.collect():
    bucket_info= bucket_info + row[0] + ' of Missing Count: '+ str(row[1])+ ',  ' 
success_info = ''
if diff_count == 0:
    success_info="Succeeded" 
else:
    success_info = f"Mismatch of Count: {diff_count}"

dbutils.notebook.exit({"diff_count": diff_count, "db1": dblist_count1, "db2": dblist_count2, "db3": dblist_count3, "bucket":bucket_info, "success":success_info})

# COMMAND ----------

