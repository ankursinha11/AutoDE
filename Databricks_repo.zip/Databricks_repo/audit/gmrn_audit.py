# Databricks notebook source
dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("gmrn_publish_path","")
dbutils.widgets.getArgument("gmrn_publish_path")
gmrn_publish_path= getArgument("gmrn_publish_path")

dbutils.widgets.text("gmrn_audit_output_path","")
dbutils.widgets.getArgument("gmrn_audit_output_path")
gmrn_audit_output_path= getArgument("gmrn_audit_output_path")

dbutils.widgets.text("uc_catalog_name","")
dbutils.widgets.getArgument("uc_catalog_name")
uc_catalog_name= getArgument("uc_catalog_name")

dbutils.widgets.text("write_container","")
dbutils.widgets.getArgument("write_container")
write_container= getArgument("write_container")

dbutils.widgets.text("write_storageaccount","")
dbutils.widgets.getArgument("write_storageaccount")
write_storageaccount= getArgument("write_storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")


# COMMAND ----------

#read base url
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

#write base url
if user == 'na': #defualt value
    write_baseurl ='wasbs://'+write_container+'@'+write_storageaccount+'.blob.core.windows.net'
else:
    write_baseurl ='wasbs://'+write_container+'@'+write_storageaccount+'.blob.core.windows.net/'+user

uc_publish_schema = 'dataingestion'

print(f"read_baseurl : {baseurl}")
print(f"write_baseurl : {write_baseurl}")
print(f"uc_publish_schema : {uc_publish_schema}")

# COMMAND ----------

from pyspark.sql.functions import *
from datetime import datetime
import pytz

# COMMAND ----------

#read storage acct
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

#write storage acct
spark.conf.set("fs.azure.account.key."+write_storageaccount+".blob.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-prodicdst-insleads-kvsecret")) 

# COMMAND ----------

pathConnectionFile = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-dataingestion-sql-insleads-cs")

# COMMAND ----------

publishPath = baseurl + gmrn_publish_path
auditOutputPath = write_baseurl + gmrn_audit_output_path 
print("publishpath : " + publishPath)
print("output_path : " + auditOutputPath)

# COMMAND ----------

todayDate = datetime.utcnow()
bc = todayDate.astimezone(pytz.timezone('US/Central')).strftime('%Y%m%dT%H') 
print("bc:",bc)

# COMMAND ----------

tableLookup = [
    {
        "schema": "erelate.dbo",
        "table_name": "globalmrn",
        "primary_key": "globalmrnipk",
        "audit_location" : "adls"
    },
    {
        "schema": "erelate.dbo",
        "table_name": "globalmrndemographics",
        "primary_key": "globalmrndemographicsipk",
        "audit_location" : "adls"
    },
    {
        "schema": "erelate.dbo",
        "table_name": "globalmrnxhospinsurancecodes",
        "primary_key": "globalmrnxhospinsurancecodespk",
        "audit_location" : "adls"
    },
    {
        "schema": "erelate.dbo",
        "table_name": "globalmrnxpacct",
        "primary_key": "globalmrnxpacctipk",
        "audit_location" : "adls"
    },
    {
        "schema": "escan.dbo",
        "table_name": "globalmrnfamilyassociations",
        "primary_key": "globalmrnfamilyassociationpk",
        "audit_location" : "uc"
    }
]


# COMMAND ----------

for table in tableLookup:
    tableName = table["table_name"]
    primaryKey = table["primary_key"]
    schema = table["schema"]
    auditLocation = table["audit_location"]


    extractAggDataQuery = f"""
                 SELECT 
                 MIN(CAST({primaryKey} AS BIGINT)) AS MinpkSql,
                 MAX(CAST({primaryKey} AS BIGINT)) AS MaxpkSql,
                 COUNT_BIG(*) AS CountSql,
                 COUNT_BIG(DISTINCT CAST({primaryKey} AS BIGINT)) AS DistinctPkSql
                 FROM {schema}.{tableName}

    """

    sql_df = spark.read.format("jdbc").option("url", pathConnectionFile).option("query", extractAggDataQuery).load()
    sqlStats = sql_df.collect()[0]

    if auditLocation == "adls":
        adlsPath = publishPath + tableName + "/current/*"
        target_df = spark.read.parquet(adlsPath)
    elif auditLocation == "uc":
        target_df = spark.read.table(f"{uc_catalog_name}.{uc_publish_schema}.{tableName}")


    dbxStats = target_df.agg(
        min(col(primaryKey).cast("bigint")).alias("MinpkAdls"),
        max(col(primaryKey).cast("bigint")).alias("MaxpkAdls"),
        countDistinct(col(primaryKey).cast("bigint")).alias("DistinctPkAdls"),
    ).collect()[0]

    minPkDbx = dbxStats["MinpkAdls"]
    maxPkDbx = dbxStats["MaxpkAdls"]
    distinctPkDbx = dbxStats["DistinctPkAdls"]

    countDbx = target_df.count()

    countDifference = sqlStats["CountSql"] - countDbx
        
    differencePercentage = (countDifference / sqlStats["CountSql"]) * 100 if sqlStats["CountSql"]!= 0 else 0

    auditResults = []


    auditResults.append((tableName, sqlStats["CountSql"], countDbx,
                        countDifference,differencePercentage,
                        sqlStats["MinpkSql"], minPkDbx, 
                        sqlStats["MaxpkSql"], maxPkDbx,
                        sqlStats["DistinctPkSql"], distinctPkDbx))
    
    auditSchema = ["TableName", "RecordCountSql",  "RecordCountDbx", "RecordCountDifference(sql-dbx)", "Difference %", "MinpkSql", "MinpkDbx", "MaxpkSql", "MaxpkDbx" , "DistinctPkSql", "DistinctPkDbx"]

    audit_df = spark.createDataFrame(auditResults, auditSchema)

    audit_df = audit_df.withColumn(
        "AuditStatus",
        when(abs(audit_df["Difference %"]) > 5, "FAILED")
        .otherwise("PASSED")
    )

    audit_df = audit_df.withColumn("Rundate",lit(bc))  

    audit_df.write.mode("append").parquet(auditOutputPath)
