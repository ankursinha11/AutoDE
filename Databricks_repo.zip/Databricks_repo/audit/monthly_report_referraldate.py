# Databricks notebook source
# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

dbutils.widgets.text("dataingestion_publish_path","")
dbutils.widgets.getArgument("dataingestion_publish_path")
dataingestion_publish_path= getArgument("dataingestion_publish_path")

dbutils.widgets.text("leaddiscovery_publish_path","")
dbutils.widgets.getArgument("leaddiscovery_publish_path")
leaddiscovery_publish_path= getArgument("leaddiscovery_publish_path")

dbutils.widgets.text("scratch_path","")
dbutils.widgets.getArgument("scratch_path")
scratch_path= getArgument("scratch_path")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("num_of_days","")
dbutils.widgets.getArgument("num_of_days")
num_of_days= getArgument("num_of_days")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("write_container","")
dbutils.widgets.getArgument("write_container")
write_container= getArgument("write_container")

dbutils.widgets.text("write_storageaccount","")
dbutils.widgets.getArgument("write_storageaccount")
write_storageaccount= getArgument("write_storageaccount")


#read base url
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

#write base url
if user == 'na': #defualt value
    # wasbs://icdleadsreports@prodicdst.blob.core.windows.net/
    write_baseurl ='wasbs://'+write_container+'@'+write_storageaccount+'.blob.core.windows.net'
else:
    write_baseurl ='wasbs://'+write_container+'@'+write_storageaccount+'.blob.core.windows.net/'+user


dataingestion_publish_path = baseurl+dataingestion_publish_path
leaddiscovery_publish_path = baseurl+leaddiscovery_publish_path
pa_path=dataingestion_publish_path+'/patientaccts/current/20991231/'
scratch_path=write_baseurl+scratch_path



print("--------------------------------------------------------------------------------")
# print("bc="+str(bc))
print("container="+str(container))
print("dataingestion_publish_path="+str(dataingestion_publish_path))
print("leaddiscovery_publish_path="+str(leaddiscovery_publish_path))
print("scratch_path="+str(scratch_path))
print("storageaccount="+str(storageaccount))
print("user="+str(user))
print("--------------------------------------------------------------------------------")
print("pa_path="+str(pa_path))

# COMMAND ----------

#read storage acct
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

#write storage acct
spark.conf.set("fs.azure.account.key."+write_storageaccount+".blob.core.windows.net","IEfzxj47CMO5j8WXNcugYeiCG5Ip/pypR+apR+/eQUOUxA9wapX8oK6rIdn+K87Dvyezcix8wcSK+AStM0qxww==")

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
from io import BytesIO
import base64
from datetime import datetime
import pytz
from pyspark.sql.functions import lit
import os

# COMMAND ----------

my_datetime = datetime.utcnow()
bc = my_datetime.astimezone(pytz.timezone('US/Central')).strftime('%Y%m%dT%H') 
print("bc:",bc)

# COMMAND ----------

pxl = spark.read.format('delta').load(leaddiscovery_publish_path)
paxl_IX = pxl.filter("breadcrumb like '%-IX%'")
paxl_FC = pxl.filter("breadcrumb like '%-FC%'")
paxl_KC = pxl.filter("breadcrumb like '%-KC%'")
paxl_MC= pxl.filter("breadcrumb like '%-MC%'")
paxl_MA= pxl.filter("breadcrumb like '%-MA%'")
paxl_BM= pxl.filter("breadcrumb like '%-BM%'")
paxl_FF= pxl.filter("breadcrumb like '%-FF%'")
paxl_ES= pxl.filter("breadcrumb like '%-ES%'")
paxl_GM= pxl.filter("breadcrumb like '%-GM%'")
paxl_LV= pxl.filter("breadcrumb like '%-LV%'")
paxl_FM= pxl.filter("breadcrumb like '%-FM%'")
paxl_GH= pxl.filter("breadcrumb like '%-GH%'")
paxl_CH= pxl.filter("breadcrumb like '%-CH%'")
paxl_FI= pxl.filter("breadcrumb like '%-FI%'")
paxl_comm_gen = pxl.filter("breadcrumb not like '%-%'")

# COMMAND ----------

ediqueries = spark.read.format("delta").load(dataingestion_publish_path + "/ediqueries/current/20991231/")
ediqueries=ediqueries.selectExpr("hospitalfk", "patientacctifk","policyid as edi_coverageid","edipartnerfk","ediquerypk","trn","edi270querycomboifk")
ediqueries.createOrReplaceTempView("ediqueries")
ediqueries=spark.sql(""" SELECT * FROM ediqueries WHERE edi_coverageid IS NOT NULL """).dropDuplicates()
ediqueries.createOrReplaceTempView("ediqueries")

ediqueryhitsandmisses = spark.read.format("delta").load(dataingestion_publish_path + "/ediqueryhitsandmisses/current/20991231/")
ediqueryhitsandmisses=ediqueryhitsandmisses.selectExpr("ediqueryfk", "edipartnerfk","hospitalfk","result","edi270querycomboifk").dropDuplicates()
ediqueryhitsandmisses.createOrReplaceTempView("ediqueryhitsandmisses")
ediqueryhitsandmisses=spark.sql(""" SELECT * FROM ediqueryhitsandmisses WHERE trim(result) <> 'EB:V' """)
ediqueryhitsandmisses.createOrReplaceTempView("ediqueryhitsandmisses")
ediqueryhitsandmisses=spark.sql(""" SELECT *,CASE WHEN ediqueryhitsandmisses.result LIKE '%EB%' THEN 'Y' ELSE 'N' END AS isEdiQueryHit FROM ediqueryhitsandmisses """)
ediqueryhitsandmisses=ediqueryhitsandmisses.filter("isEdiQueryHit=='Y'")
ediqueryhitsandmisses.createOrReplaceTempView("ediqueryhitsandmisses")

ediqueryhitsandmisses1=spark.sql(""" SELECT *,CASE WHEN ediqueryhitsandmisses.result LIKE '%EB:1%' THEN 'Y' ELSE 'N' END AS isEdiQueryHit1 FROM ediqueryhitsandmisses """)
ediqueryhitsandmisses1=ediqueryhitsandmisses1.filter("isEdiQueryHit1=='Y'")
ediqueryhitsandmisses1.createOrReplaceTempView("ediqueryhitsandmisses1")


# ediqueries_ediqueryhitsandmisses=spark.sql("""
# SELECT 
#        ediqueries.hospitalfk,
#        ediqueries.patientacctifk,
#        ediqueries.edipartnerfk,
#        ediqueries.edi_coverageid,
#        ediqueryhitsandmisses.isEdiQueryHit
# FROM ediqueries 
#   INNER JOIN ediqueryhitsandmisses
#           ON ediqueries.edi270querycomboifk = ediqueryhitsandmisses.EDI270QueryComboIFK
#          AND ediqueries.ediquerypk = ediqueryhitsandmisses.ediqueryfk
# """).dropDuplicates()

ediqueries_ediqueryhitsandmisses1=spark.sql("""
SELECT 
       ediqueries.hospitalfk,
       ediqueries.patientacctifk,
       ediqueries.edipartnerfk,
       ediqueries.edi_coverageid,
       ediqueryhitsandmisses1.isEdiQueryHit
FROM ediqueries 
  INNER JOIN ediqueryhitsandmisses1
          ON ediqueries.edi270querycomboifk = ediqueryhitsandmisses1.EDI270QueryComboIFK
         AND ediqueries.ediquerypk = ediqueryhitsandmisses1.ediqueryfk
""").dropDuplicates()

# COMMAND ----------

fc = spark.read.format('delta').load(dataingestion_publish_path+"/foundcoverage/current/20991231/")#
fc = fc.filter("hitstatus == 1")
allpatientaccts = spark.read.format("delta").load(pa_path)
pa = allpatientaccts.where(datediff(current_date(),allpatientaccts.referraldate.cast(TimestampType())) <= int(num_of_days) )
egsd = spark.read.format('delta').load(dataingestion_publish_path+"/ediglobalsourceddata/current/20991231/")
egsd.createOrReplaceTempView("egsd")

# COMMAND ----------

pa_monthly=pa.withColumn("year",year("referraldate")).withColumn("month",month("referraldate")).groupBy("year","month").agg(count("*").alias("pa_count")).orderBy("year","month")

# COMMAND ----------

def get_monthly_data(paxl,fc,workflow_type):
    l_sent1 = pa.join(paxl, (pa.patientacctipk == paxl.patientacctifk)).select("patientacctipk","lsb_coverageid","lsb_edipartnerfk","referraldate",paxl_IX.hospitalfk,"edidatasourcefk").dropDuplicates()
   #  l_sent1 = l_sent.join(pa, on='patientacctipk', how='left') \
   #                 .select('patientacctipk', 'lsb_coverageid', 'referraldate')
    
    daxsentleads_monthly = l_sent1.withColumn("year", year("referraldate")) \
                                .withColumn("month", month("referraldate")) \
                                .groupBy("year", "month") \
                                .agg(count("*").alias("sentleads_count")) \
                                .orderBy("year", "month")

    l_sent2 = pa.join(paxl, (pa.patientacctipk == paxl.patientacctifk)).select("patientacctipk","referraldate").dropDuplicates()

    daxsentleads_monthly2 = l_sent2.withColumn("year", year("referraldate")) \
                                .withColumn("month", month("referraldate")) \
                                .groupBy("year", "month") \
                                .agg(count("*").alias("sentleads_unique_pa_count")) \
                                .orderBy("year", "month")

    paxeq=l_sent1.join(ediqueries,(l_sent1.hospitalfk == ediqueries.hospitalfk) &
                   (l_sent1.lsb_edipartnerfk == ediqueries.edipartnerfk)&(l_sent1.patientacctipk == ediqueries.patientacctifk)).select(l_sent1.patientacctipk,l_sent1.hospitalfk,"lsb_edipartnerfk","ediquerypk","lsb_coverageid","trn","edidatasourcefk","referraldate","edi270querycomboifk").dropDuplicates()
    join_withediqueries=paxeq.join(ediqueryhitsandmisses,(paxeq.ediquerypk == ediqueryhitsandmisses.ediqueryfk)& 
                               (paxeq.edi270querycomboifk == ediqueryhitsandmisses.edi270querycomboifk)).drop(ediqueryhitsandmisses.hospitalfk,"result","isEdiQueryHit").dropDuplicates()
    ediglobal=join_withediqueries.join(egsd,(join_withediqueries.hospitalfk == egsd.HospitalFK)&
                                   (join_withediqueries.trn == egsd.TRN)&
                                   (join_withediqueries.edipartnerfk == egsd.EDIPartnerFK)&
                                   (join_withediqueries.patientacctipk == egsd.PatientAcctIFK)&
                                   (join_withediqueries.edidatasourcefk == egsd.EDIDataSourceFK)).select(join_withediqueries.patientacctipk,"lsb_edipartnerfk","lsb_coverageid",join_withediqueries.edidatasourcefk,"referraldate").dropDuplicates()
    
    fc_send = fc.withColumnRenamed("patientacctifk", "fc_patientacctifk") \
           .withColumnRenamed("coverageid", "fc_coverageid")
    
    fc_sendleads = fc_send.join(ediglobal, 
                           on=(ediglobal.patientacctipk == fc_send.fc_patientacctifk) & 
                              (ediglobal.lsb_coverageid == fc_send.fc_coverageid)&
                              (ediglobal.lsb_edipartnerfk == fc_send.edipartnerfk), 
                           how='inner') \
                     .select(ediglobal.patientacctipk,'lsb_coverageid','lsb_edipartnerfk','referraldate')
    
    monthly_fc = fc_sendleads.withColumn("year", year("referraldate")) \
                             .withColumn("month", month("referraldate")) \
                             .groupBy("year", "month") \
                             .agg(count("*").alias("fc_count(edi_queries_verified_hit_count)")) \
                             .orderBy("year", "month")

    paxediqueries1 = ediqueries_ediqueryhitsandmisses1.join(fc_sendleads,
                              on=(fc_sendleads.patientacctipk == ediqueries_ediqueryhitsandmisses1.patientacctifk) & 
                              (fc_sendleads.lsb_coverageid == ediqueries_ediqueryhitsandmisses1.edi_coverageid)&
                              (fc_sendleads.lsb_edipartnerfk == ediqueries_ediqueryhitsandmisses1.edipartnerfk), 
                           how='inner') \
                     .select('patientacctipk', 'referraldate')

    monthly_edi_1 = paxediqueries1.withColumn("year", year("referraldate")) \
                             .withColumn("month", month("referraldate")) \
                             .groupBy("year", "month") \
                             .agg(count("*").alias("edi_queries_active_hit_count")) \
                             .orderBy("year", "month")

    final = monthly_fc.join(daxsentleads_monthly, on=["year", "month"]).join(monthly_edi_1, on=["year", "month"]).join(daxsentleads_monthly2,on=["year", "month"])\
                     .withColumn("workflow",lit(workflow_type))\
                     .withColumn("fc_matched%",round((col("fc_count(edi_queries_verified_hit_count)")/col("sentleads_count"))*100,2)).orderBy("year", "month")\
                     .withColumn("fc_hits%",round((col("edi_queries_active_hit_count")/col("sentleads_count"))*100,2)).orderBy("year", "month")  
    return final

# COMMAND ----------

df_ix = get_monthly_data(paxl_IX,fc,'Leadpropagation from ICH (IX)')
df_fc = get_monthly_data(paxl_FC,fc,'Leadpropagation from Foundcoverage (FC)')
df_kc = get_monthly_data(paxl_KC,fc,'Known Commercial (KC)')
df_mc = get_monthly_data(paxl_MC,fc,'Medicare (MC)')
df_ma = get_monthly_data(paxl_MA,fc,'Medicaid (MA)')
df_bm = get_monthly_data(paxl_BM,fc,'BirthMonth (BM)')
df_ff = get_monthly_data(paxl_FF,fc,'Familyclustering leads from FoundCoverage (FF)')
df_es = get_monthly_data(paxl_ES,fc,'Leadpropagation from patientaccts (ES)')
df_gm = get_monthly_data(paxl_GM,fc,'Leadpropagation from GMRN (GM)')
df_lv = get_monthly_data(paxl_LV,fc,'LeadVerify (LV)')
df_fm = get_monthly_data(paxl_FM,fc,'Familyclustering leads from patientaccts (FM)')
df_gh = get_monthly_data(paxl_GH,fc,'Leadpropagation rom hfc(GH)')
df_ch = get_monthly_data(paxl_CH,fc,'Carrier files (CH)')
df_comm_gen = get_monthly_data(paxl_comm_gen,fc,'commercial generation')
df_fi = get_monthly_data(paxl_FI,fc,'Familyclustering leads from ICH (FI)')

# COMMAND ----------

df_report = df_ix.union(df_fc).union(df_kc).union(df_mc).union(df_ma).union(df_bm).union(df_ff).union(df_es).union(df_gm).union(df_lv).union(df_fm).union(df_gh).union(df_ch).union(df_comm_gen).union(df_fi)
df_report = df_report.join(pa_monthly,on=["year","month"],how='left')

# COMMAND ----------

cols=["year","month","pa_count","sentleads_count","sentleads_unique_pa_count","fc_count(edi_queries_verified_hit_count)","fc_matched%","edi_queries_active_hit_count","fc_hits%","workflow"]
df_final=df_report.select(cols).orderBy("year","month")

# COMMAND ----------

df_final = df_final.withColumn("rundate",lit(bc))

# COMMAND ----------

if not os.path.exists(scratch_path):
    df_final.write.mode("append").parquet(scratch_path)
else:
    df_final.write.mode("overwrite").parquet(scratch_path)
print(scratch_path)
