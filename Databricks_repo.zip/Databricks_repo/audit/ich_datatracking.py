# Databricks notebook source
# MAGIC %pip install sendgrid

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("cdd_dir","")
dbutils.widgets.getArgument("cdd_dir")
cdd_dir= getArgument("cdd_dir")

dbutils.widgets.text("leadrepo_dir","")
dbutils.widgets.getArgument("leadrepo_dir")
leadrepo_dir= getArgument("leadrepo_dir")

dbutils.widgets.text("lsb_dir","")
dbutils.widgets.getArgument("lsb_dir")
lsb_dir= getArgument("lsb_dir")

dbutils.widgets.text("FROM_EMAIL","")
dbutils.widgets.getArgument("FROM_EMAIL")
FROM_EMAIL= getArgument("FROM_EMAIL")

dbutils.widgets.text("TO_EMAIL","")
dbutils.widgets.getArgument("TO_EMAIL")
TO_EMAIL= getArgument("TO_EMAIL")

dbutils.widgets.text("maprdbtable", "runstatus")
maprdbtable = dbutils.widgets.getArgument("maprdbtable")
print(maprdbtable)

dbutils.widgets.text("cosmosendpoint", "")
dbutils.widgets.getArgument("cosmosendpoint")
cosmosendpoint = getArgument("cosmosendpoint")
print(cosmosendpoint)

dbutils.widgets.text("cosmosdb", "insleads")
dbutils.widgets.getArgument("cosmosdb")
cosmosdb= getArgument("cosmosdb")
print(cosmosdb)

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user
print("baseurl : "+baseurl)

# COMMAND ----------

# MAGIC %run /Workspace/Insleads-code/Common-Util/cosmos_util

# COMMAND ----------

cdd_dir = baseurl + cdd_dir
leadrepo_dir = baseurl + leadrepo_dir
lsb_dir = baseurl + lsb_dir
print("cdd_dir : " + cdd_dir)
print("leadrepo_dir : " + leadrepo_dir)
print("lsb_dir : " + lsb_dir)
# print("bc : ", bc)

# COMMAND ----------

from delta.tables import DeltaTable
from pyspark.sql.functions import *
import sendgrid
from sendgrid.helpers.mail import *
from pyspark.sql.types import *
from pyspark.sql.window import Window

# COMMAND ----------

config = cosmosconfig(cosmosendpoint, cosmosdb, maprdbtable)

# COMMAND ----------

try:
    cosmos_read = readfromcosmosdb(config).where(
        "notificationtype='ie_xref_lsb' and processed='processed' and processedon not like'%merged%'"
    ).orderBy("createdon", ascending=False).limit(1)

    # display(cosmos_read)
    bc=cosmos_read.select("bc").collect()[0][0]
except Exception as e:
    raise Exception("Error reading from cosmosdb : {}".format(e))

# COMMAND ----------

processed_df = cosmos_read.withColumn("processed_bc",substring(col("processedon"), 0, 10))
lsb_bc=processed_df.select("processed_bc").collect()[0][0]

# COMMAND ----------

ieincpostbdf_schema = StructType([ \
        StructField("tracenumber", StringType(), nullable=True), \
        StructField("received", StringType(), nullable=True), \
        StructField("providerid", StringType(), nullable=True), 
        StructField("providerlastnameorgname", StringType(), nullable=True), \
        StructField("subscriberlastname", StringType(), nullable=True), \
        StructField("subscriberfirstname", StringType(), nullable=True), \
        StructField("subscribermiddlename", StringType(), nullable=True), \
        StructField("subscribergender", StringType(), nullable=True), \
        StructField("subscriberdOb", StringType(), nullable=True), \
        StructField("subscriberssn", StringType(), nullable=True), \
        StructField("subscribergroupnumber", StringType(), nullable=True), \
        StructField("subscribersuffixcode", StringType(), nullable=True), \
        StructField("subscriberidcode", StringType(), nullable=True), \
        StructField("subscriberid", StringType(), nullable=True), \
        StructField("subscriberaddress", StringType(), nullable=True), \
        StructField("subscriberstate", StringType(), nullable=True), \
        StructField("subscribercity", StringType(), nullable=True), \
        StructField("subscriberZip", StringType(), nullable=True), \
        StructField("dependentlastname", StringType(), nullable=True), \
        StructField("dependentfirstname", StringType(), nullable=True), \
        StructField("dependentgender", StringType(), nullable=True), \
        StructField("dependentdob", StringType(), nullable=True), \
        StructField("dependentssn", StringType(), nullable=True), \
        StructField("dateofservice", StringType(), nullable=True), \
        StructField("responseresultext", StringType(), nullable=True), \
        StructField("responseresultstd", StringType(), nullable=True), \
        StructField("payerid", StringType(), nullable=True), \
        StructField("payerproviderid", StringType(), nullable=True), \
        StructField("payerlastnameorgname", StringType(), nullable=True), \
        StructField("clientid", StringType(), nullable=True), \
        StructField("breadcrumbs", StringType(), nullable=True), \
        StructField("custom1", StringType(), nullable=True), \
        StructField("custom2", StringType(), nullable=True), \
        StructField("filenum", StringType(), nullable=True), \
        StructField("recordnum", StringType(), nullable=True), \
        StructField("magnetpermid", StringType(), nullable=True), \
        StructField("iepermid", StringType(), nullable=False), \
        StructField("matchind", StringType(), nullable=True), \
        StructField("linkid", StringType(), nullable=True) \
        ])

# COMMAND ----------

print("bc",bc)
print("lsb_bc",lsb_bc)
raw_data = spark.read.text(cdd_dir + "/staging/ie/sqoop/" + bc + "/*")
staging_op=spark.read.text(cdd_dir +"/staging/input/ie/"+bc + "/*")
parsed_demog=spark.read.text(cdd_dir +"/transform/intermediate_tmp/ie/271_parsed/"+bc + "/*")
parsed_270=spark.read.csv(cdd_dir +"/transform/output/parsed_270/"+bc + "/*")
parsed_all = spark.read.csv(cdd_dir +"/publish/ie/parsed_all/"+ bc + "/*")
good_recs=spark.read.csv(cdd_dir +"/transform/output/ie/filtered/"+ bc + "/*")
bad_recs=spark.read.csv(cdd_dir +"/transform/output/ie/wBadChars/"+ bc + "/*")
bdf_deduped=spark.read.csv(cdd_dir+"/transform/output/ie/bdf_deduped/"+ bc + "/*")
up_bdf=spark.read.text(cdd_dir+"/transform/output/ie/package_bdf/"+ bc + "/merge/merge.txt")
lr_ich_extract_trans_demo=spark.read.text(leadrepo_dir+"/transform/scratch/ie_output/lr_ich_xml_parsed/transaction/"+bc)
finalPolicyInfo=spark.read.format('csv').load(cdd_dir+"/publish/ie/imRecs/"+bc+"*",sep='|',schema=ieincpostbdf_schema)
ie_cm2_finalPolicyInfo=spark.read.csv(cdd_dir+"/publish/ie_cm2/finalPolicyInfo/"+bc,sep='|')
lr_transaction=spark.read.parquet(leadrepo_dir+"/publish/cooked/lr_transaction/")
lr_transaction_filtered=lr_transaction.filter(lr_transaction.lr_creatingmodule==bc)
jsondemog=spark.read.parquet(lsb_dir+"/transform/scratch/ich/"+bc)
new_permid_ich_map_op=spark.read.parquet(lsb_dir+"/transform/scratch/leadservicebase/new_permid_ich_map_op/"+bc)
new_permid_ich_map_op=new_permid_ich_map_op.select("identity").distinct()
new_gmrnid_ich_map_op=spark.read.parquet(lsb_dir+"/transform/scratch/leadservicebase//new_gmrnid_ich_map_op/"+bc)
new_gmrnid_ich_map_op=new_gmrnid_ich_map_op.select("identity").distinct()

# COMMAND ----------

try:
    dataframes=[("ie_prebdf","raw_data",raw_data,"Sqooped Raw Data"),
                ("ie_prebdf","staging_op",staging_op,"Filter on clientid not in ('100515','100000','100523','0')) and (tmp.userid != '2344720')t_id "), ("ie_prebdf","parsed_demographics",parsed_demog,"O/P of Parsed Demographics"),
                ("ie_prebdf","cleansed_demographics",parsed_270,"Filter on Response Result Std not in 3,0. St01='271'. isValidDemographic=='1'- Unique  transactions"),
                ("ie_prebdf","parsed_all",parsed_all,"Filter on clientIdsToBlock, Subscriber & Dependent "),
                ("ie_prebdf","ie_filter_good_recs",good_recs,"Subscriber & Dependent"),
                ("ie_prebdf","ie_filter_bad_recs",bad_recs,"Bad records"),
                ("ie_prebdf","process_dupes",bdf_deduped,"group by on demographics"),
                ("ie_prebdf","sent_to_bcs",up_bdf,"Unique demographics only"),
                ("ie_postbdf","Permid's assigned",finalPolicyInfo,"Total permid's assigned"),
                ("ie_postbdf","GMRNId's assigned",ie_cm2_finalPolicyInfo,"Total gmrnid's assigned"),
                ("ich_import","lr_ich_extract_trans_demo",lr_ich_extract_trans_demo,"Filter on Response Result Std not in [3,'']"),
                ("ich_import","lr_transaction",lr_transaction_filtered,"Records appended to lr_transaction. We are mapping payerid with partner"),
                ("leadservicebase","ich_payer_id mapping",jsondemog,"tu_payerid"),
                ("leadservicebase","Unique permid before lsb merge",new_permid_ich_map_op,"Count of unique permid's"),
                ("leadservicebase","Unique gmrnid before lsb merge",new_gmrnid_ich_map_op,"Count of unique gmrnid's")
                ]

    count_data=[(project,name,df.count(),description) for project, name,df,description in dataframes]
    counts_df=spark.createDataFrame(count_data,['Project','Steps','Count','Description'])
except Exception as e:
    raise Exception("Error creating Dataframe: {}".format(e))

# COMMAND ----------

# DBTITLE 1,lsb
lsb= DeltaTable.forPath(spark,lsb_dir+"/publish/served/leadservicebase/")
hist= lsb.history()
#df=hist.filter("timestamp like '2024-10-24%'")
df = hist.filter(f"timestamp like '{lsb_bc}%'")
inserts_df=df.filter((df.job.jobName.contains('permid_insert_ie'))|(df.job.jobName.contains('gmrn_insert_ie'))).filter("operation='MERGE'")

# COMMAND ----------

try:
    stats = inserts_df.select(collect_list("operationMetrics.numTargetRowsInserted").alias("inserts"),collect_list("operationMetrics.numTargetRowsUpdated").alias("updates")).collect()[0]
    new_dataframes=[("leadservicebase","permid_inserts",stats.inserts[0],"permid's inserted into lsb"),
                        ("leadservicebase","gmrn_inserts",stats.inserts[1],"gmrn's inserted into lsb"),
                        ("leadservicebase","permid_updates",stats.updates[0],"permid's updated into lsb"),
                        ("leadservicebase","gmrn_updates",stats.updates[1],"gmrn's updated into lsb")]
    lsb_df=spark.createDataFrame(new_dataframes,['Project','Steps','Count','Description'])
    final_df=counts_df.union(lsb_df)
    windowSpec= Window.orderBy(monotonically_increasing_id())
    df_1=final_df.withColumn("SNo",row_number().over(windowSpec))
    df_final = df_1.select(col("SNo").alias("S.No"), *df_1.columns).drop("SNo")
except Exception as e:
    raise Exception("Error getting counts from lsb: {}".format(e))

# COMMAND ----------

df = df_final.toPandas().applymap(lambda x:str(x)[0:150])
bodyhtml = ""
bodyhtml = bodyhtml + '<br><p class = "TableTitle">ICH Audit</p></br> '+df.to_html(index=False,justify="center")+'</p>'

# COMMAND ----------

try:
    sg= sendgrid.SendGridAPIClient(api_key=dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-email-sendgrid-api-key"))
    email =Mail(
        from_email=FROM_EMAIL,
        to_emails=TO_EMAIL,
        subject='ICH Data tracking Audit for '+ bc,
        html_content=bodyhtml
    )
    response = sg.send(email)
    
except Exception as e:
    raise Exception("Error sending a Email: {}".format(e))
