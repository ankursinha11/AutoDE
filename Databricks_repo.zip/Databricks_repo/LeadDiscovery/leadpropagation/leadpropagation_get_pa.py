# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("hdfs_data_path","")
dbutils.widgets.getArgument("hdfs_data_path")
hdfs_data_path= getArgument("hdfs_data_path")

dbutils.widgets.text("hdfs_lsb_scratch","")
dbutils.widgets.getArgument("hdfs_lsb_scratch")
hdfs_lsb_scratch= getArgument("hdfs_lsb_scratch")

dbutils.widgets.text("permIdPatientAcctId_path","")
dbutils.widgets.getArgument("permIdPatientAcctId_path")
permIdPatientAcctId_path= getArgument("permIdPatientAcctId_path")

dbutils.widgets.text("gmrn_publish_path","")
dbutils.widgets.getArgument("gmrn_publish_path")
gmrn_publish_path= getArgument("gmrn_publish_path")

dbutils.widgets.text("pa_op_path","")
dbutils.widgets.getArgument("pa_op_path")
pa_op_path= getArgument("pa_op_path")

dbutils.widgets.text("dataset","")
dbutils.widgets.getArgument("dataset")
dataset= getArgument("dataset")


# COMMAND ----------

# bc = "06OCT2024-23"
# container = "prod-icd-stg-adls"
# dataset = "ie_propagation_famc"
# gmrn_publish_path = "/data/gmrn/publish"
# hdfs_data_path = "/data/dataingestion/publish"
# hdfs_lsb_scratch = "/data/leadservicebase/transform/scratch/leadservicebase/"
# pa_op_path = "/data/leaddiscovery/transform/scratch/leadpropagation"
# permIdPatientAcctId_path = "/data/cdd/publish/permidpatientacctid/*"
# storageaccount = "prodicdstgdls"
# user = "vishnup"

# COMMAND ----------

# DBTITLE 1,Access Initialization : Pipeline-Mode 
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))


# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

print ("baseurl : " + str(baseurl))

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/tu_data_quality

# COMMAND ----------

import os
import sys
import subprocess
import datetime
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark import SparkContext
from pyspark.conf import SparkConf

# COMMAND ----------

def create_temp_data(spark,hdfs_data_path,hdfs_tmp_data_path,dataset):

    #get all data for past 1 year and totalcharges>0, all qualifying flags and store in temp data alongwith gmrnid, permid

    pacctscols = ["patientacctipk", "hospitalfk", "firstname", "middlename", "lastname", "ssn", "dob", "gender",
                  "state", "admitdate", "referraldate", "dischargedate", "medicalrecnum", "clusteredacctfk", "totalcharges", "createdate", "updatedate",
                  "demographicsupdatedate","medicarehic", "medicaidnum"]
    padata = extract_deltalake_data(spark, hdfs_data_path + "/patientaccts/current/20991231/", pacctscols)
    padata = padata.withColumn('totalcharges', padata.totalcharges.cast("decimal(32,4)"))
    #padata = padata.withColumn('totalcharges', padata.totalcharges.cast("string"))
    padata = padata.withColumn('clusteredacctfk', padata.clusteredacctfk.cast("string"))
    padata = padata.where(padata.totalcharges > 0 )
    if(dataset=='chc_xref_lsb_propagation') :
      padata = padata.where(datediff(current_date(),padata.admitdate.cast(TimestampType())) < 730 )
    else :
      padata = padata.where(datediff(current_date(),padata.admitdate.cast(TimestampType())) < 366 )
    # padata = padata.where(datediff(current_date(),padata.demographicsupdatedate.cast(TimestampType())) < 100 ) #for famc
    #padata=  spark.read.parquet(baseurl+'/data/leadpropogation/testdata/lead_prop_getpa_padata')
    vsnapcols = ["patientacctifk", "hospitalfk","knowntricareflag","knownmcaidflag","primarymcaidflag","secondarymcaid_afterinsuranceflag","hasmedicareflag"]
    vsnapflags = extract_deltalake_data(spark, hdfs_data_path + "/vsnappatientacctsflags/current/20991231/", vsnapcols)
    ha = readparquet(spark, hdfs_data_path + "/hospitalattributes/current/*","0","na")
    hav = readparquet(spark, hdfs_data_path + "/hospitalattributevalues/current/*","0","na")
    havalues = ha.join(hav, hav.hospitalattributefk == ha.hospitalattributepk) \
                 .filter(hav.hospitalattributefk == 25) \
                 .select(hav.hospitalfk, hav.hospitalattributefk, hav.hospitalattributevalue)
    padata.createOrReplaceTempView("patientaccts")
    havalues.createOrReplaceTempView("vwhospitalattributevalues")
    vsnapflags.createOrReplaceTempView("vsnappatientacctsflags")
    paccts = spark.sql("""
                      SELECT DISTINCT p.patientacctipk as patientacctifk, p.hospitalfk, firstname, middlename, lastname, ssn,dob,gender,
                        state, admitdate,referraldate,dischargedate,demographicsupdatedate,medicalrecnum,clusteredacctfk,totalcharges,
                        createdate,updatedate,paf.knowntricareflag,paf.knownmcaidflag,p.medicarehic,p.medicaidnum,
                        CASE WHEN (
                               paf.primarymcaidflag = 1
                            OR (
                                    ((paf.knownmcaidflag = 1) OR (paf.knowntricareflag = 1))
                                AND (paf.secondarymcaid_afterinsuranceflag = 0)
                                AND (paf.hasmedicareflag = 0 )
                               )
                            OR (paf.hasmedicareflag =1 and (hospitalattributevalue=1))
                            )                         THEN 1 ELSE 0 END as commericalflag,
                        CASE WHEN hasmedicareflag = 1 THEN 0 ELSE 1 END as medicareflag,
                        CASE WHEN knownmcaidflag = 1  THEN 0 ELSE 1 END as medicaidflag
                      FROM patientaccts p
                      LEFT JOIN vsnappatientacctsflags paf on paf.hospitalfk = p.hospitalfk
                           AND p.patientacctipk = paf.patientacctifk
                      LEFT JOIN vwhospitalattributevalues hv on hv.hospitalfk = p.hospitalfk
                      """)
#   paccts = paccts.where( (paccts.commericalflag==1) | (paccts.medicareflag==1) | (paccts.medicaidflag==1) )
    paccts = paccts.where( (paccts.commericalflag==1) )

    writeparquet(spark,paccts,hdfs_tmp_data_path + "/selfpaypaccts",50,"overwrite")

    padata = readparquet(spark,hdfs_tmp_data_path + "/selfpaypaccts","0","na")
    # print("PATACC COUNT : "+str(padata.count()))
    isValidCA_udf = udf(isValidCA, IntegerType())
    isValidSSN_udf = udf(isValidSSN, IntegerType())
    isValidMRN_udf = udf(isValidMRN_ver2, IntegerType())

    padata = padata.withColumn("ssn_valid",isValidSSN_udf(padata.ssn))
    padata = padata.withColumn("ca_valid",isValidCA_udf(padata.clusteredacctfk))
    padata = padata.withColumn("mrn_valid",isValidMRN_udf(padata.medicalrecnum))

    gmrn_cols = ["patientacctifk","hospitalfk","globalmrnifk"]
    gmrnxpacct =  readparquet(spark,gmrn_publish_path,"0",gmrn_cols)

    perm_cols = ["patientacctifk","permid","matchind","hospitalfk"]
    permxpacct =  readparquet(spark, permIdPatientAcctId_path,"0",perm_cols)
    permxpacct = permxpacct.filter((col("matchind") == 'IM') | (col("matchind") == 'M1'))

    gmrnxpacct_sub = padata.join(gmrnxpacct, (padata.patientacctifk==gmrnxpacct.patientacctifk) & (padata.hospitalfk==gmrnxpacct.hospitalfk),"left")\
                           .join(permxpacct, (padata.patientacctifk==permxpacct.patientacctifk) & (padata.hospitalfk==permxpacct.hospitalfk),"left")\
                           .where( ((~gmrnxpacct.patientacctifk.isNull()) & (~gmrnxpacct.hospitalfk.isNull())) | ((~permxpacct.patientacctifk.isNull()) & (~permxpacct.hospitalfk.isNull())) | ( padata.ssn_valid == 1 )  | ( padata.mrn_valid == 1 ) | ( padata.ca_valid == 1) )\
                           .select(padata['*'],gmrnxpacct.globalmrnifk,permxpacct.permid).dropDuplicates()

    writeparquet(spark,gmrnxpacct_sub,hdfs_tmp_data_path + "/selfpaypacctsxidentity",50,"overwrite")




# COMMAND ----------

def propagate_leads(spark, lsb_op_path, hdfs_data_path,  identity):
    
    finalcols = ["patientacctifk", "hospitalfk", "firstname", "middlename", "lastname", "ssn","dob","gender","state", "admitdate","referraldate","dischargedate","demographicsupdatedate","medicalrecnum","clusteredacctfk","totalcharges","createdate","updatedate","knowntricareflag","knownmcaidflag","lsb_edipartnerfk","lsb_coverageid","lsb_hcsystemfk","lsb_source","lsb_id","lsb_leadcreatedate","lsb_leadupdatedate","lsb_identity","lsb_hospitalfklst","lsb_leadsource","lsb_xrefsource","lsb_firstname","lsb_lastname","lsb_dob","lsb_middlename","lsb_gender","lsb_ssn","lsb_state","lsb_demoupdatedate","keyname", "medicarehic", "medicaidnum"]
   
   
    
    ###############read raw leads and transform BEGIN ######################

    data = readparquet(spark, lsb_op_path, "0", "na")
    #transform raw leads
    if identity=="globalmrnifk":
      identity_prefix="G_"

    if identity=="permid":
      identity_prefix="P_"

    if identity=="ssn":
      identity_prefix="S_"

    if identity=='clusteredacctfk':
      identity_prefix="CH_"
    
    if identity=='medicalrecnum':
      identity_prefix="MH_"


    for column in data.columns:
        data = data.withColumn(column, trim(col(column)))
        data = data.withColumn(column, when(col(column).isNull(), 'XX').otherwise(col(column)))
        data = data.withColumn(column, when(col(column) == '', 'XX').otherwise(col(column)))
        data = data.withColumn(column, when(col(column) == 'null', 'XX').otherwise(col(column)))
        data = data.withColumn(column, when(col(column) == ' ', 'XX').otherwise(col(column)))

    data = data.withColumn("keyname",  when(data._id_updated.startswith("G_"),lit("globalmrnifk"))\
                                  .when(data._id_updated.startswith("P_"),lit("permid"))\
	    			              .when(data._id_updated.startswith("S_"),lit("ssn"))\
                                  .when(data._id_updated.startswith("CH_"),lit("clusteredacctfk"))\
                                  .when(data._id_updated.startswith("MH_"),lit("medicalrecnum"))\
				                  .otherwise(lit("")))

    data.createOrReplaceTempView("data")

    data=spark.sql("""
    SELECT _id_updated                         AS lsb_id,
       keyname,
       split(hcsystemfk_source_updated,"_")[0] AS lsb_hcsystemfk,
       split(hcsystemfk_source_updated,"_")[1] AS lsb_source,
       identity_updated                        AS lsb_identity,
       leadcreatedate_updated                  AS lsb_leadcreatedate,
       split(leadid_updated,"_")[0]            AS lsb_edipartnerfk,
       split(leadid_updated,"_")[1]            AS lsb_coverageid,
       leadupdatedate_updated                  AS lsb_leadupdatedate,
       lsbcreatedate_updated,
       lsbupdatedate_updated,
       dob_updated                             AS lsb_dob,
       firstname_updated                       AS lsb_firstname,
       middlename_updated                      AS lsb_middlename,
       gender_updated                          AS lsb_gender,
       hospitalfk_updated                      AS lsb_hospitalfklst,
       lastname_updated                        AS lsb_lastname,
       leadsource_updated                      AS lsb_leadsource,
       ssn_updated                             AS lsb_ssn,
       state_updated                           AS lsb_state,
       updatedate_updated                      AS lsb_demoupdatedate,
       xrefsource_updated                      AS lsb_xrefsource
    FROM   data
    WHERE  hcsystemfk_source_updated <> 'XX'
    AND    leadid_updated <> 'XX'
    """).dropDuplicates()

    data = data.withColumn("lsb_hospitalfklst", regexp_replace(col("lsb_hospitalfklst"), "\\|", ","))
    data = data.withColumn("lsb_hospitalfklst", split(col("lsb_hospitalfklst"),","))
    data = data.withColumn("lsb_leadsource", regexp_replace(col("lsb_leadsource"), "\\|", ","))
    data = data.withColumn("lsb_leadsource", split(col("lsb_leadsource"),","))
    data = data.withColumn("lsb_xrefsource", regexp_replace(col("lsb_xrefsource"), "\\|", ","))
    data = data.withColumn("lsb_xrefsource", split(col("lsb_xrefsource"),","))
    data = data.withColumn('demohash', hash(concat_ws(":", data.lsb_firstname, data.lsb_middlename, data.lsb_lastname, data.lsb_gender, data.lsb_dob, data.lsb_ssn, data.lsb_state)))

    data = data.withColumn("lookupvalue", col("lsb_identity"))
    data = data.withColumn("raw_lookupvalue", regexp_replace(col("lookupvalue"), identity_prefix, ""))
    data = data.withColumn("parsed_lookupvalue", regexp_replace(col("lookupvalue"), identity_prefix, ""))

    #data = data.withColumn("raw_lookupvalue",\
    #                                   when(data.lookupvalue.startswith("CH_"),split(data.lookupvalue,'_').getItem(2))\
    #                                  .when(data.lookupvalue.startswith("MH_"),split(data.lookupvalue,'_').getItem(2))\
    #				                  .otherwise(data.parsed_lookupvalue))

    data.createOrReplaceTempView("data")
    final = spark.sql("""
    SELECT lsb_coverageid,
           lsb_hcsystemfk,
           lsb_source,
           lsb_id,
           lsb_leadcreatedate,
           lsb_leadupdatedate,
           lsb_identity,
           lsb_hospitalfklst,
           lsb_leadsource,
           lsb_xrefsource,
           CASE WHEN lsb_firstname='XX'  THEN '' ELSE lsb_firstname  END AS lsb_firstname,
           CASE WHEN lsb_lastname='XX'   THEN '' ELSE lsb_lastname   END AS lsb_lastname,
           CASE WHEN lsb_dob='XX'        THEN '' ELSE lsb_dob        END AS lsb_dob,
           CASE WHEN lsb_middlename='XX' THEN '' ELSE lsb_middlename END AS lsb_middlename,
           CASE WHEN lsb_gender='XX'     THEN '' ELSE lsb_gender     END AS lsb_gender,
           CASE WHEN lsb_ssn='XX'        THEN '' ELSE lsb_ssn        END AS lsb_ssn,
           CASE WHEN lsb_state='XX'      THEN '' ELSE lsb_state      END AS lsb_state,
           lsb_demoupdatedate,
           CAST(lsb_edipartnerfk AS SMALLINT) AS lsb_edipartnerfk,
           demohash,
           lookupvalue,
           parsed_lookupvalue,
           raw_lookupvalue,
           keyname,
           ROW_NUMBER() OVER (PARTITION BY lookupvalue,lsb_edipartnerfk,lsb_coverageid,lsb_hcsystemfk ORDER BY CAST(lsb_demoupdatedate AS TIMESTAMP) DESC,demohash DESC) AS rn
        FROM data
    """)
    leadstopropagate = final.filter("rn = 1").drop("rn").dropDuplicates()
    #leadstopropagate = parse_concat_columns(spark,df,identity)
    #write out data
    writeparquet(spark,leadstopropagate,hdfs_data_path + "/propagateleads_" + identity, 50,"overwrite")
    
    ###############read raw leads and transform END ######################
    
    #read leads
    df1 = readparquet(spark, hdfs_data_path + "/propagateleads_" + identity + "/*", "0", "na")

    #read self-pay accounts
    df2 = readparquet(spark, hdfs_data_path + "/selfpaypacctsxidentity/*", "0", "na")

    if identity=="globalmrnifk":
      isValidNumber_udf = udf(isNumber, IntegerType())
      df1 = df1.withColumn("gid_valid",isValidNumber_udf(df1.parsed_lookupvalue))
      df2 = df2.withColumn("gid_valid",isValidNumber_udf(df2.globalmrnifk))
      joinExpr = (df1.parsed_lookupvalue == df2.globalmrnifk) 
      whereExprs = ( (df1.keyname == "globalmrnifk") & (df1.gid_valid==1) & (df2.gid_valid==1) )

    if identity=="permid":
      isValidPID_udf = udf(isValidPID, IntegerType())
      df1 = df1.withColumn("pid_valid",isValidPID_udf(df1.parsed_lookupvalue))
      df2 = df2.withColumn("pid_valid",isValidPID_udf(df2.permid))
      joinExpr = (df1.parsed_lookupvalue == df2.permid) 
      whereExprs = ( (df1.keyname == "permid") & (df1.pid_valid==1) & (df2.pid_valid==1) )

    if identity=="ssn":
      isValidSSN_udf = udf(isValidSSN, IntegerType())
      df1 = df1.withColumn("ssn_valid",isValidSSN_udf(df1.parsed_lookupvalue))
      #df2 = df2.withColumn("ssn_valid",isValidSSN_udf(df2.ssn))
      joinExpr = (df1.parsed_lookupvalue == df2.ssn) 
      whereExprs = (df1.keyname == "ssn") & (df1.ssn_valid==1) & (df2.ssn_valid==1) 

    if identity=='clusteredacctfk':
      isValidCA_udf = udf(isValidCA, IntegerType())
      df1 = df1.withColumn("ca_valid",isValidCA_udf(df1.raw_lookupvalue))
      #df2 = df2.withColumn("ca_valid",isValidCA_udf(df2.clusteredacctfk))
      joinExpr = ( df1.parsed_lookupvalue == concat_ws("_",df2.hospitalfk,df2.clusteredacctfk) ) 
      whereExprs = ( (df1.keyname == "clusteredacctfk") & (df1.ca_valid==1) & (df2.ca_valid==1) )

    if identity=='medicalrecnum':
      isValidMRN_udf = udf(isValidMRN_ver2, IntegerType())
      #df1 = df1.where(~df1.lookupvalue.like('_000000000'))
      df1 = df1.withColumn("mrn_valid",isValidMRN_udf(df1.raw_lookupvalue))
      #df2 = df2.withColumn("mrn_valid",isValidMRN_udf(df2.medicalrecnum))
      joinExpr = ( df1.parsed_lookupvalue == concat_ws("_",df2.hospitalfk,df2.medicalrecnum) )
      whereExprs = ( (df1.keyname == "medicalrecnum")  & (df1.mrn_valid==1) & (df2.mrn_valid==1) )

    df_join = df1.join(df2, joinExpr).where(whereExprs).select(finalcols).dropDuplicates()
    
    return df_join

# COMMAND ----------

def file_exists(dir):
  try:
    dbutils.fs.ls(dir)
  except:
    return False  
  return True

# COMMAND ----------

hdfs_data_path = baseurl+hdfs_data_path
pa_op_path = baseurl+pa_op_path+'/'+bc
hdfs_lsb_scratch = baseurl+hdfs_lsb_scratch
permIdPatientAcctId_path = baseurl+permIdPatientAcctId_path
gmrn_publish_path= baseurl+ gmrn_publish_path + "/globalmrnxpacct/current/*"
print(hdfs_data_path)
print(pa_op_path)
print(hdfs_lsb_scratch)
print(permIdPatientAcctId_path)
print(gmrn_publish_path)

# COMMAND ----------

globalmrnxpacct_path = hdfs_data_path + "/globalmrnxpacct/current/*"
hdfs_tmp_data_path = pa_op_path + "/tmpdata/"
nfs_tmp_data_path = "/shared/hdfs/" + pa_op_path + "/tmpdata/" + bc
create_temp_data(spark,hdfs_data_path,hdfs_tmp_data_path,dataset)
hdfs_data_path = hdfs_tmp_data_path

# COMMAND ----------

if (dataset == "fc_xref_lsb_propagation"):
     #OLD-PATH lsb_op_path_gmrnid = hdfs_lsb_scratch + "new_gmrnid" + "fc" + "_insert_response/" + bc
     #OLD-PATH lsb_op_path_permid = hdfs_lsb_scratch + "new_permid" + "fc" + "_insert_response/" + bc
     #OLD-PATH lsb_op_path_ssn = hdfs_lsb_scratch + "new_ssn" + "fc" + "_insert_response/" + bc
     #OLD-PATH lsb_op_path_medicalrecnum = hdfs_lsb_scratch + "new_medicalrecnum" + "fc" + "_insert_response/" + bc
     #OLD-PATH lsb_op_path_clusteredacctfk = hdfs_lsb_scratch + "new_clusteredacctfk" + "fc" + "_insert_response/" + bc
     lsb_op_path_gmrnid = hdfs_lsb_scratch + "new_gmrnid" +"_" + "fc" + "_lsb_join/" + bc
     lsb_op_path_permid = hdfs_lsb_scratch + "new_permid" +"_" + "fc" + "_lsb_join/" + bc
     lsb_op_path_medicalrecnum = hdfs_lsb_scratch + "new_medicalrecnum" +"_" + "fc" + "_lsb_join/" + bc
     lsb_op_path_clusteredacctfk = hdfs_lsb_scratch + "new_clusteredacctfk" +"_" + "fc" + "_lsb_join/" + bc
     lsb_op_path_ssn = hdfs_lsb_scratch + "new_ssn" +"_" + "fc" + "_lsb_join/" + bc
     print("lsb_op_path_gmrnid : "+ lsb_op_path_gmrnid)
     print("lsb_op_path_permid : "+ lsb_op_path_permid)
     print("lsb_op_path_medicalrecnum : "+ lsb_op_path_medicalrecnum)
     print("lsb_op_path_ssn : "+ lsb_op_path_ssn)
elif ((dataset == "ie_xref_lsb_propagation") | (dataset == "es_xref_lsb_propagation")):
    #OLD-PATH lsb_op_path_gmrnid = hdfs_lsb_scratch + "new_gmrnid" + "ich" + "_insert_response/" + bc
    #OLD-PATH lsb_op_path_permid = hdfs_lsb_scratch + "new_permid" + "ich" + "_insert_response/" + bc
    lsb_op_path_gmrnid = hdfs_lsb_scratch + "new_gmrnid" +"_"+ "ich" + "_lsb_join/" + bc
    lsb_op_path_permid = hdfs_lsb_scratch + "new_permid" +"_"+ "ich" + "_lsb_join/" + bc
elif (dataset == "hfc_xref_lsb_propagation"):
     lsb_op_path_gmrnid = hdfs_lsb_scratch + "new_gmrnid" +"_" + "hfc" + "_lsb_join/" + bc
     print("lsb_op_path_gmrnid : "+ lsb_op_path_gmrnid)
elif ((dataset == "chc_xref_lsb_propagation")):
    #OLD-PATH lsb_op_path_gmrnid = hdfs_lsb_scratch + "new_gmrnid" + "chc" + "_insert_response/" + bc
    #OLD-PATH lsb_op_path_permid = hdfs_lsb_scratch + "new_permid" + "chc" + "_insert_response/" + bc
    lsb_op_path_gmrnid = hdfs_lsb_scratch + "new_gmrnid" +"_"+ "chc" + "_lsb_join/" + bc
    lsb_op_path_permid = hdfs_lsb_scratch + "new_permid" +"_"+ "chc" + "_lsb_join/" + bc
elif (dataset in ['es_propagation_famc','fc_propagation_famc','ie_propagation_famc']):
    lsb_op_path_permid_ich = hdfs_lsb_scratch + "/famc/new_permid_ich_lsb_join/" + bc
    lsb_op_path_permid_fc = hdfs_lsb_scratch + "/famc/new_permid_fc_lsb_join/" + bc
elif (dataset == "globalmrnmerge_xref_lsb_propagation"):
    lsb_op_path_gmrnid = hdfs_lsb_scratch + "/updateLsbLeadsRef/gmrnid/lsb_leads/" + bc + "/"
    print("lsb_op_path_gmrnid : "+ lsb_op_path_gmrnid)
else:
    print("Unknown source ... please check")
# def propagate_leads(spark, lsb_op_path, hdfs_data_path,  identity):
if (dataset == "fc_xref_lsb_propagation"):
    df_gmrnid = propagate_leads(spark,  lsb_op_path_gmrnid, hdfs_data_path,  "globalmrnifk")
    writeparquet(spark, df_gmrnid, pa_op_path + "/" + dataset + "/gmrnid", 200, "overwrite")
    df_permid = propagate_leads(spark,  lsb_op_path_permid, hdfs_data_path,  "permid")
    writeparquet(spark, df_permid, pa_op_path + "/" + dataset + "/permid", 200, "overwrite")
    df_ssn = propagate_leads(spark, lsb_op_path_ssn, hdfs_data_path,  "ssn")
    writeparquet(spark, df_ssn, pa_op_path + "/" + dataset + "/ssn", 200, "overwrite")
    df_medicalrecnum = propagate_leads(spark,  lsb_op_path_medicalrecnum, hdfs_data_path,  "medicalrecnum")
    writeparquet(spark, df_medicalrecnum, pa_op_path + "/" + dataset + "/mrn", 200, "overwrite")
    df_clusteredacctfk = propagate_leads(spark,  lsb_op_path_clusteredacctfk, hdfs_data_path,  "clusteredacctfk")
    writeparquet(spark, df_clusteredacctfk, pa_op_path + "/" + dataset + "/ca", 200, "overwrite")
elif (dataset == "hfc_xref_lsb_propagation"):
    df_gmrnid = propagate_leads(spark,  lsb_op_path_gmrnid, hdfs_data_path,  "globalmrnifk")
    writeparquet(spark, df_gmrnid, pa_op_path + "/" + dataset + "/gmrnid", 200, "overwrite")
elif ((dataset == "ie_xref_lsb_propagation") | (dataset == "es_xref_lsb_propagation") | (dataset == "chc_xref_lsb_propagation")):
    df_gmrnid = propagate_leads(spark,  lsb_op_path_gmrnid, hdfs_data_path,  "globalmrnifk")
    writeparquet(spark, df_gmrnid, pa_op_path + "/" + dataset + "/gmrnid", 200, "overwrite")
    df_permid = propagate_leads(spark,  lsb_op_path_permid, hdfs_data_path,  "permid")
    writeparquet(spark, df_permid, pa_op_path + "/" + dataset + "/permid", 200, "overwrite")
elif (dataset in ['es_propagation_famc','fc_propagation_famc','ie_propagation_famc']):
    if file_exists(lsb_op_path_permid_fc) == True:    
        #proc_fc = spark.read.parquet(lsb_op_path_permid_fc)
        df_permid_fc = propagate_leads(spark,  lsb_op_path_permid_fc, hdfs_data_path,  "permid")
        writeparquet(spark, df_permid_fc, pa_op_path + "/" + dataset + "/permid_fc", 200, "overwrite")
    else:
        print("scratch PATH MISSING Nothing to do ")
    
    if file_exists(lsb_op_path_permid_ich) == True:    
        #proc_fc = spark.read.parquet(lsb_op_path_permid_ich)
        permid_ich = propagate_leads(spark,  lsb_op_path_permid_ich, hdfs_data_path,  "permid")
        writeparquet(spark, permid_ich, pa_op_path + "/" + dataset + "/permid_ich", 200, "overwrite")
    else:
        print("scratch PATH MISSING Nothing to do ")
    
    #lsb_op_path_permid = [lsb_op_path_permid_ich, lsb_op_path_permid_fc]
    #df_permid = propagate_leads(spark,  lsb_op_path_permid, hdfs_data_path,  "permid")
    #df_permid = df_permid.dropDuplicates()
    #writeparquet(spark, df_permid, pa_op_path + "/" + dataset + "/permid", 200, "overwrite")
    #print("fm_xref_lsb_propagation data wite complete : " + pa_op_path + "/" + dataset + "/permid")
elif (dataset == "globalmrnmerge_xref_lsb_propagation"):
    if file_exists(lsb_op_path_gmrnid) == True:    
        #proc_fc = spark.read.parquet(lsb_op_path_gmrnid)
        df_gmrnid = propagate_leads(spark,  lsb_op_path_gmrnid, hdfs_data_path,  "globalmrnifk")
        writeparquet(spark, df_gmrnid, pa_op_path + "/" + dataset + "/gmrnid", 200, "overwrite")
    else:
        print("scratch PATH MISSING Nothing to do ")
else:
    print("Unknown source ... please check")
# clean up tmpdate
# proc_tmpdata = subprocess.Popen(['hadoop', 'fs', '-rm', '-r', hdfs_tmp_data_path])
# proc_tmpdata.communicate()
# dbutils.fs.rm(hdfs_tmp_data_path, True)
# spark.stop()
# return None
