# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("hdfs_input","")
dbutils.widgets.getArgument("hdfs_input")
hdfs_input= getArgument("hdfs_input")

dbutils.widgets.text("hdfs_output","")
dbutils.widgets.getArgument("hdfs_output")
hdfs_output= getArgument("hdfs_output")

dbutils.widgets.text("hdfs_output_edipartnerfk","")
dbutils.widgets.getArgument("hdfs_output_edipartnerfk")
hdfs_output_edipartnerfk= getArgument("hdfs_output_edipartnerfk")


# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
import datetime
from configparser import SafeConfigParser
from functools import reduce
from pyspark.sql import DataFrame


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

# MAGIC %run /Insleads-code/LeadDiscovery/common/createlookup_maxminadmitdays

# COMMAND ----------

hdfs_output= baseurl+ hdfs_output+bc
hdfs_output_edipartnerfk= baseurl+hdfs_output_edipartnerfk+bc
hdfs_input=baseurl+hdfs_input

# COMMAND ----------

hp = readparquet(spark, hdfs_input + "/hospitals/current/*/", '0', 'na')
hp = hp.filter(col("active") == '1')
hpn = readparquet(spark, hdfs_input + "/hospitalprovidernums/current/*/", '0', 'na')
hpn = hpn.filter(col("enabled") == '1')
edis = readparquet(spark, hdfs_input + "/edisubmitters/current/*/", '0', 'na')
ep = readparquet(spark, hdfs_input + "/edipartners/current/*/", '0', 'na')
epp = readparquet(spark, hdfs_input + "/edipartnertype/current/*/", '0', 'na')
epp = epp.filter((col("iscommercial") == '1') | (col("istricare") == '1'))
edienv = readparquet(spark, hdfs_input + "/edipartner270settings/current/*/", '0', 'na')
epso = readparquet(spark, hdfs_input + "/edipartnersubmittersoverrides/current/*/", '0', 'na')
ephsso = readparquet(spark, hdfs_input + "/edipartnerhospital270settingsoverrides/current/*/", '0', 'na')
b = createlookup(spark, hp, hpn, edis, ep, edienv, epso, ephsso,epp)
a = createlookupbypartnerfk(spark, hp, hpn, edis, ep, edienv, epso, ephsso,epp)
# using python util to write out
writeparquet(spark, b, hdfs_output,1, "overwrite")
writeparquet(spark, a, hdfs_output_edipartnerfk,1, "overwrite")