# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("hdfs_leads_input","")
dbutils.widgets.getArgument("hdfs_leads_input")
hdfs_leads_input= getArgument("hdfs_leads_input")

dbutils.widgets.text("hdfs_leads_sent","")
dbutils.widgets.getArgument("hdfs_leads_sent")
hdfs_leads_sent= getArgument("hdfs_leads_sent")

dbutils.widgets.text("dataingestion_publish_path","")
dbutils.widgets.getArgument("dataingestion_publish_path")
dataingestion_publish_path= getArgument("dataingestion_publish_path")

dbutils.widgets.text("hdfs_sqoop_output","")
dbutils.widgets.getArgument("hdfs_sqoop_output")
hdfs_sqoop_output= getArgument("hdfs_sqoop_output")


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.functions import encode
from pyspark.sql.window import Window
from pyspark.sql.functions import *
from pyspark.sql.types import *
import sys
import datetime
import uuid

# COMMAND ----------

print("user="+str(user))
print("container="+str(container))
print("storageaccount="+str(storageaccount))
print("bc="+str(bc))
print("hdfs_leads_input="+str(hdfs_leads_input))
print("hdfs_leads_sent="+str(hdfs_leads_sent))
print("hdfs_sqoop_output="+str(hdfs_sqoop_output))
print("dataingestion_publish_path="+str(dataingestion_publish_path))

# COMMAND ----------

ret = dbutils.notebook.run("/Insleads-code/LeadDiscovery/common/check_leads", 360000, {"user":user, "container":container, "storageaccount":storageaccount, "bc":bc, "hdfs_leads_input":hdfs_leads_input, "hdfs_leads_sent":hdfs_leads_sent, "hdfs_sqoop_output":hdfs_sqoop_output, "dataingestion_publish_path":dataingestion_publish_path})

# COMMAND ----------

dbutils.notebook.exit(str(ret))
