# Databricks notebook source
from pyspark.sql.functions import *

# COMMAND ----------

dbutils.widgets.text("tablename1","")
dbutils.widgets.getArgument("tablename1")
tablename1= getArgument("tablename1")

dbutils.widgets.text("tablename2","")
dbutils.widgets.getArgument("tablename2")
tablename2= getArgument("tablename2")

dbutils.widgets.text("path_conn_file", "")
dbutils.widgets.getArgument("path_conn_file")
path_conn_file= getArgument("path_conn_file")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("sqoop_output_path","")
dbutils.widgets.getArgument("sqoop_output_path")
sqoop_output_path= getArgument("sqoop_output_path")

dbutils.widgets.text("icddb","")
dbutils.widgets.getArgument("icddb")
icddb= getArgument("icddb")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# DBTITLE 1,set basepath
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user
print(baseurl)

# COMMAND ----------

hdppatientacctxlead = spark.read.parquet(baseurl+sqoop_output_path+'/'+bc +'/' + tablename1).dropDuplicates()
hdppatientacctxlead = hdppatientacctxlead.drop("createdate")
hdppatientacctxleadbatch = spark.read.parquet(baseurl+sqoop_output_path+'/'+bc +'/' + tablename2).dropDuplicates()

# COMMAND ----------

hdppatientacctxlead.write.format('jdbc').mode('append').option('driver', 'com.microsoft.sqlserver.jdbc.SQLServerDriver').option('url', path_conn_file).option('dbtable', icddb+tablename1).save()
hdppatientacctxleadbatch.write.format('jdbc').mode('append').option('driver', 'com.microsoft.sqlserver.jdbc.SQLServerDriver').option('url', path_conn_file).option('dbtable', icddb+tablename2).save()
