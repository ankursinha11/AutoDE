# Databricks notebook source
# DBTITLE 1,01_version_history
# ================================================================================================================================ #
# IMPLEMENTATION                                                                                                                   #
#   OWNERSHIP     : FinThrive ICD RougeOnes                                                                                        #
#   AUTHOR        : Max Chatterjee                                                                                                 #
#   SCRIPTNAME    : leadpropagation_process_leads_chc                                                                              #
# ================================================================================================================================ #
# HISTORY                                                                                                                          #
#     YYYY-MM-DD: AUTHOR         : VERSION : REQID     : DESCRIPTION                                                               #
#     2024-12-05: Max Chatterjee : 1.0     : RONE-3131 : Script creation - process leads with chc hospitals and Rpaes check        #
#     2024-12-06: Max Chatterjee : 1.1     : RONE-3132 : Script update - prepare leads to push to patientacctsxleads               #
# ================================================================================================================================ #

# COMMAND ----------

# DBTITLE 1,02_python_init
from pyspark.sql.functions import *
import datetime
from pyspark.sql.types import *

# COMMAND ----------

# S A M P L E   S T G   I N P U T S
# ================================================================================================================================= #
# container="prod-icd-stg-adls"
# bc="20241105T04"
# broadcastjoin_flag="1"
# hdfs_admitdt_path="/data/leaddiscovery/transform/scratch/leadpropagation/minmaxbyedipartnerfk/"
# hdfs_input="/data/dataingestion/publish"
# hdfs_leads_input="/data/leaddiscovery/transform/scratch/leadpropagation/"
# hdfs_leadstatus="/data/leadrepo/publish/cooked/leadstatus/"
# storageaccount="prodicdstgdls"
# user="maxc"
# hdfs_maprdb_input="/data/leaddiscovery/config/mappededidatasourcefk"
# hdfs_output="/data/leaddiscovery/transform/scratch/leadpropagation/candidatepaleadspost/"
# hdfs_scratch="/data/leaddiscovery/transform/scratch/leadpropagation/"
# notificationType="chc_xref_lsb_propagation"


# S A M P L E   P R O D   I N P U T S
# ================================================================================================================================= #
# container="prod-icd-adls"
# bc="20241105T04"
# broadcastjoin_flag="1"
# hdfs_admitdt_path="/data/leaddiscovery/transform/scratch/leadpropagation/minmaxbyedipartnerfk/"
# hdfs_input="/data/dataingestion/publish"
# hdfs_leads_input="/data/leaddiscovery/transform/scratch/leadpropagation/"
# hdfs_leadstatus="/data/leadrepo/publish/cooked/leadstatus/"
# storageaccount="prodicddls"
# user="na"
# hdfs_maprdb_input="/data/leaddiscovery/config/mappededidatasourcefk"
# hdfs_output="/data/leaddiscovery/transform/scratch/leadpropagation/candidatepaleadspost/"
# hdfs_scratch="/data/leaddiscovery/transform/scratch/leadpropagation/"
# notificationType="chc_xref_lsb_propagation"

# S A M P L E   O U T P U T S
# ================================================================================================================================= #
# dbutils.notebook.exit(
#     {
#         "return_val": 1,
#         "notify_type": '-CH',
#         "bc_updated": '20241105T04-CH'
#     }
# )

# COMMAND ----------

# DBTITLE 1,03_script_input_variables
dbutils.widgets.text("user", "")
dbutils.widgets.getArgument("user")
user = getArgument("user")

dbutils.widgets.text("container", "")
dbutils.widgets.getArgument("container")
container = getArgument("container")

dbutils.widgets.text("storageaccount", "")
dbutils.widgets.getArgument("storageaccount")
storageaccount = getArgument("storageaccount")

dbutils.widgets.text("bc", "")
dbutils.widgets.getArgument("bc")
bc = getArgument("bc")

dbutils.widgets.text("hdfs_input", "")
dbutils.widgets.getArgument("hdfs_input")
hdfs_input = getArgument("hdfs_input")

dbutils.widgets.text("hdfs_leads_input", "")
dbutils.widgets.getArgument("hdfs_leads_input")
hdfs_leads_input = getArgument("hdfs_leads_input")

dbutils.widgets.text("hdfs_admitdt_path", "")
dbutils.widgets.getArgument("hdfs_admitdt_path")
hdfs_admitdt_path = getArgument("hdfs_admitdt_path")

dbutils.widgets.text("hdfs_output", "")
dbutils.widgets.getArgument("hdfs_output")
hdfs_output = getArgument("hdfs_output")

dbutils.widgets.text("hdfs_maprdb_input", "")
dbutils.widgets.getArgument("hdfs_maprdb_input")
hdfs_maprdb_input = getArgument("hdfs_maprdb_input")

dbutils.widgets.text("hdfs_leadstatus", "")
dbutils.widgets.getArgument("hdfs_leadstatus")
hdfs_leadstatus = getArgument("hdfs_leadstatus")

dbutils.widgets.text("hdfs_scratch", "")
dbutils.widgets.getArgument("hdfs_scratch")
hdfs_scratch = getArgument("hdfs_scratch")

dbutils.widgets.text("broadcastjoin_flag", "")
dbutils.widgets.getArgument("broadcastjoin_flag")
broadcastjoin_flag = getArgument("broadcastjoin_flag")

dbutils.widgets.text("notificationType", "")
dbutils.widgets.getArgument("notificationType")
notificationType = getArgument("notificationType")

# COMMAND ----------

# DBTITLE 1,04_access_key_init
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))
cosmosMasterKey = dbutils.secrets.get(scope="icd-insleads-dbwscope", key="icd-cosmos-insleads-kvsecret")

# COMMAND ----------

# DBTITLE 1,05_base_url_init
# Ensure container, storageaccount, and user are strings
container = str(container)
storageaccount = str(storageaccount)
user = str(user)

if user == 'na':  # default value
    base_url = 'abfss://' + container + '@' + storageaccount + '.dfs.core.windows.net/'
else:
    base_url = 'abfss://' + container + '@' + storageaccount + '.dfs.core.windows.net/' + user + "/"

print("base_url : " + base_url)

# COMMAND ----------

# DBTITLE 1,06_import_common_functions
# MAGIC %run /Insleads-code/LeadDiscovery/common/process_leads

# COMMAND ----------

def get_foundcoverage_hits (fq_foundcoverage,fq_foundcoverageinferredsourcemethodcodes):
    foundcoverage = spark.read.format("delta").load(fq_foundcoverage)
    foundcoverage = foundcoverage.selectExpr("hospitalfk", "patientacctifk", "edipartnerfk", "coverageid", "foundcoverageipk", "groupnumber", "currentinferredsourcemethodcode","hitstatus")
    foundcoverage = foundcoverage.withColumn('patientacctifk', foundcoverage.patientacctifk.cast('bigint'))
    foundcoverage = foundcoverage.withColumn("coverageid", when((foundcoverage.coverageid.contains(foundcoverage.groupnumber)) & (foundcoverage.groupnumber != ''), substring_index(foundcoverage.coverageid, '-', 1)).otherwise(foundcoverage.coverageid))
    foundcoverage.createOrReplaceTempView("foundcoverage")
    foundcoverage=spark.sql(""" SELECT * FROM foundcoverage WHERE CAST(TRIM(hitstatus) AS INT) IN (1,2) """)
    foundcoverage=foundcoverage.dropDuplicates()
    foundcoverageinferredsourcemethodcodes = spark.read.format("parquet").load(fq_foundcoverageinferredsourcemethodcodes)
    foundcoverageinferredsourcemethodcodes = foundcoverageinferredsourcemethodcodes.selectExpr("inferredsourcemethodcode", "edisourcedflag")
    foundcoverageinferredsourcemethodcodes = foundcoverageinferredsourcemethodcodes.dropDuplicates()
    foundcoverage_hits = foundcoverage.join(foundcoverageinferredsourcemethodcodes, foundcoverageinferredsourcemethodcodes.inferredsourcemethodcode == foundcoverage.currentinferredsourcemethodcode, "inner").select(foundcoverage['*'])
    foundcoverage_hits = foundcoverage_hits.selectExpr("hospitalfk", "patientacctifk", "edipartnerfk", "coverageid").dropDuplicates()
    return foundcoverage_hits

def get_chc_participating_carrier_hospitals (fq_chc_hosp_mapping,fq_chc_eid_mapping,fq_chc_publish,filterExpr):
    chc_eid_mapping=spark.read.format("parquet").load(fq_chc_eid_mapping)
    chc_eid_mapping.createOrReplaceTempView("chc_eid_mapping")
    chc_hosp_mapping=spark.read.format("parquet").load(fq_chc_hosp_mapping)
    chc_hosp_mapping.createOrReplaceTempView("chc_hosp_mapping")
    chc_publish=spark.read.format("parquet").load(fq_chc_publish).filter(filterExpr).selectExpr("lr_creatingmodule","eid","bpe","carrier","basefilename_state as state").dropDuplicates()
    chc_publish.createOrReplaceTempView("chc_publish")
    chc_participating_carrier_hospitals=spark.sql("""
    SELECT chc_publish.lr_creatingmodule,
           chc_eid_mapping.eid,
           chc_eid_mapping.bpe,
           chc_eid_mapping.carrier,
           chc_eid_mapping.edipartnerfk AS lsb_edipartnerfk,
           chc_hosp_mapping.hospitalfk,
           chc_hosp_mapping.state
    FROM chc_eid_mapping
      INNER JOIN chc_hosp_mapping
              ON chc_eid_mapping.eid = chc_hosp_mapping.eid
             AND chc_eid_mapping.bpe = chc_hosp_mapping.bpe
             AND chc_eid_mapping.carrier = chc_hosp_mapping.carrier
      INNER JOIN chc_publish
              ON chc_eid_mapping.eid = chc_publish.eid
             AND chc_eid_mapping.bpe = chc_publish.bpe
             AND chc_eid_mapping.carrier = chc_publish.carrier
             AND chc_hosp_mapping.state = chc_publish.state
    """).dropDuplicates()
    return chc_participating_carrier_hospitals

def get_all_leads(hdfs_leads_input):
    all_leads = extract_explode_leads(spark, hdfs_leads_input )
    cond_coverageid = when(((lower(trim(col("lsb_coverageid"))).startswith("null"))) , regexp_replace(col("lsb_coverageid"), "null", "")).otherwise(col("lsb_coverageid"))
    all_leads = all_leads.withColumn("lsb_coverageid", cond_coverageid)
    cond_id = when(((lower(trim(col("lsb_id"))).contains("_null"))), regexp_replace(col("lsb_id"), "null", "")).otherwise(col("lsb_id"))
    all_leads = all_leads.withColumn("lsb_id", cond_id)
    cond = when(((trim(col("lsb_edipartnerfk")) == "182")), lit("101")).otherwise(col("lsb_edipartnerfk"))
    all_leads = all_leads.withColumn("lsb_edipartnerfk", cond)
    cond_id_2 = when((((trim(col("lsb_edipartnerfk")) == "182") | (trim(col("lsb_edipartnerfk")) == "101")) & (lower(trim(col("lsb_id"))).contains("_182_"))), regexp_replace(col("lsb_id"), "_182_", "_101_")).otherwise(col("lsb_id"))
    all_leads = all_leads.withColumn("lsb_id", cond_id_2)
    cond_state = when(((length(trim(col("lsb_state"))) > 2)), lit("")).otherwise(col("lsb_state"))
    all_leads.createOrReplaceTempView("all_leads")
    all_leads = spark.sql("""from all_leads SELECT all_leads.*, CASE WHEN LENGTH(TRIM(lsb_state)) = 2 THEN TRIM(lsb_state) ELSE '' END AS new_lsb_state """)
    all_leads = all_leads.drop("lsb_state").withColumnRenamed('new_lsb_state', 'lsb_state')
    return all_leads

# COMMAND ----------

# DBTITLE 1,07_notification_init
if notificationType == "chc_xref_lsb_propagation":
    bcupdated = bc
    notify = "-CH"
    filterExpr="lr_creatingmodule=='"+bc+"'"
    chc_bc=bc + notify
    filterExprSentLeads="breadcrumb=='"+chc_bc+"'"
    print("notificationType    : "+notificationType)
    print("filterExpr          : "+filterExpr)
    print("filterExprSentLeads : "+filterExprSentLeads)
    unique_columns_grouped=["patientacctifk","lsb_coverageid","lsb_edipartnerfk"]
    spark.conf.set("spark.sql.shuffle.partitions", "auto")
    spark.conf.set("spark.databricks.io.cache.enabled", "true")
    spark.conf.set("spark.sql.adaptive.skewJoin.enabled", "true")
else:
    exit("notificationType is not supported")

# COMMAND ----------

# DBTITLE 1,08_input_variable_customization
hdfs_input = base_url + hdfs_input
hdfs_leads_input = base_url+hdfs_leads_input + bc 
hdfs_admitdt_path = base_url + hdfs_admitdt_path +bc
hdfs_output = base_url+ hdfs_output +bcupdated+notify
hdfs_maprdb_input = base_url + hdfs_maprdb_input
hdfs_leadstatus = base_url + hdfs_leadstatus
hdfs_scratch = base_url + hdfs_scratch +bc

hdfs_leads_input = hdfs_leads_input + "/"+ notificationType + "/*"

hdfs_sqoop_output= base_url + "/data/leaddiscovery/transform/output/leadpropagation/"+ bc + notify
hdfs_leads_sent = base_url + "/data/leaddiscovery/publish/patientacctxlead/"

fq_chc_eid_mapping = base_url + "/data/chc/staging/mapping/chc_eid_mapping/"
fq_chc_hosp_mapping = base_url + "/data/chc/staging/mapping/chc_hosp_mapping/"
fq_chc_publish = base_url + "/data/chc/publish/current/20991231/"
fq_reportwarehousemedicaideligiblepaes = base_url + "/data/dataingestion/publish/reportwarehousemedicaideligiblepaes/current/20991231/"
fq_foundcoverage = base_url + "/data/dataingestion/publish/foundcoverage/current/20991231/"
fq_foundcoverageinferredsourcemethodcodes = base_url + "/data/dataingestion/publish/foundcoverageinferredsourcemethodcodes/current/20991231/"



print("**************INPUTS & SCRATCH*************************")
print("base_url="+'"'+base_url+'"')
print("hdfs_input="+'"'+hdfs_input+'"')
print("hdfs_admitdt_path="+'"'+hdfs_admitdt_path+'"')
print("hdfs_output="+'"'+hdfs_output+'"')
print("hdfs_maprdb_input="+'"'+hdfs_maprdb_input+'"')
print("hdfs_leadstatus="+'"'+hdfs_leadstatus+'"')
print("hdfs_scratch="+'"'+hdfs_scratch+'"')
print("hdfs_leads_input="+'"'+ hdfs_leads_input+'"')
print("hdfs_sqoop_output="+'"'+ hdfs_sqoop_output+'"')
print("hdfs_leads_sent="+'"'+ hdfs_leads_sent+'"')

print("**************READ-ONLY-TABLES*************************")
print("fq_chc_eid_mapping="+'"'+fq_chc_eid_mapping+'"')
print("fq_chc_hosp_mapping="+'"'+fq_chc_hosp_mapping+'"')
print("fq_chc_publish="+'"'+fq_chc_publish+'"')
print("fq_reportwarehousemedicaideligiblepaes="+'"'+fq_reportwarehousemedicaideligiblepaes+'"')
print("fq_foundcoverage="+'"'+fq_foundcoverage+'"')
print("fq_foundcoverageinferredsourcemethodcodes="+'"'+fq_foundcoverageinferredsourcemethodcodes+'"')

# COMMAND ----------

# DBTITLE 1,11_chc_participating_carrier_hospitals
chc_participating_carrier_hospitals=get_chc_participating_carrier_hospitals(fq_chc_hosp_mapping,fq_chc_eid_mapping,fq_chc_publish,filterExpr).dropDuplicates()
chc_participating_carrier_hospitals.createOrReplaceTempView("chc_participating_carrier_hospitals")
# chc_participating_carrier_hospitals.display()

# COMMAND ----------

# DBTITLE 1,12_foundcoverage_hits
foundcoverage_hits=get_foundcoverage_hits(fq_foundcoverage,fq_foundcoverageinferredsourcemethodcodes)
foundcoverage_hits.createOrReplaceTempView("foundcoverage_hits")
foundcoverage_hits=spark.sql("""
SELECT 
    foundcoverage_hits.hospitalfk,
    foundcoverage_hits.patientacctifk,
    foundcoverage_hits.edipartnerfk,
    SPLIT(foundcoverage_hits.coverageid,'-')[0] as coverageid
FROM foundcoverage_hits
  INNER JOIN chc_participating_carrier_hospitals
          ON foundcoverage_hits.hospitalfk = chc_participating_carrier_hospitals.hospitalfk
         AND foundcoverage_hits.edipartnerfk = chc_participating_carrier_hospitals.lsb_edipartnerfk
""").dropDuplicates()
foundcoverage_hits.createOrReplaceTempView("foundcoverage_hits")

# COMMAND ----------

# DBTITLE 1,13_reportwarehousemedicaideligiblepaes
reportwarehousemedicaideligiblepaes=spark.read.format("delta").load(fq_reportwarehousemedicaideligiblepaes).selectExpr("hospitalfk","patientacctifk","coverageid")
reportwarehousemedicaideligiblepaes.createOrReplaceTempView("reportwarehousemedicaideligiblepaes")
reportwarehousemedicaideligiblepaes=spark.sql("""
SELECT *
FROM reportwarehousemedicaideligiblepaes
WHERE hospitalfk IN (SELECT DISTINCT hospitalfk
                     FROM chc_participating_carrier_hospitals)                                              
""").dropDuplicates()
reportwarehousemedicaideligiblepaes.createOrReplaceTempView("reportwarehousemedicaideligiblepaes")

# COMMAND ----------

# DBTITLE 1,all_leads
all_leads = get_all_leads(hdfs_leads_input)
all_leads.write.mode("overwrite").parquet(hdfs_scratch + "/all_leads/")
all_leads.unpersist()

# COMMAND ----------

# DBTITLE 1,14_all_leads_with_flags : CHC Hosp Check
all_leads=spark.read.parquet(hdfs_scratch + "/all_leads/")
all_leads.createOrReplaceTempView("all_leads")
all_leads=spark.sql("""
SELECT all_leads.*,
       CASE WHEN chc_participating_carrier_hospitals.hospitalfk IS NULL THEN 0 ELSE 1 END AS isChcHospital
FROM all_leads
  LEFT JOIN chc_participating_carrier_hospitals
         ON all_leads.hospitalfk = chc_participating_carrier_hospitals.hospitalfk
        AND all_leads.lsb_edipartnerfk = chc_participating_carrier_hospitals.lsb_edipartnerfk
""").dropDuplicates()
all_leads.createOrReplaceTempView("all_leads")

# COMMAND ----------

# DBTITLE 1,all_leads_with_flags RPAES and FC check
all_leads_with_flags = spark.sql("""
SELECT 
       all_leads.*,
       reportwarehousemedicaideligiblepaes.coverageid                                         AS rpaes_coverageid,
       foundcoverage_hits.coverageid                                                          AS fc_coverageid,
       CASE WHEN reportwarehousemedicaideligiblepaes.coverageid IS NULL THEN '0' ELSE '1' END AS isRpaesReported,
       CASE WHEN foundcoverage_hits.coverageid                  IS NULL THEN '0' ELSE '1' END AS isFoundCoverageReported
FROM all_leads
  LEFT JOIN reportwarehousemedicaideligiblepaes
         ON all_leads.hospitalfk = reportwarehousemedicaideligiblepaes.hospitalfk
        AND all_leads.patientacctifk = reportwarehousemedicaideligiblepaes.patientacctifk
        AND (all_leads.lsb_coverageid LIKE '%' || reportwarehousemedicaideligiblepaes.coverageid || '%'
         OR reportwarehousemedicaideligiblepaes.coverageid LIKE '%' || all_leads.lsb_coverageid || '%')
  LEFT JOIN foundcoverage_hits
         ON all_leads.hospitalfk = foundcoverage_hits.hospitalfk
        AND all_leads.lsb_edipartnerfk = foundcoverage_hits.edipartnerfk
        AND all_leads.patientacctifk = foundcoverage_hits.patientacctifk
        AND (all_leads.lsb_coverageid LIKE '%' || foundcoverage_hits.coverageid || '%'
         OR foundcoverage_hits.coverageid LIKE '%' || all_leads.lsb_coverageid || '%')
""").dropDuplicates()

all_leads_with_flags.write.mode("overwrite").parquet(hdfs_scratch + "/all_leads_with_flags/")
all_leads_with_flags.unpersist()
all_leads.unpersist()

# COMMAND ----------

# all_leads_with_flags = spark.read.parquet(hdfs_scratch + "/all_leads_with_flags/").filter("isChcHospital=='1'")
# all_leads_with_flags.selectExpr("hospitalfk","patientacctifk","lsb_coverageid","fc_coverageid","rpaes_coverageid","isChcHospital","isRpaesReported","isFoundCoverageReported").display()

# COMMAND ----------

# DBTITLE 1,all_leads_filtered
all_leads_with_flags = spark.read.parquet(hdfs_scratch + "/all_leads_with_flags/")
all_leads_with_flags = all_leads_with_flags.filter("isChcHospital=='1'")
all_leads_with_flags = all_leads_with_flags.filter("isRpaesReported=='0'")
all_leads_with_flags = all_leads_with_flags.filter("isFoundCoverageReported=='0'")
all_leads_with_flags = all_leads_with_flags.filter("totalcharges > 0")

all_leads_with_flags = all_leads_with_flags.drop("isChcHospital")
all_leads_with_flags = all_leads_with_flags.drop("isRpaesReported")
all_leads_with_flags = all_leads_with_flags.drop("isFoundCoverageReported")
all_leads_with_flags = all_leads_with_flags.drop("rpaes_coverageid")
all_leads_with_flags = all_leads_with_flags.drop("fc_coverageid")


all_leads_with_flags = all_leads_with_flags.dropDuplicates()

all_leads_with_flags.write.mode("overwrite").parquet(hdfs_scratch + "/all_leads_filtered/")
all_leads_with_flags.unpersist()

# COMMAND ----------

# DBTITLE 1,all_leads_wallingoff
all_leads_filtered=spark.read.parquet(hdfs_scratch + "/all_leads_filtered/")
# print("all_leads_filtered | "+str(all_leads_filtered.selectExpr(unique_columns_grouped).dropDuplicates().count()))

all_leads_wallingoff = applywallingoff(spark, all_leads_filtered, hdfs_input, hdfs_scratch)
writeparquet(spark, all_leads_wallingoff, hdfs_scratch + "/all_leads_wallingoff", 0, "overwrite")

# COMMAND ----------

# DBTITLE 1,all_leads_edidatasourcefk
all_leads_wallingoff=spark.read.parquet(hdfs_scratch + "/all_leads_wallingoff/")
# print("all_leads_wallingoff | "+str(all_leads_wallingoff.selectExpr(unique_columns_grouped).dropDuplicates().count()))

all_leads_edidatasourcefk = addedidatasourcefk(spark, all_leads_wallingoff, hdfs_maprdb_input, hdfs_scratch)
writeparquet(spark, all_leads_edidatasourcefk, hdfs_scratch + "/all_leads_edidatasourcefk", 0, "overwrite")

# COMMAND ----------

# DBTITLE 1,all_leads_ohi
all_leads_edidatasourcefk=spark.read.parquet(hdfs_scratch + "/all_leads_edidatasourcefk/")
# print("all_leads_edidatasourcefk | "+str(all_leads_edidatasourcefk.selectExpr(unique_columns_grouped).dropDuplicates().count()))

all_leads_ohi = ohibatchprocess(spark, all_leads_edidatasourcefk, hdfs_input, hdfs_scratch)
writeparquet(spark, all_leads_ohi, hdfs_scratch + "/all_leads_ohi", 200, "overwrite")

# COMMAND ----------

# DBTITLE 1,bestleadselection
all_leads_ohi=spark.read.parquet(hdfs_scratch + "/all_leads_ohi/")
# print("all_leads_ohi | "+str(all_leads_ohi.selectExpr(unique_columns_grouped).dropDuplicates().count()))


final_leads = bestleadselection(spark, all_leads_ohi, bc, hdfs_scratch).dropDuplicates()
print("final op dir :"+ hdfs_output)
final_leads.write.mode("overwrite").parquet(hdfs_output)

# COMMAND ----------

# DBTITLE 1,Prepare Leads for Propagation

leads=spark.read.parquet(hdfs_output).withColumn("breadcrumb", concat_ws("-", col("breadcrumb"), lit('CH')))
# print("leads | before demographic cleanse | "+str(leads.selectExpr(unique_columns_grouped).dropDuplicates().count()))
leads= leads.filter(~col("lsb_coverageId").isin('999999999','ABC123','SELFPAY'))
leads_democols = ["lsb_firstname","lsb_lastname", "lsb_ssn", "lsb_dob", "lsb_state","lsb_edipartnerfk","lsb_coverageid","patientacctifk"]

for column in leads_democols:
    leads = leads.withColumn(column, trim(col(column)))
    leads = leads.withColumn(column, when(col(column).isNull(), '').otherwise(col(column)))
    leads = leads.withColumn(column, when(upper(col(column)) == 'NULL', '').otherwise(col(column)))
    leads = leads.withColumn(column, when(upper(col(column)) == 'NONE', '').otherwise(col(column)))
    leads = leads.withColumn(column, when(upper(col(column)) == 'XX', '').otherwise(col(column)))

leads=leads.withColumn("lsb_firstname",upper(col("lsb_firstname"))).withColumn("lsb_lastname",upper(col("lsb_lastname"))).withColumn("lsb_state",upper(col("lsb_state")))
leads.createOrReplaceTempView("leads")
leads=spark.sql(""" SELECT leads.*, CASE WHEN leads.lsb_state='XX' THEN '' ELSE leads.lsb_state END AS lsb_state_2 FROM leads""").drop("lsb_state").withColumnRenamed("lsb_state_2","lsb_state")
leads.createOrReplaceTempView("leads")
leads=spark.sql(""" SELECT leads.*, CASE WHEN leads.lsb_ssn='000000000' THEN '' ELSE leads.lsb_ssn END AS lsb_ssn_2 FROM leads""").drop("lsb_ssn").withColumnRenamed("lsb_ssn_2","lsb_ssn")


cond_dob_2 = when(to_date(col("lsb_dob"), "yyyy-MM-dd HH:mm:ss").isNotNull(), date_format(col("lsb_dob"), "yyyy-MM-dd HH:mm:ss")).otherwise(None)
cond_dob = when((substring(trim(col("lsb_dob")), 0, 4).cast(IntegerType()) < 1800), lit("")).otherwise(cond_dob_2)
cond_gender = when((length(trim(col("lsb_gender"))) > 10), lit("")).otherwise(col("lsb_gender"))
cond_ssn = when((length(trim(col("lsb_ssn"))) > 11), lit("")).otherwise(col("lsb_ssn"))

leads = leads.withColumn("lsb_dob", cond_dob)
leads = leads.withColumn("admitdate", date_format(col("admitdate"), "yyyy-MM-dd HH:mm:ss"))
leads = leads.withColumn("dischargedate", date_format(col("dischargedate"), "yyyy-MM-dd HH:mm:ss"))
leads = leads.withColumn("dob", date_format(col("dob"), "yyyy-MM-dd HH:mm:ss"))
leads = leads.withColumn("lsb_gender", cond_gender)
leads = leads.withColumn("lsb_ssn", cond_ssn)
leads = leads.filter(length(col("lsb_coverageid")) <= 25)

ordered_columns = ["uniqueid", "breadcrumb", "patientacctifk", "hospitalfk", "hospitalname", "firstname", "middlename", "lastname", "dob","ssn", "gender", "state", "admitdate", "dischargedate", "clusteredacctfk", "totalcharges", "npi", "lsb_edipartnerfk", "lsb_coverageid","lsb_leadsource", "lsb_xrefsource", "lsb_firstname", "lsb_middlename", "lsb_lastname", "lsb_gender", "lsb_dob", "lsb_ssn", "lsb_state","usefamilydataflag", "edidatasourcefk", "edidatasourcetablekey", "associationsource", "demohash", "medicarehic", "medicaidnum"]

leads = leads.withColumn("uniqueid", concat_ws("_", leads.patientacctifk, expr("uuid()"))).select(ordered_columns).dropDuplicates()

for column in leads.columns:
    leads = leads.withColumn(column, trim(col(column)))
    leads = leads.withColumn(column, when(col(column).isNull(), '').otherwise(col(column)))
    leads = leads.withColumn(column, when(upper(col(column)) == 'NULL', '').otherwise(col(column)))
    leads = leads.withColumn(column, when(upper(col(column)) == 'NONE', '').otherwise(col(column)))
    leads = leads.withColumn(column, when(upper(col(column)) == 'XX', '').otherwise(col(column)))

# print("leads | after  demographic cleanse | "+str(leads.selectExpr(unique_columns_grouped).dropDuplicates().count()))
leads.write.mode("append").format("delta").save(hdfs_leads_sent)
leads.unpersist()

# COMMAND ----------

from pyspark.sql.functions import trim, when, col, upper, to_date
leads=spark.read.format("delta").load(hdfs_leads_sent).filter(filterExprSentLeads).drop("demohash")
leads = leads.withColumn('dob', ((to_date(leads.dob)).cast('timestamp')).cast('string'))
leads = leads.withColumn('admitdate', ((to_date(leads.admitdate)).cast('timestamp')).cast('string'))
leads = leads.withColumn('dischargedate', ((to_date(leads.dischargedate)).cast('timestamp')).cast('string'))
leads = leads.withColumn('lsb_dob', ((to_date(leads.lsb_dob)).cast('timestamp')).cast('string'))
leads = leads.dropDuplicates()
# print("leads | to be pushed | "+str(leads.selectExpr(unique_columns_grouped).dropDuplicates().count()))

# COMMAND ----------

# DBTITLE 1,hdppatientacctxlead
leads.repartition(10).write.format("parquet").mode("overwrite").options(timestampFormat="yyyy-MM-dd HH:mm:ss").save(hdfs_sqoop_output+"/hdppatientacctxlead")

# COMMAND ----------

# DBTITLE 1,hdppatientacctxleadbatch
batch=leads.selectExpr("breadcrumb").limit(1)
batch.repartition(1).write.mode("overwrite").format("parquet").options(timestampFormat="yyyy-MM-dd HH:mm:ss").save(hdfs_sqoop_output +"/hdppatientacctxleadbatch")

# COMMAND ----------

# hdppatientacctxlead=hdfs_sqoop_output+"/hdppatientacctxlead"
# hdppatientacctxleadbatch=hdfs_sqoop_output+"/hdppatientacctxleadbatch"
# print("hdppatientacctxlead : "+hdppatientacctxlead)
# print("hdppatientacctxleadbatch : "+hdppatientacctxleadbatch)

# COMMAND ----------

# DBTITLE 1,STAT Collection
from pyspark.sql.functions import lit

unique_columns_grouped = ["patientacctifk", "lsb_coverageid", "lsb_edipartnerfk"]

data_01 = spark.read.parquet(hdfs_scratch + "/all_leads_with_flags/").selectExpr(unique_columns_grouped).dropDuplicates().withColumn("steps", lit('step_01'))
data_02 = spark.read.parquet(hdfs_scratch + "/all_leads_filtered/").selectExpr(unique_columns_grouped).dropDuplicates().withColumn("steps", lit('step_02'))
data_03 = spark.read.parquet(hdfs_scratch + "/all_leads_wallingoff/").selectExpr(unique_columns_grouped).dropDuplicates().withColumn("steps", lit('step_03'))
data_04 = spark.read.parquet(hdfs_scratch + "/all_leads_edidatasourcefk/").selectExpr(unique_columns_grouped).dropDuplicates().withColumn("steps", lit('step_04'))
data_05 = spark.read.parquet(hdfs_scratch + "/all_leads_ohi/").selectExpr(unique_columns_grouped).dropDuplicates().withColumn("steps", lit('step_05'))
data_06 = spark.read.parquet(hdfs_output).selectExpr(unique_columns_grouped).dropDuplicates().withColumn("steps", lit('step_06'))
data_07 = spark.read.parquet(hdfs_sqoop_output + "/hdppatientacctxlead").selectExpr(unique_columns_grouped).dropDuplicates().withColumn("steps", lit('step_07'))

data = data_01.union(data_02).union(data_03).union(data_04).union(data_05).union(data_06).union(data_07).withColumn("bc", lit(bc))

data.createOrReplaceTempView("data")

data = spark.sql("""
SELECT bc,
       steps,
       COUNT(*) AS count
FROM data
GROUP BY bc,
         steps
ORDER BY steps ASC
""")
# display(data)
data = data.groupBy("bc").pivot("steps").sum("count")
# display(data)
data.write.mode("overwrite").format("parquet").save(hdfs_scratch + "/all_step_stats/")

# COMMAND ----------



# COMMAND ----------

# DBTITLE 1,isLeadsGenrated
isLeadsGenrated=spark.read.parquet(hdfs_sqoop_output+"/hdppatientacctxlead")
if (isLeadsGenrated.isEmpty()):
    ret_val = 0
else:
    ret_val = 1

# COMMAND ----------

dbutils.notebook.exit(
    {
        "return_val": ret_val,
        "notify_type": notify,
        "bc_updated": chc_bc
    }
)
