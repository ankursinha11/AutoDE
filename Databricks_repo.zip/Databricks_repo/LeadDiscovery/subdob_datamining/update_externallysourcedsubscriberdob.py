# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("scratch_path","")
dbutils.widgets.getArgument("scratch_path")
scratch_path= getArgument("scratch_path")

dbutils.widgets.text("hdfs_input","")
dbutils.widgets.getArgument("hdfs_input")
hdfs_input= getArgument("hdfs_input")

dbutils.widgets.text("sqoop_op_path","")
dbutils.widgets.getArgument("sqoop_op_path")
sqoop_op_path= getArgument("sqoop_op_path")

# dbutils.widgets.text("path_conn_file","")
# dbutils.widgets.getArgument("path_conn_file")
# path_conn_file= getArgument("path_conn_file")

dbutils.widgets.text("tablename_extsubdob","")
dbutils.widgets.getArgument("tablename_extsubdob")
tablename_extsubdob= getArgument("tablename_extsubdob")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

path_conn_file = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-dataingestion-sql-insleads-cs")

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from datetime import *

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/common_util"

# COMMAND ----------

hdfs_input = baseurl + hdfs_input
scratch_path = baseurl + scratch_path + bc
sqoop_path = baseurl  + sqoop_op_path + bc
# path_conn_file = baseurl + path_conn_file
tablename = tablename_extsubdob
print("scratch_path",scratch_path)
print("sqoop_path",sqoop_path)

# COMMAND ----------

# getting max key from table for import 

def get_max_key_externallysourcedsubscriberdob(spark,externallysourcedsubscriberdob):
    externallysourcedsubscriberdob=externallysourcedsubscriberdob.withColumn("externallysourcedsubscriberdobpklong",externallysourcedsubscriberdob.externallysourcedsubscriberdobpk.cast("long"))
    mxval = externallysourcedsubscriberdob.where(col("externallysourcedsubscriberdobpklong").isNotNull()) \
       .agg({"externallysourcedsubscriberdobpklong": "max"}).collect()[0][0]
    return mxval
# function to import externallysourcedsubscriberdob

def import_externallysourcedsubscriberdob(spark,df_conn,tablename,numeric_lit,hdfs_input):
    # string_connection = str(df_conn.collect()[0]['conn_details'])
    string_connection = df_conn
    string_query_extraction = "SELECT * FROM " + tablename + " WHERE externallysourcedsubscriberdobpk" + " > " + str(numeric_lit) +""
    print("DB EXTRACT QUERY : " + string_query_extraction)
    df_jdbc = spark.read.format("jdbc").option("url", string_connection) \
                        .option("query", string_query_extraction) \
                        .option("numPartitions", 5) \
                        .load()
    # print("DF Count :"+ str(df_jdbc.count()))
    for column in df_jdbc.columns:
      df_jdbc = df_jdbc.withColumn(column, trim(col(column)))
      df_jdbc = df_jdbc.withColumnRenamed(column,column.lower())
    writeparquet(spark,df_jdbc,scratch_path + "/externallysourcedsubscriberdob_delta/current/20991231/",1,"append")

#create o/p for sqoop

def update_externallysourcedsubscriberdob(spark,externallysourcedsubscriberdob,deduped_subdob_verified,scratch_path,sqoop_path,hdfs_input,bc):
    d = datetime.date.today()
    curr_date = d.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    dt = d.strftime('%Y-%m-%d %H:%M:%S')
    bcdate = bc
    externallysourcedsubscriberdob.createOrReplaceTempView("externallysourcedsubscriberdob")
    deduped_subdob_verified.createOrReplaceTempView("deduped_subdob_verified")
    filter_out_existing_account_pquery = """ select dsv.* 
                                                    from deduped_subdob_verified dsv
                                                    left anti join externallysourcedsubscriberdob ess
                                                    on ( ess.patientacctifk <=> dsv.patientacctifk ) and ( ess.hospitalfk <=> dsv.hospitalfk ) and (ess.edipartnerfk <=> dsv.edipartnerfk) """
    filter_out_existing_account = spark.sql(filter_out_existing_account_pquery)
    filter_out_existing_account = filter_out_existing_account.withColumn("externallysourcedsubscriberdobpk",monotonically_increasing_id())
    filter_out_existing_account = filter_out_existing_account.withColumn("createdate",lit(curr_date))
    filter_out_existing_account.createOrReplaceTempView("externallysourcedsubscriberdob_staging")
    externallysourcedsubscriberdob_pquery =  """ select
                                                 cast(externallysourcedsubscriberdobpk as string) as externallysourcedsubscriberdobpk,
                                                 hospitalfk,
                                                 patientacctifk,
                                                 subscriberdoblookuppk as subscriberdoblookupfk,
                                                 dob,
                                                 '' as sourceacxiomhospitalfk,
                                                 '' as acxiomdemographicsresponseid,
                                                 sourcepatienthospitalfk,
                                                 sourcepatientacctifk,
                                                 sourcefoundcoveragehospitalfk,
                                                 sourcefoundcoverageifk,
                                                 edisubscriberdobresponsefk,
                                                 foundcoverageifk,
                                                 foundcoverageentityifk,
                                                 createdate,
                                                 edipartnerfk,
                                                 edisubscriberdobsearchpk
                                                 from 
                                                 externallysourcedsubscriberdob_staging """
    externallysourcedsubscriberdob_tmp = spark.sql(externallysourcedsubscriberdob_pquery)
    writeparquet(spark,externallysourcedsubscriberdob_tmp,scratch_path + "/externallysourcedsubscriberdob_tmp/",5,"overwrite")
    externallysourcedsubscriberdob = readparquet(spark, scratch_path + "/externallysourcedsubscriberdob_tmp/", "0","na")
    externallysourcedsubscriberdob = externallysourcedsubscriberdob.withColumn("dob",date_format(col("dob"),"yyyy-MM-dd HH:mm:ss"))
    externallysourcedsubscriberdob = externallysourcedsubscriberdob.filter((col("dob") > '1900-01-01 00:00:00') & (col("dob") < dt))
    externallysourcedsubscriberdob_sqoop = externallysourcedsubscriberdob.withColumn("bc",lit(bcdate))
    writeparquet(spark,externallysourcedsubscriberdob,hdfs_input + "externallysourcedsubscriberdob/current/20991231/",1,"append")#may be updated as globalmrn tables or convert to deltalake
    writecsv(spark,externallysourcedsubscriberdob_sqoop,sqoop_path + "/externallysourcedsubscriberdob_holding" ,1,"overwrite","\x01")
    bclist = [bcdate]
    batch = spark.createDataFrame(bclist, StringType())
    writecsv(spark,batch,sqoop_path + "/externallysourcedsubscriberdob_batch",1,"overwrite","\x01")


# COMMAND ----------

# conschema = StructType([
#         StructField("conn_details", StringType())
#     ]) 
# df_conn = readcsv_permissive(spark, path_conn_file,conschema,"\x01","0","na")
df_conn=path_conn_file
externallysourcedsubscriberdob = readparquet(spark, hdfs_input + "externallysourcedsubscriberdob/current/*", "0","na")
numeric_lit = get_max_key_externallysourcedsubscriberdob(spark,externallysourcedsubscriberdob)
import_externallysourcedsubscriberdob(spark,df_conn,tablename,numeric_lit,hdfs_input)
deduped_subdob_verified = readparquet(spark, scratch_path + "/deduped_subdob_verified/", "0","na")
update_externallysourcedsubscriberdob(spark,externallysourcedsubscriberdob,deduped_subdob_verified,scratch_path,sqoop_path,hdfs_input,bc)
