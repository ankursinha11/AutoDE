# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("path_output","")
dbutils.widgets.getArgument("path_output")
path_output= getArgument("path_output")

dbutils.widgets.text("hdfs_input","")
dbutils.widgets.getArgument("hdfs_input")
hdfs_input= getArgument("hdfs_input")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql import types as T
from datetime import *

# COMMAND ----------

# getting valid foundcoverageentities

def get_valid_foundcoverageentities(spark,foundcoverageentities):
    foundcoverageentities = foundcoverageentities.filter(col("entityidentifiercode")=="IL")
    foundcoverageentities = foundcoverageentities.filter(col("foundcoveragesegmentifk").isNull())
    return foundcoverageentities


#function to import the data from sqlserver

def get_subdob_mine_accounts(spark,path_output,lookback_date,foundcoverageentities_filtered,hospitals,hdfs_input):
    hosprdd = hospitals.select(col("hospitalpk"),col("hcsystemfk")).rdd
    hospkeypair_rdd = hosprdd.map(lambda x : (x[0],x[1]))
    hosp_dict = hospkeypair_rdd.collectAsMap() # creating dict of hosp --> hcsystem
    @udf(T.StringType())
    def get_hcsystem(hospital):
        return hosp_dict.get(str(hospital))
    # string_connection = str(df_conn.collect()[0]['conn_details'])
    #string_query_extraction = "SELECT * FROM " + tablename + " WHERE processflag = 'H' and updatedate" + " >= '" + lookback_date + "'"
    # print("DB EXTRACT QUERY : " + string_query_extraction)
    # df_jdbc = spark.read.format("jdbc").option("url", path_conn_file) \
    #                     .option("query", string_query_extraction) \
    #                     .option("numPartitions", 20) \
    #                     .load()
    edi_sub_dob_df=spark.read.format('delta').load(hdfs_input+"edisubscriberdobsearch/current/20991231/")
    edi_sub_dob_df = edi_sub_dob_df.select('edisubscriberdobsearchpk','hospitalfk','patientacctifk','foundcoverageifk','edipartnerfk','subscriberfirstname','subscriberlastname','subscribermiddlename','subscribersuffix','subscriberdob','subscriberssn','subscriberdoblookupfk','responsesubscriberdob','edisubscriberdobresponsefk','createdate','updatedate','processflag','coverageid')
    edi_sub_dob_df = edi_sub_dob_df.filter((col("processflag") == "H") & (col("updatedate") >= lookback_date))
    for column in edi_sub_dob_df.columns:
      edi_sub_dob_df = edi_sub_dob_df.withColumn(column, trim(col(column)))
      edi_sub_dob_df = edi_sub_dob_df.withColumnRenamed(column,column.lower())
    edi_sub_dob_df = edi_sub_dob_df.withColumnRenamed("subscriberfirstname","firstname")
    edi_sub_dob_df = edi_sub_dob_df.withColumnRenamed("subscriberlastname","lastname")
    edi_sub_dob_df = edi_sub_dob_df.withColumnRenamed("subscriberdoblookupfk","subscriberdoblookuppk")
    edi_sub_dob_df = edi_sub_dob_df.withColumn("coverageid",split(col("coverageid"),'-').getItem(0))
    join_cond = [edi_sub_dob_df.hospitalfk == foundcoverageentities_filtered.hospitalfk,edi_sub_dob_df.foundcoverageifk == foundcoverageentities_filtered.foundcoverageifk]
    df_join = edi_sub_dob_df.join(foundcoverageentities_filtered,join_cond,'left') \
                     .select(edi_sub_dob_df["*"],foundcoverageentities_filtered.foundcoverageentityipk.cast("string").alias("foundcoverageentityifk"))
    df = df_join.withColumn("concat_column",sha2(concat_ws("_", df_join.edisubscriberdobsearchpk,df_join.hospitalfk,df_join.patientacctifk,df_join.edipartnerfk,df_join.coverageid), 256))
    df = df.withColumn("mock_foundcoverageifk",when(col("foundcoverageifk").isNull(),col("concat_column")).otherwise(col("foundcoverageifk")))
    df = df.drop(col("concat_column"))
    df = df.withColumn("hcsystemfk",get_hcsystem(col("hospitalfk")))
    df = df.dropDuplicates()
    writeparquet(spark,df,path_output,10,"overwrite")


# COMMAND ----------

# path_conn_file  = baseurl + path_conn_file
path_output = baseurl +path_output +bc +'/subscriberdoblookup/'
# tablename 
hdfs_input = baseurl + hdfs_input
print("path_output:",path_output)
print("hdfs_input:",hdfs_input)

# COMMAND ----------

# from datetime import datetime
d = datetime.today() - timedelta(days=365)
lookback_date = d.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
print("lookbackdate:" + lookback_date)

hospitals_col =  ["hospitalpk","hcsystemfk"]
hospitals = readparquet(spark,hdfs_input + "/hospitals/current/20991231/","1",hospitals_col)

foundcoverageentities_col = ["hospitalfk","foundcoverageifk","entityidentifiercode","foundcoveragesegmentifk","foundcoverageentityipk"] 
foundcoverageentities = extract_deltalake_data(spark,hdfs_input + "/foundcoverageentities/current/20991231/",foundcoverageentities_col)
foundcoverageentities = get_clean_data(spark,foundcoverageentities)
foundcoverageentities_filtered = get_valid_foundcoverageentities(spark,foundcoverageentities)

get_subdob_mine_accounts(spark,path_output,lookback_date,foundcoverageentities_filtered,hospitals,hdfs_input)
