# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("scratch_path","")
dbutils.widgets.getArgument("scratch_path")
scratch_path= getArgument("scratch_path")

dbutils.widgets.text("hdfs_input","")
dbutils.widgets.getArgument("hdfs_input")
hdfs_input= getArgument("hdfs_input")

dbutils.widgets.text("tu_consumer_path","")
dbutils.widgets.getArgument("tu_consumer_path")
tu_consumer_path= getArgument("tu_consumer_path")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/schema_util

# COMMAND ----------

hdfs_input = baseurl + hdfs_input
tu_consumer_path = baseurl+tu_consumer_path
scratch_path = baseurl+scratch_path + bc + '/'
print(hdfs_input)
print(tu_consumer_path)
print(scratch_path)

# COMMAND ----------

def blank_as_null(x):
    return when( ( (trim(col(x)) != "") & (trim(lower(col(x))) != "null" ) ), col(x)).otherwise(None)

#get the valid permid data where firstname and lastname matches

def get_valid_permid_data(spark,df_permid_dob,hospitals,hcsystems,scratch_path):
    hospitals = hospitals.withColumn("allowaggregationoutflag",blank_as_null("allowaggregationoutflag"))\
                   .withColumn("allowaggregationinflag",blank_as_null("allowaggregationinflag"))
    hcsystems = hcsystems.withColumn("allowaggregationoutflag",blank_as_null("allowaggregationoutflag"))\
                   .withColumn("allowaggregationinflag",blank_as_null("allowaggregationinflag")) 
    df_permid_dob.createOrReplaceTempView("df_permid_dob")
    df_permid_dob_filtered_pquery = """ select 
                                        mock_foundcoverageifk,
                                        permid,
                                        lsb_dob,
                                        hospitalfk,
                                        lsb_source as datasource_formatted, 
                                        explode(lsb_hospitalfklst) as lsb_hospitalfk
                                        from df_permid_dob
                                        where firstname <=> lsb_firstname and lastname <=> lsb_lastname """
    df_permid_dob_filtered = spark.sql(df_permid_dob_filtered_pquery)
    hospitals.createOrReplaceTempView("hospitals")
    hcsystems.createOrReplaceTempView("hcsystems")
    df_permid_dob_filtered.createOrReplaceTempView("df_permid_dob_filtered")
    valid_permid_pquery = """select d.* \
       		   from df_permid_dob_filtered d \
       		   left join hospitals h on d.hospitalfk <=> h.hospitalpk \
                   left join hcsystems hc on h.hcsystemfk <=> hc.hcsystempk \
                   left join hospitals h2 on d.lsb_hospitalfk <=> h2.hospitalpk \
                   left join hcsystems hc2 on h2.hcsystemfk <=> hc2.hcsystempk \
                   where (( coalesce(h.allowaggregationinflag ,hc.allowaggregationinflag ,1)=1 \
                         and coalesce(h2.allowaggregationoutflag, hc2.allowaggregationoutflag,1)=1 \
                        ) or h2.hcsystemfk = h.hcsystemfk or lower(d.datasource_formatted) = 'ich' \
                        ) """
    valid_permid = spark.sql(valid_permid_pquery)
    writeparquet(spark,valid_permid,scratch_path + "/valid_permid/",500,"overwrite")


#get the subdob using the permid


def get_subdob_permid_data(spark,df_permid_dob_filtered,tu_consumer_raw,subscriberdoblookup,scratch_path):
    df_permid_dob_filtered.createOrReplaceTempView("df_permid_dob_filtered")
    tu_consumer_raw.createOrReplaceTempView("consumerinforaw")
    subscriberdoblookup.createOrReplaceTempView("subscriberdoblookup")
    permid_subdob_pquery = """ select distinct mock_foundcoverageifk,
                                      permid,
                                      hospitalfk,
                                      max(lsb_dob) as sub_dob,
                                      min(case when datasource_formatted == "fc" then 1 
                                           when datasource_formatted == "m1" then 2 
                                           when datasource_formatted == "im" then 3
                                           when datasource_formatted == "hm" then 4
                                           else 5 end) as priority 
                                      from df_permid_dob_filtered dpdf
                                      join consumerinforaw cir
                                      on dpdf.permid = cir.tukey
                                      where dpdf.lsb_dob <=> cir.dob or cir.dob is null 
                                      group by mock_foundcoverageifk,permid,hospitalfk """
    permid_subdob = spark.sql(permid_subdob_pquery)
    permid_subdob = permid_subdob.withColumn("source",lit("permid-lookup"))
    permid_subdob = permid_subdob.withColumn("subdob_mine_value",lit(10))
    permid_subdob = permid_subdob.withColumn("subdob_mine_status",lit("unverified"))
    permid_subdob.createOrReplaceTempView("permid_subdob")
    prepare_externallysourcedsubscriberdob_data = """ select distinct
                                                      cast(ess.hospitalfk as  string) as hospitalfk,
                                                      cast(ess.patientacctifk as string) as patientacctifk,
                                                      ess.subscriberdoblookuppk,
                                                      cast(ps.sub_dob as string) as dob,
                                                      cast(ess.foundcoverageifk as string) as foundcoverageifk,
                                                      cast(ess.foundcoverageentityifk as  string) as foundcoverageentityifk,
                                                      '' as edisubscriberdobresponsefk,
                                                      '' as sourcepatienthospitalfk,
                                                      '' as sourcepatientacctifk,
                                                      '' as sourcefoundcoveragehospitalfk,
                                                      '' as sourcefoundcoverageifk,
                                                      ess.edipartnerfk as edipartnerfk,
                                                      ps.source,
                                                      ps.subdob_mine_value,
                                                      ps.subdob_mine_status,
                                                      ess.edisubscriberdobsearchpk
                                                      from subscriberdoblookup ess
                                                      join permid_subdob as ps
                                                       on ess.mock_foundcoverageifk = ps.mock_foundcoverageifk
                                                       and ess.hospitalfk = ps.hospitalfk """ 
    externallysourcedsubscriberdob_data = spark.sql(prepare_externallysourcedsubscriberdob_data)
    writeparquet(spark,externallysourcedsubscriberdob_data,scratch_path + "/unverified_mined_subdob_permid_data/",10,"overwrite")

# COMMAND ----------

subscriberdoblookup = readparquet(spark, scratch_path + "/subscriberdoblookup/", "0","na")
subscriberdoblookup = get_clean_data(spark,subscriberdoblookup)
hospcols = ["hcsystemfk", "hospitalpk", "allowaggregationinflag", "allowaggregationoutflag" ]
hospitals = readparquet(spark, hdfs_input + "/hospitals/current/*","1",hospcols)
hccols = ["hcsystempk", "allowaggregationinflag", "allowaggregationoutflag"]
hcsystems = readparquet(spark, hdfs_input + "/hcsystems/current/*","1", hccols)

df_permid_dob = readparquet(spark, scratch_path + "/permidsubdobmining/*", "0","na")
df_permid_dob_filtered_stage = get_valid_permid_data(spark,df_permid_dob,hospitals,hcsystems,scratch_path)
df_permid_dob_filtered = readparquet(spark, scratch_path + "/valid_permid/*", "0","na")

# tu_consumer_raw_schema_file = fs_common + "/consumer_info_raw.schema"
# tu_consumer_raw_schema = createSchemaLine(tu_consumer_raw_schema_file)
# tu_consumer_raw_columns = ["tukey","frst_nme","last_nme","dob"]
# tu_consumer_raw = readcsv_permissive(spark,tu_consumer_path,tu_consumer_raw_schema,"|","1",tu_consumer_raw_columns)
tu_consumer_raw = spark.read.parquet(tu_consumer_path).select("tukey","frst_nme","last_nme","dob")
tu_consumer_raw = get_clean_data(spark,tu_consumer_raw)
get_subdob_permid_data(spark,df_permid_dob_filtered,tu_consumer_raw,subscriberdoblookup,scratch_path)
