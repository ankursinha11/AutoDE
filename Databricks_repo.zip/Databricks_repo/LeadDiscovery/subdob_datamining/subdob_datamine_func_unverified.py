# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("scratch_path","")
dbutils.widgets.getArgument("scratch_path")
scratch_path= getArgument("scratch_path")

dbutils.widgets.text("hdfs_input","")
dbutils.widgets.getArgument("hdfs_input")
hdfs_input= getArgument("hdfs_input")

dbutils.widgets.text("permid_path","")
dbutils.widgets.getArgument("permid_path")
permid_path= getArgument("permid_path")


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.functions import udf
from pyspark.sql import types as T
from math import sin, cos, sqrt, atan2, radians

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

hdfs_input = baseurl + hdfs_input
permid_path = baseurl + permid_path
scratch_path = baseurl+scratch_path + bc + '/'
print(hdfs_input)
print(permid_path)
print(scratch_path)

# COMMAND ----------

def get_permid_lookup(spark,patientacctsxrefpermid,subscriberdoblookup,scratch_path):
    patientacctsxrefpermid = patientacctsxrefpermid.filter(col("matchind") == "HM")
    subscriberdoblookup.createOrReplaceTempView("subscriberdoblookup")
    patientacctsxrefpermid.createOrReplaceTempView("patientacctsxrefpermid")
    permid_lookup_pquery = """ select ess.* , 
                                      perm.permid
                                      from subscriberdoblookup ess
                                      join patientacctsxrefpermid perm
	                              on 
	                              ess.patientacctifk <=> perm.patientacctifk 
                                  and ess.hospitalfk <=> perm.hospitalfk 
                                      """
    permid_lookup = spark.sql(permid_lookup_pquery)
    writeparquet(spark,permid_lookup,scratch_path + "/permid_lookup/",10,"overwrite")


# hgetting the lat and long for each of the zip

def get_patientaccts_zip_latlong(spark,patientaccts,zipcodes,scratch_path):
    patientaccts = patientaccts.filter(col("dob").isNotNull())
    patientaccts.createOrReplaceTempView("patientaccts")
    zipcodes.createOrReplaceTempView("zipcodes")
    zip_latlong_pquery = """ select 
                             pa.*,
                             substring(pa.zip,0,5) as zip_first,
                             z.latitude ,
                             z.longitude
                             from patientaccts pa
                             join zipcodes z
                             on substring(pa.zip,0,5) <=> z.zipcode """
    zip_latlong_pa = spark.sql(zip_latlong_pquery)
    writeparquet(spark,zip_latlong_pa,scratch_path + "/pa_lookup/",2000,"overwrite")




# get the cluster account from clusteraccount table and get other information from pa table

def get_clusteredacct_data(spark,subscriberdoblookup,clusteredaccts,patientaccts,scratch_path,hospitals):
    hosprdd = hospitals.select(col("hospitalpk"),col("hcsystemfk")).rdd
    hospkeypair_rdd = hosprdd.map(lambda x : (x[0],x[1]))
    hosp_dict = hospkeypair_rdd.collectAsMap() # creating dict of hosp --> hcsystem
    @udf(T.StringType())
    def get_hcsystem(hospital):
        return hosp_dict.get(str(hospital))
    clusteredaccts = clusteredaccts.withColumn("hcsystemfk",get_hcsystem(col("hospitalfk")))
    clusteredaccts.createOrReplaceTempView("clusteredaccts")
    subscriberdoblookup.createOrReplaceTempView("subscriberdoblookup")
    patientaccts.createOrReplaceTempView("patientaccts")
    clusteredaccts_lookup_pquery = """  select 
                                        sdl.subscriberdoblookuppk as subscriberdoblookupfk, 
                                        sdl.hospitalfk, 
                                        sdl.patientacctifk, 
                                        sdl.foundcoverageifk,
                                        sdl.mock_foundcoverageifk,
                                        ''  as edipartnerfk, 
                                        sdl.firstname as subscriberfirstname, 
                                        sdl.lastname as subscriberlastname,
                                        '' as subscriberdob, 
                                        '' as needsdob, 
                                        ca.hospitalfk subhospitalfk, 
                                        ca.clusteredacctpk
                                        from subscriberdoblookup sdl
                                        join clusteredaccts ca
                                        on lower(sdl.firstname) <=> lower(ca.firstname)
                                        and  
	                                lower(sdl.lastname) <=> lower(ca.lastname)
                                        and ca.hcsystemfk = sdl.hcsystemfk """
    clusteredaccts_lookup = spark.sql(clusteredaccts_lookup_pquery)
    clusteredaccts_lookup.createOrReplaceTempView("clusteredaccts_lookup")
    clusteredacct_lookup_pa_pquery = """ select 
                                      sdl.subscriberdoblookupfk, 
                                      sdl.hospitalfk, 
                                      sdl.patientacctifk, 
                                      sdl.mock_foundcoverageifk,
                                      '' as edipartnerfk, 
                                      sdl.subscriberfirstname, 
                                      sdl.subscriberlastname,
                                      '' as subscriberdob, 
                                      '' as needsdob, 
                                      pa.hospitalfk subhospitalfk, 
                                      sdl.clusteredacctpk,
                                      pa.patientacctipk as subpatientacctifk
                                      from clusteredaccts_lookup sdl
                                      join patientaccts pa
                                      on 
                                      pa.hospitalfk <=> sdl.subhospitalfk 
                                      and 
                                      pa.ClusteredAcctFK <=> sdl.clusteredacctpk """
    clusteredacct_lookup_pa = spark.sql(clusteredacct_lookup_pa_pquery)
    writeparquet(spark,clusteredacct_lookup_pa,scratch_path + "/clusteredacct_lookup_pa/",2000,"overwrite")

# not reuried as of now if icd3.0 take care of it 

def create_edisubscriberdobsearch(spark,subscriberdoblookup,foundcoverage,edipartner270settings,edi270querycombos,scratch_path):
    foundcoverage.createOrReplaceTempView("foundcoverage")
    subscriberdoblookup.createOrReplaceTempView("subscriberdoblookup")
    edipartner270settings.createOrReplaceTempView("edipartner270settings")
    edi270querycombos.createOrReplaceTempView("edi270querycombos")
    edisubscriberdobsearch_pquery = """ select 
                                        distinct sdl.subscriberdoblookuppk subscriberdoblookupfk, 
                                                 sdl.hospitalfk, 
                                                 sdl.patientacctifk, 
                                                 sdl.foundcoverageifk, 
                                                 sdl.edipartnerfk,
                                                 sdl.firstname as  subscriberfirstname,
                                                 sdl.lastname as subscriberlastname,
                                                 '' as subscriberdob,
                                                 case when eqc.name like '%dob%' then 1 else 0 end needsdob
                                        from subscriberdoblookup sdl
                                        join edipartner270settings  eps
                                             on (eps.edipartnerfk = sdl.edipartnerfk)
                                        join edi270querycombos eqc
                                             on eps.subscriberquerycombo  = eqc.edi270querycombopk """
    edisubscriberdobsearch  = spark.sql(edisubscriberdobsearch_pquery)
    writeparquet(spark,edisubscriberdobsearch,scratch_path + "/edisubscriberdobsearch/",10,"overwrite")

#getting the distance between two zips

def get_distancebetweentwozipcodes(lat1,lon1,lat2,lon2):
    r = 3958.8
    lat1 = radians(float(lat1))
    lon1 = radians(float(lon1))
    lat2 = radians(float(lat2))
    lon2 = radians(float(lon2))
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = sin(dlat / 2)**2 + cos(lat1) * cos(lat2) * sin(dlon / 2)**2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))
    distance = r * c
    return str(distance)

# function get the subdob using cluster accounts


def get_subdob_clusteredacct_data(spark,clusteredacct_lookup_pa,patientaccts,hospitals,subscriberdoblookup,scratch_path):
    clusteredacct_lookup_pa.createOrReplaceTempView("edisubscriberdobsearch_patientaccts")
    patientaccts.createOrReplaceTempView("patientaccts")
    hospitals.createOrReplaceTempView("hospitals")
    udf_distancebetweentwozipcodes = udf(get_distancebetweentwozipcodes, StringType())    
    subscriberdoblookup.createOrReplaceTempView("subscriberdoblookup")
    probablesubscriberinsamesystem_stage1_pquery = """ select 
                                                       srchpat.mock_foundcoverageifk, 
                                                       pasub.dob subscriberdob,
                                                       pa.firstname as pa_firstname,
                                                       pasub.middlename as pasub_middlename,
                                                       pasub.firstname as pasub_firstname,
                                                       pa.middlename as pa_middlename,
                                                       pa.latitude as pa_latitude,
                                                       pa.longitude as pa_longitude,
                                                       pasub.latitude as pasub_latitude,
                                                       pasub.longitude as pasub_longitude,
                                                       pa.zip_first pa_zip,
                                                       pasub.zip_first pasub_zip,
                                                       pa.city pa_city,
                                                       pasub.city pasub_city,
                                                       h.city h_city,
                                                       h.hospitalpk as h_hospitalpk,
                                                       hsub.hospitalpk  as hsub_hospitalpk,
                                                       hsub.city hsub_city,
                                                       pa.state pa_state,
                                                       pasub.state pasub_state,
                                                       h.state h_state,
                                                       hsub.state hsub_state
                                                       from 
                                                       edisubscriberdobsearch_patientaccts srchpat
                                                       join
                                                       patientaccts pasub  
                                                       on 
                                                            srchpat.subhospitalfk <=> pasub.hospitalfk and srchpat.subpatientacctifk <=> pasub.patientacctipk
                                                       join 
                                                       patientaccts pa  
                                                       on 
                                                            srchpat.hospitalfk <=> pa.hospitalfk and srchpat.patientacctifk <=> pa.patientacctipk
                                                       join 
                                                       hospitals h  
                                                            on 
                                                            pa.hospitalfk <=> h.hospitalpk
                                                       join 
                                                       hospitals hsub  
                                                            on 
                                                            hsub.hospitalpk <=> pasub.hospitalfk """
    probablesubscriberinsamesystem_stage1 = spark.sql(probablesubscriberinsamesystem_stage1_pquery)
    probablesubscriberinsamesystem_stage1_tmp = probablesubscriberinsamesystem_stage1.withColumn("zipdistance",udf_distancebetweentwozipcodes(col("pa_latitude"),col("pa_longitude"),col("pasub_latitude"),col("pasub_longitude"))) 
    writeparquet(spark,probablesubscriberinsamesystem_stage1_tmp,scratch_path + "/probablesubscriberinsamesystem_stage1/",10,"overwrite")
    probablesubscriberinsamesystem_stage1_read = readparquet(spark, scratch_path + "/probablesubscriberinsamesystem_stage1/", "0","na") 
    probablesubscriberinsamesystem_stage1_read.createOrReplaceTempView("probablesubscriberinsamesystem_stage1")
    probablesubscriberinsamesystem_stage2_pquery = """ select 
                                                       mock_foundcoverageifk,
                                                       h_hospitalpk,
                                                       subscriberdob,
                                                       min(case when pa_zip = pasub_zip then 1 
                                                       when substr(pa_firstname,0,1) <=> substr(pasub_middlename,0,1) or substr(pasub_firstname,0,1) <=> substr(pa_middlename,0,1) then 2 
		                                       when zipdistance between 0 and 10 then 3 
		                                       when zipdistance between 0 and 50 then 4
		                                       when h_hospitalpk = hsub_hospitalpk then 5
		                                       when pa_city = pasub_city then 7
		                                       when h_state = hsub_state then 10
		                                       else 99
		                                       end )  as  priorityorder
                                                       from probablesubscriberinsamesystem_stage1 ps1	
                                                       group by mock_foundcoverageifk,subscriberdob,h_hospitalpk """   
    probablesubscriberinsamesystem_stage2 = spark.sql(probablesubscriberinsamesystem_stage2_pquery)
    probablesubscriberinsamesystem_stage2.createOrReplaceTempView("probablesubscriberinsamesystem_stage2")
    probablesubscriberinsamesystem_stage3_pquery = """ select 
                                                       mock_foundcoverageifk,
                                                       h_hospitalpk, 
                                                       subscriberdob,
                                                       row_number() over (partition by mock_foundcoverageifk, h_hospitalpk order by priorityorder, subscriberdob) rownum
                                                       from probablesubscriberinsamesystem_stage2
                                                   """
    probablesubscriberinsamesystem_stage3 = spark.sql(probablesubscriberinsamesystem_stage3_pquery)
    probablesubscriberinsamesystem_stage3.createOrReplaceTempView("probablesubscriberinsamesystemwithorder")
    subdob_mine_edisubscriberdobsearch_pquery = """ select  
                                                    distinct sdl.subscriberdoblookuppk, 
                                                    sdl.hospitalfk, 
                                                    sdl.patientacctifk, 
                                                    sdl.foundcoverageifk,
                                                    '' as edipartnerfk, 
                                                    sdl.firstname as subscriberfirstname, 
                                                    sdl.lastname as subscriberlastname,
                                                    pro.subscriberdob,
                                                    sdl.edisubscriberdobsearchpk
                                                    from probablesubscriberinsamesystemwithorder pro
                                                    join subscriberdoblookup sdl 
                                                    on 
                                                    sdl.mock_foundcoverageifk = pro.mock_foundcoverageifk
                                                    and sdl.hospitalfk = pro.h_hospitalpk
                                                    where pro.rownum <= 2 """
    mined_subdob_clusteracct_data = spark.sql(subdob_mine_edisubscriberdobsearch_pquery)
    mined_subdob_clusteracct_data = mined_subdob_clusteracct_data.withColumn("source",lit("clusteraccts"))
    mined_subdob_clusteracct_data = mined_subdob_clusteracct_data.withColumn("subdob_mine_value",lit(9))
    mined_subdob_clusteracct_data = mined_subdob_clusteracct_data.withColumn("subdob_mine_status",lit("unverified"))
    mined_subdob_clusteracct_data.createOrReplaceTempView("mined_subdob_clusteracct_data")
    # formatting the data to read all o/p of mine this will not go to externallysourcedsubscriberdob as  this is unverfied dob
    format_externallysourcedsubscriberdob_data_pquery = """ select
                                                      cast(hospitalfk as string) as hospitalfk,
                                                      cast(patientacctifk as string) as patientacctifk,
                                                      cast(subscriberdoblookuppk as string) as subscriberdoblookuppk,
                                                      cast(subscriberdob as string) as dob,
                                                      cast(foundcoverageifk as string) as foundcoverageifk, 
                                                      '' as foundcoverageentityifk,
                                                      '' as edisubscriberdobresponsefk,
                                                      '' as sourcepatienthospitalfk,
                                                      '' as sourcepatientacctifk,
                                                      '' as sourcefoundcoveragehospitalfk,
                                                      '' as sourcefoundcoverageifk,
                                                      '' as edipartnerfk,
                                                      source,
                                                      subdob_mine_value,
                                                      subdob_mine_status,
                                                      edisubscriberdobsearchpk
                                                      from mined_subdob_clusteracct_data """
    format_externallysourcedsubscriberdob_data = spark.sql(format_externallysourcedsubscriberdob_data_pquery)
    writeparquet(spark,format_externallysourcedsubscriberdob_data,scratch_path + "/unverified_mined_subdob_clusteracct_data/",10,"overwrite")

# COMMAND ----------

subscriberdoblookup = readparquet(spark, scratch_path + "/subscriberdoblookup/", "0","na")
hospitals_column = ["hospitalpk","city","state","hcsystemfk"]  
hospitals = readparquet(spark, hdfs_input + "/hospitals/current/*", "1",hospitals_column)
hospitals = get_clean_data(spark,hospitals)

# permidschema = StructType([
#         StructField("permid", StringType()),
#         StructField("hospitalfk", StringType()),
#         StructField("patientacctifk", StringType()),
#         StructField("matchind", StringType()),
#         StructField("magnetpermid", StringType())
#     ])
#patientacctsxrefpermid = readcsv_permissive(spark,permid_path,permidschema,"|","0","na") 
patientacctsxrefpermid = readparquet(spark, permid_path, "0","na")
patientacctsxrefpermid = get_clean_data(spark,patientacctsxrefpermid)
zipcodes = readparquet(spark, hdfs_input + "/zipcodes/current/*", "0","na")
zipcodes = get_clean_data(spark,zipcodes)
patientaccts_col = ["hospitalfk","patientacctipk","dob","firstname","lastname","zip","clusteredacctfk","city","state","middlename"]
patientaccts = extract_deltalake_data(spark,hdfs_input + "/patientaccts/current/20991231/",patientaccts_col)
patientaccts = get_clean_data(spark,patientaccts)
patientaccts = get_patientaccts_zip_latlong(spark,patientaccts,zipcodes,scratch_path)
patientaccts_extended = readparquet(spark, scratch_path + "/pa_lookup/", "0","na")

clusteredaccts_col = ["hospitalfk","clusteredacctpk","dob","firstname","lastname"]
clusteredaccts = extract_deltalake_data(spark,hdfs_input + "/clusteredaccts/current/20991231/",clusteredaccts_col)
clusteredaccts = get_clean_data(spark,clusteredaccts)
get_clusteredacct_data(spark,subscriberdoblookup,clusteredaccts,patientaccts_extended,scratch_path,hospitals)
clusteredacct_lookup_pa = readparquet(spark, scratch_path + "/clusteredacct_lookup_pa/", "0","na")
get_permid_lookup(spark,patientacctsxrefpermid,subscriberdoblookup,scratch_path)
get_subdob_clusteredacct_data(spark,clusteredacct_lookup_pa,patientaccts_extended,hospitals,subscriberdoblookup,scratch_path)
