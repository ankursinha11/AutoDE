# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("catalog_name","")
dbutils.widgets.getArgument("catalog_name")
catalog_name = getArgument("catalog_name")

# COMMAND ----------

# container = "prod-icd-stg-adls"
# storageaccount = "prodicdstgdls"
# user = "vishnup"
# bc = "20250825T13"
# catalog_name = "prod_icd_stg_leadgen_catalog"

# COMMAND ----------

# DBTITLE 1,set basepath
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user
print(baseurl)

scratch_path = "/data/leaddiscovery/transform/output/subscriber_dob/"

## UPDATE THIS TO escan BEFORE DEPLOYING
icddb = "escan"
tablename1 = "dbo.ExternallySourcedSubscriberDOB_holding"
tablename2 = "dbo.ExternallySourcedSubscriberDOB_batch"
tablename3 = "dbo.EDISubscriberDOBSearch_holding"
tablename4 = "dbo.EDISubscriberDOBSearch_batch"

scratch_path = scratch_path + bc
externallysourcedsubscriberdob_holding_path = f"{baseurl}{scratch_path}/externallysourcedsubscriberdob_holding/"
externallysourcedsubscriberdob_batch_path = f"{baseurl}{scratch_path}/externallysourcedsubscriberdob_batch/"
edisubscriberdobsearch_holding_path = f"{baseurl}{scratch_path}/edisubscriberdobsearch_holding/"
edisubscriberdobsearch_batch_path = f"{baseurl}{scratch_path}/edisubscriberdobsearch_batch/"

# Creating empty dataframes
externallysourcedsubscriberdob_holding_df = None
externallysourcedsubscriberdob_batch_df = None
edisubscriberdobsearch_holding_df = None
edisubscriberdobsearch_batch_df = None

print(externallysourcedsubscriberdob_holding_path)
print(externallysourcedsubscriberdob_batch_path)
print(edisubscriberdobsearch_holding_path)
print(edisubscriberdobsearch_batch_path)

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# MAGIC %run ../../Common-Util/shard_db_util

# COMMAND ----------

def count_file(dir):
    counter = 0
    for file in dir:
        if(file.name.startswith('part')):
            counter += 1
    return counter

# COMMAND ----------

externally_holding_schema = StructType([
    StructField("externallysourcedsubscriberdobpk", StringType(), True),
    StructField("hospitalfk", StringType(), True),
    StructField("patientacctifk", StringType(), True),
    StructField("subscriberdoblookupfk", StringType(), True),
    StructField("dob", StringType(), True),
    StructField("sourceacxiomhospitalfk", StringType(), True),
    StructField("acxiomdemographicsresponseid", StringType(), True),
    StructField("sourcepatienthospitalfk", StringType(), True),
    StructField("sourcepatientacctifk", StringType(), True),
    StructField("sourcefoundcoveragehospitalfk", StringType(), True),
    StructField("sourcefoundcoverageifk", StringType(), True),
    StructField("edisubscriberdobresponsefk", StringType(), True),
    StructField("foundcoverageifk", StringType(), True),
    StructField("foundcoverageentityifk", StringType(), True),
    StructField("createdate", StringType(), True),
    StructField("edipartnerfk", StringType(), True),
    StructField("edisubscriberdobsearchfk", StringType(), True),
    StructField("breadcrumb", StringType(), True)])

batch_schema = StructType([StructField("breadcrumb", StringType(), True)])

edi_holding_schema = StructType([
    StructField("edisubscriberdobsearchfk", StringType(), True),
    StructField("hospitalfk", StringType(), True),
    StructField("patientacctifk", StringType(), True),
    StructField("foundcoverageifk", StringType(), True),
    StructField("edipartnerfk", StringType(), True),
    StructField("subscriberfirstname", StringType(), True),
    StructField("subscriberlastname", StringType(), True),
    StructField("subscribermiddlename", StringType(), True),
    StructField("subscribersuffix", StringType(), True),
    StructField("subscriberdob", StringType(), True),
    StructField("subscriberssn", StringType(), True),
    StructField("subscriberdoblookupfk", StringType(), True),
    StructField("responsesubscriberdob", StringType(), True),
    StructField("edisubscriberdobresponsefk", StringType(), True),
    StructField("process_flag", StringType(), True),
    StructField("coverageid", StringType(), True),
    StructField("createdate", StringType(), True),
    StructField("updatedate", StringType(), True),
    StructField("breadcrumb", StringType(), True),
    StructField("subdob", StringType(), True),
    StructField("source", StringType(), True),
    StructField("status", StringType(), True)])

# COMMAND ----------

def get_dataframe(path, df_schema):
    try:
        path_val = dbutils.fs.ls(path)
        if(count_file(path_val) > 0):
            df = spark.read.csv(path, sep="\x01", schema = df_schema)
            return df
        else:            
            return None            
    except Exception as e:
        raise Exception(f"Data doesn't exist for path - {path}. Error - {e}")

# COMMAND ----------

def data_migration_to_sql(df, table_name, server_name, connection_string):
    try:
        df.write.format('jdbc').mode('append').option('driver', 'com.microsoft.sqlserver.jdbc.SQLServerDriver').option('url', connection_string).option('dbtable', f"{icddb}.{table_name}").save()
    except Exception as e:        
        raise Exception(f"Sqoop for table - {table_name} failed on server - {server_name}. \n Error - {e}")

# COMMAND ----------

# DBTITLE 1,Read all the datasets
externallysourcedsubscriberdob_holding_df = get_dataframe(externallysourcedsubscriberdob_holding_path, externally_holding_schema)
externallysourcedsubscriberdob_batch_df = get_dataframe(externallysourcedsubscriberdob_batch_path, batch_schema)
edisubscriberdobsearch_holding_df = get_dataframe(edisubscriberdobsearch_holding_path, edi_holding_schema)
edisubscriberdobsearch_batch_df = get_dataframe(edisubscriberdobsearch_batch_path, batch_schema)

# Getting list of all the shard DBs connection string and Hospitals
connection_string_df = get_shard_db_connection_string(catalog_name, f"{baseurl}/data/dataingestion/publish/")
connection_string_map = [{
                            "HospitalFKList": row['HospitalFKList'],
                            "ServerName": row['ServerName'],
                            "ConnectionString": row['ConnectionString']
                        } for row in connection_string_df.collect()]

# COMMAND ----------

# DBTITLE 1,Sqooping externallysourcedsubscriberdob_holding data to shard DBs
for shard in connection_string_map:
    HospitalFKList = shard["HospitalFKList"]    
    df_1 = externallysourcedsubscriberdob_holding_df.filter(col("hospitalfk").isin(HospitalFKList))
    if df_1.take(1):
        data_migration_to_sql(df_1, tablename1, shard["ServerName"], shard['ConnectionString'])
        data_migration_to_sql(externallysourcedsubscriberdob_batch_df, tablename2, shard["ServerName"], shard['ConnectionString'])

# COMMAND ----------

# DBTITLE 1,Sqooping edisubscriberdobsearch_holding data to shard DBs
for shard in connection_string_map:
    HospitalFKList = shard["HospitalFKList"]    
    df_2 = edisubscriberdobsearch_holding_df.filter(col("hospitalfk").isin(HospitalFKList))
    if df_2.take(1):
        data_migration_to_sql(df_2, tablename3, shard["ServerName"], shard['ConnectionString'])
        data_migration_to_sql(edisubscriberdobsearch_batch_df, tablename4, shard["ServerName"], shard['ConnectionString'])
