# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("scratch_path","")
dbutils.widgets.getArgument("scratch_path")
scratch_path= getArgument("scratch_path")

dbutils.widgets.text("hdfs_input","")
dbutils.widgets.getArgument("hdfs_input")
hdfs_input= getArgument("hdfs_input")


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from datetime import *

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

hdfs_input = baseurl+hdfs_input
scratch_path = baseurl+scratch_path + bc + '/'
print(hdfs_input)
print(scratch_path)

# COMMAND ----------

def get_subdob_edi_responses(spark,edisubscriberdobsearch,edisubscriberdobresponse,subscriberdoblookup,scratch_path):
    edisubscriberdobsearch = edisubscriberdobsearch.filter(col("responsesubscriberdob").isNotNull())
    edisubscriberdobsearch.createOrReplaceTempView("edisubscriberdobsearch")
    edisubscriberdobresponse.createOrReplaceTempView("edisubscriberdobresponse")
    subscriberdoblookup.createOrReplaceTempView("subscriberdoblookup")
    lookup_subdob_edi_pquery = """ select 
                                          sdl.mock_foundcoverageifk,
                                          max(src.responsesubscriberdob) subscriberdob, 
                                          min(src.edisubscriberdobresponsefk) edisubscriberdobresponsefk
                                          from subscriberdoblookup sdl
                                          join edisubscriberdobsearch src
                                             on sdl.hospitalfk <=> src.hospitalfk
                                             and sdl.patientacctifk <=> src.patientacctifk
                                             and sdl.foundcoverageifk <=> src.foundcoverageifk
                                          join edisubscriberdobresponse res
                                              on src.hospitalfk <=> res.hospitalfk
                                              and src.patientacctifk <=> res.patientacctifk
                                              and src.edisubscriberdobresponsefk <=> res.edisubscriberdobresponsepk
                                          where lower(src.subscriberfirstname) <=> lower(res.firstname)
                                                group by sdl.mock_foundcoverageifk,sdl.hospitalfk
                                                having count(distinct src.responsesubscriberdob) = 1 """
    mined_subdob_edi_data = spark.sql(lookup_subdob_edi_pquery)
    mined_subdob_edi_data = mined_subdob_edi_data.withColumn("source",lit("edi-response"))
    mined_subdob_edi_data = mined_subdob_edi_data.withColumn("subdob_mine_value",lit(1))
    mined_subdob_edi_data = mined_subdob_edi_data.withColumn("subdob_mine_status",lit("verified"))
    mined_subdob_edi_data.createOrReplaceTempView("ediresponse")
    prepare_externallysourcedsubscriberdob_data = """ select
                                                      ess.hospitalfk, 
                                                      ess.patientacctifk, 
                                                      ess.subscriberdoblookuppk, 
                                                      cast(edi.subscriberdob as string) as dob, 
                                                      ess.foundcoverageifk, 
                                                      ess.foundcoverageentityifk, 
                                                      edi.edisubscriberdobresponsefk,
                                                      '' as sourcepatienthospitalfk,
                                                      '' as sourcepatientacctifk,
                                                      '' as sourcefoundcoveragehospitalfk,
                                                      '' as sourcefoundcoverageifk,
                                                      ess.edipartnerfk as edipartnerfk,
                                                      edi.source,
                                                      edi.subdob_mine_value,
                                                      edi.subdob_mine_status,
                                                      ess.edisubscriberdobsearchpk
                                                      from subscriberdoblookup ess
                                                      join ediresponse edi 
                                                       on ess.mock_foundcoverageifk = edi.mock_foundcoverageifk 
                                                       and ess.hospitalfk = edi.hospitalfk """
    externallysourcedsubscriberdob_data = spark.sql(prepare_externallysourcedsubscriberdob_data)    
    writeparquet(spark,externallysourcedsubscriberdob_data,scratch_path + "/verified_mined_subdob_edi_data/",10,"overwrite")


#This below func look at past ediresponses and try to find subdob 

def get_subdob_past_edi_response(spark,edisubscriberdobsearch,edisubscriberdobresponse,subscriberdoblookup,foundcoverage,scratch_path):
   edisubscriberdobresponse = edisubscriberdobresponse.filter(col("dob").isNotNull())   
   edisubscriberdobsearch.createOrReplaceTempView("edisubscriberdobsearch")
   edisubscriberdobresponse.createOrReplaceTempView("edisubscriberdobresponse")
   subscriberdoblookup.createOrReplaceTempView("subscriberdoblookup")
   foundcoverage.createOrReplaceTempView("foundcoverage")    
   lookup_subdob_past_edi_pquery = """ 
                                 select
                                 sdl.mock_foundcoverageifk,
                                 sdl.hospitalfk, 
                                 max(res.dob) subscriberdob, 
                                 min(res.edisubscriberdobresponsepk) edisubscriberdobresponsefk
                                 from subscriberdoblookup sdl
                                 join edisubscriberdobresponse res
                                   on sdl.firstname <=> res.firstname and 
                                      sdl.lastname <=> res.lastname and 
                                      res.edipartnerfk <=> sdl.edipartnerfk and 
                                      sdl.coverageid <=> res.derived_coverageid
                                 group by sdl.mock_foundcoverageifk,sdl.hospitalfk
                                 having count(distinct res.dob) = 1
                              """
   mined_subdob_past_edi_data = spark.sql(lookup_subdob_past_edi_pquery)
   mined_subdob_past_edi_data = mined_subdob_past_edi_data.withColumn("source",lit("past-edi-response"))
   mined_subdob_past_edi_data = mined_subdob_past_edi_data.withColumn("subdob_mine_value",lit(2))
   mined_subdob_past_edi_data = mined_subdob_past_edi_data.withColumn("subdob_mine_status",lit("verified"))
   mined_subdob_past_edi_data.createOrReplaceTempView("pastediresponse")
   prepare_externallysourcedsubscriberdob_data = """ select
                                                      ess.hospitalfk,
                                                      ess.patientacctifk,
                                                      ess.subscriberdoblookuppk,
                                                      cast(edi.subscriberdob as string) as dob,
                                                      ess.foundcoverageifk,
                                                      ess.foundcoverageentityifk,
                                                      edi.edisubscriberdobresponsefk,
                                                      '' as sourcepatienthospitalfk,
                                                      '' as sourcepatientacctifk,
                                                      '' as sourcefoundcoveragehospitalfk,
                                                      '' as sourcefoundcoverageifk,
                                                      ess.edipartnerfk as edipartnerfk,
                                                      edi.source,
                                                      edi.subdob_mine_value,
                                                      edi.subdob_mine_status,
                                                      ess.edisubscriberdobsearchpk
                                                      from subscriberdoblookup ess
                                                      join pastediresponse edi
                                                       on ess.mock_foundcoverageifk = edi.mock_foundcoverageifk
                                                       and ess.hospitalfk = edi.hospitalfk """
   externallysourcedsubscriberdob_data = spark.sql(prepare_externallysourcedsubscriberdob_data)
   writeparquet(spark,externallysourcedsubscriberdob_data,scratch_path + "/verified_mined_subdob_past_edi_data/",10,"overwrite")


#This function is to get the correct coverage id from a dataframe where format is  <coverage_id>_<groupnumber>

def get_formatted_coverageid_data(spark,df):
    df = df.withColumn("extracted_grpnum",split(col("coverageid"),'-').getItem(1))
    df = df.withColumn("derived_coverageid",when(((col("groupnumber").isNotNull()) & (col("extracted_grpnum") == col("groupnumber"))),split(col("coverageid"),'-').getItem(0)).otherwise(col("coverageid")))
    return df



# COMMAND ----------

edisubscriberdobsearch_col = ["responsesubscriberdob","edisubscriberdobresponsefk","hospitalfk","patientacctifk","foundcoverageifk","subscriberfirstname"]
edisubscriberdobsearch = extract_deltalake_data(spark,hdfs_input + "/edisubscriberdobsearch/current/20991231/",edisubscriberdobsearch_col)
edisubscriberdobsearch = get_clean_data(spark,edisubscriberdobsearch)

edisubscriberdobresponse_col = ["hospitalfk","patientacctifk","edisubscriberdobresponsepk","firstname","groupnumber","coverageid","dob","lastname","edipartnerfk"]
edisubscriberdobresponse = readparquet(spark, hdfs_input + "/edisubscriberdobresponse/current/20991231/","1",edisubscriberdobresponse_col)
edisubscriberdobresponse = get_clean_data(spark,edisubscriberdobresponse)
edisubscriberdobresponse = get_formatted_coverageid_data(spark,edisubscriberdobresponse)

foundcoverage_col = ["hospitalfk","foundcoverageipk","edipartnerfk","groupnumber","coverageid"]
foundcoverage =  extract_deltalake_data(spark, hdfs_input + "/foundcoverage/current/20991231/",foundcoverage_col)
foundcoverage = get_clean_data(spark,foundcoverage)
foundcoverage = get_formatted_coverageid_data(spark,foundcoverage)

subscriberdoblookup = readparquet(spark, scratch_path + "/subscriberdoblookup/", "0","na")
#   get_subdob_edi_responses(spark,edisubscriberdobsearch,edisubscriberdobresponse,subscriberdoblookup,scratch_path)
get_subdob_past_edi_response(spark,edisubscriberdobsearch,edisubscriberdobresponse,subscriberdoblookup,foundcoverage,scratch_path)
