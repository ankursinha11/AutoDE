# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("scratch_path","")
dbutils.widgets.getArgument("scratch_path")
scratch_path= getArgument("scratch_path")

dbutils.widgets.text("ip_lsb_id","")
dbutils.widgets.getArgument("ip_lsb_id")
ip_lsb_id= getArgument("ip_lsb_id")



# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

ip_lsb_id= baseurl+ ip_lsb_id
scratch_path = baseurl + scratch_path + bc +'/'
print(ip_lsb_id)
print(scratch_path)

# COMMAND ----------

def get_lsb_id_from_identity(spark,df_candidatepa,df_lsb_id,scratch_path):
    df_lsb_id = df_lsb_id.dropDuplicates()
    df_candidatepa_permid = df_candidatepa.where(col("permid").isNotNull()).withColumn("permid_formatted", concat(lit("P_"), col("permid")))
    df_candidatepa_permid = df_candidatepa_permid.join(df_lsb_id, df_candidatepa_permid.permid_formatted == df_lsb_id.lookupvalue, 'inner').select(df_candidatepa_permid['*'], df_lsb_id._id).dropDuplicates()
    df_candidatepa_permid = df_candidatepa_permid.withColumn("permid_valid",lit(1))
    writeparquet(spark,df_candidatepa_permid,scratch_path + "/permidxlsbid/",100,"overwrite")

# COMMAND ----------

df_candidatepa = readparquet(spark, scratch_path + "/permid_lookup/*", "0","na")
lsb_id_columns = ["lookupvalue","_id"]
df_lsb_id = readparquet(spark,ip_lsb_id, "1",lsb_id_columns)

get_lsb_id_from_identity(spark,df_candidatepa,df_lsb_id,scratch_path)
