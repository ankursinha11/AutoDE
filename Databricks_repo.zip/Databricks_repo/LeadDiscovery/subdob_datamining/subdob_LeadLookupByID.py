# Databricks notebook source
#LeadLookupByID_1

# COMMAND ----------

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("hdfs_lsb_pax","")
dbutils.widgets.getArgument("hdfs_lsb_pax")
hdfs_lsb_pax= getArgument("hdfs_lsb_pax")

dbutils.widgets.text("hdfs_int_path","")
dbutils.widgets.getArgument("hdfs_int_path")
hdfs_int_path= getArgument("hdfs_int_path")

dbutils.widgets.text("hdfs_leadservicebase_path","")
dbutils.widgets.getArgument("hdfs_leadservicebase_path")
hdfs_leadservicebase_path= getArgument("hdfs_leadservicebase_path")

dbutils.widgets.text("keyname","")
dbutils.widgets.getArgument("keyname")
keyname= getArgument("keyname")

dbutils.widgets.text("keyindex","")
dbutils.widgets.getArgument("keyindex")
keyindex= getArgument("keyindex")

dbutils.widgets.text("store_column_name","")
dbutils.widgets.getArgument("store_column_name")
store_column_name= getArgument("store_column_name")



# COMMAND ----------

# DBTITLE 1,Set Base URL

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

hdfs_lsb_pax = baseurl + hdfs_lsb_pax + bc +'/'+keyname +'xlsbid'
#hdfs_lsb_pax = baseurl + hdfs_lsb_pax +'/'+keyname +'xlsbid'
hdfs_int_path = baseurl + hdfs_int_path + bc+'/'+'permidsubdobmining/'+keyname
hdfs_leadservicebase_path = baseurl + hdfs_leadservicebase_path 
print("hdfs_lsb_pax: ",hdfs_lsb_pax)
print("hdfs_int_path: ",hdfs_int_path)
print("hdfs_leadservicebase_path: ",hdfs_leadservicebase_path)

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
import pyspark.sql.functions as f

def get_hospital(json_obj,col,getCol):
    try:
        out = []
        out = json_obj[col][getCol].split('|')
        return out
    except:
        pass
    finally:
        return out

def get_string(json_obj,col,getCol):
    try:
        out = ''
        out = str(json_obj[col][getCol])
        return out 
    except:
        pass
    finally:
        return out

# COMMAND ----------

get_hospital_udf = spark.udf.register("get_hospital_udf",get_hospital,ArrayType(StringType()))
get_string_udf = spark.udf.register("get_string_udf",get_string,StringType())

hdfs_input = hdfs_lsb_pax
hdfs_int_path = hdfs_int_path
hdfs_store_path = hdfs_leadservicebase_path
keyname = keyname
keyindex = keyindex
store_column_name = store_column_name
num_partition = 2000
output_partition = 1


#int_df =spark.read.parquet(hdfs_store_path)#.repartition(num_partition)
int_df =spark.read.format('delta').load(hdfs_store_path)
# int_df = int_df.where("_id=='G_20394884_82_3J65F46GR58'").cache()
# _id = 'G_20394884_82_3J65F46GR58'
int_df1 = int_df.select(f.split("hcsystemfk_source",'[|]').alias('tmp'),"*").withColumn("tmp",f.explode("tmp")).select(get_hospital_udf(col("demographics"),col("tmp"),f.lit("hospitalfk")).alias('demolsthospitals'),get_hospital_udf(col("demographics"),col("tmp"),f.lit("leadsource")).alias('leadsource'),
get_hospital_udf(col("demographics"),col("tmp"),f.lit("xrefsource")).alias('xrefsource'),f.split("tmp",'[_]')[0].alias("hcsystemfk"),f.split("tmp",'[_]')[1].alias("demosource"),"leadid","*").withColumn("edipartnerfk",f.expr("substring(leadid,1,locate('_',leadid)-1)")).withColumn("coverageid",f.expr("substring(leadid,locate('_',leadid)+1,len(leadid))"))
int_df1 = int_df1.select( 
                         f.col("edipartnerfk").alias("lsb_edipartnerfk"),
                         f.col("coverageid").alias("lsb_coverageid"),
                         f.col("hcsystemfk").alias("lsb_hcsystemfk"),
                         f.col("demosource").alias("lsb_source"),
                         f.col("_id").alias("lsb_id"),
                         f.col("leadcreatedate").alias("lsb_leadcreatedate"),
                         f.col("leadupdatedate").alias("lsb_leadupdatedate"),
                         f.col("identity").alias("lsb_identity"),
                         f.col("demolsthospitals").alias("lsb_hospitalfklst"),
                         f.col("leadsource").alias("lsb_leadsource"),
                         f.col("xrefsource").alias("lsb_xrefsource"),
get_string_udf(col("demographics"),col("tmp"),f.lit("firstname")).alias('lsb_firstname'),
get_string_udf(col("demographics"),col("tmp"),f.lit("middlename")).alias('lsb_middlename'),
get_string_udf(col("demographics"),col("tmp"),f.lit("lastname")).alias('lsb_lastname'),
get_string_udf(col("demographics"),col("tmp"),f.lit("gender")).alias('lsb_gender'),
get_string_udf(col("demographics"),col("tmp"),f.lit("dob")).alias('lsb_dob'),
get_string_udf(col("demographics"),col("tmp"),f.lit("ssn")).alias('lsb_ssn'),
get_string_udf(col("demographics"),col("tmp"),f.lit("state")).alias('lsb_state'),
get_string_udf(col("demographics"),col("tmp"),f.lit("updatedate")).alias('lsb_demoupdatedate'))

cpa1 = spark.read.parquet(hdfs_input)
#cpa1 = spark.read.parquet(hdfs_input).where("_id=='G_20394884_82_3J65F46GR58'")
cpa2 = cpa1.repartition(num_partition)
df3 = cpa2.join(int_df1,on=cpa2["_id"]==int_df1["lsb_id"],how='inner')
df4 = df3.withColumn("keyname", lit(keyname))
df4.write.mode("overwrite").parquet(hdfs_int_path)
