# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("scratch_path","")
dbutils.widgets.getArgument("scratch_path")
scratch_path= getArgument("scratch_path")

dbutils.widgets.text("hdfs_input","")
dbutils.widgets.getArgument("hdfs_input")
hdfs_input= getArgument("hdfs_input")

dbutils.widgets.text("permid_path","")
dbutils.widgets.getArgument("permid_path")
permid_path= getArgument("permid_path")


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.functions import udf
from pyspark.sql import types as T

# COMMAND ----------

hdfs_input = baseurl + hdfs_input
permid_path = baseurl + permid_path
scratch_path = baseurl+scratch_path + bc + '/'
print(hdfs_input)
print(permid_path)
print(scratch_path)

# COMMAND ----------

def get_fc_data(spark,foundcoverage,scratch_path):
    foundcoverage = foundcoverage.filter(col("dob").isNotNull())     
    foundcoverage = foundcoverage.filter(col("hitstatus").isin("1","2"))
    foundcoverage = foundcoverage.filter(col("currentinferredsourcemethodcode").isin('RE', 'IE', 'FE', 'FI','CM','CG','FG','FJ', 'HG'))
    writeparquet(spark,foundcoverage,scratch_path + "/foundcoverage_lookup/",1000,"overwrite")
    

#This function is to clean patientacctsguarantors data with bad and invalid dob
def get_formatted_patientacctsguarantors_data(spark,df):
    df = df.filter(col("guardob").isNotNull())
    df = df.filter(col("guardob").cast("timestamp") > "1900-01-01 00:00:00.000000")
    return df



#Finding sub dob using family and founcoverage

def get_subdob_family_foundcoverage_data(spark,foundcoverage,subscriberdoblookup,familymembers,scratch_path):
    familymembers.createOrReplaceTempView("familymembers")
    foundcoverage.createOrReplaceTempView("foundcoverage")
    subscriberdoblookup.createOrReplaceTempView("subscriberdoblookup")
    lookup_subdob_familymemebers_foundcoverage_pquery = """select 
                                             ess.mock_foundcoverageifk,
                                             ess.patientacctifk,
                                             ess.hospitalfk, 
                                             max(fc.dob) subscriberdob, 
                                             max(fc.foundcoverageipk) srcfoundcoverageipk
                                             from subscriberdoblookup ess
                                             join foundcoverage fctemp 
                                                   on ess.hospitalfk <=> fctemp.hospitalfk
                                                   and ess.foundcoverageifk <=> fctemp.foundcoverageipk
                                             join familymembers fm 
                                                   on ess.hospitalfk <=> fm.hospitalfk and ess.patientacctifk <=> fm.patientacctifk
                                             join foundcoverage fc 
					                                   on fm.memberhospitalfk <=> fc.hospitalfk 
                                                   and fm.memberpatientacctifk <=> fc.patientacctifk
                                                   and fctemp.edipartnerfk <=> fc.edipartnerfk
                                             where 	
                                                 fc.firstname <=> ess.firstname
                                                 and fc.lastname <=> ess.lastname
                                             group by ess.mock_foundcoverageifk,ess.hospitalfk,ess.patientacctifk
                                             having count(distinct fc.dob) = 1"""	
    lookup_subdob_family_foundcoverage_data= spark.sql(lookup_subdob_familymemebers_foundcoverage_pquery)
    writeparquet(spark,lookup_subdob_family_foundcoverage_data,scratch_path + "/lookup_subdob_family_foundcoverage_data_stage/",10,"overwrite")
    lookup_subdob_family_foundcoverage_data_stage = readparquet(spark, scratch_path + "/lookup_subdob_family_foundcoverage_data_stage/", "0","na")
    lookup_subdob_family_foundcoverage_data_stage.createOrReplaceTempView("lookup_subdob_family_foundcoverage_data_stage")
    #joining back to familymembers to get memberhospitalfk
    lookup_subdob_family_foundcoverage_data_stage_query = """SELECT lkp.mock_foundcoverageifk,
                                             lkp.hospitalfk,
                                             fm.memberhospitalfk,
                                             max(subscriberdob) subscriberdob, 
                                             max(srcfoundcoverageipk) srcfoundcoverageipk
                                             from lookup_subdob_family_foundcoverage_data_stage lkp
                                             join familymembers fm 
                                             on lkp.hospitalfk <=> fm.hospitalfk and lkp.patientacctifk <=> fm.patientacctifk
                                             group by lkp.mock_foundcoverageifk,fm.memberhospitalfk,lkp.hospitalfk"""
    lookup_subdob_family_foundcoverage_data_stage_temp = spark.sql(lookup_subdob_family_foundcoverage_data_stage_query)
    lookup_subdob_family_foundcoverage_data_stage_temp = lookup_subdob_family_foundcoverage_data_stage_temp.withColumn("source",lit("family-foundcoverage-data"))
    lookup_subdob_family_foundcoverage_data_stage_temp = lookup_subdob_family_foundcoverage_data_stage_temp.withColumn("subdob_mine_value",lit(6))
    lookup_subdob_family_foundcoverage_data_stage_memberhospitalfk = lookup_subdob_family_foundcoverage_data_stage_temp.withColumn("subdob_mine_status",lit("verified"))
    lookup_subdob_family_foundcoverage_data_stage_memberhospitalfk.createOrReplaceTempView("familymemberfoundcoverage")
    prepare_externallysourcedsubscriberdob_data = """ select
                                                      ess.hospitalfk,
                                                      ess.patientacctifk,
                                                      ess.subscriberdoblookuppk,
                                                      cast(fmfc.subscriberdob as string) as dob,
                                                      ess.foundcoverageifk,
                                                      ess.foundcoverageentityifk,
                                                      '' as edisubscriberdobresponsefk,
                                                      '' as sourcepatienthospitalfk,
                                                      '' as sourcepatientacctifk,
		                                      cast(fc.hospitalfk as string) as sourcefoundcoveragehospitalfk,
			                              cast(fc.foundcoverageipk as string) as  sourcefoundcoverageifk, 
                                                      ess.edipartnerfk as edipartnerfk,
                                                      fmfc.source,
                                                      fmfc.subdob_mine_value,
                                                      fmfc.subdob_mine_status,
                                                      ess.edisubscriberdobsearchpk
                                                      from subscriberdoblookup ess
                                                      join familymemberfoundcoverage  fmfc  
                                                           on ess.mock_foundcoverageifk <=> fmfc.mock_foundcoverageifk
                                                           and ess.hospitalfk <=> fmfc.hospitalfk
                                                      join foundcoverage fc  
                                                           on fmfc.srcfoundcoverageipk <=> fc.foundcoverageipk
                                                           and fmfc.memberhospitalfk <=> fc.hospitalfk """
    externallysourcedsubscriberdob_data = spark.sql(prepare_externallysourcedsubscriberdob_data)
    writeparquet(spark,externallysourcedsubscriberdob_data,scratch_path + "/verified_mined_subdob_family_foundcoverage_data/",10,"overwrite")


#Finding the sub dob using patientaccts of familymembers 

def get_subdob_family_patientaccts_data(spark,subscriberdoblookup,patientaccts,familymembers,scratch_path,hospitals):
    hosprdd = hospitals.select(col("hospitalpk"),col("hcsystemfk")).rdd
    hospkeypair_rdd = hosprdd.map(lambda x : (x[0],x[1]))
    hosp_dict = hospkeypair_rdd.collectAsMap() # creating dict of hosp --> hcsystem
    @udf(T.StringType())
    def get_hcsystem(hospital):
        return hosp_dict.get(str(hospital))
    patientaccts = patientaccts.filter(col("dob").isNotNull())
    patientaccts = patientaccts.withColumn("hcsystemfk",get_hcsystem(col("hospitalfk")))
    subscriberdoblookup.createOrReplaceTempView("subscriberdoblookup")
    patientaccts.createOrReplaceTempView("patientaccts")
    familymembers.createOrReplaceTempView("familymembers")
    lookup_subdob_familymemebers_patientaccts_pquery = """select 
                                                          ess.mock_foundcoverageifk,
                                                          ess.patientacctifk,
                                                          ess.hospitalfk, 
                                                          max(pa.dob) subscriberdob, 
                                                          max(pa.patientacctipk) patientacctipk
			                                  from subscriberdoblookup ess
			                                  join familymembers fm 
			                                       on ess.hospitalfk <=> fm.hospitalfk and ess.patientacctifk <=> fm.patientacctifk
			                                  join patientaccts pa 
			                                       on fm.memberhospitalfk <=> pa.hospitalfk and fm.memberpatientacctifk <=> pa.patientacctipk
			                                  where pa.firstname <=> ess.firstname and pa.lastname <=> ess.lastname and pa.hcsystemfk <=> ess.hcsystemfk
		  	                                  group by ess.mock_foundcoverageifk,ess.hospitalfk,ess.patientacctifk
			                                           having count(distinct pa.dob) = 1 """
    lookup_subdob_family_patientaccts_data = spark.sql(lookup_subdob_familymemebers_patientaccts_pquery)
    lookup_subdob_family_patientaccts_data.createOrReplaceTempView("lookup_subdob_family_patientaccts_data_temp")
    #joining back to familymembers to get memberhospitalfk
    lookup_subdob_family_patientaccts_data_stage_query = """SELECT lkp.mock_foundcoverageifk,
                                             lkp.hospitalfk,
                                             fm.memberhospitalfk,
                                             max(subscriberdob) subscriberdob, 
                                             max(patientacctipk) patientacctipk
                                             from lookup_subdob_family_patientaccts_data_temp lkp
                                             join familymembers fm 
                                             on lkp.hospitalfk <=> fm.hospitalfk and lkp.patientacctifk <=> fm.patientacctifk
                                             group by lkp.mock_foundcoverageifk,fm.memberhospitalfk,lkp.hospitalfk"""
    lookup_subdob_family_patientaccts_data_mem_hosp = spark.sql(lookup_subdob_family_patientaccts_data_stage_query)

    lookup_subdob_family_patientaccts_data_mem_hosp = lookup_subdob_family_patientaccts_data_mem_hosp.withColumn("source",lit("family-patientaccts-data"))
    lookup_subdob_family_patientaccts_data_mem_hosp = lookup_subdob_family_patientaccts_data_mem_hosp.withColumn("subdob_mine_value",lit(7))
    lookup_subdob_family_patientaccts_data_mem_hosp = lookup_subdob_family_patientaccts_data_mem_hosp.withColumn("subdob_mine_status",lit("verified"))
    lookup_subdob_family_patientaccts_data_mem_hosp.createOrReplaceTempView("familymemberpatientacct")
    prepare_externallysourcedsubscriberdob_data = """ select
                                                      ess.hospitalfk,
                                                      ess.patientacctifk,
                                                      ess.subscriberdoblookuppk,
                                                      cast(fmpa.subscriberdob as string) as dob,
                                                      ess.foundcoverageifk,
                                                      ess.foundcoverageentityifk,
                                                      '' as edisubscriberdobresponsefk,
                                                      cast(pa.hospitalfk as string) as sourcepatienthospitalfk,
                                                      cast(pa.patientacctipk as string) as sourcepatientacctifk,
                                                      '' as sourcefoundcoveragehospitalfk,
                                                      '' as sourcefoundcoverageifk,
                                                      ess.edipartnerfk as edipartnerfk,
                                                      fmpa.source,
                                                      fmpa.subdob_mine_value,
                                                      fmpa.subdob_mine_status,
                                                      ess.edisubscriberdobsearchpk
                                                      from subscriberdoblookup ess
                                                      join familymemberpatientacct  fmpa
                                                           on ess.mock_foundcoverageifk <=> fmpa.mock_foundcoverageifk
                                                           and ess.hospitalfk <=> fmpa.hospitalfk
                                                      join patientaccts pa
                                                           on fmpa.patientacctipk <=> pa.patientacctipk
                                                           and fmpa.memberhospitalfk <=> pa.hospitalfk  """
 
    externallysourcedsubscriberdob_data = spark.sql(prepare_externallysourcedsubscriberdob_data)
    writeparquet(spark,externallysourcedsubscriberdob_data,scratch_path + "/verified_mined_subdob_family_patientaccts_data/",10,"overwrite")

#finding the sub dob using patientacctsguarantors of familymembers

def get_subdob_family_patientacctsguarantors_data(spark,subscriberdoblookup,patientaccts,patientacctsguarantors,familymembers,scratch_path):
    subscriberdoblookup.createOrReplaceTempView("subscriberdoblookup")
    patientaccts.createOrReplaceTempView("patientaccts")
    familymembers.createOrReplaceTempView("familymembers")
    patientacctsguarantors.createOrReplaceTempView("patientacctsguarantors")
    lookup_subdob_familymemebers_patientacctsguarantors_pquery = """ select 
                                                                     ess.mock_foundcoverageifk,
                                                                     ess.hospitalfk,
                                                                     ess.patientacctifk, 
                                                                     max(pag.guardob) subscriberdob, 
                                                                     max(pa.patientacctipk) patientacctipk
                                                                     from subscriberdoblookup ess
                                                                     join familymembers fm 
                                                                       on ess.hospitalfk <=> fm.hospitalfk and ess.patientacctifk <=> fm.patientacctifk
                                                                     join patientaccts pa
                                                                       on fm.memberhospitalfk <=> pa.hospitalfk and fm.memberpatientacctifk <=> pa.patientacctipk
                                                                     join patientacctsguarantors pag		
                                                                       on pa.hospitalfk <=> pag.hospitalfk and pa.patientacctipk <=> pag.patientacctifk
                                                                     where
                                                                       pag.guarfirstname <=> ess.firstname
                                                                       and pag.guarlastname <=> ess.lastname
                                                                     group by ess.mock_foundcoverageifk,ess.hospitalfk,ess.patientacctifk
                                                                              having count(distinct pag.guardob) = 1"""
    lookup_subdob_family_patientacctsguarantors_data_staging = spark.sql(lookup_subdob_familymemebers_patientacctsguarantors_pquery)
    lookup_subdob_family_patientacctsguarantors_data_staging.createOrReplaceTempView("lookup_subdob_family_patientacctsguarantors_data_temp")
    #joining back to familymembers to get memberhospitalfk
    lookup_subdob_family_patientacctsguarantors_data_stage_query = """SELECT lkp.mock_foundcoverageifk,
                                             lkp.hospitalfk,
                                             fm.memberhospitalfk,
                                             max(subscriberdob) subscriberdob, 
                                             max(patientacctipk) patientacctipk
                                             from lookup_subdob_family_patientacctsguarantors_data_temp lkp
                                             join familymembers fm 
                                             on lkp.hospitalfk <=> fm.hospitalfk and lkp.patientacctifk <=> fm.patientacctifk
                                             group by lkp.mock_foundcoverageifk,fm.memberhospitalfk,lkp.hospitalfk"""
    lookup_subdob_family_patientacctsguarantors_data = spark.sql(lookup_subdob_family_patientacctsguarantors_data_stage_query)
                                                             
    lookup_subdob_family_patientacctsguarantors_data = lookup_subdob_family_patientacctsguarantors_data.withColumn("source",lit("family-patientacctsguarantors-data"))
    lookup_subdob_family_patientacctsguarantors_data = lookup_subdob_family_patientacctsguarantors_data.withColumn("subdob_mine_value",lit(8))
    lookup_subdob_family_patientacctsguarantors_data = lookup_subdob_family_patientacctsguarantors_data.withColumn("subdob_mine_status",lit("verified"))
    lookup_subdob_family_patientacctsguarantors_data.createOrReplaceTempView("familymemberpatientacctguarantor")
    prepare_externallysourcedsubscriberdob_data = """ select
                                                      ess.hospitalfk,
                                                      ess.patientacctifk,
                                                      ess.subscriberdoblookuppk,
                                                      cast(fmpa.subscriberdob as string) as dob,
                                                      ess.foundcoverageifk,
                                                      ess.foundcoverageentityifk,
                                                      '' as edisubscriberdobresponsefk,
                                                      cast(pa.hospitalfk as string) as sourcepatienthospitalfk,
                                                      cast(pa.patientacctipk as string) as sourcepatientacctifk,
                                                      '' as sourcefoundcoveragehospitalfk,
                                                      '' as sourcefoundcoverageifk,
                                                      ess.edipartnerfk as edipartnerfk,
                                                      fmpa.source,
                                                      fmpa.subdob_mine_value,
                                                      fmpa.subdob_mine_status,
                                                      ess.edisubscriberdobsearchpk
                                                      from subscriberdoblookup ess
                                                      join familymemberpatientacctguarantor  fmpa
                                                           on ess.mock_foundcoverageifk <=> fmpa.mock_foundcoverageifk
                                                           and ess.hospitalfk <=> fmpa.hospitalfk
                                                      join patientaccts pa
                                                           on fmpa.patientacctipk <=> pa.patientacctipk
                                                           and fmpa.memberhospitalfk <=> pa.hospitalfk """
    externallysourcedsubscriberdob_data = spark.sql(prepare_externallysourcedsubscriberdob_data)
    writeparquet(spark,externallysourcedsubscriberdob_data,scratch_path + "/verified_mined_subdob_family_patientacctsguarantors_data/",10,"overwrite")


# COMMAND ----------

patientacctsguarantors_col = ["hospitalfk","patientacctifk","guardob","guarfirstname","guarlastname"]
patientacctsguarantors =  extract_deltalake_data(spark, hdfs_input + "/patientacctsguarantors/current/20991231/",patientacctsguarantors_col)
patientacctsguarantors = get_clean_data(spark,patientacctsguarantors)
patientacctsguarantors = get_formatted_patientacctsguarantors_data(spark,patientacctsguarantors)

patientaccts_col = ["hospitalfk","patientacctipk","dob","firstname","lastname"]
patientaccts = extract_deltalake_data(spark,hdfs_input + "/patientaccts/current/20991231/",patientaccts_col)
patientaccts = get_clean_data(spark,patientaccts)

subscriberdoblookup = readparquet(spark, scratch_path + "/subscriberdoblookup/", "0","na")
hospitals_col =  ["hospitalpk","hcsystemfk"]
hospitals = readparquet(spark,hdfs_input + "/hospitals/current/20991231/","1",hospitals_col)

familymembers = readparquet(spark, scratch_path + "/familymembers_lookup_data/", "0","na")
familymembers = get_clean_data(spark,familymembers)

foundcoverage_col = ["dob","foundcoverageipk","hospitalfk","edipartnerfk","hitstatus","currentinferredsourcemethodcode","firstname","lastname","patientacctifk"]
foundcoverage = extract_deltalake_data(spark,hdfs_input + "/foundcoverage/current/20991231/",foundcoverage_col)
foundcoverage = get_clean_data(spark,foundcoverage)
foundcoverage = get_fc_data(spark,foundcoverage,scratch_path)
foundcoverage_filtered = readparquet(spark, scratch_path + "/foundcoverage_lookup/", "0","na")

get_subdob_family_foundcoverage_data(spark,foundcoverage_filtered,subscriberdoblookup,familymembers,scratch_path)
get_subdob_family_patientaccts_data(spark,subscriberdoblookup,patientaccts,familymembers,scratch_path,hospitals)
get_subdob_family_patientacctsguarantors_data(spark,subscriberdoblookup,patientaccts,patientacctsguarantors,familymembers,scratch_path)
