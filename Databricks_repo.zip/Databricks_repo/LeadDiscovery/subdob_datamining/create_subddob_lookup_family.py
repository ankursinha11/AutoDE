# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("scratch_path","")
dbutils.widgets.getArgument("scratch_path")
scratch_path= getArgument("scratch_path")

dbutils.widgets.text("hdfs_input","")
dbutils.widgets.getArgument("hdfs_input")
hdfs_input= getArgument("hdfs_input")


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

scratch_path = baseurl+scratch_path + bc + '/'
print(scratch_path)

# COMMAND ----------

def get_subdob_lookup_family(spark,subscriberdoblookup,tusourcedfamilymemberlink,scratch_path):
    tusourcedfamilymemberlink.createOrReplaceTempView("tusourcedfamilymemberlink")
    subscriberdoblookup.createOrReplaceTempView("subscriberdoblookup")
    vw_familymembers_pquery1 = """ select patientacctifk1 patientacctifk,
                                      hospitalfk1 hospitalfk,
                                      patientacctifk2 memberpatientacctifk,
                                      hospitalfk2 memberhospitalfk
                               from tusourcedfamilymemberlink """
    vw_familymembers1 = spark.sql(vw_familymembers_pquery1)
    writeparquet(spark,vw_familymembers1,scratch_path + "/familymembers_data/",200,"overwrite")
    vw_familymembers_pquery2=  """ select patientacctifk2 patientacctifk,
                                      hospitalfk2 hospitalfk,
                                      patientacctifk1 memberpatientacctifk,
                                      hospitalfk1 memberhospitalfk
                               from tusourcedfamilymemberlink """
    vw_familymembers2 = spark.sql(vw_familymembers_pquery2)
    writeparquet(spark,vw_familymembers2,scratch_path + "/familymembers_data/",200,"append")
    vwfamilymembers = readparquet(spark, scratch_path + "/familymembers_data/", "0","na")
    vwfamilymembers.createOrReplaceTempView("vwfamilymembers")
    familymembers_pquery = """ select ess.hospitalfk, 
                                      ess.patientacctifk, 
                                      fm.memberhospitalfk, 
                                      fm.memberpatientacctifk
                               from subscriberdoblookup ess
                               join vwfamilymembers fm
                                on ess.hospitalfk <=> fm.hospitalfk 
                                and ess.patientacctifk <=> fm.patientacctifk  """
    familymembers = spark.sql(familymembers_pquery) 
    writeparquet(spark,familymembers,scratch_path + "/familymembers_lookup_data/",10,"overwrite")
     


# COMMAND ----------

subscriberdoblookup = readparquet(spark, scratch_path + "/subscriberdoblookup/", "0","na")
tusourcedfamilymemberlink =  extract_deltalake_data(spark, f"{baseurl}/data/cdd/publish/tu/tusourcedfamilymemberlink/current/20991231/")
tusourcedfamilymemberlink = get_clean_data(spark,tusourcedfamilymemberlink)
get_subdob_lookup_family(spark,subscriberdoblookup,tusourcedfamilymemberlink,scratch_path)
