# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("scratch_path","")
dbutils.widgets.getArgument("scratch_path")
scratch_path= getArgument("scratch_path")

dbutils.widgets.text("hdfs_input","")
dbutils.widgets.getArgument("hdfs_input")
hdfs_input= getArgument("hdfs_input")



# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/schema_util

# COMMAND ----------

hdfs_input = baseurl + hdfs_input
scratch_path = baseurl+scratch_path + bc + '/'
print(hdfs_input)
print(scratch_path)

# COMMAND ----------

#all the verified subdob 

def get_all_verified_subdob(spark,all_verified_subdob,scratch_path):
    all_verified_subdob.createOrReplaceTempView("all_verified_subdob")
    distinct_min_mine_value_pa_pquery  = """ select 
                                             distinct patientacctifk,min(subdob_mine_value) as min_subdob_mine_value,
                                             hospitalfk
                                             from all_verified_subdob 
                                             group by patientacctifk, hospitalfk """ 
    distinct_min_mine_value_pa = spark.sql(distinct_min_mine_value_pa_pquery)
    distinct_min_mine_value_pa.createOrReplaceTempView("distinct_min_mine_value_pa")
    
    deduped_subdob_verified_pquery = """ select avs.*
                                         from all_verified_subdob avs 
                                         join distinct_min_mine_value_pa dmmva 
                                         on  (avs.patientacctifk = dmmva.patientacctifk)
                                         and (avs.hospitalfk = dmmva.hospitalfk)
                                         and (avs.subdob_mine_value = dmmva.min_subdob_mine_value) """
    deduped_subdob_verified = spark.sql(deduped_subdob_verified_pquery)
    writeparquet(spark,deduped_subdob_verified,scratch_path + "/deduped_subdob_verified/",10,"overwrite") 


#all the unverified subdob


def get_all_unverified_subdob(spark,deduped_verified_subdob,scratch_path,all_unverified_subdob):
    deduped_verified_subdob.createOrReplaceTempView("deduped_verified_subdob")
    all_unverified_subdob.createOrReplaceTempView("all_unverified_subdob")
    deduped_verified_subdob_extract_pquery = """ select
                                                 distinct patientacctifk,
                                                 hospitalfk
                                                 from all_verified_subdob
                                                 group by patientacctifk,hospitalfk """   
    deduped_verified_subdob_extract = spark.sql(deduped_verified_subdob_extract_pquery)
    deduped_verified_subdob_extract.createOrReplaceTempView("deduped_verified_subdob_extract")
    deduped_unverified_subdob_pquery = """ select aus.*
                                                  from all_unverified_subdob aus
                                                  left anti join deduped_verified_subdob_extract dvse
                                                  on (aus.patientacctifk = dvse.patientacctifk and aus.hospitalfk = dvse.hospitalfk) """ 
    deduped_unverified_subdob = spark.sql(deduped_unverified_subdob_pquery)
    writeparquet(spark,deduped_unverified_subdob,scratch_path + "/deduped_subdob_unverified/",10,"overwrite") 
 

# COMMAND ----------

subscriberdoblookup = readparquet(spark, scratch_path + "/subscriberdoblookup/", "0","na")
all_verified_subdob = readparquet(spark, scratch_path + "/verified_mined*/*", "0","na") 
all_unverified_subdob = readparquet(spark, scratch_path + "/unverified_mined*/*", "0","na") 
get_all_verified_subdob(spark,all_verified_subdob,scratch_path) 
deduped_verified_subdob = readparquet(spark, scratch_path + "/deduped_subdob_verified/*", "0","na")
get_all_unverified_subdob(spark,deduped_verified_subdob,scratch_path,all_unverified_subdob)
