# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("scratch_path","")
dbutils.widgets.getArgument("scratch_path")
scratch_path= getArgument("scratch_path")

dbutils.widgets.text("sqoop_op_path","")
dbutils.widgets.getArgument("sqoop_op_path")
sqoop_op_path= getArgument("sqoop_op_path")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from datetime import *

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

scratch_path = baseurl + scratch_path +bc
sqoop_path = baseurl + sqoop_op_path +bc
print(scratch_path)
print(sqoop_path)

# COMMAND ----------

# create o/p for sqoop to edisubscriberdobsearch

def create_sqoopdata_edisubscriberdobsearch(spark,deduped_subdob_verified,deduped_subdob_unverified,subscriberdoblookup,sqoop_path,bc):
    d = datetime.date.today()
    curr_date = d.strftime('%Y-%m-%d %H:%M:%S')
    bcdate = bc
    subscriberdoblookup = subscriberdoblookup.withColumn("bc",lit("bcdate"))
    subscriberdoblookup.createOrReplaceTempView("subscriberdoblookup")
    deduped_subdob_unverified.createOrReplaceTempView("deduped_subdob_unverified")
    deduped_subdob_verified.createOrReplaceTempView("deduped_subdob_verified")
    prepare_sqoop_data_verified_pquery = """ select distinct sdl.edisubscriberdobsearchpk,
                                                    sdl.hospitalfk,
                                                    sdl.patientacctifk,
                                                    sdl.foundcoverageifk,
                                                    sdl.edipartnerfk,
                                                    sdl.firstname,
                                                    sdl.lastname,
                                                    sdl.subscribermiddlename,
                                                    sdl.subscribersuffix,
                                                    dsv.dob as subscriberdob,
                                                    sdl.subscriberssn,
                                                    sdl.subscriberdoblookuppk,
                                                    sdl.responsesubscriberdob,
                                                    sdl.edisubscriberdobresponsefk,
                                                    sdl.processflag,
                                                    sdl.coverageid,
                                                    sdl.createdate,
                                                    sdl.updatedate,
                                                    sdl.bc,
                                                    dsv.dob as subdob,
                                                    dsv.source,
                                                    case when dsv.subdob_mine_status == "unverified" then "NV"
                                                         when  dsv.subdob_mine_status == "verified" then "VI"
                                                         else "NF" end as status
                                                    from subscriberdoblookup sdl
                                                    join deduped_subdob_verified dsv
                                                    on (sdl.patientacctifk = dsv.patientacctifk and sdl.hospitalfk = dsv.hospitalfk) 
                                                    """ 
    sqoop_data_verified = spark.sql(prepare_sqoop_data_verified_pquery)
    sqoop_data_verified = sqoop_data_verified.drop(col("foundcoverageentityifk"))
    sqoop_data_verified = sqoop_data_verified.withColumn("subscriberdob",date_format(col("subscriberdob"),"yyyy-MM-dd HH:mm:ss"))
    sqoop_data_verified = sqoop_data_verified.withColumn("responsesubscriberdob",date_format(col("responsesubscriberdob"),"yyyy-MM-dd HH:mm:ss"))
    sqoop_data_verified = sqoop_data_verified.filter((col("subscriberdob") > '1900-01-01 00:00:00') & ((col("subscriberdob") < curr_date)))
    #sqoop_data_verified = sqoop_data_verified.filter(col("responsesubscriberdob") > '1900-01-01 00:00:00')
   
    sqoop_data_verified = sqoop_data_verified.withColumn("bc",lit(bcdate))
    prepare_sqoop_data_unverified_pquery = """ select distinct sdl.edisubscriberdobsearchpk,
                                                    sdl.hospitalfk,
                                                    sdl.patientacctifk,
                                                    sdl.foundcoverageifk,
                                                    sdl.edipartnerfk,
                                                    sdl.firstname,
                                                    sdl.lastname,
                                                    sdl.subscribermiddlename,
                                                    sdl.subscribersuffix,
                                                    dsu.dob as subscriberdob,
                                                    sdl.subscriberssn,
                                                    sdl.subscriberdoblookuppk,
                                                    sdl.responsesubscriberdob,
                                                    sdl.edisubscriberdobresponsefk,
                                                    sdl.processflag,
                                                    sdl.coverageid,
                                                    sdl.createdate,
                                                    sdl.updatedate,
                                                    sdl.bc,
                                                    dsu.dob as subdob,
                                                    dsu.source,
                                                    case when dsu.subdob_mine_status == "unverified" then "NV"
                                                         when dsu.subdob_mine_status == "verified" then "VI"
                                                         else "NF" end as status
                                                    from subscriberdoblookup sdl
                                                    join deduped_subdob_unverified dsu
                                                    on (sdl.patientacctifk = dsu.patientacctifk and sdl.hospitalfk = dsu.hospitalfk) 
                                                    """
    sqoop_data_unverified = spark.sql(prepare_sqoop_data_unverified_pquery)
    sqoop_data_unverified = sqoop_data_unverified.drop(col("foundcoverageentityifk"))
    sqoop_data_unverified = sqoop_data_unverified.withColumn("subscriberdob",date_format(col("subscriberdob"),"yyyy-MM-dd HH:mm:ss"))
    sqoop_data_unverified = sqoop_data_unverified.withColumn("responsesubscriberdob",date_format(col("responsesubscriberdob"),"yyyy-MM-dd HH:mm:ss"))
    sqoop_data_unverified = sqoop_data_unverified.filter((col("subscriberdob") > '1900-01-01 00:00:00') & ((col("subscriberdob") < curr_date)))
    
    #sqoop_data_unverified = sqoop_data_unverified.filter(col("responsesubscriberdob") > '1900-01-01 00:00:00')
    
    sqoop_data_unverified = sqoop_data_unverified.withColumn("bc",lit(bcdate))
    writecsv(spark,sqoop_data_verified,sqoop_path + "/edisubscriberdobsearch_holding" ,1,"overwrite","\x01")
    writecsv(spark,sqoop_data_unverified,sqoop_path + "/edisubscriberdobsearch_holding" ,1,"append","\x01")
    bclist = [bcdate]
    batch = spark.createDataFrame(bclist, StringType())
    writecsv(spark,batch,sqoop_path + "/edisubscriberdobsearch_batch",1,"overwrite","\x01")


# COMMAND ----------

subscriberdoblookup = readparquet(spark, scratch_path + "/subscriberdoblookup/", "0","na") 
deduped_subdob_unverified = readparquet(spark, scratch_path + "/deduped_subdob_unverified/", "0","na")
deduped_subdob_verified = readparquet(spark, scratch_path + "/deduped_subdob_verified/", "0","na")
create_sqoopdata_edisubscriberdobsearch(spark,deduped_subdob_verified,deduped_subdob_unverified,subscriberdoblookup,sqoop_path,bc)
