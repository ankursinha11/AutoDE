# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("scratch_path","")
dbutils.widgets.getArgument("scratch_path")
scratch_path= getArgument("scratch_path")

dbutils.widgets.text("hdfs_input","")
dbutils.widgets.getArgument("hdfs_input")
hdfs_input= getArgument("hdfs_input")

dbutils.widgets.text("permid_path","")
dbutils.widgets.getArgument("permid_path")
permid_path= getArgument("permid_path")

dbutils.widgets.text("gmrn_publish_path","")
dbutils.widgets.getArgument("gmrn_publish_path")
gmrn_publish_path= getArgument("gmrn_publish_path")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------


from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql import types as T

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

hdfs_input = baseurl + hdfs_input
gmrn_publish_path = baseurl + gmrn_publish_path
permid_path = baseurl + permid_path
scratch_path = baseurl+scratch_path + bc + '/'
print(hdfs_input)
print(gmrn_publish_path)
print(permid_path)
print(scratch_path)

# COMMAND ----------

def get_formatted_patientacctsguarantors_data(spark,df):
    df = df.filter(col("guardob").isNotNull())
    df = df.filter(col("guardob").cast("timestamp") > "1900-01-01 00:00:00.000000")
    return df

# this function map hospitalfk with each hcsystemfk

def get_hcsytemfk(spark,hospitals,df):
    hosprdd = hospitals.select(col("hospitalpk"),col("hcsystemfk")).rdd
    hospkeypair_rdd = hosprdd.map(lambda x : (x[0],x[1]))
    hosp_dict = hospkeypair_rdd.collectAsMap() # creating dict of hosp --> hcsystem
    @udf(T.StringType())
    def get_hcsystem(hospital):
        return hosp_dict.get(str(hospital)) 
    df = df.withColumn("hcsystemfk",get_hcsystem(col("hospitalfk")))
    return df


#Finding sub dob using patientacctsguarantors data

def get_subdob_patientacctsguarantors_data(spark,patientacctsguarantors,subscriberdoblookup,scratch_path):
    patientacctsguarantors.createOrReplaceTempView("patientacctsguarantors")
    subscriberdoblookup.createOrReplaceTempView("subscriberdoblookup")
    lookup_subdob_patientacctsguarantors_pquery = """    select 			
                                                         ess.mock_foundcoverageifk,
                                                         ess.hospitalfk,
                                                         max(cast(pag.guardob as timestamp)) as subscriberdob
                                                         from subscriberdoblookup ess
                                                         join    patientacctsguarantors pag
	                                                 on  ess.hospitalfk <=> pag.hospitalfk
			                                     and ess.patientacctifk <=> pag.patientacctifk 
			                                     and pag.guarfirstname <=> ess.firstname
			                                     and pag.guarlastname <=> ess.lastname
                                                         group by ess.mock_foundcoverageifk,ess.hospitalfk
                                                         having count(distinct pag.guardob) = 1 """

    lookup_subdob_patientacctsguarantors_data = spark.sql(lookup_subdob_patientacctsguarantors_pquery)
    lookup_subdob_patientacctsguarantors_data = lookup_subdob_patientacctsguarantors_data.withColumn("source",lit("patientacctsguarantors-data"))
    lookup_subdob_patientacctsguarantors_data = lookup_subdob_patientacctsguarantors_data.withColumn("subdob_mine_value",lit(3))
    lookup_subdob_patientacctsguarantors_data = lookup_subdob_patientacctsguarantors_data.withColumn("subdob_mine_status",lit("verified"))
    lookup_subdob_patientacctsguarantors_data.createOrReplaceTempView("patientguarantor")
    prepare_externallysourcedsubscriberdob_data = """ select
                                                      ess.hospitalfk,
                                                      ess.patientacctifk,
                                                      ess.subscriberdoblookuppk,
                                                      cast(pg.subscriberdob as string) as dob,
                                                      ess.foundcoverageifk,
                                                      ess.foundcoverageentityifk,
                                                      '' as edisubscriberdobresponsefk,
                                                      cast(ess.hospitalfk as string) as sourcepatienthospitalfk,
                                                      cast(ess.patientacctifk as string) as sourcepatientacctifk,
                                                      '' as sourcefoundcoveragehospitalfk,
                                                      '' as sourcefoundcoverageifk,
                                                      ess.edipartnerfk as edipartnerfk,
                                                      pg.source,
                                                      pg.subdob_mine_value,
                                                      pg.subdob_mine_status,
                                                      ess.edisubscriberdobsearchpk
                                                      from subscriberdoblookup ess
                                                      join patientguarantor as pg
                                                       on ess.mock_foundcoverageifk = pg.mock_foundcoverageifk
                                                       and ess.hospitalfk = pg.hospitalfk """ 
    externallysourcedsubscriberdob_data = spark.sql(prepare_externallysourcedsubscriberdob_data)
    writeparquet(spark,externallysourcedsubscriberdob_data,scratch_path + "/verified_mined_subdob_patientacctsguarantors_data/",10,"overwrite")

#Finding the sub dob using patientacctsguarantors and permid 

def get_subdob_patientacctsguarantorsxpermid_data(spark,patientacctsguarantors,subscriberdoblookup,patientacctsxrefpermid,patientaccts,scratch_path):
    patientacctsguarantors.createOrReplaceTempView("patientacctsguarantors")
    subscriberdoblookup.createOrReplaceTempView("subscriberdoblookup")
    patientacctsxrefpermid.createOrReplaceTempView("patientacctsxrefpermid")
    patientaccts.createOrReplaceTempView("patientaccts")
    permid_lookup_pquery = """ select ess.* , 
                                      perm.permid
                                      from subscriberdoblookup ess
                                      join patientacctsxrefpermid perm
	                              on 
	                              ess.patientacctifk <=> perm.patientacctifk 
                                  and ess.hospitalfk <=> perm.hospitalfk 
                                      """
    permid_lookup = spark.sql(permid_lookup_pquery)
    writeparquet(spark,permid_lookup,scratch_path + "/permid_lookup_stage1/",100,"overwrite")
    permid_lookup_stage = readparquet(spark, scratch_path + "/permid_lookup_stage1/", "0","na")
    permid_lookup_stage.createOrReplaceTempView("permid")
    permid_associated_accounts = """ select    
                                      p.* ,
				      pa.hospitalfk as asoc_hospitalfk,
                                      perm.patientacctifk as asoc_patientacctifk
                                      from permid p
                                      join patientacctsxrefpermid perm
                                      on
                                      p.permid <=> perm.permid
		                      join patientaccts pa
                                      on 
                                      pa.patientacctipk <=> perm.patientacctifk and pa.hospitalfk <=> perm.hospitalfk where p.hcsystemfk = pa.hcsystemfk"""
    assoc_permid_stage = spark.sql(permid_associated_accounts)
    writeparquet(spark,assoc_permid_stage,scratch_path + "/assoc_permid_stage/",100,"overwrite")
    assoc_permid = readparquet(spark, scratch_path + "/assoc_permid_stage/", "0","na")
    assoc_permid.createOrReplaceTempView("subscriberdoblookup_extended")
    get_subdob_asoc_permid_pquery = """ select ess.mock_foundcoverageifk,ess.hospitalfk,
                                               max(pag.patientacctifk) sourcepatientacctifk
                                               from subscriberdoblookup_extended ess 
                                               join patientacctsguarantors pag
                                               on  ess.asoc_hospitalfk <=> pag.hospitalfk
                                                   and ess.asoc_patientacctifk <=> pag.patientacctifk
                                                   and pag.guarfirstname <=> ess.firstname
                                                   and pag.guarlastname <=> ess.lastname
                                                   group by ess.mock_foundcoverageifk,ess.hospitalfk
                                                   having count(distinct pag.guardob) = 1 """
    get_subdob_asoc_permid_stage =  spark.sql(get_subdob_asoc_permid_pquery)   
    #Joining back to subscriberdoblookup_extended to get the asoc_hospitalfk
    get_subdob_asoc_permid_stage.createOrReplaceTempView("get_subdob_asoc_permid_stage_tmp")
    get_subdob_asoc_permid_asoc_hosp_query="""select ess.mock_foundcoverageifk,ess.asoc_hospitalfk,ess.hospitalfk as ess_hospitalfk,
                                               max(lkp.sourcepatientacctifk) sourcepatientacctifk
                                               from subscriberdoblookup_extended ess 
                                               join get_subdob_asoc_permid_stage_tmp lkp
                                               on  ess.hospitalfk <=> lkp.hospitalfk
                                                   and ess.asoc_patientacctifk <=> lkp.sourcepatientacctifk
                                                   and ess.mock_foundcoverageifk <=> lkp.mock_foundcoverageifk 
                                                group by ess.mock_foundcoverageifk,ess.asoc_hospitalfk,ess.hospitalfk
                                                   """
    get_subdob_asoc_permid_assoc_hosp=spark.sql(get_subdob_asoc_permid_asoc_hosp_query)
    writeparquet(spark,get_subdob_asoc_permid_assoc_hosp,scratch_path + "/get_subdob_asoc_permid_stage/",100,"overwrite")   
    get_subdob_asoc_permid = readparquet(spark, scratch_path + "/get_subdob_asoc_permid_stage/", "0","na")
    get_subdob_asoc_permid.createOrReplaceTempView("patientguarantor")
    get_lookup_pagxpermid_pquery = """       select pag.mock_foundcoverageifk, 
                                             pag.sourcepatientacctifk,
                                             pag.ess_hospitalfk, 
                                             pa.hospitalfk sourcepatienthospitalfk,
                                             guar.guardob subscriberdob
                                             from patientguarantor pag
                                             join patientaccts pa 
                                             on pag.sourcepatientacctifk <=> pa.patientacctipk
                                             and pag.asoc_hospitalfk <=> pa.hospitalfk
                                             join patientacctsguarantors guar 
                                             on pa.hospitalfk <=> guar.hospitalfk 
                                             and pa.patientacctipk <=> guar.patientacctifk """
    mined_subdob_pagxpermid_data_stage = spark.sql(get_lookup_pagxpermid_pquery)
    writeparquet(spark,mined_subdob_pagxpermid_data_stage,scratch_path + "/mined_subdob_pagxpermid_data_stage/",100,"overwrite")
    mined_subdob_pagxpermid_data = readparquet(spark, scratch_path + "/mined_subdob_pagxpermid_data_stage/", "0","na")
    mined_subdob_pagxpermid_data = mined_subdob_pagxpermid_data.withColumn("source",lit("patientacctsguarantorsxpermid"))
    mined_subdob_pagxpermid_data = mined_subdob_pagxpermid_data.withColumn("subdob_mine_value",lit(4))
    mined_subdob_pagxpermid_data = mined_subdob_pagxpermid_data.withColumn("subdob_mine_status",lit("verified"))
    mined_subdob_pagxpermid_data.createOrReplaceTempView("patientguarantordetails")
    prepare_externallysourcedsubscriberdob_data = """ select
                                                      ess.hospitalfk,
                                                      ess.patientacctifk,
                                                      ess.subscriberdoblookuppk,
                                                      cast(pg.subscriberdob as string) dob,
                                                      ess.foundcoverageifk,
                                                      ess.foundcoverageentityifk,
                                                      '' as edisubscriberdobresponsefk,
                                                      cast(pg.sourcepatienthospitalfk as string) sourcepatienthospitalfk ,
                                                      cast(pg.sourcepatientacctifk as string) as sourcepatientacctifk ,
                                                      '' as sourcefoundcoveragehospitalfk,
                                                      '' as sourcefoundcoverageifk,
                                                      ess.edipartnerfk as edipartnerfk,
                                                      pg.source,
                                                      pg.subdob_mine_value,
                                                      pg.subdob_mine_status,
                                                      ess.edisubscriberdobsearchpk
                                                      from subscriberdoblookup ess
                                                      join patientguarantordetails as pg
                                                       on ess.mock_foundcoverageifk = pg.mock_foundcoverageifk 
                                                       and ess.hospitalfk = pg.ess_hospitalfk """
    externallysourcedsubscriberdob_data = spark.sql(prepare_externallysourcedsubscriberdob_data)
    writeparquet(spark,externallysourcedsubscriberdob_data,scratch_path + "/verified_mined_subdob_pagxpermid_data/",10,"overwrite")


#Finding the sub dob using patientacctsguarantors and gmrnid


def get_subdob_patientacctsguarantorsxgmrnid_data(spark,patientacctsguarantors,subscriberdoblookup,globalmrnxpacct,patientaccts,scratch_path):
    patientacctsguarantors.createOrReplaceTempView("patientacctsguarantors")
    subscriberdoblookup.createOrReplaceTempView("subscriberdoblookup")
    globalmrnxpacct.createOrReplaceTempView("globalmrnxpacct")
    patientaccts.createOrReplaceTempView("patientaccts")
    gmrnid_lookup_pquery = """ select ess.* ,
                                      gmrn.globalmrnifk as gmrnid
                                      from subscriberdoblookup ess
                                      join globalmrnxpacct gmrn
                                      on
                                      ess.patientacctifk <=> gmrn.patientacctifk 
                                      and ess.hospitalfk <=> gmrn.hospitalfk
                                      """
    gmrnid_lookup = spark.sql(gmrnid_lookup_pquery)
    gmrnid_lookup.createOrReplaceTempView("gmrnid")
    gmrnid_associated_accounts = """ select
                                      g.* ,
                                      gmrn.hospitalfk as asoc_hospitalfk,
                                      gmrn.patientacctifk as asoc_patientacctifk
                                      from gmrnid g
                                      join globalmrnxpacct gmrn
                                      on
                                      g.gmrnid <=> gmrn.globalmrnifk and g.hcsystemfk = gmrn.hcsystemfk """
    assoc_gmrnid_stage = spark.sql(gmrnid_associated_accounts)
    writeparquet(spark,assoc_gmrnid_stage,scratch_path + "/assoc_gmrnid_stage/",100,"overwrite")
    assoc_gmrnid = readparquet(spark, scratch_path + "/assoc_gmrnid_stage/", "0","na")
    assoc_gmrnid.createOrReplaceTempView("subscriberdoblookup_extended")
    get_subdob_asoc_gmrnid_pquery = """ select ess.mock_foundcoverageifk,
                                               ess.hospitalfk,
                                               max(pag.patientacctifk) sourcepatientacctifk
                                               from subscriberdoblookup_extended ess
                                               join patientacctsguarantors pag
                                               on  ess.asoc_hospitalfk <=> pag.hospitalfk
                                                   and ess.asoc_patientacctifk <=> pag.patientacctifk
                                                   and pag.guarfirstname <=> ess.firstname
                                                   and pag.guarlastname <=> ess.lastname
                                                   group by ess.mock_foundcoverageifk,ess.hospitalfk
                                                   having count(distinct pag.guardob) = 1 """
    get_subdob_asoc_gmrnid_staging = spark.sql(get_subdob_asoc_gmrnid_pquery)
    #Joining back to subscriberdoblookup_extended to get the asoc_hospitalfk
    get_subdob_asoc_gmrnid_staging.createOrReplaceTempView("get_subdob_asoc_gmrnid_stage_tmp")
    get_subdob_asoc_gmrnid_asoc_hosp_query="""select ess.mock_foundcoverageifk,ess.asoc_hospitalfk,ess.hospitalfk as ess_hospitalfk,
                                               max(lkp.sourcepatientacctifk) sourcepatientacctifk
                                               from subscriberdoblookup_extended ess 
                                               join get_subdob_asoc_gmrnid_stage_tmp lkp
                                               on  ess.hospitalfk <=> lkp.hospitalfk
                                                   and ess.asoc_patientacctifk <=> lkp.sourcepatientacctifk
                                                   and ess.mock_foundcoverageifk <=> lkp.mock_foundcoverageifk 
                                                group by ess.mock_foundcoverageifk,ess.asoc_hospitalfk,ess.hospitalfk
                                                   """
    get_subdob_asoc_permid_assoc_hosp=spark.sql(get_subdob_asoc_gmrnid_asoc_hosp_query)
    writeparquet(spark,get_subdob_asoc_permid_assoc_hosp,scratch_path + "/get_subdob_asoc_gmrnid_staging/",100,"overwrite")   
    get_subdob_asoc_gmrnid = readparquet(spark, scratch_path + "/get_subdob_asoc_gmrnid_staging/", "0","na")
    get_subdob_asoc_gmrnid.createOrReplaceTempView("patientguarantor")
    get_lookup_pagxgmrnid_pquery = """       select pag.mock_foundcoverageifk,
                                             pag.sourcepatientacctifk,
                                             pag.ess_hospitalfk,
                                             pa.hospitalfk sourcepatienthospitalfk,
                                             guar.guardob subscriberdob
                                             from patientguarantor pag
                                             join patientaccts pa
                                             on pag.sourcepatientacctifk <=> pa.patientacctipk
                                             and pag.asoc_hospitalfk <=> pa.hospitalfk
                                             join patientacctsguarantors guar
                                             on pa.hospitalfk <=> guar.hospitalfk
                                             and pa.patientacctipk <=> guar.patientacctifk """
    mined_subdob_pagxgmrnid_data_stage = spark.sql(get_lookup_pagxgmrnid_pquery)
    writeparquet(spark,mined_subdob_pagxgmrnid_data_stage,scratch_path + "/mined_subdob_pagxgmrnid_data_stage/",100,"overwrite")
    mined_subdob_pagxgmrnid_data = readparquet(spark, scratch_path + "/mined_subdob_pagxgmrnid_data_stage/","0","na")
    mined_subdob_pagxgmrnid_data = mined_subdob_pagxgmrnid_data.withColumn("source",lit("patientacctsguarantorsxgmrnid"))
    mined_subdob_pagxgmrnid_data = mined_subdob_pagxgmrnid_data.withColumn("subdob_mine_value",lit(5))
    mined_subdob_pagxgmrnid_data = mined_subdob_pagxgmrnid_data.withColumn("subdob_mine_status",lit("verified"))
    mined_subdob_pagxgmrnid_data.createOrReplaceTempView("patientguarantordetails")
    prepare_externallysourcedsubscriberdob_data = """ select
                                                      ess.hospitalfk,
                                                      ess.patientacctifk,
                                                      ess.subscriberdoblookuppk,
                                                      cast(pg.subscriberdob as string) dob,
                                                      ess.foundcoverageifk,
                                                      ess.foundcoverageentityifk,
                                                      '' as edisubscriberdobresponsefk,
                                                      cast(pg.sourcepatienthospitalfk  as string) as  sourcepatienthospitalfk,
                                                      cast(pg.sourcepatientacctifk as string) as sourcepatientacctifk,
                                                      '' as sourcefoundcoveragehospitalfk,
                                                      '' as sourcefoundcoverageifk,
                                                      ess.edipartnerfk as edipartnerfk,
                                                      pg.source,
                                                      pg.subdob_mine_value,
                                                      pg.subdob_mine_status,
                                                      ess.edisubscriberdobsearchpk
                                                      from subscriberdoblookup ess
                                                      join patientguarantordetails as pg
                                                       on ess.mock_foundcoverageifk = pg.mock_foundcoverageifk
                                                       and ess.hospitalfk = pg.ess_hospitalfk """
    externallysourcedsubscriberdob_data = spark.sql(prepare_externallysourcedsubscriberdob_data)
    writeparquet(spark,externallysourcedsubscriberdob_data,scratch_path + "/verified_mined_subdob_pagxgmrnid_data/",10,"overwrite")


# COMMAND ----------

hospitals_col =  ["hospitalpk","hcsystemfk"]
hospitals = readparquet(spark,hdfs_input + "/hospitals/current/20991231/","1",hospitals_col)
globalmrnxpacct = readparquet(spark, gmrn_publish_path + "/globalmrnxpacct/current/*", "0","na")
globalmrnxpacct = get_hcsytemfk(spark,hospitals,globalmrnxpacct)
globalmrnxpacct = get_clean_data(spark,globalmrnxpacct)
patientacctsguarantors_col = ["hospitalfk","patientacctifk","guardob","guarfirstname","guarlastname"]
patientacctsguarantors =  extract_deltalake_data(spark, hdfs_input + "/patientacctsguarantors/current/20991231/",patientacctsguarantors_col)
patientacctsguarantors = get_clean_data(spark,patientacctsguarantors)
patientacctsguarantors = get_formatted_patientacctsguarantors_data(spark,patientacctsguarantors)

patientaccts_col = ["hospitalfk","patientacctipk"]
patientaccts = extract_deltalake_data(spark,hdfs_input + "/patientaccts/current/20991231/",patientaccts_col)
patientaccts = get_hcsytemfk(spark,hospitals,patientaccts)
patientaccts = get_clean_data(spark,patientaccts)

subscriberdoblookup = readparquet(spark, scratch_path + "/subscriberdoblookup/", "0","na")
# permidschema = StructType([
#         StructField("permid", StringType()),
#         StructField("hospitalfk", StringType()),
#         StructField("patientacctifk", StringType()),
#         StructField("matchind", StringType()),
#         StructField("magnetpermid", StringType())
#     ])
#patientacctsxrefpermid = readcsv_permissive(spark,permid_path,permidschema,"|","0","na") 
patientacctsxrefpermid = readparquet(spark,permid_path, "0","na")
patientacctsxrefpermid = get_clean_data(spark,patientacctsxrefpermid)    
get_subdob_patientacctsguarantors_data(spark,patientacctsguarantors,subscriberdoblookup,scratch_path)
get_subdob_patientacctsguarantorsxpermid_data(spark,patientacctsguarantors,subscriberdoblookup,patientacctsxrefpermid,patientaccts,scratch_path)
get_subdob_patientacctsguarantorsxgmrnid_data(spark,patientacctsguarantors,subscriberdoblookup,globalmrnxpacct,patientaccts,scratch_path)
