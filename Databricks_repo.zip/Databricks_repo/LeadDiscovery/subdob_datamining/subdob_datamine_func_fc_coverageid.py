# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("scratch_path","")
dbutils.widgets.getArgument("scratch_path")
scratch_path= getArgument("scratch_path")

dbutils.widgets.text("hdfs_input","")
dbutils.widgets.getArgument("hdfs_input")
hdfs_input= getArgument("hdfs_input")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from datetime import *

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

hdfs_input = baseurl+hdfs_input
scratch_path = baseurl+scratch_path + bc + '/'
print(hdfs_input)
print(scratch_path)

# COMMAND ----------

def get_fc_data(spark,foundcoverage,scratch_path):
    foundcoverage = foundcoverage.filter(col("dob").isNotNull())     
    foundcoverage = foundcoverage.filter(col("hitstatus").isin("1","2"))
    foundcoverage = foundcoverage.filter(col("currentinferredsourcemethodcode").isin('RE', 'IE', 'FE', 'FI','CM','CG','FG','FJ', 'HG'))
    writeparquet(spark,foundcoverage,scratch_path + "/foundcoverage_lookup/",1000,"overwrite")

#getting formatted fc data for coverageid
    
def get_formatted_coverageid_data(spark,df):
    df = df.withColumn("extracted_grpnum",split(col("coverageid"),'-').getItem(1))
    df = df.withColumn("derived_coverageid",when(((col("groupnumber").isNotNull()) & (col("extracted_grpnum") == col("groupnumber"))),split(col("coverageid"),'-').getItem(0)).otherwise(col("coverageid")))
    return df



#Finding sub dob using foundcoverage and coverageid data

def get_subdob_foundcoverage_coverageid_data(spark,foundcoverage,subscriberdoblookup,scratch_path):
    foundcoverage.createOrReplaceTempView("foundcoverage")
    subscriberdoblookup.createOrReplaceTempView("subscriberdoblookup")
    coverageid_lookup_pquery = """ select ess.mock_foundcoverageifk,
                                   ess.hospitalfk, 
                                   max(fc.dob) subscriberdob, 
                                   max(fc.foundcoverageipk) srcfoundcoverageipk
                                   from subscriberdoblookup ess
                                   join foundcoverage fc
                                       on (ess.coverageid <=> fc.derived_coverageid) and (ess.patientacctifk <=> fc.patientacctifk)
                                       and (ess.hospitalfk <=> fc.hospitalfk) and (ess.edipartnerfk <=> fc.edipartnerfk)
                                   where
                                           fc.firstname <=> ess.firstname
                                       and fc.lastname <=> ess.lastname
                                   group by ess.mock_foundcoverageifk,ess.hospitalfk
                                           having count(distinct fc.dob) = 1 """
    coverageid_lookup = spark.sql(coverageid_lookup_pquery)
    coverageid_lookup = coverageid_lookup.withColumn("source",lit("foundcoverage-coverageid"))
    coverageid_lookup = coverageid_lookup.withColumn("subdob_mine_value",lit(9))
    coverageid_lookup = coverageid_lookup.withColumn("subdob_mine_status",lit("verified"))
    coverageid_lookup.createOrReplaceTempView("samecoverageidfoundcoverage")
    prepare_externallysourcedsubscriberdob_data = """ select
                                                      ess.hospitalfk,
                                                      ess.patientacctifk,
                                                      ess.subscriberdoblookuppk,
                                                      cast(fmfc.subscriberdob as string) as dob,
                                                      ess.foundcoverageifk,
                                                      ess.foundcoverageentityifk,
                                                      '' as edisubscriberdobresponsefk,
                                                      '' as sourcepatienthospitalfk,
                                                      '' as sourcepatientacctifk,
                                                      cast(fc.hospitalfk as string) as sourcefoundcoveragehospitalfk,
                                                      cast(fc.foundcoverageipk as string) as sourcefoundcoverageifk,
                                                      ess.edipartnerfk as edipartnerfk,
                                                      fmfc.source,
                                                      fmfc.subdob_mine_value,
                                                      fmfc.subdob_mine_status,
                                                      ess.edisubscriberdobsearchpk
                                                      from subscriberdoblookup ess
                                                      join samecoverageidfoundcoverage  fmfc
                                                           on ess.mock_foundcoverageifk <=> fmfc.mock_foundcoverageifk
                                                           and ess.hospitalfk <=> fmfc.hospitalfk
                                                      join foundcoverage fc
                                                           on fmfc.srcfoundcoverageipk <=> fc.foundcoverageipk
                                                           and fmfc.hospitalfk <=> fc.hospitalfk  """
    externallysourcedsubscriberdob_data = spark.sql(prepare_externallysourcedsubscriberdob_data)
    writeparquet(spark,externallysourcedsubscriberdob_data,scratch_path + "/verified_mined_foundcoverage_coverageid/",10,"overwrite")


# COMMAND ----------

subscriberdoblookup = readparquet(spark, scratch_path + "/subscriberdoblookup/", "0","na")
foundcoverage_col = ["dob","foundcoverageipk","hospitalfk","edipartnerfk","hitstatus","currentinferredsourcemethodcode","firstname","lastname","coverageid","groupnumber","patientacctifk"]
foundcoverage = extract_deltalake_data(spark,hdfs_input + "/foundcoverage/current/20991231/",foundcoverage_col)
foundcoverage = get_clean_data(spark,foundcoverage)
foundcoverage = get_formatted_coverageid_data(spark,foundcoverage)
foundcoverage = get_fc_data(spark,foundcoverage,scratch_path)
foundcoverage_filtered = readparquet(spark, scratch_path + "/foundcoverage_lookup/", "0","na")
get_subdob_foundcoverage_coverageid_data(spark,foundcoverage_filtered,subscriberdoblookup,scratch_path)
