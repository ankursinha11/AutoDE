# Databricks notebook source
# MAGIC %md
# MAGIC #birthmonth: process leads

# COMMAND ----------

# MAGIC %run /Insleads-code/LeadDiscovery/common/process_leads

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import *
import sys
import datetime
import subprocess

# COMMAND ----------

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("hdfs_input","")
dbutils.widgets.getArgument("hdfs_input")
hdfs_input= getArgument("hdfs_input")

dbutils.widgets.text("hdfs_leads_input","")
dbutils.widgets.getArgument("hdfs_leads_input")
hdfs_leads_input= getArgument("hdfs_leads_input")

dbutils.widgets.text("hdfs_admitdt_path","")
dbutils.widgets.getArgument("hdfs_admitdt_path")
hdfs_admitdt_path= getArgument("hdfs_admitdt_path")

dbutils.widgets.text("hdfs_output","")
dbutils.widgets.getArgument("hdfs_output")
hdfs_output= getArgument("hdfs_output")

dbutils.widgets.text("hdfs_maprdb_input","")
dbutils.widgets.getArgument("hdfs_maprdb_input")
hdfs_maprdb_input= getArgument("hdfs_maprdb_input")

dbutils.widgets.text("hdfs_leadstatus","")
dbutils.widgets.getArgument("hdfs_leadstatus")
hdfs_leadstatus= getArgument("hdfs_leadstatus")

dbutils.widgets.text("hdfs_scratch","")
dbutils.widgets.getArgument("hdfs_scratch")
hdfs_scratch= getArgument("hdfs_scratch")

dbutils.widgets.text("broadcastjoin_flag","")
dbutils.widgets.getArgument("broadcastjoin_flag")
broadcastjoin_flag= getArgument("broadcastjoin_flag")

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

hdfs_admitdt_path=baseurl+hdfs_admitdt_path+'/'+bc+'/*'
hdfs_input=baseurl+hdfs_input
hdfs_leads_input=baseurl+hdfs_leads_input+'/'+bc
hdfs_leadstatus=baseurl+hdfs_leadstatus
hdfs_maprdb_input=baseurl+hdfs_maprdb_input
hdfs_output=baseurl+hdfs_output+'/'+bc
hdfs_scratch=baseurl+hdfs_scratch+'/'+bc+'/'

print("hdfs_admitdt_path="+str(hdfs_admitdt_path))
print("hdfs_input="+str(hdfs_input))
print("hdfs_leads_input="+str(hdfs_leads_input))
print("hdfs_leadstatus="+str(hdfs_leadstatus))
print("hdfs_maprdb_input="+str(hdfs_maprdb_input))
print("hdfs_output="+str(hdfs_output))
print("hdfs_scratch="+str(hdfs_scratch))

# COMMAND ----------

# adding this to distinguish leads at record level from edi side
def addedidatasourcefk(spark, all_leads_wallingoff_tmp, hdfs_maprdb_input,hdfs_scratch):
    edi = all_leads_wallingoff_tmp.withColumn("edidatasourcefk",lit('50'))
    return edi

# COMMAND ----------

create_temp_data(spark, hdfs_input, hdfs_scratch)

all_leads = extract_explode_leads(spark, hdfs_leads_input + "/*")

# temporary fix or null value in coverageid from LSB
cond_coverageid = when( \
    ((lower(trim(col("lsb_coverageid"))).startswith("null"))) \
    , regexp_replace(col("lsb_coverageid"), "null", "") \
    ) \
    .otherwise(col("lsb_coverageid"))

all_leads = all_leads.withColumn("lsb_coverageid", cond_coverageid)

cond_id = when( \
    ((lower(trim(col("lsb_id"))).contains("_null"))) \
    , regexp_replace(col("lsb_id"), "null", "") \
    ) \
    .otherwise(col("lsb_id"))

all_leads = all_leads.withColumn("lsb_id", cond_id)
# end temporary fix

# fix for the edipartnerfk=182 not merging into 101
cond = when( \
    ((trim(col("lsb_edipartnerfk")) == "182")) \
    , lit("101") \
    ) \
    .otherwise(col("lsb_edipartnerfk"))

all_leads = all_leads.withColumn("lsb_edipartnerfk", cond)

cond_id_2 = when( \
    (((trim(col("lsb_edipartnerfk")) == "182") | (trim(col("lsb_edipartnerfk")) == "101")) & (lower(trim(col("lsb_id"))).contains("_182_"))) \
    , regexp_replace(col("lsb_id"), "_182_", "_101_") \
    ) \
    .otherwise(col("lsb_id"))

all_leads = all_leads.withColumn("lsb_id", cond_id_2)

# fix for state beign longer from ICG
cond_state = when( \
    ((length(trim(col("lsb_state"))) > 2)) \
    , lit("") \
    ) \
    .otherwise(col("lsb_state"))

all_leads = all_leads.withColumn("lsb_state", cond_state)

writeparquet(spark, all_leads, hdfs_scratch + "/all_leads", 200, "overwrite")
all_leads_tmp = readparquet(spark, hdfs_scratch + "/all_leads/", "0", "na")

# Filter out blacklisted Policy Id's
blcol = ["edipartnerfk", "coverageid"]
blacklist_accts = extract_parquet_data(spark, hdfs_input + "/partnerpolicyidblacklists/current/*", blcol)
all_leads_nbl = filter_blacklisted_partnerpolicyid(spark, all_leads_tmp, blacklist_accts, hdfs_input, hdfs_scratch)
writeparquet(spark, all_leads_nbl, hdfs_scratch + "/all_leads_nbl", 200, "overwrite")
all_leads_nbl_tmp = readparquet(spark, hdfs_scratch + "/all_leads_nbl/", "0", "na")

all_leads_len_admitdt = filter_coverageid_len_admitdt(spark, all_leads_nbl_tmp, hdfs_admitdt_path, hdfs_scratch)
writeparquet(spark, all_leads_len_admitdt, hdfs_scratch + "/all_leads_len_admitdt", 200, "overwrite")
all_leads_len_admitdt_tmp = readparquet(spark, hdfs_scratch + "/all_leads_len_admitdt/", "0", "na")

all_leads_ct = filter_commerical_tricare_edipartners(spark, all_leads_len_admitdt_tmp, hdfs_input, hdfs_scratch)
writeparquet(spark, all_leads_ct, hdfs_scratch + "/all_leads_ct", 200, "overwrite")
all_leads_ct_tmp = readparquet(spark, hdfs_scratch + "/all_leads_ct/", "0", "na")

all_leads_hpn = filter_ifhpn_notenabled(spark, all_leads_ct_tmp, hdfs_input, hdfs_scratch)
writeparquet(spark, all_leads_hpn, hdfs_scratch + "/all_leads_hpn", 200, "overwrite")
all_leads_hpn_tmp = readparquet(spark, hdfs_scratch + "/all_leads_hpn/", "0", "na")

all_leads_passmincharges = filter_mincharges_by_partner(spark, all_leads_hpn_tmp, hdfs_input, hdfs_scratch)
writeparquet(spark, all_leads_passmincharges, hdfs_scratch + "/all_leads_passmincharges", 200, "overwrite")
all_leads_passmincharges_tmp = readparquet(spark, hdfs_scratch + "/all_leads_passmincharges/", "0", "na")

all_leads_wallingoff = applywallingoff(spark, all_leads_passmincharges_tmp, hdfs_input, hdfs_scratch)
writeparquet(spark, all_leads_wallingoff, hdfs_scratch + "/all_leads_wallingoff", 200, "overwrite")
all_leads_wallingoff_tmp = readparquet(spark, hdfs_scratch + "/all_leads_wallingoff/", "0", "na")

all_leads_edidatasourcefk = addedidatasourcefk(spark, all_leads_wallingoff_tmp, hdfs_maprdb_input, hdfs_scratch)
writeparquet(spark, all_leads_edidatasourcefk, hdfs_scratch + "/all_leads_edidatasourcefk", 200, "overwrite")
all_leads_edidatasourcefk_tmp = readparquet(spark, hdfs_scratch + "/all_leads_edidatasourcefk/", "0", "na")

all_leads_ohi = ohibatchprocess(spark, all_leads_edidatasourcefk_tmp, hdfs_input, hdfs_scratch)
writeparquet(spark, all_leads_ohi, hdfs_scratch + "/all_leads_ohi", 200, "overwrite")
all_leads_ohi_tmp = readparquet(spark, hdfs_scratch + "/all_leads_ohi/", "0", "na")

final_leads = bestleadselection(spark, all_leads_ohi_tmp, bc, hdfs_scratch)

final_leads.dropDuplicates().repartition(200).write.mode("overwrite").parquet(hdfs_output)

if (final_leads.isEmpty()):
    ret_val = 0
else:
    ret_val = 1

delete_temp_data(spark, hdfs_scratch)

# COMMAND ----------

dbutils.notebook.exit(ret_val)
