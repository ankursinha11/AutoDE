# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("hdfs_leads_input","")
dbutils.widgets.getArgument("hdfs_leads_input")
hdfs_leads_input= getArgument("hdfs_leads_input")

dbutils.widgets.text("hdfs_leads_sent","")
dbutils.widgets.getArgument("hdfs_leads_sent")
hdfs_leads_sent= getArgument("hdfs_leads_sent")

dbutils.widgets.text("hdfs_sqoop_output","")
dbutils.widgets.getArgument("hdfs_sqoop_output")
hdfs_sqoop_output= getArgument("hdfs_sqoop_output")

dbutils.widgets.text("dataingestion_publish_path","")
dbutils.widgets.getArgument("dataingestion_publish_path")

dataingestion_publish_path= getArgument("dataingestion_publish_path")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.functions import encode
from pyspark.sql.window import Window
import sys
import datetime
import uuid

# COMMAND ----------

def blank_as_null(x):
    return when(trim(col(x)) != "", trim(col(x))).otherwise(None)

# COMMAND ----------

hdfs_leads_input= baseurl+hdfs_leads_input + bc
hdfs_leads_sent= baseurl+hdfs_leads_sent
hdfs_sqoop_output= baseurl+ hdfs_sqoop_output + bc
dataingestion_publish_path= baseurl+ dataingestion_publish_path

# COMMAND ----------

initialrun = 0

# read sent leads
sent_leads = spark.read.format("delta").load(hdfs_leads_sent)
sent_leads.createOrReplaceTempView("sent_leads")
sent_leads=spark.sql("""
SELECT uniqueid,
       patientacctifk,
       lsb_edipartnerfk,
       demohash,
       UPPER(TRIM(lsb_coverageid)) AS lsb_coverageid,
       UPPER(TRIM(lsb_firstname)) AS sl_firstname,
       UPPER(TRIM(lsb_lastname))  AS sl_lastname,
       CASE WHEN TRIM(lsb_ssn) = '000000000' THEN '' ELSE TRIM(lsb_ssn) END AS sl_ssn,
       TRIM(lsb_dob) AS sl_dob,
       CASE WHEN UPPER(TRIM(lsb_state)) ='XX' THEN '' ELSE UPPER(TRIM(lsb_state)) END AS sl_state
FROM sent_leads""").dropDuplicates()

sent_leads_democols = ["sl_firstname","sl_lastname", "sl_ssn", "sl_dob", "sl_state"]
for column in sent_leads_democols:
    sent_leads = sent_leads.withColumn(column, trim(col(column)))
    sent_leads = sent_leads.withColumn(column, when(col(column).isNull(), '').otherwise(col(column)))
    sent_leads = sent_leads.withColumn(column, when(upper(col(column)) == 'NULL', '').otherwise(col(column)))
    sent_leads = sent_leads.withColumn(column, when(upper(col(column)) == 'NONE', '').otherwise(col(column)))
    sent_leads = sent_leads.withColumn(column, when(upper(col(column)) == 'XX', '').otherwise(col(column)))
sent_leads.createOrReplaceTempView("sent_leads")

# read new leads
leads = spark.read.parquet(hdfs_leads_input + "/*")
# Filter out bad coverageId records.
leads= leads.filter(~col("lsb_coverageId").isin('999999999','ABC123','SELFPAY'))
input_leads_democols = ["lsb_firstname","lsb_lastname", "lsb_ssn", "lsb_dob", "lsb_state"]
for column in input_leads_democols:
    leads = leads.withColumn(column, trim(col(column)))
    leads = leads.withColumn(column, when(col(column).isNull(), '').otherwise(col(column)))
    leads = leads.withColumn(column, when(upper(col(column)) == 'NULL', '').otherwise(col(column)))
    leads = leads.withColumn(column, when(upper(col(column)) == 'NONE', '').otherwise(col(column)))
    leads = leads.withColumn(column, when(upper(col(column)) == 'XX', '').otherwise(col(column)))

for c_name in leads.columns:
    leads = leads.withColumn(c_name, trim(col(c_name).cast("string")))

leads=leads.withColumn("lsb_firstname",upper(col("lsb_firstname"))).withColumn("lsb_lastname",upper(col("lsb_lastname"))).withColumn("lsb_state",upper(col("lsb_state")))
leads.createOrReplaceTempView("leads")
leads=spark.sql(""" SELECT leads.*, CASE WHEN leads.lsb_state='XX' THEN '' ELSE leads.lsb_state END AS lsb_state_2 FROM leads""").drop("lsb_state").withColumnRenamed("lsb_state_2","lsb_state")
leads.createOrReplaceTempView("leads")
leads=spark.sql(""" SELECT leads.*, CASE WHEN leads.lsb_ssn='000000000' THEN '' ELSE leads.lsb_ssn END AS lsb_ssn_2 FROM leads""").drop("lsb_ssn").withColumnRenamed("lsb_ssn_2","lsb_ssn")

diff_leads = leads
#------------------
ordered_columns = ["uniqueid", "breadcrumb", "patientacctifk", "hospitalfk", "hospitalname", "firstname", "middlename", "lastname", "dob","ssn", "gender", "state", "admitdate", "dischargedate", "clusteredacctfk", "totalcharges", "npi", "lsb_edipartnerfk", "lsb_coverageid","lsb_leadsource", "lsb_xrefsource", "lsb_firstname", "lsb_middlename", "lsb_lastname", "lsb_gender", "lsb_dob", "lsb_ssn", "lsb_state","usefamilydataflag", "edidatasourcefk", "edidatasourcetablekey", "associationsource", "demohash", "medicarehic", "medicaidnum"]
diff_leads = diff_leads.withColumn("uniqueid", concat_ws("_", diff_leads.patientacctifk, expr("uuid()"))).select(ordered_columns)
cond_dob_2 = when(to_date(col("lsb_dob"), "yyyy-MM-dd HH:mm:ss").isNotNull(), date_format(col("lsb_dob"), "yyyy-MM-dd HH:mm:ss")).otherwise(None)
cond_dob = when( \
    (substring(trim(col("lsb_dob")), 0, 4).cast(IntegerType()) < 1800) \
    , lit("") \
    ) \
    .otherwise(cond_dob_2)
diff_leads = diff_leads.withColumn("lsb_dob", cond_dob)
diff_leads = diff_leads.withColumn("admitdate", date_format(col("admitdate"), "yyyy-MM-dd HH:mm:ss"))
diff_leads = diff_leads.withColumn("dischargedate", date_format(col("dischargedate"), "yyyy-MM-dd HH:mm:ss"))
diff_leads = diff_leads.withColumn("dob", date_format(col("dob"), "yyyy-MM-dd HH:mm:ss"))
## send empty string for bad ssn or gender
cond_gender = when( \
    (length(trim(col("lsb_gender"))) > 10) \
    , lit("") \
    ) \
    .otherwise(col("lsb_gender"))
diff_leads = diff_leads.withColumn("lsb_gender", cond_gender)
cond_ssn = when( \
    (length(trim(col("lsb_ssn"))) > 11) \
    , lit("") \
    ) \
    .otherwise(col("lsb_ssn"))
diff_leads = diff_leads.withColumn("lsb_ssn", cond_ssn)
## taking all coverageid with only len 25 or below -- business rule
diff_leads = diff_leads.filter(length(col("lsb_coverageid")) <= 25)
# getting the correct bc
diff_leads = diff_leads.withColumn("breadcrumb", lit(bc))
diff_leads = diff_leads.withColumn("createdate", date_format(current_timestamp(), "yyyy-MM-dd HH:mm:ss"))
# write out leads
diff_leads.dropDuplicates().repartition(5).write.mode("append").format("delta").save(hdfs_leads_sent)
diff_leads.unpersist()

#DELTA LAKE LOGIC STARTS
from delta.tables import *
df_raw = DeltaTable.forPath(spark, hdfs_leads_sent)
pJoinExpression="raw.hospitalfk=delta.hospitalfk"
# print("COUNT BEFORE PURGE : "+str(df_raw.toDF().count()))
df_delete=spark.read.parquet(dataingestion_publish_path + "/hospitalpurge/current/20991231/").filter("active=='1'").selectExpr("hospitalfk").dropDuplicates()
# print("COUNT hospitalpurge LIST : "+str(df_delete.count()))
df_raw.alias("raw").merge(df_delete.alias("delta"), pJoinExpression).whenMatchedDelete().execute()
df_raw = DeltaTable.forPath(spark, hdfs_leads_sent)
# print("COUNT AFTER PURGE : "+str(df_raw.toDF().count()))
#DELTA LAKE LOGIC ENDS


try:
    diff_leads = spark.read.format("delta").load(hdfs_leads_sent)
except Exception as e:
    print("Error loading Delta table:", str(e))

filterExpr="breadcrumb='"+bc+"'"
print("REGULAR filterExpr : "+str(filterExpr))

from pyspark.sql.functions import trim, when, col, upper, to_date
diff_leads=diff_leads.filter(filterExpr).dropDuplicates()

# Apply transformations to each column individually
for column in diff_leads.columns:
    diff_leads = diff_leads.withColumn(column, trim(col(column)))
    diff_leads = diff_leads.withColumn(column, when(col(column).isNull(), '').otherwise(col(column)))
    diff_leads = diff_leads.withColumn(column, when(upper(col(column)) == 'NULL', '').otherwise(col(column)))
    diff_leads = diff_leads.withColumn(column, when(upper(col(column)) == 'NONE', '').otherwise(col(column)))
    diff_leads = diff_leads.withColumn(column, when(upper(col(column)) == 'XX', '').otherwise(col(column)))

# Apply additional transformations to specific columns
diff_leads = diff_leads.withColumn('dob', ((to_date(diff_leads.dob)).cast('timestamp')).cast('string'))
diff_leads = diff_leads.withColumn('admitdate', ((to_date(diff_leads.admitdate)).cast('timestamp')).cast('string'))
diff_leads = diff_leads.withColumn('dischargedate', ((to_date(diff_leads.dischargedate)).cast('timestamp')).cast('string'))
diff_leads = diff_leads.withColumn('lsb_dob', ((to_date(diff_leads.lsb_dob)).cast('timestamp')).cast('string'))

# Print the count and output path
# print("COUNT diff_leads : " + str(diff_leads.count()))
print("hdfs_sqoop_output : " + str(hdfs_sqoop_output + "/hdppatientacctxlead"))



diff_leads.drop("demohash").repartition(10) \
    .write.format("parquet") \
    .mode("overwrite") \
    .options(timestampFormat="yyyy-MM-dd HH:mm:ss") \
    .save(hdfs_sqoop_output+"/hdppatientacctxlead")

batch = spark.createDataFrame([ Row(breadcrumb= bc)])

batch.repartition(1) \
    .write.mode("overwrite") \
    .format("parquet") \
    .options(timestampFormat="yyyy-MM-dd HH:mm:ss") \
    .save(hdfs_sqoop_output +"/hdppatientacctxleadbatch")

if (diff_leads.isEmpty()):
    ret_val = 0
else:
    ret_val = 1

dbutils.notebook.exit(ret_val)

# COMMAND ----------


