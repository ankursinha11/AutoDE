# Databricks notebook source
dbutils.widgets.text("hdfs_input","")
dbutils.widgets.getArgument("hdfs_input")
hdfs_input= getArgument("hdfs_input")

dbutils.widgets.text("hdfs_all_leads","")
dbutils.widgets.getArgument("hdfs_all_leads")
hdfs_all_leads= getArgument("hdfs_all_leads")

dbutils.widgets.text("hdfs_leadverifyrepo","")
dbutils.widgets.getArgument("hdfs_leadverifyrepo")
hdfs_leadverifyrepo= getArgument("hdfs_leadverifyrepo")


dbutils.widgets.text("hdfs_scratch","")
dbutils.widgets.getArgument("hdfs_scratch")
hdfs_scratch= getArgument("hdfs_scratch")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("hdfs_output","")
dbutils.widgets.getArgument("hdfs_output")
hdfs_output= getArgument("hdfs_output")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

# COMMAND ----------


if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

hdfs_all_leads = baseurl+hdfs_all_leads+bc
hdfs_input = baseurl+hdfs_input
hdfs_leadverifyrepo = baseurl+hdfs_leadverifyrepo
hdfs_scratch = baseurl+hdfs_scratch+bc
hdfs_output = baseurl+hdfs_output+bc

print("bc:",bc)
print("hdfs_all_leads:",hdfs_all_leads)
print("hdfs_input:",hdfs_input)
print("hdfs_leadverifyrepo:",hdfs_leadverifyrepo)
print("hdfs_scratch:",hdfs_scratch)
print("hdfs_output:",hdfs_output)

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
import datetime
import os
import subprocess
from pyspark import SparkContext
from pyspark.conf import SparkConf

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

def filter_ifexists_leadverifyrepo(spark,df_leads,df_leadverifyrepo,df_pacctcommhelper,df_hosp,df_hcsystem):
    df_leadrepo = df_leadverifyrepo.union(df_pacctcommhelper)
    df_leads.createOrReplaceTempView("leads")
    df_leadrepo.createOrReplaceTempView("repo")
    leadsql = """select a.*,r.hospitalfk as helperhospitalfk
                 from leads a
                 join repo r on a.hdp_demographicshash = r.hdp_demographicshash  and a.lsb_edipartnerfk = r.edipartnerfk """        
    leads = spark.sql(leadsql)
    a_count = len(leads.head(1))
    if (a_count == 0):
       return df_leads
    else :       
       leads_wallingoff = check_wallingoff(spark,leads,df_hosp, df_hcsystem) 
       df_leads_filtered = df_leads.join(leads_wallingoff, (df_leads.hdp_demographicshash == leads_wallingoff.hdp_demographicshash) & \
                  (df_leads.lsb_edipartnerfk == leads_wallingoff.lsb_edipartnerfk), "left_anti") 
       return df_leads_filtered

# COMMAND ----------

def check_wallingoff(spark, all_leads,df_hosp, df_hcsystem):    
    df_hosp.createOrReplaceTempView("hospitals")
    df_hcsystem.createOrReplaceTempView("hcsystems")
    all_leads.createOrReplaceTempView("leads")
    leadsql = """select a.*
                  from leads a
                  join hospitals h on a.selfpay_hospitalfk = h.hospitalpk
                  join hcsystems hc on h.hcsystemfk = hc.hcsystempk
                  join hospitals h2 on a.helperhospitalfk = h2.hospitalpk
                  join hcsystems hc2 on h2.hcsystemfk = hc2.hcsystempk 
                  where ((h.hcsystemfk = h2.hcsystemfk) or 
                  (coalesce(h.allowaggregationinflag ,hc.allowaggregationinflag ,1)=1 
                  and coalesce(h2.allowaggregationoutflag, hc2.allowaggregationoutflag,1) = 1))"""
    leads = spark.sql(leadsql)
    return leads

# COMMAND ----------

hospcols = ["hcsystemfk", "hospitalpk", "allowaggregationinflag", "allowaggregationoutflag" ]
df_hosp = extract_parquet_data(spark, hdfs_input + "/hospitals/current/*", hospcols)
df_hosp = df_hosp.withColumn("allowaggregationoutflag",blank_as_null("allowaggregationoutflag"))\
   .withColumn("allowaggregationinflag",blank_as_null("allowaggregationinflag"))
hccols = ["hcsystempk", "allowaggregationinflag", "allowaggregationoutflag"]
df_hcsystem = extract_parquet_data(spark, hdfs_input + "/hcsystems/current/*", hccols)
df_hcsystem = df_hcsystem.withColumn("allowaggregationoutflag",blank_as_null("allowaggregationoutflag"))\
   .withColumn("allowaggregationinflag",blank_as_null("allowaggregationinflag"))
pacctcommcols = ["edipartnerfk","hospitalfk","patientacctifk","coverageid","firstname","lastname","dob","ssn","demographicshash","hdp_demographicshash"]  
df_pacctcommhelper = extract_parquet_data(spark,hdfs_input +"/patientacctcommercialhelpers/current/*",pacctcommcols)
df_leads = extract_parquet_data(spark,hdfs_all_leads)
df_leadverifyrepo = extract_parquet_data(spark,hdfs_leadverifyrepo+"/*",pacctcommcols)
df_leadverifyrepo_filtered = filter_ifexists_leadverifyrepo(spark,df_leads,df_leadverifyrepo,df_pacctcommhelper,df_hosp,df_hcsystem) 
writeparquet(spark,df_leadverifyrepo_filtered,hdfs_output,200,'overwrite')  