# Databricks notebook source
import datetime
from pyspark.sql.functions import *

# COMMAND ----------

dbutils.widgets.text("hdfs_input","")
dbutils.widgets.getArgument("hdfs_input")
hdfs_input= getArgument("hdfs_input")

dbutils.widgets.text("hdfs_permid_input","")
dbutils.widgets.getArgument("hdfs_permid_input")
hdfs_permid_input= getArgument("hdfs_permid_input")

dbutils.widgets.text("hdfs_admitdatelookup","")
dbutils.widgets.getArgument("hdfs_admitdatelookup")
hdfs_admitdatelookup= getArgument("hdfs_admitdatelookup")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("hdfs_pa_path","")
dbutils.widgets.getArgument("hdfs_pa_path")
hdfs_pa_path= getArgument("hdfs_pa_path")

dbutils.widgets.text("hdfs_scratch","")
dbutils.widgets.getArgument("hdfs_scratch")
hdfs_scratch= getArgument("hdfs_scratch")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("gmrn_publish","")
dbutils.widgets.getArgument("gmrn_publish")
gmrn_publish= getArgument("gmrn_publish")

# COMMAND ----------

# bc = "20250623T01"
# container = "prod-icd-stg-adls"
# gmrn_publish = "/data/gmrn/publish"
# hdfs_admitdatelookup = "/data/leaddiscovery/transform/scratch/leadverify/minmaxbyhospital/"
# hdfs_input = "/data/dataingestion/publish"
# hdfs_pa_path = "/data/leadrepo/staging/input/raw/patientaccts/"
# hdfs_permid_input = "/data/cdd/publish/permidpatientacctid/*"
# hdfs_scratch = "/data/leaddiscovery/transform/scratch/leadverify/"
# storageaccount = "prodicdstgdls"
# user = "vishnup"

# COMMAND ----------


if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

hdfs_admitdatelookup = baseurl+hdfs_admitdatelookup+bc
hdfs_input = baseurl+hdfs_input
hdfs_permid_input = baseurl+hdfs_permid_input
hdfs_scratch = baseurl+hdfs_scratch+bc
hdfs_pa_path = baseurl+hdfs_pa_path+bc
gmrn_publish = baseurl+gmrn_publish

print("bc:",bc)
print("hdfs_admitdatelookup:",hdfs_admitdatelookup)
print("hdfs_input:",hdfs_input)
print("hdfs_permid_input:",hdfs_permid_input)
print("hdfs_scratch:",hdfs_scratch)
print("hdfs_pa_path:",hdfs_pa_path)
print("gmrn_publish:",gmrn_publish)

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))
spark.conf.set("spark.sql.shuffle.partitions", "auto")

# COMMAND ----------

# MAGIC %run ../../Common-Util/common_util

# COMMAND ----------

# MAGIC %run ../common/get_candidate_patientaccts

# COMMAND ----------

# MAGIC %run ../../Common-Util/tu_data_quality

# COMMAND ----------

def get_valid_patientaccts(spark,hdfs_pa_path,pacctscols):
    df_patientaccts = extract_parquet_data(spark,hdfs_pa_path,pacctscols)
    df_patientaccts = df_patientaccts.withColumnRenamed("patientacctipk","patientacctifk")
    #df_patientaccts = df_patientaccts.withColumn('totalcharges', df_patientaccts.totalcharges.cast("decimal(32,4)"))
    df_patients = df_patientaccts.filter("totalcharges >= 0.01")
    return df_patients

# COMMAND ----------

def get_permid_data(spark,hdfs_permid_input): 
    df_permid = readparquet(spark, hdfs_permid_input,"0","na")
    df_permid = df_permid.where((df_permid.matchind=='IM') | (df_permid.matchind=='M1'))
    return df_permid   

# COMMAND ----------

def get_candidates_gmrn_permid(spark,df_gmrnxpaccts,df_permid,hdfs_scratch):   
    df_paccts = extract_parquet_data(spark,hdfs_scratch+'/patientaccts_selfpay/*')
    df_gmrnifk_permid = df_paccts\
                       .join(df_gmrnxpaccts, (df_paccts.patientacctifk == df_gmrnxpaccts.patientacctifk) & (df_paccts.hospitalfk == df_gmrnxpaccts.hospitalfk), "left") \
                       .join(df_permid, (df_paccts.patientacctifk == df_permid.patientacctifk) & (df_paccts.hospitalfk == df_permid.hospitalfk),"left")\
                       .select(df_paccts['*'],df_gmrnxpaccts.globalmrnifk,df_permid.permid)

    df_gmrnifk_permid = df_gmrnifk_permid.filter((df_gmrnifk_permid.globalmrnifk.isNotNull()) | (df_gmrnifk_permid.permid.isNotNull()))

    writeparquet(spark,df_gmrnifk_permid,hdfs_scratch+'/gmrn_permid_raw/',0,'overwrite')
    df_patientgmrnpermid = extract_parquet_data(spark,hdfs_scratch+'/gmrn_permid_raw/*')
    df_patientgmrnpermid.createOrReplaceTempView('patientgmrnpermid')
    df_gmrnxpaccts.createOrReplaceTempView('globalmrnxpaccts') 
    df_candidates_gmrnpatient = spark.sql(""" select p.*,
                                              g.patientacctifk as candidatepatientacctifk,                                              
                                              'globalmrnifk' as keyname,1 as keyvalue,
                                              cast(g.hospitalfk as short) as candidatehospitalfk
                                              from patientgmrnpermid p 
                                              inner join globalmrnxpaccts g on p.globalmrnifk = g.globalmrnifk
                                              where (p.patientacctifk <> g.patientacctifk) or (p.patientacctifk = g.patientacctifk and p.hospitalfk <> g.hospitalfk)""")
    df_candidates_gmrnpatient = df_candidates_gmrnpatient.withColumn('lsb_identity',lit(df_candidates_gmrnpatient.globalmrnifk)) 
    writeparquet(spark,df_candidates_gmrnpatient,hdfs_scratch+'/gmrn_permid/gmrn/',0,'overwrite')   

    df_permid.createOrReplaceTempView('patientacctxpermid')
    df_candidates_permidpatient = spark.sql("""select p.*,
                                               g.patientacctifk as candidatepatientacctifk,                                               
                                               'permid' as keyname,2 as keyvalue,
                                               cast(g.hospitalfk as short) as candidatehospitalfk
                                              from patientgmrnpermid p
                                              inner join patientacctxpermid g on p.permid = g.permid                                              
                                              where (p.patientacctifk <> g.patientacctifk) or (p.patientacctifk = g.patientacctifk and p.hospitalfk <> g.hospitalfk)""")
    df_candidates_permidpatient = df_candidates_permidpatient.withColumn('lsb_identity',lit(df_candidates_permidpatient.permid))
    
    writeparquet(spark,df_candidates_permidpatient,hdfs_scratch+'/gmrn_permid/permid/',0,'overwrite')

# COMMAND ----------

def filter_candidates_bypatientaccts(spark,df_patientaccts,hdfs_scratch):
    df_ca = extract_parquet_data(spark,hdfs_scratch+'/gmrn_permid/*')
    df_candidates = df_ca.join(df_patientaccts, (df_ca.candidatepatientacctifk == df_patientaccts.patientacctipk) & (df_ca.candidatehospitalfk == df_patientaccts.hospitalfk))\
                         .select(df_ca['*'])
    writeparquet(spark,df_candidates,hdfs_scratch+'/candidatepatients/',0,'overwrite')

# COMMAND ----------

def get_edipartnerfk(spark,df_ghic,df_edipayers,df_edipartners,df_hospinsurancecodes,hdfs_scratch):
    df_candidates_hospallow = extract_parquet_data(spark,hdfs_scratch+'/candidatepatients/*')
    df_candidates_hospallow = df_candidates_hospallow.dropDuplicates()
    df_candidates_hospallow.createOrReplaceTempView("candidates")
    df_ghic.createOrReplaceTempView("globalmrnxhospinsurancecodes")
    df_edipayers.createOrReplaceTempView("edipayers")
    df_edipartners.createOrReplaceTempView("edipartners")
    df_hospinsurancecodes.createOrReplaceTempView("hospinsurancecodes")
    df_edipartnerfk = spark.sql(""" select c.*,ghic.globalmrnxhospinsurancecodespk,ghic.inspolicyid as coverageid,ghic.createdate as ghiccreatedate,
                                    pp.edipartnerpk,pp.edipartnertypefk,pp.allowknownmedicaidqueriesflag,
                                    case when h.mcaid =1 then 1 else 0 end ismanagedmedicaid 
                                             from candidates c
                                             join globalmrnxhospinsurancecodes ghic on ghic.patientacctifk = c.candidatepatientacctifk
                                                                                    and ghic.hospitalfk=c.candidatehospitalfk
                                             join hospinsurancecodes h on h.hospitalfk = ghic.hospitalfk and ghic.insurancecode = h.code
                                             join edipayers p on p.edipayerpk = h.edipayerfk
                                             join edipartners pp on pp.edipayerfk = p.edipayerpk """)
    writeparquet(spark,df_edipartnerfk,hdfs_scratch+'/all_candidates/selfpay/',0,'overwrite')

# COMMAND ----------

#spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)
# get all required data into dataframes
pa_col = ["patientacctipk","hospitalfk","firstname","middlename","lastname","ssn","dob","gender","state","admitdate","referraldate","dischargedate",\
  "demographicsupdatedate","medicalrecnum","clusteredacctfk","totalcharges","createdate","updatedate"]
df_patientaccts = get_valid_patientaccts(spark,hdfs_pa_path,pa_col)
 
hospcols = ["hcsystemfk", "hospitalpk","allowaggregationoutflag","allowaggregationinflag","active"]
df_hospitals = extract_parquet_data(spark,hdfs_input + "/hospitals/current/*",hospcols)
df_admitdate = extract_parquet_data(spark, hdfs_admitdatelookup)
df_hospadmitdate = df_hospitals.join(df_admitdate, df_admitdate.hospitalfk == df_hospitals.hospitalpk) \
.filter(df_hospitals.active == '1').select(df_admitdate['*'])  

# Get patientaccts with admit date filter
df_patientaccts_admitdt = getpatientacctswithadmitdt(spark, df_patientaccts, df_hospadmitdate)

# Get hospattribute values	
df_hospitalattributes = extract_parquet_data(spark, hdfs_input + "/hospitalattributes/current/*")
df_hospitalattributevalues = extract_parquet_data(spark, hdfs_input + "/hospitalattributevalues/current/*")
df_hospattributes_hospattributevalues = hospattributes(spark,df_hospitalattributes,df_hospitalattributevalues)

# Filter for selfpay accountsynced
vsnapcols = ["patientacctifk","hospitalfk","knownmcaidflag","primarymcaidflag","hasmedicareflag","knowntricareflag","secondarymcaid_afterinsuranceflag"]
df_vsnappatientacctsflags = extract_deltalake_data(spark, hdfs_input + "/vsnappatientacctsflags/current/20991231/", vsnapcols)
df_vsnappatientacctsflags = df_vsnappatientacctsflags.withColumn('patientacctifk', df_vsnappatientacctsflags.patientacctifk.cast("long")) 
df_paccts_selfpay_knownmcaid = getcandidateacctsfilter\
  (spark,df_patientaccts_admitdt,df_hospattributes_hospattributevalues,df_vsnappatientacctsflags) 
writeparquet(spark,df_paccts_selfpay_knownmcaid,hdfs_scratch+'/patientaccts_selfpay/',0,'overwrite')

# Get associated patientaccts from permid and gmrn
df_patientaccts_all = extract_deltalake_data(spark,hdfs_input + "/patientaccts/current/20991231/",pa_col)
df_patientaccts_all = df_patientaccts_all.filter(df_patientaccts_all.admitdate >= date_sub(current_date(), 365))
df_globalmrnxpaccts = extract_parquet_data(spark,gmrn_publish + "/globalmrnxpacct/current/*") #confirm path
df_permid = get_permid_data(spark,hdfs_permid_input)
hccols = ["hcsystempk","allowaggregationoutflag","allowaggregationinflag"]
df_hcsystems = extract_parquet_data(spark, hdfs_input + "/hcsystems/current/*", hccols)
get_candidates_gmrn_permid(spark,df_globalmrnxpaccts,df_permid,hdfs_scratch)
   
filter_candidates_bypatientaccts(spark,df_patientaccts_all,hdfs_scratch)
  
# Get edipartnerfk
ghiccols = ["globalmrnxhospinsurancecodespk","hospitalfk","patientacctifk","insurancecode","globalmrnifk","inspolicyid","createdate"]
df_ghic = extract_parquet_data(spark, gmrn_publish + "/globalmrnxhospinsurancecodes/current/*",ghiccols)
hospinscols = ["hospitalfk","code","edipayerfk","mcaid"]
df_hospinsurancecodes = extract_parquet_data(spark, hdfs_input + "/hospinsurancecodes/current/*",hospinscols)
df_edipayers = extract_parquet_data(spark, hdfs_input + "/edipayers/current/*",["edipayerpk"])
partnercols = ["edipayerfk","edipartnerpk","edipartnertypefk","allowknownmedicaidqueriesflag"]
df_edipartners = extract_parquet_data(spark, hdfs_input + "/edipartners/current/*",partnercols)
df_edipartnertypes = extract_parquet_data(spark, hdfs_input + "/edipartnertype/current/*")
df_hospitalpayercob = extract_parquet_data(spark,hdfs_input + "/hospitalpayercob/current/*",["hospitalfk","edipayerfk"])
get_edipartnerfk(spark,df_ghic,df_edipayers,df_edipartners,df_hospinsurancecodes,hdfs_scratch)
