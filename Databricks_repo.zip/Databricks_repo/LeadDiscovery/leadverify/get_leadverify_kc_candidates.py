# Databricks notebook source
#not used in workflow right now

# COMMAND ----------

dbutils.widgets.text("hdfs_input","")
dbutils.widgets.getArgument("hdfs_input")
hdfs_input= getArgument("hdfs_input")

dbutils.widgets.text("hdfs_permid_input","")
dbutils.widgets.getArgument("hdfs_permid_input")
hdfs_permid_input= getArgument("hdfs_permid_input")

dbutils.widgets.text("hdfs_admitdatelookup","")
dbutils.widgets.getArgument("hdfs_admitdatelookup")
hdfs_admitdatelookup= getArgument("hdfs_admitdatelookup")


dbutils.widgets.text("hdfs_scratch","")
dbutils.widgets.getArgument("hdfs_scratch")
hdfs_scratch= getArgument("hdfs_scratch")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("gmrn_publish","")
dbutils.widgets.getArgument("gmrn_publish")
gmrn_publish= getArgument("gmrn_publish")

# COMMAND ----------


if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

gmrn_publish = baseurl+gmrn_publish
hdfs_input = baseurl+hdfs_input
hdfs_admitdatelookup = baseurl+hdfs_admitdatelookup+bc
hdfs_permid_input = baseurl+hdfs_permid_input
hdfs_scratch = baseurl+hdfs_scratch+bc

print("bc:",bc)
print("gmrn_publish:",gmrn_publish)
print("hdfs_input:",hdfs_input)
print("hdfs_permid_input:",hdfs_permid_input)
print("hdfs_scratch:",hdfs_scratch)
print("hdfs_admitdatelookup:",hdfs_admitdatelookup)

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
import datetime
import os
import subprocess
from pyspark import SparkContext
from pyspark.conf import SparkConf

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

# MAGIC %run /Insleads-code/LeadDiscovery/common/get_candidate_patientaccts

# COMMAND ----------

def get_patientacct_demographics(spark,df_patientaccts_all,df_kc,hdfs_scratch):
    df_kc.createOrReplaceTempView("candidates")
    df_patientaccts_all.createOrReplaceTempView("patientaccts")
    df_ca = spark.sql("""select c.patientacctifk ,
                                p1.hospitalfk ,
                                p.firstname,
                                p.middlename,
                                p.lastname,
                                p.ssn,
                                p.dob,
                                p.gender,
                                p.state,
                                p.admitdate,
                                p.referraldate,
                                p.dischargedate,
                                p.demographicsupdatedate,
                                p.medicalrecnum,
                                p.clusteredacctfk,
                                p.totalcharges,
                                p.createdate,
                                p.updatedate,
                                c.knowntricareflag,
                                c.knownmcaidflag,
                                c.globalmrnifk,
                                c.permid,
			        c.candidatepatientacctifk,
				c.keyname,
                                c.keyvalue,
				c.lsb_identity,
				c.candidatehospitalfk,
				c.globalmrnxhospinsurancecodespk,
                                c.coverageid ,
				c.ghiccreatedate,
				c.edipartnerpk,
				c.edipartnertypefk,
				c.allowknownmedicaidqueriesflag,
                                c.ismanagedmedicaid
                                from candidates c
                                inner join patientaccts p on p.patientacctipk = c.candidatepatientacctifk and p.hospitalfk=c.candidatehospitalfk
                                inner join patientaccts p1 on p1.patientacctipk = c.patientacctifk""")
    writeparquet(spark,df_ca,hdfs_scratch+'/kc/patientdemographics/',200,'overwrite')

# COMMAND ----------

def get_gmrn_permid_by_patientacct(spark,df_permid,df_gmrnxpaccts,hdfs_scratch):
    df_kc = extract_parquet_data(spark,hdfs_scratch+'/kc/kcaccounts/*')
    df_add_permid = df_kc\
                     .join(df_permid, df_kc.candidatepatientacctifk==df_permid.patientacctifk,"left")\
                     .select(df_kc['*'],df_permid.permid)
    df_add_permid.createOrReplaceTempView('patientgmrnpermid')
    df_gmrnxpaccts.createOrReplaceTempView('globalmrnxpaccts')
    # get gmrn and permid associated patients
    df_candidates_gmrnpatient = spark.sql(""" select p.*,
                                              g.patientacctifk ,g.hospitalfk ,'globalmrnifk' as keyname,1 as keyvalue,p.globalmrnifk as lsb_identity
                                              from patientgmrnpermid p
                                              inner join globalmrnxpaccts g on p.globalmrnifk = g.globalmrnifk
                                              where p.candidatepatientacctifk <> g.patientacctifk and p.globalmrnifk is not null """)
    df_candidates_gmrnpatient = df_candidates_gmrnpatient.withColumn("hospitalfk",df_candidates_gmrnpatient.hospitalfk.cast('string'))
    writeparquet(spark,df_candidates_gmrnpatient,hdfs_scratch+'/kc/gmrn_permid/gmrn/',200,'overwrite')
    df_permid.createOrReplaceTempView('permid')
    df_candidates_permidpatient =  spark.sql("""select p.*,
                                                g.patientacctifk,'' as hospitalfk,'permid' as keyname,2 as keyvalue,g.permid as lsb_identity
                                                from patientgmrnpermid p
                                                inner join permid g on p.permid = g.permid
                                                where p.candidatepatientacctifk <> g.patientacctifk and p.permid is not null """)
    writeparquet(spark,df_candidates_permidpatient,hdfs_scratch+'/kc/gmrn_permid/permid/',200,'overwrite')


# COMMAND ----------

def get_kc_accounts(spark,df_ghic,df_edipayers,df_edipartners,df_edipartnertypes,df_hospinsurancecodes,hdfs_scratch):
    df_ghic.createOrReplaceTempView("globalmrnxhospinsurancecodes")
    df_edipayers.createOrReplaceTempView("edipayers")
    df_edipartners.createOrReplaceTempView("edipartners")
    df_edipartnertypes.createOrReplaceTempView("edipartnertype")
    df_hospinsurancecodes.createOrReplaceTempView("hospinsurancecodes")
    df_kc_accounts = spark.sql(""" select ghic.globalmrnxhospinsurancecodespk,
                                          ghic.globalmrnifk,
                                          ghic.patientacctifk candidatepatientacctifk,
                                          ghic.hospitalfk as candidatehospitalfk,
                                          ghic.inspolicyid as coverageid,
                                          ghic.createdate as ghiccreatedate,
                                          pp.edipartnerpk,
                                          pp.edipartnertypefk,
                                          pp.allowknownmedicaidqueriesflag,
                                          case when h.mcaid =1 then 1 else 0 end ismanagedmedicaid
                                    from globalmrnxhospinsurancecodes ghic 
                                    join hospinsurancecodes h on h.hospitalfk = ghic.hospitalfk and ghic.insurancecode = h.code
                                    join edipayers p on p.edipayerpk = h.edipayerfk
                                    join edipartners pp on pp.edipayerfk = p.edipayerpk
                                    join edipartnertype pt on pt.edipartnertypepk = pp.edipartnertypefk
                                    where ((pt.iscommercial=1) or (pt.istricare=1))
                                    """)
    writeparquet(spark,df_kc_accounts,hdfs_scratch+'/kc/kcaccounts/',200,'overwrite') 

# COMMAND ----------

def get_permid_data(spark,hdfs_permid_input): 
    df_permid = readparquet(spark, hdfs_permid_input,"0","na")
    df_permid = df_permid.where((df_permid.matchind=='IM') | (df_permid.matchind=='M1'))
    return df_permid

# COMMAND ----------

# get last 2 days worth of data from ghic and get associated patientaccts based on gmrn and permid

ghiccols = ["globalmrnxhospinsurancecodespk","hospitalfk","patientacctifk","insurancecode","globalmrnifk","inspolicyid","createdate"]
   
df_ghic = extract_parquet_data(spark, gmrn_publish + "/globalmrnxhospinsurancecodes/current/*",ghiccols)
df_ghic = df_ghic.filter(df_ghic.createdate >= date_sub(current_date(), 2))
  
hospinscols = ["hospitalfk","code","edipayerfk","mcaid"]
df_hospinsurancecodes = extract_parquet_data(spark, hdfs_input + "/hospinsurancecodes/current/*",hospinscols)
df_edipayers = extract_parquet_data(spark, hdfs_input + "/edipayers/current/*",["edipayerpk"])
partnercols = ["edipayerfk","edipartnerpk","edipartnertypefk","allowknownmedicaidqueriesflag"]
df_edipartners = extract_parquet_data(spark, hdfs_input + "/edipartners/current/*",partnercols)
df_edipartnertypes = extract_parquet_data(spark, hdfs_input + "/edipartnertype/current/*")
  
get_kc_accounts(spark,df_ghic,df_edipayers,df_edipartners,df_edipartnertypes,df_hospinsurancecodes,hdfs_scratch)

# after getting kc accounts, get associated gmrn/permid and their associated accounts
df_gmrnxpaccts = extract_parquet_data(spark,gmrn_publish + "/globalmrnxpacct/current/*")
df_permid = get_permid_data(spark,hdfs_permid_input)
get_gmrn_permid_by_patientacct(spark,df_permid,df_gmrnxpaccts,hdfs_scratch)

# Get hospattribute values and filter for selfpay accounts
df_hospitalattributes = extract_parquet_data(spark, hdfs_input + "/hospitalattributes/current/*")
df_hospitalattributevalues = extract_parquet_data(spark, hdfs_input + "/hospitalattributevalues/current/*")
df_hospattributes_hospattributevalues = hospattributes(spark,df_hospitalattributes,df_hospitalattributevalues)

# Filter selfpay accounts
df_gmrn_permid_patients = extract_parquet_data(spark,hdfs_scratch+"/kc/gmrn_permid/*")
vsnapcols = ["patientacctifk","hospitalfk","knownmcaidflag","primarymcaidflag","hasmedicareflag","knowntricareflag","secondarymcaid_afterinsuranceflag"]
#df_vsnappatientacctsflags = extract_parquet_data(spark, hdfs_input + "/vsnappatientacctsflags/current/20991231/", vsnapcols)
df_vsnappatientacctsflags = extract_deltalake_data(spark, hdfs_input + "/vsnappatientacctsflags/current/20991231/", vsnapcols)
df_vsnappatientacctsflags = df_vsnappatientacctsflags.withColumn('patientacctifk', df_vsnappatientacctsflags.patientacctifk.cast("long"))
df_paccts_selfpay_knownmcaid = getcandidateacctsfilter\
    (spark,df_gmrn_permid_patients,df_hospattributes_hospattributevalues,df_vsnappatientacctsflags)
writeparquet(spark,df_paccts_selfpay_knownmcaid,hdfs_scratch+'/kc/patientaccts_kc_with_selfpay/',200,'overwrite')

df_ca = extract_parquet_data(spark,hdfs_scratch+'/kc/patientaccts_kc_with_selfpay/*')
pa_col = ["patientacctipk","hospitalfk","firstname","middlename","lastname","ssn","dob","gender","state","admitdate","referraldate","dischargedate",\
    "demographicsupdatedate","medicalrecnum","clusteredacctfk","totalcharges","createdate","updatedate"]
#df_patientaccts_all = extract_parquet_data(spark,hdfs_input + "/patientaccts/current/20991231/",pa_col)
df_patientaccts_all = extract_deltalake_data(spark,hdfs_input + "/patientaccts/current/20991231/",pa_col)
df_patientaccts_all = df_patientaccts_all.filter(df_patientaccts_all.admitdate >= date_sub(current_date(), 365))
get_patientacct_demographics(spark,df_patientaccts_all,df_ca,hdfs_scratch)

df_capaccts = extract_parquet_data(spark,hdfs_scratch+'/kc/patientdemographics/*')

# check admit date and total charges for self pay accounts
hospcols = ["hcsystemfk", "hospitalpk","allowaggregationoutflag","allowaggregationinflag","active"]
df_hospitals = extract_parquet_data(spark,hdfs_input + "/hospitals/current/*",hospcols)
df_admitdate = extract_parquet_data(spark, hdfs_admitdatelookup)
df_hospadmitdate = df_hospitals.join(df_admitdate, df_admitdate.hospitalfk == df_hospitals.hospitalpk)\
    .filter(df_hospitals.active == '1').select(df_admitdate['*'])
df_patientaccts_admitdt = getpatientacctswithadmitdt(spark, df_capaccts, df_hospadmitdate) 
df_patientaccts_admitdt = df_patientaccts_admitdt.withColumn("createdate",df_patientaccts_admitdt.createdate.cast("timestamp"))\
    .withColumn("updatedate",df_patientaccts_admitdt.updatedate.cast("timestamp"))\
    .withColumn("candidatehospitalfk",df_patientaccts_admitdt.candidatehospitalfk.cast("int"))
writeparquet(spark,df_patientaccts_admitdt,hdfs_scratch+'/all_candidates/kc/',200,'overwrite')