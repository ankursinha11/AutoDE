# Databricks notebook source
dbutils.widgets.text("hdfs_input","")
dbutils.widgets.getArgument("hdfs_input")
hdfs_input= getArgument("hdfs_input")

dbutils.widgets.text("hdfs_all_leads","")
dbutils.widgets.getArgument("hdfs_all_leads")
hdfs_all_leads= getArgument("hdfs_all_leads")

dbutils.widgets.text("hdfs_lsbleads","")
dbutils.widgets.getArgument("hdfs_lsbleads")
hdfs_lsbleads= getArgument("hdfs_lsbleads")


dbutils.widgets.text("hdfs_scratch","")
dbutils.widgets.getArgument("hdfs_scratch")
hdfs_scratch= getArgument("hdfs_scratch")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("hdfs_output","")
dbutils.widgets.getArgument("hdfs_output")
hdfs_output= getArgument("hdfs_output")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

# COMMAND ----------


if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

hdfs_all_leads = baseurl+hdfs_all_leads+bc
hdfs_input = baseurl+hdfs_input
hdfs_lsbleads = baseurl+hdfs_lsbleads+bc+'/lsb_lookedup_leads/all/'
hdfs_scratch = baseurl+hdfs_scratch+bc
hdfs_output = baseurl+hdfs_output+bc

print("bc:",bc)
print("hdfs_all_leads:",hdfs_all_leads)
print("hdfs_input:",hdfs_input)
print("hdfs_lsbleads:",hdfs_lsbleads)
print("hdfs_scratch:",hdfs_scratch)
print("hdfs_output:",hdfs_output)

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
import datetime
import os
import subprocess
from pyspark import SparkContext
from pyspark.conf import SparkConf

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

def filter_ifexists_lsb(spark,df_lsbleads,df_leads_all,hdfs_scratch,hdfs_output,df_hosp,df_hcsystem):
    df_lsbleads = df_lsbleads.withColumn('lsb_hospitalfk',explode(col("lsb_hospitalfklst"))).drop("lsb_hospitalfklst")  
    df_check_aggr = check_wallingoff(spark,df_lsbleads,df_hosp,df_hcsystem) 
    df_leads = df_leads_all.join(df_check_aggr, ((df_leads_all.hdp_demographicshash == df_check_aggr.hdp_demographicshash) & \
                                (df_leads_all.lsb_edipartnerfk==df_check_aggr.lsb_edipartnerfk)),"left_anti")
    writeparquet(spark,df_leads,hdfs_output,200,'overwrite')

# COMMAND ----------

def check_wallingoff(spark, all_leads,df_hosp, df_hcsystem):    
    df_hosp.createOrReplaceTempView("hospitals")
    df_hcsystem.createOrReplaceTempView("hcsystems")
    all_leads.createOrReplaceTempView("leads")
    leadsql = """select a.*
                  from leads a
                  left join hospitals h on a.selfpay_hospitalfk = h.hospitalpk
                  left join hcsystems hc on h.hcsystemfk = hc.hcsystempk
                  left join hospitals h2 on a.lsb_hospitalfk = h2.hospitalpk
                  left join hcsystems hc2 on h2.hcsystemfk = hc2.hcsystempk 
                  where ((h.hcsystemfk = h2.hcsystemfk) or (a.lsb_source='ich') or
                  (coalesce(h.allowaggregationinflag ,hc.allowaggregationinflag ,1)=1
                  and coalesce(h2.allowaggregationoutflag, hc2.allowaggregationoutflag,1) = 1))"""
    leads = spark.sql(leadsql)
    return leads

# COMMAND ----------

hospcols = ["hcsystemfk", "hospitalpk", "allowaggregationinflag", "allowaggregationoutflag" ]
df_hosp = extract_parquet_data(spark, hdfs_input + "/hospitals/current/*", hospcols)
df_hosp = df_hosp.withColumn("allowaggregationoutflag",blank_as_null("allowaggregationoutflag"))\
    .withColumn("allowaggregationinflag",blank_as_null("allowaggregationinflag"))
hccols = ["hcsystempk", "allowaggregationinflag", "allowaggregationoutflag"]
df_hcsystem = extract_parquet_data(spark, hdfs_input + "/hcsystems/current/*", hccols)
df_hcsystem = df_hcsystem.withColumn("allowaggregationoutflag",blank_as_null("allowaggregationoutflag"))\
    .withColumn("allowaggregationinflag",blank_as_null("allowaggregationinflag"))
df_lsbleads = extract_parquet_data(spark,hdfs_lsbleads)
df_all_leads = extract_parquet_data(spark,hdfs_all_leads)
filter_ifexists_lsb(spark,df_lsbleads,df_all_leads,hdfs_scratch,hdfs_output,df_hosp,df_hcsystem) 