# Databricks notebook source
dbutils.widgets.text("hdfs_input","")
dbutils.widgets.getArgument("hdfs_input")
hdfs_input= getArgument("hdfs_input")

dbutils.widgets.text("hdfs_leads_input","")
dbutils.widgets.getArgument("hdfs_leads_input")
hdfs_leads_input= getArgument("hdfs_leads_input")

dbutils.widgets.text("hdfs_admitdt_path","")
dbutils.widgets.getArgument("hdfs_admitdt_path")
hdfs_admitdt_path= getArgument("hdfs_admitdt_path")


dbutils.widgets.text("hdfs_scratch","")
dbutils.widgets.getArgument("hdfs_scratch")
hdfs_scratch= getArgument("hdfs_scratch")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("hdfs_output","")
dbutils.widgets.getArgument("hdfs_output")
hdfs_output= getArgument("hdfs_output")

dbutils.widgets.text("hdfs_output2","")
dbutils.widgets.getArgument("hdfs_output2")
hdfs_output2= getArgument("hdfs_output2")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("hdfs_maprdb_input","")
dbutils.widgets.getArgument("hdfs_maprdb_input")
hdfs_maprdb_input= getArgument("hdfs_maprdb_input")

# COMMAND ----------


if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

hdfs_admitdt_path = baseurl+hdfs_admitdt_path+bc
hdfs_leads_input = baseurl+hdfs_leads_input+bc
hdfs_input = baseurl+hdfs_input
hdfs_maprdb_input = baseurl+hdfs_maprdb_input
hdfs_scratch = baseurl+hdfs_scratch+bc
hdfs_output = baseurl+hdfs_output+bc
hdfs_output2 = baseurl+hdfs_output2+bc+'-LV'

print("bc:",bc)
print("hdfs_admitdt_path:",hdfs_admitdt_path)
print("hdfs_input:",hdfs_input)
print("hdfs_leads_input:",hdfs_leads_input)
print("hdfs_scratch:",hdfs_scratch)
print("hdfs_output:",hdfs_output)
print("hdfs_maprdb_input:",hdfs_maprdb_input)
print("hdfs_output2:",hdfs_output2)

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
import datetime
from configparser import SafeConfigParser
from functools import reduce
from pyspark.sql import DataFrame

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

# MAGIC %run /Insleads-code/LeadDiscovery/common/process_leads

# COMMAND ----------

def update_leads_in_pacctcommercialhelper(spark,leads,bc,hdfs_output):
    leads.createOrReplaceTempView('all_leads')
    paccthelpers = spark.sql(""" select lsb_edipartnerfk as edipartnerfk,hospitalfk,patientacctifk,lsb_coverageid as coverageid,
                                 firstname,lastname,dob,ssn,demohash as demographicshash 
                                 from all_leads""")
    paccthelpers = get_hdp_demographicshash(spark,paccthelpers)
    paccthelpers = paccthelpers.dropDuplicates()
    writeparquet(spark,paccthelpers,hdfs_output,200,'overwrite')

# COMMAND ----------

def run_checkmode(spark,leads,hdfs_scratch):
    leads = leads.filter(leads.lsb_edipartnerfk.isin([65]))
    writeparquet(spark,leads,hdfs_scratch+'/runcheckmode/',200,'overwrite')

# COMMAND ----------

def get_all_leads_cols(spark,hdfs_leads_input,bc):
    all_leads = extract_parquet_data(spark, hdfs_leads_input)
    all_leads = all_leads.withColumn('associationsource', when(col("keyname") == "globalmrnifk", 'GM'). \
                                     when(col("keyname") == "permid", 'PI'))
    all_leads = all_leads.withColumn('keyvalue', when(col("keyname") == "globalmrnifk", 1). \
                                     when(col("keyname") == "permid", 2))
    all_leads = all_leads.withColumn("breadcrumb",lit(bc))\
                         .withColumn("npi",lit(""))  \
                         .withColumn("usefamilydataflag",lit(0))\
                         .withColumn("edidatasourcetablekey",lit(all_leads.lsb_id))\
                         .withColumn("totalcharges",all_leads.totalcharges.cast("float"))
    return all_leads

# COMMAND ----------

def get_edidatasourcefk(spark,all_leads, hdfs_maprdb_input):
    #df = spark.loadFromMapRDB(hdfs_maprdb_input)
    df = spark.read.parquet(hdfs_maprdb_input)
    leads = all_leads.join(df, (upper(all_leads.lsb_leadsource) == upper(df.leaddatasource)) & \
                      (upper(all_leads.lsb_xrefsource) == upper(df.leadsource)) & \
                      (upper(all_leads.associationsource) == upper(df.associationsource)),"left") \
        .select(all_leads['*'], df.edidatasourcefk)
    return leads

# COMMAND ----------

leads = get_all_leads_cols(spark,hdfs_leads_input,bc)
 #Filter out blacklisted Policy Id's
blcol = ["edipartnerfk", "coverageid"]
blacklist_accts = extract_parquet_data(spark, hdfs_input + "/partnerpolicyidblacklists/current/*", blcol)
all_leads_nbl = filter_blacklisted_partnerpolicyid(spark, leads, blacklist_accts, hdfs_input, hdfs_scratch)
writeparquet(spark,all_leads_nbl,hdfs_scratch + "/all_leads_nbl",200,"overwrite")
all_leads_nbl_tmp = readparquet(spark, hdfs_scratch + "/all_leads_nbl/", "0","na")
run_checkmode(spark,all_leads_nbl_tmp,hdfs_scratch)
leads_filtered = extract_parquet_data(spark,hdfs_scratch+'/runcheckmode/')
a_count = len(leads_filtered.head(1))
ret_val = 0
if (a_count==0):
    print("Transition flag : 0 and No config found for hospital-edipartner combo")
    #exit()
else:
    all_leads_len_admitdt = filter_coverageid_len_admitdt(spark,leads_filtered,hdfs_admitdt_path,hdfs_scratch)
    all_leads_hpn = filter_ifhpn_notenabled(spark, all_leads_len_admitdt,hdfs_input,hdfs_scratch) 
    all_leads = get_edidatasourcefk(spark,all_leads_hpn, hdfs_maprdb_input)
    df_hosp = extract_parquet_data(spark,hdfs_input+"/hospitals/current/*")
    all_leads = all_leads.join(df_hosp, all_leads.hospitalfk == df_hosp.hospitalpk).select(all_leads["*"],df_hosp.hospitalname)
    update_leads_in_pacctcommercialhelper(spark,all_leads,bc,hdfs_output)
    #writeparquet(spark,all_leads,hdfs_scratch+"/processleads",200,'overwrite')
    writeparquet(spark,all_leads,hdfs_output2,200,'overwrite')
    if (all_leads.isEmpty()):
        ret_val = 0
    else:
        ret_val = 1

# COMMAND ----------

dbutils.notebook.exit(ret_val)