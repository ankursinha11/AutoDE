# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import datetime

# COMMAND ----------

# DBTITLE 1,input parameters
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("hdfs_input","")
dbutils.widgets.getArgument("hdfs_input")
hdfs_input= getArgument("hdfs_input")

dbutils.widgets.text("hdfs_output","")
dbutils.widgets.getArgument("hdfs_output")
hdfs_output= getArgument("hdfs_output")

dbutils.widgets.text("hdfs_lsb_cooked","")
dbutils.widgets.getArgument("hdfs_lsb_cooked")
hdfs_lsb_cooked= getArgument("hdfs_lsb_cooked")

dbutils.widgets.text("hdfs_scratch","")
dbutils.widgets.getArgument("hdfs_scratch")
hdfs_scratch= getArgument("hdfs_scratch")

# COMMAND ----------

# bc = "20250623T01"
# container = "prod-icd-stg-adls"
# hdfs_input = "/data/dataingestion/publish"
# hdfs_lsb_cooked = "/data/leadservicebase/publish/cooked/leadservicebasehelper/"
# hdfs_output = "/data/leaddiscovery/transform/output/leadverify/leads/"
# hdfs_scratch = "/data/leaddiscovery/transform/scratch/leadverify/"
# storageaccount = "prodicdstgdls"
# user = "vishnup"

# COMMAND ----------


if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

hdfs_lsb_cooked = baseurl+hdfs_lsb_cooked
hdfs_input = baseurl+hdfs_input
hdfs_output = baseurl+hdfs_output+bc
hdfs_scratch = baseurl+hdfs_scratch+bc

print("bc:",bc)
print("hdfs_lsb_cooked:",hdfs_lsb_cooked)
print("hdfs_input:",hdfs_input)
print("hdfs_output:",hdfs_output)
print("hdfs_scratch:",hdfs_scratch)

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))
spark.conf.set("spark.sql.shuffle.partitions", "auto")

# COMMAND ----------

# MAGIC %run ../../Common-Util/common_util

# COMMAND ----------

# MAGIC %run ../../Common-Util/tu_data_quality

# COMMAND ----------

def filter_invalid_selfpayaccount(spark,hdfs_scratch):
    ca = extract_parquet_data(spark,hdfs_scratch+'/hospallowed/*')
    isValidSSN_udf    = udf(isValidSSN, IntegerType())
    isValidMRN_udf    = udf(isValidMRN, IntegerType())
    isValidPID_udf    = udf(isValidPID, IntegerType())
    isValidNumber_udf = udf(isNumber, IntegerType())

    ca = ca.withColumn("globalmrnifk_valid", isValidNumber_udf(ca.globalmrnifk))
    ca = ca.withColumn("ssn_valid", isValidSSN_udf(ca.ssn))
    ca = ca.withColumn("permid_valid", isValidPID_udf(ca.permid))
    ca = ca.withColumn("medicalrecnum_valid", isValidMRN_udf(ca.medicalrecnum))
    ca = ca.withColumn("clusteredacctfk_valid", isValidNumber_udf(ca.clusteredacctfk.cast(StringType())))

    # check atleast one of it is valid in ssn, permid, medicalrecnum, clusteredacctfk

    ca = ca.where((ca.globalmrnifk_valid == 1) | (ca.ssn_valid == 1) | (ca.permid_valid == 1) | (
                    ca.medicalrecnum_valid == 1) | (ca.clusteredacctfk_valid == 1))
    writeparquet(spark,ca,hdfs_scratch+'/candidates_with_validflags/',0,'overwrite')

# COMMAND ----------

def filter_knowncommerical_ohiselfpay(spark,df_edipartnertype,df_hospitalpayercob,df_patientaccts_all,hdfs_output,hdfs_scratch):
    df_edipartnerfk = extract_parquet_data(spark,hdfs_scratch+'/candidates_with_validflags/*')
    df_edipartnerfk = df_edipartnerfk.withColumn('demohash', hash(concat_ws(":", df_edipartnerfk.firstname, df_edipartnerfk.middlename, df_edipartnerfk.lastname, df_edipartnerfk.dob, df_edipartnerfk.ssn, df_edipartnerfk.state)))
    df_candidates = get_hdp_demographicshash(spark,df_edipartnerfk)
    df_candidates.createOrReplaceTempView("candidates")
    df_edipartnertype.createOrReplaceTempView("edipartnertype")
    df_hospitalpayercob.createOrReplaceTempView("hospitalpayercob")
    df_patientaccts_all.createOrReplaceTempView("patientaccts")

    df_knowncommercial = spark.sql("""select c.patientacctifk as selfpay_patientacctifk,
                                             c.hospitalfk as selfpay_hospitalfk,
                                             p.patientacctipk as patientacctifk,
                                             p.hospitalfk,
                                             c.firstname,
                                             c.middlename,
                                             c.lastname,
                                             c.ssn,
                                             concat('S_',c.ssn,'_',c.edipartnerpk,'_',c.coverageid) as ssn_id,
                                             concat('MH_',c.hospitalfk,'_',c.medicalrecnum,'_',c.edipartnerpk,'_',c.coverageid) as mrn_id,
                                             concat('CH_',c.hospitalfk,'_',c.clusteredacctfk,'_',c.edipartnerpk,'_',c.coverageid) as ch_id,
                                             concat('G_',c.globalmrnifk,'_',c.edipartnerpk,'_',c.coverageid) as gmrn_id,
                                             concat('P_',c.permid,'_',c.edipartnerpk,'_',c.coverageid) as permid_id,
                                             c.dob,
                                             c.gender,
                                             c.state,
                                             c.admitdate,
                                             c.referraldate,
                                             c.dischargedate,
                                             c.demographicsupdatedate,
                                             c.medicalrecnum,
                                             c.clusteredacctfk,
                                             c.totalcharges,
                                             c.createdate,
                                             c.updatedate,
                                             c.knowntricareflag,
                                             c.knownmcaidflag,
                                             c.ismanagedmedicaid,
                                             c.edipartnerpk as lsb_edipartnerfk,
                                             c.coverageid as lsb_coverageid,
                                             c.hcsystemfk as lsb_hcsystemfk,
                                             'LV' as lsb_source,
                                             c.globalmrnxhospinsurancecodespk as lsb_id,
                                             c.ghiccreatedate as lsb_leadcreatedate,
                                             c.ghiccreatedate as lsb_leadupdatedate,
                                             c.lsb_identity ,
                                             c.candidatehospitalfk as lsb_hospitalfklst,
                                             'LV' as lsb_leadsource,
                                             'RE' as lsb_xrefsource,
                                              p.firstname as lsb_firstname,
                                             p.lastname as lsb_lastname,
                                             p.dob as lsb_dob,
                                             p.middlename as lsb_middlename,
                                             p.gender as lsb_gender,
                                             p.ssn as lsb_ssn,
                                             p.state as lsb_state,
                                             p.demographicsupdatedate as lsb_demoupdatedate,
                                             c.keyname,
                                             c.keyvalue,
                                             c.globalmrnifk,
                                             c.permid,
                                             CASE WHEN isnull(hpc.hospitalfk) THEN 0 ELSE 1 end as selfpay_isohi,
                                             hdp_demographicshash,
                                             demohash,
					     p.medicarehic,
					     p.medicaidnum
                                             from candidates c
                                             inner join patientaccts p on p.patientacctipk = c.candidatepatientacctifk and p.hospitalfk = c.candidatehospitalfk
                                             join edipartnertype pt on pt.edipartnertypepk = c.edipartnertypefk
                                             left join hospitalpayercob hpc ON c.candidatehospitalfk = hpc.hospitalfk
                                      where ((pt.iscommercial=1) or (pt.istricare=1))""")

    df_knowncommercial = df_knowncommercial.withColumn("rn", row_number()\
                         .over(Window.partitionBy(df_knowncommercial.lsb_edipartnerfk,df_knowncommercial.hdp_demographicshash)\
                         .orderBy(df_knowncommercial.keyvalue)))
    df_knowncommercial = df_knowncommercial.filter("rn = 1").drop("rn")
    writeparquet(spark,df_knowncommercial,hdfs_scratch+'/knowncommercial/',0,'overwrite')
    cond = when(\
                 ( (col("selfpay_isohi")== 1) & (col("ismanagedmedicaid") == 1) )\
                 ,lit(0)\
                 )\
         .otherwise(lit(1))
    df_filterohi = extract_parquet_data(spark,hdfs_scratch+'/knowncommercial/*')
    df_filterohi = df_filterohi.withColumn('includelead',cond)
    df_filterohi = df_filterohi.where(df_filterohi.includelead == 1).drop("includelead")
    df_filterohi = df_filterohi.dropDuplicates()
    writeparquet(spark,df_filterohi,hdfs_output,0,'overwrite')

# COMMAND ----------

def lsb_cooked_lookup(spark,df_lsb,df_leads,hdfs_lsb_lookup):

    df_leads.createOrReplaceTempView('leads')
    df_lsb.createOrReplaceTempView('lsb')

    df_ssn = spark.sql("""select selfpay_patientacctifk,selfpay_hospitalfk ,ssn_id as _id, 'ssn' as lookupkey,hdp_demographicshash,'1' as all_valid
                          from leads left join lsb on leads.ssn_id = lsb._id where lsb._id is not null """)
    #writeparquet(spark,df_ssn,hdfs_lsb_lookup,200,'overwrite')
    df_gmrn = spark.sql("""select selfpay_patientacctifk,selfpay_hospitalfk ,gmrn_id as _id, 'gmrnik' as lookupkey,hdp_demographicshash,'1' as all_valid
                          from leads left join lsb on leads.gmrn_id = lsb._id where lsb._id is not null """)
    #writeparquet(spark,df_gmrn,hdfs_lsb_lookup,200,'append')
    df_permid = spark.sql("""select selfpay_patientacctifk,selfpay_hospitalfk , permid_id as _id, 'permid' as lookupkey,hdp_demographicshash,'1' as all_valid
                          from leads left join lsb on leads.permid_id = lsb._id where lsb._id is not null """)
    #writeparquet(spark,df_permid,hdfs_lsb_lookup,200,'append')
    df_mrn = spark.sql("""select selfpay_patientacctifk,selfpay_hospitalfk ,mrn_id as _id, 'mrn' as lookupkey,hdp_demographicshash,'1' as all_valid
                          from leads left join lsb on leads.mrn_id = lsb._id where lsb._id is not null """)
    #writeparquet(spark,df_mrn,hdfs_lsb_lookup,200,'append')
    df_ch = spark.sql("""select selfpay_patientacctifk,selfpay_hospitalfk ,ch_id as _id, 'ch' as lookupkey,hdp_demographicshash,'1' as all_valid
                          from leads left join lsb on leads.ch_id = lsb._id where lsb._id is not null """)
    df_lsb_lookup = df_ssn.union(df_gmrn).union(df_permid).union(df_mrn).union(df_ch)
    writeparquet(spark,df_lsb_lookup,hdfs_lsb_lookup,0,'overwrite')

# COMMAND ----------

def filter_hospitalwallingoff(spark,df_hospitals,df_hcsystems,df_candidates,hdfs_scratch):
    df_hospitals = df_hospitals.withColumn("allowaggregationoutflag",blank_as_null("allowaggregationoutflag"))
    df_hcsystems = df_hcsystems.withColumn("allowaggregationoutflag",blank_as_null("allowaggregationoutflag"))
    df_hospitals = df_hospitals.withColumn("allowaggregationinflag",blank_as_null("allowaggregationinflag"))
    df_hcsystems = df_hcsystems.withColumn("allowaggregationinflag",blank_as_null("allowaggregationinflag"))
    df_hospitals.createOrReplaceTempView("hospitals")
    df_hcsystems.createOrReplaceTempView("hcsystems")
    df_candidates.createOrReplaceTempView('candidates')
    df_ca = spark.sql("""select c.* ,h.hcsystemfk
                         from candidates c
                         join hospitals h on c.hospitalfk = h.hospitalpk
                         join hcsystems hc on h.hcsystemfk = hc.hcsystempk
                         join hospitals h2 on c.candidatehospitalfk = h2.hospitalpk
                         join hcsystems hc2 on h2.hcsystemfk = hc2.hcsystempk
                   where (( coalesce(h.allowaggregationinflag ,hc.allowaggregationinflag ,1)=1
                         and coalesce(h2.allowaggregationoutflag, hc2.allowaggregationoutflag,1)=1
                        ) or h2.hcsystemfk = h.hcsystemfk) """)
    writeparquet(spark,df_ca,hdfs_scratch+'/hospallowed/',0,'overwrite')

# COMMAND ----------

hospcols = ["hcsystemfk", "hospitalpk","allowaggregationoutflag","allowaggregationinflag","active"]
df_hospitals = extract_parquet_data(spark,hdfs_input + "/hospitals/current/*",hospcols)
hccols = ["hcsystempk","allowaggregationoutflag","allowaggregationinflag"]
df_hcsystems = extract_parquet_data(spark, hdfs_input + "/hcsystems/current/*", hccols)
df_candidates = extract_parquet_data(spark,hdfs_scratch+'/all_candidates/*')
filter_hospitalwallingoff(spark,df_hospitals,df_hcsystems,df_candidates,hdfs_scratch)

filter_invalid_selfpayaccount(spark,hdfs_scratch)
pa_col = ["patientacctipk","hospitalfk","firstname","middlename","lastname","ssn","dob","gender","state","admitdate","referraldate","dischargedate",\
  "demographicsupdatedate","medicalrecnum","clusteredacctfk","totalcharges","createdate","updatedate", "medicarehic", "medicaidnum"]
df_patientaccts_all = extract_deltalake_data(spark,hdfs_input + "/patientaccts/current/20991231/",pa_col) 
df_patientaccts_all = df_patientaccts_all.filter(df_patientaccts_all.admitdate >= date_sub(current_date(), 365)) 
df_edipartnertypes = extract_parquet_data(spark, hdfs_input + "/edipartnertype/current/*")
df_hospitalpayercob = extract_parquet_data(spark,hdfs_input + "/hospitalpayercob/current/*",["hospitalfk","edipayerfk"])

# Filter out ohi self pay accounts and commerical accounts
filter_knowncommerical_ohiselfpay(spark,df_edipartnertypes,df_hospitalpayercob,df_patientaccts_all,hdfs_output,hdfs_scratch)

# create a copy of helpers to look up in lsb
lsbcol = ["lookupvalue", "_id"]
df_lsb_cooked = extract_parquet_data(spark,hdfs_lsb_cooked,lsbcol)
leadcol = ["ssn_id","mrn_id","ch_id","gmrn_id","permid_id","selfpay_hospitalfk","selfpay_patientacctifk","lsb_edipartnerfk","lsb_coverageid","hdp_demographicshash"]
df_leads = extract_parquet_data(spark,hdfs_output,leadcol)
df_lsb_cooked = df_lsb_cooked.dropDuplicates()
df_leads = df_leads.dropDuplicates()
lsb_cooked_lookup(spark,df_lsb_cooked,df_leads,hdfs_scratch +'/lsb_lookup_leads/')  
