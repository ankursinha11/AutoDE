# Databricks notebook source
#   Vineela Tatineni
#   05/21/2019
#   This pyspark script is used to get candidate accounts which do not have medicarehic and are either self pay or knownmcare
#   modified globalmrn_swift check of entire directory
#   Revision History:
#     afshaik|20220215|US552939-Extract additional columns from patientaccts
#     afshaik|20220405|US586332-code optimization

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/tu_data_quality

# COMMAND ----------

# MAGIC %run /Insleads-code/LeadDiscovery/common/get_candidate_patientaccts

# COMMAND ----------

dbutils.widgets.text("cdd_publish_path","")
dbutils.widgets.getArgument("cdd_publish_path")
cdd_publish_path= getArgument("cdd_publish_path")

dbutils.widgets.text("dataingestion_publish_path","")
dbutils.widgets.getArgument("dataingestion_publish_path")
dataingestion_publish_path= getArgument("dataingestion_publish_path")

dbutils.widgets.text("gmrn_publish_path","")
dbutils.widgets.getArgument("gmrn_publish_path")
gmrn_publish_path= getArgument("gmrn_publish_path")

dbutils.widgets.text("leaddiscovery_transform_path","")
dbutils.widgets.getArgument("leaddiscovery_transform_path")
leaddiscovery_transform_path= getArgument("leaddiscovery_transform_path")

dbutils.widgets.text("notificationtype","")
dbutils.widgets.getArgument("notificationtype")
notificationtype= getArgument("notificationtype")

dbutils.widgets.text("lead_mode_flag","")
dbutils.widgets.getArgument("lead_mode_flag")
lead_mode_flag= getArgument("lead_mode_flag")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

print("bc="+str(bc))
print("cdd_publish_path="+str(cdd_publish_path))
print("container="+str(container))
print("dataingestion_publish_path="+str(dataingestion_publish_path))
print("gmrn_publish_path="+str(gmrn_publish_path))
print("lead_mode_flag="+str(lead_mode_flag))
print("leaddiscovery_transform_path="+str(leaddiscovery_transform_path))
print("notificationtype="+str(notificationtype))
print("storageaccount="+str(storageaccount))
print("user="+str(user))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

cdd_publish_path = baseurl+cdd_publish_path
dataingestion_publish_path = baseurl+dataingestion_publish_path
gmrn_publish_path = baseurl+gmrn_publish_path
leaddiscovery_transform_path = baseurl+leaddiscovery_transform_path

candidatepa_path = leaddiscovery_transform_path + notificationtype + '/candidatepa/'+bc+'/'
hdfs_admitdatelookup=leaddiscovery_transform_path+notificationtype+'/minmaxbyhospital/'+bc+'/*'
hdfs_scratch=leaddiscovery_transform_path+notificationtype+'/leadstatus/'+bc+'/'
pa_path=leaddiscovery_transform_path+notificationtype+'/patientaccts/'

print("--------------------------------------------------------------------------------")
print("bc="+str(bc))
print("cdd_publish_path="+str(cdd_publish_path))
print("container="+str(container))
print("dataingestion_publish_path="+str(dataingestion_publish_path))
print("gmrn_publish_path="+str(gmrn_publish_path))
print("lead_mode_flag="+str(lead_mode_flag))
print("leaddiscovery_transform_path="+str(leaddiscovery_transform_path))
print("notificationtype="+str(notificationtype))
print("storageaccount="+str(storageaccount))
print("user="+str(user))
print("--------------------------------------------------------------------------------")
print("candidatepa_path="+str(candidatepa_path))
print("hdfs_admitdatelookup="+str(hdfs_admitdatelookup))
print("hdfs_scratch="+str(hdfs_scratch))
print("pa_path="+str(pa_path))

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
import datetime
import getpass
import os
import sys
import subprocess

# COMMAND ----------

user = getpass.getuser()
#print(user)
#spark = SparkSession.builder.appName("Leaddiscovery: get candidates").getOrCreate()
#spark.sparkContext.setLogLevel("ERROR")
#spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)

admitdate = readparquet(spark, hdfs_admitdatelookup, '0', 'na')
enddt = date_sub(current_date(), 10)

    # get hospital attributevalues
ha = readparquet(spark, dataingestion_publish_path + "/hospitalattributes/current/*", '0', 'na')
hav = readparquet(spark, dataingestion_publish_path + "/hospitalattributevalues/current/*", '0', 'na')
havalues = hospattributes(spark, ha, hav)

hiccolumns = ["hospinsurancecodepk", "hospitalfk", "code", "codedesc", "hospcodestatusfk" ,"mcare", "secondarytomcaid", "edipayerfk" ]
hic = extract_deltalake_data(spark, dataingestion_publish_path + "hospinsurancecodes/current/20991231/", hiccolumns)

patientacctcodescolumns = [ "patientacctifk", "hospitalfk", "insurancecode1", "insurancecode2", "insurancecode3"  ]
patientacctcodes =  extract_deltalake_data(spark, dataingestion_publish_path + "/patientacctscodes/current/20991231/", patientacctcodescolumns )

edipayers = readparquet(spark, dataingestion_publish_path + "/edipayers/current/20991231", "0", 'na')

vsnapcols = ["patientacctifk", "hospitalfk", "knownmcaidflag", "primarymcaidflag", "hasmedicareflag", "knowntricareflag", "secondarymcaid_afterinsuranceflag","createdate"]
vsnapflags = extract_deltalake_data(spark, dataingestion_publish_path + "/vsnappatientacctsflags/current/20991231/", vsnapcols)
vsnapflags = vsnapflags.join(admitdate, admitdate.hospitalfk == vsnapflags.hospitalfk).select(vsnapflags['*'])
vsnapflags = vsnapflags.withColumn('patientacctifk', vsnapflags.patientacctifk.cast("long"))
vsnapflags = vsnapflags.withColumnRenamed('createdate', 'vsnapflags_createdate')
vsnapflags = vsnapflags.withColumnRenamed('hospitalfk', 'vsnapflags_hospitalfk')

patientaccts = get_patientacct(spark, pa_path, lead_mode_flag, enddt,bc[:11], admitdate, vsnapflags)
#display(patientaccts.filter(patientaccts.patientacctipk == 3611312569))
    # apply all filters together to get final candidate acct list
if( lead_mode_flag == '1'):
    candidates = getcandidateacctsfilter_ll(spark, patientaccts, patientacctcodes, havalues, hic, edipayers )
else:
    candidates = getcandidateacctsfilter_coc(spark, patientaccts, vsnapflags)

writeparquet(spark, candidates, hdfs_scratch + "/tmpdata/pa_vsnapflags", 50, "overwrite")
candidates = readparquet(spark, hdfs_scratch + "/tmpdata/pa_vsnapflags", '0', 'na')
ca = get_globalmrn(spark, gmrn_publish_path, candidates, bc)
ca = get_permid(spark, cdd_publish_path, ca)
ca = check_valid_identities(spark, ca)
writeparquet(spark, ca, candidatepa_path, 10, "overwrite")