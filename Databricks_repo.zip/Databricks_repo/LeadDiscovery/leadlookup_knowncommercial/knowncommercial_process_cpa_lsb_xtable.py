# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("ip_cpa","")
dbutils.widgets.getArgument("ip_cpa")
ip_cpa= getArgument("ip_cpa")

dbutils.widgets.text("ip_lsb_id","")
dbutils.widgets.getArgument("ip_lsb_id")
ip_lsb_id= getArgument("ip_lsb_id")

dbutils.widgets.text("op_cpa_xlsbhelper","")
dbutils.widgets.getArgument("op_cpa_xlsbhelper")
op_cpa_xlsbhelper= getArgument("op_cpa_xlsbhelper")

# COMMAND ----------

dbutils.notebook.run("/Insleads-code/LeadDiscovery/common/cpa_lsb_xtable", 3600, {"bc":bc, "container":container, "ip_cpa":ip_cpa, "ip_lsb_id":ip_lsb_id, "op_cpa_xlsbhelper":op_cpa_xlsbhelper, "storageaccount":storageaccount, "user":user})