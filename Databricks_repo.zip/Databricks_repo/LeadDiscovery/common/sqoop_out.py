# Databricks notebook source
from pyspark.sql.functions import *

# COMMAND ----------

dbutils.widgets.text("tablename1","")
dbutils.widgets.getArgument("tablename1")
tablename1= getArgument("tablename1")

dbutils.widgets.text("tablename2","")
dbutils.widgets.getArgument("tablename2")
tablename2= getArgument("tablename2")

dbutils.widgets.text("path_conn_file", "")
dbutils.widgets.getArgument("path_conn_file")
path_conn_file= getArgument("path_conn_file")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("sqoop_output_path","")
dbutils.widgets.getArgument("sqoop_output_path")
sqoop_output_path= getArgument("sqoop_output_path")

dbutils.widgets.text("icddb","")
dbutils.widgets.getArgument("icddb")
icddb= getArgument("icddb")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")


dbutils.widgets.text("module","")
dbutils.widgets.getArgument("module")
module= getArgument("module")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# DBTITLE 1,set basepath
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user
print(baseurl)

# COMMAND ----------

if module =='': 
    module="regular" 
else: 
    module=module

print("module is : "+module)

# COMMAND ----------

if module =='aid':
    hdppatientacctxlead = spark.read.parquet(baseurl+sqoop_output_path+'/aid/'+bc +'/' + tablename1)
    hdppatientacctxleadbatch = spark.read.parquet(baseurl+sqoop_output_path+'/aid/'+bc +'/' + tablename2)
else :
    hdppatientacctxlead = spark.read.parquet(baseurl+sqoop_output_path+'/'+bc +'/' + tablename1)
    hdppatientacctxleadbatch = spark.read.parquet(baseurl+sqoop_output_path+'/'+bc +'/' + tablename2)
hdppatientacctxlead = hdppatientacctxlead.drop("createdate")

# COMMAND ----------

# DBTITLE 1,CHC Exception : zescantemp.dbo.hdppatientacctxlead_chc
# hdppatientacctxlead.createOrReplaceTempView("hdppatientacctxlead")
# hdppatientacctxlead_chc=spark.sql("""SELECT * FROM hdppatientacctxlead WHERE breadcrumb LIKE '%CH%'""")
# chc_count=hdppatientacctxlead_chc.count()
# if chc_count > 0:
#     print("CHC data FOUND : redirect to hdppatientacctxlead_chc")
#     hdppatientacctxlead_chc.write.format('jdbc').mode('append').option('driver', 'com.microsoft.sqlserver.jdbc.SQLServerDriver').option('url', path_conn_file).option('dbtable', "zescantemp.dbo.hdppatientacctxlead_chc").save()
#     hdppatientacctxleadbatch.write.format('jdbc').mode('append').option('driver', 'com.microsoft.sqlserver.jdbc.SQLServerDriver').option('url', path_conn_file).option('dbtable', icddb+tablename2).save()
#     exit(0)
# else :
#     print("NON CHC data FOUND ")

# COMMAND ----------

#path_conn_file ='jdbc:sqlserver://prod-icd-scus-icd-sqlmi-01.4ff1c6b32202.database.windows.net;user=hce9hdp;password=AT3qh&wu*k\%vFyE;trustServerCertificate=true'
#hdppatientacctxlead.count()


# COMMAND ----------

hdppatientacctxlead = hdppatientacctxlead.withColumn('totalcharges', hdppatientacctxlead.totalcharges.cast("decimal(32,2)").cast("string"))
hdppatientacctxlead.write.format('jdbc').mode('append').option('driver', 'com.microsoft.sqlserver.jdbc.SQLServerDriver').option('url', path_conn_file).option('dbtable', icddb+tablename1).save()

# COMMAND ----------

hdppatientacctxleadbatch.write.format('jdbc').mode('append').option('driver', 'com.microsoft.sqlserver.jdbc.SQLServerDriver').option('url', path_conn_file).option('dbtable', icddb+tablename2).save()
