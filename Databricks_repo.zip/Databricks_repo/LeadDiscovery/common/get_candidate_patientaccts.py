# Databricks notebook source
#   Vineela Tatineni
#   05/21/2019
#   This pyspark script is used to get candidate accounts which do not have medicarehic and are either self pay or knownmcare
#   modified globalmrn_swift check of entire directory
#   Revision History:
#     afshaik|20220215|US552939-Extract additional columns from patientaccts
#     afshaik|20220405|US586332-code optimization

# COMMAND ----------

def get_globalmrn(spark, hdfs_input, candidates, bc):
    gmrn = readparquet(spark, hdfs_input + "/globalmrnxpacct/current/*", '0', 'na')
    gmrn_swift_dir = hdfs_input + "globalmrnxpacct_swift/" + bc + "/"
    #proc_gmrn_swift = subprocess.Popen(['hadoop', 'fs', '-test', '-s', gmrn_swift_dir])
    #proc_gmrn_swift.communicate()
    returncode = 1
    try:
        dbutils.fs.ls(gmrn_swift_dir)
        returncode = 0
    except:
        returncode = 1

    #if proc_gmrn_swift.returncode != 0:
    if returncode != 0:
      print("no data in swift geting data from base gmrnpacct table")
      candidates = candidates.join(gmrn, (candidates.patientacctifk == gmrn.patientacctifk) & (candidates.hospitalfk == gmrn.hospitalfk), "left") \
            .select(candidates['*'], gmrn.globalmrnifk)
    else:
      print("getting  data from swift along with base table")
      gmrn_swift = readparquet(spark, hdfs_input + "globalmrnxpacct_swift/*/part*", '0', 'na').dropDuplicates()
      if not 'patientacctifk' in gmrn_swift.columns:
        gmrn_swift=gmrn_swift.withColumnRenamed("patientacctipk", "patientacctifk")
      if not 'globalmrnifk' in gmrn_swift.columns:
        gmrn_swift.createOrReplaceTempView("gmrn_swift")
        gmrn_swift=spark.sql("""SELECT *, gmrnid as globalmrnifk FROM gmrn_swift""")
      candidates_base = candidates.join(gmrn, (candidates.patientacctifk == gmrn.patientacctifk) & (candidates.hospitalfk == gmrn.hospitalfk), "left").select(candidates['*'], gmrn.globalmrnifk)
      candidates_excluded = candidates_base.filter(col("globalmrnifk").isNull())
      candidates_excluded = candidates_excluded.drop("globalmrnifk")
      candidates_found = candidates_base.filter(col("globalmrnifk").isNotNull())
      candidates_swift = candidates_excluded.join(gmrn_swift, (candidates_excluded.patientacctifk == gmrn_swift.patientacctifk) & (candidates_excluded.hospitalfk == gmrn_swift.hospitalfk), "left") \
            .select(candidates_excluded['*'], gmrn_swift.globalmrnifk)
      candidates = candidates_found.union(candidates_swift)
    return candidates.dropDuplicates()

# COMMAND ----------

# Get Permid and add to candidate accts
def get_permid(spark, hdfs_input, candidates):
    permid = readparquet(spark, hdfs_input + "permidpatientacctid/*", '0', 'na')
    permid = permid.where((permid.matchind=='IM') | (permid.matchind=='M1'))
    ca = candidates.join(permid,(candidates.patientacctifk==permid.patientacctifk) & (candidates.hospitalfk == permid.hospitalfk),"left").select(candidates['*'],permid.permid)
    return ca.dropDuplicates()

# COMMAND ----------

def check_valid_identities(spark, ca):
    # Validate Identity columns
    isValidSSN_udf    = udf(isValidSSN, IntegerType())
    isValidMRN_udf    = udf(isValidMRN, IntegerType())
    isValidPID_udf    = udf(isValidPID, IntegerType())
    isValidNumber_udf = udf(isNumber, IntegerType())

    ca = ca.withColumn("globalmrnifk_valid", isValidNumber_udf(ca.globalmrnifk))
    ca = ca.withColumn("ssn_valid", isValidSSN_udf(ca.ssn))
    ca = ca.withColumn("permid_valid", isValidPID_udf(ca.permid))
    ca = ca.withColumn("medicalrecnum_valid", isValidMRN_udf(ca.medicalrecnum))
    ca = ca.withColumn("clusteredacctfk_valid", isValidNumber_udf(ca.clusteredacctfk.cast(StringType())))

    # check atleast one of it is valid in ssn, permid, globalmrn, medicalrecnum, clusteredacctfk
    ca = ca.where((ca.globalmrnifk_valid == 1) | (ca.ssn_valid == 1) | (ca.permid_valid == 1) | (
                    ca.medicalrecnum_valid == 1) | (ca.clusteredacctfk_valid == 1))
    return ca

# COMMAND ----------

#getting the correct paacct based on lead mode
def get_patientacct(spark,pa_path,lead_mode_flag,enddt,bc,hospadmitdate,vsnapflags):
   if( lead_mode_flag == '1'):
       pacctscols = ["patientacctipk", "hospitalfk", "firstname", "middlename", "lastname", "ssn", "dob", "gender",
               "state", "admitdate", "referraldate",
               "dischargedate", "medicalrecnum", "clusteredacctfk", "totalcharges", "createdate", "updatedate",
               "demographicsupdatedate", "medicarehic", "medicaidnum", "trgupdatedate", "currentbalance"]
   else:
     pa_path = pa_path + bc + "/"
     pacctscols = ["patientacctipk", "hospitalfk", "firstname", "middlename", "lastname", "ssn", "dob", "gender",
             "state", "admitdate", "referraldate", \
             "dischargedate", "medicalrecnum", "clusteredacctfk", "totalcharges", "createdate", "updatedate",
             "demographicsupdatedate", "medicarehic", "medicaidnum"]
   allpatientaccts = extract_deltalake_data(spark,pa_path, pacctscols)
   allpatientaccts = allpatientaccts.withColumn('totalcharges', allpatientaccts.totalcharges.cast("decimal(32,4)"))
   allpatientaccts = allpatientaccts.withColumn('patientacctipk', allpatientaccts.patientacctipk.cast("long"))
   allpatientaccts = allpatientaccts.filter(allpatientaccts.totalcharges > 0)
        # apply admit date filters for patientaccts
   allpatientaccts = getpatientacctswithadmitdt(spark, allpatientaccts, hospadmitdate)
   if (lead_mode_flag == '1'):
     dup_cols = ("vsnapflags_hospitalfk", "patientacctipk", "vsnapflags_createdate")
     allpatientaccts = allpatientaccts.join(vsnapflags, (allpatientaccts.patientacctipk == vsnapflags.patientacctifk) & (allpatientaccts.hospitalfk == vsnapflags.vsnapflags_hospitalfk))\
                                 .filter((allpatientaccts.trgupdatedate >= enddt) |(vsnapflags.vsnapflags_createdate >= enddt)) \
                                 .drop(*dup_cols)
   return allpatientaccts
 


# COMMAND ----------

# DBTITLE 1,get_globalmrn_aid
def get_globalmrn_aid(spark, hdfs_input, candidates, bc):
    gmrn_swift_dir = hdfs_input + "/globalmrnxpacct_swift/" + bc + "/"
    gmrn = spark.read.parquet(gmrn_swift_dir).dropDuplicates()
    gmrn=gmrn.withColumn("globalmrnifk", trim(col("gmrnid")))
    candidates_base = candidates.join(gmrn, (candidates.patientacctifk == gmrn.patientacctifk) & (candidates.hospitalfk == gmrn.hospitalfk), "left").select(candidates['*'], gmrn.globalmrnifk)
    candidates_found = candidates_base.filter(col("globalmrnifk").isNotNull())
    candidates=candidates_found.dropDuplicates()
    return candidates

# COMMAND ----------

def get_patientacct_aid_combined(spark,pa_path,pacctscols,aidpatientaccts,lead_mode_flag,enddt,bc,hospadmitdate,vsnapflags) :
    # pacctscols = ["patientacctipk", "hospitalfk", "firstname", "middlename", "lastname", "ssn", "dob", "gender", "state", "admitdate", "referraldate", "dischargedate", "medicalrecnum", "clusteredacctfk", "totalcharges", "createdate", "updatedate", "demographicsupdatedate", "medicarehic", "medicaidnum", "trgupdatedate", "currentbalance"]
    paccts = spark.read.parquet(pa_path).selectExpr(pacctscols)
    paccts = paccts.join(aidpatientaccts, ["patientacctipk", "hospitalfk"], "inner").select(*paccts.columns)
    #print("INNER POST AC VS PA check : " + str(paccts.count()))
    paccts = paccts.withColumn("totalcharges", paccts.totalcharges.cast("decimal(32,4)"))
    paccts = paccts.withColumn("patientacctipk", paccts.patientacctipk.cast("long"))
    vsnapflags = vsnapflags.withColumn("patientacctifk", vsnapflags.patientacctifk.cast("long"))
    paccts = paccts.filter(paccts.totalcharges > 0)
    #print("INNER POST totalcharges check > 0 : " + str(paccts.count()))
    paccts = getpatientacctswithadmitdt(spark, paccts, hospadmitdate)
    #print("INNER POST admitdate check  : " + str(paccts.count()))
    if lead_mode_flag == "1":
        dup_cols = ("vsnapflags_hospitalfk", "patientacctipk", "vsnapflags_createdate")
        paccts = paccts.join(vsnapflags, (paccts.hospitalfk == vsnapflags.vsnapflags_hospitalfk) & (paccts.patientacctipk == vsnapflags.patientacctifk)) \
            .filter((paccts.trgupdatedate.cast("date") >= enddt.cast("date")) | (vsnapflags.vsnapflags_createdate.cast("date") >= enddt.cast("date"))) \
                .drop(*dup_cols)
        #print("INNER POST vsnapflags check  : " + str(paccts.count()))
    return paccts

# COMMAND ----------

# DBTITLE 1,get_patientacct_aid
def get_patientacct_aid(spark,pa_path,aid_accounts_path,lead_mode_flag,enddt,bc,hospadmitdate,vsnapflags):
    # SAMPLE_INPUT
    # pa_path="abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/maxc/data/dataingestion/staging/input/patientaccts/20240611T11/"
    # aid_accounts_path="abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/maxc/data/dataingestion/publish/patientacctsaccesscoordinator/current/20991231/"
    pacctscols = [
        "patientacctipk",
        "hospitalfk",
        "firstname",
        "middlename",
        "lastname",
        "ssn",
        "dob",
        "gender",
        "state",
        "admitdate",
        "referraldate",
        "dischargedate",
        "medicalrecnum",
        "clusteredacctfk",
        "totalcharges",
        "createdate",
        "updatedate",
        "demographicsupdatedate",
        "medicarehic",
        "medicaidnum",
        "trgupdatedate",
        "currentbalance",
    ]
    paccts = spark.read.parquet(pa_path).selectExpr(pacctscols)
    paccts.createOrReplaceTempView("paccts")
    patientacctsaccesscoordinator = spark.read.format("parquet").load(aid_accounts_path)
    patientacctsaccesscoordinator = patientacctsaccesscoordinator.selectExpr(
        "patientacctifk as patientacctipk", "hospitalfk"
    ).dropDuplicates()
    patientacctsaccesscoordinator.createOrReplaceTempView(
        "patientacctsaccesscoordinator"
    )
    paccts = spark.sql(
        """SELECT paccts.* FROM paccts INNER JOIN patientacctsaccesscoordinator ON 
                     CAST(paccts.hospitalfk AS BIGINT)=CAST(patientacctsaccesscoordinator.hospitalfk AS BIGINT) 
                     AND CAST(paccts.patientacctipk AS BIGINT)=CAST(patientacctsaccesscoordinator.patientacctipk AS BIGINT)
                     """
    )
    #print("INNER POST AC VS PA check : " + str(paccts.count()))
    paccts = paccts.withColumn(
        "totalcharges", paccts.totalcharges.cast("decimal(32,4)")
    )
    paccts = paccts.withColumn("patientacctipk", paccts.patientacctipk.cast("long"))
    vsnapflags = vsnapflags.withColumn(
        "patientacctifk", vsnapflags.patientacctifk.cast("long")
    )
    paccts = paccts.filter(paccts.totalcharges > 0)
    #print("INNER POST totalcharges check > 0 : " + str(paccts.count()))
    paccts = getpatientacctswithadmitdt(spark, paccts, hospadmitdate)
    #print("INNER POST admitdate check  : " + str(paccts.count()))
    if lead_mode_flag == "1":
        dup_cols = ("vsnapflags_hospitalfk", "patientacctipk", "vsnapflags_createdate")
        paccts = (
            paccts.join(vsnapflags, (paccts.patientacctipk == vsnapflags.patientacctifk) & (paccts.hospitalfk == vsnapflags.vsnapflags_hospitalfk))
            .filter(
                (paccts.trgupdatedate.cast("date") >= enddt.cast("date"))
                | (vsnapflags.vsnapflags_createdate.cast("date") >= enddt.cast("date"))
            )
            .drop(*dup_cols)
        )
        #print("INNER POST vsnapflags check  : " + str(paccts.count()))
    return paccts

# COMMAND ----------

def getpatientacctswithadmitdt(spark, patientaccts, hospadmitdate):
    patientaccts.createOrReplaceTempView("pa")
    hospadmitdate.createOrReplaceTempView("ha")
        #if the admitdate is in the future, check if it is within 30 days of the immediate future
    paccts = spark.sql("""
                      SELECT pa.*
                      FROM pa inner join ha on CAST(pa.hospitalfk AS BIGINT) = CAST(ha.hospitalfk AS BIGINT)
                      WHERE
                      (   (pa.admitdate between date_sub(current_date(),int(ha.maxsearchduration)) and date_sub(current_date(),int(ha.minsearchduration)))
                       OR (pa.admitdate between current_date() and date_add(current_date(),30))
                      )""")
    return paccts

# COMMAND ----------

def hospattributes(spark, ha, hav):

    havalues = ha.join(hav, hav.hospitalattributefk == ha.hospitalattributepk). \
        filter(hav.hospitalattributefk == 25). \
        select(hav.hospitalfk, hav.hospitalattributefk, hav.hospitalattributevalue)
    return havalues

# COMMAND ----------

def getcandidateacctsfilter_coc(spark, pa, vsnap):
    pa.createOrReplaceTempView("pa")
    vsnap.createOrReplaceTempView("vsnap")
    ca = spark.sql("""select p.*,paf.knowntricareflag,paf.knownmcaidflag
                      from pa p
                      left join vsnap paf on paf.vsnapflags_hospitalfk = p.hospitalfk and p.patientacctipk = paf.patientacctifk""")
    ca = ca.dropDuplicates()
    ca = ca.withColumnRenamed("patientacctipk", "patientacctifk")
    return ca

# COMMAND ----------

def getcandidateacctsfilter(spark, pa, havalues, vsnap):
    pa.createOrReplaceTempView("pa")
    havalues.createOrReplaceTempView("havalues")
    vsnap.createOrReplaceTempView("vsnap")
    ca = spark.sql("""select p.*,paf.knowntricareflag,paf.knownmcaidflag
                      from pa p
                      left join vsnap paf on paf.hospitalfk = p.hospitalfk and p.patientacctifk = paf.patientacctifk
                      left join havalues hv on hv.hospitalfk = p.hospitalfk
                      where paf.primarymcaidflag = 1
                      or (((paf.knownmcaidflag = 1)
                           or  (paf.knowntricareflag = 1))
                           and (paf.secondarymcaid_afterinsuranceflag = 0)
                           and (paf.hasmedicareflag = 0 ))
                      or (paf.hasmedicareflag =1 and (hospitalattributevalue=1)) """)
    ca = ca.dropDuplicates()
    return ca

# COMMAND ----------

def getcandidateacctsfilter_ll(spark, pa, patientacctcodes, havalues, hic, edipayers):
    pa.createOrReplaceTempView("pa")
    patientacctcodes.createOrReplaceTempView("pac")
    havalues.createOrReplaceTempView("havalues")
    hic.createOrReplaceTempView("c1")
    hic.createOrReplaceTempView("c2")
    hic.createOrReplaceTempView("c3")
    edipayers.createOrReplaceTempView("edipayers")


    ca = spark.sql("""select p.*, case when (p.hasmedicareflag =1 and (hospitalattributevalue=1)  ) then 1 else 0 end as hasmedicareflag_filter
                      from pa p
                      left join havalues hv on hv.hospitalfk = p.hospitalfk
                      where p.primarymcaidflag = 1
                      or (((p.knownmcaidflag = 1)
                           or  (p.knowntricareflag = 1))
                           and (p.secondarymcaid_afterinsuranceflag = 0)
                           and (p.hasmedicareflag = 0 ))
                      or (p.hasmedicareflag =1 and (hospitalattributevalue=1)) """)
    ca_regular = ca.filter( ca.hasmedicareflag_filter == 0).drop(ca.hasmedicareflag_filter).drop(ca.currentbalance)
    ca_regular = ca_regular.dropDuplicates()


    ca_mcare = ca.filter(ca.hasmedicareflag_filter == 1 )
    ca_mcare = ca_mcare.dropDuplicates()
    ca_mcare.createOrReplaceTempView("ca_mcare")
    ca_mcare_pac = spark.sql( """ select p.* , pac.insurancecode1, pac.insurancecode2, pac.insurancecode3
                              from ca_mcare  p
                              left join pac  on
                                   p.hospitalfk = pac.hospitalfk and
                                   p.patientacctifk = pac.patientacctifk """ )

    ca_mcare_pac.createOrReplaceTempView("ca_mcare_pac")

    ca_mcare1 = spark.sql( """
    SELECT
           ca_mcare_pac.*, c1.edipayerfk as c1_edipayerfk
    FROM       ca_mcare_pac
    JOIN       c1 on coalesce(c1.code,"") =coalesce(ca_mcare_pac.insurancecode1,"") and ca_mcare_pac.hospitalfk=c1.hospitalfk
    JOIN       c2 on coalesce(c2.code,"") =coalesce(ca_mcare_pac.insurancecode2, "")  AND  ca_mcare_pac.hospitalfk=c2.hospitalfk
    JOIN       c3 on coalesce(c3.code,"") =coalesce(ca_mcare_pac.insurancecode3,"")  and  ca_mcare_pac.hospitalfk=c3.hospitalfk
    LEFT JOIN  edipayers on  coalesce(c1.edipayerfk, "")  = edipayers.edipayerpk
    WHERE
           c1.mcare=1
    AND
           c2.secondarytomcaid = 1
    AND
           c3.secondarytomcaid =  1
    AND
           float(ca_mcare_pac.currentbalance) > 0
    AND
           year(ca_mcare_pac.admitdate) >= 2022
""" )

    ca_mcare1 = ca_mcare1.filter( ca_mcare1.c1_edipayerfk.isNull() )
    ca_mcare1 = ca_mcare1.drop('currentbalance').drop('c1_edipayerfk').drop('insurancecode1').drop('insurancecode2').drop('insurancecode3').drop('hasmedicareflag_filter')
    ca_mcare1=ca_mcare1.dropDuplicates()
    ca_mcare1.printSchema()
    ca_regular.printSchema()

    #print('candidate non medicare counts    = '  +str(ca_regular.count()))
    #print('candidate medicare only counts    = '  +str(ca_mcare1.count()))


    ca_final = ca_regular.union(ca_mcare1)
    return ca_final
