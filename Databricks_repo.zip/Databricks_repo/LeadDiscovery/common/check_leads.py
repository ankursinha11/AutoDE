# Databricks notebook source
dbutils.widgets.text("user", "")
dbutils.widgets.getArgument("user")
user = getArgument("user")

dbutils.widgets.text("container", "")
dbutils.widgets.getArgument("container")
container = getArgument("container")

dbutils.widgets.text("storageaccount", "")
dbutils.widgets.getArgument("storageaccount")
storageaccount = getArgument("storageaccount")

dbutils.widgets.text("bc", "")
dbutils.widgets.getArgument("bc")
bc = getArgument("bc")

dbutils.widgets.text("hdfs_leads_input", "")
dbutils.widgets.getArgument("hdfs_leads_input")
hdfs_leads_input = getArgument("hdfs_leads_input")

dbutils.widgets.text("hdfs_leads_sent", "")
dbutils.widgets.getArgument("hdfs_leads_sent")
hdfs_leads_sent = getArgument("hdfs_leads_sent")

dbutils.widgets.text("hdfs_sqoop_output", "")
dbutils.widgets.getArgument("hdfs_sqoop_output")
hdfs_sqoop_output = getArgument("hdfs_sqoop_output")

dbutils.widgets.text("dataingestion_publish_path", "")
dbutils.widgets.getArgument("dataingestion_publish_path")
dataingestion_publish_path = getArgument("dataingestion_publish_path")

dbutils.widgets.text("mode", "")
dbutils.widgets.getArgument("mode")
mode = getArgument("mode")

# COMMAND ----------

# DBTITLE 1,Sample Inputs
# bc="20240618T16"
# container="prod-icd-stg-adls"
# storageaccount="prodicdstgdls"
# user="geetha"
# hdfs_leads_input="/data/leaddiscovery/transform/scratch/globalmrn_assign/candidatepaleadspost/"
# hdfs_leads_sent="/data/leaddiscovery/publish/patientacctxlead/"
# hdfs_sqoop_output="/data/leaddiscovery/transform/output/globalmrn_assign/"
# dataingestion_publish_path="/data/dataingestion/publish/"
# mode="aid"

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

module = str(mode)

if module=='':
    module = "regular"

if module == "aid":
    print("module : "+str(module))
else:
    module = "regular"
    print("module : "+str(module))

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import datetime
import uuid
spark.conf.set("spark.sql.shuffle.partitions","auto")

# COMMAND ----------

if module == "aid":
    print("module : "+str(module))
    hdfs_leads_input = baseurl + hdfs_leads_input +"/aid/"+ bc
    hdfs_leads_sent = baseurl + hdfs_leads_sent
    hdfs_sqoop_output = baseurl + hdfs_sqoop_output +"/aid/"+ bc
    dataingestion_publish_path = baseurl + dataingestion_publish_path
else:
    module = "regular"
    print("module : "+str(module))
    hdfs_leads_input = baseurl + hdfs_leads_input + bc
    hdfs_leads_sent = baseurl + hdfs_leads_sent
    hdfs_sqoop_output = baseurl + hdfs_sqoop_output + bc
    dataingestion_publish_path = baseurl + dataingestion_publish_path

# COMMAND ----------

from datetime import datetime
runtimestamp = datetime.now().strftime("%Y%m%d%H%M%S")

hdfs_leads_temp_root_rw= baseurl + "/data/leaddiscovery/transform/scratch/runtime/check_leads/hdfs_leads_temp_rw/"
hdfs_leads_temp_rw=hdfs_leads_temp_root_rw + str(runtimestamp)

print(hdfs_leads_temp_root_rw)
print(runtimestamp)
print(hdfs_leads_temp_rw)

# COMMAND ----------

# DBTITLE 1,Read patientacctxlead
initialrun = 0

# read sent leads
sent_leads = spark.read.format("delta").load(hdfs_leads_sent)
sent_leads.createOrReplaceTempView("sent_leads")
sent_leads=spark.sql("""
SELECT uniqueid,
       patientacctifk,
       hospitalfk,
       lsb_edipartnerfk,
       demohash,
       UPPER(TRIM(lsb_coverageid)) AS lsb_coverageid,
       UPPER(TRIM(lsb_firstname))  AS sl_firstname,
       UPPER(TRIM(lsb_lastname))   AS sl_lastname,
       CASE WHEN TRIM(lsb_ssn) = '000000000' THEN '' ELSE TRIM(lsb_ssn) END AS sl_ssn,
       TRIM(lsb_dob) AS sl_dob,
       CASE WHEN UPPER(TRIM(lsb_state)) ='XX' THEN '' ELSE UPPER(TRIM(lsb_state)) END AS sl_state
FROM sent_leads""").dropDuplicates()

sent_leads_democols = ["sl_firstname","sl_lastname", "sl_ssn", "sl_dob", "sl_state","lsb_edipartnerfk","lsb_coverageid","patientacctifk", "hospitalfk"]

for column in sent_leads_democols:
    sent_leads = sent_leads.withColumn(column, trim(col(column)))
    sent_leads = sent_leads.withColumn(column, when(col(column).isNull(), '').otherwise(col(column)))
    sent_leads = sent_leads.withColumn(column, when(upper(col(column)) == 'NULL', '').otherwise(col(column)))
    sent_leads = sent_leads.withColumn(column, when(upper(col(column)) == 'NONE', '').otherwise(col(column)))
    sent_leads = sent_leads.withColumn(column, when(upper(col(column)) == 'XX', '').otherwise(col(column)))
    
sent_leads.createOrReplaceTempView("sent_leads")

# COMMAND ----------

# DBTITLE 1,Read today's Leads and cleanse
# read new leads

leads = spark.read.parquet(hdfs_leads_input + "/*")
# AID BASED LOGIC STARTS HERE ******************************************************************************
leads=leads.withColumn("module",lit(str(module)))
leads.createOrReplaceTempView("leads")
patientacctsaccesscoordinator=spark.read.parquet(dataingestion_publish_path + "/patientacctsaccesscoordinator/current/20991231/")
# NEW AID UNION STARTS
aid_bc = bc.split("-")[0]
print("aid_bc:",aid_bc)
patientacctsaccesscoordinator = patientacctsaccesscoordinator.selectExpr("patientacctifk","hospitalfk").dropDuplicates()
# filterBc="bcupdated=='"+aid_bc+"'"
# aidpatientaccts = spark.read.format("delta").load(dataingestion_publish_path + "/aidpatientaccts/current/20991231/").filter(filterBc)
aidpatientaccts = spark.read.format("delta").load(dataingestion_publish_path + "/aidpatientaccts/current/20991231/")
aidpatientaccts = aidpatientaccts.selectExpr("patientacctifk","hospitalfk").dropDuplicates()
patientacctsaccesscoordinator = patientacctsaccesscoordinator.union(aidpatientaccts)
# NEW AID UNION ENDS
patientacctsaccesscoordinator.createOrReplaceTempView("patientacctsaccesscoordinator")
leads=spark.sql("""
SELECT leads.*,
       CASE
         WHEN leads.patientacctifk_2 IS NOT NULL THEN '51'
         ELSE leads.edidatasourcefk
       END AS mod_edidatasourcefk,
       CASE
         WHEN (lower(leads.module) = "aid" AND leads.patientacctifk_2 IS NOT NULL) THEN CONCAT (leads.breadcrumb,'-AD')
         ELSE leads.breadcrumb
       END AS mod_breadcrumb
FROM (SELECT leads.*,
             patientacctsaccesscoordinator.patientacctifk AS patientacctifk_2
      FROM leads
        LEFT JOIN patientacctsaccesscoordinator
               ON  leads.patientacctifk = patientacctsaccesscoordinator.patientacctifk 
               AND leads.hospitalfk = patientacctsaccesscoordinator.hospitalfk) leads
""")
leads=leads.drop("patientacctifk_2").drop("edidatasourcefk").withColumnRenamed("mod_edidatasourcefk","edidatasourcefk")
leads=leads.drop("module").drop("breadcrumb").withColumnRenamed("mod_breadcrumb","breadcrumb").dropDuplicates()
# AID BASED LOGIC ENDS HERE ******************************************************************************

# print("STEP-1 : "+str(leads.count()))

# Filter out bad coverageId records.
leads= leads.filter(~col("lsb_coverageId").isin('999999999','ABC123','SELFPAY'))

input_leads_democols = ["lsb_firstname","lsb_lastname", "lsb_ssn", "lsb_dob", "lsb_state","lsb_edipartnerfk","lsb_coverageid","patientacctifk", "hospitalfk"]

for column in input_leads_democols:
    leads = leads.withColumn(column, trim(col(column)))
    leads = leads.withColumn(column, when(col(column).isNull(), '').otherwise(col(column)))
    leads = leads.withColumn(column, when(upper(col(column)) == 'NULL', '').otherwise(col(column)))
    leads = leads.withColumn(column, when(upper(col(column)) == 'NONE', '').otherwise(col(column)))
    leads = leads.withColumn(column, when(upper(col(column)) == 'XX', '').otherwise(col(column)))

leads=leads.withColumn("lsb_firstname",upper(col("lsb_firstname"))).withColumn("lsb_lastname",upper(col("lsb_lastname"))).withColumn("lsb_state",upper(col("lsb_state")))
leads.createOrReplaceTempView("leads")
leads=spark.sql(""" SELECT leads.*, CASE WHEN leads.lsb_state='XX' THEN '' ELSE leads.lsb_state END AS lsb_state_2 FROM leads""").drop("lsb_state").withColumnRenamed("lsb_state_2","lsb_state")
leads.createOrReplaceTempView("leads")
leads=spark.sql(""" SELECT leads.*, CASE WHEN leads.lsb_ssn='000000000' THEN '' ELSE leads.lsb_ssn END AS lsb_ssn_2 FROM leads""").drop("lsb_ssn").withColumnRenamed("lsb_ssn_2","lsb_ssn")

#------------Code moved up to handle duplicates 20240313
cond_dob_2 = when(to_date(col("lsb_dob"), "yyyy-MM-dd HH:mm:ss").isNotNull(), date_format(col("lsb_dob"), "yyyy-MM-dd HH:mm:ss")).otherwise(None)
cond_dob = when( \
    (substring(trim(col("lsb_dob")), 0, 4).cast(IntegerType()) < 1800) \
    , lit("") \
    ) \
    .otherwise(cond_dob_2)
leads = leads.withColumn("lsb_dob", cond_dob)
leads = leads.withColumn("admitdate", date_format(col("admitdate"), "yyyy-MM-dd HH:mm:ss"))
leads = leads.withColumn("dischargedate", date_format(col("dischargedate"), "yyyy-MM-dd HH:mm:ss"))
leads = leads.withColumn("dob", date_format(col("dob"), "yyyy-MM-dd HH:mm:ss"))
## send empty string for bad ssn or gender
cond_gender = when( \
    (length(trim(col("lsb_gender"))) > 10) \
    , lit("") \
    ) \
    .otherwise(col("lsb_gender"))
leads = leads.withColumn("lsb_gender", cond_gender)
cond_ssn = when( \
    (length(trim(col("lsb_ssn"))) > 11) \
    , lit("") \
    ) \
    .otherwise(col("lsb_ssn"))
leads = leads.withColumn("lsb_ssn", cond_ssn)
## taking all coverageid with only len 25 or below -- business rule
leads = leads.filter(length(col("lsb_coverageid")) <= 25)
#-------------- END of code To handle duplicates 20240313

#---------------Updated to handle duplicates wrt null/value 20240304
# print("STEP-2 : "+str(leads.count()))




leads.createOrReplaceTempView("leads")

# COMMAND ----------

# DBTITLE 1,JOIN OPT
joinExpr = (
    (leads.lsb_edipartnerfk == sent_leads.lsb_edipartnerfk)
    & (leads.patientacctifk == sent_leads.patientacctifk)
    & (leads.hospitalfk == sent_leads.hospitalfk)    
    & (
        (upper(leads.lsb_coverageid) == upper(sent_leads.lsb_coverageid))
        | (upper(leads.lsb_coverageid).contains(upper(sent_leads.lsb_coverageid)))
        | (upper(sent_leads.lsb_coverageid).contains(upper(leads.lsb_coverageid)))
    )
)

all_leads = leads.join(sent_leads, joinExpr, "left").select(leads['*'], sent_leads.uniqueid, sent_leads.sl_firstname, sent_leads.sl_lastname, sent_leads.sl_ssn, sent_leads.sl_dob, sent_leads.sl_state).dropDuplicates()
all_leads.write.mode("overwrite").parquet(hdfs_leads_temp_rw)
all_leads.unpersist()
all_leads = spark.read.parquet(hdfs_leads_temp_rw)

# COMMAND ----------

# DBTITLE 1,Compare leads UPD and INS

new_leads = all_leads.filter(col("uniqueid").isNull())
# print("new_leads count: " + str(new_leads.count()))



up_leads = all_leads.filter(~col("uniqueid").isNull()) 
up_leads = up_leads.withColumn("match_flag", when(((up_leads.lsb_firstname != '') & (up_leads.lsb_firstname != up_leads.sl_firstname)) 
                                                            | ((up_leads.lsb_lastname != '') & (up_leads.lsb_lastname != up_leads.sl_lastname)) 
                                                            | ((up_leads.lsb_ssn != '') & (up_leads.lsb_ssn != up_leads.sl_ssn)) 
                                                            | ((up_leads.lsb_dob != '') & (up_leads.lsb_dob != up_leads.sl_dob)) 
                                                            | ((up_leads.lsb_state != '') & (up_leads.lsb_state != up_leads.sl_state)), '0').otherwise('1'))

up_leads.createOrReplaceTempView('up_leads')
up_leads_match = spark.sql("""
                    SELECT patientacctifk, hospitalfk, lsb_edipartnerfk, lsb_coverageid, max(match_flag) as max_match_flag FROM up_leads
                    GROUP BY patientacctifk, hospitalfk, lsb_edipartnerfk, lsb_coverageid
                    """)
up_leads_match = up_leads_match.filter("max_match_flag == 0") 
up_leads_final = up_leads.join(up_leads_match, ['patientacctifk', 'hospitalfk', 'lsb_edipartnerfk', 'lsb_coverageid']).select(up_leads["*"]).drop("match_flag")
# print("up_leads_final count: " + str(up_leads_final.count()))



diff_leads = new_leads.union(up_leads_final)
diff_leads = diff_leads.drop("uniqueid").drop("sl_firstname").drop("sl_lastname").drop("sl_ssn").drop("sl_dob").drop("sl_state").dropDuplicates()
ordered_columns = ["uniqueid", "breadcrumb", "patientacctifk", "hospitalfk", "hospitalname", "firstname", "middlename", "lastname", "dob","ssn", "gender", "state", "admitdate", "dischargedate", "clusteredacctfk", "totalcharges", "npi", "lsb_edipartnerfk", "lsb_coverageid","lsb_leadsource", "lsb_xrefsource", "lsb_firstname", "lsb_middlename", "lsb_lastname", "lsb_gender", "lsb_dob", "lsb_ssn", "lsb_state","usefamilydataflag", "edidatasourcefk", "edidatasourcetablekey", "associationsource", "demohash", "medicarehic", "medicaidnum"]
diff_leads = diff_leads.withColumn("uniqueid", concat_ws("_", diff_leads.patientacctifk, expr("uuid()"))).select(ordered_columns)
diff_leads = diff_leads.withColumn("createdate", date_format(current_timestamp(), "yyyy-MM-dd HH:mm:ss"))
# print("diff_leads count: " + str(diff_leads.count()))


# COMMAND ----------

diff_leads.createOrReplaceTempView('diff_leads')
diff_leads=spark.sql(""" SELECT * FROM diff_leads WHERE TRIM(lsb_coverageid) <> '' """) 

# COMMAND ----------

# DBTITLE 1,breadcrumb ADJUST
# getting the correct bc
if module == "aid":
    print("module : " + str(module))
    filterExpr="breadcrumb='"+bc+"-AD'"
    print("AID filterExpr : "+str(filterExpr))
    diff_leads = diff_leads.withColumn("breadcrumb", lit(bc + "-AD"))
else:
    module = "regular"
    print("module : " + str(module))
    filterExpr="breadcrumb='"+bc+"'"
    print("REGULAR filterExpr : "+str(filterExpr))
    diff_leads = diff_leads.withColumn("breadcrumb", lit(bc))

# COMMAND ----------

# DBTITLE 1,WRITE OUT LEADS
for column in diff_leads.columns:
    diff_leads = diff_leads.withColumn(column, trim(col(column)))
    diff_leads = diff_leads.withColumn(column, when(col(column).isNull(), '').otherwise(col(column)))
    diff_leads = diff_leads.withColumn(column, when(upper(col(column)) == 'NULL', '').otherwise(col(column)))
    diff_leads = diff_leads.withColumn(column, when(upper(col(column)) == 'NONE', '').otherwise(col(column)))
    diff_leads = diff_leads.withColumn(column, when(upper(col(column)) == 'XX', '').otherwise(col(column)))

if diff_leads.count() > 0:
    diff_leads.dropDuplicates().write.mode("append").format("delta").save(hdfs_leads_sent)
    diff_leads.unpersist()
    lead_gen_flag = 1
    print("YES LEADS TO BE ADDED")
else :
    print("NO LEADS ADDED")
    lead_gen_flag = 0

# COMMAND ----------

if lead_gen_flag == 1:
    # DELTA LAKE LOGIC STARTS : PURGE HOSPITALS    
    from delta.tables import *
    df_raw = DeltaTable.forPath(spark, hdfs_leads_sent)
    pJoinExpression = "raw.hospitalfk=delta.hospitalfk"
    df_delete = spark.read.parquet(dataingestion_publish_path + "/hospitalpurge/current/20991231/").filter("active=='1'").selectExpr("hospitalfk").dropDuplicates()
    # print("COUNT hospitalpurge LIST : " + str(df_delete.count()))
    df_raw.alias("raw").merge(df_delete.alias("delta"), pJoinExpression).whenMatchedDelete().execute()
    df_delete.unpersist()
    # DELTA LAKE LOGIC ENDS: PURGE HOSPITALS
else :
    print("NO LEADS TO BE ADDED")

# COMMAND ----------

if lead_gen_flag == 1:
    diff_leads = spark.read.format("delta").load(hdfs_leads_sent)    
    diff_leads=diff_leads.filter(filterExpr).drop("demohash").dropDuplicates()
    diff_leads = diff_leads.withColumn('dob', ((to_date(diff_leads.dob)).cast('timestamp')).cast('string'))
    diff_leads = diff_leads.withColumn('admitdate', ((to_date(diff_leads.admitdate)).cast('timestamp')).cast('string'))
    diff_leads = diff_leads.withColumn('dischargedate', ((to_date(diff_leads.dischargedate)).cast('timestamp')).cast('string'))
    diff_leads = diff_leads.withColumn('lsb_dob', ((to_date(diff_leads.lsb_dob)).cast('timestamp')).cast('string'))
    diff_leads.repartition(10).write.format("parquet").mode("overwrite").options(timestampFormat="yyyy-MM-dd HH:mm:ss").save(hdfs_sqoop_output+"/hdppatientacctxlead")
    diff_leads.unpersist()
    batch=spark.read.parquet(hdfs_sqoop_output+"/hdppatientacctxlead").selectExpr("breadcrumb").limit(1)
    batch.repartition(1).write.mode("overwrite").format("parquet").options(timestampFormat="yyyy-MM-dd HH:mm:ss").save(hdfs_sqoop_output +"/hdppatientacctxleadbatch")
    batch.unpersist()
    ret_val = 1
else :
    ret_val = 0

# COMMAND ----------

def file_exists(path):
  try:
    dbutils.fs.ls(path)
    return True
  except Exception as e:
    if 'java.io.FileNotFoundException' in str(e):
      return False
    else:
      raise

# COMMAND ----------

isFilesTrue=file_exists(hdfs_leads_temp_rw)

if isFilesTrue == True:
    print("isFilesTrue : " + str(isFilesTrue))
    dbutils.fs.rm(hdfs_leads_temp_rw, True)
else:
    print("isFilesTrue : " + str(isFilesTrue))

# COMMAND ----------

dbutils.notebook.exit(ret_val)
