# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
import datetime
# from configparser import SafeConfigParser
from functools import reduce
from pyspark.sql import DataFrame


# COMMAND ----------


def createlookupbypartnerfk(spark, hp, hpn, edis, ep, edienv, epso, ephsso, epp):
    hp.createOrReplaceTempView("hp")
    hpn.createOrReplaceTempView("hpn")
    edis.createOrReplaceTempView("edis")
    ep = ep.filter("isenabledflag='1'")
    ep.createOrReplaceTempView("ep")
    edienv.createOrReplaceTempView("edienv")
    epso.createOrReplaceTempView("epso")
    ephsso.createOrReplaceTempView("ephsso")
    epp.createOrReplaceTempView("epp")
    a = """select hpn.hospitalfk,ep.edipartnerpk,
              0 as minsearchduration,
              max(maxsearchduration) as maxsearchduration
       from ephsso
       join ep
            on ephsso.edipartnerfk = ep.edipartnerpk
       join  epp
            on ep.edipartnertypefk = epp.edipartnertypepk
       join  hpn
            on hpn.hospitalfk = ephsso.hospitalfk
       join hp
            on hp.hospitalpk= hpn.hospitalfk
       group by hpn.hospitalfk,ep.edipartnerpk"""
    b = spark.sql(a)
    c = """select hpn.hospitalfk,ep.edipartnerpk,
               min(minsearchduration) as minsearchduration,
               max(maxsearchduration) as maxsearchduration
        from hpn
        join hp
             on hp.hospitalpk=hpn.hospitalfk
        join epso
             on hpn.edisubmitterfk = epso.edisubmitterfk
        join ep
             on hpn.edipartnerfk = ep.edipartnerpk
        join  epp
             on ep.edipartnertypefk = epp.edipartnertypepk
        group by hpn.hospitalfk,ep.edipartnerpk """
    d = spark.sql(c)
    e = """select hpn.hospitalfk,ep.edipartnerpk,
                 min(minsearchduration) as minsearchduration,
                 max(maxsearchduration) as maxsearchduration
          from  hpn
          join  hp
                on hp.hospitalpk=hpn.hospitalfk
          join  edienv
                on hpn.edipartnerfk = edienv.edipartnerfk
          join ep
                on hpn.edipartnerfk = ep.edipartnerpk
          join epp
                on ep.edipartnertypefk = epp.edipartnertypepk
          group by hpn.hospitalfk,ep.edipartnerpk """
    f = spark.sql(e)
    dfs = [b, d, f]
    df = reduce(DataFrame.unionAll, dfs)
    for column in df.columns:
        df = df.withColumn(column, when(col(column) == 'null', lit(0)).otherwise(col(column)))
    df.createOrReplaceTempView("tbl1")
    g = """ select max(int(maxsearchduration)) as maxsearchduration ,
                   min(int(minsearchduration)) as minsearchduration ,
                   hospitalfk,edipartnerpk
            from tbl1
                 group by hospitalfk,edipartnerpk """
    h = spark.sql(g)
    return h


def createlookup(spark, hp, hpn, edis, ep, edienv, epso, ephsso, epp):
    hp.createOrReplaceTempView("hp")
    hpn.createOrReplaceTempView("hpn")
    edis.createOrReplaceTempView("edis")
    ep.createOrReplaceTempView("ep")
    edienv.createOrReplaceTempView("edienv")
    epso.createOrReplaceTempView("epso")
    ephsso.createOrReplaceTempView("ephsso")
    epp.createOrReplaceTempView("epp")
    a = """select hpn.hospitalfk,
                  0 as minsearchduration,
                  max(maxsearchduration) as maxsearchduration
           from ephsso
           join ep
                on ephsso.edipartnerfk = ep.edipartnerpk
           join  epp
                on ep.edipartnertypefk = epp.edipartnertypepk
           join  hpn
                on hpn.hospitalfk = ephsso.hospitalfk
           join hp
                on hp.hospitalpk= hpn.hospitalfk
           group by hpn.hospitalfk"""
    b = spark.sql(a)
    c = """select hpn.hospitalfk,
                   min(minsearchduration) as minsearchduration,
                   max(maxsearchduration) as maxsearchduration
            from hpn
            join hp
                 on hp.hospitalpk=hpn.hospitalfk
            join epso
                 on hpn.edisubmitterfk = epso.edisubmitterfk
            join ep
                 on hpn.edipartnerfk = ep.edipartnerpk
            join  epp
                 on ep.edipartnertypefk = epp.edipartnertypepk
            group by hpn.hospitalfk """
    d = spark.sql(c)
    e = """select hpn.hospitalfk,
                     min(minsearchduration) as minsearchduration,
                     max(maxsearchduration) as maxsearchduration
              from  hpn
              join  hp
                    on hp.hospitalpk=hpn.hospitalfk
              join  edienv
                    on hpn.edipartnerfk = edienv.edipartnerfk
              join  ep
                    on hpn.edipartnerfk = ep.edipartnerpk
              join epp
                    on ep.edipartnertypefk = epp.edipartnertypepk
              group by hpn.hospitalfk"""
    f = spark.sql(e)
    dfs = [b, d, f]
    df = reduce(DataFrame.unionAll, dfs)
    for column in df.columns:
        df = df.withColumn(column, when(col(column) == 'null', lit(0)).otherwise(col(column)))

    df = df.withColumn('minsearchduration', df.minsearchduration.cast('int'))
    df = df.withColumn('maxsearchduration', df.maxsearchduration.cast('int'))
    df.createOrReplaceTempView("tbl1")
    g = """ select max(int(maxsearchduration)) as maxsearchduration ,
                       min(int(minsearchduration)) as minsearchduration ,
                       hospitalfk
                from tbl1
                     group by hospitalfk"""
    h = spark.sql(g)
    return h
