# Databricks notebook source
#cosmos_test - install required libraries
# azure-storage-file-datalake==12.18.0

# COMMAND ----------

from pyspark.sql.functions import *
from azure.storage.filedatalake import DataLakeDirectoryClient, DataLakeServiceClient


# COMMAND ----------

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("module","")
dbutils.widgets.getArgument("module")
module= getArgument("module")

dbutils.widgets.text("workflow_name", "")
dbutils.widgets.getArgument("workflow_name")
workflow_name = getArgument("workflow_name")

# COMMAND ----------

storageacct_credential = dbutils.secrets.get(scope = "icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret")

# Set the paths
containerName = "edi-payer-leads"
accountUrl="https://"+storageaccount+".dfs.core.windows.net"

in_progressPath = 'abfss://'+ containerName + "@" + storageaccount + '.dfs.core.windows.net/shards_inprogress'

# COMMAND ----------

# spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",storageacct_credential)

# COMMAND ----------

if module =='': 
    module="regular" 
else: 
    module=module

print("module is : "+module)

# COMMAND ----------

if module =='aid':
    bc = bc+"-AD"
else :
    bc
print("bc is : "+bc)

# COMMAND ----------

shards = dbutils.fs.ls(in_progressPath)

shards_list = [shard_info.name for shard_info in shards if shard_info.name.startswith('databaseshardname=')]

print(shards_list)

# COMMAND ----------

for shards in shards_list:
    try:
        sourcePath = f"/shards_inprogress/{shards}workflow_name={workflow_name}/bc={bc}/"
        shardName = shards.replace("databaseshardname=","")
        #DO NOT CHANGE THE TARGET PATH. it IS BEING DELETED IN THE NEXT LINES AND WE DONOT WANT TO DELETE THE PARENT FOLDER
        #THATS WHY AN EXPLICIT PATH TILL bc IS DECLARED HERE
        #abfss://edi-payer-leads@prodicdstgdls.dfs.core.windows.net/shards_current/shard2/medicaid/20240124T06
        targetPath = f"/shards_current/{shardName}{workflow_name}/{bc}"

        sourceDirectoryClient = DataLakeDirectoryClient(
            account_url=accountUrl,
            credential=storageacct_credential,
            file_system_name=containerName,
            directory_name=sourcePath
        )
        targetDirectoryClient = DataLakeDirectoryClient(
            account_url=accountUrl,
            credential=storageacct_credential,
            file_system_name=containerName,
            directory_name=targetPath
        )

        # Ensure the parent directory of the target path exists
        parentTargetPath = "/".join(targetPath.split("/")[:-1])
        parentTargetDirectoryClient = DataLakeDirectoryClient(
            account_url=accountUrl,
            credential=storageacct_credential,
            file_system_name=containerName,
            directory_name=parentTargetPath
        )

        if not parentTargetDirectoryClient.exists():
            parentTargetDirectoryClient.create_directory()

        if sourceDirectoryClient.exists():
            if targetDirectoryClient.exists():
                print("target path exists, removing the directory: ", targetPath)
                targetDirectoryClient.delete_directory()
            print("source path exists, moving the contents: ", sourcePath)
            sourceDirectoryClient.rename_directory(new_name=f"{sourceDirectoryClient.file_system_name}/{targetPath}")
        else:
            print(f"{sourcePath} doesn't exist")
    except Exception as e:
        print(f"An error occurred while processing shard {shards}: {e}")

# COMMAND ----------


