# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("ip_cpa","")
dbutils.widgets.getArgument("ip_cpa")
ip_cpa= getArgument("ip_cpa")

dbutils.widgets.text("module","")
dbutils.widgets.getArgument("module")
module= getArgument("module")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Sample PROD Params

# COMMAND ----------

#SAMPLE PROD INPUTS
# user="na"
# container="prod-icd-adls"
# storageaccount="prodicddls"
# bc="20250729T01"
# ip_cpa="/data/leaddiscovery/transform/scratch/globalmrn_assign/candidatepa/"
# module ="regular"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Sample STAGE Params

# COMMAND ----------

# SAMPLE STAGE INPUTS
# user="maxc"
# container="prod-icd-stg-adls"
# storageaccount="prodicdstgdls"
# bc="20250729T01"
# ip_cpa="/data/leaddiscovery/transform/scratch/globalmrn_assign/candidatepa/"
# module ="regular"

# COMMAND ----------

if module == '' or module is None:
    module = 'regular'

module=module.lower()
module=str(module)
print("module=" + str(module))


if module == "aid":
    ip_cpa = ip_cpa + "/" + module + "/"

print("ip_cpa=" + str(ip_cpa))
print("storageaccount=" + str(storageaccount))
print("bc=" + str(bc))
print("container=" + str(container))
print("user=" + str(user))

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

print("baseurl=" + str(baseurl))

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

# MAGIC %md
# MAGIC ### _Common Columns + Sql Columns + Output Column Order_

# COMMAND ----------

cpa_common_columns = [
    "admitdate",
    "clusteredacctfk",
    "clusteredacctfk_valid",
    "createdate",
    "demographicsupdatedate",
    "dischargedate",
    "dob",
    "firstname",
    "gender",
    "globalmrnifk",
    "globalmrnifk_valid",
    "hasmedicareflag",
    "hospitalfk",
    "knownmcaidflag",
    "knowntricareflag",
    "lastname",
    "medicaidnum",
    "medicalrecnum",
    "medicalrecnum_valid",
    "medicarehic",
    "middlename",
    "patientacctifk",
    "permid",
    "permid_valid",
    "primarymcaidflag",
    "referraldate",
    "secondarymcaid_afterinsuranceflag",
    "ssn",
    "ssn_valid",
    "state",
    "totalcharges",
    "trgupdatedate",
    "updatedate",
]

output_column_order = [
    "hospitalfk",
    "firstname",
    "middlename",
    "lastname",
    "ssn",
    "dob",
    "gender",
    "state",
    "admitdate",
    "referraldate",
    "dischargedate",
    "medicalrecnum",
    "clusteredacctfk",
    "totalcharges",
    "createdate",
    "updatedate",
    "demographicsupdatedate",
    "medicarehic",
    "medicaidnum",
    "trgupdatedate",
    "patientacctifk",
    "knownmcaidflag",
    "primarymcaidflag",
    "hasmedicareflag",
    "knowntricareflag",
    "secondarymcaid_afterinsuranceflag",
    "globalmrnifk",
    "permid",
    "globalmrnifk_valid",
    "ssn_valid",
    "permid_valid",
    "medicalrecnum_valid",
    "clusteredacctfk_valid",
    "_id",
    "lsb_edipartnerfk",
    "lsb_coverageid",
    "lsb_hcsystemfk",
    "lsb_source",
    "lsb_id",
    "lsb_leadcreatedate",
    "lsb_leadupdatedate",
    "lsb_identity",
    "lsb_hospitalfklst",
    "lsb_leadsource",
    "lsb_xrefsource",
    "lsb_firstname",
    "lsb_middlename",
    "lsb_lastname",
    "lsb_gender",
    "lsb_dob",
    "lsb_ssn",
    "lsb_state",
    "lsb_demoupdatedate",
    "keyname",
]

common_output_sql = """
SELECT 
    admitdate,
    clusteredacctfk,
    clusteredacctfk_valid,
    createdate,
    demographicsupdatedate,
    dischargedate,
    dob,
    firstname,
    gender,
    globalmrnifk,
    globalmrnifk_valid,
    hasmedicareflag,
    hospitalfk,
    knownmcaidflag,
    knowntricareflag,
    lastname,
    medicaidnum,
    medicalrecnum,
    medicalrecnum_valid,
    medicarehic,
    middlename,
    patientacctifk,
    permid,
    permid_valid,
    primarymcaidflag,
    referraldate,
    secondarymcaid_afterinsuranceflag,
    ssn,
    ssn_valid,
    state,
    totalcharges,
    trgupdatedate,
    updatedate,
    substring(leadid, 1, locate('_', leadid) - 1)                                       AS lsb_edipartnerfk,
    substring(leadid, locate('_', leadid) + 1, length(leadid))                          AS lsb_coverageid,
    split(key,'_')[0]                                                                   AS lsb_hcsystemfk,
    split(key,'_')[1]                                                                   AS lsb_source,
    _id                                                                                 AS lsb_id,
    leadcreatedate                                                                      AS lsb_leadcreatedate,
    leadupdatedate                                                                      AS lsb_leadupdatedate,
    identity                                                                            AS lsb_identity,
    split(value.hospitalfk, '\\\\|')                                                    AS lsb_hospitalfklst,
    split(value.leadsource, '\\\\|')                                                    AS lsb_leadsource,
    split(value.xrefsource, '\\\\|')                                                    AS lsb_xrefsource,
    CASE WHEN LOWER(value.firstname) == 'none' THEN NULL ELSE value.firstname END       AS lsb_firstname,
    CASE WHEN LOWER(value.middlename) == 'none' THEN NULL ELSE value.middlename END     AS lsb_middlename,
    CASE WHEN LOWER(value.lastname) == 'none' THEN NULL ELSE value.lastname END         AS lsb_lastname,
    CASE WHEN LOWER(value.gender) == 'none' THEN NULL ELSE value.gender END             AS lsb_gender,
    CASE WHEN LOWER(value.dob) == 'none' THEN NULL ELSE value.dob END                   AS lsb_dob,
    CASE WHEN LOWER(value.ssn) == 'none' THEN NULL ELSE value.ssn END                   AS lsb_ssn,
    CASE WHEN LOWER(value.state) == 'none' THEN NULL ELSE value.state END               AS lsb_state,
    CASE WHEN LOWER(value.updatedate) == 'none' THEN NULL ELSE value.updatedate END     AS lsb_demoupdatedate
FROM """

# COMMAND ----------

# MAGIC %md
# MAGIC ### Candidate Patient Accounts : Divide in separate dataFrames

# COMMAND ----------

# DBTITLE 1,CPA
cpa_path = baseurl+ip_cpa+bc

#handing 3 leadGenType to detrmine the Write directories
lead_gen_type = next((keyword for keyword in ['globalmrn_assign', 'medicareleads', 'medicaidleads'] if keyword in cpa_path), None)
print("lead_gen_type", lead_gen_type)

#aligning the schema , if any missing columns then pad it with ''
df_cpa = spark.read.format("parquet").load(cpa_path)
for column in cpa_common_columns:
    if column not in df_cpa.columns:
        df_cpa = df_cpa.withColumn(column, lit(''))
df_cpa = df_cpa.selectExpr(cpa_common_columns)

# Candidate Patient Accounts : SSN
df_cpa_S  = df_cpa.where(df_cpa.ssn_valid == 1).withColumn("keyvalue", concat(lit('S_'), df_cpa.ssn)).dropDuplicates()

# Candidate Patient Accounts : PERMID
df_cpa_P  = df_cpa.where(df_cpa.permid_valid == 1).withColumn("keyvalue", concat(lit('P_'), df_cpa.permid)).dropDuplicates()

# Candidate Patient Accounts : GMRNID
df_cpa_G  = df_cpa.where(df_cpa.globalmrnifk_valid == 1).withColumn("keyvalue", concat(lit('G_'), df_cpa.globalmrnifk)).dropDuplicates()

# Candidate Patient Accounts : CLUSTERFK
df_cpa_CH = df_cpa.where(df_cpa.clusteredacctfk_valid == 1).withColumn("keyvalue", concat(lit('CH_'), col("hospitalfk"), lit("_"), df_cpa.clusteredacctfk)).dropDuplicates()


# Candidate Patient Accounts : MRN
df_cpa_MH = df_cpa.where(df_cpa.medicalrecnum_valid == 1).withColumn("keyvalue", concat(lit('MH_'), col("hospitalfk"), lit("_"), trim(df_cpa.medicalrecnum))).dropDuplicates()

N = 50
df_cpa_S  = df_cpa_S.withColumn("salt", hash("keyvalue") % N)
df_cpa_P  = df_cpa_P.withColumn("salt", hash("keyvalue") % N)
df_cpa_G  = df_cpa_G.withColumn("salt", hash("keyvalue") % N)
df_cpa_CH = df_cpa_CH.withColumn("salt", hash("keyvalue") % N)
df_cpa_MH = df_cpa_MH.withColumn("salt", hash("keyvalue") % N)

# COMMAND ----------

# MAGIC %md
# MAGIC ### leadservicebase data : Divide in separate dataFrames

# COMMAND ----------

# DBTITLE 1,leadservicebase
leadservicebase = spark.read.format("delta").load(baseurl+"/data/leadservicebase/publish/served/leadservicebase/")

# leads : leadservicebase : GMRNID
leadservicebase_G   = leadservicebase.withColumn("key",split(col("_id"),"_")[0]).filter(col("key").isNotNull()).where((col("key") == "G")).withColumn("keyvalue", col("identity"))
# leads : leadservicebase : PERMID
leadservicebase_P   = leadservicebase.withColumn("key",split(col("_id"),"_")[0]).filter(col("key").isNotNull()).where((col("key") == "P")).withColumn("keyvalue", col("identity"))
# leads : leadservicebase : SSN
leadservicebase_S   = leadservicebase.withColumn("key",split(col("_id"),"_")[0]).filter(col("key").isNotNull()).where((col("key") == "S")).withColumn("keyvalue", col("identity"))
# leads : leadservicebase : MRN
leadservicebase_MH  = leadservicebase.withColumn("key",split(col("_id"),"_")[0]).filter(col("key").isNotNull()).where((col("key") == "MH")).withColumn("keyvalue", col("identity"))
# leads : leadservicebase : CLUSTERFK
leadservicebase_CH  = leadservicebase.withColumn("key",split(col("_id"),"_")[0]).filter(col("key").isNotNull()).where((col("key") == "CH")).withColumn("keyvalue", col("identity"))

N = 50
leadservicebase_G  = leadservicebase_G.withColumn("salt", hash("keyvalue") % N)
leadservicebase_P  = leadservicebase_P.withColumn("salt", hash("keyvalue") % N)
leadservicebase_S  = leadservicebase_S.withColumn("salt", hash("keyvalue") % N)
leadservicebase_CH = leadservicebase_CH.withColumn("salt", hash("keyvalue") % N)
leadservicebase_MH = leadservicebase_MH.withColumn("salt", hash("keyvalue") % N)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prepare leads found based on G {[globalmrnifk]}

# COMMAND ----------

leadservicebase_GXCPA = df_cpa_G.join(
    leadservicebase_G,
    (df_cpa_G.salt == leadservicebase_G.salt) & (df_cpa_G.keyvalue == leadservicebase_G.keyvalue),
    "inner"
).select(
    df_cpa_G["*"],
    leadservicebase_G["_id"],
    leadservicebase_G["leadid"],
    leadservicebase_G["leadcreatedate"],
    leadservicebase_G["leadupdatedate"],
    leadservicebase_G["identity"],
    leadservicebase_G["demographics"]
).drop("salt")

leadservicebase_GXCPA = leadservicebase_GXCPA.select("*", explode_outer("demographics")).drop("demographics")
leadservicebase_GXCPA.createOrReplaceTempView("leadservicebase_GXCPA")
sql_GXCPA = common_output_sql + "leadservicebase_GXCPA"
leadservicebase_GXCPA = spark.sql(sql_GXCPA).withColumn("keyname", lit('globalmrnifk')).withColumn("_id", col("lsb_id"))
leadservicebase_GXCPA = leadservicebase_GXCPA.selectExpr(output_column_order)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prepare leads found based on P {[permid]}

# COMMAND ----------

leadservicebase_PXCPA = df_cpa_P.join(
    leadservicebase_P,
    (df_cpa_P.salt == leadservicebase_P.salt) & (df_cpa_P.keyvalue == leadservicebase_P.keyvalue),
    "inner"
).select(
    df_cpa_P["*"],
    leadservicebase_P["_id"],
    leadservicebase_P["leadid"],
    leadservicebase_P["leadcreatedate"],
    leadservicebase_P["leadupdatedate"],
    leadservicebase_P["identity"],
    leadservicebase_P["demographics"]
).drop("salt")

leadservicebase_PXCPA = leadservicebase_PXCPA.select("*", explode_outer("demographics")).drop("demographics")
leadservicebase_PXCPA.createOrReplaceTempView("leadservicebase_PXCPA")
sql_PXCPA = common_output_sql + "leadservicebase_PXCPA"
leadservicebase_PXCPA = spark.sql(sql_PXCPA).withColumn("keyname", lit('permid')).withColumn("_id", col("lsb_id"))
leadservicebase_PXCPA = leadservicebase_PXCPA.selectExpr(output_column_order)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prepare leads found based on S {[ssn]}

# COMMAND ----------

leadservicebase_SXCPA = df_cpa_S.join(
    leadservicebase_S,
    (df_cpa_S.salt == leadservicebase_S.salt) & (df_cpa_S.keyvalue == leadservicebase_S.keyvalue),
    "inner"
).select(
    df_cpa_S["*"],
    leadservicebase_S["_id"],
    leadservicebase_S["leadid"],
    leadservicebase_S["leadcreatedate"],
    leadservicebase_S["leadupdatedate"],
    leadservicebase_S["identity"],
    leadservicebase_S["demographics"]
).drop("salt")

leadservicebase_SXCPA = leadservicebase_SXCPA.select("*", explode_outer("demographics")).drop("demographics")
leadservicebase_SXCPA.createOrReplaceTempView("leadservicebase_SXCPA")
sql_SXCPA = common_output_sql + "leadservicebase_SXCPA"
leadservicebase_SXCPA = spark.sql(sql_SXCPA).withColumn("keyname", lit('ssn')).withColumn("_id", col("lsb_id"))
leadservicebase_SXCPA = leadservicebase_SXCPA.selectExpr(output_column_order)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prepare leads found based on MH {[medicalrecnum]}

# COMMAND ----------

leadservicebase_MHXCPA = df_cpa_MH.join(
    leadservicebase_MH,
    (df_cpa_MH.salt == leadservicebase_MH.salt) & (df_cpa_MH.keyvalue == leadservicebase_MH.keyvalue),
    "inner"
).select(
    df_cpa_MH["*"],
    leadservicebase_MH["_id"],
    leadservicebase_MH["leadid"],
    leadservicebase_MH["leadcreatedate"],
    leadservicebase_MH["leadupdatedate"],
    leadservicebase_MH["identity"],
    leadservicebase_MH["demographics"]
).drop("salt")

leadservicebase_MHXCPA = leadservicebase_MHXCPA.select("*", explode_outer("demographics")).drop("demographics")
leadservicebase_MHXCPA.createOrReplaceTempView("leadservicebase_MHXCPA")
sql_MHXCPA = common_output_sql + "leadservicebase_MHXCPA"
leadservicebase_MHXCPA = spark.sql(sql_MHXCPA).withColumn("keyname", lit('medicalrecnum')).withColumn("_id", col("lsb_id"))
leadservicebase_MHXCPA = leadservicebase_MHXCPA.selectExpr(output_column_order)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prepare leads found based on CH {[clusteredacctfk]}

# COMMAND ----------

leadservicebase_CHXCPA = df_cpa_CH.join(
    leadservicebase_CH,
    (df_cpa_CH.salt == leadservicebase_CH.salt) & (df_cpa_CH.keyvalue == leadservicebase_CH.keyvalue),
    "inner"
).select(
    df_cpa_CH["*"],
    leadservicebase_CH["_id"],
    leadservicebase_CH["leadid"],
    leadservicebase_CH["leadcreatedate"],
    leadservicebase_CH["leadupdatedate"],
    leadservicebase_CH["identity"],
    leadservicebase_CH["demographics"]
).drop("salt")

leadservicebase_CHXCPA = leadservicebase_CHXCPA.select("*", explode_outer("demographics")).drop("demographics")
leadservicebase_CHXCPA.createOrReplaceTempView("leadservicebase_CHXCPA")
sql_CHXCPA = common_output_sql + "leadservicebase_CHXCPA"
leadservicebase_CHXCPA = spark.sql(sql_CHXCPA).withColumn("keyname", lit('clusteredacctfk')).withColumn("_id", col("lsb_id"))
leadservicebase_CHXCPA = leadservicebase_CHXCPA.selectExpr(output_column_order)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Prepare leads to write to _disk_

# COMMAND ----------

hdfs_int_path ="/data/leaddiscovery/transform/scratch/"+lead_gen_type+"/candidatepaleadsmerged/"

if module == "aid":
    hdfs_int_path = baseurl + hdfs_int_path + module + "/"+ bc
else :
    hdfs_int_path = baseurl + hdfs_int_path + bc

print({"WRITE to hdfs_int_path": hdfs_int_path})
import time
spark.conf.set("spark.sql.shuffle.partitions", "auto")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Parallel Write 

# COMMAND ----------

from concurrent.futures import ThreadPoolExecutor
timings = {}

def write_data_to_disk(df, path, name):
    start = time.time()
    df.write.format("parquet").mode("overwrite").save(path)
    timings[name] = time.time() - start

dfs = [
    (leadservicebase_GXCPA,  hdfs_int_path + "/globalmrnifk/", "globalmrnifk"),
    (leadservicebase_PXCPA,  hdfs_int_path + "/permid/", "permid"),
    (leadservicebase_SXCPA,  hdfs_int_path + "/ssn/", "ssn"),
    (leadservicebase_MHXCPA, hdfs_int_path + "/medicalrecnum/", "medicalrecnum"),
    (leadservicebase_CHXCPA, hdfs_int_path + "/clusteredacctfk/", "clusteredacctfk")
]

with ThreadPoolExecutor(max_workers=5) as executor:
    futures = [executor.submit(write_data_to_disk, df, path, name) for df, path, name in dfs]
    for future in futures:
        future.result()

display(timings)
