# Databricks notebook source
# DBTITLE 1,input parameters
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("ip_cpa","")
dbutils.widgets.getArgument("ip_cpa")
ip_cpa= getArgument("ip_cpa")

dbutils.widgets.text("ip_lsb_id","")
dbutils.widgets.getArgument("ip_lsb_id")
ip_lsb_id= getArgument("ip_lsb_id")

dbutils.widgets.text("op_cpa_xlsbhelper","")
dbutils.widgets.getArgument("op_cpa_xlsbhelper")
op_cpa_xlsbhelper= getArgument("op_cpa_xlsbhelper")

#number of files in op
rep_val=50

# COMMAND ----------

import os
import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window

# COMMAND ----------

# DBTITLE 1,adls access
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# DBTITLE 1,basepath
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

# DBTITLE 1,common util
# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

#from pyspark import SparkContext
#from pyspark.conf import SparkConf
#conf = SparkConf()
#sc = SparkContext(conf=conf)
#sc.addPyFile(fs_common + "/common_util.py")
#import common_util as cu
#spark = SparkSession.builder.appName('candidatepaXssnXpermXgmrnXclustXmrn').getOrCreate()
#spark.sparkContext.setLogLevel("ERROR")
#spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)

# COMMAND ----------

df_cpa = readparquet(spark, baseurl+ip_cpa+bc, '0', 'na').dropDuplicates()
df_lsb_id = readparquet(spark, baseurl+ip_lsb_id, '0', 'na').selectExpr("lookupvalue", "_id", "keyname").dropDuplicates()

df_cpa_ssn = df_cpa.where(df_cpa.ssn_valid == 1).select("ssn").withColumn("keyvalue", concat(lit('S_'), df_cpa.ssn)).drop("ssn")
df_cpa_permid = df_cpa.where(df_cpa.permid_valid == 1).select("permid").withColumn("keyvalue", concat(lit('P_'), df_cpa.permid)).drop("permid")
df_cpa_globalmrnifk = df_cpa.where(df_cpa.globalmrnifk_valid == 1).select("globalmrnifk").withColumn("keyvalue", concat(lit('G_'), df_cpa.globalmrnifk)).drop("globalmrnifk")
df_cpa_clusteredacctfk = df_cpa.where(df_cpa.clusteredacctfk_valid == 1).select("hospitalfk", "clusteredacctfk").withColumn("keyvalue", concat(lit('CH_'), col("hospitalfk"), lit("_"), df_cpa.clusteredacctfk)).drop("hospitalfk", "clusteredacctfk")
df_cpa_medicalrecnum = df_cpa.where(df_cpa.medicalrecnum_valid == 1).select("hospitalfk", "medicalrecnum").withColumn("keyvalue", concat(lit('MH_'), col("hospitalfk"), lit("_"), trim(df_cpa.medicalrecnum))).drop("hospitalfk", "medicalrecnum")

df_lsb_id_ssn = df_lsb_id.where(col("keyname") == "ssn")
df_lsb_id_permid = df_lsb_id.where(col("keyname") == "permid")
df_lsb_id_globalmrnifk = df_lsb_id.where(col("keyname") == "globalmrnifk")
df_lsb_id_clusteredacctfk = df_lsb_id.where(col("keyname") == "clusteredacctfk")
df_lsb_id_medicalrecnum = df_lsb_id.where(col("keyname") == "medicalrecnum")

df_cpaxlsb_ssn = df_cpa_ssn.join(df_lsb_id_ssn, df_cpa_ssn.keyvalue == df_lsb_id_ssn.lookupvalue).select(df_cpa_ssn.keyvalue, df_lsb_id_ssn._id).dropDuplicates()
df_cpaxlsb_permid = df_cpa_permid.join(df_lsb_id_permid, df_cpa_permid.keyvalue == df_lsb_id_permid.lookupvalue).select(df_cpa_permid.keyvalue, df_lsb_id_permid._id).dropDuplicates()
df_cpaxlsb_globalmrnifk = df_cpa_globalmrnifk.join(df_lsb_id_globalmrnifk, df_cpa_globalmrnifk.keyvalue == df_lsb_id_globalmrnifk.lookupvalue).select(df_cpa_globalmrnifk.keyvalue, df_lsb_id_globalmrnifk._id).dropDuplicates()
df_cpaxlsb_clusteredacctfk = df_cpa_clusteredacctfk.join(df_lsb_id_clusteredacctfk, df_cpa_clusteredacctfk.keyvalue == df_lsb_id_clusteredacctfk.lookupvalue).select(df_cpa_clusteredacctfk.keyvalue, df_lsb_id_clusteredacctfk._id).dropDuplicates()
df_cpaxlsb_medicalrecnum = df_cpa_medicalrecnum.join(df_lsb_id_medicalrecnum, df_cpa_medicalrecnum.keyvalue == df_lsb_id_medicalrecnum.lookupvalue).select(df_cpa_medicalrecnum.keyvalue, df_lsb_id_medicalrecnum._id).dropDuplicates()

# COMMAND ----------

writeparquet(spark, df_cpaxlsb_ssn, baseurl+op_cpa_xlsbhelper+bc+ "/ssn", rep_val, "overwrite")
writeparquet(spark, df_cpaxlsb_permid, baseurl+op_cpa_xlsbhelper+bc+ "/permid", rep_val, "overwrite")
writeparquet(spark, df_cpaxlsb_globalmrnifk, baseurl+op_cpa_xlsbhelper+bc+ "/globalmrnifk", rep_val, "overwrite")
writeparquet(spark, df_cpaxlsb_clusteredacctfk, baseurl+op_cpa_xlsbhelper+bc + "/clusteredacctfk", rep_val, "overwrite")
writeparquet(spark, df_cpaxlsb_medicalrecnum, baseurl+op_cpa_xlsbhelper+bc + "/medicalrecnum", rep_val, "overwrite")