# Databricks notebook source
# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

def create_temp_data(spark, hdfs_input, hdfs_scratch):
    # creating foundcoverage scratch data to avoid read and write conflicts in code
    hdfs_scratch_fc_data = hdfs_scratch + "/tmpdata/foundcoverage"
    fccols = ["hospitalfk", "patientacctifk", "edipartnerfk", "coverageid", "foundcoverageipk", "groupnumber", "currentinferredsourcemethodcode"]

    fc = extract_deltalake_data(spark, hdfs_input + "/foundcoverage/current/20991231/", fccols).dropDuplicates()

    fcscols = ["inferredsourcemethodcode", "edisourcedflag"]
    fcs = extract_parquet_data(spark, hdfs_input + "/foundcoverageinferredsourcemethodcodes/current/*", fcscols)
    #fcs = fcs.where("edisourcedflag=='1'")# Disabled on 10/17/2024 to address low volume issues
    fc = fc.withColumn('patientacctifk', fc.patientacctifk.cast('bigint'))
    fc = fc.withColumn("coverageid_grpno", when((fc.coverageid.contains(fc.groupnumber)) & (fc.groupnumber != ''), substring_index(fc.coverageid, '-', 1)).otherwise(fc.coverageid))

    fc_fcs = fc.join(fcs, fcs.inferredsourcemethodcode == fc.currentinferredsourcemethodcode, "inner").select(fc['*'])
    fc_fcs.write.mode("overwrite").parquet(hdfs_scratch_fc_data)

def delete_temp_data(spark, hdfs_scratch):
    hdfs_scratch_fc_data = hdfs_scratch + "/tmpdata/foundcoverage"
    # proc_tmpdata = subprocess.Popen(['hadoop', 'fs', '-rm', '-r', hdfs_scratch_fc_data])
    # proc_tmpdata.communicate()
    dbutils.fs.rm(hdfs_scratch_fc_data, True)

def extract_parquet_data(spark, hdfs_path, cols=None):
    if cols == '' or cols is None:
        df = spark.read.parquet(hdfs_path)
    else:
        df = spark.read.parquet(hdfs_path).select(cols)
    return df

# COMMAND ----------

def extract_explode_leads(spark, hdfs_leads_input):
    all_leads = extract_parquet_data(spark, hdfs_leads_input)
    all_leads = all_leads.dropDuplicates()
    all_leads = all_leads.withColumn('associationsource', when(col("keyname") == "globalmrnifk", 'GM'). \
                                     when(col("keyname") == "permid", 'PI'). \
                                     when(col("keyname") == "ssn", 'SH'). \
                                     when(col("keyname") == "medicalrecnum", 'MR'). \
                                     when(col("keyname") == "clusteredacctfk", 'CA'))
    all_leads = all_leads.withColumn('keyvalue', when(col("keyname") == "globalmrnifk", 1). \
                                     when(col("keyname") == "permid", 2). \
                                     when(col("keyname") == "ssn", 3). \
                                     when(col("keyname") == "medicalrecnum", 4). \
                                     when(col("keyname") == "clusteredacctfk", 5))
    all_leads = all_leads.withColumn('demohash', hash(concat_ws(":", all_leads.lsb_firstname, all_leads.lsb_middlename, all_leads.lsb_lastname, all_leads.lsb_gender, all_leads.lsb_dob, all_leads.lsb_ssn, all_leads.lsb_state)))
    all_leads = all_leads.withColumn("lsb_hospitalfk", explode(col("lsb_hospitalfklst"))).drop("lsb_hospitalfklst")
    all_leads = all_leads.withColumn("lsb_leadsourcevalue", explode(col("lsb_leadsource"))).drop("lsb_leadsource")
    all_leads = all_leads.withColumn("lsb_xrefsourcevalue", explode(col("lsb_xrefsource"))).drop("lsb_xrefsource")
    ## Cast dates as Timestamp instead of string
    all_leads = all_leads.withColumn('lsb_leadcreatedate', all_leads.lsb_leadcreatedate.cast('timestamp')). \
        withColumn('lsb_leadupdatedate', all_leads.lsb_leadupdatedate.cast('timestamp')). \
        withColumn('lsb_dob', all_leads.lsb_dob.cast('timestamp')). \
        withColumn('lsb_demoupdatedate', all_leads.lsb_demoupdatedate.cast('timestamp')). \
        withColumn('lsb_edipartnerfk', all_leads.lsb_edipartnerfk.cast('int'))
    return all_leads

# COMMAND ----------

def write_log_trail(spark, all_leads, stepname, step, hdfs_scratch):
    debug_mode = 0
    if (debug_mode == 1):
        all_leads = all_leads.select("patientacctifk", "hospitalfk", "admitdate", "dischargedate", "lsb_dob", "lsb_edipartnerfk", "lsb_coverageid") \
            .dropDuplicates()
        all_leads = all_leads.withColumn("stepname", lit(stepname)) \
            .withColumn("step", lit(step))

        all_leads = all_leads.select([col(c).cast("string") for c in all_leads.columns]) \
            .write.mode("overwrite") \
            .parquet(hdfs_scratch + '/logtrail/' + stepname)

# COMMAND ----------

def filter_coverageid_len_admitdt(spark, all_leads, hdfs_admitdt_path, hdfs_scratch):
    ##
    ## 9/22/2025 :: Updated the minimum coverage id lenght to 6    
    ##
    all_leads_len = all_leads.filter(length(trim(all_leads.lsb_coverageid)) > 5)
    hospadmitdate = extract_parquet_data(spark, hdfs_admitdt_path)
    
    hospadmitdate = hospadmitdate.withColumn('maxsearchduration',hospadmitdate.maxsearchduration.cast(IntegerType())).withColumn('minsearchduration',hospadmitdate.minsearchduration.cast(IntegerType()))
    all_leads_len.createOrReplaceTempView("leads")
    hospadmitdate.createOrReplaceTempView("ha")
    leads = spark.sql("""
                      SELECT pa.*
                      FROM leads pa inner join ha ON pa.hospitalfk = ha.hospitalfk
                        AND pa.lsb_edipartnerfk = ha.edipartnerpk
                      WHERE
                      (   (pa.admitdate between date_sub(current_date(),ha.maxsearchduration) and date_sub(current_date(),ha.minsearchduration))
                       OR (pa.admitdate between current_date() and date_add(current_date(),366))
                      )""")
    write_log_trail(spark, leads, 'filter_coverageid_len_admitdt', 1, hdfs_scratch)
    return leads

# COMMAND ----------

def filter_commerical_tricare_edipartners(spark, all_leads, hdfs_input, hdfs_scratch):
    # TESTING i/p Param
    # hdfs_input = "/hcedata/user/phd9appl/CDD/publish/escan/data/"
    # hdfs_scratch = "/user/phd9uat/tmp/hdfs_scratch/"
    # all_leads = spark.read.parquet("/workspace/hceleads/user/phd9uat/testingtricare/20211107T23-IX/*")
    # TESTING i/p Param
    ptcol = ['edipartnertypepk', 'iscommercial', 'istricare']
    partnertype = extract_parquet_data(spark, hdfs_input + "/edipartnertype/current/*", ptcol)
    partnertype = partnertype.withColumn('edipartnertypepk', partnertype.edipartnertypepk.cast('int'))
    pcol = ['edipartnertypefk', 'allowknownmedicaidqueriesflag', 'edipartnerpk']
    partners = extract_parquet_data(spark, hdfs_input + "/edipartners/current/*", pcol)
    pt = partners.join(partnertype, partners.edipartnertypefk == partnertype.edipartnertypepk)
    pt.createOrReplaceTempView("pt")
    all_leads.createOrReplaceTempView("leads_all")
    leads_all = spark.sql("""
    SELECT l.*
    FROM leads_all l
      INNER JOIN pt ON CAST (pt.edipartnerpk AS BIGINT) = CAST (l.lsb_edipartnerfk AS BIGINT)
    WHERE (pt.iscommercial = 1 AND NOT (pt.allowknownmedicaidqueriesflag = 0 AND l.knownmcaidflag = 1))
    OR    (pt.istricare = 1 AND l.knowntricareflag = 0)
    """).dropDuplicates()
    leads_all.createOrReplaceTempView("leads_all")
    # hdfs_scratch_tmp = hdfs_scratch + "/all_leads_ct/"
    lead_set_01 = spark.sql(""" SELECT leads_all.*,'587' AS lsb_edipartnerfk_mod FROM leads_all WHERE leads_all.lsb_edipartnerfk = '64'  AND leads_all.knowntricareflag = '0' """)
    lead_set_01 = lead_set_01.drop("lsb_edipartnerfk").withColumnRenamed("lsb_edipartnerfk_mod", "lsb_edipartnerfk").dropDuplicates()
    lead_set_02 = spark.sql(""" SELECT leads_all.*,'64'  AS lsb_edipartnerfk_mod FROM leads_all WHERE leads_all.lsb_edipartnerfk = '587' AND leads_all.knowntricareflag = '0' """)
    lead_set_02 = lead_set_02.drop("lsb_edipartnerfk").withColumnRenamed("lsb_edipartnerfk_mod", "lsb_edipartnerfk").dropDuplicates()
    lead_set_03 = spark.sql(""" SELECT leads_all.*,lsb_edipartnerfk AS lsb_edipartnerfk_mod FROM leads_all """)
    lead_set_03 = lead_set_03.drop("lsb_edipartnerfk").withColumnRenamed("lsb_edipartnerfk_mod", "lsb_edipartnerfk").dropDuplicates()
    leads_sets = lead_set_01.union(lead_set_02).union(lead_set_03)
    write_log_trail(spark, leads_sets, 'filter_commerical_tricare_edipartners', 2, hdfs_scratch)
    return leads_sets

# COMMAND ----------

def filter_mincharges_by_partner(spark, all_leads, hdfs_input, hdfs_scratch):
    epa_cols = ["edipartnerattributepk", "attributedefaultvalue"]
    edipartnerattributes = spark.read.parquet(hdfs_input + "/edipartnerattributes/current/*").select(epa_cols)
    edipartnerattributes = edipartnerattributes.withColumn("edipartnerattributepk", blank_as_null("edipartnerattributepk"))
    edipartnerattributes = edipartnerattributes.withColumn("attributedefaultvalue", blank_as_null("attributedefaultvalue"))
    edipartnerattributes.createOrReplaceTempView("edipartnerattributes")
    epav_cols = ["edipartnerfk", "edipartnerattributefk", "edipartnerattributevalue"]
    edipartnerattributevalues = spark.read.parquet(hdfs_input + "/edipartnerattributevalues/current/*").select(epav_cols)
    edipartnerattributevalues = edipartnerattributevalues.withColumn("edipartnerfk", blank_as_null("edipartnerfk"))
    edipartnerattributevalues = edipartnerattributevalues.withColumn("edipartnerattributevalue", blank_as_null("edipartnerattributevalue"))
    edipartnerattributevalues.createOrReplaceTempView("edipartnerattributevalues")

    all_leads.createOrReplaceTempView("all_leads")

    min_SQL = """
             SELECT DISTINCT a.*
             FROM all_leads a
			 LEFT JOIN edipartnerattributevalues pav 
                               ON a.lsb_edipartnerfk = pav.edipartnerfk
			      AND pav.edipartnerattributefk = 6
			 LEFT JOIN edipartnerattributes pa 
                              ON pa.edipartnerattributepk = pav.edipartnerattributefk
			     AND pa.edipartnerattributepk = 6 
			 WHERE a.totalcharges >= COALESCE(pav.edipartnerattributevalue,pa.attributedefaultvalue,"0.01")
          """
    all_leads_1 = spark.sql(min_SQL)

    write_log_trail(spark, all_leads_1, 'filter_mincharges_by_partner', 4, hdfs_scratch)

    return all_leads_1

# COMMAND ----------

def filter_ifexistsinfc(spark, all_leads, hdfs_input, hdfs_scratch):
    hdfs_scratch_fc_data = hdfs_scratch + "/tmpdata/foundcoverage"
    fc = readparquet(spark, hdfs_scratch_fc_data, "0", "na")

    all_leads_c = all_leads.join(fc, (all_leads.hospitalfk == fc.hospitalfk) & \
                                 (all_leads.patientacctifk == fc.patientacctifk) & \
                                 (all_leads.lsb_edipartnerfk == fc.edipartnerfk), "inner").select(all_leads['*'], fc.coverageid_grpno)

    # cmp_udf = udf(compare_coverageid, IntegerType())
    all_leads_c = all_leads_c.withColumn('coveragematch', compare_coverageid_spark(all_leads_c.lsb_coverageid, all_leads_c.coverageid_grpno))
    all_leads_c = all_leads_c.filter("coveragematch = 1 ")
    columns_to_drop = ['coverageid_grpno', 'coveragematch']
    all_leads_c = all_leads_c.drop(*columns_to_drop)
    leads = all_leads.exceptAll(all_leads_c)

    write_log_trail(spark, leads, 'filter_ifexistsinfc', 5, hdfs_scratch)

    return leads

# COMMAND ----------

def filter_ifhpn_notenabled(spark, all_leads, hdfs_input, hdfs_scratch):
    hpncols = ["hospitalfk", "edipartnerfk", "enabled"]
    hpn = extract_parquet_data(spark, hdfs_input + "/hospitalprovidernums/current/*", hpncols)
    hpn = hpn.where("enabled =='1'")
    all_leads_hpn = all_leads.join(hpn, ((all_leads.hospitalfk == hpn.hospitalfk) & (all_leads.lsb_edipartnerfk == hpn.edipartnerfk))).select(all_leads['*'])
    write_log_trail(spark, all_leads_hpn, 'filter_ifhpn_notenabled', 3, hdfs_scratch)
    return all_leads_hpn

# COMMAND ----------

def applywallingoff(spark, all_leads, hdfs_input, hdfs_scratch):
    hospcols = ["hcsystemfk", "hospitalpk", "allowaggregationinflag", "allowaggregationoutflag"]
    hospitals = extract_parquet_data(spark, hdfs_input + "/hospitals/current/*", hospcols)
    hospitals = hospitals.withColumn("allowaggregationoutflag", blank_as_null("allowaggregationoutflag")) \
        .withColumn("allowaggregationinflag", blank_as_null("allowaggregationinflag"))
    hccols = ["hcsystempk", "allowaggregationinflag", "allowaggregationoutflag"]
    hcsystems = extract_parquet_data(spark, hdfs_input + "/hcsystems/current/*", hccols)
    hcsystems = hcsystems.withColumn("allowaggregationoutflag", blank_as_null("allowaggregationoutflag")) \
        .withColumn("allowaggregationinflag", blank_as_null("allowaggregationinflag"))
    fcleads = all_leads.where((upper(all_leads.lsb_source).isin('FC', 'CHC', 'MH')) | ((upper(all_leads.lsb_source) == 'FM') & (upper(all_leads.lsb_leadsourcevalue) == 'FC')))
    hospitals.createOrReplaceTempView("hospitals")
    hcsystems.createOrReplaceTempView("hcsystems")
    fcleads.createOrReplaceTempView("allfcleads")
    fcleadsql = """select a.*\
       		   from allfcleads a\
       		   join hospitals h on a.hospitalfk = h.hospitalpk\
                   join hcsystems hc on h.hcsystemfk = hc.hcsystempk\
                   join hospitals h2 on a.lsb_hospitalfk = h2.hospitalpk\
                   join hcsystems hc2 on h2.hcsystemfk = hc2.hcsystempk\
                   where (( coalesce(h.allowaggregationinflag ,hc.allowaggregationinflag ,1)=1\
                         and coalesce(h2.allowaggregationoutflag, hc2.allowaggregationoutflag,1)=1\
                        ) or h2.hcsystemfk = h.hcsystemfk\
                        ) """
    fcleads = spark.sql(fcleadsql)
    leads = all_leads.where(~((upper(all_leads.lsb_source).isin('FC', 'CHC','MH')) | ((upper(all_leads.lsb_source) == 'FM') & (upper(all_leads.lsb_leadsourcevalue) == 'FC')))).union(fcleads)
    write_log_trail(spark, leads, 'applywallingoff', 6, hdfs_scratch)
    return leads

# COMMAND ----------

def run_checkmode(spark, all_leads, hdfs_input, hdfs_scratch):
    gpcol = ["paramvalue", "description"]
    globalparam = extract_parquet_data(spark, hdfs_input + "/escanglobalparameters/current/*", gpcol)
    globalparam = globalparam.where("description=='fcleadtransitiontohdpflag'").select("paramvalue")
    transflag = "0"
    algorithm = "FOUNDCOVERAGE"
    leadmode = ["H", "AH"]
    transflag = globalparam.collect()[0][0]
    df_config = spark.read.parquet(hdfs_input + "/edileadsourcetransition/current/*")
    all_leads = all_leads.join(df_config, (all_leads.hospitalfk == df_config.hospitalfk) & (all_leads.lsb_edipartnerfk == df_config.edipartnerfk), "left") \
        .select(all_leads['*'], df_config.pacctcreatecutoffdate.alias("config_patientacctcreatedate").cast('timestamp'), \
                df_config.leadcreatecutoffdate.alias("config_leadcreatedate").cast('timestamp'), \
                df_config.edileadsourcetransitionpk.cast('long'), df_config.mode, df_config.algorithm)
    leads_hasconfig = all_leads.where(~all_leads.edileadsourcetransitionpk.isNull() \
                                      & (upper(trim(all_leads.algorithm)) == algorithm) \
                                      & (upper(trim(all_leads.mode)).isin(leadmode)) \
                                      & (((all_leads.config_patientacctcreatedate.isNull()) | (all_leads.createdate >= all_leads.config_patientacctcreatedate) | \
                                          (all_leads.demographicsupdatedate >= all_leads.config_patientacctcreatedate)) \
                                         | (all_leads.config_leadcreatedate.isNull() | (all_leads.lsb_leadcreatedate >= all_leads.config_leadcreatedate))))
    leads_hasconfig = leads_hasconfig.drop("patientacctcreatedate") \
        .drop("config_patientacctcreatedate") \
        .drop("config_leadcreatedate") \
        .drop("mode") \
        .drop("algorithm")

    write_log_trail(spark, leads_hasconfig, 'run_checkmode', 0, hdfs_scratch)
    if (transflag == '0'):
        return leads_hasconfig
    else:
        leads_hasnoconfig = all_leads.where(all_leads.edileadsourcetransitionpk.isNull()) \
            .drop("patientacctcreatedate") \
            .drop("config_patientacctcreatedate") \
            .drop("config_leadcreatedate") \
            .drop("mode") \
            .drop("algorithm")
        leads = leads_hasconfig.union(leads_hasnoconfig)
        return leads

# COMMAND ----------

def run_checkmode_dryrun(spark, all_leads, hdfs_input):
    gpcol = ["paramvalue", "description"]
    globalparam = extract_parquet_data(spark, hdfs_input + "/escanglobalparameters/current/*", gpcol)
    globalparam = globalparam.where("description=='fcleadtransitiontohdpflag'").select("paramvalue")
    transflag = "0"
    algorithm = "FOUNDCOVERAGE"
    leadmode = ["H", "AH"]
    transflag = globalparam.collect()[0][0]
    return all_leads

# COMMAND ----------

def addedidatasourcefk(spark, all_leads, hdfs_maprdb_input, hdfs_scratch):
    df = spark.read.parquet(hdfs_maprdb_input)
    # df = spark.loadFromMapRDB(hdfs_maprdb_input) #spark.read.parquet(hdfs_maprdb_input)
    all_leads_ich = all_leads.filter(upper(all_leads.lsb_leadsourcevalue) == 'ICH')
    all_leads_fc = all_leads.filter(upper(all_leads.lsb_xrefsourcevalue) == 'FC')
    all_leads_chc = all_leads.filter(upper(all_leads.lsb_leadsourcevalue) == 'CHC')
    all_leads_fm = all_leads.filter(upper(all_leads.lsb_xrefsourcevalue) == 'FM')
    all_leads_hfc = all_leads.filter(upper(all_leads.lsb_xrefsourcevalue) == 'GH')
    edi_hfc  = df.join(all_leads_hfc,  (upper(all_leads_hfc.lsb_xrefsourcevalue)  == upper(df.leaddatasource))  & (upper(all_leads_hfc.lsb_leadsourcevalue)  == upper(df.leadsource)) & (upper(all_leads_hfc.associationsource)  == upper(df.associationsource))).select(all_leads_hfc['*'], df.edidatasourcefk)
    edi_fm  = df.join(all_leads_fm,  (upper(all_leads_fm.lsb_xrefsourcevalue)  == upper(df.leadsource))      & (upper(all_leads_fm.associationsource)    == upper(df.associationsource))).select(all_leads_fm['*'], df.edidatasourcefk)
    edi_chc = df.join(all_leads_chc, (upper(all_leads_chc.lsb_leadsourcevalue) == upper(df.leaddatasource))  & (upper(all_leads_chc.associationsource)   == upper(df.associationsource))).select(all_leads_chc['*'], df.edidatasourcefk)
    edi_ich = df.join(all_leads_ich, (upper(all_leads_ich.lsb_leadsourcevalue) == upper(df.leaddatasource))  & (upper(all_leads_ich.lsb_xrefsourcevalue) == upper(df.leadsource)) & (upper(all_leads_ich.associationsource) == upper(df.associationsource))).select(all_leads_ich['*'], df.edidatasourcefk)
    edi_fc  = df.join(all_leads_fc,  (upper(all_leads_fc.lsb_xrefsourcevalue)  == upper(df.leaddatasource))  & (upper(all_leads_fc.lsb_leadsourcevalue)  == upper(df.leadsource)) & (upper(all_leads_fc.associationsource)  == upper(df.associationsource))).select(all_leads_fc['*'], df.edidatasourcefk)
    edi = edi_ich.union(edi_fc).union(edi_chc).union(edi_fm).union(edi_hfc).dropDuplicates()
    edi = edi.dropDuplicates()
    write_log_trail(spark, edi, 'addedidatasourcefk', 7, hdfs_scratch)
    return edi

# COMMAND ----------

def bestleadselection(spark, all_leads, bc, hdfs_scratch):
    lf1 = all_leads
    lf1 = lf1.withColumn('breadcrumb', lit(bc))
    lf1.createOrReplaceTempView('lf1')
    final = spark.sql("""
    SELECT
           breadcrumb,
           patientacctifk,
           hospitalfk,
           hospitalname,
           firstname,
           middlename,
           lastname,
           dob,
           ssn,
           gender,
           state,
           admitdate,
           dischargedate,
           clusteredacctfk,
           totalcharges,
           npi,
           CAST(lsb_edipartnerfk AS SMALLINT) AS lsb_edipartnerfk,
           lsb_coverageid,
           lsb_leadsourcevalue                AS lsb_leadsource,
           lsb_xrefsourcevalue                AS lsb_xrefsource,
           lsb_firstname,
           lsb_middlename,
           lsb_lastname,
           lsb_gender,
           lsb_dob,
           lsb_ssn,
           lsb_state,
           0 AS usefamilydataflag,
           CAST(edidatasourcefk AS SMALLINT) AS edidatasourcefk,
           lsb_id AS edidatasourcetablekey,
           associationsource,
           demohash,
           keyvalue,
           lsb_demoupdatedate,
           medicarehic,
           medicaidnum,
           ROW_NUMBER() OVER (PARTITION BY patientacctifk,hospitalfk,lsb_edipartnerfk,lsb_coverageid,lsb_id 
           ORDER BY CAST(lsb_demoupdatedate AS TIMESTAMP) DESC,demohash DESC, lsb_leadsourcevalue asc, lsb_xrefsourcevalue asc) AS rn
    FROM lf1
    """)
    # final = final.filter("rn = 1").drop("rn")
    final = final.filter("rn = 1")
    final.createOrReplaceTempView('lf2')
    final2 = spark.sql("""
    SELECT 
           breadcrumb,
           patientacctifk,
           hospitalfk,
           hospitalname,
           firstname,
           middlename,
           lastname,
           dob,
           ssn,
           gender,
           state,
           admitdate,
           dischargedate,
           clusteredacctfk,
           totalcharges,
           npi,
           lsb_edipartnerfk,
           lsb_coverageid,
           lsb_leadsource,
           lsb_xrefsource,
           lsb_firstname,
           lsb_middlename,
           lsb_lastname,
           lsb_gender,
           lsb_dob,
           lsb_ssn,
           lsb_state,
           usefamilydataflag,
           edidatasourcefk,
           edidatasourcetablekey,
           associationsource,
           demohash,
           keyvalue,
           medicarehic,
           medicaidnum,
           ROW_NUMBER() OVER (PARTITION BY patientacctifk,hospitalfk,lsb_edipartnerfk,upper(trim(lsb_coverageid)),rn ORDER BY CAST(keyvalue AS INT) ASC, edidatasourcetablekey) AS rn2
    FROM lf2
    """)
    final2 = final2.filter("rn2 = 1").drop("rn2").drop("rn").drop("keyvalue")
    write_log_trail(spark, final2, 'bestleadselection', 10, hdfs_scratch)
    return final2

# COMMAND ----------

def blank_as_null(x):
    return when(((trim(col(x)) != "") & (trim(lower(col(x))) != "null")), col(x)).otherwise(None)

# COMMAND ----------

def ohibatchprocess_disabled(spark, all_leads, hdfs_input):
    all_leads = all_leads.withColumn("npi", lit(''))
    all_leads = all_leads.withColumn("hospitalname", lit(''))
    return all_leads

# COMMAND ----------

def ohibatchprocess(spark, all_leads, hdfs_input, hdfs_scratch):
    hpc = extract_parquet_data(spark, hdfs_input + "/hospitalpayercob/current/*").select("hospitalfk", "edipayerfk")
    papc_cols = ["hospitalfk", "patientacctifk", "billingnpi", "billingnpiname", "groupnpi", "groupnpiname"]
    papc = extract_deltalake_data(spark, hdfs_input + "/patientacctspayercob/current/20991231/", papc_cols).dropDuplicates()
    papc = papc.withColumn("billingnpi", blank_as_null("billingnpi"))
    papc = papc.withColumn("billingnpiname", blank_as_null("billingnpiname"))
    papc = papc.withColumn("groupnpi", blank_as_null("groupnpi"))
    papc = papc.withColumn("groupnpiname", blank_as_null("groupnpiname"))

    hnpi = extract_parquet_data(spark, hdfs_input + "/hospitalnpioverrides/current/*").select("hospitalfk", "edipartnerfk", "npi", "activefor270")
    hnpi = hnpi.withColumn("npi", blank_as_null("npi"))
    payer = extract_parquet_data(spark, hdfs_input + "/edipartners/current/*").select("edipartnerpk", "edipayerfk")

    hpc.createOrReplaceTempView('hospitalpayercob')
    papc.createOrReplaceTempView('patientacctspayercob')
    hnpi.createOrReplaceTempView('hospitalnpioverrides')
    payer.createOrReplaceTempView('edipartners')
    all_leads.createOrReplaceTempView('all_leads')

    cSQL = """
    SELECT
      DISTINCT a.*,
      CASE WHEN isnull(hpc.hospitalfk) THEN '' ELSE COALESCE(hnpi.npi, pp.groupnpi,pp.billingnpi) END as npi,
      CASE WHEN isnull(hpc.hospitalfk) THEN '' ELSE COALESCE(pp.groupnpiname,pp.billingnpiname) END as hospitalname,
      hnpi.activefor270,
      CASE WHEN isnull(hpc.hospitalfk) THEN 0 ELSE 1 end as isohi,
      CASE WHEN (a.hospitalfk = hpc.hospitalfk AND ep.edipayerfk = hpc.edipayerfk) THEN 1 ELSE 0 END as excludeohilead
    FROM all_leads a
    JOIN edipartners ep ON a.lsb_edipartnerfk = ep.edipartnerpk
    LEFT JOIN hospitalpayercob hpc ON a.hospitalfk = hpc.hospitalfk
    LEFT JOIN hospitalnpioverrides hnpi ON a.hospitalfk = hnpi.hospitalfk
       AND a.lsb_edipartnerfk = hnpi.edipartnerfk
       AND hnpi.activefor270 = '1'
    LEFT JOIN patientacctspayercob pp ON a.hospitalfk=pp.hospitalfk
       AND a.patientacctifk = pp.patientacctifk
    """

    final = spark.sql(cSQL)
    cond_2 = when( \
        ((col("excludeohilead") == 0) & (col("npi") != "")) \
        , lit(1) \
        ) \
        .otherwise(lit(0))
    cond_1 = when( \
        (col("isohi") == 1) \
        , cond_2 \
        ) \
        .otherwise(lit(1))

    final = final.withColumn("includelead", cond_1)
    final = final.where(final.includelead == 1)
    # get records into scratch folder to check lead status
    # final = final.withColumn("leadid", concat_ws("_", final.lsb_edipartnerfk, final.lsb_coverageid))

    # lead = final.filter("isohi = 1").select(final.patientacctifk,final.hospitalfk,final.leadid,final.lsb_edipartnerfk,final.lsb_coverageid,final.lsb_dob,final.admitdate,final.dischargedate)
    # lead = lead.dropDuplicates()
    # lead.write.mode("overwrite").parquet(hdfs_scratch+'/ohileads/')    

    final = final.drop("activefor270").drop("includelead")

    write_log_trail(spark, final, 'ohibatchprocess', 8, hdfs_scratch)
    return final

# COMMAND ----------

def check_ohi_leadstatus(spark, hdfs_leadstatus, all_leads, hdfs_scratch):
    lead = extract_parquet_data(spark, hdfs_scratch + '/ohileads/*')
    lead = lead.dropDuplicates()
    ct = len(lead.head(1))
    if (ct == 0):
        return all_leads
    else:
        lead = lead.withColumn('lsb_dob', to_timestamp(lead.lsb_dob))
        lead = lead.withColumn('lsb_dob', blank_as_null('lsb_dob')) \
            .withColumn('admitdate', blank_as_null('admitdate')) \
            .withColumn('dischargedate', blank_as_null('dischargedate'))

        ls = extract_parquet_data(spark, hdfs_leadstatus)
        ls = ls.withColumn('startdate', to_timestamp(ls.startdate)) \
            .withColumn('enddate', to_timestamp(ls.enddate)) \
            .withColumn('leaddob', to_timestamp(ls.dob)) \
            .withColumn('leaddob', blank_as_null('leaddob'))

        ls = ls.join(lead, (lead.leadid == ls.leadid) & (lead.lsb_dob.eqNullSafe(ls.leaddob))).select(ls["*"])
        # intermediate write for performance
        ls.dropDuplicates().write.mode("overwrite").parquet(hdfs_scratch + '/leadstatus/')

        lsraw = extract_parquet_data(spark, hdfs_scratch + '/leadstatus/*')
        lsraw = lsraw.withColumn("status", lower(lsraw.status))

        window = Window.partitionBy("leadid", "leaddob").orderBy("startdate")
        lsraw_1 = lsraw.withColumn("lagstartdate", lag(col("startdate"), 1).over(window))
        lsraw_1 = lsraw_1.withColumn("lagstartstatus", lag(col("status"), 1).over(window))

        window2 = Window.partitionBy("leadid", "leaddob").orderBy(col("enddate").desc())
        lsraw_2 = lsraw.withColumn("rn", row_number().over(window2)).where(col("rn") == 1)

        lead.createOrReplaceTempView("ohicandidatepaleads")
        lsraw_1.createOrReplaceTempView("leadstatus")
        lsraw_2.createOrReplaceTempView("leadstatusmaxenddate")

        # evaluates all conditions fro inactive check
        # conditions when is lead set to inactive
        # dt is > last max enddate for leadid, leaddob and status=inactive,  consider inactive
        # dt is between startdate and enddate and status=inactive and not exists in the dataset within date range with active, consider inactive
        # dt is between lagstartdate and startdate and lagstartdate is not null and status=inactive and lagstartstatus=inactive, consider inactive

        cSQL = """
		SELECT c.admitdate,c.dischargedate,c.leadid, c.lsb_dob
		FROM ohicandidatepaleads c
		JOIN leadstatus l ON c.leadid=l.leadid
		   AND lsb_dob <=> l.leaddob
		WHERE
		(
		  (
			c.admitdate BETWEEN l.startdate AND l.enddate
			AND status='inactive'
			AND NOT EXISTS
			(
			  SELECT 1
			  FROM leadstatus z
			  WHERE c.leadid=z.leadid
				AND lsb_dob <=> z.leaddob
				AND c.admitdate BETWEEN z.startdate AND z.enddate
				AND z.status='active'
			)

		  )
		  OR
		  (
			c.admitdate BETWEEN l.lagstartdate AND l.startdate
			AND l.lagstartdate IS NOT NULL
			AND l.status='inactive'
			AND l.lagstartstatus='inactive'
		  )
		  OR EXISTS
		  (
                      SELECT 1
                      FROM leadstatusmaxenddate m
                      WHERE c.leadid=m.leadid
                        AND c.lsb_dob <=> m.leaddob
                        AND c.admitdate > m.enddate
                        AND m.status='inactive'
		  )
		)
		OR
		( 
		  (
			c.dischargedate BETWEEN l.startdate AND l.enddate
			AND status='inactive'
			AND NOT EXISTS
			(
			  SELECT 1
			  FROM leadstatus z
			  WHERE c.leadid=z.leadid
				AND c.lsb_dob <=> z.leaddob
				AND c.dischargedate BETWEEN z.startdate AND z.enddate
				AND z.status='active'
			)

		  )
		  OR
		  (
			c.dischargedate BETWEEN l.lagstartdate AND l.startdate
			AND l.lagstartdate IS NOT NULL
			AND status='inactive'
			AND lagstartstatus='inactive'
		  )
		  OR EXISTS
		  (
                      SELECT 1
                      FROM leadstatusmaxenddate m
                      WHERE c.leadid=m.leadid
                        AND c.lsb_dob <=> m.leaddob
                        AND c.dischargedate > m.enddate
                        AND m.status='inactive'
		  )
		)

       """
        inactivedf = spark.sql(cSQL)
        # intermediate write
        inactivedf.dropDuplicates().write.mode("overwrite").parquet(hdfs_scratch + "/inactive")

        ## get all ohi inactive candidatepaleads
        inactive = extract_parquet_data(spark, hdfs_scratch + '/inactive/')

        all_leads.createOrReplaceTempView("candidatepaleads")
        inactive.createOrReplaceTempView("inactiveleads")
        cSQL_int = """
       SELECT DISTINCT o.patientacctifk,o.hospitalfk,o.lsb_edipartnerfk,o.lsb_coverageid,o.lsb_dob,o.admitdate,o.dischargedate
       FROM ohicandidatepaleads o
       JOIN inactiveleads i ON  o.admitdate <=> i.admitdate
           AND o.dischargedate <=> i.dischargedate
           AND o.leadid = i.leadid
           AND o.lsb_dob <=> i.lsb_dob
       """

        ohi_inactive = spark.sql(cSQL_int)
        ohi_inactive.createOrReplaceTempView("ohiinactivecandidatepaleads")

        ## get all candidatepaleads without the inactive candidatepaleads

        cSQL_final = """
       SELECT DISTINCT a.*
       FROM candidatepaleads a
       WHERE NOT EXISTS 
       (
          SELECT 1
          FROM ohiinactivecandidatepaleads o
          WHERE a.patientacctifk = o.patientacctifk
            AND a.hospitalfk = o.hospitalfk
            AND a.lsb_edipartnerfk = o.lsb_edipartnerfk
            AND a.lsb_coverageid = o.lsb_coverageid
            AND a.lsb_dob <=> o.lsb_dob
            AND a.admitdate <=> o.admitdate
            AND a.dischargedate <=> o.dischargedate
       )
       """

        final_output = spark.sql(cSQL_final)

        write_log_trail(spark, final_output, 'check_ohi_leadstatus', 9, hdfs_scratch)
        return final_output

# COMMAND ----------

# DBTITLE 1,Coverage ID utils
def removegrpno_coverageid(df):
    df = df.withColumn("coverageid_grpno", when((df.coverageid.contains(df.groupnumber)) & (df.groupnumber != ''), substring_index(df.coverageid, '-', 1)).otherwise(df.coverageid))
    return df

def compare_coverageid(str1, str2):
    val1 = str(str1).strip()
    val2 = str(str2).strip()
    if ((val1 == val2)):
        return 1
    else:
        return 0

def return_coverageid(str1, str2):
    val1 = str(str1).strip()
    val2 = str(str2).strip()
    if ((val1 in val2) | (val2 in val1)):
        if (len(val1) < len(val2)):
            return val1
        else:
            return val2
    else:
        return 0
    
def compare_coverageid_spark(str1, str2):
    return when(trim(str1) == trim(str2), 1).otherwise(0)

# COMMAND ----------

def filter_blacklisted_partnerpolicyid(spark, all_leads, blacklist_accts, hdfs_input, hdfs_scratch):
    blacklist_accts.createOrReplaceTempView("partnerpolicyidblacklists")
    all_leads.createOrReplaceTempView("lead")

    leads = spark.sql(""" SELECT l.*
                               FROM lead l 
                               WHERE NOT EXISTS ( SELECT 1
                                     FROM   partnerpolicyidblacklists bl
                                     WHERE  bl.edipartnerfk = l.lsb_edipartnerfk
                                     AND ( ( bl.coverageid = l.lsb_coverageid )
				      	OR ( bl.coverageid LIKE '%' + l.lsb_coverageid + '%' )
					OR ( l.lsb_coverageid LIKE '%' + bl.coverageid + '%' ) ) )
                      """)
    write_log_trail(spark, leads, 'filter_blacklisted_partnerpolicyid', 11, hdfs_scratch)
    return leads  

# COMMAND ----------

def get_real_verified_hit_foundcoverages(spark, hdfs_input, hdfs_scratch):
    # creating real verified hit found coverages
    hdfs_scratch_fc_data = hdfs_scratch + "/tmpdata/foundcoverage"
    fccols = ["hospitalfk", "patientacctifk", "edipartnerfk", "coverageid", "foundcoverageipk", "groupnumber", "currentinferredsourcemethodcode"]
    fc = extract_deltalake_data(spark, hdfs_input + "/foundcoverage/current/20991231/", fccols).dropDuplicates()
    fc = fc.filter("hitstatus in ('1','2')") #fc hitstatus filter
    fc = fc.withColumn('patientacctifk', fc.patientacctifk.cast('bigint'))
    fc = fc.withColumn("coverageid_grpno", when((fc.coverageid.contains(fc.groupnumber)) & (fc.groupnumber != ''), substring_index(fc.coverageid, '-', 1)).otherwise(fc.coverageid))
    
    fcscols = ["inferredsourcemethodcode", "edisourcedflag"]
    fcs = extract_parquet_data(spark, hdfs_input + "/foundcoverageinferredsourcemethodcodes/current/*", fcscols)
    #fcs = fcs.where("edisourcedflag=='1'")# Disabled on 10/17/2024 to address low volume issues
    fcs= fcs.filter("inferredflag=0") #Added this filter on 12/12/2024 to get the real verified records
    
    fc_fcs = fc.join(fcs, fcs.inferredsourcemethodcode == fc.currentinferredsourcemethodcode, "inner").select(fc['*']) #join fc and fcismc
    
    ediqueriescols = ["hospitalfk", "edipartnerfk", "patientacctifk", "ediquerypk"]
    dfediqueries = extract_deltalake_data(spark,hdfs_input +"/ediqueries/current/20991231/",ediqueriescols)
    
    dfediqueryhitsmissescols = ['ediqueryfk', 'policyid', 'result']
    dfediqueryhitsmisses = extract_deltalake_data(spark,hdfs_input+ "/ediqueryhitsandmisses/current/20991231/",dfediqueryhitsmissescols)
    dfediqueryhitsmisses = dfediqueryhitsmisses.where((dfediqueryhitsmisses.result.like("EB%")) & (dfediqueryhitsmisses.result !='EB:V')) #hit coverages
    
    fc_ediqueries = fc_fcs.join(dfediqueries, (dfediqueries.hospitalfk == fc_fcs.hospitalfk) & (dfediqueries.edipartnerfk==fc_fcs.edipartnerfk) & (dfediqueries.patientacctifk==fc_fcs.patientacctifk), "inner").select(fc_fcs['*'],dfediqueries['ediquerypk'])
    
    fc_ediqueries_hitsmisses = fc_ediqueries.join(dfediqueryhitsmisses, (fc_ediqueries.ediquerypk == dfediqueryhitsmisses.ediqueryfk) & (fc_ediqueries.coverageid_grpno==dfediqueryhitsmisses.policyid) , "inner").select(fc_ediqueries['*'])
    fc_ediqueries_hitsmisses = fc_ediqueries_hitsmisses.drop('ediquerypk')
    
    fc_ediqueries_hitsmisses.write.mode("overwrite").parquet(hdfs_scratch_fc_data)

# COMMAND ----------

# This functions returns all the medicaid leads to the configured edipartnerfk
# This function added to common to be used for medicaid leads generation and medicaid helpers
# This function is used to configure medicaid partners in a phased way to migrate from SQL to Databricks
def check_edipartner_config(spark, all_leads, hdfs_input, hdfs_scratch, input_edipartnerattributefk):
    epa_cols = ["edipartnerattributepk", "attributedefaultvalue", "activeflag"]   
    edipartnerattributes = spark.read.parquet(hdfs_input + "/edipartnerattributes/current/*").select(epa_cols)
    edipartnerattributes = edipartnerattributes.withColumn("edipartnerattributepk",blank_as_null("edipartnerattributepk"))
    edipartnerattributes = edipartnerattributes.withColumn("attributedefaultvalue",blank_as_null("attributedefaultvalue"))
    edipartnerattributes.createOrReplaceTempView("edipartnerattributes")
    epav_cols = ["edipartnerfk","edipartnerattributefk","edipartnerattributevalue"]
    edipartnerattributevalues = spark.read.parquet(hdfs_input + "/edipartnerattributevalues/current/*").select(epav_cols)
    edipartnerattributevalues = edipartnerattributevalues.withColumn("edipartnerfk",blank_as_null("edipartnerfk"))
    edipartnerattributevalues = edipartnerattributevalues.withColumn("edipartnerattributevalue",blank_as_null("edipartnerattributevalue"))
    edipartnerattributevalues.createOrReplaceTempView("edipartnerattributevalues")
    
    all_leads.createOrReplaceTempView("all_leads") 
    cpa_SQL = """
			 SELECT a.*, coalesce(pav.edipartnerattributevalue, pa.attributedefaultvalue) AS enableflag
			 FROM all_leads a
			 LEFT JOIN edipartnerattributevalues pav
			 	ON a.lsb_edipartnerfk = pav.edipartnerfk
			 JOIN edipartnerattributes pa
			 	ON pa.edipartnerattributepk = pav.edipartnerattributefk
			 WHERE pav.edipartnerattributefk = 
		  """ + input_edipartnerattributefk + " AND pa.activeflag = 1"    
    all_leads_cpa = spark.sql(cpa_SQL) 
    all_leads_cpa = all_leads_cpa.filter("enableflag == 1")    
    write_log_trail(spark,all_leads_cpa,'check_edipartner_config',0,hdfs_scratch)  
    return all_leads_cpa

# COMMAND ----------

def getpartnerconfig(base_url):
    try:
        # Read the edipartnerattributevalues table for edipartnerattributefk == 42 which gives the list of partners on which the filter can be applied 
        edi_partners_df = spark.read.format("parquet").load(f"{base_url}/data/dataingestion/publish/edipartnerattributevalues/current/20991231/")
        edi_partners_df = edi_partners_df.filter("edipartnerattributefk = 42 AND  edipartnerattributevalue = 1").select("edipartnerfk").distinct()        
        partnerFilter = [str(partners[0]) for partners in edi_partners_df.collect()]  
        return partnerFilter
    except Exception as e:
        raise Exception("Error reading edipartnerattributevalues table: {}".format(e))

def applypartnerandproviderfilter(all_leads_df, hdfs_input, base_url):
    all_leads_df.createOrReplaceTempView("AllLeads")
    hospitals_df = extract_parquet_data(spark, hdfs_input + "/hospitals/current/20991231/")
    hospitals_df.createOrReplaceTempView("Hospitals")
    partnerFilter = getpartnerconfig(base_url)

    partnerProviderQuery = """
                                SELECT /*+ BROADCAST(h) */
                                    al.*
                                FROM AllLeads al
                                INNER JOIN Hospitals h
                                    ON al.HospitalFK = h.hospitalpk
                                WHERE h.Active = 1
                                AND h.ProviderTypeFK <> 10
                            """
    # Run the query
    partner_provider_df = spark.sql(partnerProviderQuery).filter(col("lsb_edipartnerfk").isin(partnerFilter)).dropDuplicates()
    # display(df_filter)
    return partner_provider_df

# COMMAND ----------

def filter_past_billing_deadline(all_leads_df, hdfs_input, hdfs_scratch, base_url):
    edi_billing_dl_rules_df = extract_parquet_data(spark, hdfs_input + "/edipartnershospitalbilldlrules/current/20991231/")
    edi_billing_dl_rules_df.createOrReplaceTempView("EdiPartnersHospitalBillDLRule")
    provider_filtered_leads_df = applypartnerandproviderfilter(all_leads_df, hdfs_input, base_url)
    provider_filtered_leads_df.createOrReplaceTempView("AllLeads")
    edi_partners_df = extract_parquet_data(spark, hdfs_input + "/edipartners/current/20991231/")
    edi_partners_df.createOrReplaceTempView("EdiPartners")

    billingDeadlineQuery = """
                            SELECT /*+ BROADCAST(epart, ebrule) */
                                al.*,
                                CASE
                                    WHEN ebrule.EDIPartnersHospitalBillDLRulePK IS NOT NULL AND ebrule.BDDelayServiceDateUnits = 'd' 
                                        THEN DATE_ADD(al.AdmitDate, CAST(ebrule.BDDelayServiceDate AS INT))
                                    WHEN ebrule.EDIPartnersHospitalBillDLRulePK IS NOT NULL AND ebrule.BDDelayServiceDateUnits = 'm' 
                                        THEN ADD_MONTHS(al.AdmitDate, CAST(ebrule.BDDelayServiceDate AS INT))
                                    WHEN ebrule.EDIPartnersHospitalBillDLRulePK IS NULL AND epart.bddelayservicedateunits = 'd' 
                                        THEN DATE_ADD(al.AdmitDate, CAST(epart.bddelayservicedate AS INT))
                                    WHEN ebrule.EDIPartnersHospitalBillDLRulePK IS NULL AND epart.bddelayservicedateunits = 'm' 
                                        THEN ADD_MONTHS(al.AdmitDate, CAST(epart.bddelayservicedate AS INT))
                                    ELSE NULL
                                END AS BillingDeadLine
                            FROM AllLeads al
                            INNER JOIN EdiPartners epart
                                ON al.lsb_edipartnerfk = epart.EDIPartnerPK and epart.isenabledflag = 1
                            LEFT JOIN EdiPartnersHospitalBillDLRule ebrule
                                ON al.HospitalFK = ebrule.HospitalFK and al.lsb_edipartnerfk = ebrule.EDIPartnerFK and ebrule.EnabledFlag = 1
                        """

    billing_deadline_df = spark.sql(billingDeadlineQuery)
    billing_deadline_df.createOrReplaceTempView("BillingDeadline")
    billingDeadlineFilterQuery = """
                                    SELECT * FROM BillingDeadline WHERE BillingDeadLine < CURRENT_DATE() AND BillingDeadLine IS NOT NULL """

    billing_deadline_rejected_df = spark.sql(billingDeadlineFilterQuery)

    # Writing the rejected leads to the scratch path
    writeparquet(spark, billing_deadline_rejected_df, hdfs_scratch + "/all_leads_billing_deadline_rejected", 0, "overwrite")    
    billing_deadline_rejected_df = billing_deadline_rejected_df.drop("bddelayservicedateunits", "bddelayservicedate", "BillingDeadLine")
    all_leads_billing_deadline_df = all_leads_df.subtract(billing_deadline_rejected_df)
    #all_leads_billing_deadline_df = all_leads_df #temporary code
    return all_leads_billing_deadline_df


# COMMAND ----------

def filter_known_coverages(all_leads_df, hdfs_input, hdfs_scratch, base_url):
   
    appliedPartnersList = getpartnerconfig(base_url)
    
    payerCols = ['edipayerpk']
    partnerCols = ['edipartnerpk','edipayerfk','isenabledflag']
    edi_payers_df = extract_parquet_data(spark, hdfs_input + "/edipayers/current/*",payerCols)
    edi_partners_df = extract_parquet_data(spark, hdfs_input + "/edipartners/current/*", partnerCols)

    edi_applied_payers_df = (
    edi_partners_df.alias("partners")
    .join(edi_payers_df.alias("payers"), col("payers.edipayerpk") == col("partners.edipayerfk"))
    .filter((col("partners.edipartnerpk").isin(appliedPartnersList)) & (col("partners.isenabledflag") == 1))
    .select(col("payers.edipayerpk")).distinct()
    )
    
    appliedPayersList = ", ".join([f"'{row['edipayerpk']}'" for row in edi_applied_payers_df.collect()])
 
    all_leads_applied_parters_df = applypartnerandproviderfilter(all_leads_df, hdfs_input, base_url) 
    all_leads_applied_parters_df.createOrReplaceTempView("AllLeadsAppliedParters")
    
    paacctCodesCols = ['patientacctifk','hospitalfk','InsuranceCode1','InsuranceCode2','InsuranceCode3','InsuranceCode4','ins1policyid','ins2policyid','ins3policyid','ins4policyid']
    
    hospInsCodesCols = ['hospitalfk','code','hospinsurancecodepk','edipayerfk']
    
    patientaccctscodes_df = extract_deltalake_data(spark, hdfs_input + "/patientacctscodes/current/20991231/", paacctCodesCols).dropDuplicates()
    hospinsurancecodes_df = extract_deltalake_data(spark, hdfs_input + "/hospinsurancecodes/current/20991231/", hospInsCodesCols).dropDuplicates()
    
    paacctCodesColsToClean = ['ins1policyid','ins2policyid','ins3policyid','ins4policyid']
    for col_name in paacctCodesColsToClean:
        patientaccctscodes_df = patientaccctscodes_df.withColumn(
        col_name, regexp_replace(col(col_name), '"', "")
        )

    hospinsurancecodes_df = hospinsurancecodes_df.withColumn("code", regexp_replace(col("code"), '"', ""))   
    
    patientaccctscodes_df.createOrReplaceTempView("PatientAcctsCodes")
    hospinsurancecodes_df.createOrReplaceTempView("HospInsuranceCodes")
    
    coverageAndPolicyIdQuery = f"""
 	SELECT
    alap.*,
    ic1.hospinsurancecodepk AS HospInsuranceCodeFK1,
    ac.ins1policyid ,
    ic2.hospinsurancecodepk AS HospInsuranceCodeFK2,
    ac.ins2policyid ,
    ic3.hospinsurancecodepk AS HospInsuranceCodeFK3,
    ac.ins3policyid,
    ic4.hospinsurancecodepk AS HospInsuranceCodeFK4,
    ac.ins4policyid,
    
	CASE
		WHEN 
			ic1.edipayerfk IN ({appliedPayersList})
			OR ic2.edipayerfk IN ({appliedPayersList})
			OR ic3.edipayerfk IN ({appliedPayersList})
			OR ic4.edipayerfk IN ({appliedPayersList}) 
			THEN 1 
		ELSE 0 
		END 
	knownCovFlag
	FROM 
	AllLeadsAppliedParters alap
	INNER JOIN PatientAcctsCodes ac  ON ac.patientacctifk = alap.patientacctifk 
		AND ac.hospitalfk = alap.hospitalfk 
	LEFT JOIN HospInsuranceCodes ic1  ON ic1.code = ac.InsuranceCode1 
		AND ic1.hospitalfk = ac.hospitalfk
	LEFT JOIN HospInsuranceCodes ic2  ON ic2.code = ac.InsuranceCode2 
		AND ic2.hospitalfk = ac.hospitalfk
	LEFT JOIN HospInsuranceCodes ic3  ON ic3.code = ac.InsuranceCode3 
		AND ic3.hospitalfk = ac.hospitalfk
	LEFT JOIN HospInsuranceCodes ic4 ON ic4.code = ac.InsuranceCode4 
		AND ic4.hospitalfk = ac.hospitalfk
    """
    all_leads_knowcoverage_policyid_df = spark.sql(coverageAndPolicyIdQuery)
    all_leads_knowcoverage_policyid_df.createOrReplaceTempView("AllLeadsKnownCoveragePolicyId")
    
    knownCoveragesAndPolicyIdQuery = """
    SELECT 
	alkp.*
	FROM 
	AllLeadsKnownCoveragePolicyId alkp
	WHERE
	alkp.knownCovFlag = 1
	OR 
	(
			alkp.lsb_coverageid IN (alkp.Ins1PolicyID, alkp.Ins2PolicyID, alkp.Ins3PolicyID, alkp.Ins4PolicyID)
			OR
				LEFT(alkp.lsb_coverageid, 5) IN (LEFT(alkp.Ins1PolicyID,5), LEFT(alkp.Ins2PolicyID, 5), LEFT(alkp.Ins3PolicyID, 5), LEFT(alkp.Ins4PolicyID, 5))
			OR
				RIGHT(alkp.lsb_coverageid, 5) IN (RIGHT(alkp.Ins1PolicyID, 5), RIGHT(alkp.Ins2PolicyID, 5), RIGHT(alkp.Ins3PolicyID, 5), RIGHT(alkp.Ins4PolicyID, 5))
			OR
				(
					LEN(alkp.lsb_coverageid) >= 5 
					AND LEN(alkp.Ins1PolicyID) >= 5 
					AND (alkp.lsb_coverageid LIKE '%' + alkp.Ins1PolicyID + '%' OR alkp.Ins1PolicyID LIKE '%' + alkp.lsb_coverageid + '%')
				)
			OR
				(
					LEN(alkp.lsb_coverageid) >= 5 
					AND LEN(alkp.Ins2PolicyID) >= 5 
					AND (alkp.lsb_coverageid LIKE '%' + alkp.Ins2PolicyID + '%' OR alkp.Ins2PolicyID LIKE '%' + alkp.lsb_coverageid + '%')
				)
			OR
				(
					LEN(alkp.lsb_coverageid) >= 5 
					AND LEN(alkp.Ins3PolicyID) >= 5 
					AND (alkp.lsb_coverageid LIKE '%' + alkp.Ins3PolicyID + '%' OR alkp.Ins3PolicyID LIKE '%' + alkp.lsb_coverageid + '%')
				)
			OR          
				(
					LEN(alkp.lsb_coverageid) >= 5 
					AND LEN(alkp.Ins4PolicyID) >= 5 
					AND (alkp.lsb_coverageid LIKE '%' + alkp.Ins4PolicyID + '%' OR alkp.Ins4PolicyID LIKE '%' + alkp.lsb_coverageid + '%')
				)
	)
    """
    
    known_coverages_rejected_df = spark.sql(knownCoveragesAndPolicyIdQuery)
    known_coverages_rejected_df = known_coverages_rejected_df.drop("HospInsuranceCodeFK1", "ins1policyid", "HospInsuranceCodeFK2", "ins2policyid", "HospInsuranceCodeFK3", "ins3policyid", "HospInsuranceCodeFK4", "ins4policyid", "knownCovFlag","configkey", "configvalue")
    
    writeparquet(spark, known_coverages_rejected_df, hdfs_scratch + "/all_leads_known_coverage_rejected/", 0, "overwrite")
    
    all_leads_known_coverages_df = all_leads_df.subtract(known_coverages_rejected_df) 
    #all_leads_known_coverages_df = all_leads_df # temporary code
    
    return all_leads_known_coverages_df

# COMMAND ----------

def bcbs_coverage_prefix(leads_df,base_url):
    bcbsprefixtopayermappings_df = spark.read.format("parquet").load(f"{base_url}/data/dataingestion/publish/bcbsprefixtopayermappings/current/20991231/")
    bcbsprefixtopayermappings_df.createOrReplaceTempView("bcbsprefixtopayermappings")
    
    # Separate BCBS and non-BCBS leads
    leads_non_bcbs_df = leads_df.filter(col("lsb_edipartnerfk") != 101).withColumn("bcbs_payername", lit("")).withColumn("bcbs_coverageid_noprefix", lit(""))
    
    leads_bcbs_df = leads_df.filter(col("lsb_edipartnerfk") == 101)
    leads_bcbs_df.createOrReplaceTempView("leads_bcbs_df")

    # Join with prefix mapping and get bcbs_coverageid_noprefix
    leads_bcbs_prefix_df = spark.sql("""
        SELECT
            l.*,
            TRIM(b.payername) AS bcbs_payername,
            SUBSTRING(l.lsb_coverageid, LENGTH(b.bcbsprefix) + 1,LENGTH(l.lsb_coverageid)) AS bcbs_coverageid_noprefix
        FROM leads_bcbs_df l
        LEFT JOIN bcbsprefixtopayermappings b
        ON SUBSTRING(TRIM(l.lsb_coverageid), 1, 3) = TRIM(b.bcbsprefix)
    """)
    
    # Window function to deduplicate
    window_spec = Window.partitionBy("hospitalfk","patientacctifk", "bcbs_payername","lsb_edipartnerfk","bcbs_coverageid_noprefix","lsb_identity").orderBy(col("lsb_leadupdatedate").desc())
    leads_bcbs_df = leads_bcbs_prefix_df.withColumn("rn", row_number().over(window_spec)).filter(col("rn") == 1).drop("rn")
    leads_df = leads_bcbs_df.union(leads_non_bcbs_df)
    return leads_df	

# COMMAND ----------

def filter_ifexistsinfc_bcbs(spark, all_leads, hdfs_input, hdfs_scratch):
    hdfs_scratch_fc_data = hdfs_scratch + "/tmpdata/foundcoverage"
    fc = readparquet(spark, hdfs_scratch_fc_data, "0", "na")
    all_leads_bcbs = all_leads.filter("lsb_edipartnerfk = 101")
    all_leads_bcbs = all_leads_bcbs.join(fc, (all_leads_bcbs.hospitalfk == fc.hospitalfk) & \
                                 (all_leads_bcbs.patientacctifk == fc.patientacctifk) & \
                                 (all_leads_bcbs.lsb_edipartnerfk == fc.edipartnerfk), "inner").select(all_leads_bcbs['*'], fc.coverageid_grpno)
    all_leads_bcbs = all_leads_bcbs.withColumn('coveragematch', compare_coverageid_spark(all_leads_bcbs.bcbs_coverageid_noprefix, all_leads_bcbs.coverageid_grpno))
    all_leads_bcbs = all_leads_bcbs.filter("coveragematch = 1 ")
    columns_to_drop = ['coverageid_grpno', 'coveragematch']
    all_leads_bcbs = all_leads_bcbs.drop(*columns_to_drop)
    leads = all_leads.exceptAll(all_leads_bcbs)
    leads=leads.drop('bcbs_coverageid_noprefix','bcbs_payername')
    return leads
