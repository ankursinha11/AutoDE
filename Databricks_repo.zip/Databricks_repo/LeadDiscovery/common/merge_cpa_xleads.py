# Databricks notebook source
# MAGIC %md
# MAGIC #Leaddiscovery: Merge all leads

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import *
import sys
import datetime
import subprocess
from pyspark.sql import DataFrame
from pyspark import SparkContext
from pyspark.conf import SparkConf

# COMMAND ----------

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("hdfs_input_cpa_path","")
dbutils.widgets.getArgument("hdfs_input_cpa_path")
hdfs_input_cpa_path= getArgument("hdfs_input_cpa_path")

dbutils.widgets.text("hdfs_leads_input","")
dbutils.widgets.getArgument("hdfs_leads_input")
hdfs_leads_input= getArgument("hdfs_leads_input")

dbutils.widgets.text("hdfs_leads_output","")
dbutils.widgets.getArgument("hdfs_leads_output")
hdfs_leads_output= getArgument("hdfs_leads_output")

dbutils.widgets.text("op_partitions","")
dbutils.widgets.getArgument("op_partitions")
op_partitions= getArgument("op_partitions")

dbutils.widgets.text("module","")
dbutils.widgets.getArgument("module")
module= getArgument("module")

# COMMAND ----------

# bc="20240618T16"
# container="prod-icd-stg-adls"
# storageaccount="prodicdstgdls"
# user="geetha"
# hdfs_input_cpa_path="/data/leaddiscovery/transform/scratch/globalmrn_assign/candidatepa/"
# hdfs_leads_input="/data/leaddiscovery/transform/scratch/globalmrn_assign/candidatepaleads/"
# hdfs_leads_output="/data/leaddiscovery/transform/scratch/globalmrn_assign/candidatepaleadsmerged/"
# op_partitions="200"
# module="aid"

# COMMAND ----------

if module=='':
    module='regular'

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

if module =='aid':
    hdfs_input_cpa_path=hdfs_input_cpa_path+"/aid/"
    hdfs_leads_input=hdfs_leads_input+"/aid/"
    hdfs_leads_output=hdfs_leads_output+"/aid/"

# COMMAND ----------

hdfs_leads_input=baseurl+hdfs_leads_input+bc
hdfs_input_cpa_path=baseurl+hdfs_input_cpa_path+bc
hdfs_leads_output=baseurl+hdfs_leads_output+bc
op_partitions=int(op_partitions)

# COMMAND ----------

leads_s = readparquet(spark, hdfs_leads_input + "/ssn", '0', 'na')
leads_p = readparquet(spark, hdfs_leads_input + "/permid", '0', 'na')
leads_g = readparquet(spark, hdfs_leads_input + "/globalmrnifk", '0', 'na')
leads_c = readparquet(spark, hdfs_leads_input + "/clusteredacctfk", '0', 'na')
leads_m = readparquet(spark, hdfs_leads_input + "/medicalrecnum", '0', 'na')

df_cpa = readparquet(spark, hdfs_input_cpa_path, '0', 'na')

df_cpa_s = df_cpa.where(df_cpa.ssn_valid == 1)
df_cpa_p = df_cpa.where(df_cpa.permid_valid == 1)
df_cpa_g = df_cpa.where(df_cpa.globalmrnifk_valid == 1)
df_cpa_c = df_cpa.where(df_cpa.clusteredacctfk_valid == 1)
df_cpa_m = df_cpa.where(df_cpa.medicalrecnum_valid == 1)

all_cols = [df_cpa['*'],"_id","lsb_edipartnerfk","lsb_coverageid","lsb_hcsystemfk","lsb_source","lsb_id","lsb_leadcreatedate","lsb_leadupdatedate","lsb_identity","lsb_hospitalfklst","lsb_leadsource","lsb_xrefsource","lsb_firstname","lsb_middlename","lsb_lastname","lsb_gender","lsb_dob","lsb_ssn","lsb_state","lsb_demoupdatedate","keyname"]

leads_s = leads_s.join(df_cpa_s, concat(lit('S_'), df_cpa_s.ssn) == leads_s.keyvalue).select(all_cols)
leads_p = leads_p.join(df_cpa_p, concat(lit('P_'), df_cpa_p.permid) == leads_p.keyvalue).select(all_cols)
leads_g = leads_g.join(df_cpa_g, concat(lit('G_'), df_cpa_g.globalmrnifk) == leads_g.keyvalue).select(all_cols)
leads_c = leads_c.join(df_cpa_c, concat(lit('CH_'), df_cpa_c.hospitalfk, lit("_"), df_cpa_c.clusteredacctfk) == leads_c.keyvalue).select(all_cols)
leads_m = leads_m.join(df_cpa_m, concat(lit('MH_'), df_cpa_c.hospitalfk, lit("_"), df_cpa_m.medicalrecnum) == leads_m.keyvalue).select(all_cols)

writeparquet(spark, leads_s, hdfs_leads_output + "/ssn", op_partitions, "overwrite")
writeparquet(spark, leads_p, hdfs_leads_output + "/permid", op_partitions, "overwrite")
writeparquet(spark, leads_g, hdfs_leads_output + "/globalmrnifk", op_partitions, "overwrite")
writeparquet(spark, leads_c, hdfs_leads_output + "/clusteredacctfk", op_partitions, "overwrite")
writeparquet(spark, leads_m, hdfs_leads_output + "/medicalrecnum", op_partitions, "overwrite")

# COMMAND ----------


