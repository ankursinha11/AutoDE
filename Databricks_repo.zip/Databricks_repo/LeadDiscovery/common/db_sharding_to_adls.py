# Databricks notebook source
from pyspark.sql.functions import *

# COMMAND ----------

dbutils.widgets.text("tablename1","")
dbutils.widgets.getArgument("tablename1")
tablename1= getArgument("tablename1")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("check_leads_op","")
dbutils.widgets.getArgument("check_leads_op")
check_leads_op = getArgument("check_leads_op")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("module","")
dbutils.widgets.getArgument("module")
module= getArgument("module")

dbutils.widgets.text("maxRecordsPerFile", "")
dbutils.widgets.getArgument("maxRecordsPerFile")
maxRecordsPerFile = getArgument("maxRecordsPerFile")

dbutils.widgets.text("workflow_name", "")
dbutils.widgets.getArgument("workflow_name")
workflow_name = getArgument("workflow_name")

dbutils.widgets.text("dataingestion_publish_path", "")
dbutils.widgets.getArgument("dataingestion_publish_path")
dataingestion_publish_path = getArgument("dataingestion_publish_path")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

# DBTITLE 1,set basepath
#set the baseurl
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user
print("baseurl: ", baseurl)


#set the edi_payer_baseurl
edi_payer_baseurl ='abfss://edi-payer-leads@'+storageaccount+'.dfs.core.windows.net'

print("edi_payer_baseurl:", edi_payer_baseurl)

# COMMAND ----------

if module =='': 
    module="regular" 
else: 
    module=module

print("module is : "+module)

# COMMAND ----------

if module =='aid':
    hdppatientacctxlead = spark.read.parquet(baseurl+check_leads_op+'/aid/'+bc +'/' + tablename1)
else :
    hdppatientacctxlead = spark.read.parquet(baseurl+check_leads_op + bc +'/' + tablename1)


# COMMAND ----------

# Read the config file to get the shards
config_path = baseurl + dataingestion_publish_path + "/partnerxrefconfig/current/20991231/"
configcols = ["edipartnerfk", "databaseshardname"]

df_shard_config = extract_deltalake_data(spark,config_path, configcols)

#Output shards path
shard_path = edi_payer_baseurl + "/shards_inprogress/"

# COMMAND ----------

join_df = hdppatientacctxlead.join(df_shard_config, hdppatientacctxlead.lsb_edipartnerfk == df_shard_config.edipartnerfk, "left").select(hdppatientacctxlead["*"], df_shard_config["databaseshardname"])

# COMMAND ----------

if module =='aid':
    join_df2 = join_df.withColumn("databaseshardname", coalesce(col("databaseshardname"), lit("default_shard")))\
                 .withColumn("workflow_name", lit(workflow_name))\
                  .withColumn("bc", lit(bc+"-AD"))
else :
    join_df2 = join_df.withColumn("databaseshardname", coalesce(col("databaseshardname"), lit("default_shard")))\
                 .withColumn("workflow_name", lit(workflow_name))\
                  .withColumn("bc", lit(bc))

# COMMAND ----------

import pyspark.sql.functions as F
from pyspark.sql.types import IntegerType, TimestampType, DecimalType, LongType

join_df3 = join_df2.withColumn("patientacctifk", F.col("patientacctifk").cast(LongType()))\
	.withColumn("hospitalfk", F.col("hospitalfk").cast(IntegerType()))\
	.withColumn("dob", F.to_timestamp(F.col("dob")))\
	.withColumn("admitdate", F.col("admitdate").cast(TimestampType()))\
	.withColumn("dischargedate", F.col("dischargedate").cast(TimestampType()))\
	.withColumn("clusteredacctfk", F.col("clusteredacctfk").cast(IntegerType()))\
	.withColumn("totalcharges", F.col("totalcharges").cast(DecimalType(38,2)))\
	.withColumn("lsb_edipartnerfk", F.col("lsb_edipartnerfk").cast(IntegerType()))\
	.withColumn("lsb_dob", F.col("lsb_dob").cast(TimestampType()))\
	.withColumn("edidatasourcefk", F.col("edidatasourcefk").cast(IntegerType()))

# COMMAND ----------

join_df3.coalesce(1) \
        .write.option("maxRecordsPerFile", maxRecordsPerFile)\
        .mode("overwrite")\
        .partitionBy("databaseshardname","workflow_name","bc")\
        .parquet(shard_path)

# COMMAND ----------


