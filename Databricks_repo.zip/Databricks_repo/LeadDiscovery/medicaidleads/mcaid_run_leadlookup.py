# Databricks notebook source
dbutils.widgets.text("user", "")
dbutils.widgets.getArgument("user")
user = getArgument("user")

dbutils.widgets.text("container", "")
dbutils.widgets.getArgument("container")
container = getArgument("container")

dbutils.widgets.text("storageaccount", "")
dbutils.widgets.getArgument("storageaccount")
storageaccount = getArgument("storageaccount")

dbutils.widgets.text("bc", "")
dbutils.widgets.getArgument("bc")
bc = getArgument("bc")

dbutils.widgets.text("hdfs_lsb_pax", "")
dbutils.widgets.getArgument("hdfs_lsb_pax")
hdfs_lsb_pax = getArgument("hdfs_lsb_pax")

dbutils.widgets.text("hdfs_int_path", "")
dbutils.widgets.getArgument("hdfs_int_path")
hdfs_int_path = getArgument("hdfs_int_path")

dbutils.widgets.text("hdfs_leadservicebase_path", "")
dbutils.widgets.getArgument("hdfs_leadservicebase_path")
hdfs_leadservicebase_path = getArgument("hdfs_leadservicebase_path")

dbutils.widgets.text("keyname", "")
dbutils.widgets.getArgument("keyname")
keyname = getArgument("keyname")

dbutils.widgets.text("keyindex", "")
dbutils.widgets.getArgument("keyindex")
keyindex = getArgument("keyindex")

dbutils.widgets.text("store_column_name", "")
dbutils.widgets.getArgument("store_column_name")
store_column_name = getArgument("store_column_name")


dbutils.widgets.text("module", "")
dbutils.widgets.getArgument("module")
module = getArgument("module")

# COMMAND ----------

# bc="20240618T16"
# container="prod-icd-stg-adls"
# storageaccount="prodicdstgdls"
# user="geetha"
# hdfs_int_path="/data/leaddiscovery/transform/scratch/medicaid/candidatepaleads/"
# hdfs_leadservicebase_path="/data/leadservicebase/publish/served/leadservicebase/"
# hdfs_lsb_pax="/data/leaddiscovery/transform/scratch/medicaid/candidatepaxlsb/"
# keyindex="idx_identity"
# # keyname="globalmrnifk"
# # keyname="permid"
# # keyname="ssn"
# # keyname="clusteredacctfk"
# # keyname="medicalrecnum"
# store_column_name="_id"
# module="aid"

# COMMAND ----------

if module=='':
    module="regular"

module=module.lower()
module=str(module)

# COMMAND ----------

if module == "aid":
    hdfs_int_path = hdfs_int_path + "/" + module + "/"
    hdfs_lsb_pax = hdfs_lsb_pax + "/" + module + "/"

# COMMAND ----------

dbutils.notebook.run(
    "/Insleads-code/LeadDiscovery/common/LeadLookupByID_1",
    36000,
    {
        "bc": bc,
        "container": container,
        "hdfs_int_path": hdfs_int_path,
        "hdfs_leadservicebase_path": hdfs_leadservicebase_path,
        "hdfs_lsb_pax": hdfs_lsb_pax,
        "keyindex": keyindex,
        "keyname": keyname,
        "storageaccount": storageaccount,
        "store_column_name": store_column_name,
        "user": user,
    },
)

# COMMAND ----------


