# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("ip_cpa","")
dbutils.widgets.getArgument("ip_cpa")
ip_cpa= getArgument("ip_cpa")

dbutils.widgets.text("ip_lsb_id","")
dbutils.widgets.getArgument("ip_lsb_id")
ip_lsb_id= getArgument("ip_lsb_id")

dbutils.widgets.text("op_cpa_xlsbhelper","")
dbutils.widgets.getArgument("op_cpa_xlsbhelper")
op_cpa_xlsbhelper= getArgument("op_cpa_xlsbhelper")

dbutils.widgets.text("module","")
dbutils.widgets.getArgument("module")
module= getArgument("module")

# COMMAND ----------

# DBTITLE 1,SAMPLE INPUTS
# bc="20240618T16"
# container="prod-icd-stg-adls"
# ip_cpa="/data/leaddiscovery/transform/scratch/medicaid/candidatepa/"
# ip_lsb_id="/data/leadservicebase/publish/cooked/leadservicebasehelper/"
# op_cpa_xlsbhelper="/data/leaddiscovery/transform/scratch/medicaid/candidatepaxlsb/"
# storageaccount="prodicdstgdls"
# user="geetha"
# module="aid"

# COMMAND ----------

if module=='':
    module="regular"

module=module.lower()
module=str(module)

# COMMAND ----------

if module == "aid":
    op_cpa_xlsbhelper = op_cpa_xlsbhelper + "/" + module + "/"
    ip_cpa = ip_cpa + "/" + module + "/"


print("bc : " + str(bc))
print("container : " + str(container))
print("ip_cpa : " + str(ip_cpa))
print("ip_lsb_id : " + str(ip_lsb_id))
print("op_cpa_xlsbhelper : " + str(op_cpa_xlsbhelper))
print("storageaccount : " + str(storageaccount))
print("user : " + str(user))
print("module : " + str(module))

# COMMAND ----------

dbutils.notebook.run(
    "/Insleads-code/LeadDiscovery/common/cpa_lsb_xtable",
    3600,
    {
        "bc": bc,
        "container": container,
        "ip_cpa": ip_cpa,
        "ip_lsb_id": ip_lsb_id,
        "op_cpa_xlsbhelper": op_cpa_xlsbhelper,
        "storageaccount": storageaccount,
        "user": user,
    },
)

# COMMAND ----------


