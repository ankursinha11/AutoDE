# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
import datetime
import getpass
import os
import sys
import subprocess


# bc = "20240618T16-MA"
# cdd_publish = "/data/cdd/publish/"
# container = "prod-icd-stg-adls"
# dataingestion_publish = "/data/dataingestion/publish/"
# gmrn_publish = "/data/gmrn/publish/"
# hdfs_admitdatelookup ="/data/leaddiscovery/transform/scratch/medicaidleads/minmaxbyhospital/"
# storageaccount = "prodicdstgdls"
# user = "geetha"
# lead_mode_flag = "1"
# pa_path = "/data/dataingestion/publish/patientaccts/current/20991231/"
# hdfs_scratch = "/data/leaddiscovery/transform/scratch/medicaidleads/leadstatus/"
# hdfs_input = "/data/dataingestion/publish/"
# hdfs_output = "/data/leaddiscovery/transform/scratch/medicaidleads/candidatepa/"
# module = "aid"

# COMMAND ----------

# dbutils.fs.rm("abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/maxc/data/dataingestion/publish/patientacctsaccesscoordinator/current/20991231/",True)

# COMMAND ----------

dbutils.widgets.text("hdfs_input", "")
dbutils.widgets.getArgument("hdfs_input")
hdfs_input = getArgument("hdfs_input")

dbutils.widgets.text("hdfs_output", "")
dbutils.widgets.getArgument("hdfs_output")
hdfs_output = getArgument("hdfs_output")

dbutils.widgets.text("hdfs_admitdatelookup", "")
dbutils.widgets.getArgument("hdfs_admitdatelookup")
hdfs_admitdatelookup = getArgument("hdfs_admitdatelookup")

dbutils.widgets.text("lead_mode_flag", "")
dbutils.widgets.getArgument("lead_mode_flag")
lead_mode_flag = getArgument("lead_mode_flag")

dbutils.widgets.text("bc", "")
dbutils.widgets.getArgument("bc")
bc = getArgument("bc")

dbutils.widgets.text("pa_path", "")
dbutils.widgets.getArgument("pa_path")
pa_path = getArgument("pa_path")

dbutils.widgets.text("hdfs_scratch", "")
dbutils.widgets.getArgument("hdfs_scratch")
hdfs_scratch = getArgument("hdfs_scratch")

dbutils.widgets.text("user", "")
dbutils.widgets.getArgument("user")
user = getArgument("user")

dbutils.widgets.text("container", "")
dbutils.widgets.getArgument("container")
container = getArgument("container")

dbutils.widgets.text("storageaccount", "")
dbutils.widgets.getArgument("storageaccount")
storageaccount = getArgument("storageaccount")

dbutils.widgets.text("cdd_publish", "")
dbutils.widgets.getArgument("cdd_publish")
cdd_publish = getArgument("cdd_publish")

dbutils.widgets.text("gmrn_publish", "")
dbutils.widgets.getArgument("gmrn_publish")
gmrn_publish = getArgument("gmrn_publish")

dbutils.widgets.text("dataingestion_publish", "")
dbutils.widgets.getArgument("dataingestion_publish")
dataingestion_publish = getArgument("dataingestion_publish")

dbutils.widgets.text("module", "")
dbutils.widgets.getArgument("module")
module = getArgument("module")

dbutils.widgets.text("num_of_days", "")
num_of_days = dbutils.widgets.get("num_of_days")

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

print(baseurl)

# COMMAND ----------

#input paths
hdfs_input = baseurl + hdfs_input
pa_path = baseurl + pa_path
vsnappatientaccts_path = baseurl + dataingestion_publish
globalmrnxpacct_path = baseurl + gmrn_publish
permidpatientacctid_path = baseurl + cdd_publish

#output paths in if-else block
if module =='regular':
    hdfs_admitdatelookup = baseurl + hdfs_admitdatelookup + bc + '/'
    hdfs_output = baseurl + hdfs_output + bc + '/'
    hdfs_scratch = baseurl + hdfs_scratch + bc + '/'
else :
    hdfs_admitdatelookup = baseurl + hdfs_admitdatelookup + 'aid/' + bc + '/'
    hdfs_output = baseurl + hdfs_output + 'aid/' + bc + '/'
    hdfs_scratch = baseurl + hdfs_scratch + 'aid/' + bc + '/'


# COMMAND ----------

print("bc:",bc)
print("hdfs_admitdatelookup:",hdfs_admitdatelookup)
print("hdfs_input:",hdfs_input)
print("hdfs_output:",hdfs_output)
print("hdfs_scratch:",hdfs_scratch)
print("lead_mode_flag:",lead_mode_flag)
print("pa_path:",pa_path)
print("vsnappatientaccts_path:",vsnappatientaccts_path)
print("globalmrnxpacct_path:",globalmrnxpacct_path)
print("permidpatientacctid_path:",permidpatientacctid_path)

aid_bc=bc.split("-")[0]
print("aid_bc:",aid_bc)
aid_pa_path=baseurl+"/data/dataingestion/staging/input/patientaccts/"+aid_bc
aid_accounts=baseurl+"/data/dataingestion/publish/patientacctsaccesscoordinator/current/20991231/"
print("aid_pa_path:",aid_pa_path)
print("aid_accounts:",aid_accounts)
print("module:",module)

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

# MAGIC %run /Insleads-code/LeadDiscovery/common/get_candidate_patientaccts

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/tu_data_quality

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

user = getpass.getuser()

admitdate = readparquet(spark, hdfs_admitdatelookup, '0', 'na')
enddt = date_sub(current_date(), int(num_of_days))

vsnapcols = ["patientacctifk", "hospitalfk", "knownmcaidflag", "createdate"]
vsnapflags = extract_deltalake_data(spark, vsnappatientaccts_path + "/vsnappatientacctsflags/current/20991231/", vsnapcols)
vsnapflags = vsnapflags.join(admitdate, admitdate.hospitalfk == vsnapflags.hospitalfk).select(vsnapflags['*'])
vsnapflags = vsnapflags.withColumn('patientacctifk', vsnapflags.patientacctifk.cast("long"))
vsnapflags = vsnapflags.withColumnRenamed('createdate', 'vsnapflags_createdate')
vsnapflags = vsnapflags.withColumnRenamed('hospitalfk', 'vsnapflags_hospitalfk')

# print("vsnapflags : "+str(vsnapflags.count()))

if module=="aid":
    # print("AID PATACCTS")
    # print("aid_accounts" +aid_accounts)
    # print("aid_pa_path "+aid_pa_path)
    # patientaccts = get_patientacct_aid(spark,aid_pa_path,aid_accounts, lead_mode_flag,enddt, bc, admitdate,vsnapflags)
# NEW AID PATACCTS COMBINED START
    path_aidpatientaccts = baseurl + "/data/dataingestion/publish/aidpatientaccts/current/20991231/"
    path_patientacctsaccesscoordinator = baseurl + "/data/dataingestion/publish/patientacctsaccesscoordinator/current/20991231/"
    filterBc="bcupdated=='"+aid_bc+"'"
    aidpatientaccts = spark.read.format("delta").load(path_aidpatientaccts).filter(filterBc).selectExpr("patientacctifk as patientacctipk","hospitalfk").dropDuplicates()
    patientacctsaccesscoordinator = spark.read.format("parquet").load(path_patientacctsaccesscoordinator).selectExpr("patientacctifk as patientacctipk","hospitalfk").dropDuplicates()
    aidpatientaccts = aidpatientaccts.union(patientacctsaccesscoordinator)
    pacctscols = ["patientacctipk", "hospitalfk", "firstname", "middlename", "lastname", "ssn", "dob", "gender", "state", "admitdate", "referraldate", "dischargedate", "medicalrecnum", "clusteredacctfk", "totalcharges", "createdate", "updatedate", "demographicsupdatedate", "medicarehic", "medicaidnum", "trgupdatedate", "currentbalance"]
    patientaccts = get_patientacct_aid_combined(spark,aid_pa_path,pacctscols,aidpatientaccts, lead_mode_flag,enddt, bc, admitdate,vsnapflags)
# NEW AID PATACCTS COMBINED END
else :
    print("NON AID PATACCTS")
    patientaccts = get_patientacct(spark, pa_path, lead_mode_flag, enddt, bc, admitdate,vsnapflags)

# apply all filters together to get final candidate acct list
candidates = patientaccts.where(patientaccts.knownmcaidflag == 0 )
writeparquet(spark, candidates, hdfs_scratch + "/tmpdata/pa_vsnapflags", 50, "overwrite") 
candidates = readparquet(spark, hdfs_scratch + "/tmpdata/pa_vsnapflags", '0', 'na')


# Get GMRN from globalmrnxpaccts
if module=="aid":
    ca = get_globalmrn_aid(spark, globalmrnxpacct_path, candidates, aid_bc)
else :
    ca = get_globalmrn(spark, globalmrnxpacct_path, candidates, bc)

ca = get_permid(spark, permidpatientacctid_path, ca)
ca = check_valid_identities(spark, ca)
writeparquet(spark, ca, hdfs_output, 10, "overwrite")
