# Databricks notebook source
#mcaid_createlookup_maxminadmitdays.py
#dbutils.widgets.removeAll()

# COMMAND ----------

# DBTITLE 1,input parameters
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("hdfs_input","")
dbutils.widgets.getArgument("hdfs_input")
hdfs_input= getArgument("hdfs_input")

dbutils.widgets.text("hdfs_output","")
dbutils.widgets.getArgument("hdfs_output")
hdfs_output= getArgument("hdfs_output")

dbutils.widgets.text("hdfs_output_edipartnerfk","")
dbutils.widgets.getArgument("hdfs_output_edipartnerfk")
hdfs_output_edipartnerfk= getArgument("hdfs_output_edipartnerfk")

dbutils.widgets.text("module","")
dbutils.widgets.getArgument("module")
module= getArgument("module")

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
import datetime
from configparser import SafeConfigParser
from functools import reduce
from pyspark.sql import DataFrame


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

# bc="20240920T11"
# container="prod-icd-stg-adls"
# hdfs_input="/data/dataingestion/publish"
# hdfs_output="/data/leaddiscovery/transform/scratch/medicaidleads/minmaxbyhospital/"
# hdfs_output_edipartnerfk="/data/leaddiscovery/transform/scratch/medicaidleads/minmaxbyedipartnerfk/"
# storageaccount="prodicdstgdls"
# user="divya"
# module="aid"

# COMMAND ----------

if module =='regular':
    hdfs_output_edipartnerfk = hdfs_output_edipartnerfk
    hdfs_output = hdfs_output
else :
    hdfs_output_edipartnerfk = hdfs_output_edipartnerfk + 'aid/'
    hdfs_output = hdfs_output+'aid/'

print("bc: " + str(bc))
print("container: " + str(container))
print("storageaccount: " + str(storageaccount))
print("user: " + str(user))
print("module: " + str(module))
print("hdfs_input: " + str(hdfs_input))
print("hdfs_output: " + str(hdfs_output))
print("hdfs_output_edipartnerfk: " + str(hdfs_output_edipartnerfk))

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

# MAGIC %run /Insleads-code/LeadDiscovery/common/createlookup_maxminadmitdays

# COMMAND ----------

hp = readparquet(spark, baseurl+hdfs_input + "/hospitals/current/*/", '0', 'na')
hp = hp.filter(col("active") == '1')
hpn = readparquet(spark, baseurl+hdfs_input + "/hospitalprovidernums/current/*/", '0', 'na')
hpn = hpn.filter(col("enabled") == '1')
edis = readparquet(spark, baseurl+hdfs_input + "/edisubmitters/current/*/", '0', 'na')
ep = readparquet(spark, baseurl+hdfs_input + "/edipartners/current/*/", '0', 'na')
epp = readparquet(spark, baseurl+hdfs_input + "/edipartnertype/current/*/", '0', 'na')
epp = epp.filter(col("ismedicaid") == '1')
edienv = readparquet(spark, baseurl+hdfs_input + "/edipartner270settings/current/*/", '0', 'na')
epso = readparquet(spark, baseurl+hdfs_input + "/edipartnersubmittersoverrides/current/*/", '0', 'na')
ephsso = readparquet(spark, baseurl+hdfs_input + "/edipartnerhospital270settingsoverrides/current/*/", '0', 'na')
b = createlookup(spark, hp, hpn, edis, ep, edienv, epso, ephsso,epp)
a = createlookupbypartnerfk(spark, hp, hpn, edis, ep, edienv, epso, ephsso,epp)

# COMMAND ----------

writeparquet(spark, b,baseurl+hdfs_output+bc,1, "overwrite")
writeparquet(spark, a,baseurl+hdfs_output_edipartnerfk+bc,1, "overwrite")
