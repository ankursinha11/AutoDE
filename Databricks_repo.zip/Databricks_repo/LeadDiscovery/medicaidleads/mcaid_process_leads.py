# Databricks notebook source
#mcaid_process_leads

# COMMAND ----------

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("hdfs_input","")
dbutils.widgets.getArgument("hdfs_input")
hdfs_input= getArgument("hdfs_input")

dbutils.widgets.text("hdfs_leads_input","")
dbutils.widgets.getArgument("hdfs_leads_input")
hdfs_leads_input= getArgument("hdfs_leads_input")

dbutils.widgets.text("hdfs_admitdt_path","")
dbutils.widgets.getArgument("hdfs_admitdt_path")
hdfs_admitdt_path= getArgument("hdfs_admitdt_path")

dbutils.widgets.text("hdfs_output","")
dbutils.widgets.getArgument("hdfs_output")
hdfs_output= getArgument("hdfs_output")

dbutils.widgets.text("hdfs_scratch","")
dbutils.widgets.getArgument("hdfs_scratch")
hdfs_scratch= getArgument("hdfs_scratch")

input_edipartnerattributefk = '15'

dbutils.widgets.text("module","")
dbutils.widgets.getArgument("module")
module= getArgument("module")


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

# MAGIC %run /Insleads-code/LeadDiscovery/common/process_leads

# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions","auto")

# COMMAND ----------

hdfs_input = baseurl + hdfs_input

if module == "aid":
    hdfs_admitdt_path = baseurl + hdfs_admitdt_path + module + "/" + bc + "/*"
    hdfs_leads_input = baseurl + hdfs_leads_input + module + "/" + bc + "/"
    hdfs_output = baseurl + hdfs_output + module + "/" + bc + "/"
    hdfs_scratch = baseurl + hdfs_scratch + module + "/" + bc + "/"
else:
    hdfs_admitdt_path = baseurl + hdfs_admitdt_path + bc + "/*"
    hdfs_leads_input = baseurl + hdfs_leads_input + bc
    hdfs_output = baseurl + hdfs_output + bc
    hdfs_scratch = baseurl + hdfs_scratch + bc + "/"

print("hdfs_input:",hdfs_input)
print("hdfs_leads_input:",hdfs_leads_input)
print("hdfs_admitdt_path:",hdfs_admitdt_path)
print("hdfs_output:",hdfs_output)
print("hdfs_scratch:",hdfs_scratch)
current_dt = current_date()

# COMMAND ----------

def scrub_data(all_leads):
    #temporary fix or null value in coverageid from LSB
    cond_coverageid = when(\
               ( (lower(trim(col("lsb_coverageid"))).startswith("null")) )\
               ,regexp_replace(col("lsb_coverageid"),"null","")\
             )\
         .otherwise(col("lsb_coverageid"))
    all_leads = all_leads.withColumn("lsb_coverageid",cond_coverageid)

    cond_id = when(\
               ( (lower(trim(col("lsb_id"))).contains("_null")) )\
               ,regexp_replace(col("lsb_id"),"null","")\
             )\
         .otherwise(col("lsb_id"))
    all_leads = all_leads.withColumn("lsb_id",cond_id)
    #end temporary fix

    #fix for the edipartnerfk=182 not merging into 101
    cond = when(\
               ( (trim(col("lsb_edipartnerfk"))=="182") )\
               ,lit("101")\
             )\
         .otherwise(col("lsb_edipartnerfk"))
    all_leads = all_leads.withColumn("lsb_edipartnerfk",cond)

    cond_id_2 = when(\
               ( ((trim(col("lsb_edipartnerfk"))=="182") | (trim(col("lsb_edipartnerfk"))=="101") ) & (lower(trim(col("lsb_id"))).contains("_182_")) )\
               ,regexp_replace(col("lsb_id"),"_182_","_101_")\
             )\
         .otherwise(col("lsb_id"))
    all_leads = all_leads.withColumn("lsb_id",cond_id_2)

    #fix for state beign longer from ICG
    cond_state = when(\
               ( (length(trim(col("lsb_state"))) > 2 ) )\
               ,lit("")\
             )\
         .otherwise(col("lsb_state"))
    all_leads = all_leads.withColumn("lsb_state",cond_state)
    return all_leads
    

#add hardcoded edidatasourcefk= 42 for medicaid leads
def add_edidatasourcefk(all_leads_wallingoff_tmp):
    edi = all_leads_wallingoff_tmp.withColumn("edidatasourcefk",lit('42'))
    return edi

# COMMAND ----------

# DBTITLE 1,Temp filter for parity analysis 20250304
def create_temp_data_local(spark, hdfs_input, hdfs_scratch):
    # creating foundcoverage scratch data to avoid read and write conflicts in code
    hdfs_scratch_fc_data = hdfs_scratch + "/tmpdata/foundcoverage"
    fccols = ["hospitalfk", "patientacctifk", "edipartnerfk", "coverageid", "foundcoverageipk", "groupnumber", "currentinferredsourcemethodcode", "updatedate"]
    fc = extract_deltalake_data(spark, hdfs_input + "/foundcoverage/current/20991231/", fccols)
    # temp filter for parity analysis
    fc = fc.filter(fc.updatedate < date_sub(current_dt, 30))

    fcscols = ["inferredsourcemethodcode", "edisourcedflag","inferredflag"]
    fcs = extract_parquet_data(spark, hdfs_input + "/foundcoverageinferredsourcemethodcodes/current/*", fcscols)
    fcs= fcs.filter("inferredflag=0").drop("inferredflag")
    #fcs = fcs.where("edisourcedflag=='1'")# Disabled on 10/17/2024 to address low volume issues
    fc = fc.withColumn('patientacctifk', fc.patientacctifk.cast('bigint'))
    fc = fc.withColumn("coverageid_grpno", when((fc.coverageid.contains(fc.groupnumber)) & (fc.groupnumber != ''), substring_index(fc.coverageid, '-', 1)).otherwise(fc.coverageid))

    fc_fcs = fc.join(fcs, fcs.inferredsourcemethodcode == fc.currentinferredsourcemethodcode, "inner").select(fc['*'])
    fc_fcs.write.mode("overwrite").parquet(hdfs_scratch_fc_data)

# COMMAND ----------

# create_temp_data(spark,hdfs_input,hdfs_scratch)
create_temp_data_local(spark,hdfs_input,hdfs_scratch)
all_leads = extract_explode_leads(spark, hdfs_leads_input + "/*")

##Cleanup data
all_leads_clean = scrub_data(all_leads)
writeparquet(spark,all_leads_clean,hdfs_scratch + "/all_leads",0,"overwrite")
all_leads_tmp = readparquet(spark, hdfs_scratch + "/all_leads/", "0","na")

 ##Filter out blacklisted Policy Id's
blcol = ["edipartnerfk", "coverageid"]
blacklist_accts = readparquet(spark, hdfs_input + "/partnerpolicyidblacklists/current/*","1", blcol)
all_leads_nbl = filter_blacklisted_partnerpolicyid(spark, all_leads_tmp, blacklist_accts, hdfs_input, hdfs_scratch)
writeparquet(spark,all_leads_nbl,hdfs_scratch + "/all_leads_nbl",0,"overwrite")
all_leads_nbl_tmp = readparquet(spark, hdfs_scratch + "/all_leads_nbl/", "0","na")

## STEP-0: check mode and either return or proceed based on mode
leads_mode = check_edipartner_config(spark, all_leads_nbl_tmp, hdfs_input, hdfs_scratch, input_edipartnerattributefk)
writeparquet(spark,leads_mode,hdfs_scratch + "/run_checkmode",0,"overwrite")
leads_mode_tmp = readparquet(spark, hdfs_scratch + "/run_checkmode/", "0","na")
a_count = len(leads_mode_tmp.head(1))

ret_val = 0

if (a_count == 0):
    print("Transition flag : 0 and No config found for edipartner.")
    #exit()
else:
## STEP-1:
    all_leads_len_admitdt = filter_coverageid_len_admitdt(spark, leads_mode_tmp, hdfs_admitdt_path,hdfs_scratch)
    writeparquet(spark, all_leads_len_admitdt ,hdfs_scratch + "/all_leads_len_admitdt",0,"overwrite")
    all_leads_len_admitdt_tmp = readparquet(spark, hdfs_scratch + "/all_leads_len_admitdt/", "0","na")

## STEP-2:
    all_leads_hpn = filter_ifhpn_notenabled(spark, all_leads_len_admitdt_tmp, hdfs_input,hdfs_scratch)
    writeparquet(spark, all_leads_hpn ,hdfs_scratch + "/all_leads_hpn",0,"overwrite")
    all_leads_hpn_tmp = readparquet(spark, hdfs_scratch + "/all_leads_hpn/", "0","na")

## STEP-3:
    all_leads_passmincharges = filter_mincharges_by_partner(spark, all_leads_hpn_tmp, hdfs_input,hdfs_scratch)
    writeparquet(spark, all_leads_passmincharges ,hdfs_scratch + "/all_leads_passmincharges",0,"overwrite")
    all_leads_passmincharges_tmp = readparquet(spark, hdfs_scratch + "/all_leads_passmincharges/", "0","na")

## STEP-4:
    all_leads_fc = filter_ifexistsinfc(spark, all_leads_passmincharges_tmp, hdfs_input,hdfs_scratch)
    writeparquet(spark, all_leads_fc ,hdfs_scratch + "/all_leads_fc",0,"overwrite")
    all_leads_fc_tmp = readparquet(spark, hdfs_scratch + "/all_leads_fc/", "0","na")

## STEP-5:
    all_leads_wallingoff = applywallingoff(spark, all_leads_fc_tmp, hdfs_input,hdfs_scratch)
    writeparquet(spark, all_leads_wallingoff ,hdfs_scratch + "/all_leads_wallingoff",0,"overwrite")
    all_leads_wallingoff_tmp = readparquet(spark, hdfs_scratch + "/all_leads_wallingoff/", "0","na")

## STEP-6:
    all_leads_edidatasourcefk = add_edidatasourcefk(all_leads_wallingoff_tmp)
    writeparquet(spark, all_leads_edidatasourcefk ,hdfs_scratch + "/all_leads_edidatasourcefk",0,"overwrite")
    all_leads_edidatasourcefk_tmp = readparquet(spark, hdfs_scratch + "/all_leads_edidatasourcefk/", "0","na")

## STEP-7: Fetch npi and hospitalname 
    all_leads_ohi_tmp = ohibatchprocess(spark, all_leads_edidatasourcefk_tmp, hdfs_input,hdfs_scratch)

## STEP-8: Bestleadselection
    final_leads = bestleadselection(spark,all_leads_ohi_tmp, bc,hdfs_scratch)
    writeparquet(spark, final_leads, hdfs_output, 10, "overwrite")
    final_leads.unpersist()
    final_leads=spark.read.parquet(hdfs_output)
    if (final_leads.isEmpty()):
        ret_val = 0
    else:
        ret_val = 1

#spark.stop()
#return None

# COMMAND ----------

dbutils.notebook.exit(ret_val)
