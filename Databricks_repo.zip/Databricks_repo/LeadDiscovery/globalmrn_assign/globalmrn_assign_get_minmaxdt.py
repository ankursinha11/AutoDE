# Databricks notebook source
# MAGIC %run /Insleads-code/LeadDiscovery/common/createlookup_maxminadmitdays

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
import datetime
from functools import reduce
from pyspark.sql import DataFrame

# COMMAND ----------

dbutils.widgets.text("cdd_publish_path","")
dbutils.widgets.getArgument("cdd_publish_path")
cdd_publish_path= getArgument("cdd_publish_path")

dbutils.widgets.text("dataingestion_publish_path","")
dbutils.widgets.getArgument("dataingestion_publish_path")
dataingestion_publish_path= getArgument("dataingestion_publish_path")

dbutils.widgets.text("gmrn_publish_path","")
dbutils.widgets.getArgument("gmrn_publish_path")
gmrn_publish_path= getArgument("gmrn_publish_path")

dbutils.widgets.text("leaddiscovery_transform_path","")
dbutils.widgets.getArgument("leaddiscovery_transform_path")
leaddiscovery_transform_path= getArgument("leaddiscovery_transform_path")

dbutils.widgets.text("notificationtype","")
dbutils.widgets.getArgument("notificationtype")
notificationtype= getArgument("notificationtype")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("module","")
dbutils.widgets.getArgument("module")
module= getArgument("module")

# COMMAND ----------

# bc="20240618T16"
# cdd_publish_path="/data/cdd/publish/"
# container="prod-icd-stg-adls"
# dataingestion_publish_path="/data/dataingestion/publish/"
# gmrn_publish_path="/data/gmrn/publish/"
# leaddiscovery_transform_path="/data/leaddiscovery/transform/scratch/"
# notificationtype="globalmrn_assign"
# storageaccount="prodicdstgdls"
# user="geetha"
# module="aid"

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

print(baseurl)

# COMMAND ----------

print("bc=" + str(bc))
print("cdd_publish_path=" + str(cdd_publish_path))
print("dataingestion_publish_path=" + str(dataingestion_publish_path))
print("gmrn_publish_path=" + str(gmrn_publish_path))
print("container=" + str(container))
print("storageaccount=" + str(storageaccount))
print("user=" + str(user))
print("notificationtype=" + str(notificationtype))
print("module=" + str(module))

# COMMAND ----------

cdd_publish_path = baseurl + cdd_publish_path
dataingestion_publish_path = baseurl + dataingestion_publish_path
gmrn_publish_path = baseurl + gmrn_publish_path
leaddiscovery_transform_path = baseurl + leaddiscovery_transform_path
hdfs_input = dataingestion_publish_path

# COMMAND ----------

if module=='':
    module='regular'

module=module.lower()
module=str(module)

# COMMAND ----------

if module =='regular':
    hdfs_output_edipartnerfk=leaddiscovery_transform_path+notificationtype+'/minmaxbyedipartnerfk/'+bc+'/'
    hdfs_output=leaddiscovery_transform_path+notificationtype+'/minmaxbyhospital/'+bc+'/'
else :
    hdfs_output_edipartnerfk=leaddiscovery_transform_path+notificationtype+'/minmaxbyedipartnerfk/'+ module+'/'+bc+'/'
    hdfs_output=leaddiscovery_transform_path+notificationtype+'/minmaxbyhospital/'+ module+'/'+bc+'/'

print("leaddiscovery_transform_path="+str(leaddiscovery_transform_path))


print("bc="+str(bc))
print("cdd_publish_path="+str(cdd_publish_path))
print("dataingestion_publish_path="+str(dataingestion_publish_path))
print("gmrn_publish_path="+str(gmrn_publish_path))
print("leaddiscovery_transform_path="+str(leaddiscovery_transform_path))
print("container="+str(container))
print("storageaccount="+str(storageaccount))
print("user="+str(user))
print("notificationtype="+str(notificationtype))
print("--------------------------------------------------------------------------------")
print("hdfs_output_edipartnerfk="+str(hdfs_output_edipartnerfk))
print("hdfs_input="+str(hdfs_input))
print("hdfs_output="+str(hdfs_output))

# COMMAND ----------

# MAGIC %md
# MAGIC ##Leaddiscovery: create admit date lookup

# COMMAND ----------

# using python util to read the arquet
hp = readparquet(spark, hdfs_input + "/hospitals/current/*/", '0', 'na')
hp = hp.filter(col("active") == '1')
hpn = readparquet(spark, hdfs_input + "/hospitalprovidernums/current/*/", '0', 'na')
hpn = hpn.filter(col("enabled") == '1')
edis = readparquet(spark, hdfs_input + "/edisubmitters/current/*/", '0', 'na')
ep = readparquet(spark, hdfs_input + "/edipartners/current/*/", '0', 'na')
epp = readparquet(spark, hdfs_input + "/edipartnertype/current/*/", '0', 'na')
epp = epp.filter((col("iscommercial") == '1') | (col("istricare") == '1'))
edienv = readparquet(spark, hdfs_input + "/edipartner270settings/current/*/", '0', 'na')
epso = readparquet(spark, hdfs_input + "/edipartnersubmittersoverrides/current/*/", '0', 'na')
ephsso = readparquet(spark, hdfs_input + "/edipartnerhospital270settingsoverrides/current/*/", '0', 'na')

b = createlookup(spark, hp, hpn, edis, ep, edienv, epso, ephsso,epp)
a = createlookupbypartnerfk(spark, hp, hpn, edis, ep, edienv, epso, ephsso,epp)
# using python util to write out
writeparquet(spark, b, hdfs_output,1, "overwrite")
writeparquet(spark, a, hdfs_output_edipartnerfk,1, "overwrite")
