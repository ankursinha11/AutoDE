# Databricks notebook source
# DBTITLE 1,SAMPLE INPUT
# bc="20240918T01"
# cdd_publish_path="/data/cdd/publish/"
# container="prod-icd-stg-adls"
# dataingestion_publish_path="/data/dataingestion/publish/"
# gmrn_publish_path="/data/gmrn/publish/"
# leaddiscovery_transform_path="/data/leaddiscovery/transform/scratch/"
# notificationtype="globalmrn_assign"
# storageaccount="prodicdstgdls"
# user="geetha"
# lead_mode_flag="1"
# mode="aid"

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/tu_data_quality

# COMMAND ----------

# MAGIC %run /Insleads-code/LeadDiscovery/common/get_candidate_patientaccts

# COMMAND ----------

dbutils.widgets.text("cdd_publish_path", "")
cdd_publish_path = dbutils.widgets.get("cdd_publish_path")

dbutils.widgets.text("dataingestion_publish_path", "")
dataingestion_publish_path = dbutils.widgets.get("dataingestion_publish_path")

dbutils.widgets.text("gmrn_publish_path", "")
gmrn_publish_path = dbutils.widgets.get("gmrn_publish_path")

dbutils.widgets.text("leaddiscovery_transform_path", "")
leaddiscovery_transform_path = dbutils.widgets.get("leaddiscovery_transform_path")

dbutils.widgets.text("notificationtype", "")
notificationtype = dbutils.widgets.get("notificationtype")

dbutils.widgets.text("lead_mode_flag", "")
lead_mode_flag = dbutils.widgets.get("lead_mode_flag")

dbutils.widgets.text("bc", "")
bc = dbutils.widgets.get("bc")

dbutils.widgets.text("user", "")
user = dbutils.widgets.get("user")

dbutils.widgets.text("container", "")
container = dbutils.widgets.get("container")

dbutils.widgets.text("storageaccount", "")
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text("mode", "")
mode = dbutils.widgets.get("mode")

# COMMAND ----------

print("bc="+str(bc))
print("cdd_publish_path="+str(cdd_publish_path))
print("container="+str(container))
print("dataingestion_publish_path="+str(dataingestion_publish_path))
print("gmrn_publish_path="+str(gmrn_publish_path))
print("lead_mode_flag="+str(lead_mode_flag))
print("leaddiscovery_transform_path="+str(leaddiscovery_transform_path))
print("notificationtype="+str(notificationtype))
print("storageaccount="+str(storageaccount))
print("user="+str(user))

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

cdd_publish_path = baseurl+cdd_publish_path
dataingestion_publish_path = baseurl+dataingestion_publish_path
gmrn_publish_path = baseurl+gmrn_publish_path
pa_path=dataingestion_publish_path+'/patientaccts/current/20991231/'

print("--------------------------------------------------------------------------------")
print("bc="+str(bc))
print("cdd_publish_path="+str(cdd_publish_path))
print("container="+str(container))
print("dataingestion_publish_path="+str(dataingestion_publish_path))
print("gmrn_publish_path="+str(gmrn_publish_path))
print("--------------------------------------------------------------------------------")

# COMMAND ----------

aid_bc=bc.split("-")[0]
print("aid_bc:",aid_bc)
aid_pa_path=baseurl+"/data/dataingestion/staging/input/patientaccts/"+aid_bc
aid_accounts=baseurl+"/data/dataingestion/publish/patientacctsaccesscoordinator/current/20991231/"
print("aid_pa_path:",aid_pa_path)
print("aid_accounts:",aid_accounts)
r_mode=mode

if r_mode=='':
    r_mode='regular'

r_mode=r_mode.lower()
r_mode=str(r_mode)
print("r_mode:",r_mode)

# COMMAND ----------

if r_mode=='regular':
    leaddiscovery_transform_path = baseurl+leaddiscovery_transform_path
    candidatepa_path = leaddiscovery_transform_path + notificationtype + '/candidatepa/'+bc+'/'
    hdfs_admitdatelookup=leaddiscovery_transform_path+notificationtype+'/minmaxbyhospital/'+bc+'/*'
    hdfs_scratch=leaddiscovery_transform_path+notificationtype+'/leadstatus/'+bc+'/'
else :
    leaddiscovery_transform_path = baseurl+leaddiscovery_transform_path
    candidatepa_path = leaddiscovery_transform_path + notificationtype + '/candidatepa/'+r_mode+'/'+bc+'/'
    hdfs_admitdatelookup=leaddiscovery_transform_path+notificationtype+'/minmaxbyhospital/'+r_mode+'/'+bc+'/*'
    hdfs_scratch=leaddiscovery_transform_path+notificationtype+'/leadstatus/'+r_mode+'/'+bc+'/'

# COMMAND ----------

print("lead_mode_flag="+str(lead_mode_flag))
print("leaddiscovery_transform_path="+str(leaddiscovery_transform_path))
print("notificationtype="+str(notificationtype))
print("storageaccount="+str(storageaccount))
print("user="+str(user))
print("--------------------------------------------------------------------------------")
print("candidatepa_path="+str(candidatepa_path))
print("hdfs_admitdatelookup="+str(hdfs_admitdatelookup))
print("hdfs_scratch="+str(hdfs_scratch))
print("pa_path="+str(pa_path))

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
import datetime
import getpass
import os
import sys
import subprocess

# COMMAND ----------

# DBTITLE 1,spark.conf.set("spark.sql.shuffle.partitions","auto")
spark.conf.set("spark.sql.shuffle.partitions","auto")

# COMMAND ----------

admitdate = readparquet(spark, hdfs_admitdatelookup, '0', 'na')
enddt = date_sub(current_date(), 90)



# get hospital attributevalues
ha = readparquet(spark, dataingestion_publish_path + "/hospitalattributes/current/*", '0', 'na')
hav = readparquet(spark, dataingestion_publish_path + "/hospitalattributevalues/current/*", '0', 'na')
havalues = hospattributes(spark, ha, hav)

hiccolumns = ["hospinsurancecodepk", "hospitalfk", "code", "codedesc", "hospcodestatusfk" ,"mcare", "secondarytomcaid", "edipayerfk" ]
hic = extract_deltalake_data(spark, dataingestion_publish_path + "hospinsurancecodes/current/20991231/", hiccolumns)

patientacctcodescolumns = [ "patientacctifk", "hospitalfk", "insurancecode1", "insurancecode2", "insurancecode3"  ]
patientacctcodes =  extract_deltalake_data(spark, dataingestion_publish_path + "/patientacctscodes/current/20991231/", patientacctcodescolumns )

edipayers = readparquet(spark, dataingestion_publish_path + "/edipayers/current/20991231", "0", 'na')

vsnapcols = ["patientacctifk", "hospitalfk", "knownmcaidflag", "primarymcaidflag", "hasmedicareflag", "knowntricareflag", "secondarymcaid_afterinsuranceflag","createdate"]
vsnapflags = extract_deltalake_data(spark, dataingestion_publish_path + "/vsnappatientacctsflags/current/20991231/", vsnapcols)
vsnapflags = vsnapflags.join(admitdate, admitdate.hospitalfk == vsnapflags.hospitalfk).select(vsnapflags['*'])
vsnapflags = vsnapflags.withColumn('patientacctifk', vsnapflags.patientacctifk.cast("long"))
vsnapflags = vsnapflags.withColumnRenamed('createdate', 'vsnapflags_createdate')
vsnapflags = vsnapflags.withColumnRenamed('hospitalfk', 'vsnapflags_hospitalfk')


print("r_mode:",r_mode)
if r_mode == 'aid':
    print("AID PATACCTS")
    #patientaccts = get_patientacct_aid(spark,aid_pa_path,aid_accounts, lead_mode_flag,enddt, bc, admitdate,vsnapflags)
    # NEW AID PATACCTS COMBINED START
    path_aidpatientaccts = baseurl + "/data/dataingestion/publish/aidpatientaccts/current/20991231/"
    path_patientacctsaccesscoordinator = baseurl + "/data/dataingestion/publish/patientacctsaccesscoordinator/current/20991231/"
    filterBc="bcupdated=='"+aid_bc+"'"
    aidpatientaccts = spark.read.format("delta").load(path_aidpatientaccts).filter(filterBc).selectExpr("patientacctifk as patientacctipk","hospitalfk").dropDuplicates()
    patientacctsaccesscoordinator = spark.read.format("parquet").load(path_patientacctsaccesscoordinator).selectExpr("patientacctifk as patientacctipk","hospitalfk").dropDuplicates()
    aidpatientaccts = aidpatientaccts.union(patientacctsaccesscoordinator)
    pacctscols = ["patientacctipk", "hospitalfk", "firstname", "middlename", "lastname", "ssn", "dob", "gender", "state", "admitdate", "referraldate", "dischargedate", "medicalrecnum", "clusteredacctfk", "totalcharges", "createdate", "updatedate", "demographicsupdatedate", "medicarehic", "medicaidnum", "trgupdatedate", "currentbalance"]
    patientaccts = get_patientacct_aid_combined(spark,aid_pa_path,pacctscols,aidpatientaccts, lead_mode_flag,enddt, bc, admitdate,vsnapflags)
    # NEW AID PATACCTS COMBINED END
    # print("patientaccts : "+str(patientaccts.count()))
else :
    print("NON AID PATACCTS")
    patientaccts = get_patientacct(spark, pa_path, lead_mode_flag, enddt, bc, admitdate,vsnapflags)
    # print("patientaccts : "+str(patientaccts.count()))


#display(patientaccts.filter(patientaccts.patientacctipk == 3611312569))
    # apply all filters together to get final candidate acct list
if( lead_mode_flag == '1'):
    candidates = getcandidateacctsfilter_ll(spark, patientaccts, patientacctcodes, havalues, hic, edipayers )
else:
    candidates = getcandidateacctsfilter_coc(spark, patientaccts, vsnapflags)

writeparquet(spark, candidates, hdfs_scratch + "/tmpdata/pa_vsnapflags", 0, "overwrite")
candidates = readparquet(spark, hdfs_scratch + "/tmpdata/pa_vsnapflags", '0', 'na')
#ca = get_globalmrn(spark, gmrn_publish_path, candidates, bc)
if r_mode=="aid":
    ca = get_globalmrn_aid(spark, gmrn_publish_path, candidates, aid_bc)
    # print("ca : "+str(ca.count()))
else :
    ca = get_globalmrn(spark, gmrn_publish_path, candidates, bc)
    # print("ca : "+str(ca.count()))

ca = get_permid(spark, cdd_publish_path, ca)
ca = check_valid_identities(spark, ca)
writeparquet(spark, ca, candidatepa_path, 0, "overwrite")
