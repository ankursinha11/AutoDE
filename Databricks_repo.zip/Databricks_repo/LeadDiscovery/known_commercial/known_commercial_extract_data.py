# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("cloudmigration_tables","")
dbutils.widgets.getArgument("cloudmigration_tables")
cloudmigration_tables = getArgument("cloudmigration_tables")


dbutils.widgets.text("path_kc_process_temp_config_values","")
dbutils.widgets.getArgument("path_kc_process_temp_config_values")
path_kc_process_temp_config_values = getArgument("path_kc_process_temp_config_values")

dbutils.widgets.text("path_kc_process_temp_fnf","")
dbutils.widgets.getArgument("path_kc_process_temp_fnf")
path_kc_process_temp_fnf = getArgument("path_kc_process_temp_fnf")

dbutils.widgets.text("path_kc_sqoop_config","")
dbutils.widgets.getArgument("path_kc_sqoop_config")
path_kc_sqoop_config = getArgument("path_kc_sqoop_config")




# COMMAND ----------


if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

path_kc_process_temp_config_values = baseurl + path_kc_process_temp_config_values + bc
path_kc_process_temp_fnf = baseurl + path_kc_process_temp_fnf
path_kc_sqoop_config = baseurl + path_kc_sqoop_config + bc
# path_kc_sqoop_conn_file = baseurl + path_kc_sqoop_conn_file
print("path_kc_process_temp_config_values", path_kc_process_temp_config_values)
print("path_kc_process_temp_fnf", path_kc_process_temp_fnf)
print("path_kc_sqoop_config", path_kc_sqoop_config)
# print("path_kc_sqoop_conn_file", path_kc_sqoop_conn_file)

# COMMAND ----------


path_patientacctscodes = baseurl + cloudmigration_tables + 'patientacctscodes/current/20991231/'
path_patientaccts = baseurl + cloudmigration_tables  + 'patientaccts/current/20991231/'
path_vsnappatientacctsflags = baseurl + cloudmigration_tables + 'vsnappatientacctsflags/current/20991231/'
path_hospfinclasscodes = baseurl + cloudmigration_tables + 'hospfinclasscodes/current/20991231/'
path_hospinsurancecodes = baseurl + cloudmigration_tables + 'hospinsurancecodes/current/20991231/'
path_edipayers = baseurl + cloudmigration_tables  + 'edipayers/current/20991231/'
path_hospitals = baseurl + cloudmigration_tables + 'hospitals/current/20991231'
path_hcsystems = baseurl + cloudmigration_tables + 'hcsystems/current/20991231/'
path_hospitalimportpayment = baseurl + cloudmigration_tables + 'hospitalimportpayment/current/20991231/'
path_hosppaymentcodes = baseurl + cloudmigration_tables + 'hosppaymentcodes/current/20991231/'
path_hospitalattributes = baseurl + cloudmigration_tables + 'hospitalattributes/current/20991231/'
path_hospitalattributevalues = baseurl + cloudmigration_tables + 'hospitalattributevalues/current/20991231/'
print(path_patientacctscodes)

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------


import sys
import os
import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
from pyspark import SparkContext
from pyspark.conf import SparkConf
import subprocess
from delta.tables import *
spark.sql("SET spark.databricks.delta.formatCheck.enabled=false")



def get_kcenabled_list(spark, path_kc_sqoop_config):
    df_data = spark.read.format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", mode="FAILFAST", quote="", delimiter='\x01').load(path_kc_sqoop_config).selectExpr("_c0 as hospitalpk", "_c1 as hcsystemfk", "_c2 as kcenabled")
    for column in df_data.columns:
        df_data = df_data.withColumn(column, trim(col(column)))
        df_data = df_data.withColumn(column, when(col(column).isNull(), None).otherwise(col(column)))
        df_data = df_data.withColumn(column, when(col(column) == '', None).otherwise(col(column)))
        df_data = df_data.withColumn(column, when(col(column) == 'null', None).otherwise(col(column)))
    df_data = df_data.dropDuplicates()
    return df_data


def get_hospitals(spark, path_hospitals):
    pColumnList = ["hospitalpk", "hospitalname", "hcsystemfk"]
    df_hospitals = readparquet(spark, path_hospitals, "1", pColumnList)
    # df_hospitals = spark.read.parquet(path_hospitals).selectExpr("hospitalpk", "hospitalname", "hcsystemfk").dropDuplicates()
    return df_hospitals


def get_hcsystems(spark, path_hcsystems):
    pColumnList = ["hcsystempk", "hcsname"]
    df_hcsystems = readparquet(spark, path_hcsystems, "1", pColumnList).dropDuplicates()
    # kc_hcsystems_codes = ["570", "283"]
    # df_hcsystems = df_hcsystems.where(col("hcsystempk").isin(kc_hcsystems_codes)).dropDuplicates()
    return df_hcsystems


def  get_hospitalattributes(spark, path_hospitalattributes):
    pColumnList = ["hospitalattributepk", "attributename", "attributedescription", "attributetype", "attributedefaultvalue"]
    kc_codes = ["95", "96", "97", "98", "99"]
    df_hospitalattributes = readparquet(spark, path_hospitalattributes, "1", pColumnList).where(col("hospitalattributepk").isin(kc_codes)).dropDuplicates()
    for column in df_hospitalattributes.columns:
        df_hospitalattributes = df_hospitalattributes.withColumn(column, trim(col(column)))
        df_hospitalattributes = df_hospitalattributes.withColumn(column, when(col(column).isNull(), None).otherwise(col(column)))
        df_hospitalattributes = df_hospitalattributes.withColumn(column, when(col(column) == '', None).otherwise(col(column)))
        df_hospitalattributes = df_hospitalattributes.withColumn(column, when(col(column) == 'null', None).otherwise(col(column)))
    return df_hospitalattributes


def get_hospitalattributevalues(spark, path_hospitalattributevalues):
    pColumnList = ["hospitalattributefk", "hospitalfk", "hospitalattributevalue"]
    kc_codes = ["95", "96", "97", "98", "99"]
    df_hospitalattributevalues = readparquet(spark, path_hospitalattributevalues, "1", pColumnList).where(col("hospitalattributefk").isin(kc_codes)).dropDuplicates()
    for column in df_hospitalattributevalues.columns:
        df_hospitalattributevalues = df_hospitalattributevalues.withColumn(column, trim(col(column)))
        df_hospitalattributevalues = df_hospitalattributevalues.withColumn(column, when(col(column).isNull(), None).otherwise(col(column)))
        df_hospitalattributevalues = df_hospitalattributevalues.withColumn(column, when(col(column) == '', None).otherwise(col(column)))
        df_hospitalattributevalues = df_hospitalattributevalues.withColumn(column, when(col(column) == 'null', None).otherwise(col(column)))
    return df_hospitalattributevalues


def get_configattributes(spark, df_hospitalattributes, df_hospitalattributevalues, df_hospitals, path_kc_process_temp_fnf):
    df_hospitalattributes_ljoin_hospitalattributevalues = df_hospitalattributes.join(df_hospitalattributevalues, df_hospitalattributes.hospitalattributepk == df_hospitalattributevalues.hospitalattributefk, 'left') \
        .select(df_hospitalattributes['*'],
                df_hospitalattributevalues.hospitalfk,
                df_hospitalattributevalues.hospitalattributevalue).dropDuplicates()
    df_hospital_attributes = df_hospitalattributes_ljoin_hospitalattributevalues \
        .withColumn("attributevalue", when(df_hospitalattributes_ljoin_hospitalattributevalues \
                                           .hospitalattributevalue.isNull(),
                                           df_hospitalattributes_ljoin_hospitalattributevalues.attributedefaultvalue) \
                    .otherwise(df_hospitalattributes_ljoin_hospitalattributevalues.hospitalattributevalue)).drop("attributedefaultvalue").drop("hospitalattributevalue").dropDuplicates()
    writeparquet(spark, df_hospital_attributes, path_kc_process_temp_fnf + "/hxh/", 10, "overwrite")
    df_hospital_attributes.unpersist()
    df_hospital_attributes = spark.read.parquet(path_kc_process_temp_fnf + "/hxh/")
    df_hospital_attributes.createOrReplaceTempView("hospital_attributes")
    df_hospital_list = df_hospitals.selectExpr("hospitalpk as hospitalfk").dropDuplicates()
    writeparquet(spark, df_hospital_list, path_kc_process_temp_fnf + "/hosp/", 10, "overwrite")
    df_hospital_list.unpersist()
    df_hospital_list = spark.read.parquet(path_kc_process_temp_fnf + "/hosp/")
    df_hospital_list.createOrReplaceTempView("hospital_list")
    spark.conf.set("spark.sql.crossJoin.enabled", "true")
    sql_hosp_x_attributes_XJ = """
    SELECT  
           hospital_list.hospitalfk,
           hospital_attributes.hospitalattributepk,
           hospital_attributes.attributename,
           hospital_attributes.attributedescription,
           hospital_attributes.attributevalue,
           hospital_attributes.attributetype,
           '0' as attributeflag
    FROM hospital_list
      CROSS JOIN (SELECT * FROM hospital_attributes WHERE hospitalfk IS NULL) hospital_attributes
    """
    sql_hosp_x_attributes_IJ = """
    SELECT hospital_list.hospitalfk,
           hospital_attributes.hospitalattributepk,
           hospital_attributes.attributename,
           hospital_attributes.attributedescription,
           hospital_attributes.attributevalue,
           hospital_attributes.attributetype,
           '1' as attributeflag
    FROM hospital_list
      INNER JOIN (SELECT * FROM hospital_attributes WHERE hospitalfk IS NOT NULL) hospital_attributes
      ON hospital_list.hospitalfk = hospital_attributes.hospitalfk
    """
    df_config_table_1 = spark.sql(sql_hosp_x_attributes_XJ)
    df_config_table_2 = spark.sql(sql_hosp_x_attributes_IJ)
    df_config_table = df_config_table_1.unionAll(df_config_table_2).dropDuplicates()
    df_config_table.createOrReplaceTempView("hosp_x_attributes")
    sql_hosp_x_attributes_RNK = """
    SELECT hospitalfk,
           hospitalattributepk,
           attributename,
           attributedescription,
           attributetype,
           attributevalue,
           attributeflag,
           RANK() OVER (PARTITION BY hospitalfk,hospitalattributepk,attributename,attributedescription,attributetype,attributevalue ORDER BY attributeflag DESC) AS rnk
    FROM hosp_x_attributes
    """
    df_config_table = spark.sql(sql_hosp_x_attributes_RNK).filter("rnk =='1'").dropDuplicates()
    return df_config_table



# COMMAND ----------



from delta.tables import *


df_hospitalattributes = spark.read.parquet(path_hospitalattributes).select("hospitalattributepk","attributename","attributedescription","attributetype","attributedefaultvalue").dropDuplicates()
for column in df_hospitalattributes.columns:
    df_hospitalattributes = df_hospitalattributes.withColumn(column, trim(col(column)))
    df_hospitalattributes = df_hospitalattributes.withColumn(column, when(col(column).isNull(), None).otherwise(col(column)))
    df_hospitalattributes = df_hospitalattributes.withColumn(column, when(col(column) == '', None).otherwise(col(column)))
    df_hospitalattributes = df_hospitalattributes.withColumn(column, when(col(column) == 'null', None).otherwise(col(column)))
writeparquet(spark, df_hospitalattributes, path_kc_process_temp_fnf + "/hospitalattributes/", 10, "overwrite")


df_hospitalattributevalues = spark.read.parquet(path_hospitalattributevalues).dropDuplicates()
for column in df_hospitalattributevalues.columns:
    df_hospitalattributevalues = df_hospitalattributevalues.withColumn(column, trim(col(column)))
    df_hospitalattributevalues = df_hospitalattributevalues.withColumn(column, when(col(column).isNull(), None).otherwise(col(column)))
    df_hospitalattributevalues = df_hospitalattributevalues.withColumn(column, when(col(column) == '', None).otherwise(col(column)))
    df_hospitalattributevalues = df_hospitalattributevalues.withColumn(column, when(col(column) == 'null', None).otherwise(col(column)))
writeparquet(spark, df_hospitalattributevalues, path_kc_process_temp_fnf + "/hospitalattributevalues/", 10, "overwrite")

df_kc_enabled_config_values = get_kcenabled_list(spark, path_kc_sqoop_config).selectExpr("hospitalpk", "hcsystemfk").dropDuplicates()
df_hospitals = get_hospitals(spark, path_hospitals)
df_hospitals = df_hospitals.join(df_kc_enabled_config_values, df_hospitals.hospitalpk == df_kc_enabled_config_values.hospitalpk).select(df_hospitals['*']).dropDuplicates()
writeparquet(spark, df_hospitals, path_kc_process_temp_fnf + "/hospitals/", 1000, "overwrite")
df_hospitals.unpersist()
df_hospitals = spark.read.parquet(path_kc_process_temp_fnf + "/hospitals/")

df_hcsystems = get_hcsystems(spark, path_hcsystems)
df_hospitals_x_hcsystems = df_hospitals.join(df_hcsystems, df_hospitals.hcsystemfk == df_hcsystems.hcsystempk, 'inner')
df_hospitals_x_hcsystems = df_hospitals_x_hcsystems.selectExpr("hospitalpk", "hospitalpk as hospitalfk", "hcsystempk", "hcsystemfk", "hcsname", "hospitalname").dropDuplicates()
df_hcsystems = df_hospitals_x_hcsystems.selectExpr("hcsystempk", "hcsname").dropDuplicates()
writeparquet(spark, df_hcsystems, path_kc_process_temp_fnf + "/hcsystems/", 1000, "overwrite")

df_hospitals_in_play = df_hospitals_x_hcsystems.selectExpr("hospitalpk", "hospitalfk").dropDuplicates()
writeparquet(spark, df_hospitals_in_play, path_kc_process_temp_fnf + "/hospitals_in_play/", 1000, "overwrite")
df_hospitals_in_play.unpersist()
df_hospitals_in_play = spark.read.parquet(path_kc_process_temp_fnf + "/hospitals_in_play/")

df_hospitalattributes = get_hospitalattributes(spark, path_kc_process_temp_fnf + "/hospitalattributes/")
df_hospitalattributevalues = get_hospitalattributevalues(spark, path_kc_process_temp_fnf + "/hospitalattributevalues/")
df_config_values = get_configattributes(spark, df_hospitalattributes, df_hospitalattributevalues, df_hospitals, path_kc_process_temp_fnf)
writeparquet(spark, df_config_values, path_kc_process_temp_config_values, 10, "overwrite")
df_config_values.unpersist()
df_hospitalattributes.unpersist()
df_hospitalattributevalues.unpersist()
print("KC-PROC-01 : CONFIG TABLE EXTRACTION : COMPLETE")

pColumnList = ['patientacctipk', 'hospitalfk', 'admitdate', 'dischargedate', 'acctnum', 'totalcharges', 'currentbalance', 'demographicsupdatedate', 'firstname', 'middlename', 'lastname', 'dob', 'ssn', 'gender', 'state', 'medicalrecnum', 'clusteredacctfk', 'createdate', 'updatedate', 'referraldate', 'medicarehic', 'medicaidnum','trgupdatedate']
df_patientaccts = DeltaTable.forPath(spark, path_patientaccts).toDF().selectExpr(pColumnList).dropDuplicates()
df_patientaccts = df_patientaccts.join(df_hospitals_in_play, df_patientaccts.hospitalfk == df_hospitals_in_play.hospitalfk).select(df_patientaccts['*']).dropDuplicates()
df_patientaccts.createOrReplaceTempView("df_patientaccts")
df_patientaccts=spark.sql("""SELECT patientacctipk,
                                    hospitalfk,
                                    admitdate,
                                    dischargedate,
                                    acctnum,
                                    totalcharges,
                                    currentbalance,
                                    CASE WHEN trgupdatedate > demographicsupdatedate THEN trgupdatedate ELSE demographicsupdatedate END AS demographicsupdatedate,
                                    firstname,
                                    middlename,
                                    lastname,
                                    dob,
                                    ssn,
                                    gender,
                                    state,
                                    medicalrecnum,
                                    clusteredacctfk,
                                    createdate,
                                    updatedate,
                                    referraldate,
                                    medicarehic,
                                    medicaidnum
                            FROM df_patientaccts""").dropDuplicates()
writeparquet(spark, df_patientaccts, path_kc_process_temp_fnf + "/patientaccts/", 1000, "overwrite")
df_patientaccts.unpersist()

pColumnList = ['patientacctifk', 'hospitalfk', 'finclasscurrent', 'insurancecode1', 'insurancecode2', 'insurancecode3', 'insurancecode4']
df_patientacctscodes = DeltaTable.forPath(spark, path_patientacctscodes).toDF().selectExpr(pColumnList).dropDuplicates()
df_patientacctscodes = df_patientacctscodes.join(df_hospitals_in_play, df_patientacctscodes.hospitalfk == df_hospitals_in_play.hospitalfk).select(df_patientacctscodes['*']).dropDuplicates()
writeparquet(spark, df_patientacctscodes, path_kc_process_temp_fnf + "/patientacctscodes/", 1000, "overwrite")
df_patientacctscodes.unpersist()

pColumnList = ['patientacctifk', 'hospitalfk', 'secondarymcaidflag', 'secondarymcaid_afterinsuranceflag']
df_vsnappatientacctsflags = DeltaTable.forPath(spark, path_vsnappatientacctsflags).toDF().selectExpr(pColumnList).dropDuplicates()
df_vsnappatientacctsflags = df_vsnappatientacctsflags.join(df_hospitals_in_play, df_vsnappatientacctsflags.hospitalfk == df_hospitals_in_play.hospitalfk).select(df_vsnappatientacctsflags['*']).dropDuplicates()
writeparquet(spark, df_vsnappatientacctsflags, path_kc_process_temp_fnf + "/vsnappatientacctsflags/", 1000, "overwrite")
df_vsnappatientacctsflags.unpersist()

pColumnList = ['payer', 'hospitalfk', 'transcategorycode', 'paymenttype', 'acctnum', 'transamount', 'createdate']
df_hospitalimportpayment = DeltaTable.forPath(spark, path_hospitalimportpayment).toDF().selectExpr(pColumnList).dropDuplicates()
df_hospitalimportpayment = df_hospitalimportpayment.join(df_hospitals_in_play, df_hospitalimportpayment.hospitalfk == df_hospitals_in_play.hospitalfk).select(df_hospitalimportpayment['*']).dropDuplicates()
writeparquet(spark, df_hospitalimportpayment, path_kc_process_temp_fnf + "/hospitalimportpayment/", 1000, "overwrite")
df_hospitalimportpayment.unpersist()

pColumnList = ['patientpayment', 'hospitalfk', 'edipayerfk', 'paymenttype', 'code']
'''
TODO: Uncomment the delta table read and comment the parquet read
'''

# df_hosppaymentcodes = spark.read.parquet('abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/karthik/data/leadpropagation/hosppaymentcodes/').selectExpr(pColumnList).dropDuplicates()
# df_hosppaymentcodes = spark.read.format('delta').load(path_hosppaymentcodes).selectExpr(pColumnList).dropDuplicates()
df_hosppaymentcodes = DeltaTable.forPath(spark, path_hosppaymentcodes).toDF().selectExpr(pColumnList).dropDuplicates()
df_hosppaymentcodes = df_hosppaymentcodes.join(df_hospitals_in_play, df_hosppaymentcodes.hospitalfk == df_hospitals_in_play.hospitalfk).select(df_hosppaymentcodes['*']).dropDuplicates()
writeparquet(spark, df_hosppaymentcodes, path_kc_process_temp_fnf + "/hosppaymentcodes/", 1000, "overwrite")
df_hosppaymentcodes.unpersist()

pColumnList = ['hospitalfk', 'code', 'codedesc']
df_hospfinclasscodes = DeltaTable.forPath(spark, path_hospfinclasscodes).toDF().selectExpr(pColumnList).dropDuplicates()
df_hospfinclasscodes = df_hospfinclasscodes.join(df_hospitals_in_play, df_hospfinclasscodes.hospitalfk == df_hospitals_in_play.hospitalfk).select(df_hospfinclasscodes['*']).dropDuplicates()
writeparquet(spark, df_hospfinclasscodes, path_kc_process_temp_fnf + "/hospfinclasscodes/", 1000, "overwrite")
df_hospfinclasscodes.unpersist()

pColumnList = ["hospitalfk", "code", "codedesc", "tricare", "thirdpartyliabflag", "edipayerfk", "secondarytomcaid"]
df_hospinsurancecodes = DeltaTable.forPath(spark, path_hospinsurancecodes).toDF().selectExpr(pColumnList).dropDuplicates()
df_hospinsurancecodes = df_hospinsurancecodes.join(df_hospitals_in_play, df_hospinsurancecodes.hospitalfk == df_hospitals_in_play.hospitalfk).select(df_hospinsurancecodes['*']).dropDuplicates()
writeparquet(spark, df_hospinsurancecodes, path_kc_process_temp_fnf + "/hospinsurancecodes/", 1000, "overwrite")
df_hospinsurancecodes.unpersist()

pColumnList = ["edipayergroupfk", "edipayerpk"]
df_edipayers = readparquet(spark, path_edipayers, "1", pColumnList).dropDuplicates()
writeparquet(spark, df_edipayers, path_kc_process_temp_fnf + "/edipayers/", 1000, "overwrite")
df_edipayers.unpersist()
