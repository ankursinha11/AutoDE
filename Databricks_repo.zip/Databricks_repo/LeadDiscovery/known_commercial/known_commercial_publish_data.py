# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("path_kc_process_temp_kc_filtered","")
dbutils.widgets.getArgument("path_kc_process_temp_kc_filtered")
path_kc_process_temp_kc_filtered = getArgument("path_kc_process_temp_kc_filtered")

dbutils.widgets.text("path_kc_process_delta_table","")
dbutils.widgets.getArgument("path_kc_process_delta_table")
path_kc_process_delta_table = getArgument("path_kc_process_delta_table")

dbutils.widgets.text("path_kc_process_final_output","")
dbutils.widgets.getArgument("path_kc_process_final_output")
path_kc_process_final_output = getArgument("path_kc_process_final_output")

dbutils.widgets.text("path_kc_process_final_output_sqoop","")
dbutils.widgets.getArgument("path_kc_process_final_output_sqoop")
path_kc_process_final_output_sqoop = getArgument("path_kc_process_final_output_sqoop")

dbutils.widgets.text("path_kc_process_final_output_sqoop2","")
dbutils.widgets.getArgument("path_kc_process_final_output_sqoop2")
path_kc_process_final_output_sqoop2 = getArgument("path_kc_process_final_output_sqoop2")


# COMMAND ----------


if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

# path_kc_process_temp_kc_filtered = '/data/known_commercial/hceleads/phd9uat/leads/scratch/known_commercial/kc_filtered/'
# bc='20230905T06'

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql import Row
from  pyspark.sql.utils import *
from delta.tables import *

spark.sql("SET spark.databricks.delta.formatCheck.enabled=false")
spark.sql("SET spark.databricks.delta.retentionDurationCheck.enabled = false")
spark.sql("SET spark.databricks.optimizer.dynamicPartitionPruning = true")

# COMMAND ----------

path_kc_process_temp_kc_filtered = baseurl + path_kc_process_temp_kc_filtered + bc
path_kc_process_delta_table = baseurl + path_kc_process_delta_table
path_kc_process_final_output = baseurl + path_kc_process_final_output + bc
path_kc_process_final_output_sqoop = baseurl + path_kc_process_final_output_sqoop + bc
path_kc_process_final_output_sqoop2 = baseurl + path_kc_process_final_output_sqoop2 + bc
print("path_kc_process_temp_kc_filtered: ",path_kc_process_temp_kc_filtered)
print("path_kc_process_delta_table: ",path_kc_process_delta_table)
print("path_kc_process_final_output: ", path_kc_process_final_output)
print("path_kc_process_final_output_sqoop: ", path_kc_process_final_output_sqoop)
print("path_kc_process_final_output_sqoop2: ", path_kc_process_final_output_sqoop2)


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------



pJoinExpression = "raw.patientacctipk = delta.patientacctipk AND raw.hospitalfk = delta.hospitalfk"
df_delta = spark.read.parquet(path_kc_process_temp_kc_filtered).withColumn("bc", lit(bc))
# print ("df_delta COUNT : " + str(df_delta.count()))
# proc = subprocess.Popen(['hadoop', 'fs', '-test', '-e', path_kc_process_delta_table])
# proc.communicate()


try:
    df_tst = spark.read.format("delta").load(path_kc_process_delta_table)
    flag = 0
except AnalysisException:
    flag = 1
    print("Delta Table Not Found")

if flag != 0:
    print("PUBLISH PATH MISSING : LOADING BASE : " + path_kc_process_delta_table)
    df_delta.repartition(2567).write.format("delta").mode("overwrite").save(path_kc_process_delta_table)
    df_delta.unpersist()
    print("DELTA TABLE CREATED")
    df_delta = DeltaTable.forPath(spark, path_kc_process_delta_table).toDF()
    # df_delta.repartition(100).write.mode("overwrite").parquet(path_kc_process_final_output)
    df_delta.repartition(20).write.format("delta").mode("overwrite").save(path_kc_process_final_output)
    df_delta.unpersist()
    print("O/P  CREATED")
    df_delta = spark.read.parquet(path_kc_process_final_output).selectExpr("patientacctipk", "hospitalfk").withColumn("BreadCrumb", lit(bc)).dropDuplicates()
    df_delta.repartition(100).write.format("csv").mode("overwrite").options(timestampFormat="yyyy-MM-dd HH:mm:ss", delimiter="\x01", emptyValue='null').save(path_kc_process_final_output_sqoop)
    df_delta.drop("patientacctipk").drop("hospitalfk").dropDuplicates().repartition(1).write.format("csv").mode("overwrite").options(timestampFormat="yyyy-MM-dd HH:mm:ss", delimiter="\x01", emptyValue='null').save(path_kc_process_final_output_sqoop2)
    df_delta.unpersist()
    print("SQP o/P CREATED")
    if (df_delta.isEmpty()):
        ret_val = 0
    else:
        ret_val = 1
    # spark.stop()
    # exit(0)
else:
    print("PUBLISH PATH FOUND   : LOADING DELTA : " + path_kc_process_delta_table)
    df_raw = DeltaTable.forPath(spark, path_kc_process_delta_table)
    df_raw.alias("raw").merge(
        df_delta.alias("delta"),
        pJoinExpression) \
        .whenMatchedUpdate(
        condition="raw.demographicsupdatedate < delta.demographicsupdatedate",
        set={
            "firstname": "delta.firstname",
            "middlename": "delta.middlename",
            "lastname": "delta.lastname",
            "ssn": "delta.ssn",
            "dob": "delta.dob",
            "gender": "delta.gender",
            "state": "delta.state",
            "admitdate": "delta.admitdate",
            "referraldate": "delta.referraldate",
            "dischargedate": "delta.dischargedate",
            "medicalrecnum": "delta.medicalrecnum",
            "clusteredacctfk": "delta.clusteredacctfk",
            "totalcharges": "delta.totalcharges",
            "createdate": "delta.createdate",
            "updatedate": "delta.updatedate",
            "demographicsupdatedate": "delta.demographicsupdatedate",
            "medicarehic": "delta.medicarehic",
            "medicaidnum": "delta.medicaidnum",
            "bc": "delta.bc"
        }
    ).execute()
    df_raw.alias("raw").merge(df_delta.alias("delta"), pJoinExpression).whenNotMatchedInsertAll().execute()
    df_raw = DeltaTable.forPath(spark, path_kc_process_delta_table)
    df_raw.vacuum(0)
    print("DELTA TABLE VACCUM DONE")    
    df_output = DeltaTable.forPath(spark, path_kc_process_delta_table).toDF().dropDuplicates()
    df_output.repartition(20).write.option("dataChange", "true").format("delta").mode("overwrite").save(path_kc_process_final_output)
    df_output.unpersist()
    print("o/p DONE")
    filterExpr1 = "bc == '" + bc + "'"
    df_output = spark.read.format('delta').load(path_kc_process_delta_table).filter(filterExpr1).selectExpr("patientacctipk", "hospitalfk").withColumn("BreadCrumb", lit(bc)).dropDuplicates()
    # print ("df_output COUNT : " + str(df_output.count()))
    df_output.repartition(25).write.format("csv").mode("overwrite").options(timestampFormat="yyyy-MM-dd HH:mm:ss", delimiter="\x01", emptyValue='null').save(path_kc_process_final_output_sqoop)
    df_output.drop("patientacctipk").drop("hospitalfk").dropDuplicates().repartition(1).write.format("csv").mode("overwrite").options(timestampFormat="yyyy-MM-dd HH:mm:ss", delimiter="\x01", emptyValue='null').save(path_kc_process_final_output_sqoop2)
    print("sqp o/p DONE")
    #df_output.unpersist()
    if (df_output.isEmpty()):
        ret_val = 0
    else:
        ret_val = 1

# COMMAND ----------

dbutils.notebook.exit(ret_val)