# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("input_path","")
dbutils.widgets.getArgument("input_path")
input_path = getArgument("input_path")

dbutils.widgets.text("output_path","")
dbutils.widgets.getArgument("output_path")
output_path = getArgument("output_path")

dbutils.widgets.text("path_kc_process_temp_config_values","")
dbutils.widgets.getArgument("path_kc_process_temp_config_values")
path_kc_process_temp_config_values = getArgument("path_kc_process_temp_config_values")




# COMMAND ----------


if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

# input_path = '/data/known_commercial/hceleads/phd9uat/leads/scratch/known_commercial/'
# path_kc_process_temp_config_values = '/data/known_commercial/hceleads/phd9uat/leads/scratch/known_commercial/config_values/'
# bc='20230905T06'

# COMMAND ----------

input_path = baseurl+input_path
output_path = baseurl+output_path
path_kc_process_temp_config_values = baseurl + path_kc_process_temp_config_values + bc

path_kc_process_temp_patientacctscodes_cross_others = input_path + 'patientacctscodes_cross_others/' + bc
path_kc_process_temp_boundary_condition_01 = input_path + 'boundary_condition_01/' + bc
path_kc_process_temp_boundary_condition_02_03 = input_path + 'boundary_condition_02_03/' + bc

path_kc_process_temp_kc_unfiltered = output_path + 'kc_unfiltered/' + bc
path_kc_process_temp_kc_filtered = output_path + 'kc_filtered/' + bc

print("input_path: ",input_path)
print("path_kc_process_temp_config_values: ",path_kc_process_temp_config_values)
print("path_kc_process_temp_patientacctscodes_cross_others: ",path_kc_process_temp_patientacctscodes_cross_others)
print("output_path: ",output_path)
print("path_kc_process_temp_kc_unfiltered: ",path_kc_process_temp_kc_unfiltered)
print("path_kc_process_temp_kc_filtered: ",path_kc_process_temp_kc_filtered)

# COMMAND ----------

# karthik/data/known_commercial/hceleads/phd9uat/leads/scratch/known_commercial/

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

# CreatedBy        : Max Chatterjee
# CreateDate       : April 12 2021 Mon
# DesignInfo       : https://wiki.transunion.com/display/ESCAN/Account+Evaluation
# StoryInfo        : PI22S04 : US406761 : https://rally1.rallydev.com/#/322955512156/iterationstatus?detail=%2Fuserstory%2F521005892132
# ModifiedBy       :
# ModifiedDate     :
# ModificationInfo :


from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window


df_kc_patientacct = spark.read.parquet(path_kc_process_temp_patientacctscodes_cross_others)
df_kc_patientacct = df_kc_patientacct \
    .withColumn("admitdate", to_timestamp(col("admitdate"))) \
    .withColumn("dischargedate", to_timestamp(col("admitdate"))) \
    .withColumn("totalcharges", col("totalcharges").cast("float")) \
    .withColumn("currentbalance", col("currentbalance").cast("float"))
df_kc_patientacct = df_kc_patientacct.withColumn("admit_discharge_date", coalesce(df_kc_patientacct["dischargedate"], df_kc_patientacct["admitdate"]))
df_kc_patientacct = df_kc_patientacct.withColumn("edipayergroupfk_edipayerpk", coalesce(df_kc_patientacct["edipayergroupfk"], df_kc_patientacct["edipayerpk"])).dropDuplicates()
df_kc_patientacct = df_kc_patientacct.selectExpr("patientacctifk", "hospitalfk", "acctnum", "patientacctipk", "totalcharges", "admitdate", "dischargedate", "admit_discharge_date", "edipayerfk", "edipayerpk", "edipayergroupfk", "edipayergroupfk_edipayerpk",
                                                    "demographicsupdatedate", "firstname", "middlename", "lastname", "ssn", "dob", "gender", "state", "medicalrecnum", "clusteredacctfk", "createdate", "updatedate", "referraldate", "hospitalpk", "hcsystemfk", "hospitalname",
                                                    "hcsname", "medicarehic", "medicaidnum").where(col("edipayergroupfk_edipayerpk").isNotNull())
df_kc_patientacct = df_kc_patientacct.dropDuplicates()
df_kc_patientacct.createOrReplaceTempView("kc_patientacct")
df_boundary_condition_primary = spark.read.parquet(path_kc_process_temp_boundary_condition_01)
df_boundary_condition_primary.createOrReplaceTempView("boundary_condition_primary")
df_config_values = spark.read.parquet(path_kc_process_temp_config_values)
df_config_values.createOrReplaceTempView("config_values")
p_denial_amount = spark.sql("""SELECT hospitalfk,
                                        CASE WHEN attributetype='Money' THEN CAST(config_values.attributevalue AS FLOAT) ELSE 'NULL' END as amount
                                        FROM config_values
                                        WHERE attributename ='KnownCommercialDenialsTotalCharges'""").dropDuplicates()
p_denial_dates = spark.sql("""SELECT hospitalfk,
                                CASE WHEN attributetype='INT' THEN CAST(config_values.attributevalue AS INT) ELSE '0' END AS upper_date,
                                CASE WHEN attributetype='INT' THEN 270 ELSE '0' END AS lower_date
                                FROM config_values
                                WHERE attributename ='KnownCommercialDenialsNumOfDays'""").dropDuplicates()
p_nopay_amount = spark.sql("""SELECT hospitalfk,
                                        CASE WHEN attributetype='Money' THEN CAST(config_values.attributevalue AS FLOAT) ELSE 'NULL' END as amount
                                        FROM config_values
                                        WHERE attributename ='KnownCommercialNoPymtTotalCharges'""").dropDuplicates()
p_nopay_dates = spark.sql("""SELECT hospitalfk,
                                    CASE WHEN attributetype='INT' THEN CAST(config_values.attributevalue AS INT) ELSE '0' END AS upper_date,
                                    CASE WHEN attributetype='INT' THEN 395 ELSE '0' END AS lower_date
                                    FROM config_values
                                    WHERE attributename ='KnownCommercialNoPymtNumOfDays'""").dropDuplicates()
p_denial = p_denial_amount.join(p_denial_dates, p_denial_amount.hospitalfk == p_denial_dates.hospitalfk, 'inner').select(p_denial_amount.hospitalfk, p_denial_amount.amount, p_denial_dates.upper_date, p_denial_dates.lower_date).dropDuplicates()
p_nopay = p_nopay_amount.join(p_nopay_dates, p_nopay_amount.hospitalfk == p_nopay_dates.hospitalfk, 'inner').select(p_nopay_amount.hospitalfk, p_nopay_amount.amount, p_nopay_dates.upper_date, p_nopay_dates.lower_date).dropDuplicates()
# Including only accounts that have a denial. Making the assumption that the denial is the primary based on previous conditions.
sql_evaluate_boundary_condition_primary = """
SELECT
kc_patientacct.*,
CASE WHEN boundary_condition_primary.hospitalfk IS NOT NULL THEN 'Y' ELSE 'N' END AS isDenialAcc
FROM kc_patientacct
    LEFT JOIN boundary_condition_primary
            ON CAST(kc_patientacct.hospitalfk AS BIGINT) = CAST(boundary_condition_primary.hospitalfk AS BIGINT)
        AND TRIM(kc_patientacct.acctnum) = TRIM(boundary_condition_primary.acctnum)
"""
df_kc_patientacct = spark.sql(sql_evaluate_boundary_condition_primary).dropDuplicates()
df_kc_patientacct.createOrReplaceTempView("kc_patientacct")
df_boundary_condition_denial = spark.read.parquet(path_kc_process_temp_boundary_condition_02_03).filter("patientpayment <> 'Y'").drop("patientpayment").dropDuplicates()
df_boundary_condition_denial.createOrReplaceTempView("boundary_condition_denial")
valid_payer = """SELECT * FROM boundary_condition_denial
WHERE
CAST(transamount AS FLOAT) <> 0
AND
(CAST(boundary_condition_denial.hic_edipayergroupfk_edipayerfk AS BIGINT) IS NOT NULL AND CAST(boundary_condition_denial.hic_edipayergroupfk_edipayerfk AS BIGINT) <> 0)
OR
(CAST(boundary_condition_denial.hpc_edipayergroupfk_edipayerfk AS BIGINT) IS NOT NULL AND CAST(boundary_condition_denial.hpc_edipayergroupfk_edipayerfk AS BIGINT) <> 0)
"""
df_boundary_condition_denial = spark.sql(valid_payer).dropDuplicates()
df_boundary_condition_denial = df_boundary_condition_denial.join(p_denial, df_boundary_condition_denial.hospitalfk == p_denial.hospitalfk, 'inner').select(df_boundary_condition_denial['*'], p_denial.amount, p_denial.upper_date, p_denial.lower_date)
df_boundary_condition_denial = df_boundary_condition_denial.selectExpr("hospitalfk", "acctnum", "amount", "lower_date", "upper_date", "hic_edipayergroupfk_edipayerfk", "hpc_edipayergroupfk_edipayerfk", "hip_createdate").dropDuplicates()
df_boundary_condition_denial = df_boundary_condition_denial.withColumn("hpc_hic_edipayergroupfk_edipayerpk", coalesce(df_boundary_condition_denial["hic_edipayergroupfk_edipayerfk"], df_boundary_condition_denial["hpc_edipayergroupfk_edipayerfk"]))
df_boundary_condition_denial = df_boundary_condition_denial.selectExpr("hospitalfk", "acctnum", "amount", "lower_date", "upper_date", "hpc_hic_edipayergroupfk_edipayerpk", "hip_createdate").dropDuplicates()
df_boundary_condition_denial = df_boundary_condition_denial.drop("hip_createdate").dropDuplicates()
df_boundary_condition_denial.createOrReplaceTempView("boundary_condition_denial")
sql_evaluate_boundary_condition_denial = """
SELECT
kc_patientacct.*,
CASE WHEN (
            boundary_condition_denial.hospitalfk IS NOT NULL
            AND
            (
            CAST(kc_patientacct.edipayergroupfk_edipayerpk AS BIGINT) = CAST(boundary_condition_denial.hpc_hic_edipayergroupfk_edipayerpk AS BIGINT)
            )
            ) THEN 'Y'
            ELSE 'N'
            END AS isPrimaryPayerAcc
FROM kc_patientacct
LEFT JOIN boundary_condition_denial
        ON CAST (kc_patientacct.hospitalfk AS BIGINT) = CAST (boundary_condition_denial.hospitalfk AS BIGINT)
    AND TRIM (kc_patientacct.acctnum) = TRIM (boundary_condition_denial.acctnum)
"""
df_kc_patientacct = spark.sql(sql_evaluate_boundary_condition_denial)
df_kc_patientacct.createOrReplaceTempView("kc_patientacct")
sql_dedupe = """
    SELECT patientacctifk,
            hospitalfk,
            acctnum,
            patientacctipk,
            admitdate,
            dischargedate,
            admit_discharge_date,
            edipayerfk,
            edipayerpk,
            edipayergroupfk,
            edipayergroupfk_edipayerpk,
            totalcharges,
            demographicsupdatedate,
            firstname,
            middlename,
            lastname,
            ssn,
            dob,
            gender,
            state,
            referraldate,
            medicalrecnum,
            clusteredacctfk,
            createdate,
            updatedate,
            hospitalpk,
            hcsystemfk,
            hospitalname,
            hcsname,
            medicarehic,
            medicaidnum,
            isDenialAcc,
            collect_set(isPrimaryPayerAcc) AS isPrimaryPayerAcc
    FROM kc_patientacct
    GROUP BY patientacctifk,
                hospitalfk,
                acctnum,
                patientacctipk,
                admitdate,
                dischargedate,
                admit_discharge_date,
                edipayerfk,
                edipayerpk,
                edipayergroupfk,
                edipayergroupfk_edipayerpk,
                totalcharges,
                demographicsupdatedate,
                firstname,
                middlename,
                lastname,
                ssn,
                dob,
                gender,
                state,
                referraldate,
                medicalrecnum,
                clusteredacctfk,
                createdate,
                updatedate,
                hospitalpk,
                hcsystemfk,
                hospitalname,
                hcsname,
                medicarehic,
                medicaidnum,
                isDenialAcc
    """
df_kc_patientacct = spark.sql(sql_dedupe).dropDuplicates()
df_kc_patientacct.createOrReplaceTempView("kc_patientacct")
sql_flag = """
    SELECT *,
            CASE
                WHEN (array_contains (isPrimaryPayerAcc,'Y') AND array_contains (isPrimaryPayerAcc,'N')) THEN 'Y'
                WHEN (size(isPrimaryPayerAcc) = 1 AND array_contains (isPrimaryPayerAcc,'Y')) THEN 'Y'
                WHEN (size(isPrimaryPayerAcc) = 1 AND array_contains (isPrimaryPayerAcc,'N')) THEN 'N'
                ELSE NULL
            END AS mod_isPrimaryPayerAcc
    FROM kc_patientacct"""
df_kc_patientacct = spark.sql(sql_flag).withColumnRenamed("isPrimaryPayerAcc", "array_isPrimaryPayerAcc").withColumnRenamed("mod_isPrimaryPayerAcc", "isPrimaryPayerAcc").dropDuplicates()
df_kc_patientacct.createOrReplaceTempView("kc_patientacct")
p_denial.selectExpr("hospitalfk", "amount", "lower_date", "upper_date").dropDuplicates().createOrReplaceTempView("denialvals")
sql12 = """
SELECT kc_patientacct.*,
        denialvals.amount                                                                     as denial_amount,
        CAST(date_sub (CAST(CURRENT_TIMESTAMP() AS DATE),CAST(denialvals.lower_date AS INT)) AS TIMESTAMP) as denial_lower_date,
        CAST(date_sub (CAST(CURRENT_TIMESTAMP() AS DATE),cast(denialvals.upper_date AS INT)) AS TIMESTAMP) as denial_upper_date
        FROM kc_patientacct LEFT JOIN denialvals ON CAST(kc_patientacct.hospitalfk AS BIGINT) = CAST(denialvals.hospitalfk AS BIGINT)
"""
df_kc_patientacct = spark.sql(sql12).dropDuplicates()
df_kc_patientacct.createOrReplaceTempView("kc_patientacct")
df_boundary_condition_nopay = spark.read.parquet(path_kc_process_temp_boundary_condition_02_03).filter("patientpayment <> 'Y'").dropDuplicates()
df_boundary_condition_nopay = df_boundary_condition_nopay.join(p_nopay, df_boundary_condition_nopay.hospitalfk == p_nopay.hospitalfk, 'inner').select(df_boundary_condition_nopay['*'], p_nopay.amount, p_nopay.upper_date, p_nopay.lower_date)
df_boundary_condition_nopay = df_boundary_condition_nopay.selectExpr("hospitalfk", "acctnum", "amount", "lower_date", "upper_date").dropDuplicates()
df_boundary_condition_nopay.createOrReplaceTempView("boundary_condition_nopay")
sql_evaluate_boundary_condition_nopay = """
SELECT kc_patientacct.*,
        CASE WHEN boundary_condition_nopay.hospitalfk IS NOT NULL THEN 'Y' ELSE 'N' END AS isNoPayAcc
FROM kc_patientacct
    LEFT JOIN boundary_condition_nopay
            ON CAST (kc_patientacct.hospitalfk AS BIGINT) = CAST (boundary_condition_nopay.hospitalfk AS BIGINT)
        AND TRIM (kc_patientacct.acctnum) = TRIM (boundary_condition_nopay.acctnum)
"""
df_kc_patientacct = spark.sql(sql_evaluate_boundary_condition_nopay).dropDuplicates()
df_kc_patientacct.createOrReplaceTempView("kc_patientacct")
p_nopay.selectExpr("hospitalfk", "amount", "lower_date", "upper_date").dropDuplicates().createOrReplaceTempView("nopayvals")
sql12 = """
    SELECT kc_patientacct.*,
            nopayvals.amount                                                                     as nopay_amount,
            CAST(date_sub (CAST(CURRENT_TIMESTAMP() AS DATE),CAST(nopayvals.lower_date AS INT)) AS TIMESTAMP) as nopay_lower_date,
            CAST(date_sub (CAST(CURRENT_TIMESTAMP() AS DATE),CAST(nopayvals.upper_date AS INT)) AS TIMESTAMP) as nopay_upper_date
            FROM kc_patientacct LEFT JOIN nopayvals ON CAST(kc_patientacct.hospitalfk AS BIGINT) = CAST(nopayvals.hospitalfk AS BIGINT)
    """
df_kc_patientacct = spark.sql(sql12).dropDuplicates()
df_kc_patientacct.createOrReplaceTempView("kc_patientacct")
sql_account_evaluation = """
SELECT
kc_patientacct.*,
CASE WHEN ( kc_patientacct.isDenialAcc ='Y' AND
            kc_patientacct.isPrimaryPayerAcc ='N' AND
            CAST(kc_patientacct.totalcharges AS FLOAT) > CAST(kc_patientacct.denial_amount AS FLOAT) AND
            kc_patientacct.admit_discharge_date BETWEEN kc_patientacct.denial_lower_date AND kc_patientacct.denial_upper_date
            ) THEN 'Y' ELSE 'N' END AS denialNoPrimaryPayer,
CASE WHEN ( kc_patientacct.isNoPayAcc ='N' AND
            CAST(kc_patientacct.totalcharges AS FLOAT) >= CAST(kc_patientacct.nopay_amount AS FLOAT) AND
            kc_patientacct.admit_discharge_date BETWEEN kc_patientacct.nopay_lower_date AND kc_patientacct.nopay_upper_date
            ) THEN 'Y' ELSE 'N' END AS noPayAccounts
FROM kc_patientacct
"""
df_kc_unfiltered = spark.sql(sql_account_evaluation).dropDuplicates()
df_kc_unfiltered.repartition(120).write.mode("overwrite").parquet(path_kc_process_temp_kc_unfiltered)
df_kc_unfiltered.unpersist()
df_kc_unfiltered = spark.read.parquet(path_kc_process_temp_kc_unfiltered)
df_kc_unfiltered.createOrReplaceTempView("TEMP")
sql_filtered = """
SELECT patientacctipk,
        hospitalfk,
        firstname,
        middlename,
        lastname,
        ssn,
        dob,
        gender,
        state,
        admitdate,
        referraldate,
        dischargedate,
        medicalrecnum,
        clusteredacctfk,
        totalcharges,
        createdate,
        updatedate,
        demographicsupdatedate,
        medicarehic,
        medicaidnum
FROM TEMP
WHERE denialNoPrimaryPayer = 'Y'
OR    noPayAccounts = 'Y' """
df_kc_filtered = spark.sql(sql_filtered).dropDuplicates()
df_kc_filtered.repartition(100).write.mode("overwrite").parquet(path_kc_process_temp_kc_filtered)
df_kc_filtered.unpersist()

