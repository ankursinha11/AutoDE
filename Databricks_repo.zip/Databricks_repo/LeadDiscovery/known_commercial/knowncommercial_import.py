# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("path_output","")
dbutils.widgets.getArgument("path_output")
path_output= getArgument("path_output")

# COMMAND ----------


if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

path_output = baseurl + path_output +bc
dataingestion_publish_path =  baseurl + '/data/dataingestion/publish/'
print(path_output)
print(dataingestion_publish_path)

# COMMAND ----------

hospitals = spark.read.format("parquet").load(dataingestion_publish_path + 'hospitals/current/20991231/')
hospitalattributevalues = spark.read.format("parquet").load(dataingestion_publish_path + 'hospitalattributevalues/current/20991231/')
hospitalattributes = spark.read.format("parquet").load(dataingestion_publish_path + 'hospitalattributes/current/20991231/')
hospitals.createOrReplaceTempView("hospitals")
hospitalattributevalues.createOrReplaceTempView("hospitalattributevalues")
hospitalattributes.createOrReplaceTempView("hospitalattributes")


extraction_query = """SELECT A.*FROM (SELECT a.*
                     FROM (SELECT ho.hospitalpk, ho.hcsystemfk,
                     COALESCE(hav.hospitalattributevalue,ha.attributedefaultvalue,'0') AS kcenabled
                     FROM hospitals ho
                     LEFT JOIN hospitalattributevalues hav
                     ON ho.hospitalpk = hav.hospitalfk
                     AND hav.hospitalattributefk = 99
                     LEFT JOIN hospitalattributes ha
                     ON ha.hospitalattributepk = hav.hospitalattributefk
                     AND hav.hospitalattributefk = 99) a
                     WHERE a.kcenabled = 1) A"""
import_df = spark.sql(extraction_query)
import_df.write.csv(path_output, sep="\x01", mode="overwrite")
