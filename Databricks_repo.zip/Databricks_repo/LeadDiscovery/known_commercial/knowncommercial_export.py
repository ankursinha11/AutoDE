# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("path_kc_process_final_output_sqoop","")
dbutils.widgets.getArgument("path_kc_process_final_output_sqoop")
path_kc_process_final_output_sqoop = getArgument("path_kc_process_final_output_sqoop")

dbutils.widgets.text("path_kc_process_final_output_sqoop2","")
dbutils.widgets.getArgument("path_kc_process_final_output_sqoop2")
path_kc_process_final_output_sqoop2 = getArgument("path_kc_process_final_output_sqoop2")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("catalog_name","")
dbutils.widgets.getArgument("catalog_name")
catalog_name= getArgument("catalog_name")

# COMMAND ----------

# DBTITLE 1,set basepath
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user
print(baseurl)
# path_conn_file = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-dataingestion-sql-insleads-cs")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# MAGIC %run ../../Common-Util/shard_db_util

# COMMAND ----------

sqoop_db="escan"
tablename1="dbo.hdppatientacctxops"
tablename2="dbo.hdppatientacctxopsbatch"

# COMMAND ----------

def data_migration_to_sql(df, table_name, server_name, connection_string):
    try:
        df.write.format('jdbc').mode('append').option('driver', 'com.microsoft.sqlserver.jdbc.SQLServerDriver').option('url', connection_string).option('dbtable', f"{sqoop_db}.{table_name}").save()
    except Exception as e:        
        raise Exception(f"Sqoop for table - {table_name} failed on server - {server_name}. \n Error - {e}")

# COMMAND ----------

hdp_schema= StructType([
    StructField("PatientAcctIFK", StringType(), True),
    StructField("HospitalFK", StringType(), True),
    StructField("BreadCrumb", StringType(), True)])

hdp_schema_batch= StructType([StructField("BreadCrumb", StringType(), True)])

# COMMAND ----------

hdppatientacctxops = spark.read.csv(baseurl+path_kc_process_final_output_sqoop+bc,sep="\x01",schema=hdp_schema)
hdppatientacctxopsbatch = spark.read.csv(baseurl+path_kc_process_final_output_sqoop2+bc,sep="\x01",schema=hdp_schema_batch)

# COMMAND ----------

# Getting list of all the shard DBs connection string and Hospitals
connection_string_df = get_shard_db_connection_string(catalog_name, f"{baseurl}/data/dataingestion/publish/")
connection_string_map = [{
                            "HospitalFKList": row['HospitalFKList'],
                            "ServerName": row['ServerName'],
                            "ConnectionString": row['ConnectionString']
                        } for row in connection_string_df.collect()]

# COMMAND ----------

for shard in connection_string_map:
    HospitalFKList = shard["HospitalFKList"]    
    df_1 = hdppatientacctxops.filter(col("HospitalFK").isin(HospitalFKList))
    if df_1.take(1):
        data_migration_to_sql(df_1, tablename1, shard["ServerName"], shard['ConnectionString'])
        data_migration_to_sql(hdppatientacctxopsbatch, tablename2, shard["ServerName"], shard['ConnectionString'])
