# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("cloudmigration_tables","")
dbutils.widgets.getArgument("cloudmigration_tables")
cloudmigration_tables = getArgument("cloudmigration_tables")

dbutils.widgets.text("path_kc_process_temp_fnf","")
dbutils.widgets.getArgument("path_kc_process_temp_fnf")
path_kc_process_temp_fnf = getArgument("path_kc_process_temp_fnf")

dbutils.widgets.text("output_path","")
dbutils.widgets.getArgument("output_path")
output_path = getArgument("output_path")

# dbutils.widgets.remove("path_kc_process_temp_config_values")




# COMMAND ----------

# path_kc_process_temp_fnf = '/data/known_commercial/hceleads/phd9uat/leads/scratch/known_commercial/fnf/'
# bc='20230905T06'

# COMMAND ----------


if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

path_kc_process_temp_fnf = baseurl + path_kc_process_temp_fnf
output_path = baseurl + output_path

path_patientaccts = path_kc_process_temp_fnf + "patientaccts"

path_patientacctscodes = path_kc_process_temp_fnf + "patientacctscodes"
path_vsnappatientacctsflags = path_kc_process_temp_fnf + "vsnappatientacctsflags"
path_hospfinclasscodes = path_kc_process_temp_fnf + "hospfinclasscodes"
path_hospinsurancecodes = path_kc_process_temp_fnf + "hospinsurancecodes"
path_edipayers = path_kc_process_temp_fnf + "edipayers"
path_hospitals = path_kc_process_temp_fnf + "hospitals"
path_hcsystems = path_kc_process_temp_fnf + "hcsystems"
path_hospitalimportpayment = path_kc_process_temp_fnf + "hospitalimportpayment"
path_hosppaymentcodes = path_kc_process_temp_fnf + "hosppaymentcodes"


path_kc_process_temp_patientacctscodes_cross_others = output_path + 'patientacctscodes_cross_others/' + bc
path_kc_process_temp_boundary_condition_01 = output_path + 'boundary_condition_01/' + bc
path_kc_process_temp_boundary_condition_02_03 = output_path + 'boundary_condition_02_03/' + bc

print("path_patientaccts: ",path_patientaccts)
print("path_hosppaymentcodes: ",path_hosppaymentcodes)
print("path_kc_process_temp_fnf: ",path_kc_process_temp_fnf)
print("output_path: ",output_path)
print("path_kc_process_temp_patientacctscodes_cross_others: ",path_kc_process_temp_patientacctscodes_cross_others)

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))
spark.sql("SET spark.databricks.delta.formatCheck.enabled=false")

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

# CreateDate       : April 12 2021 Mon
# DesignInfo       : https://wiki.transunion.com/display/ESCAN/Account+Evaluation
# StoryInfo        : PI22S04 : US406761 : https://rally1.rallydev.com/#/322955512156/iterationstatus?detail=%2Fuserstory%2F521005892132
# ModifiedBy       :
# ModifiedDate     :
# ModificationInfo :

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window



def get_hosppaymentcodes(spark, path_hosppaymentcodes):
    pColumnList = ['patientpayment', 'hospitalfk', 'edipayerfk', 'paymenttype', 'code']
    df_hosppaymentcodes = readparquet(spark, path_hosppaymentcodes, "1", pColumnList)
    # df_hosppaymentcodes = spark.read.parquet(path_hosppaymentcodes).selectExpr("patientpayment", "hospitalfk", "edipayerfk", "paymenttype", "code").dropDuplicates()
    for column in df_hosppaymentcodes.columns:
        df_hosppaymentcodes = df_hosppaymentcodes.withColumn(column, trim(col(column)))
        df_hosppaymentcodes = df_hosppaymentcodes.withColumn(column, when(col(column).isNull(), 'PYNULL').otherwise(col(column)))
        df_hosppaymentcodes = df_hosppaymentcodes.withColumn(column, when(col(column) == '', 'PYNULL').otherwise(col(column)))
        df_hosppaymentcodes = df_hosppaymentcodes.withColumn(column, when(col(column) == 'null', 'PYNULL').otherwise(col(column)))
    return df_hosppaymentcodes


def get_hospitalimportpayment(spark, path_hospitalimportpayment):
    pColumnList = ['payer', 'hospitalfk', 'transcategorycode', 'paymenttype', 'acctnum', 'transamount', 'createdate']
    df_hospitalimportpayment = readparquet(spark, path_hospitalimportpayment, "1", pColumnList)
    # df_hospitalimportpayment = spark.read.parquet(path_hospitalimportpayment).selectExpr("payer", "hospitalfk", "transcategorycode", "paymenttype", "acctnum", "transamount").dropDuplicates()
    for column in df_hospitalimportpayment.columns:
        df_hospitalimportpayment = df_hospitalimportpayment.withColumn(column, trim(col(column)))
        df_hospitalimportpayment = df_hospitalimportpayment.withColumn(column, when(col(column).isNull(), '0').otherwise(col(column)))
        df_hospitalimportpayment = df_hospitalimportpayment.withColumn(column, when(col(column) == '', '0').otherwise(col(column)))
    return df_hospitalimportpayment


def get_patientaccts(spark, path_patientaccts):
    pColumnList = ['patientacctipk', 'hospitalfk', 'admitdate', 'dischargedate', 'acctnum', 'totalcharges', 'currentbalance', 'demographicsupdatedate', 'firstname', 'middlename', 'lastname', 'dob', 'ssn', 'gender', 'state', 'medicalrecnum', 'clusteredacctfk', 'createdate',
                   'updatedate', 'referraldate', 'medicarehic', 'medicaidnum']
    df_patientaccts = readparquet(spark, path_patientaccts, "1", pColumnList)
    # df_patientaccts = spark.read.parquet(path_patientaccts).selectExpr("patientacctipk", "hospitalfk", "admitdate", "dischargedate", "acctnum", "totalcharges", "currentbalance").dropDuplicates()
    for column in df_patientaccts.columns:
        df_patientaccts = df_patientaccts.withColumn(column, trim(col(column)))
        df_patientaccts = df_patientaccts.withColumn(column, when(col(column).isNull(), '0').otherwise(col(column)))
        df_patientaccts = df_patientaccts.withColumn(column, when(col(column) == '', '0').otherwise(col(column)))
    return df_patientaccts


def get_patientacctscodes(spark, path_patientacctscodes):
    pColumnList = ['patientacctifk', 'hospitalfk', 'finclasscurrent', 'insurancecode1', 'insurancecode2', 'insurancecode3', 'insurancecode4']
    df_patientacctscodes = readparquet(spark, path_patientacctscodes, "1", pColumnList)
    # df_patientacctscodes = spark.read.parquet(path_patientacctscodes).selectExpr("patientacctifk", "hospitalfk", "finclasscurrent", "insurancecode1", "insurancecode2", "insurancecode3", "insurancecode4").dropDuplicates()
    for column in df_patientacctscodes.columns:
        df_patientacctscodes = df_patientacctscodes.withColumn(column, trim(col(column)))
        df_patientacctscodes = df_patientacctscodes.withColumn(column, when(col(column).isNull(), '0').otherwise(col(column)))
        df_patientacctscodes = df_patientacctscodes.withColumn(column, when(col(column) == '', '0').otherwise(col(column)))
    return df_patientacctscodes


def get_vsnappatientacctsflags(spark, path_vsnappatientacctsflags):
    pColumnList = ['patientacctifk', 'hospitalfk', 'secondarymcaidflag', 'secondarymcaid_afterinsuranceflag']
    df_vsnappatientacctsflags = readparquet(spark, path_vsnappatientacctsflags, "1", pColumnList)
    # df_vsnappatientacctsflags = spark.read.parquet(path_vsnappatientacctsflags).selectExpr("patientacctifk", "hospitalfk", "secondarymcaidflag", "secondarymcaid_afterinsuranceflag").dropDuplicates()
    for column in df_vsnappatientacctsflags.columns:
        df_vsnappatientacctsflags = df_vsnappatientacctsflags.withColumn(column, trim(col(column)))
        df_vsnappatientacctsflags = df_vsnappatientacctsflags.withColumn(column, when(col(column).isNull(), '0').otherwise(col(column)))
        df_vsnappatientacctsflags = df_vsnappatientacctsflags.withColumn(column, when(col(column) == '', '0').otherwise(col(column)))
    return df_vsnappatientacctsflags


def get_hospfinclasscodes(spark, path_hospfinclasscodes):
    pColumnList = ['hospitalfk', 'code', 'codedesc']
    df_hospfinclasscodes = readparquet(spark, path_hospfinclasscodes, "1", pColumnList)
    # df_hospfinclasscodes = spark.read.parquet(path_hospfinclasscodes).selectExpr("hospitalfk", "code", "codedesc").dropDuplicates()
    for column in df_hospfinclasscodes.columns:
        df_hospfinclasscodes = df_hospfinclasscodes.withColumn(column, trim(col(column)))
        df_hospfinclasscodes = df_hospfinclasscodes.withColumn(column, when(col(column).isNull(), '0').otherwise(col(column)))
        df_hospfinclasscodes = df_hospfinclasscodes.withColumn(column, when(col(column) == '', '0').otherwise(col(column)))
    return df_hospfinclasscodes


def get_hospinsurancecodes(spark, path_hospinsurancecodes):
    pColumnList = ["hospitalfk", "code", "codedesc", "tricare", "thirdpartyliabflag", "edipayerfk", "secondarytomcaid"]
    df_hospinsurancecodes = readparquet(spark, path_hospinsurancecodes, "1", pColumnList)
    # df_hospinsurancecodes = spark.read.parquet(path_hospinsurancecodes).selectExpr("hospitalfk", "code", "codedesc", "tricare", "thirdpartyliabflag", "edipayerfk", "secondarytomcaid").dropDuplicates()
    for column in df_hospinsurancecodes.columns:
        df_hospinsurancecodes = df_hospinsurancecodes.withColumn(column, trim(col(column)))
        df_hospinsurancecodes = df_hospinsurancecodes.withColumn(column, when(col(column).isNull(), '0').otherwise(col(column)))
        df_hospinsurancecodes = df_hospinsurancecodes.withColumn(column, when(col(column) == '', '0').otherwise(col(column)))
    return df_hospinsurancecodes


def get_edipayers(spark, path_edipayers):
    pColumnList = ["edipayergroupfk", "edipayerpk"]
    df_edipayers = readparquet(spark, path_edipayers, "1", pColumnList)
    for column in df_edipayers.columns:
        df_edipayers = df_edipayers.withColumn(column, trim(col(column)))
        df_edipayers = df_edipayers.withColumn(column, when(col(column).isNull(), '0').otherwise(col(column)))
        df_edipayers = df_edipayers.withColumn(column, when(col(column) == '', '0').otherwise(col(column)))
    return df_edipayers


def get_hospitals(spark, path_hospitals):
    pColumnList = ["hospitalpk", "hospitalname", "hcsystemfk"]
    df_hospitals = readparquet(spark, path_hospitals, "1", pColumnList)
    # df_hospitals = spark.read.parquet(path_hospitals).selectExpr("hospitalpk", "hospitalname", "hcsystemfk").dropDuplicates()
    return df_hospitals


def get_hcsystems(spark, path_hcsystems):
    pColumnList = ["hcsystempk", "hcsname"]
    df_hcsystems = readparquet(spark, path_hcsystems, "1", pColumnList).dropDuplicates()
    # kc_hcsystems_codes = ["570", "283"]
    # df_hcsystems = df_hcsystems.where(col("hcsystempk").isin(kc_hcsystems_codes)).dropDuplicates()
    return df_hcsystems



df_patientacctscodes = get_patientacctscodes(spark, path_patientacctscodes)
df_patientaccts = get_patientaccts(spark, path_patientaccts)
df_vsnappatientacctsflags = get_vsnappatientacctsflags(spark, path_vsnappatientacctsflags)
df_hospfinclasscodes = get_hospfinclasscodes(spark, path_hospfinclasscodes)
df_hospinsurancecodes = get_hospinsurancecodes(spark, path_hospinsurancecodes)
df_hospitalimportpayment = get_hospitalimportpayment(spark, path_hospitalimportpayment)
df_hosppaymentcodes = get_hosppaymentcodes(spark, path_hosppaymentcodes)
df_hospitals = get_hospitals(spark, path_hospitals)
df_hcsystems = get_hcsystems(spark, path_hcsystems)
df_edipayers = get_edipayers(spark, path_edipayers)
# CREATING VIEWS
df_patientacctscodes.createOrReplaceTempView("patientacctscodes")
df_patientaccts.createOrReplaceTempView("patientaccts")
df_vsnappatientacctsflags.createOrReplaceTempView("vsnappatientacctsflags")
df_hospfinclasscodes.createOrReplaceTempView("hospfinclasscodes")
df_hospinsurancecodes.createOrReplaceTempView("hospinsurancecodes")
df_hospitals.createOrReplaceTempView("hospitals")
df_hcsystems.createOrReplaceTempView("hcsystems")
df_hospitalimportpayment.createOrReplaceTempView("hospitalimportpayment")
df_hosppaymentcodes.createOrReplaceTempView("hosppaymentcodes")
df_edipayers.createOrReplaceTempView("edipayers")
print("KC-PROC-02 : READING SOURCE TABLE : COMPLETE")
sql_patientacctscodes_joined_patientaccts_joined_vsnappatientacctsflags = """
SELECT patientacctscodes.*,
        vsnappatientacctsflags.secondarymcaidflag,
        vsnappatientacctsflags.secondarymcaid_afterinsuranceflag
FROM (SELECT patientacctscodes.*,
                patientaccts.acctnum,
                patientaccts.patientacctipk,
                patientaccts.totalcharges,
                patientaccts.currentbalance,
                patientaccts.admitdate,
                patientaccts.dischargedate,
                patientaccts.demographicsupdatedate,
                patientaccts.firstname,
                patientaccts.middlename,
                patientaccts.lastname,
                patientaccts.ssn,
                patientaccts.dob,
                patientaccts.gender,
                patientaccts.state,
                patientaccts.medicalrecnum,
                patientaccts.clusteredacctfk,
                patientaccts.createdate,
                patientaccts.updatedate,
                patientaccts.referraldate,
                patientaccts.medicarehic,
                patientaccts.medicaidnum
        FROM patientacctscodes
        JOIN patientaccts
            ON CAST (patientacctscodes.hospitalfk AS BIGINT) = CAST (patientaccts.hospitalfk AS BIGINT)
            AND CAST (patientacctscodes.patientacctifk AS BIGINT) = CAST (patientaccts.patientacctipk AS BIGINT)) patientacctscodes
    JOIN vsnappatientacctsflags
    ON CAST (patientacctscodes.hospitalfk AS BIGINT) = CAST (vsnappatientacctsflags.hospitalfk AS BIGINT)
    AND CAST (patientacctscodes.patientacctipk AS BIGINT) = CAST (vsnappatientacctsflags.patientacctifk AS BIGINT)
"""
df_patientacctscodes_cross_others = spark.sql(sql_patientacctscodes_joined_patientaccts_joined_vsnappatientacctsflags).dropDuplicates()
writeparquet(spark, df_patientacctscodes_cross_others, path_kc_process_temp_fnf + "/patxpacxvnap/", 256, "overwrite")
df_patientacctscodes_cross_others.unpersist()
df_patientacctscodes_cross_others = spark.read.parquet(path_kc_process_temp_fnf + "/patxpacxvnap/")
df_patientacctscodes_cross_others.createOrReplaceTempView("patientacctscodes_cross_others")
sql_patientacctscodes_cross_others_ljoined_hospfinclasscodes = """
SELECT patientacctscodes_cross_others.*,
        hospfinclasscodes.codedesc AS finclasscurrentdesc
FROM patientacctscodes_cross_others
    JOIN hospfinclasscodes
    ON CAST (patientacctscodes_cross_others.hospitalfk AS BIGINT) = CAST (hospfinclasscodes.hospitalfk AS BIGINT)
    AND TRIM (patientacctscodes_cross_others.finclasscurrent) = TRIM (hospfinclasscodes.code)
"""
df_patientacctscodes_cross_others = spark.sql(sql_patientacctscodes_cross_others_ljoined_hospfinclasscodes).dropDuplicates()
df_patientacctscodes_cross_others.createOrReplaceTempView("patientacctscodes_cross_others")
sql_patientacctscodes_cross_others_ljoin_hospinsurancecodes = """
SELECT patientacctscodes_cross_others.*,
    hospinsurancecodes.codedesc AS insurancecode4desc
    FROM (SELECT patientacctscodes_cross_others.*,
            hospinsurancecodes.codedesc AS insurancecode3desc
    FROM (SELECT patientacctscodes_cross_others.*,
                hospinsurancecodes.codedesc AS insurancecode2desc
        FROM (SELECT patientacctscodes_cross_others.*,
                        hospinsurancecodes.codedesc AS insurancecode1desc,
                        CASE
                        WHEN CAST(hospinsurancecodes.edipayerfk AS BIGINT) = 0 THEN NULL
                        ELSE CAST(hospinsurancecodes.edipayerfk AS BIGINT)
                        END AS edipayerfk,
                        CASE
                        WHEN CAST(edipayers.edipayerpk AS BIGINT) = 0 THEN NULL
                        ELSE CAST(edipayers.edipayerpk AS BIGINT)
                        END AS edipayerpk,
                        CASE
                        WHEN CAST(edipayers.edipayergroupfk AS BIGINT) = 0 THEN NULL
                        ELSE CAST(edipayers.edipayergroupfk AS BIGINT)
                        END AS edipayergroupfk
                FROM patientacctscodes_cross_others
                LEFT JOIN hospinsurancecodes
                        ON CAST (patientacctscodes_cross_others.hospitalfk AS BIGINT) = CAST (hospinsurancecodes.hospitalfk AS BIGINT)
                        AND TRIM (patientacctscodes_cross_others.insurancecode1) = TRIM (hospinsurancecodes.code)
                LEFT JOIN edipayers ON CAST (hospinsurancecodes.edipayerfk AS BIGINT) = CAST (edipayers.edipayerpk AS BIGINT)
                WHERE CAST(hospinsurancecodes.tricare AS BIGINT) <> '1'
                AND   CAST(hospinsurancecodes.thirdpartyliabflag AS BIGINT) <> '1') patientacctscodes_cross_others
            LEFT JOIN hospinsurancecodes
                    ON CAST (patientacctscodes_cross_others.hospitalfk AS BIGINT) = CAST (hospinsurancecodes.hospitalfk AS BIGINT)
                AND TRIM (patientacctscodes_cross_others.insurancecode2) = TRIM (hospinsurancecodes.code)
        WHERE CAST(hospinsurancecodes.secondarytomcaid AS BIGINT) = '1') patientacctscodes_cross_others
    LEFT JOIN hospinsurancecodes
            ON CAST (patientacctscodes_cross_others.hospitalfk AS BIGINT) = CAST (hospinsurancecodes.hospitalfk AS BIGINT)
            AND TRIM (patientacctscodes_cross_others.insurancecode3) = TRIM (hospinsurancecodes.code)
    WHERE CAST(hospinsurancecodes.secondarytomcaid AS BIGINT) = '1') patientacctscodes_cross_others
LEFT JOIN hospinsurancecodes
        ON CAST (patientacctscodes_cross_others.hospitalfk AS BIGINT) = CAST (hospinsurancecodes.hospitalfk AS BIGINT)
    AND TRIM (patientacctscodes_cross_others.insurancecode4) = TRIM (hospinsurancecodes.code)
WHERE CAST(hospinsurancecodes.secondarytomcaid AS BIGINT) = '1'
"""
df_patientacctscodes_cross_others_ljoin_hospinsurancecodes = spark.sql(sql_patientacctscodes_cross_others_ljoin_hospinsurancecodes)
df_patientacctscodes_cross_others_ljoin_hospinsurancecodes.createOrReplaceTempView("patientacctscodes_cross_others_ljoin_hospinsurancecodes")
sql_patientacctscodes_cross_others_ljoin_hospinsurancecodes_join_hospital_hcsystem = """
SELECT patientacctscodes_cross_others_ljoin_hospinsurancecodes.*,
        hcsystems.hcsname
FROM (
        SELECT patientacctscodes_cross_others_ljoin_hospinsurancecodes.*,
                hospitals.hospitalpk,
                hospitals.hcsystemfk,
                hospitals.hospitalname
        FROM patientacctscodes_cross_others_ljoin_hospinsurancecodes
        JOIN hospitals ON CAST (patientacctscodes_cross_others_ljoin_hospinsurancecodes.hospitalfk AS BIGINT) = CAST (hospitals.hospitalpk AS BIGINT)
        WHERE CAST(patientacctscodes_cross_others_ljoin_hospinsurancecodes.secondarymcaid_afterinsuranceflag AS BIGINT) = '1'
        ) 
        patientacctscodes_cross_others_ljoin_hospinsurancecodes
    JOIN hcsystems ON CAST (patientacctscodes_cross_others_ljoin_hospinsurancecodes.hcsystemfk AS BIGINT) = CAST (hcsystems.hcsystempk AS BIGINT)

"""
df_patientacctscodes_cross_others_ljoin_hospinsurancecodes_join_hospital_hcsystem = spark.sql(sql_patientacctscodes_cross_others_ljoin_hospinsurancecodes_join_hospital_hcsystem)
writeparquet(spark, df_patientacctscodes_cross_others_ljoin_hospinsurancecodes_join_hospital_hcsystem, path_kc_process_temp_patientacctscodes_cross_others, 250, "overwrite")
df_patientacctscodes_cross_others_ljoin_hospinsurancecodes_join_hospital_hcsystem.unpersist()
print("KC-PROC-03 : PATACCxOTHERS WRITING : COMPLETE")
sql_boundary_condition_01 = """
SELECT 
    hospitalimportpayment.hospitalfk,
    hospitalimportpayment.acctnum,
    CASE
        WHEN (
        TRIM(hospitalimportpayment.paymenttype) = 'null' OR 
        TRIM(hospitalimportpayment.paymenttype) IS NULL OR 
        TRIM(hospitalimportpayment.paymenttype) = 'PYNULL' OR 
        CAST(hospitalimportpayment.paymenttype AS BIGINT) = 0) THEN NULL
        ELSE TRIM(hospitalimportpayment.paymenttype)
    END AS hip_paymenttype,
    CASE
        WHEN (
        TRIM(hosppaymentcodes.paymenttype) = 'null' OR 
        TRIM(hosppaymentcodes.paymenttype) IS NULL OR 
        TRIM(hosppaymentcodes.paymenttype) = 'PYNULL' OR 
        CAST(hosppaymentcodes.paymenttype AS BIGINT) = 0) THEN NULL
        ELSE TRIM(hosppaymentcodes.paymenttype)
    END AS hpc_paymenttype,
    CASE
        WHEN CAST(hospitalimportpayment.transamount AS FLOAT) IS NULL THEN CAST('0' AS FLOAT)
        ELSE CAST(hospitalimportpayment.transamount AS FLOAT)
    END AS transamount,
    CASE
        WHEN hosppaymentcodes.patientpayment = 'PYNULL' THEN 'N'
        ELSE 'Y'
    END AS patientpayment
    FROM hospitalimportpayment
    JOIN hosppaymentcodes
    ON CAST (hospitalimportpayment.hospitalfk AS BIGINT) = CAST (hosppaymentcodes.hospitalfk AS BIGINT)
    AND TRIM (hospitalimportpayment.transcategorycode) = TRIM (hosppaymentcodes.code)
    LEFT JOIN hospinsurancecodes
        ON CAST (hospitalimportpayment.hospitalfk AS BIGINT) = CAST (hospinsurancecodes.hospitalfk AS BIGINT)
    AND TRIM (hospitalimportpayment.payer) = TRIM (hospinsurancecodes.code)
"""
df_boundary_condition_01 = spark.sql(sql_boundary_condition_01).dropDuplicates()
df_boundary_condition_01 = df_boundary_condition_01.withColumn("paymenttype", coalesce(df_boundary_condition_01["hip_paymenttype"], df_boundary_condition_01["hpc_paymenttype"]))
df_boundary_condition_01.createOrReplaceTempView("bc01")
sqlbc01 = """
SELECT *
FROM bc01
WHERE paymenttype NOT IN ('ADJ','OTH','PYNULL','0')
AND   CAST(transamount AS FLOAT) = 0
AND   patientpayment <> 'Y'
"""
df_boundary_condition_01 = spark.sql(sqlbc01).dropDuplicates()
writeparquet(spark, df_boundary_condition_01, path_kc_process_temp_boundary_condition_01, 251, "overwrite")
df_boundary_condition_01.unpersist()
print("KC-PROC-04 : BOUNDARY CONDITION 01 Writing : COMPLETE")
sql_boundary_condition_02_03 = """
SELECT A.*,
    CASE WHEN CAST(edipayers.edipayergroupfk AS BIGINT) = 0 THEN NULL
        WHEN CAST(edipayers.edipayergroupfk AS BIGINT) IS NULL THEN NULL
        ELSE CAST(edipayers.edipayergroupfk AS BIGINT) 
        END AS hic_edipayergroupfk
    FROM (SELECT A.*,
            CASE WHEN CAST(edipayers.edipayergroupfk AS BIGINT) = 0 THEN NULL 
                WHEN CAST(edipayers.edipayergroupfk AS BIGINT) IS NULL THEN NULL
                ELSE CAST(edipayers.edipayergroupfk AS BIGINT) END AS hpc_edipayergroupfk
    FROM (SELECT *
        FROM (SELECT A.*,
                        COALESCE(hip_paymenttype,hpc_paymenttype) AS paymenttype
                FROM (SELECT hospitalimportpayment.hospitalfk,
                            hospitalimportpayment.acctnum,
                            hospitalimportpayment.createdate as hip_createdate,
                            CASE
                                WHEN (TRIM(hosppaymentcodes.edipayerfk) = 'null' OR 
                                    TRIM(hosppaymentcodes.edipayerfk) IS NULL OR 
                                    CAST(hosppaymentcodes.edipayerfk AS BIGINT) = 0) THEN NULL
                                ELSE CAST(hosppaymentcodes.edipayerfk AS BIGINT)
                            END AS hpc_edipayerfk,
                            CASE
                                WHEN (TRIM(hospinsurancecodes.edipayerfk) = 'null' OR 
                                    TRIM(hospinsurancecodes.edipayerfk) IS NULL OR 
                                    CAST(hospinsurancecodes.edipayerfk AS BIGINT) = 0) THEN NULL
                                ELSE CAST(hospinsurancecodes.edipayerfk AS BIGINT)
                            END AS hic_edipayerfk,
                            CASE
                                WHEN (TRIM(hospitalimportpayment.paymenttype) = 'null' OR TRIM(hospitalimportpayment.paymenttype) IS NULL OR TRIM(hospitalimportpayment.paymenttype) = 'PYNULL' OR CAST(hospitalimportpayment.paymenttype AS BIGINT) = 0) THEN NULL
                                ELSE TRIM(hospitalimportpayment.paymenttype)
                            END AS hip_paymenttype,
                            CASE
                                WHEN (TRIM(hosppaymentcodes.paymenttype) = 'null' OR TRIM(hosppaymentcodes.paymenttype) IS NULL OR TRIM(hosppaymentcodes.paymenttype) = 'PYNULL' OR CAST(hosppaymentcodes.paymenttype AS BIGINT) = 0) THEN NULL
                                ELSE TRIM(hosppaymentcodes.paymenttype)
                            END AS hpc_paymenttype,
                            CASE
                                WHEN CAST(hospitalimportpayment.transamount AS FLOAT) IS NULL THEN CAST('0' AS FLOAT)
                                ELSE CAST(hospitalimportpayment.transamount AS FLOAT)
                            END AS transamount,
                            CASE
                                WHEN hosppaymentcodes.patientpayment = 'PYNULL' THEN 'N'
                                ELSE 'Y'
                            END AS patientpayment
                    FROM hospitalimportpayment
                        JOIN hosppaymentcodes
                        ON CAST (hospitalimportpayment.hospitalfk AS BIGINT) = CAST (hosppaymentcodes.hospitalfk AS BIGINT)
                        AND TRIM (hospitalimportpayment.transcategorycode) = TRIM (hosppaymentcodes.code)
                        LEFT JOIN hospinsurancecodes
                                ON CAST (hospitalimportpayment.hospitalfk AS BIGINT) = CAST (hospinsurancecodes.hospitalfk AS BIGINT)
                            AND TRIM (hospitalimportpayment.payer) = TRIM (hospinsurancecodes.code)) A) A
        WHERE A.paymenttype NOT IN ('ADJ','OTH','0','PYNULL')
        AND   A.transamount <> 0) A
    LEFT JOIN edipayers ON CAST (A.hpc_edipayerfk AS BIGINT) = CAST (edipayers.edipayerpk AS BIGINT)) A
LEFT JOIN edipayers ON CAST (A.hic_edipayerfk AS BIGINT) = CAST (edipayers.edipayerpk AS BIGINT)
"""
df_boundary_condition_02_03 = spark.sql(sql_boundary_condition_02_03).dropDuplicates()
df_boundary_condition_02_03 = df_boundary_condition_02_03 \
    .withColumn("hic_edipayergroupfk_edipayerfk", coalesce(df_boundary_condition_02_03["hic_edipayergroupfk"], df_boundary_condition_02_03["hic_edipayerfk"])) \
    .withColumn("hpc_edipayergroupfk_edipayerfk", coalesce(df_boundary_condition_02_03["hpc_edipayergroupfk"], df_boundary_condition_02_03["hpc_edipayerfk"])).dropDuplicates()
df_boundary_condition_02_03 = df_boundary_condition_02_03.withColumn("hip_createdate", to_timestamp(col("hip_createdate")))
writeparquet(spark, df_boundary_condition_02_03, path_kc_process_temp_boundary_condition_02_03, 252, "overwrite")
df_boundary_condition_02_03.unpersist()
print("KC-PROC-05 : BOUNDARY CONDITION 03 Writing : COMPLETE")
    # spark.stop()
    # exit(0)


