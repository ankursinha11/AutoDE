# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("hdfs_candidateaccts_path","")
dbutils.widgets.getArgument("hdfs_candidateaccts_path")
hdfs_candidateaccts_path= getArgument("hdfs_candidateaccts_path")

dbutils.widgets.text("hdfs_lsb_helper","")
dbutils.widgets.getArgument("hdfs_lsb_helper")
hdfs_lsb_helper= getArgument("hdfs_lsb_helper")

dbutils.widgets.text("hdfs_scratch_path","")
dbutils.widgets.getArgument("hdfs_scratch_path")
hdfs_scratch_path= getArgument("hdfs_scratch_path")

dbutils.widgets.text("module","")
dbutils.widgets.getArgument("module")
module= getArgument("module")

# COMMAND ----------

# DBTITLE 1,Set Base URL
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

# bc = bc
# ip_cpa = hdfs_candidateaccts_path
# ip_lsb_id = hdfs_lsb_helper
# scratch_path = hdfs_scratch_path
# # fs_common = sys.argv[5]
# scratch_path_permid = scratch_path + "/candidatepaxpermid/" + bc
# scratch_path_gmrnid = scratch_path + "/candidatepaxglobalmrnifk/" + bc
# scratch_path_ssn    = scratch_path + "/candidatepaxssn/" + bc
# scratch_path_medicalrecnum = scratch_path + "/candidatepaxmedicalrecnum/" + bc
# scratch_path_clusteredacctfk = scratch_path + "/candidatepaxclusteredacctfk/" + bc

# COMMAND ----------

if module == "aid":
    ip_cpa = baseurl + hdfs_candidateaccts_path + module + "/" + bc
    scratch_path_permid = baseurl + hdfs_scratch_path + "/candidatepaxpermid/" + module + "/" + bc
    scratch_path_gmrnid = baseurl + hdfs_scratch_path + "/candidatepaxglobalmrnifk/" + module + "/" + bc
    scratch_path_ssn    = baseurl + hdfs_scratch_path + "/candidatepaxssn/" + module + "/" + bc
    scratch_path_medicalrecnum = baseurl + hdfs_scratch_path + "/candidatepaxmedicalrecnum/" + module + "/" + bc
    scratch_path_clusteredacctfk = baseurl + hdfs_scratch_path + "/candidatepaxclusteredacctfk/" + module + "/" + bc
    ip_lsb_id = baseurl + hdfs_lsb_helper
else:
    ip_cpa = baseurl + hdfs_candidateaccts_path + bc
    scratch_path_permid = baseurl + hdfs_scratch_path + "/candidatepaxpermid/" + bc
    scratch_path_gmrnid = baseurl + hdfs_scratch_path + "/candidatepaxglobalmrnifk/" + bc
    scratch_path_ssn    = baseurl + hdfs_scratch_path + "/candidatepaxssn/" + bc
    scratch_path_medicalrecnum = baseurl + hdfs_scratch_path + "/candidatepaxmedicalrecnum/" + bc
    scratch_path_clusteredacctfk = baseurl + hdfs_scratch_path + "/candidatepaxclusteredacctfk/" + bc
    ip_lsb_id = baseurl + hdfs_lsb_helper

print("bc : " + str(bc))
print("container : " + str(container))
print("storageaccount : " + str(storageaccount))
print("user : " + str(user))
print("module : " + str(module))
print("--------------------------------------------------------")
print("ip_cpa : " + str(ip_cpa))
print("scratch_path_permid : " + str(scratch_path_permid))
print("scratch_path_gmrnid : " + str(scratch_path_gmrnid))
print("scratch_path_ssn : " + str(scratch_path_ssn))
print("scratch_path_medicalrecnum : " + str(scratch_path_medicalrecnum))
print("scratch_path_clusteredacctfk : " + str(scratch_path_clusteredacctfk))
print("ip_lsb_id : " + str(hdfs_lsb_helper))


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

def get_mbi_lead_id(spark,df,op_path):
    df = df.withColumn("id_list",split(col("_id"),"_"))
    df = df.withColumn("coverageid",df.id_list.getItem(size(df.id_list) - 1))
    df = df.withColumn("edipartnerfk",df.id_list.getItem(size(df.id_list) - 2))
    df = df.filter((df.edipartnerfk == "82") | (df.edipartnerfk == "92"))
    all_leads_mbi = df.where(df.coverageid.rlike(
        "^[1-9][AC-HJKMNPQRT-Y][0-9AC-HJKMNPQRT-Y][0-9][AC-HJKMNPQRT-Y][0-9AC-HJKMNPQRT-Y][0-9][AC-HJKMNPQRT-Y][AC-HJKMNPQRT-Y][0-9][0-9]$"))
    writeparquet(spark,all_leads_mbi,op_path,100,"overwrite")

    
#getting the associated lsb id for the permid 

def get_lsb_id_from_permid(spark,df_candidatepa,df_lsb_id,scratch_path_permid):
    df_candidatepa_permid = df_candidatepa.where(col("permid").isNotNull()).withColumn("permid_formatted", concat(lit("P_"), col("permid")))
    df_candidatepa_permid = df_candidatepa_permid.join(df_lsb_id, df_candidatepa_permid.permid_formatted == df_lsb_id.lookupvalue, 'inner').select(df_candidatepa_permid['*'], df_lsb_id._id).dropDuplicates()
    get_mbi_lead_id(spark,df_candidatepa_permid,scratch_path_permid)

#getting the associated lsb id for the gmrnid

def get_lsb_id_from_gmrnid(spark,df_candidatepa,df_lsb_id,scratch_path_gmrnid):
    df_candidatepa_gmrnid = df_candidatepa.where(col("globalmrnifk").isNotNull()).withColumn("globalmrnifk_formatted", concat(lit("G_"), col("globalmrnifk")))
    df_candidatepa_grmnid = df_candidatepa_gmrnid.join(df_lsb_id,df_candidatepa_gmrnid.globalmrnifk_formatted == df_lsb_id.lookupvalue, 'inner').select(df_candidatepa_gmrnid['*'], df_lsb_id._id).dropDuplicates()
    get_mbi_lead_id(spark,df_candidatepa_grmnid,scratch_path_gmrnid)


#getting the associated lsb id for the ssn

def get_lsb_id_from_ssn(spark,df_candidatepa,df_lsb_id,scratch_path_ssn):
    df_candidatepa_ssn = df_candidatepa.where(col("ssn").isNotNull()).withColumn("ssn_formatted", concat(lit("S_"), col("ssn")))
    df_candidatepa_ssn = df_candidatepa_ssn.join(df_lsb_id, df_candidatepa_ssn.ssn_formatted == df_lsb_id.lookupvalue, 'inner').select(df_candidatepa_ssn['*'], df_lsb_id._id).dropDuplicates()
    get_mbi_lead_id(spark,df_candidatepa_ssn,scratch_path_ssn)


#getting the associated lsb id for the medicalrecnum

def get_lsb_id_from_medicalrecnum(spark,df_candidatepa,df_lsb_id,scratch_path_medicalrecnum):
    df_candidatepa_medicalrecnum = df_candidatepa.where(col("medicalrecnum").isNotNull()).withColumn("medicalrecnum_formatted", concat(lit("MH_"), col("hospitalfk"), lit("_"),col("medicalrecnum")))
    df_candidatepa_medicalrecnum = df_candidatepa_medicalrecnum.join(df_lsb_id, df_candidatepa_medicalrecnum.medicalrecnum_formatted == df_lsb_id.lookupvalue, 'inner').select(df_candidatepa_medicalrecnum['*'], df_lsb_id._id).dropDuplicates()  
    get_mbi_lead_id(spark,df_candidatepa_medicalrecnum,scratch_path_medicalrecnum)


#getting the associated lsb id for the clusteredacctfk

def get_lsb_id_from_clusteredacctfk(spark,df_candidatepa,df_lsb_id,scratch_path_clusteredacctfk):
    df_candidatepa_clusteredacctfk = df_candidatepa.where(col("clusteredacctfk").isNotNull()).withColumn("clusteredacctfk_formatted", concat(lit("CH_"), col("hospitalfk"),lit("_"), col("clusteredacctfk")))
    df_candidatepa_clusteredacctfk = df_candidatepa_clusteredacctfk.join(df_lsb_id, df_candidatepa_clusteredacctfk.clusteredacctfk_formatted == df_lsb_id.lookupvalue, 'inner').select(df_candidatepa_clusteredacctfk['*'], df_lsb_id._id).dropDuplicates()
    get_mbi_lead_id(spark,df_candidatepa_clusteredacctfk,scratch_path_clusteredacctfk)


# COMMAND ----------

df_candidatepa = readparquet(spark,ip_cpa, "0","na")

lsb_id_columns = ["lookupvalue","_id"]
df_lsb_id = readparquet(spark,ip_lsb_id, "1",lsb_id_columns).dropDuplicates()

get_lsb_id_from_permid(spark,df_candidatepa,df_lsb_id,scratch_path_permid)
get_lsb_id_from_gmrnid(spark,df_candidatepa,df_lsb_id,scratch_path_gmrnid)
get_lsb_id_from_ssn(spark,df_candidatepa,df_lsb_id,scratch_path_ssn)
get_lsb_id_from_medicalrecnum(spark,df_candidatepa,df_lsb_id,scratch_path_medicalrecnum)
get_lsb_id_from_clusteredacctfk(spark,df_candidatepa,df_lsb_id,scratch_path_clusteredacctfk)
