# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("hdfs_input_path","")
dbutils.widgets.getArgument("hdfs_input_path")
hdfs_input_path= getArgument("hdfs_input_path")

dbutils.widgets.text("hdfs_int_path","")
dbutils.widgets.getArgument("hdfs_int_path")
hdfs_int_path= getArgument("hdfs_int_path")

dbutils.widgets.text("hdfs_minmaxdt_path_edipartnerfk","")
dbutils.widgets.getArgument("hdfs_minmaxdt_path_edipartnerfk")
hdfs_minmaxdt_path_edipartnerfk= getArgument("hdfs_minmaxdt_path_edipartnerfk")

dbutils.widgets.text("hdfs_leads_output","")
dbutils.widgets.getArgument("hdfs_leads_output")
hdfs_leads_output= getArgument("hdfs_leads_output")

dbutils.widgets.text("hdfs_scratch","")
dbutils.widgets.getArgument("hdfs_scratch")
hdfs_scratch= getArgument("hdfs_scratch")

dbutils.widgets.text("hdfs_maprdb_lookup_path","")
dbutils.widgets.getArgument("hdfs_maprdb_lookup_path")
hdfs_maprdb_lookup_path= getArgument("hdfs_maprdb_lookup_path")

dbutils.widgets.text("module","")
dbutils.widgets.getArgument("module")
module= getArgument("module")

# COMMAND ----------

# DBTITLE 1,Set Base URL
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

hdfs_input_path = baseurl + hdfs_input_path
hdfs_maprdb_lookup_path = baseurl + hdfs_maprdb_lookup_path

if module == "aid":
    hdfs_int_path = baseurl + hdfs_int_path + "aid/" + bc
    hdfs_minmaxdt_path_edipartnerfk = baseurl + hdfs_minmaxdt_path_edipartnerfk + "aid/" + bc
    hdfs_scratch = baseurl+hdfs_scratch + "/aid/" + bc
    hdfs_leads_output = baseurl + hdfs_leads_output + "aid/" + bc

else:
    hdfs_int_path = baseurl + hdfs_int_path +bc
    hdfs_minmaxdt_path_edipartnerfk = baseurl +hdfs_minmaxdt_path_edipartnerfk +bc
    hdfs_scratch = baseurl+hdfs_scratch +bc
    hdfs_leads_output = baseurl +hdfs_leads_output+bc


print("hdfs_int_path:",hdfs_int_path)
print("hdfs_minmaxdt_path_edipartnerfk: ",hdfs_minmaxdt_path_edipartnerfk)
print("hdfs_scratch: ",hdfs_scratch)
print("hdfs_leads_output: ",hdfs_leads_output)
print("hdfs_maprdb_lookup_path: ",hdfs_maprdb_lookup_path)


# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

# MAGIC %run /Insleads-code/LeadDiscovery/common/process_leads

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions","auto")

# COMMAND ----------

# This functions returns all the medicare lead to the configured edipartnerfk

def get_medicare_edipartners(spark, all_leads, hdfs_input):
    ptcol = ['edipartnertypepk', 'iscommercial', 'istricare', 'ismedicare']
    partnertype = readparquet(spark, hdfs_input + "/edipartnertype/current/*", "1", ptcol)
    partnertype = partnertype.withColumn('edipartnertypepk', partnertype.edipartnertypepk.cast('int'))
    pcol = ['edipartnertypefk', 'allowknownmedicaidqueriesflag', 'edipartnerpk']
    partners = readparquet(spark, hdfs_input + "/edipartners/current/*", "1", pcol)
    pt = partners.join(partnertype, partners.edipartnertypefk == partnertype.edipartnertypepk).filter(
        col("ismedicare") == "1")
    pt.createOrReplaceTempView("partners")
    all_leads.createOrReplaceTempView("lead")
    leads = spark.sql(""" select l.*\
                               from lead l inner join partners pt on pt.edipartnerpk=l.lsb_edipartnerfk\
                      """)
    return leads


#add hardcoded edidatasourcefk= 49 for medicare leads

def add_edidatasourcefk(spark, all_leads_wallingoff_tmp, hdfs_maprdb_input,hdfs_scratch):
#    df = spark.loadFromMapRDB(hdfs_maprdb_input)
    edi = all_leads_wallingoff_tmp.withColumn("edidatasourcefk",lit('49'))
    return edi


# This Functions take input dataframe and cleans it
# i. Change all lsb_edipartnerfk "92" to "82"
# ii. Make null as blanks


def get_clean_mbi_lead_data(spark, all_leads_mbi,hdfs_scratch):
    cond_coverageid = when( \
        ((lower(trim(col("lsb_coverageid"))).startswith("null"))) \
        , regexp_replace(col("lsb_coverageid"), "null", "") \
        ) \
        .otherwise(col("lsb_coverageid"))
    all_leads_mbi = all_leads_mbi.withColumn("lsb_coverageid", cond_coverageid)
    cond_id = when( \
        ((lower(trim(col("lsb_id"))).contains("_null"))) \
        , regexp_replace(col("lsb_id"), "null", "") \
        ) \
        .otherwise(col("lsb_id"))
    all_leads_mbi = all_leads_mbi.withColumn("lsb_id", cond_id)
    # edipartnerfk=92 merging into 82 as per business need
    cond = when( \
        ((trim(col("lsb_edipartnerfk")) == "92")) \
        , lit("82") \
        ) \
        .otherwise(col("lsb_edipartnerfk"))
    all_leads_mbi = all_leads_mbi.withColumn("lsb_edipartnerfk", cond)
    # fix for state beign longer from ICG
    cond_state = when( \
        ((length(trim(col("lsb_state"))) > 2)) \
        , lit("") \
        ) \
        .otherwise(col("lsb_state"))
    all_leads_mbi = all_leads_mbi.withColumn("lsb_state", cond_state)
    writeparquet(spark,all_leads_mbi,hdfs_scratch + "/all_leads_mbi",0,"overwrite")

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *

hdfs_input = hdfs_input_path 
hdfs_leads_input = hdfs_int_path
hdfs_admitdt_path = hdfs_minmaxdt_path_edipartnerfk
hdfs_output = hdfs_leads_output
hdfs_maprdb_input = hdfs_maprdb_lookup_path
hdfs_scratch = hdfs_scratch

# COMMAND ----------

create_temp_data(spark,hdfs_input,hdfs_scratch)
all_leads = extract_explode_leads(spark, hdfs_leads_input + "/*")

# COMMAND ----------

get_clean_mbi_lead_data(spark, all_leads,hdfs_scratch)
all_leads_mbi = readparquet(spark, hdfs_scratch + "/all_leads_mbi/", "0","na")

# COMMAND ----------

blcol = ["edipartnerfk", "coverageid"]
blacklist_accts = extract_parquet_data(spark, hdfs_input + "/partnerpolicyidblacklists/current/*", blcol)
all_leads_nbl = filter_blacklisted_partnerpolicyid(spark, all_leads_mbi, blacklist_accts, hdfs_input, hdfs_scratch)
writeparquet(spark,all_leads_nbl,hdfs_scratch + "/all_leads_nbl",0,"overwrite")
all_leads_nbl_tmp = readparquet(spark, hdfs_scratch + "/all_leads_nbl/", "0","na")

# COMMAND ----------

all_leads_len_admitdt = filter_coverageid_len_admitdt(spark, all_leads_nbl_tmp, hdfs_admitdt_path,hdfs_scratch)
writeparquet(spark, all_leads_len_admitdt ,hdfs_scratch + "/all_leads_len_admitdt",0,"overwrite")
all_leads_len_admitdt_tmp = readparquet(spark, hdfs_scratch + "/all_leads_len_admitdt/", "0","na")

# COMMAND ----------

all_leads_ct = get_medicare_edipartners(spark, all_leads_len_admitdt_tmp, hdfs_input)
writeparquet(spark, all_leads_ct,hdfs_scratch + "/all_leads_ct",0,"overwrite")
all_leads_ct_tmp = readparquet(spark, hdfs_scratch + "/all_leads_ct/", "0","na")

# COMMAND ----------

all_leads_hpn = filter_ifhpn_notenabled(spark, all_leads_ct_tmp, hdfs_input,hdfs_scratch)
writeparquet(spark, all_leads_hpn ,hdfs_scratch + "/all_leads_hpn",0,"overwrite")
all_leads_hpn_tmp = readparquet(spark, hdfs_scratch + "/all_leads_hpn/", "0","na")

# COMMAND ----------

all_leads_passmincharges = filter_mincharges_by_partner(spark, all_leads_hpn_tmp, hdfs_input,hdfs_scratch)
writeparquet(spark, all_leads_passmincharges ,hdfs_scratch + "/all_leads_passmincharges",0,"overwrite")
all_leads_passmincharges_tmp = readparquet(spark, hdfs_scratch + "/all_leads_passmincharges/", "0","na")

# COMMAND ----------

all_leads_fc = filter_ifexistsinfc(spark, all_leads_passmincharges_tmp, hdfs_input,hdfs_scratch)
writeparquet(spark, all_leads_fc ,hdfs_scratch + "/all_leads_fc",0,"overwrite")
all_leads_fc_tmp = readparquet(spark, hdfs_scratch + "/all_leads_fc/", "0","na")

# COMMAND ----------

all_leads_wallingoff = applywallingoff(spark, all_leads_fc_tmp, hdfs_input,hdfs_scratch)
writeparquet(spark, all_leads_wallingoff ,hdfs_scratch + "/all_leads_wallingoff",0,"overwrite")
all_leads_wallingoff_tmp = readparquet(spark, hdfs_scratch + "/all_leads_wallingoff/", "0","na")

# COMMAND ----------

all_leads_edidatasourcefk = add_edidatasourcefk(spark, all_leads_wallingoff_tmp, hdfs_maprdb_input,hdfs_scratch)
writeparquet(spark, all_leads_edidatasourcefk ,hdfs_scratch + "/all_leads_edidatasourcefk",0,"overwrite")
all_leads_edidatasourcefk_tmp = readparquet(spark, hdfs_scratch + "/all_leads_edidatasourcefk/", "0","na")

# COMMAND ----------

# modified funtion call to fetch npi and hospitalnames
all_leads_ohi_tmp = ohibatchprocess(spark, all_leads_edidatasourcefk_tmp, hdfs_input, hdfs_scratch)
final_leads = bestleadselection(spark,all_leads_ohi_tmp, bc,hdfs_scratch)
# final_leads = final_leads.withColumn('lsb_dob',((to_date(final_leads.lsb_dob)).cast('timestamp')).cast('string'))\
# .withColumn('dob',((to_date(final_leads.dob)).cast('timestamp')).cast('string'))\
# .withColumn('admitdate',((to_date(final_leads.admitdate)).cast('timestamp')).cast('string'))\
# .withColumn('dischargedate',((to_date(final_leads.dischargedate)).cast('timestamp')).cast('string'))
writeparquet(spark, final_leads, hdfs_output, 10, "overwrite")
final_leads.unpersist()
final_leads=spark.read.parquet(hdfs_output)
if (final_leads.isEmpty()):
    ret_val = 0
else:
    ret_val = 1

# COMMAND ----------

dbutils.notebook.exit(ret_val)
