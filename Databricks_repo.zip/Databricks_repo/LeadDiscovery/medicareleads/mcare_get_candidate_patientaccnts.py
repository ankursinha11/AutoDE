# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("hdfs_input_path","")
dbutils.widgets.getArgument("hdfs_input_path")
hdfs_input_path= getArgument("hdfs_input_path")

dbutils.widgets.text("hdfs_candidateaccts_path","")
dbutils.widgets.getArgument("hdfs_candidateaccts_path")
hdfs_candidateaccts_path= getArgument("hdfs_candidateaccts_path")

dbutils.widgets.text("hdfs_minmaxdt_path","")
dbutils.widgets.getArgument("hdfs_minmaxdt_path")
hdfs_minmaxdt_path= getArgument("hdfs_minmaxdt_path")

dbutils.widgets.text("pa_path","")
dbutils.widgets.getArgument("pa_path")
pa_path= getArgument("pa_path")

dbutils.widgets.text("gmrn_publish","")
dbutils.widgets.getArgument("gmrn_publish")
gmrn_publish= getArgument("gmrn_publish")

dbutils.widgets.text("cdd_publish","")
dbutils.widgets.getArgument("cdd_publish")
cdd_publish= getArgument("cdd_publish")

dbutils.widgets.text("hdfs_scratch","")
dbutils.widgets.getArgument("hdfs_scratch")
hdfs_scratch= getArgument("hdfs_scratch")

dbutils.widgets.text("lead_mode","")
dbutils.widgets.getArgument("lead_mode")
lead_mode= getArgument("lead_mode")

dbutils.widgets.text("module","")
dbutils.widgets.getArgument("module")
module= getArgument("module")

dbutils.widgets.text("num_of_days", "")
num_of_days = dbutils.widgets.get("num_of_days")


# COMMAND ----------

# bc="20240611T11-MC"
# container="prod-icd-stg-adls"
# hdfs_candidateaccts_path="/data/leaddiscovery/transform/scratch/medicareleads/candidatepa/"
# hdfs_input_path="/data/dataingestion/publish"
# hdfs_minmaxdt_path="/data/leaddiscovery/transform/scratch/medicareleads/minmaxbyhospital/"
# hdfs_scratch="/data/leaddiscovery/transform/scratch/medicareleads"
# storageaccount="prodicdstgdls"
# user="maxc"
# lead_mode="1"
# pa_path="/data/dataingestion/publish/patientaccts/current/20991231/"
# gmrn_publish="/data/gmrn/publish/"
# cdd_publish="/data/cdd/publish/"
# module="aid"

# COMMAND ----------

# DBTITLE 1,Set Base URL

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

#input paths
hdfs_input_path = baseurl + hdfs_input_path
pa_path = baseurl + pa_path
gmrn_publish = baseurl + gmrn_publish
cdd_publish = baseurl + cdd_publish

# hdfs_candidateaccts_path = baseurl + hdfs_candidateaccts_path + bc
# hdfs_minmaxdt_path = baseurl + hdfs_minmaxdt_path + bc
# hdfs_scratch = baseurl + hdfs_scratch

#output paths in if-else block
if module =='aid':
    hdfs_candidateaccts_path = baseurl + hdfs_candidateaccts_path + 'aid/' + bc + '/'
    hdfs_minmaxdt_path = baseurl + hdfs_minmaxdt_path + 'aid/' + bc + '/'
    hdfs_scratch = baseurl + hdfs_scratch + '/aid/' 
else :
    hdfs_candidateaccts_path = baseurl + hdfs_candidateaccts_path + bc + '/'
    hdfs_minmaxdt_path = baseurl + hdfs_minmaxdt_path + bc + '/'
    hdfs_scratch = baseurl + hdfs_scratch + '/' 

print("hdfs_input_path: ",hdfs_input_path)
print("hdfs_candidateaccts_path: ",hdfs_candidateaccts_path)
print("hdfs_minmaxdt_path: ",hdfs_minmaxdt_path)
print("hdfs_scratch: ",hdfs_scratch)

aid_bc=bc.split("-")[0]
print("aid_bc:",aid_bc)
aid_pa_path=baseurl+"/data/dataingestion/staging/input/patientaccts/"+aid_bc
aid_accounts=baseurl+"/data/dataingestion/publish/patientacctsaccesscoordinator/current/20991231/"
print("aid_pa_path:",aid_pa_path)
print("aid_accounts:",aid_accounts)
print("module:",module)

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/tu_data_quality

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

# MAGIC %run /Insleads-code/LeadDiscovery/common/get_candidate_patientaccts

# COMMAND ----------

#getting the correct paacct based on lead mode
def get_patientacct(spark, pa_path, lead_mode_flag, enddt, bc, hospadmitdate, vsnapflags):
    pacctscols = ["patientacctipk", "hospitalfk", "firstname", "middlename", "lastname", "ssn", "dob", "gender",
                "state", "admitdate", "referraldate", "dischargedate", "medicalrecnum", "clusteredacctfk", "totalcharges", "createdate", "updatedate",
                "demographicsupdatedate", "medicarehic", "medicaidnum", "trgupdatedate", "currentbalance", "dod"]

    allpatientaccts = extract_deltalake_data(spark, pa_path, pacctscols)
    allpatientaccts = allpatientaccts.withColumn('totalcharges', allpatientaccts.totalcharges.cast("decimal(32,4)"))
    allpatientaccts = allpatientaccts.withColumn('patientacctipk', allpatientaccts.patientacctipk.cast("long"))
    allpatientaccts = allpatientaccts.filter(allpatientaccts.totalcharges > 0)
    
    # apply admit date filters for patientaccts
    allpatientaccts = getpatientacctswithadmitdt(spark, allpatientaccts, hospadmitdate)
    if lead_mode_flag == '1':
        dup_cols = ("vsnapflags_hospitalfk", "patientacctipk", "vsnapflags_createdate")
        allpatientaccts = allpatientaccts.join(vsnapflags, (allpatientaccts.patientacctipk == vsnapflags.patientacctifk) & (allpatientaccts.hospitalfk == vsnapflags.vsnapflags_hospitalfk)) \
                                    .filter((allpatientaccts.trgupdatedate >= enddt) | (vsnapflags.vsnapflags_createdate >= enddt)) \
                                    .drop(*dup_cols)

    return allpatientaccts


# def get_patientacct_aid(spark, pa_path, aid_accounts_path, lead_mode_flag, enddt, bc, hospadmitdate, vsnapflags):
#     # SAMPLE_INPUT
#     # pa_path="abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/maxc/data/dataingestion/staging/input/patientaccts/20240611T11/"
#     # aid_accounts_path="abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/maxc/data/dataingestion/publish/patientacctsaccesscoordinator/current/20991231/"
#     pacctscols = ["patientacctipk","hospitalfk","firstname","middlename","lastname","ssn","dob","gender","state","admitdate","referraldate","dischargedate","medicalrecnum","clusteredacctfk","totalcharges","createdate","updatedate","demographicsupdatedate","medicarehic","medicaidnum","trgupdatedate","currentbalance", "dod"]
    
#     paccts = spark.read.parquet(pa_path).selectExpr(pacctscols)
#     paccts.createOrReplaceTempView("paccts")
#     patientacctsaccesscoordinator = spark.read.format("parquet").load(aid_accounts_path)
#     patientacctsaccesscoordinator = patientacctsaccesscoordinator.selectExpr(
#         "patientacctifk as patientacctipk", "hospitalfk"
#     ).dropDuplicates()
#     patientacctsaccesscoordinator.createOrReplaceTempView(
#         "patientacctsaccesscoordinator"
#     )
#     paccts = spark.sql(
#         """SELECT paccts.* FROM paccts INNER JOIN patientacctsaccesscoordinator ON 
#                      CAST(paccts.hospitalfk AS BIGINT)=CAST(patientacctsaccesscoordinator.hospitalfk AS BIGINT) 
#                      AND CAST(paccts.patientacctipk AS BIGINT)=CAST(patientacctsaccesscoordinator.patientacctipk AS BIGINT)
#                      """
#     )
#     print("INNER POST AC VS PA check : " + str(paccts.count()))
#     paccts = paccts.withColumn(
#         "totalcharges", paccts.totalcharges.cast("decimal(32,4)")
#     )
#     paccts = paccts.withColumn("patientacctipk", paccts.patientacctipk.cast("long"))
#     vsnapflags = vsnapflags.withColumn(
#         "patientacctifk", vsnapflags.patientacctifk.cast("long")
#     )
#     paccts = paccts.filter(paccts.totalcharges > 0)
#     print("INNER POST totalcharges check > 0 : " + str(paccts.count()))
#     paccts = getpatientacctswithadmitdt(spark, paccts, hospadmitdate)
#     print("INNER POST admitdate check  : " + str(paccts.count()))
#     if lead_mode_flag == "1":
#         dup_cols = ("vsnapflags_hospitalfk", "patientacctipk", "vsnapflags_createdate")
#         paccts = (
#             paccts.join(vsnapflags, paccts.patientacctipk == vsnapflags.patientacctifk)
#             .filter(
#                 (paccts.trgupdatedate.cast("date") >= enddt.cast("date"))
#                 | (vsnapflags.vsnapflags_createdate.cast("date") >= enddt.cast("date"))
#             )
#             .drop(*dup_cols)
#         )
#         print("INNER POST vsnapflags check  : " + str(paccts.count()))
#     return paccts

# COMMAND ----------

from pyspark.sql.functions import *


hdfs_input = hdfs_input_path
hdfs_output = hdfs_candidateaccts_path
hdfs_admitdatelookup = hdfs_minmaxdt_path
lead_mode_flag = lead_mode
admitdate = readparquet(spark, hdfs_admitdatelookup, '0', 'na') #cu

enddt = date_sub(current_date(), int(num_of_days))

vsnapcols = ["patientacctifk", "hospitalfk", "hasmedicareflag", "createdate"]
vsnapflags = extract_deltalake_data(spark, hdfs_input + "/vsnappatientacctsflags/current/20991231/", vsnapcols) #cu
vsnapflags = vsnapflags.join(admitdate, admitdate.hospitalfk == vsnapflags.hospitalfk).select(vsnapflags['*'])
vsnapflags = vsnapflags.withColumn('patientacctifk', vsnapflags.patientacctifk.cast("long"))
vsnapflags = vsnapflags.withColumnRenamed('createdate', 'vsnapflags_createdate')
vsnapflags = vsnapflags.withColumnRenamed('hospitalfk', 'vsnapflags_hospitalfk')



if module=="aid":
    # print("AID PATACCTS")
    # patientaccts = get_patientacct_aid(spark,aid_pa_path,aid_accounts, lead_mode_flag,enddt, bc, admitdate,vsnapflags)
    # print("patientaccts : "+str(patientaccts.count()))
    # NEW AID PATACCTS COMBINED START
    path_aidpatientaccts = baseurl + "/data/dataingestion/publish/aidpatientaccts/current/20991231/"
    path_patientacctsaccesscoordinator = baseurl + "/data/dataingestion/publish/patientacctsaccesscoordinator/current/20991231/"
    filterBc="bcupdated=='"+aid_bc+"'"
    aidpatientaccts = spark.read.format("delta").load(path_aidpatientaccts).filter(filterBc).selectExpr("patientacctifk as patientacctipk","hospitalfk").dropDuplicates()
    patientacctsaccesscoordinator = spark.read.format("parquet").load(path_patientacctsaccesscoordinator).selectExpr("patientacctifk as patientacctipk","hospitalfk").dropDuplicates()
    aidpatientaccts = aidpatientaccts.union(patientacctsaccesscoordinator)
    pacctscols = ["patientacctipk", "hospitalfk", "firstname", "middlename", "lastname", "ssn", "dob", "gender", "state", "admitdate", "referraldate", "dischargedate", "medicalrecnum", "clusteredacctfk", "totalcharges", "createdate", "updatedate", "demographicsupdatedate", "medicarehic", "medicaidnum", "trgupdatedate", "currentbalance", "dod"]
    patientaccts = get_patientacct_aid_combined(spark,aid_pa_path,pacctscols,aidpatientaccts, lead_mode_flag,enddt, bc, admitdate,vsnapflags)
    # NEW AID PATACCTS COMBINED END
else :
    print("NON AID PATACCTS")
    patientaccts = get_patientacct(spark, pa_path, lead_mode_flag, enddt, bc, admitdate,vsnapflags)
    # print("patientaccts : "+str(patientaccts.count()))

    # apply all filters together to get final candidate acct list
candidates = patientaccts.where((patientaccts.hasmedicareflag == 0 ) | (patientaccts.dod.isNotNull()))
writeparquet(spark, candidates, hdfs_scratch + "/tmpdata/pa_vsnapflags", 50, "overwrite") #cu
candidates = readparquet(spark, hdfs_scratch + "/tmpdata/pa_vsnapflags", '0', 'na') #cu

    # Get GMRN from globalmrnxpaccts and PermId from CDD
if module=="aid":
    ca = get_globalmrn_aid(spark, gmrn_publish, candidates, aid_bc)
    # print("ca : "+str(ca.count()))
else :
    ca = get_globalmrn(spark, gmrn_publish, candidates, bc)
    # print("ca : "+str(ca.count()))

ca = get_permid(spark, cdd_publish, ca) #cpa
ca = check_valid_identities(spark, ca)  #cpa 
writeparquet(spark, ca, hdfs_output, 10, "overwrite") #cu
