# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("hdfs_input","")
dbutils.widgets.getArgument("hdfs_input")
hdfs_input= getArgument("hdfs_input")

dbutils.widgets.text("hdfs_output","")
dbutils.widgets.getArgument("hdfs_output")
hdfs_output= getArgument("hdfs_output")

dbutils.widgets.text("hdfs_output_edipartnerfk","")
dbutils.widgets.getArgument("hdfs_output_edipartnerfk")
hdfs_output_edipartnerfk= getArgument("hdfs_output_edipartnerfk")

dbutils.widgets.text("module","")
dbutils.widgets.getArgument("module")
module= getArgument("module")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# DBTITLE 1,Set Base URL
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/' + user

# COMMAND ----------

# bc="20240925T16"
# container="prod-icd-stg-adls"
# hdfs_input="/data/dataingestion/publish"
# hdfs_output="/data/leaddiscovery/transform/scratch/medicareleads/minmaxbyhospital/"
# hdfs_output_edipartnerfk="/data/leaddiscovery/transform/scratch/medicareleads/minmaxbyedipartnerfk/"
# storageaccount="prodicdstgdls"
# user="divya"
# module="aid"

# COMMAND ----------

# DBTITLE 1,Setting up Input & Output Path
hdfs_input = baseurl + hdfs_input 

if module =='regular':
    hdfs_output_edipartnerfk = baseurl + hdfs_output_edipartnerfk + bc 
    hdfs_output = baseurl + hdfs_output + bc 
else :
    hdfs_output_edipartnerfk = baseurl + hdfs_output_edipartnerfk + 'aid/' + bc
    hdfs_output = baseurl + hdfs_output  + 'aid/' + bc

print("bc: " + str(bc))
print("container: " + str(container))
print("storageaccount: " + str(storageaccount))
print("user: " + str(user))
print("module: " + str(module))
print("hdfs_input: " + str(hdfs_input))
print("hdfs_output: " + str(hdfs_output))
print("hdfs_output_edipartnerfk: " + str(hdfs_output_edipartnerfk))

# COMMAND ----------

# MAGIC %run /Insleads-code/LeadDiscovery/common/createlookup_maxminadmitdays

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

hp = readparquet(spark, hdfs_input + "/hospitals/current/*/", '0', 'na')
hp = hp.filter(col("active") == '1')
hpn = readparquet(spark, hdfs_input + "/hospitalprovidernums/current/*/", '0', 'na')
hpn = hpn.filter(col("enabled") == '1')
edis = readparquet(spark, hdfs_input + "/edisubmitters/current/*/", '0', 'na')
ep = readparquet(spark, hdfs_input + "/edipartners/current/*/", '0', 'na')
epp = readparquet(spark, hdfs_input + "/edipartnertype/current/*/", '0', 'na')
epp = epp.filter(col("ismedicare") == '1') 
edienv = readparquet(spark, hdfs_input + "/edipartner270settings/current/*/", '0', 'na')
epso = readparquet(spark, hdfs_input + "/edipartnersubmittersoverrides/current/*/", '0', 'na')
ephsso = readparquet(spark, hdfs_input + "/edipartnerhospital270settingsoverrides/current/*/", '0', 'na')

b = createlookup(spark, hp, hpn, edis, ep, edienv, epso, ephsso,epp)
a = createlookupbypartnerfk(spark, hp, hpn, edis, ep, edienv, epso, ephsso,epp)

# using python util to write out
writeparquet(spark, b, hdfs_output,1, "overwrite")
writeparquet(spark, a, hdfs_output_edipartnerfk,1, "overwrite")
