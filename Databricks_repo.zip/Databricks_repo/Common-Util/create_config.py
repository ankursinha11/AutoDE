# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.types import LongType, StringType, StructField, StructType, BooleanType, ArrayType, IntegerType, TimestampType,FloatType
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.functions import rank, col, row_number, udf
import re
from pyspark import SparkConf, SparkContext, SparkFiles

# COMMAND ----------


def createColumn( schemafile,tablename,function) :
  columns=''
  for  line in open(schemafile):
    fieldNameType = line.split(',')
    if ( fieldNameType[0] == tablename):
        if(fieldNameType[-1].strip() == function):
          fieldNameType.pop(0)
          fieldNameType.pop(-1)
          columns = ','.join(fieldNameType)
  return columns


def createCondition(schemafile,tablename,rtblname,ltblname,function):
   cond = ''
   rightList=[]
   leftList=[]
   for line in open(schemafile):
     fieldNameType = line.split(',')
     if ( fieldNameType[0] == tablename and fieldNameType[-1].strip() == function):
       fieldNameType.pop(0)
       fieldNameType.pop(-1)
       for i in range(len(fieldNameType)):
          right_hand = rtblname + '.' + fieldNameType[i]
          left_hand = ltblname + '.' + fieldNameType[i]
          rightList.append((right_hand,left_hand))
   
   for j in range(len(rightList)):
      val = ' == '.join(rightList[j])   
      leftList.append(val)
   
   cond = ','.join(leftList)
   return cond

def createjoinColumn(schemafile,tablename,rtblname,function):
   cond = ''
   rightList=[]
   leftList=[]
   for line in open(schemafile):
     fieldNameType = line.split(',')
     if ( fieldNameType[0] == tablename and fieldNameType[-1].strip() == function):
       fieldNameType.pop(0)
       fieldNameType.pop(-1)
       for i in range(len(fieldNameType)):
          right_hand = rtblname + '.' + fieldNameType[i]
          rightList.append(right_hand)

   val = ','.join(rightList)
   return val
