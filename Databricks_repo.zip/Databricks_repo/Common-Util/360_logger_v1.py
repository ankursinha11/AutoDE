# Databricks notebook source
#dbutils.widgets.removeAll()
#help("keywords")

# COMMAND ----------

dbutils.widgets.text("wf_id", "es_postbdf")
dbutils.widgets.getArgument("wf_id")
wf_id = getArgument("wf_id")

dbutils.widgets.text("logdb", "operations_log_360")
dbutils.widgets.getArgument("logdb")
logdb = getArgument("logdb")

dbutils.widgets.text("project", "CDD")
dbutils.widgets.getArgument("project")
project = getArgument("project")

dbutils.widgets.text("module", "CDD PostBDF")
dbutils.widgets.getArgument("module")
module = getArgument("module")

dbutils.widgets.text("user_id", "some_spn_goes_here")
dbutils.widgets.getArgument("user_id")
user_id = getArgument("user_id")

dbutils.widgets.text("bcdata", "bcdata")
dbutils.widgets.getArgument("bcdata")
bcdata = getArgument("bcdata")

dbutils.widgets.text("mode1", "RUNNING")
dbutils.widgets.getArgument("mode1")
mode1 = getArgument("mode1")

print(mode1)

dbutils.widgets.text("runstatusid", "some_runstatusid_goes_ger")
dbutils.widgets.getArgument("runstatusid")
runstatusid = getArgument("runstatusid")

dbutils.widgets.text("cosmosendpoint", "https://prod-ent-icd-cosmos-test.documents.azure.com:443/")
dbutils.widgets.getArgument("cosmosendpoint")
cosmosendpoint = getArgument("cosmosendpoint")

dbutils.widgets.text("cosmosdb", "insleads")
dbutils.widgets.getArgument("cosmosdb")
cosmosdb= getArgument("cosmosdb")

# COMMAND ----------

import uuid
#cosmosEndpoint = "https://prod-icd-cosmos.documents.azure.com:443/"
cosmosMasterKey = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-cosmos-insleads-kvsecret")
#cosmosMasterKey = "BCNRDuwIaA07Va40r5AxB7m2O5ibws6Yk8s045lUKPIzHdH7Zck1KhQosJSnNbLQemEViToAlf28ACDbDLDSSg=="
#cosmosDatabaseName = "insleads"
#cosmosContainerName = maprdbtable

cfg = {
  "spark.cosmos.accountEndpoint" : cosmosendpoint,
  "spark.cosmos.accountKey" : cosmosMasterKey,
  "spark.cosmos.database" : cosmosdb,
  "spark.cosmos.container" : logdb,
}

# Configure Catalog Api to be used
spark.conf.set("spark.sql.catalog.cosmosCatalog", "com.azure.cosmos.spark.CosmosCatalog")
spark.conf.set("spark.sql.catalog.cosmosCatalog.spark.cosmos.accountEndpoint", cosmosendpoint)
spark.conf.set("spark.sql.catalog.cosmosCatalog.spark.cosmos.accountKey", cosmosMasterKey)
spark.conf.set("spark.sql.catalog.cosmosCatalog.spark.cosmos.views.repositoryPath", "/viewDefinitions" + str(uuid.uuid4()))

# create an Azure Cosmos DB database using catalog api
#spark.sql("CREATE DATABASE IF NOT EXISTS cosmosCatalog.{};".format(cosmosDatabaseName))

# create an Azure Cosmos DB container using catalog api
#spark.sql("CREATE TABLE IF NOT EXISTS cosmosCatalog.{}.{} using cosmos.oltp TBLPROPERTIES(partitionKeyPath = '/id', manualThroughput = '1100')".format(cosmosdb, logdb))

# COMMAND ----------

# DBTITLE 1,function to read and write from cosmosdb
def readfromcosmosdb(config):
    filterExpr1 = "id == '" + wf_id + "'"
    df = spark.read.format("cosmos.oltp").options(**cfg).option("spark.cosmos.read.inferSchema.enabled", "true").load()
    if 'id' in df.columns:
        df = df.filter(filterExpr1).limit(1)
    return df

def writetocosmosdb(df,config):
    df.write.format("cosmos.oltp").options(**cfg).mode("APPEND").save()
    return df

# COMMAND ----------

import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.conf import SparkConf
from pyspark import SparkContext
from pyspark.sql import SparkSession
import datetime
import datetime
from dateutil import relativedelta

spark = SparkSession.builder.appName('OOZIE_360').getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

wf_run_status = ""
start_time = ""
end_time = ""
duration = ""
status = ""

print(logdb)
print(mode1)
print(module)


if mode1 == 'RUNNING':
    status = "RUNNING"
    current_dt = datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    start_time = str(current_dt)
    end_time = ""
    wf_run_time = ""
    duration = ""
    #filterExpr1 = "_id == '" + wf_id + "'"
    #df = spark.loadFromMapRDB(logdb).filter(filterExpr1).limit(1)
    #df = spark.read.format("cosmos.oltp").options(**cfg).option("spark.cosmos.read.inferSchema.enabled", "true").load().filter(filterExpr1).limit(1)
    df = readfromcosmosdb(cfg)

    #display(df)
    #print("hello 1")

    #if not df.isEmpty(): 
    #    df.filter(col("ID") == wf_id)\
    #    .show()
    
    if not 'runstatusid' in df.columns:
        cflag = '0'
    else:
        cflag = '1'
    if len(df.head(1)) == 0:
        rerun = 0
    else:
        df_row = df.collect()[0]
        project = df_row["project"]
        module = df_row["module"]
        bcdata = df_row["bcdata"]
        user_id = df_row["user_id"]
        rerun = df_row["rerun"]
        rerun = int(rerun) + 1
        if cflag == '1':
            print("COL PRESENT")
            runstatusid = str(df_row["runstatusid"])
        else:
            runstatusid = '0'

elif mode1 == 'FAILED':
    status = "FAILED"
    #filterExpr1 = "_id == '" + wf_id + "'"
    #start_time = str(spark.loadFromMapRDB(logdb).filter(filterExpr1).selectExpr("start_time").limit(1).collect()[0]["start_time"])
    #start_time = str(readfromcosmosdb(cfg).collect()[0]["start_time"])
    start_time = readfromcosmosdb(cfg)
    if start_time.count() > 0:
        start_time = str(readfromcosmosdb(cfg).collect()[0]["start_time"])
        rerun = int(readfromcosmosdb(cfg).collect()[0]["rerun"])
        #print(start_time)
    else:
        filterExpr1 = "bcdata == '" + bcdata + "' and module == '" + module + "' and runstatusid == '" + runstatusid +"'"
        start_time = str(spark.read.format("cosmos.oltp").options(**cfg).option("spark.cosmos.read.inferSchema.enabled", "true").load().filter(filterExpr1).limit(1).collect()[0]["start_time"])
        rerun = str(spark.read.format("cosmos.oltp").options(**cfg).option("spark.cosmos.read.inferSchema.enabled", "true").load().filter(filterExpr1).count())
        #print(rerun)
        #print(start_time)
    current_dt = datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    end_time = str(current_dt)
    date_time_start_obj = datetime.datetime.strptime(start_time, '%Y-%m-%d %H:%M:%S.%f')
    date_time_end_obj = datetime.datetime.strptime(end_time, '%Y-%m-%d %H:%M:%S.%f')
    duration = str((date_time_end_obj - date_time_start_obj).total_seconds() / 60.0)
    #rerun = int(spark.loadFromMapRDB(logdb).filter(filterExpr1).selectExpr("rerun").limit(1).collect()[0]["rerun"])
    #rerun = int(readfromcosmosdb(cfg).collect()[0]["rerun"])

elif mode1 == 'FINISHED':
    #status = "FINISHED"
    #filterExpr1 = "id == '" + wf_id + "'"
    #rdf = spark.read.format("cosmos.oltp").options(**cfg).option("spark.cosmos.read.inferSchema.enabled", "true").load()
    #frdf = rdf.filter(col("id") == wf_id).withColumn("start_time",col("start_time"))
    #start_time = str(frdf.select("start_time").show())
    #start_time = str(spark.loadFromMapRDB(logdb).filter(filterExpr1).selectExpr("start_time").limit(1).collect()[0]["start_time"])
    #current_dt = datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    #end_time = str(current_dt)
    #date_time_start_obj = datetime.datetime.strptime(start_time, '%Y-%m-%d %H:%M:%S.%f')
    #date_time_end_obj = datetime.datetime.strptime(end_time, '%Y-%m-%d %H:%M:%S.%f')
    #duration = str((date_time_end_obj - date_time_start_obj).total_seconds() / 60.0)
    #rerun = int(spark.loadFromMapRDB(logdb).filter(filterExpr1).selectExpr("rerun").limit(1).collect()[0]["rerun"])

    status = "FINISHED"
    #start_time = str(readfromcosmosdb(cfg).collect()[0]["start_time"])
    start_time = readfromcosmosdb(cfg)
    if start_time.count() > 0:
        start_time = str(readfromcosmosdb(cfg).collect()[0]["start_time"])
        rerun = int(readfromcosmosdb(cfg).collect()[0]["rerun"])
        #print(start_time)
    else:
        filterExpr1 = "bcdata == '" + bcdata + "' and module == '" + module + "' and runstatusid == '" + runstatusid +"'"
        start_time = str(spark.read.format("cosmos.oltp").options(**cfg).option("spark.cosmos.read.inferSchema.enabled", "true").load().filter(filterExpr1).limit(1).collect()[0]["start_time"])
        rerun = str(spark.read.format("cosmos.oltp").options(**cfg).option("spark.cosmos.read.inferSchema.enabled", "true").load().filter(filterExpr1).count())
        #print(rerun)
        #print(start_time)
    current_dt = datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    end_time = str(current_dt)
    date_time_start_obj = datetime.datetime.strptime(start_time, '%Y-%m-%d %H:%M:%S.%f')
    date_time_end_obj = datetime.datetime.strptime(end_time, '%Y-%m-%d %H:%M:%S.%f')
    duration = str((date_time_end_obj - date_time_start_obj).total_seconds() / 60.0)
    #rerun = int(readfromcosmosdb(cfg).collect()[0]["rerun"])

elif mode1 == 'ERROR':
    status = "ERROR"
    #filterExpr1 = "_id == '" + wf_id + "'"
    #start_time = str(spark.loadFromMapRDB(logdb).filter(filterExpr1).selectExpr("start_time").limit(1).collect()[0]["start_time"])
    #start_time = str(readfromcosmosdb(cfg).collect()[0]["start_time"])
    start_time = readfromcosmosdb(cfg)
    if start_time.count() > 0:
        start_time = str(readfromcosmosdb(cfg).collect()[0]["start_time"])
        rerun = int(readfromcosmosdb(cfg).collect()[0]["rerun"])
        #print(start_time)
    else:
        filterExpr1 = "bcdata == '" + bcdata + "' and module == '" + module + "' and runstatusid == '" + runstatusid +"'"
        start_time = str(spark.read.format("cosmos.oltp").options(**cfg).option("spark.cosmos.read.inferSchema.enabled", "true").load().filter(filterExpr1).limit(1).collect()[0]["start_time"])
        rerun = str(spark.read.format("cosmos.oltp").options(**cfg).option("spark.cosmos.read.inferSchema.enabled", "true").load().filter(filterExpr1).count())
        #print(rerun)
        #print(start_time)
    current_dt = datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    end_time = str(current_dt)
    date_time_start_obj = datetime.datetime.strptime(start_time, '%Y-%m-%d %H:%M:%S.%f')
    date_time_end_obj = datetime.datetime.strptime(end_time, '%Y-%m-%d %H:%M:%S.%f')
    duration = str((date_time_end_obj - date_time_start_obj).total_seconds() / 60.0)
    #rerun = int(spark.loadFromMapRDB(logdb).filter(filterExpr1).selectExpr("rerun").limit(1).collect()[0]["rerun"])
    #rerun = int(readfromcosmosdb(cfg).collect()[0]["rerun"])

else:
    print("hello incorrect mode value")
    #exit(0)

log_data = []
log_data.append(wf_id)
log_data.append(user_id)
log_data.append(project)
log_data.append(module)
log_data.append(bcdata)
log_data.append(start_time)
log_data.append(end_time)
log_data.append(duration)
log_data.append(status)
log_data.append(rerun)
log_data.append(runstatusid)
log_data_tuple = tuple(log_data)
print(log_data_tuple)
df_data = []
df_data.append(log_data_tuple)

if module == 'module':
    exit(0)
else:
    df = spark.createDataFrame(df_data, ['id', 'user_id', 'project', 'module', 'bcdata', 'start_time', 'end_time', 'duration', 'status', 'rerun', 'runstatusid'])
    #display(df)
    writetocosmosdb(df,cfg)
    #spark.saveToMapRDB(df, logdb, id_field_path="wf_id", create_table=False)