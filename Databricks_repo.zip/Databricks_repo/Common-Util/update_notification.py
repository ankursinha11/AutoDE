# Databricks notebook source
# MAGIC %run ./cosmos_util

# COMMAND ----------

# Supriya Robertson
# May 5th, 2020
# This script logs a notification to MARDB, It also allows you to update the previously logged notification as processed

import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
import datetime 

# COMMAND ----------

dbutils.widgets.text("maprdbtable", "runstatus")
maprdbtable = dbutils.widgets.getArgument("maprdbtable")
print(maprdbtable)

dbutils.widgets.text("cosmosendpoint", "https://prod-ent-icd-cosmos-test.documents.azure.com:443/")
dbutils.widgets.getArgument("cosmosendpoint")
cosmosendpoint = getArgument("cosmosendpoint")
print(cosmosendpoint)

dbutils.widgets.text("cosmosdb", "insleads")
dbutils.widgets.getArgument("cosmosdb")
cosmosdb= getArgument("cosmosdb")
print(cosmosdb)

dbutils.widgets.text("id","")
id = dbutils.widgets.getArgument("id")
print(id)

dbutils.widgets.text("processed","")
processed = dbutils.widgets.getArgument("processed")
print(processed)

# COMMAND ----------

if not processed:
    print("processed parameter is empty")

# COMMAND ----------

config = cosmosconfig(cosmosendpoint, cosmosdb, maprdbtable)

# COMMAND ----------

def update_data(id):
  """Writing notification to log table"""
  current_dt=datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]

  #id = notificationtype+"_"+bc
  df = readfromcosmosdb(config).where("id='"+id+"'")
  df = df.withColumn("processedon",lit(current_dt))
  if processed:
    df = df.withColumn("processed",lit(processed))
  writetocosmosdb(df,config)
  #display(readfromcosmosdb(config).where("id='"+id+"'"))
  return None

# COMMAND ----------

update_data(id)