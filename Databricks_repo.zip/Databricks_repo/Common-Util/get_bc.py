# Databricks notebook source
dbutils.widgets.text("bcformat","")
dbutils.widgets.getArgument("bcformat")
bcformat= getArgument("bcformat")

# COMMAND ----------

from datetime import datetime
import pytz

#my_datetime = datetime.utcnow()
my_datetime = datetime.now(pytz.timezone('US/Central'))
if bcformat == 'YMDTH':
    my_datetime_cst = my_datetime.astimezone(pytz.timezone('US/Central')).strftime('%Y%m%dT%H') #20231019T15
elif bcformat == 'YMDHMS':
    my_datetime_cst = my_datetime.astimezone(pytz.timezone('US/Central')).strftime('%Y%m%d%H%M%S') #20231019155954
elif bcformat == 'YMDT-H':
   my_datetime_cst = my_datetime.astimezone(pytz.timezone('US/Central')).strftime("%d%b%Y-%H").upper() #19OCT2023-16
else:
    my_datetime_cst = my_datetime.astimezone(pytz.timezone('US/Central')).strftime('%Y%m%dT%H') #20231019T16

print(my_datetime_cst)

dbutils.notebook.exit(my_datetime_cst)
