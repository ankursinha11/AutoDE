# Databricks notebook source
# DBTITLE 1,Imports
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# DBTITLE 1,Gets all the shard db server connection strings by hospital fk
def get_shard_db_connection_string(catalog_name, dataingestion_path, feature_name = "eScan", scope_name = "Hospital"):

    shard_db_connection_template = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-dbx-shard-db-connection-template")
    dataingestion_publish_schema = "dataingestion"
    nexus_config_table_name = f"{catalog_name}.{dataingestion_publish_schema}.nexusconfig"
    nexus_features_table_name = f"{catalog_name}.{dataingestion_publish_schema}.nexusfeatures"
    nexus_servers_table_name = f"{catalog_name}.{dataingestion_publish_schema}.nexusservers"
    nexus_scope_table_name = f"{catalog_name}.{dataingestion_publish_schema}.nexusscope"
    hospitals_table_path = f"{dataingestion_path}/hospitals/current/*"

    nexus_config_df = spark.read.table(nexus_config_table_name)
    nexus_features_df = spark.read.table(nexus_features_table_name)
    nexus_servers_df = spark.read.table(nexus_servers_table_name)
    nexus_scope_df = spark.read.table(nexus_scope_table_name)
    hospitals_df = spark.read.parquet(hospitals_table_path)

    # Get FeatureID
    feature_df = nexus_features_df.filter(
        (col("FeatureName") == feature_name) &
        (col("EnableFlag") == 1)
    ).select("FeatureID")

    if feature_df.count() == 0:
        raise ValueError(f"Feature '{feature_name}' not found or not enabled")

    feature_id = feature_df.collect()[0]["FeatureID"]

    # Get ScopeID
    scope_df = nexus_scope_df.filter(
        (col("ScopeName") == scope_name) &
        (col("EnableFlag") == 1)
    ).select("ScopeId")

    if scope_df.count() == 0:
        raise ValueError(f"Scope '{scope_name}' not found or not enabled")

    scope_id = scope_df.collect()[0]["ScopeId"]

    # Build Config DataFrame (equivalent to #Config temp table)
    config_df = nexus_config_df.alias("c") \
        .join(nexus_features_df.alias("f"),
                (col("c.FeatureID") == col("f.FeatureID")) &
                (coalesce(col("f.EnableFlag"), lit(0)) == 1)) \
        .join(nexus_servers_df.alias("db"),
                (col("c.ServerID") == col("db.ServerID")) &
                (coalesce(col("db.EnableFlag"), lit(0)) == 1)) \
        .join(nexus_scope_df.alias("s"),
                (col("c.ScopeId") == col("s.ScopeId")) &
                (coalesce(col("s.EnableFlag"), lit(0)) == 1)) \
        .filter(
            (col("c.FeatureID") == feature_id) &
            (coalesce(col("c.EnableFlag"), lit(0)) == 1)
        ) \
        .filter(
            when(((col("c.ScopeId") == 1) |
                                (coalesce(lit(scope_id), col("c.ScopeId")) == col("c.ScopeId"))), lit(1))
            .when((col("c.ScopeId") == 1) | (col("c.ScopeId") == scope_id), lit(1))
            .otherwise(lit(0)) == 1
        ) \
        .select(
            col("db.ConnectionString"),
            col("c.ScopeValue")
        )

    # Connection String is the DB server name here. It doesnt have any credentials in the string.
    # Scope Value is the HospitalFK
    # Get hospital shard count
    hospital_shard_count = config_df.count()

    # Get scope values that are not null from config
    config_scope_values_df = config_df.filter(col("ScopeValue").isNotNull()) \
        .select("ScopeValue").distinct()

    active_hospitals_df = hospitals_df.filter(col("Active") == 1) \
        .join(config_scope_values_df,
                hospitals_df["hospitalpk"] == config_scope_values_df["ScopeValue"],
                "left_anti")

    # Build final result with UNION logic
    if hospital_shard_count > 1:
        # Getting server name for each configured hospital 
        server_name_df = config_df.filter(col("ScopeValue").isNotNull()) \
            .select(
                col("ScopeValue").alias("HospitalFK"),
                col("ConnectionString")
            ).distinct()

        # Getting default server name for hospitals not configured
        default_server_name_df = active_hospitals_df.alias("a") \
            .join(config_df.alias("b"),
                    col("a.hospitalpk") == coalesce(col("b.ScopeValue"), col("a.hospitalpk")),
                    "left") \
            .select(
                col("a.hospitalpk"),
                col("b.ConnectionString")
            ).distinct()

        # Combine both parts
        final_result = server_name_df.union(default_server_name_df).distinct()
    else:
        # If hospital_shard_count <= 1, return empty DataFrame with proper schema
        final_result = spark.createDataFrame([],
            StructType([
                StructField("HospitalFK", StringType(), True),
                StructField("ConnectionString", StringType(), True)
            ])
        )

    # Group by ConnectionString and collect unique HospitalFKs
    # Replace {shard_db_server_name} placeholder in shard_db_connection_template with ConnectionString 
    connection_string_df = final_result.groupBy("ConnectionString") \
        .agg(collect_set("HospitalFK").alias("HospitalFKList")) \
        .withColumn("ServerName", col("ConnectionString")) \
        .withColumn("ConnectionString", regexp_replace(lit(shard_db_connection_template), r"\{shard_db_server_name\}", col("ConnectionString"))) \
        .withColumn("ConnectionString", regexp_replace(col("ConnectionString"), r"\\", r"\\\\"))

    return connection_string_df

