# Databricks notebook source
dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("accountkey","")
dbutils.widgets.getArgument("accountkey")
accountkey= getArgument("accountkey")

dbutils.widgets.text("bc","")
bc = dbutils.widgets.getArgument("bc")
print(bc)

dbutils.widgets.text("notificationtype","")
notificationtype = dbutils.widgets.getArgument("notificationtype")
print(notificationtype)

dbutils.widgets.text("maprdbtable", "")
maprdbtable = dbutils.widgets.getArgument("maprdbtable")
print(maprdbtable)

dbutils.widgets.text("cosmosendpoint", "")
dbutils.widgets.getArgument("cosmosendpoint")
cosmosendpoint = getArgument("cosmosendpoint")
print(cosmosendpoint)

dbutils.widgets.text("cosmosdb", "")
dbutils.widgets.getArgument("cosmosdb")
cosmosdb= getArgument("cosmosdb")
print(cosmosdb)

dbutils.widgets.text("user", "")
dbutils.widgets.getArgument("user")
user= getArgument("user")
print(user)

dbutils.widgets.text("workflowtype", "")
dbutils.widgets.getArgument("workflowtype")
workflowtype= getArgument("workflowtype")
print(workflowtype)

# COMMAND ----------

# SAMPLE

# notificationtype = "globalmrn_assign_medicare"
# bc = "20250508T13-MC"
# container = "prod-icd-stg-adls"
# cosmosdb = "insleads"
# cosmosendpoint = "https://prod-icd-stg-cosmos.documents.azure.com:443/"
# maprdbtable = "runstatus"
# storageaccount = "prodicdstgdls"
# user = "maxc"
# workflowtype = "aid"

# notificationtype = "globalmrn_assign_medicaid"
# bc = "20250508T13-MA"
# container = "prod-icd-stg-adls"
# cosmosdb = "insleads"
# cosmosendpoint = "https://prod-icd-stg-cosmos.documents.azure.com:443/"
# maprdbtable = "runstatus"
# storageaccount = "prodicdstgdls"
# user = "maxc"
# workflowtype = "aid"

# notificationtype = "globalmrn_assign"
# bc = "20250508T13"
# container = "prod-icd-stg-adls"
# cosmosdb = "insleads"
# cosmosendpoint = "https://prod-icd-stg-cosmos.documents.azure.com:443/"
# maprdbtable = "runstatus"
# storageaccount = "prodicdstgdls"
# user = "maxc"
# workflowtype = "aid"

# COMMAND ----------

workflowtype = str(workflowtype).lower().strip()
if workflowtype is None or workflowtype == '':
    workflowtype = 'regular'
    print("workflowtype is not set, setting to regular")
else:
    print("workflowtype is set to " + workflowtype)

from pyspark.sql.functions import col

# COMMAND ----------

# MAGIC %run ./cosmos_util

# COMMAND ----------

account = f"fs.azure.account.key.{storageaccount}.dfs.core.windows.net"

# COMMAND ----------

spark.conf.set(account,dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

config = cosmosconfig(cosmosendpoint, cosmosdb, maprdbtable)
if workflowtype == 'aid':
    df = readfromcosmosdb(config).filter(col("workflowtype") == "aid")
else:
  df = readfromcosmosdb(config)
idcol = notificationtype + "_" + bc
filterExpr1 = "id == '" + idcol + "'"
df = df.filter(filterExpr1)
# df.display()
df = df.limit(1).select(df.msglocation).collect()
msglocation = df[0][0]
print("msglocation is " + msglocation)

# COMMAND ----------

#import datetime
#strdatetime = datetime.datetime.today().strftime('%Y%m%d%H%M%S')
filename = f"{notificationtype}_{bc}.txt"
print("filename is " + filename)

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+msglocation+'/'+filename
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user+'/'+msglocation+'/'+filename

print("filelocation : " + baseurl)

# COMMAND ----------

dbutils.fs.put(baseurl, idcol, True)

# COMMAND ----------


