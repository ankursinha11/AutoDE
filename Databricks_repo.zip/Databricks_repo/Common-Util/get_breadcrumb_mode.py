# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
import datetime
import getpass
import os
import sys
import subprocess

cosmosmasterkey = dbutils.secrets.get(scope="icd-insleads-dbwscope", key="icd-cosmos-insleads-kvsecret")

def readFromCosmos(cosmosendpoint, cosmosmasterkey, cosmosdb, cosmoscontainer):
    read_conf = {
        "spark.cosmos.accountEndpoint": cosmosendpoint,
        "spark.cosmos.accountKey": cosmosmasterkey,
        "spark.cosmos.database": cosmosdb,
        "spark.cosmos.container": cosmoscontainer,
    }
    df_read = (
        spark.read.format("cosmos.oltp")
        .options(**read_conf)
        .option("spark.cosmos.read.inferSchema.enabled", "true")
        .load()
    )
    return df_read

# COMMAND ----------

dbutils.widgets.text("notificationtype", "")
notificationtype = dbutils.widgets.get("notificationtype")

dbutils.widgets.text("maprdbtable", "")
maprdbtable = dbutils.widgets.get("maprdbtable")

dbutils.widgets.text("cosmosendpoint", "")
cosmosendpoint = dbutils.widgets.get("cosmosendpoint")

dbutils.widgets.text("cosmosdb", "")
cosmosdb = dbutils.widgets.get("cosmosdb")

dbutils.widgets.text("workflowtype", "")
workflowtype = dbutils.widgets.get("workflowtype")

# COMMAND ----------

# SAMPLE INPUTS
# cosmosdb = "insleads"
# cosmosendpoint = "https://prod-icd-stg-cosmos.documents.azure.com:443/"
# maprdbtable = "runstatus"
# notificationtype = "globalmrn_assign"
# workflowtype = "aid"

# SAMPLE INPUTS
# cosmosdb = "insleads"
# cosmosendpoint = "https://prod-icd-stg-cosmos.documents.azure.com:443/"
# maprdbtable = "runstatus"
# notificationtype = "globalmrn_assign"
# workflowtype = "regular"

# COMMAND ----------

cosmoscontainer = maprdbtable
print(
    "cosmosendpoint : "
    + cosmosendpoint
    + " cosmosdb : "
    + cosmosdb
    + " cosmoscontainer : "
    + cosmoscontainer
    + " workflowtype : "
    + workflowtype
    + " notificationtype : "
    + notificationtype
)

filter_notificationtype = "notificationtype == '" + notificationtype +"'"
filter_workflowtype     = "workflowtype == '" + workflowtype +"'"
filter_processed        = "processed !='processed'"

print("filter_notificationtype : "+filter_notificationtype)
print("filter_workflowtype     : "+filter_workflowtype)
print("filter_processed        : "+filter_processed)

# COMMAND ----------

df = readFromCosmos(cosmosendpoint, cosmosmasterkey, cosmosdb, cosmoscontainer)
df = df.filter(filter_workflowtype)
df = df.filter(filter_notificationtype)
df = df.filter(filter_processed)
df = df.orderBy(df.createdon.asc())
df.show(10,False)

# COMMAND ----------

df = df.selectExpr("bc", "workflowtype")
df = df.limit(1).collect()
bc = df[0][0]
wt = df[0][1]

if wt == None:
    wt = "regular"
else:
    wt = wt

print(bc)
print(wt)

# COMMAND ----------

dbutils.notebook.exit({"bc":bc,"wt":wt})
