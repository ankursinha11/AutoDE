# Databricks notebook source
dbutils.widgets.text("cosmosEndpoint", "")
dbutils.widgets.getArgument("cosmosEndpoint")
cosmosEndpoint = getArgument("cosmosEndpoint")
print(cosmosEndpoint)

dbutils.widgets.text("cosmosDatabaseName", "")
dbutils.widgets.getArgument("cosmosDatabaseName")
cosmosDatabaseName= getArgument("cosmosDatabaseName")
print(cosmosDatabaseName)

dbutils.widgets.text("cosmosContainerName", "")
dbutils.widgets.getArgument("cosmosContainerName")
cosmosContainerName = getArgument("cosmosContainerName")
print(cosmosContainerName)

dbutils.widgets.text("notificationtype", "")
dbutils.widgets.getArgument("notificationtype")
notificationtype= getArgument("notificationtype")
print(notificationtype)


dbutils.widgets.text("storageaccount", "")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")
print(storageaccount)


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))
cosmosMasterKey = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-cosmos-insleads-kvsecret")

# COMMAND ----------

print("cosmosEndpoint :" + str(cosmosEndpoint))
print("cosmosMasterKey :" + str(cosmosMasterKey))
print("cosmosDatabaseName :" + str(cosmosDatabaseName))
print("cosmosContainerName :" + str(cosmosContainerName))

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/cosmos_util"

# COMMAND ----------

def generateFilterExp(lis):
    temp_str = ""

    for i in lis:
        if(len(temp_str) == 0):
            temp_str = "notificationtype == '" + i +"' " 
        else:
            temp_str = temp_str +"or notificationtype == '" + i +"' "

    return temp_str

# COMMAND ----------

if(',' in notificationtype):
    lis = notificationtype.split(',')
    Filter_Exp = generateFilterExp(lis)
    Filter_Exp = "(" + Filter_Exp + ")" + " and processed != 'processed'"
else:
    Filter_Exp = "notificationtype == '" + notificationtype + "' and processed != 'processed'"

# COMMAND ----------

print(Filter_Exp)

# COMMAND ----------

cosmosContainerName="runstatus"
cosmosDatabaseName="insleads"
cosmosEndpoint="https://prod-icd-cosmos.documents.azure.com:443/"
print("cosmosEndpoint :" + str(cosmosEndpoint))
print("cosmosMasterKey :" + str(cosmosMasterKey))
print("cosmosDatabaseName :" + str(cosmosDatabaseName))
print("cosmosContainerName :" + str(cosmosContainerName))

# COMMAND ----------

def readFromCosmos(Endpoint,MasterKey,DatabaseName,ContainerName):
    readConf = {
    "spark.cosmos.accountEndpoint" : Endpoint,
    "spark.cosmos.accountKey" : MasterKey,
    "spark.cosmos.database" : DatabaseName,
    "spark.cosmos.container" : ContainerName
}
    df_read = spark.read.format("cosmos.oltp").options(**readConf).option("spark.cosmos.read.inferSchema.enabled", "true").load()
    return df_read

# COMMAND ----------

df_read_run_status = readFromCosmos(cosmosEndpoint,cosmosMasterKey,cosmosDatabaseName,cosmosContainerName)
df_read_run_status=df_read_run_status.filter(Filter_Exp)
df_read_run_status = df_read_run_status.orderBy(df_read_run_status.createdon.asc())

# COMMAND ----------

#df_read_run_status.show(10,False)

# COMMAND ----------

df_read_run_status=df_read_run_status.selectExpr("bc","notificationtype").limit(1).collect()


# COMMAND ----------

bc = df_read_run_status[0][0]
print("bc : " + str(bc))
notificationtype = df_read_run_status[0][1]
print("notificationtype : " + str(notificationtype))

# COMMAND ----------

dbutils.notebook.exit(bc)
dbutils.notebook.exit(notificationtype)

# COMMAND ----------




# config = cosmosconfig(cosmosendpoint, cosmosdb, maprdbtable)
# df = readfromcosmosdb(config)
# # filterExpr1 = "notificationtype == 'ie_xref_lsb_propagation' or notificationtype == 'es_xref_lsb_propagation' or notificationtype == 'globalmrnmerge_xref_lsb_propagation' or notificationtype == 'fc_xref_lsb_propagation' or notificationtype =='chc_xref_lsb_propagation'  and processed != 'processed'"
# df = df.filter(Filter_Exp)
# df = df.orderBy(df.createdon.asc())
# df = df.select(df.bc)
# df = df.limit(1).collect()
# bc = df[0][0]
# #print(bc)
# dbutils.notebook.exit(bc)