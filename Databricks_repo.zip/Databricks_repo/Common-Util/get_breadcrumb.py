# Databricks notebook source
dbutils.widgets.text("notificationtype","")
notificationtype = dbutils.widgets.getArgument("notificationtype")
print(notificationtype)

dbutils.widgets.text("maprdbtable", "")
maprdbtable = dbutils.widgets.getArgument("maprdbtable")
print(maprdbtable)

dbutils.widgets.text("cosmosendpoint", "")
dbutils.widgets.getArgument("cosmosendpoint")
cosmosendpoint = getArgument("cosmosendpoint")
print(cosmosendpoint)

dbutils.widgets.text("cosmosdb", "")
dbutils.widgets.getArgument("cosmosdb")
cosmosdb= getArgument("cosmosdb")
print(cosmosdb)

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/cosmos_util"

# COMMAND ----------

config = cosmosconfig(cosmosendpoint, cosmosdb, maprdbtable)
df = readfromcosmosdb(config)
filterExpr1 = "notificationtype == '" + notificationtype + "' and processed != 'processed'"
df = df.filter(filterExpr1)
df = df.orderBy(df.createdon.asc())
df = df.select(df.bc)
df = df.limit(1).collect()
bc = df[0][0]
#print(bc)
dbutils.notebook.exit(bc)