# Databricks notebook source
dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("filename","")
dbutils.widgets.getArgument("filename")
filename= getArgument("filename")

dbutils.widgets.text("folderpath","")
dbutils.widgets.getArgument("folderpath")
folderpath= getArgument("folderpath")

# COMMAND ----------

print(filename)
print(folderpath)
folderpath=folderpath.replace(container, '')
print(folderpath)

# COMMAND ----------

account = f"fs.azure.account.key.{storageaccount}.dfs.core.windows.net"
baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+folderpath+'/'+filename

# COMMAND ----------

spark.conf.set(account,dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

print(baseurl)

# COMMAND ----------

dbutils.fs.rm(baseurl)

# COMMAND ----------

# if dbutils.fs.ls(baseurl):
#     dbutils.fs.rm(baseurl)
