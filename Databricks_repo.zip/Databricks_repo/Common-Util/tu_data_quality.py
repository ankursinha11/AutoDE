# Databricks notebook source
# MAGIC %md 
# MAGIC tu data quality 

# COMMAND ----------

import sys
from pyspark.sql.types import *
from pyspark.sql import SparkSession
import datetime
from dateutil.relativedelta import relativedelta
from dateutil.parser import parse
import pyspark.sql.functions as f
import re
import itertools

# COMMAND ----------

# MAGIC %md 
# MAGIC invalid name components

# COMMAND ----------

InvalidNameList = ['EMPLOYEE','PRIVATE','FNU','UNKNOWN','TRAUMA','RESEARCH','SORE','UNPOSTED','PATIENT','TEST','Zztrashcan','Mpi','HEALTH']
InvalidNameContains = ['ZZZ','BABY','GIRL','BBOY','UNIDENTIFIED']
InvalidStartsWithName = ['BG','BB','B-','NBM','NBF','BOY','MALE','FEMALE']
InvalidEndsWithName = ['BG','BB','NBM','NBF','BOY','MALE','FEMALE']

# COMMAND ----------

# MAGIC %md
# MAGIC Invalid SSN components

# COMMAND ----------

InvalidStartsWithSSN = ['9','666','000']
InvalidSSNListAdvertisements = ['002281852','128036045','165207999','212099999','042103580','135016629',
                                '165227999','306302348','062360749','141186941','165247999','308125070',
                                '078051120','165167999','189092294','468288779','095073645','165187999',
                                '212097694','549241889']
InvalidSSNContainsList = ['12345678','111111','2222222','3333333','4444444','5555555','6666666','7777777',
                          '8888888','999999','0000000']
InvalidSSNList = ['987654321','100101000','111223333','010101010','121212121','777889999','100101000','111999999',
                  '012345678','111223333','010101010','009111111','121212121','888999999','777889999','123123123',
                  '123999999','123121234','090909090','111121212','001010001','111223344','049999904','101010101',
                  '111551114','121121212','123456780','111221111','111223456','449989555','059700970','060507537',
                  '499888888','123456788']

# COMMAND ----------

InvalidMRN = ['000000', '111111', '999999', 'not', 'ignore','000000000']
InvalidCA = ['000000']

# COMMAND ----------

# MAGIC %md
# MAGIC String Functions

# COMMAND ----------

def isValidString(str):
    if not str or not str.strip():
        return 0
    else:
        return 1

# COMMAND ----------

def isNumber(str):
    if not isValidString(str):
        return 0
    try:
        float(str)
        return 1
    except:
        return 0

# COMMAND ----------

# MAGIC %md
# MAGIC Address Functions

# COMMAND ----------

def isValidCity(str):

    if not str or not str.strip():
        return 0
  
    if len(str) < 3:
        return 0
    
    return 1

# COMMAND ----------

def isValidState(str):

    if not str or not str.strip():
        return 0 

    if len(str) < 2:
        return 0

    return 1

# COMMAND ----------

def isValidZip(str):
    if not str or not str.strip():
        return 0 
    else:
        return 1

# COMMAND ----------

def isValidPhone(str):

    if not str or not str.strip():
        return 0 

    if len(str) < 6:
        return 0 
    
    return 1

# COMMAND ----------

# MAGIC %md
# MAGIC Name Functions

# COMMAND ----------

def isValidName(name):
    # empty or white space
    if not name:
        return 0
    newname  = name.upper().strip()
    if not newname:
        return 0
    # min 2 char
    if len(newname) <= 1:
        return 0
    # contains only letters, hyphen, dot or accent
    _name_re = re.compile(r"^[A-Z]['`\-\., A-Z]*$")
    match = _name_re.match(newname)
    if not match:
        return 0
    # invalid names
    if newname in InvalidNameList:
        return 0
    # invalid starts with
    for nm in InvalidStartsWithName:
        if newname.startswith(nm):
            return 0
    # invalid ends with
    for nm in InvalidEndsWithName:
        if newname.endswith(nm):
            return 0
    # invalid contains
    for nm in InvalidNameContains:
        if nm in newname:
            return 0
    return 1

# COMMAND ----------

def isValidGender(str):
    if not str or not str.strip():
        return 0
    else:
        return 1

# COMMAND ----------

# MAGIC %md
# MAGIC SSN

# COMMAND ----------

# SSA will not issue SSNs beginning with the number "9".
# SSA will not issue SSNs beginning with the number "666" in positions 1-3.
# SSA will not issue SSNs beginning with the number "000" in positions 1-3.
# SSA will not issue SSNs with the number "00" in positions 4-5.
# SSA will not issue SSNs with the number "0000" in positions 6-9.
# SSN used in advertisements will not be used

# COMMAND ----------

def isValidSSN(ssn):
    # empty or white space
    if not ssn:
        return 0
    newssn  = ssn.strip().replace("-","")
    if not newssn:
        return 0
    # contains exactly 9 numbers
    _ssn_re = re.compile(r"^[0-9]{9}$")
    match = _ssn_re.match(newssn)
    if not match:
        return 0
    # invalid ssn -- used in ads
    if newssn in InvalidSSNListAdvertisements:
        return 0
    # invalid ssn -- magic numbers used by hospitals
    if newssn in InvalidSSNList:
        return 0
    # invalid starts with
    for ssn_start in InvalidStartsWithSSN:
        if newssn.startswith(ssn_start):
            return 0
    # ends with 0000
    if newssn.endswith('0000'):
        return 0
    # can't have 00 in middle set xxx-00-xxxx
    _ssn_re = re.compile(r"^[0-9]{3}00[0-9]{4}$")
    match = _ssn_re.match(newssn)
    if match:
        return 0
    # invalid contains
    for ssn in InvalidSSNContainsList:
        if ssn in newssn:
            return 0
    return 1

# COMMAND ----------

# MAGIC %md
# MAGIC DOB functions

# COMMAND ----------

def isValidDOB(date_text):
    # check for null
    if not date_text:
        return 0
    try:
        testDate = parse(str(date_text)).date()
        # should not be in the future
        if testDate >= datetime.date.today():
            return 0
        # should not be over 100 years old
        reallyOld = datetime.datetime.strptime('1/1/1905','%d/%m/%Y').date()
        if testDate < reallyOld:
            return 0
        return 1
    except:
        return 0

# COMMAND ----------

# MAGIC %md
# MAGIC ID functions

# COMMAND ----------

def isValidPID(str):
    if not str or not str.strip():
        return 0
    else:
        return 1

# COMMAND ----------

def isValidMCR(str):


    if not str: 
        return 0

    if not str.strip():
        return 0

    if str == '0':
        return 0

    if str == 'NONE':
        return 0

    if len(str) < 6: 
        return 0

    mcr1_re = re.compile(r"^\d{9}[a-zA-Z]")

    mcr2_re = re.compile(r"^[a-zA-Z]..\d{4}")

    mcr3_re = re.compile(r"[a-zA-Z0-9][a-zA-Z][a-zA-Z0-9][a-zA-Z0-9][a-zA-Z][a-zA-Z0-9][a-zA-Z0-9][a-zA-Z][a-zA-Z][a-zA-Z0-9][a-zA-Z0-9]")

    match1 = mcr1_re.match(str)
    match2 = mcr2_re.match(str)
    match3 = mcr3_re.match(str)

    if match1 or match2 or match3:
        return 1

    return 0

# COMMAND ----------

def isValidMCD(str):


    if not str: 
        return 0

    if not str.strip():
        return 0

    if str == '0':
        return 0

    if str == 'NONE':
        return 0

    if len(str) < 6: 
        return 0
    
    return 1

# COMMAND ----------

def isValidMRN(str):

    if not str or not str.strip():
        return 0

    if len(str) < 5: 
        return 0

    if str in InvalidMRN:
        return 0

    return 1

# COMMAND ----------

def isValidMRN_ver2(val):
    if not val or not val.strip():
        return 0
    if len(val.strip()) < 5:
        return 0
    if val.strip() in InvalidMRN:
        return 0
    try:
       x = int(val,16)
       if x == 0:
          return 0
    except:
       x = 0
    return 1

# COMMAND ----------

def isValidCA(val):
    if not val or not val.strip():
        return 0
    if not isNumber(val):
        return 0
    if val.strip() in InvalidCA:
        return 0
    try:
       x = int(val,16)
       if x == 0:
          return 0
    except:
       x = 0
    return 1

# COMMAND ----------


def isValidPolicy(str):

    if not str or not str.strip():
        return 0

    if len(str) < 6: 
        return 0

    return 1

# COMMAND ----------

def isValidGmrnid(str):

    if not str or not str.strip():
        return 0
    elif re.match("^[0-9_]*$", str):
       return 1
    else: 
       return 0
    return 1

# COMMAND ----------

def isValidZip5(zip):
    # empty or white space
    if not zip:
        return 0
    newzip  = zip.strip().replace("-","")
    if not newzip:
        return 0
    # contains exactly 5 numbers
    _zip_re = re.compile(r"^[0-9]{5}$")
    match = _zip_re.match(newzip)
    if not match:
        return 0
    # invalid zip -- <= 00500
    if int(newzip) <= 500:
        return 0
    return 1

# COMMAND ----------

def isValidResponseType(responsestd,responseext):
     if responsestd is not None and str(responsestd).strip()=="3" and (responseext is None or str(responseext).strip()=="" or str(responseext).strip().lower()=="null"):
        return 0
     return 1 