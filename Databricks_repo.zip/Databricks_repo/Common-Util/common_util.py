# Databricks notebook source
#This util is collection of frequently use functions for pyspark

# COMMAND ----------

import sys
from pyspark.sql.types import *
from pyspark.sql import SparkSession
import datetime
from dateutil.relativedelta import relativedelta
from dateutil.parser import parse
import pyspark.sql.functions as f
import re
import itertools

# COMMAND ----------

#1.if there is no column to choose 
#a=readparquet(spark, hdfs_path,"0","na")
#2. if there is column to choose
#a=readparquet(spark, hdfs_path,"1",[list_column])

# COMMAND ----------

def extract_parquet_data(spark, hdfs_path, cols=None):
    if cols == '' or cols is None:
        df = readparquet(spark,hdfs_path,"0","na")
    else:
        df = readparquet(spark,hdfs_path,"1",cols)
    return df

# COMMAND ----------

def readparquet(spark, hdfs_path, columns_flag, columns):
    if (columns_flag == '0'):
        a = spark.read.parquet(hdfs_path)
    else:
        a = spark.read.parquet(hdfs_path).select(columns)
    return a

# COMMAND ----------

#1.if there is no column to choose
#a=readcsv(spark, hdfs_path,schema_file,<delimiter of file>,"0","na")
#2. if there is column to choose
#a=readcsv(spark, hdfs_path,schema_file,<delimiter of file>,"1",[list_column])

# COMMAND ----------

def readcsv(spark, hdfs_path,cschema,dm,columns_flag,columns):
  if ( columns_flag == '0'):
    a=spark.read.format("csv").schema(cschema).options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", mode="FAILFAST", quote="", delimiter=dm).load(hdfs_path).dropDuplicates()
  else:
    a=spark.read.format("csv").schema(cschema).options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", mode="FAILFAST", quote="", delimiter=dm).load(hdfs_path).select(columns).dropDuplicates()
  return a

# COMMAND ----------

# This functions takes a df and loop through all columns to convert "null" or empty string value to None value

def get_clean_data(spark, df):
    for column in df.columns:
        df = df.withColumn(column, when(((trim(col(column)) != "") & (trim(lower(col(column))) != "null")), col(column)).otherwise(None))
    return df

# COMMAND ----------

# This function takes all null values and put string value instead of it 

def convert_null_value(spark, df):
    for column in df.columns:
        df = df.withColumn(column, when((col(column).isNull()), lit("NULL_VALUE")).otherwise(col(column)))
    return df

# COMMAND ----------

def get_hdp_demographicshash(spark, df):
    df.createOrReplaceTempView("vw_df_delta")
    sql12 = """
    select vw_df_delta.*,
    sha1(
    concat(
            case when coverageid is null then '' else coverageid end,":",
            coalesce((case when firstname is null then '' else UPPER(firstname) end),''),":",
            coalesce((case when lastname is null then '' else UPPER(lastname) end),''),":",
            case when substring(regexp_replace ((case when dob is null then '' else dob end),"-",""),1,8) is null then '' else substring(regexp_replace ((case when dob is null then '' else dob end),"-",""),1,8) end,":",
            (
              case when length (regexp_replace(coalesce((case when ssn is null then '' else ssn end),''),'-','')) = 7 then concat('00',regexp_replace(coalesce((case when ssn is null then '' else ssn end),''),'-','')) 
                   when length (regexp_replace(coalesce((case when ssn is null then '' else ssn end),''),'-','')) = 8 then concat('0',regexp_replace(coalesce((case when ssn is null then '' else ssn end),''),'-',''))
                   else regexp_replace(coalesce((case when ssn is null then '' else ssn end),''),'-','') end
             )
           )
          ) as hdp_demographicshash 
    from vw_df_delta
    """
    output = spark.sql(sql12)
    return output

# COMMAND ----------

#1.if there is no column to choose
#a=readcsv_permissive(spark, hdfs_path,schema_file,<delimiter of file>,"0","na")
#2. if there is column to choose
#a=readcsv_permissive(spark, hdfs_path,schema_file,<delimiter of file>,"1",[list_column])

# COMMAND ----------

def readcsv_permissive(spark, hdfs_path,cschema,dm,columns_flag,columns):
  if ( columns_flag == '0'):
    a=spark.read.format("csv").schema(cschema).options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", quote="", delimiter=dm).load(hdfs_path).dropDuplicates()
  else:
    a=spark.read.format("csv").schema(cschema).options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", quote="", delimiter=dm).load(hdfs_path).select(columns).dropDuplicates()
  return a


# COMMAND ----------


# reading deltalake file 
# have to import delta lake jar in the code before using this function 
# ex:
# sc.addPyFile(fs_common + "/io.delta_delta-core_2.11-0.6.1.jar")
# from delta.tables import *

# COMMAND ----------

def extract_deltalake_data(spark, hdfs_path, cols=None):
    if cols == '' or cols is None:
        df = spark.read.format("delta").load(hdfs_path)
    else:
        df = spark.read.format("delta").load(hdfs_path).select(cols)
    return df

# COMMAND ----------

#write parquet
#writeparquet(spark,<dataframe to write>,<hdfs_path_to_write>,<repartition_num>,<mode(e.g. "overwrite","aapend"etc)>)

# COMMAND ----------

def writeparquet(spark,df,hdfs_path,repartition,mode):
  if repartition == 0 :
    df.write.mode(mode).parquet(hdfs_path)
  else :
    df.repartition(repartition).write.mode(mode).parquet(hdfs_path)

# COMMAND ----------

#write parquet with drop duplicates on
#writeparquetcoalesce(spark,<dataframe to write>,<hdfs_path_to_write>,<repartition_num>,<mode(e.g. "overwrite","aapend"etc)>

# COMMAND ----------

def writeparquetcoalesce(spark,df,hdfs_path,repartition,mode):
  df.dropDuplicates().coalesce(repartition).write.mode(mode).parquet(hdfs_path)

# COMMAND ----------

# write parquet with option to write default partitions
# (spark,<dataframe to write>,<hdfs_path_to_write>,<repartition_num>/<column>/""(default partitions),<mode(e.g. "overwrite","aapend"etc)>)

# COMMAND ----------

def writeparquet_v1(spark, df, hdfs_path, repartition, mode):
    if repartition == '' :
        df.write.mode(mode).parquet(hdfs_path)
    else:
        df.repartition(repartition).write.mode(mode).parquet(hdfs_path)
    return df

# COMMAND ----------

#pass the applicatin name to get sparksession

# COMMAND ----------

def getsparksession(applicationName):
    spark = SparkSession.builder.appName(applicationName) \
    .config('spark.executor.memory', '10G')         \
    .config('spark.executor.instances', 100)        \
    .getOrCreate()

    return spark

# COMMAND ----------

#write out csv 
#writeparquet(spark,<dataframe to write>,<hdfs_path_to_write>,<repartition_num>,<mode(e.g. "overwrite","aapend"etc)>,<deilimiter>)

# COMMAND ----------

def writecsv(spark,df,hdfs_path,repartition,mode,dm):
   df.repartition(repartition).write.mode(mode).format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter=dm).save(hdfs_path)

# COMMAND ----------

#write to maprdb
#writetomaprdb(spark,<dataframe>,<maprdb_path>)

# COMMAND ----------

def writetomaprdb(spark,df,maprdb_path):
    spark.saveToMapRDB(df, maprdb_path, create_table=False)

# COMMAND ----------

#read to maprdb
#readmaprdb(spark,<maprdb_path>)

# COMMAND ----------

def readfrommaprdb(spark,maprdb_path):
    df = spark.loadFromMapRDB(maprdb_path)
    return df

# COMMAND ----------

def removegrpno_coverageid(spark,df):
    df = df.withColumn("coverageid_grpno",when((df.coverageid.contains(df.groupnumber))& (df.groupnumber != '') \
                      ,substring_index(df.coverageid,'-',1)).otherwise(df.coverageid))
    return df

# COMMAND ----------

def compare_coverageid(str1,str2):
    if((len(str1) == 4) | (len(str2) == 4)):
       if(str1 == str2):
         return 1
       else:
         return 0
    else:
       c1 = (str1[0:5])
       c2 = (str2[0:5])
       c3 = (str1[-5:])
       c4 = (str2[-5:])
       if( (c1 == c2) & (c3 == c4)):
          return 1
       else:
          return 0

# COMMAND ----------

# Same as readcsv but no need to pass no of columns or na if not selecting columns

def extract_csv_data(spark, hdfs_path,cschema,dm,cols=None):
  if cols == '' or cols is None:
    a = readcsv(spark,hdfs_path,cschema,dm,"0","na")
  else:
    a = readcsv(spark,hdfs_path,cschema,dm,"1",cols)  
  return a

# COMMAND ----------

#use to make blank cols as null 

def blank_as_null(x):
    return when(((trim(col(x)) != "") & (trim(lower(col(x))) != "null" )), col(x)).otherwise(None)
