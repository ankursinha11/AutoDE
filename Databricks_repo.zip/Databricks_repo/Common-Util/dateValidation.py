# Databricks notebook source
#dateValidation.py

# COMMAND ----------

import datetime

def isValidDate(inDate):
    strDate = str(inDate)
    for fmt in ["%Y%m%d", "%Y-%m-%d"]:
        try:
            dt = datetime.datetime.strptime(strDate, fmt)
            return True
        except ValueError:
            pass
    return False

# COMMAND ----------

def addDashesToDate(inDate):
    strDate = str(inDate)
    for fmt in ["%Y%m%d", "%Y-%m-%d"]:
        try:
            dt = datetime.datetime.strptime(strDate, fmt)
            return dt.strftime("%Y-%m-%d")
        except ValueError:
            pass
    return ""

# COMMAND ----------

def transformDate(inDate):
    try:
        return str(inDate).replace('-', '')
    except:
        pass
    return ""

# COMMAND ----------

def leftJustify(field, length):
    try:
        return str(field).ljust(length)
    except:
        pass

# COMMAND ----------

