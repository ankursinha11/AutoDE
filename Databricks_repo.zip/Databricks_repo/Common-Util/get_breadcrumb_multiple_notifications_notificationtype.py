# Databricks notebook source
dbutils.widgets.text("maprdbtable", "")
maprdbtable = dbutils.widgets.getArgument("maprdbtable")
print(maprdbtable)

dbutils.widgets.text("cosmosendpoint", "")
dbutils.widgets.getArgument("cosmosendpoint")
cosmosendpoint = getArgument("cosmosendpoint")
print(cosmosendpoint)

dbutils.widgets.text("cosmosdb", "")
dbutils.widgets.getArgument("cosmosdb")
cosmosdb= getArgument("cosmosdb")
print(cosmosdb)

dbutils.widgets.text("notificationtype", "")
dbutils.widgets.getArgument("notificationtype")
notificationtype= getArgument("notificationtype")
print(notificationtype)

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/cosmos_util"

# COMMAND ----------

def generateFilterExp(lis):
    temp_str = ""

    for i in lis:
        if(len(temp_str) == 0):
            temp_str = "notificationtype == '" + i +"' " 
        else:
            temp_str = temp_str +"or notificationtype == '" + i +"' "

    return temp_str

# COMMAND ----------

if(',' in notificationtype):
    lis = notificationtype.split(',')
    Filter_Exp = generateFilterExp(lis)
    Filter_Exp = "(" + Filter_Exp + ")" + " and processed != 'processed'"
else:
    Filter_Exp = "notificationtype == '" +notificationtype + "' and processed != 'processed'"

# COMMAND ----------

Filter_Exp

# COMMAND ----------

Filter_Exp

# COMMAND ----------

config = cosmosconfig(cosmosendpoint, cosmosdb, maprdbtable)
df = readfromcosmosdb(config)
# filterExpr1 = "notificationtype == 'ie_xref_lsb_propagation' or notificationtype == 'es_xref_lsb_propagation' or notificationtype == 'globalmrnmerge_xref_lsb_propagation' or notificationtype == 'fc_xref_lsb_propagation' or notificationtype =='chc_xref_lsb_propagation'  and processed != 'processed'"
df = df.filter(Filter_Exp)
df = df.orderBy(df.createdon.asc())
df = df.select(df.bc, df.notificationtype)
df = df.limit(1).collect()
bc = df[0][0]
notificationtype = df[0][1]
#print(bc)
dbutils.notebook.exit({'bc':bc,'notification_type':notificationtype})