# Databricks notebook source
import uuid

# COMMAND ----------

def cosmosconfig(cosmosendpoint, cosmosdb, maprdbtable):
    cosmosMasterKey = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-cosmos-insleads-kvsecret")
    config = {
    "spark.cosmos.accountEndpoint" : cosmosendpoint,
    "spark.cosmos.accountKey" : cosmosMasterKey,
    "spark.cosmos.database" : cosmosdb,
    "spark.cosmos.container" : maprdbtable,
    }

    # Configure Catalog Api to be used
    spark.conf.set("spark.sql.catalog.cosmosCatalog", "com.azure.cosmos.spark.CosmosCatalog")
    spark.conf.set("spark.sql.catalog.cosmosCatalog.spark.cosmos.accountEndpoint", cosmosendpoint)
    spark.conf.set("spark.sql.catalog.cosmosCatalog.spark.cosmos.accountKey", cosmosMasterKey)
    spark.conf.set("spark.sql.catalog.cosmosCatalog.spark.cosmos.views.repositoryPath", "/viewDefinitions" + str(uuid.uuid4()))

    # create an Azure Cosmos DB database using catalog api
    #spark.sql("CREATE DATABASE IF NOT EXISTS cosmosCatalog.{};".format(cosmosDatabaseName))

    # create an Azure Cosmos DB container using catalog api
    #spark.sql("CREATE TABLE IF NOT EXISTS cosmosCatalog.{}.{} using cosmos.oltp TBLPROPERTIES(partitionKeyPath = '/id', manualThroughput = '1100')".format(cosmosdb, maprdbtable))

    return config

# COMMAND ----------

def readfromcosmosdb(config):
    df = spark.read.format("cosmos.oltp").options(**config).option("spark.cosmos.read.inferSchema.enabled", "true").load()
    return df

def writetocosmosdb(df, config):
    df.write.format("cosmos.oltp").options(**config).mode("APPEND").save()
    return df 