# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.types import *
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.functions import rank, col, row_number, udf
import re
from pyspark import SparkConf, SparkContext, SparkFiles

# COMMAND ----------

# This functions takes
#   input:  a fulll path to a schema file
#           such as patientsaccount_schema with a comma separated  fieledname,fieldtype in each line.
#
#    output: A List of Struct Types
#            StructType(List(StructField(patientacctpk,StringType,true),StructField(hospitalfk,StringType,true)
#            This will typically be used to load a input data file based on the layout specified in the schema.

# COMMAND ----------

def createSchemaLine( schemaFile ) :
    fields=[]
    fh =  spark.read.text(schemaFile)
    fileContent = fh.collect()
    schemas = [schema[0] for schema in fileContent]
    
    for field_name_type in schemas:
        if not field_name_type.startswith("#"):
            fieldNameType = field_name_type.split(',', 2)
            fieldName = fieldNameType[0].strip()
            fieldType = fieldNameType[1].strip()
            if fieldType == "string":
                structField = StructField(fieldName, StringType(), True)
                fields.append(structField)
            elif fieldType == "timestamp":
                structField = StructField(fieldName, TimestampType(), True)
                fields.append(structField)
            elif fieldType == "int":
                structField = StructField(fieldName, IntegerType(), True)
                fields.append(structField)
            elif fieldType == "integer":
                structField = StructField(fieldName, IntegerType(), True)
                fields.append(structField)
            elif fieldType == "double":
                structField = StructField(fieldName, DoubleType(), True)
                fields.append(structField)
            elif fieldType == "float":
                structField = StructField(fieldName, FloatType(), True)
                fields.append(structField)
            elif fieldType == "decimal":
                structField = StructField(fieldName, DecimalType(), True)
                fields.append(structField)
            elif fieldType == "smallint":
                structField = StructField(fieldName, ShortType(), True)
                fields.append(structField)
            else:
                structField = StructField(fieldName, StringType(), True)
                fields.append(structField)
    schema = StructType(fields)
    return schema

# COMMAND ----------

def load_partioned_table_dictionary(file_path):
    p_table_dictionary = {
    }
    with open(file_path) as f:
        data = [line.rstrip() for line in f]
    for i in data:
        table_name = i
        p_table_dictionary.update({table_name: '1'})
    return p_table_dictionary

# COMMAND ----------

def load_delta_write_table_dictionary(file_path):
    p_table_dictionary = {
    }
    with open(file_path) as f:
        data = [line.rstrip() for line in f]
    for i in data:
        table_name = i
        p_table_dictionary.update({table_name: '1'})
    return p_table_dictionary


# COMMAND ----------

def load_table_uniqkey_dictionary(file_path):
    p_table_uniqkey_dictionary = {
    }
    with open(file_path) as f:
        data = [line.rstrip() for line in f]
    for i in data:
        table_name, table_key = i.split(":")
        p_table_uniqkey_dictionary.update({table_name: table_key})
    return p_table_uniqkey_dictionary