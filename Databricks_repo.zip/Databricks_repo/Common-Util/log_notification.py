# Databricks notebook source
# Supriya Robertson
# May 5th, 2020
# This script logs a notification to MARDB, It also allows you to update the previously logged notification as processed


# COMMAND ----------

import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
import datetime

# COMMAND ----------

# SAMPLE

# bc = "20250508T13-MC"
# cosmosdb = "insleads"
# cosmosendpoint = "https://prod-icd-stg-cosmos.documents.azure.com:443/"
# maprdbtable = "runstatus"
# notificationdir = "triggers"
# notificationtype = "globalmrn_assign_medicare"
# workflowtype = "aid"

# bc = "20250508T13-MA"
# cosmosdb = "insleads"
# cosmosendpoint = "https://prod-icd-stg-cosmos.documents.azure.com:443/"
# maprdbtable = "runstatus"
# notificationdir = "triggers"
# notificationtype = "globalmrn_assign_medicaid"
# workflowtype = "aid"

# bc = "20250508T13"
# cosmosdb = "insleads"
# cosmosendpoint = "https://prod-icd-stg-cosmos.documents.azure.com:443/"
# maprdbtable = "runstatus"
# notificationdir = "triggers"
# notificationtype = "globalmrn_assign"
# workflowtype = "aid"

# COMMAND ----------

def isAidLeadGen(bc, workflowtype, notificationtype):
    isAidLeadGenTrue = 0
    workflowtype = str(workflowtype).lower()
    notificationtype = str(notificationtype).lower()
    if workflowtype == "aid" and notificationtype in [
        "globalmrn_assign",
        "globalmrn_assign_medicare",
        "globalmrn_assign_medicaid",
    ]:
        print("isAidLeadGen=true")
        isAidLeadGenTrue = 1
        category = str(get_category(notificationtype))
        idcol = notificationtype + "_" + bc
        createdon = datetime.datetime.today().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        msglocation = str(get_msg_location(notificationdir, notificationtype + "_aid"))
        print("idcol            : " + idcol)
        print("notificationtype : " + notificationtype)
        print("category         : " + category)
        print("bc               : " + bc)
        print("createdon        : " + createdon)
        print("msglocation      : " + msglocation)
        print("workflowtype     : " + workflowtype)
        schema = StructType(
            [
                StructField("id", StringType(), True),
                StructField("notificationtype", StringType(), True),
                StructField("category", StringType(), True),
                StructField("bc", StringType(), True),
                StructField("msglocation", StringType(), True),
                StructField("workflowtype", StringType(), True),
            ]
        )
        l = [(idcol, notificationtype, category, bc, msglocation, workflowtype)]
        df = spark.createDataFrame(l, schema).withColumn("processed", lit("unprocessed")).withColumn("createdon", lit(createdon))
        # df.display()
        writetocosmosdb(df, config)
        return isAidLeadGenTrue
    else :
        print("isAidLeadGen=false")
        isAidLeadGenTrue = 0
        return isAidLeadGenTrue

# COMMAND ----------

dbutils.widgets.text("bc","")
bc = dbutils.widgets.getArgument("bc")
print(bc)

dbutils.widgets.text("notificationtype","")
notificationtype = dbutils.widgets.getArgument("notificationtype")
print(notificationtype)

dbutils.widgets.text("maprdbtable", "runstatus")
maprdbtable = dbutils.widgets.getArgument("maprdbtable")
print(maprdbtable)

dbutils.widgets.text("notificationdir","")
notificationdir = dbutils.widgets.getArgument("notificationdir")
print(notificationdir)

dbutils.widgets.text("cosmosendpoint", "https://prod-ent-icd-cosmos-test.documents.azure.com:443/")
dbutils.widgets.getArgument("cosmosendpoint")
cosmosendpoint = getArgument("cosmosendpoint")
print(cosmosendpoint)

dbutils.widgets.text("cosmosdb", "insleads")
dbutils.widgets.getArgument("cosmosdb")
cosmosdb= getArgument("cosmosdb")
print(cosmosdb)

dbutils.widgets.text("workflowtype", "")
dbutils.widgets.getArgument("workflowtype")
workflowtype= getArgument("workflowtype")
print(workflowtype)

# COMMAND ----------

def get_category(notificationtype):
    """category lookup"""

    category = {
        "ie_prebdf": "ichtransaction",
        "ie_postbdf": "xref",
        "es_postbdf": "xref",
        "escan_globalmrn_merge": "xref",
        "fc_xref": "xref",
        "chc_xref": "chc_xref",
        "fc_ingest": "fctransaction",
        "globalmrn_assign": "leadlookup",
        "globalmrn_assign_aid": "leadlookup",
        "ie_xref_lsb": "leadservicebase",
        "es_xref_lsb": "leadservicebase",
        "globalmrnmerge_xref_lsb": "leadservicebase",
        "fc_xref_lsb": "leadservicebase",
        "hfc_xref_lsb": "leadservicebase",
        "mh_xref_lsb": "leadservicebase",
        "chc_xref_lsb": "leadservicebase",
        "ie_xref_lsb_propagation": "leadpropagation",
        "es_xref_lsb_propagation": "leadpropagation",
        "globalmrnmerge_xref_lsb_propagation": "leadpropagation",
        "fc_xref_lsb_propagation": "leadpropagation",
        "hfc_xref_lsb_propagation": "leadpropagation",
        "leadpropagation": "leadlookup",
        "chc_xref_lsb_propagation": "leadpropagation",
        "leadstatus_edi": "leadstatusupdate",
        "leadstatus_ich": "leadstatusupdate",
        "bcs_permid_swift": "bcs_permid_swift",
        "knowncommercial": "leadlookup",
        "bdf_download": "es_swift_postbdf",
        "bdf_download_ie": "ie_postbdf",
        "globalmrn_assign_medicare": "leadlookup",
        "globalmrn_assign_medicare_aid": "leadlookup",
        "pa_lead_verification": "leadverify",
        "globalmrn_assign_medicaid": "leadlookup",
        "globalmrn_assign_medicaid_aid": "leadlookup",
        "ich_import": "ich_update",
        "data_ingestion_patientaccts": "es_prebdf",
        "data_ingestion_patientaccts2": "fc_ingest",
        "data_ingestion_patientaccts3": "globalmrnmerged",
        "data_ingestion_patientaccts4": "ghic",
        "data_ingestion_patientaccts5": "medicarecoveragediscovery",
        "data_ingestion_patientaccts6": "bestopp",
        "data_ingestion_patientaccts7": "globalmrnmerged_swift",
        "data_ingestion_helperfoundcoverages": "hfc_import",
        "data_ingestion_medicarecoverage": "mh_import",
        "data_ingestion_clusteredaccts": "medicaidhelper",
        "globalmrn": "leadlookup",
        "policyhelpers": "mbihelper",
        "ie_xref_famc": "family_clustering_xref",
        "es_xref_famc": "family_clustering_xref",
        "fc_xref_famc": "family_clustering_xref",
        "ie_lsb_famc": "leadservicebase",
        "es_lsb_famc": "leadservicebase",
        "fc_lsb_famc": "leadservicebase",
        "ie_propagation_famc": "leadpropagation",
        "es_propagation_famc": "leadpropagation",
        "fc_propagation_famc": "leadpropagation",
        "es_xref_famc_tu": "tusourcedfamilymemberlink",
        "data_ingestion_hintfc":"commercial_hints",
        "gmrn_family_helper":"gmrn_family_associations",
    }
    return category.get(notificationtype)

# COMMAND ----------

def get_msg_location(notificationdir, notificationtype):
    """msg location lookup"""
    msglocation = {
        "ie_prebdf": notificationdir + "/ich_update",
        "ie_postbdf": notificationdir + "/xref_update",
        "es_postbdf": notificationdir + "/xref_update",
        "escan_globalmrn_merge": notificationdir + "/xref_update",
        "fc_xref": notificationdir + "/xref_update",
        "chc_xref": notificationdir + "/chc_xref",
        "fc_ingest": notificationdir + "/foundcoverage",
        "globalmrn_assign": notificationdir + "/leadlookup",
        "globalmrn_assign_aid": notificationdir + "/leadlookup_aid",
        "ie_xref_lsb_propagation": notificationdir + "/leadpropagation",
        "es_xref_lsb_propagation": notificationdir + "/leadpropagation",
        "globalmrnmerge_xref_lsb_propagation": notificationdir + "/leadpropagation",
        "fc_xref_lsb_propagation": notificationdir + "/leadpropagation",
        "hfc_xref_lsb_propagation": notificationdir + "/leadpropagation",
        "ie_xref_lsb": notificationdir + "/leadservicebase",
        "es_xref_lsb": notificationdir + "/leadservicebase",
        "globalmrnmerge_xref_lsb": notificationdir + "/leadservicebase",
        "fc_xref_lsb": notificationdir + "/leadservicebase",
        "hfc_xref_lsb": notificationdir + "/leadservicebase",
        "mh_xref_lsb": notificationdir + "/leadservicebase",
        "chc_xref_lsb": notificationdir + "/leadservicebase",
        "chc_xref_lsb_propagation": notificationdir + "/leadpropagation",
        "leadpropagation": notificationdir + "/leadlookup_propagation",
        "leadstatus_edi": notificationdir + "/leadstatusupdate",
        "leadstatus_ich": notificationdir + "/leadstatusupdate",
        "bcs_permid_swift": notificationdir + "/bcs_permid_swift",
        "knowncommercial": notificationdir + "/leadlookup_knowncommercial/",
        "bdf_download": notificationdir + "/es_swift_postbdf/",
        "bdf_download_ie": notificationdir + "/ie_postbdf/",
        "globalmrn_assign_medicare": notificationdir + "/medicareleads/",
        "globalmrn_assign_medicaid": notificationdir + "/medicaidleads/",
        "globalmrn_assign_medicare_aid": notificationdir + "/medicareleads_aid/",
        "globalmrn_assign_medicaid_aid": notificationdir + "/medicaidleads_aid/",
        "pa_lead_verification": notificationdir + "/leadverify",
        "ich_import": notificationdir + "/ich_update",
        "data_ingestion_patientaccts": notificationdir + "/es_prebdf",
        "data_ingestion_patientaccts2": notificationdir +"/fc_ingest",
        "data_ingestion_patientaccts3": notificationdir +"/globalmrnmerged",
        "data_ingestion_patientaccts4": notificationdir +"/ghic",
        "data_ingestion_patientaccts5": notificationdir +"/medicarecoveragediscovery",
        "data_ingestion_patientaccts6": notificationdir +"/bestopp",
        "data_ingestion_patientaccts7": notificationdir +"/globalmrnmerged_swift",
        "data_ingestion_helperfoundcoverages":notificationdir +"/hfc_import",
        "data_ingestion_medicarecoverage":notificationdir +"/mh_import",
        "data_ingestion_clusteredaccts":notificationdir +"/medicaidhelper",
        "globalmrn": notificationdir +"/globalmrn_assign",
        "policyhelpers": notificationdir +"/mbihelper",
        "ie_xref_famc": notificationdir +"/family_clustering_xref",
        "es_xref_famc": notificationdir +"/family_clustering_xref",
        "fc_xref_famc": notificationdir +"/family_clustering_xref",
        "ie_lsb_famc": notificationdir +"/leadservicebase",
        "es_lsb_famc": notificationdir +"/leadservicebase",
        "fc_lsb_famc": notificationdir +"/leadservicebase",
        "ie_propagation_famc": notificationdir +"/leadpropagation",
        "es_propagation_famc": notificationdir +"/leadpropagation",
        "fc_propagation_famc": notificationdir +"/leadpropagation",
        "es_xref_famc_tu": notificationdir +"/tusourcedfamilymemberlink",
        "data_ingestion_hintfc":notificationdir +"/commercial_hints",
        "gmrn_family_helper":notificationdir +"/gmrn_family_helper"
    }
    return msglocation.get(notificationtype)

# COMMAND ----------

# MAGIC %run ./cosmos_util

# COMMAND ----------

config = cosmosconfig(cosmosendpoint, cosmosdb, maprdbtable)

# COMMAND ----------

def log_data(bc, notificationtype, maprdbtable, notificationdir):
    """Log the notification in the maprdb table"""

    schema = StructType([
        StructField("id", StringType(), True),
        StructField("notificationtype", StringType(), True),
        StructField("category", StringType(), True),
        StructField("bc", StringType(), True),
        StructField("msglocation", StringType(), True)
    ])

    idcol = notificationtype + "_" + bc

    current_dt = datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]

    l = [(idcol, notificationtype, get_category(notificationtype), bc, get_msg_location(notificationdir, notificationtype))]
    df = spark.createDataFrame(l, schema)
    df = df.withColumn("createdon", lit(current_dt))
    if notificationdir == 'na':
        df = df.withColumn("processed", lit("running")) 
    else:
        df = df.withColumn("processed", lit("unprocessed")) 
    
    if workflowtype == 'aid':
        df = df.withColumn("workflowtype", lit("aid")) 
    else:
        df = df.withColumn("workflowtype", lit("regular")) 

    # display(df)
    #spark.saveToMapRDB(df, maprdbtable)
    writetocosmosdb(df, config)
    #df.write.format("cosmos.oltp").options(**config).mode("APPEND").save()

    df = readfromcosmosdb(config)
    #filterExpr1 = "id == '" + idcol + "'"
    #df = spark.read.format("cosmos.oltp").options(**config).option("spark.cosmos.read.inferSchema.enabled", "true").load().filter(filterExpr1).limit(1)
    #display(df)

    return None

# COMMAND ----------

# DBTITLE 1,isAidLeadGen
isAidLeadGenTrue = isAidLeadGen(bc,workflowtype, notificationtype)

# COMMAND ----------

# DBTITLE 1,isAidLeadGen
if isAidLeadGenTrue == 1 :
  print("isAidLeadGenTrue: " + str(isAidLeadGenTrue))
  dbutils.notebook.exit(0)
else :
  print("isAidLeadGenTrue: " + str(isAidLeadGenTrue) + " : Continue")

# COMMAND ----------

#print(get_category(notificationtype))
#print(get_msg_location(notificationdir, notificationtype))
log_data(bc, notificationtype, maprdbtable, notificationdir)
