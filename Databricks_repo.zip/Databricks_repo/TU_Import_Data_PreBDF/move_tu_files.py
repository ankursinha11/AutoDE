# Databricks notebook source
dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("read_container","")
dbutils.widgets.getArgument("read_container")
read_container= getArgument("read_container")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("bcdate","")
dbutils.widgets.getArgument("bcdate")
bcdate= getArgument("bcdate")

dbutils.widgets.text("cdd_dir","")
dbutils.widgets.getArgument("cdd_dir")
cdd_dir= getArgument("cdd_dir")

dbutils.widgets.text("files_count","")
dbutils.widgets.getArgument("files_count")
files_count= getArgument("files_count")

# COMMAND ----------

import re
import os

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+read_container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+read_container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

#for write
if user == 'na': #defualt value
    write_baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    write_baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

tu_source = baseurl +'/tumonthly/data/'
tu_sink = write_baseurl +cdd_dir+"/staging/input/tu/"+bcdate
tu_sink_partial = write_baseurl+ cdd_dir+"/staging/input/tu/Partialfiles/"+bcdate

print(tu_source)
print(tu_sink)
print(tu_sink_partial)

# COMMAND ----------

#if returns some count then it means there are no partial files
from pyspark.sql.utils import AnalysisException

def check_for_partial_files(df, name):
    try:
        count = df.count()
        print(f"{name} count: {count}")
        return count
    except Exception as e:
        print(f"Error counting {name}")
        return None

# COMMAND ----------

def move_files():
    files = dbutils.fs.ls(tu_source)
    file_names = [file.path for file in files]

    if len(file_names) == int(files_count):
       for file in files:
            filename = file.name
            dbutils.fs.mv(file.path, os.path.join(tu_sink, filename))
            print(f"Moved {filename} to {tu_sink}")
    else:
        error_message = print(f"Validation failed: Expected {files_count} files, but found {len(file_names)} files")
        print(error_message)
        raise Exception(error_message)

# COMMAND ----------

def find_partial_files():
    files = dbutils.fs.ls(tu_source)
    partial_files = []
    for file in files:
        file_path = file.path
        file_name = file.name
        try:
           df = spark.read.option("header", "true").csv(file_path) 
           record_count = df.count()
           print(f" Valid File: {file_name}, Record Count: {record_count}")
        except Exception as e:
           print(f" Partial File Detected: {file_name}")
           partial_files.append(file_name)
           dbutils.fs.mv(file.path, os.path.join(tu_sink_partial, file_name))
           print(f"Moved {file_name} to {tu_sink_partial}")
    return partial_files
           

# COMMAND ----------

# Read the data
data_address = spark.read.csv(tu_source + "/*tlo_address*")
data_phone = spark.read.csv(tu_source + "/*tlo_phone*")
data_consumer = spark.read.csv(tu_source + "/*tlo_cv_header*")

# Count records and check for failures
counts = {
    "phone": check_for_partial_files(data_phone, "phone"),
    "address": check_for_partial_files(data_address, "address"),
    "consumer": check_for_partial_files(data_consumer, "consumer")
}

# Check if any dataset failed
if any(value is None for value in counts.values()):
    print("Partial files detected in the folder. Identifying specific files...")
    partial_files = find_partial_files()
    error_message = f"Failure: Partial files detected : Files: {', '.join(partial_files)}"
    raise Exception(error_message)
else:
    print("All files are good. Proceeding with file movement.")
    move_files()
