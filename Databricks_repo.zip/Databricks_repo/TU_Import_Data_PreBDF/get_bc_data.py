# Databricks notebook source
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import *
import datetime

# COMMAND ----------

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bcdate","")
dbutils.widgets.getArgument("bcdate")
bcdate= getArgument("bcdate")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("cdd_dir","")
dbutils.widgets.getArgument("cdd_dir")
cdd_dir= getArgument("cdd_dir")

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

#mount the storage account#
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

tu_input = baseurl+cdd_dir+"/staging/input/tu/"+bcdate 
#/data/cdd/staging/input/tu/26APR2024-10
tu_output = baseurl+cdd_dir+"/transform/tu"

print("tu_input: ",tu_input)
print("tu_output: ",tu_output)

# input_cdd_dir = f"/hcecdd/user/{inputUser}/CDD"
# output_cdd_dir = f"/hcecdd/user/{outputUser}/CDD"
# inputDir = f"{input_cdd_dir}/input/tu"
# outputBaseDir = f"{output_cdd_dir}/output/tu"
# InputStorageLocation = "abfss://npp@divyaprodstorageact1.dfs.core.windows.net/" + inputDir + '/' + bcdate
# OutputStorageLocation = "abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net" + outputBaseDir

# COMMAND ----------

# DBTITLE 1,Load consumerInfo data
consumerInfo = spark.read.text(tu_input + "/*tlo_cv_header*.dat*")

consumerInfo = (consumerInfo.withColumn("value",regexp_replace(col("value"), "\\|", " "))
                                .withColumn("TUKEY",substring(col('Value'),1,12))
                                .withColumn("FILE_SINCE_DTE",substring(col('Value'),13,10))
                                .withColumn("SSN",substring(col('Value'),23,9))
                                .withColumn("FRST_NME",substring(col('Value'),32,20))
                                .withColumn("MIDL_NME",substring(col('Value'),52,20))
                                .withColumn("LAST_NME",substring(col('Value'),72,32))
                                .withColumn("GENERATIONAL_NME_SFX",substring(col('Value'),104,4))
                                .withColumn("NME_PFX_CDE",substring(col('Value'),108,4))
                                .withColumn("NME_SFX_CDE",substring(col('Value'),112,4))
                                .withColumn("NME_FIRST_RPTD_DTE",substring(col('Value'),116,10))
                                .withColumn("DOB",substring(col('Value'),126,10))
                                .withColumn("AKA1_FRST_NME",substring(col('Value'),136,20))
                                .withColumn("AKA1_MIDL_NME",substring(col('Value'),156,20))
                                .withColumn("AKA1_LAST_NME",substring(col('Value'),176,32))
                                .withColumn("AKA1_NME_PFX_CDE",substring(col('Value'),208,4))
                                .withColumn("AKA1_NME_SFX_CDE",substring(col('Value'),212,4))
                                .withColumn("AKA1_NME_FIRST_RPTD_DTE",substring(col('Value'),216,10))
                                .withColumn("AKA2_FRST_NME",substring(col('Value'),226,20))
                                .withColumn("AKA2_MIDL_NME",substring(col('Value'),246,20))
                                .withColumn("AKA2_LAST_NME",substring(col('Value'),266,32))
                                .withColumn("AKA2_NME_PFX_CDE",substring(col('Value'),298,4))
                                .withColumn("AKA2_NME_SFX_CDE",substring(col('Value'),302,4))
                                .withColumn("AKA2_NME_FIRST_RPTD_DTE",substring(col('Value'),306,10))
                                .withColumn("AKA3_FRST_NME",substring(col('Value'),316,20))
                                .withColumn("AKA3_MIDL_NME",substring(col('Value'),336,20))
                                .withColumn("AKA3_LAST_NME",substring(col('Value'),356,32))
                                .withColumn("AKA3_NME_PFX_CDE",substring(col('Value'),388,4))
                                .withColumn("AKA3_NME_SFX_CDE",substring(col('Value'),392,4))
                                .withColumn("AKA3_NME_FIRST_RPTD_DTE",substring(col('Value'),396,10))
                                .withColumn("DECEASED_DTE",substring(col('Value'),406,10))
                                .drop('value')
                            )

# Add the breadcrumbs field
consumerInfoWithBC = consumerInfo.withColumn("breadCrumbs", lit(bcdate))

# Store the data
consumerInfoWithBCOutput = tu_output +"/consumerWithBC/" + bcdate

# consumerInfoWithBC.repartition(200).write.mode('overwrite').option("delimiter", "|").option('header',True) .csv(consumerInfoWithBCOutput)
consumerInfoWithBC.write.mode('overwrite').parquet(consumerInfoWithBCOutput)

# COMMAND ----------

# DBTITLE 1,Load addressInfo data
addressInfo = spark.read.text(tu_input + "/*tlo_address*.dat*")
addressInfo = (addressInfo.withColumn("value",regexp_replace(col("value"), "\\|", " "))
                                .withColumn("TUKEY",substring(col('Value'),1,12))
                                .withColumn("ADDR_SEQ_NUM",substring(col('Value'),13,2))
                                .withColumn("ADDR_NUM",substring(col('Value'),15,10))
                                .withColumn("PREDIR_CDE",substring(col('Value'),25,2))
                                .withColumn("STR_NME",substring(col('Value'),27,28))
                                .withColumn("STR_TYP_CDE",substring(col('Value'),55,4))
                                .withColumn("POSTDIR_CDE",substring(col('Value'),59,4))
                                .withColumn("UNIT_TYPE",substring(col('Value'),63,4))
                                .withColumn("UNIT_NUM",substring(col('Value'),67,10))
                                .withColumn("CITY_NME",substring(col('Value'),77,28))
                                .withColumn("STATE_CDE",substring(col('Value'),105,2))
                                .withColumn("ZIP_CDE",substring(col('Value'),107,5))
                                .withColumn("ZIP_EXTND_CDE",substring(col('Value'),112,4))
                                .withColumn("ADDR_FRST_RPTD_DTE",substring(col('Value'),116,10))
                                .withColumn("STD_FLG",substring(col('Value'),126,1))
                                .drop('value'))
                            

# Add the breadcrumbs field
addressInfoWithBC = addressInfo.withColumn("breadCrumbs", lit(bcdate))

# Store the data
# addressInfoWithBC.repartition(200).write.mode('overwrite').option("delimiter", "|").option('header',True).csv(f"{OutputStorageLocation}/addressWithBC/{bcdate}")

addressInfoWithBCOutput = tu_output +"/addressWithBC/" + bcdate

# addressInfoWithBC.repartition(200).write.mode('overwrite').option("delimiter", "|").option('header',True).csv(addressInfoWithBCOutput)
addressInfoWithBC.write.mode('overwrite').parquet(addressInfoWithBCOutput)

# COMMAND ----------

# DBTITLE 1,Load phoneInfo data
phoneInfo = spark.read.text(tu_input + "/*tlo_phone*.dat*")
phoneInfo = (phoneInfo.withColumn("value",regexp_replace(col("value"), "\\|", " "))
                                .withColumn("TUKEY",substring(col('Value'),1,12))
                                .withColumn("PHONE_SEQ_NUM",substring(col('Value'),13,2))
                                .withColumn("PHONE_AREA_CDE",substring(col('Value'),15,3))
                                .withColumn("PHONE_XCHNG_NUM",substring(col('Value'),18,3))
                                .withColumn("PHONE_SFX_NUM",substring(col('Value'),21,4))
                                .withColumn("PHONE_FRST_RPTD_DTE",substring(col('Value'),25,10))
                                .drop('value'))

# Add the breadcrumbs field
phoneInfoWithBC = phoneInfo.withColumn("breadCrumbs", lit(bcdate))

# Store the data
# phoneInfoWithBC.repartition(200).write.mode('overwrite').option("delimiter", "|").option('header',True).csv(f"{OutputStorageLocation}/phoneWithBC/{bcdate}")

phoneInfoWithBCOutput = tu_output +"/phoneWithBC/" + bcdate

# phoneInfoWithBC.repartition(200).write.mode('overwrite').option("delimiter", "|").option('header',True).csv(phoneInfoWithBCOutput)
phoneInfoWithBC.write.mode('overwrite').parquet(phoneInfoWithBCOutput)
