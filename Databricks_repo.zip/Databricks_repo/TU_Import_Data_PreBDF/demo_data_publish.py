# Databricks notebook source
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bcdate","")
dbutils.widgets.getArgument("bcdate")
bcdate= getArgument("bcdate")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("cdd_dir","")
dbutils.widgets.getArgument("cdd_dir")
cdd_dir= getArgument("cdd_dir")

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

#mount the storage account#
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

inputDir = baseurl + cdd_dir + "/transform/tu"
outputBaseDir = baseurl + cdd_dir + "/publish/tu"

print("inputDir: ",inputDir)
print("outputBaseDir: ",outputBaseDir)

# COMMAND ----------

dbutils.fs.mv(f"{outputBaseDir}/consumer/current/", f"{outputBaseDir}/consumer/prev",True)
dbutils.fs.cp(f"{inputDir}/consumerWithBC/{bcdate}", f"{outputBaseDir}/consumer/current/{bcdate}", True)

dbutils.fs.mv(f"{outputBaseDir}/address/current/", f"{outputBaseDir}/address/prev",True)
dbutils.fs.cp(f"{inputDir}/addressWithBC/{bcdate}", f"{outputBaseDir}/address/current/{bcdate}" ,True)

dbutils.fs.mv(f"{outputBaseDir}/phone/current/", f"{outputBaseDir}/phone/prev",True)
dbutils.fs.cp(f"{inputDir}/phoneWithBC/{bcdate}", f"{outputBaseDir}/phone/current/{bcdate}" ,True)

print("All folders have been moved successfully.")
