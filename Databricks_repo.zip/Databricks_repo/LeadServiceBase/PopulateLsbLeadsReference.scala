// Databricks notebook source
// MAGIC %md 
// MAGIC this notebook performs activities from PopulateLsbLeadsReference.scala

// COMMAND ----------

import org.apache.spark.sql.{DataFrame}
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._
import scala.io.Source
import scala.collection._
import java.time.format.DateTimeFormatter
import java.time.LocalDate
import java.time.LocalDateTime
import io.delta.tables._
import spark.implicits._
import org.apache.spark.sql.expressions.{Window, WindowSpec}
import org.apache.spark.sql.types._
import org.apache.spark.sql.Column
import org.apache.spark.sql.expressions.UserDefinedFunction

// COMMAND ----------

// "hdfs_path","abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/divya/data/leadrepo/scratch/leadservicebase/json_demog/"
// "deltalake_output","abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/divya/data/test_leadrepo/publish/served/divya_leadservicebase_ssn"
// "id_column","transactionkey" 
// "store_path","abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/divya/data/leadrepo/publish/cooked/lr_xref_ssn_mrn_cluster_transaction"
// "list_column","ssn"
// "num_partition","2500"
// "column_to_get","lookupvalue"
// "sec_index_name","idx_transkey"
// "config_file_path","abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/data/leadservicebase/leadservicebase_create/config.txt"
// "source","fc"
// "hospitalfk_field_name","hospitalfk"
// ("temp_op_path","abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/divya/data/leadrepo/scratch/leadservicebase/"
// "user","phd9appl"
// "bc","20230913T02"
// "wf_source_path","abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/divya/data/leadrepo/publish/toserve/fc_import/"
// "leadlookupoppath","abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/divya/data/leadrepo/publish/cooked/leadservicebasehelper/"

// COMMAND ----------

// DBTITLE 1,Input Parameters
dbutils.widgets.text("hdfs_path","")
val hdfs_path=dbutils.widgets.get("hdfs_path")

dbutils.widgets.text("deltalake_output","")
val deltalake_output=dbutils.widgets.get("deltalake_output")

dbutils.widgets.text("id_column","")
val id_column=dbutils.widgets.get("id_column")

dbutils.widgets.text("store_path","")
val store_path=dbutils.widgets.get("store_path")

dbutils.widgets.text("list_column","")
val list_column=dbutils.widgets.get("list_column")

dbutils.widgets.text("num_partition","2500")
val num_partition=dbutils.widgets.get("num_partition").toInt

dbutils.widgets.text("column_to_get","")
val column_to_get=dbutils.widgets.get("column_to_get")

dbutils.widgets.text("sec_index_name","")
val sec_index_name=dbutils.widgets.get("sec_index_name")

dbutils.widgets.text("config_file_path","")
val config_file_path=dbutils.widgets.get("config_file_path")

dbutils.widgets.text("source","")
val source=dbutils.widgets.get("source")

dbutils.widgets.text("hospitalfk_field_name","")
val hospitalfk_field_name=dbutils.widgets.get("hospitalfk_field_name")

dbutils.widgets.text("source_col","")
val source_col=dbutils.widgets.get("source_col")

dbutils.widgets.text("temp_op_path","")
val temp_op_path=dbutils.widgets.get("temp_op_path")

dbutils.widgets.text("user","")
val user=dbutils.widgets.get("user")

dbutils.widgets.text("bc","")
val bc=dbutils.widgets.get("bc")

dbutils.widgets.text("wf_source_path","")
val wf_source_path=dbutils.widgets.get("wf_source_path")

dbutils.widgets.text("leadlookupoppath","")
val leadlookupoppath=dbutils.widgets.get("leadlookupoppath")

dbutils.widgets.text("storageaccount","")
val storageaccount=dbutils.widgets.get("storageaccount")

dbutils.widgets.text("notificationtype","")
val notificationtype=dbutils.widgets.get("notificationtype")

// COMMAND ----------

// DBTITLE 1,ADLS Access
// MAGIC %python
// MAGIC dbutils.widgets.text("storageaccount","")
// MAGIC storageaccount=dbutils.widgets.get("storageaccount")
// MAGIC spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

// COMMAND ----------

// MAGIC %run "/Insleads-code/LeadServiceBase/common/LeadServiceBase-Common"

// COMMAND ----------

// DBTITLE 1,Defining mapFile function - get the scource and its source key from the config.txt file
def mapFile(filePath: String): Map[String, String] ={
    val file = spark.read.text(filePath)
    (for {
    row <- file.rdd.collect
    Array(key, value) = row.mkString(",").split(":")
  } yield key -> value).toMap
}

// COMMAND ----------

val hp = hospitalfk_field_name
val mp: Map[String, String] = mapFile(config_file_path)
val source_val = mp.getOrElse(source, null)
val param_val = mp.getOrElse(list_column, null)
val id_column_name = id_column

// COMMAND ----------

// DBTITLE 1,Reading json_demog, lr_xref_xxx_transactionid & lsb_delta_df
val json_demog: DataFrame = getParquetData(hdfs_path + "/" + source + "/" + bc + "/")
val lr_xref_df:DataFrame = spark.read.format("delta").load(store_path)
val lsb_delta_df = spark.read.format("delta").load(deltalake_output)

val temp_op_path_formatted = temp_op_path + "/new_" + list_column + "_" + source + "_lookupvalue/"
val temp_op_path1 = temp_op_path + "/new_" + list_column + "_"  + source + "_maprdbinput/"
val temp_op_path2 = temp_op_path + "/new_" + list_column + "_"  + source + "_insert_response/" + bc + "/"
//lsb and input join 
val temp_op_path3 = temp_op_path + "/new_" + list_column + "_"  + source + "_lsb_join/" + bc + "/"
//before upsert into lsb
val temp_op_path4 = temp_op_path + "/new_" + list_column + "_"  + source + "_map_op/" + bc + "/"

val bad_record_path = temp_op_path + "/bad_record/"  + source + "/" + bc + "/"
val lsb_temp_path = temp_op_path + "/lsb_parquet_temp/" + bc + "/"

// COMMAND ----------

// DBTITLE 1,Defining getReferenceId function 
def getReferenceId(df: DataFrame, list_column: String ,source_val: String, temp_op_path_formatted: String,df1: DataFrame): Unit = {
  val df2 = df.withColumn("sourcekey",lit(source_val))
  val joinkeys_ref = Seq("transactionkey", "sourcekey")
  val df3 =  df2.alias("to_serve").join(df1.alias("df1"),joinkeys_ref).select("to_serve.*",list_column,"xrefsource")
  val df4 = df3.withColumnRenamed(list_column,("lookupvalue"))
  writeParquetData(df4: DataFrame, temp_op_path_formatted: String, "overwrite")
}

// COMMAND ----------

// added getReferenceIdHosp for sharding composite key 
def getReferenceIdHosp(df: DataFrame, list_column: String, source_val: String, temp_op_path_formatted: String, df1: DataFrame): Unit = {
    val df2 = df.withColumn("sourcekey", lit(source_val))
    val joinkeys_ref = Seq("transactionkey", "sourcekey", "hospitalfk")
    val df3 = df2.alias("to_serve").join(df1.alias("df1"), joinkeys_ref).select("to_serve.*", list_column, "xrefsource")
    val df4 = df3.withColumnRenamed(list_column,("lookupvalue"))
    println(temp_op_path_formatted)
    writeParquetData(df4: DataFrame, temp_op_path_formatted: String, "overwrite")
  }


// COMMAND ----------

// DBTITLE 1,Defining getFilteredParquetData function
def getFilteredParquetData(hdfsPath: String, column_to_get: String): DataFrame = {
  val df: DataFrame = spark.read.parquet(hdfsPath).filter(trim(col(column_to_get)) =!= "")
  val df1: DataFrame = df.withColumn(column_to_get, trim(col(column_to_get)))
  return df1
}

// COMMAND ----------

// DBTITLE 1,Defining prepareDeltaLakeTable
def prepareDeltaLakeTable1(df: DataFrame, column_to_get: String, param_val: String, source: String, id_column_name: String, temp_op_path1: String,bad_record_path: String): Unit = {
  val df1 = df.withColumn(column_to_get, concat_ws("_", lit(param_val), col(column_to_get)))

  val df2 = df1.withColumn("new_id", concat_ws("_", col("hcsystemfk"), col("source")))

  val df3 = df2.select(
    col(column_to_get),
    concat_ws(".", lit("demographics"), col("new_id")).alias("demo_id"),
    col("leadid"),
    concat_ws("~",
      col("lookupvalue"),
      concat_ws(".", lit("demographics"), col("new_id")).alias("new_id"),
      col("source"),
      col("new_id").alias("demo_key"),
      col("demographics.firstname"),
      col("demographics.lastname"),
      col("demographics.dob"),
      col("demographics.middlename"),
      col("demographics.gender"),
      col("demographics.updatedate"),
      col("demographics.hospitalfk"),
      col("demographics.ssn").alias("ssn"),
      col("xrefsource").alias("xrefsource"),
      col("demographics.leadsource").alias("leadsource"),
      col("demographics.state").alias("state"),
      col("demographics.createdate").alias("leadcreatedate")
    ).alias("concat_columns"))
    
  val df4 = df3.withColumn("_id", concat_ws("_", col(column_to_get), col("leadid")))

  val df5 = df4.withColumn("new_col",split(col("concat_columns"),"~"))

  val df6 = df5.withColumn("size_new_col",size(col("new_col")))

  val df7 = df6.filter(col("size_new_col") === 16)
  
  val df8 = df6.filter(col("size_new_col") =!= 16)  // bad records

  writeParquetData( df7: DataFrame, temp_op_path1: String, "overwrite")
  writeParquetData( df8: DataFrame, bad_record_path: String, "overwrite")
}

// COMMAND ----------

// DBTITLE 1,Calling the functions - getFilteredParquetData & prepareDeltaLakeTable1
if ((notificationtype == "ie_xref_lsb") || (notificationtype == "es_xref_lsb")) {
  if (list_column == "gmrnid"){
    println("Running for " + notificationtype)
    println("list_column " + list_column)
    //getReferenceId(json_demog, list_column, source_val,temp_op_path_formatted,lr_xref_df)
    val input_df1: DataFrame = getFilteredParquetData(hdfs_path + "/" + source + "/" + bc + "/", column_to_get)
    val input_df2: DataFrame = input_df1.filter("lookupvalue like 'G_%'")
    val input_df3: DataFrame = input_df2.withColumn("lookupvalue", expr("substring(lookupvalue, 3, length(lookupvalue))"))
    prepareDeltaLakeTable1(input_df3, column_to_get, param_val, source, id_column_name, temp_op_path1,bad_record_path)}
  else{
    println("Running for " + notificationtype)
    println("list_column " + list_column)
    val input_df1: DataFrame = getFilteredParquetData(hdfs_path + "/" + source + "/" + bc + "/", column_to_get)
    val input_df2: DataFrame = input_df1.filter("lookupvalue like 'P_%'")
    val input_df3: DataFrame = input_df2.withColumn("lookupvalue", expr("substring(lookupvalue, 3, length(lookupvalue))"))
    prepareDeltaLakeTable1(input_df3, column_to_get, param_val, source, id_column_name, temp_op_path1,bad_record_path)}}
else if (notificationtype == "chc_xref_lsb"){
  println("Running for " + notificationtype)
  getReferenceId(json_demog, list_column, source_val,temp_op_path_formatted,lr_xref_df)
  val input_df1: DataFrame = getFilteredParquetData(temp_op_path_formatted, column_to_get)
  prepareDeltaLakeTable1(input_df1, column_to_get, param_val, source, id_column_name, temp_op_path1,bad_record_path)}
//added the else condition for sharding composite key 
else {
  println("Running for " + notificationtype)
  getReferenceIdHosp(json_demog, list_column, source_val,temp_op_path_formatted,lr_xref_df)
  val input_df1: DataFrame = getFilteredParquetData(temp_op_path_formatted, column_to_get)
  prepareDeltaLakeTable1(input_df1, column_to_get, param_val, source, id_column_name, temp_op_path1,bad_record_path)}

// COMMAND ----------

UpsertIntoLSBTable(num_partition.toInt, deltalake_output, temp_op_path1, source, temp_op_path3, temp_op_path4, lsb_delta_df, leadlookupoppath)

// COMMAND ----------

//spark.sql("SET spark.databricks.delta.retentionDurationCheck.enabled = false")
//val df_raw = DeltaTable.forPath(spark, deltalake_output)
//df_raw.vacuum(0)

// COMMAND ----------

// Number of rows inserted into the target table: 200783
// Number of rows updated in the target table: 1012454
