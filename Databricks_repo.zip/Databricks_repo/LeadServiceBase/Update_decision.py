# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *


# COMMAND ----------

# dbutils.widgets.text('source1','fc')
# source1 = dbutils.widgets.get("source1")

# dbutils.widgets.text('source2','ich')
# source2 = dbutils.widgets.get("source2")

# dbutils.widgets.text('bc','20230731T21')
# bc = dbutils.widgets.get("bc")

# dbutils.widgets.text('hdfs_source_path','abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/data/leadrepo/publish/toserve/gmrn/')
# hdfs_source_path = dbutils.widgets.get("hdfs_source_path")

# COMMAND ----------

dbutils.widgets.text('source_fc','')
source1 = dbutils.widgets.get("source_fc")

dbutils.widgets.text('source_ich','')
source2 = dbutils.widgets.get("source_ich")

dbutils.widgets.text('bc','')
bc = dbutils.widgets.get("bc")

dbutils.widgets.text('hdfs_source_path','')
hdfs_source_path = dbutils.widgets.get("hdfs_source_path")

# COMMAND ----------

dbutils.widgets.text('storageaccount','')
storageaccount = dbutils.widgets.get("storageaccount")
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

fc_source_path = hdfs_source_path + bc + "/source=" + source1
ich_source_path = hdfs_source_path + bc + "/source=" + source2

print("fc_source_path: " + fc_source_path)
print("ich_source_path: " + ich_source_path)

# COMMAND ----------

def file_exists(path):
  try:
    dbutils.fs.ls(path)
    return True
  except Exception as e:
    if 'java.io.FileNotFoundException' in str(e):
      return False
    else:
      raise

# COMMAND ----------

fc_path_decision = file_exists(fc_source_path)
ich_path_decision = file_exists(ich_source_path)

# COMMAND ----------

print(fc_path_decision)
print(ich_path_decision)

# COMMAND ----------

if fc_path_decision is True:
    fc_path_decision = "fc"
if ich_path_decision is True:
    ich_path_decision = "ich"

# COMMAND ----------

print(fc_path_decision)
print(ich_path_decision)

# COMMAND ----------

import json
dict={"fc":fc_path_decision,"ich":ich_path_decision}
jsondict=json.dumps(dict)
dbutils.notebook.exit(jsondict)