// Databricks notebook source
// MAGIC %md 
// MAGIC this notebook performs activities from PopulateLsbLeadsReference.scala

// COMMAND ----------

import org.apache.spark.sql.{DataFrame}
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._
import scala.io.Source
import scala.collection._
import java.time.format.DateTimeFormatter
import java.time.LocalDate
import java.time.LocalDateTime
import io.delta.tables._
import spark.implicits._
import org.apache.spark.sql.expressions.{Window, WindowSpec}
import org.apache.spark.sql.types._
import org.apache.spark.sql.Column
import org.apache.spark.sql.expressions.UserDefinedFunction

// COMMAND ----------

// DBTITLE 1,adls access
// MAGIC %python
// MAGIC dbutils.widgets.text("storageaccount","")
// MAGIC storageaccount=dbutils.widgets.get("storageaccount")
// MAGIC spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

// COMMAND ----------

// DBTITLE 1,Input Parameters
// dbutils.widgets.text("hdfs_path","abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/divya/data/leadrepo/scratch/leadservicebase/json_demog/")
// val hdfs_path=dbutils.widgets.get("hdfs_path")

// dbutils.widgets.text("deltalake_output","abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/divya/data/test_leadrepo/publish/served/leadservicebase_updateLsbLeadsRef")
// val deltalake_output=dbutils.widgets.get("deltalake_output")

// dbutils.widgets.text("column_to_get","lookupvalue")
// val column_to_get=dbutils.widgets.get("column_to_get")

// dbutils.widgets.text("list_column","gmrnid")
// val list_column=dbutils.widgets.get("list_column")

// dbutils.widgets.text("config_file_path","abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/data/leadservicebase/leadservicebase_create/config.txt")
// val config_file_path=dbutils.widgets.get("config_file_path")

// dbutils.widgets.text("source","fc")
// val source=dbutils.widgets.get("source")

// dbutils.widgets.text("num_partition","2500")
// val num_partition=dbutils.widgets.get("num_partition").toInt

// dbutils.widgets.text("temp_op_path","abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/divya/data/leadrepo/scratch/leadservicebase/")
// val temp_op_path=dbutils.widgets.get("temp_op_path")

// dbutils.widgets.text("bc","20230827T19")
// val bc=dbutils.widgets.get("bc")

// dbutils.widgets.text("leadlookupoppath","abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/divya/data/leadrepo/publish/cooked/leadservicebasehelper/")
// val leadlookupoppath=dbutils.widgets.get("leadlookupoppath")

// COMMAND ----------

dbutils.widgets.text("hdfs_path","")
val hdfs_path=dbutils.widgets.get("hdfs_path")

dbutils.widgets.text("deltalake_output","")
val deltalake_output=dbutils.widgets.get("deltalake_output")

dbutils.widgets.text("column_to_get","")
val column_to_get=dbutils.widgets.get("column_to_get")

dbutils.widgets.text("list_column","")
val list_column=dbutils.widgets.get("list_column")

dbutils.widgets.text("config_file_path","")
val config_file_path=dbutils.widgets.get("config_file_path")

dbutils.widgets.text("source","")
val source=dbutils.widgets.get("source")

dbutils.widgets.text("num_partition","")
val num_partition=dbutils.widgets.get("num_partition").toInt

dbutils.widgets.text("temp_op_path","")
val temp_op_path=dbutils.widgets.get("temp_op_path")

dbutils.widgets.text("bc","")
val bc=dbutils.widgets.get("bc")

dbutils.widgets.text("leadlookupoppath","")
val leadlookupoppath=dbutils.widgets.get("leadlookupoppath")

// COMMAND ----------

// MAGIC %run "/Insleads-code/LeadServiceBase/common/LeadServiceBase-Common"

// COMMAND ----------

// DBTITLE 1,Reading json_demog, lr_xref_xxx_transactionid & lsb_delta_df
val json_demog: DataFrame = getParquetData(hdfs_path + "/" + source + "/" + bc + "/")
val lsb_delta_df = spark.read.format("delta").load(deltalake_output)

// val temp_op_path_new = temp_op_path + "updateLsbLeadsRef/" + list_column + "/" + source + "_update/" + bc + "/"
//val temp_update_path = temp_op_path_new + "updated_trans/"
// val temp_delete_path = temp_op_path_new + "deleted_trans/"


val temp_op_path1 = temp_op_path + "updateLsbLeadsRef/" + list_column + "/" + source + "_update_prep/" + bc + "/"
val temp_op_path2 = temp_op_path + "updateLsbLeadsRef/" + list_column + "/"+ source + "_delete_prep/" + bc + "/"
//lsb and input join 
val temp_op_path3 = temp_op_path + "updateLsbLeadsRef/" + list_column + "/"+ source + "_lsb_join/" + bc + "/"
//before upsert into lsb
val temp_op_path4 = temp_op_path + "updateLsbLeadsRef/" + list_column + "/" + source + "_map_op/" + bc + "/"

// COMMAND ----------

// DBTITLE 1,Defining mapFile function - get the scource and its source key from the config.txt file
def mapFile(filePath: String): Map[String, String] ={
    val file = spark.read.text(filePath)
    (for {
    row <- file.rdd.collect
    Array(key, value) = row.mkString(",").split(":")
  } yield key -> value).toMap
}

// COMMAND ----------

val mp: Map[String, String] = mapFile(config_file_path)
val source_val = mp.getOrElse(source, null)
val param_val = mp.getOrElse(list_column, null)

// COMMAND ----------

// DBTITLE 1,Defining prepareDeltaLakeTable1
def prepareDeltaLakeTable1(json_demog: DataFrame, column_to_get: String, param_val: String, source: String, temp_op_path1: String, temp_op_path2: String): Unit = {
  //isert and update
  val df1 = json_demog.withColumn("lookupvalue", concat_ws("_", lit(param_val), col("toglobalmrn")))
  val df2 = df1.withColumn("new_id", concat_ws("_", col("hcsystemfk"), col("source")))
  val df3 = df2.select(
    col(column_to_get),
    concat_ws(".", lit("demographics"), col("new_id")).alias("demo_id"),
    col("leadid"),
    concat_ws("~",
      col("lookupvalue"),
      concat_ws(".", lit("demographics"), col("new_id")).alias("new_id"),
      col("source"),
      col("new_id").alias("demo_key"),
      col("demographics.firstname"),
      col("demographics.lastname"),
      col("demographics.dob"),
      col("demographics.middlename"),
      col("demographics.gender"),
      col("demographics.updatedate"),
      col("demographics.hospitalfk"),
      col("demographics.ssn").alias("ssn"),
      col("xrefsource").alias("xrefsource"),
      col("demographics.leadsource").alias("leadsource"),
      col("demographics.state").alias("state"),
      col("demographics.createdate").alias("leadcreatedate")
    ).alias("concat_columns"))
  val df4 = df3.withColumn("_id", concat_ws("_", col(column_to_get), col("leadid")))
  val df5 = df4.withColumn("new_col",split(col("concat_columns"),"~"))

  val df6 = df5.withColumn("size_new_col",size(col("new_col")))
  writeParquetData( df5: DataFrame, temp_op_path1: String, "overwrite")

  // prep delete transaction
  val df21 = df2.withColumn("old_lookupvalue", concat_ws("_", lit(param_val), col("fromglobalmrn")))
  val df22 = df21.withColumn("_id", concat_ws("_", col("old_lookupvalue"), col("leadid")))
  
  val distinctIdValues = df22.select("_id").distinct()
  val matching_id_df  = lsb_delta_df.alias("lsb").join(distinctIdValues,Seq("_id"),"inner").select("lsb._id")

  // print("Count of matching _id's for deletion : " + matching_id_df.count())
 
  val df23 = df22.join(matching_id_df,Seq("_id"),"inner").select(df22("*"))
  writeParquetData(df23: DataFrame, temp_op_path2: String, "overwrite")

}

// COMMAND ----------

// DBTITLE 1,Calling the functions - prepareDeltaLakeTable1
prepareDeltaLakeTable1(json_demog: DataFrame, column_to_get: String, param_val: String, source: String, temp_op_path1: String, temp_op_path2: String)

// COMMAND ----------

UpsertIntoLSBTable(num_partition.toInt, deltalake_output, temp_op_path1, source, temp_op_path3, temp_op_path4, lsb_delta_df, leadlookupoppath)

// Number of rows inserted into the target table: 1711
// Number of rows updated in the target table: 1469


// COMMAND ----------

def finalDeleteFromLSBTable(deltalake_output:String, temp_op_path2:String) : Unit ={
  val deltaTableLSB = DeltaTable.forPath(spark, deltalake_output)
  val delete_id_df = getParquetData(temp_op_path2).select("_id")

  deltaTableLSB.as("lsb").merge(delete_id_df.alias("delete_df"), "lsb._id = delete_df._id")
        .whenMatched()
        .delete()
        .execute()
  
  val lastOperationDF = deltaTableLSB.history(1)
  println("Number of rows deleted from the target table: " + 
                    lastOperationDF.select($"operationMetrics.numTargetRowsDeleted").as[String].head)
}

// COMMAND ----------

finalDeleteFromLSBTable(deltalake_output, temp_op_path2)

// COMMAND ----------

//spark.sql("SET spark.databricks.delta.retentionDurationCheck.enabled = false")
//val df_raw = DeltaTable.forPath(spark, deltalake_output)
//df_raw.vacuum(0)