# Databricks notebook source
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql import Row
import datetime
from pyspark.sql import *
from pyspark.sql import functions as F
from pyspark.sql.readwriter import *
import os
import subprocess

# COMMAND ----------

# dbutils.widgets.text("input_source","fc")
# input_source=dbutils.widgets.get("input_source")

# dbutils.widgets.text("input_breadcrumb","20230731T21")
# input_breadcrumb=dbutils.widgets.get("input_breadcrumb")

# dbutils.widgets.text("input_base_tables","abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/data/escan_data_ingestion/")
# input_base_tables=dbutils.widgets.get("input_base_tables")

# dbutils.widgets.text("input_lr_transaction","abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/data/leadrepo/publish/cooked/lr_transaction_new/")
# input_lr_transaction=dbutils.widgets.get("input_lr_transaction")

# dbutils.widgets.text("input_toserve","abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/data/leadrepo/publish/toserve/")
# input_toserve=dbutils.widgets.get("input_toserve")

# dbutils.widgets.text("output_demographics","abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/data/leadrepo/scratch/leadservicebase/json_demog/")
# output_demographics=dbutils.widgets.get("output_demographics")

# COMMAND ----------

dbutils.widgets.text("input_source","")
input_source=dbutils.widgets.get("input_source")

dbutils.widgets.text("input_breadcrumb","")
input_breadcrumb=dbutils.widgets.get("input_breadcrumb")

dbutils.widgets.text("input_base_tables","")
input_base_tables=dbutils.widgets.get("input_base_tables")

dbutils.widgets.text("input_lr_transaction","")
input_lr_transaction=dbutils.widgets.get("input_lr_transaction")

dbutils.widgets.text("input_toserve","")
input_toserve=dbutils.widgets.get("input_toserve")

dbutils.widgets.text("output_demographics","")
output_demographics=dbutils.widgets.get("output_demographics")

dbutils.widgets.text("storageaccount","")
storageaccount=dbutils.widgets.get("storageaccount")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)

# COMMAND ----------

# DERVIED INPUT -OUTPUT 
input_toserve = input_toserve + "gmrn/" + input_breadcrumb
input_patientaccts = input_base_tables + "/" + "/patientaccts/current/20991231/"
input_hospitals = input_base_tables + "/" + "/hospitals/current/20991231/"
input_hcsystems = input_base_tables + "/" + "/hcsystems/current/20991231/"
input_edipayers_tupayeridmapping = input_base_tables + "/" + "/edipayers_tupayeridmapping/current/20991231/"
input_edipartner = input_base_tables + "/" + "/edipartners/current/20991231/"
output_demographics = output_demographics + "/" + input_breadcrumb

# COMMAND ----------

output_demographics

# COMMAND ----------

if input_source == "ich":
    source_id = '2'
elif input_source == "fc":
    source_id = '1'
elif input_source == "chc":
    source_id = '3'
else:
    source_id = '0'

print("input_source : " + input_source + " : " + str(source_id))
p_factor = 5

# COMMAND ----------

to_serve_filter = "source==" + "'" + input_source + "'"
print("input_toserve" + input_toserve)
df_toserve = spark.read.parquet(input_toserve).selectExpr("transactionkey", "fromglobalmrn", "toglobalmrn", "xrefsource")
df_toserve = df_toserve.withColumn("transactionkey", trim("transactionkey"))
df_toserve = df_toserve.withColumn("transactionrange", (col("transactionkey").cast("bigint") % p_factor).cast("bigint"))
df_toserve = df_toserve.filter(to_serve_filter).dropDuplicates()
df_toserve.createOrReplaceTempView("df_toserve")

# COMMAND ----------

# df_patientaccts = spark.read.parquet(input_patientaccts).selectExpr("patientacctipk", "hospitalfk", "clusteredacctfk").dropDuplicates()
df_patientaccts = spark.read.format('delta').load(input_patientaccts).selectExpr("patientacctipk", "hospitalfk", "clusteredacctfk").dropDuplicates()
df_patientaccts.createOrReplaceTempView("df_patientaccts")
df_hospitals = spark.read.parquet(input_hospitals).selectExpr("hospitalpk as hospitalfk", "hcsystemfk").dropDuplicates()
df_hcsystems = spark.read.parquet(input_hcsystems).selectExpr("hcsystempk as hcsystemfk").dropDuplicates()
df_hospitals_x_hcsystems = df_hospitals.join(df_hcsystems, "hcsystemfk", "inner").select("hospitalfk", "hcsystemfk").dropDuplicates()
df_hospitals_x_hcsystems.createOrReplaceTempView("df_hospitals_x_hcsystems")

# COMMAND ----------

lr_transaction_filter = "sourcekey==" + "'" + source_id + "'"
df_lr_transaction = spark.read.parquet(input_lr_transaction).filter(lr_transaction_filter)
df_lr_transaction.createOrReplaceTempView("df_lr_transaction")

# COMMAND ----------

df_lr_transaction = df_lr_transaction.selectExpr("transactionkey",
                                                 "transactionrange",
                                                 "coverageid",
                                                 "payerid",
                                                 "firstname",
                                                 "middlename",
                                                 "lastname",
                                                 "dob",
                                                 "ssn",
                                                 "gender",
                                                 "state",
                                                 "createdate",
                                                 "updatedate",
                                                 "clientid",
                                                 "dependentflag",
                                                 "verifiedsource as leadsource",
                                                 "sourcepatientacctifk as patientacctipk").dropDuplicates()
df_lr_transaction.createOrReplaceTempView("df_lr_transaction")

# COMMAND ----------

df_lr_transaction_x_toserve = spark.sql("""
SELECT df_lr_transaction.transactionkey,
       df_lr_transaction.coverageid,
       df_lr_transaction.payerid,
       df_lr_transaction.firstname,
       df_lr_transaction.middlename,
       df_lr_transaction.lastname,
       df_lr_transaction.dob,
       df_lr_transaction.ssn,
       df_lr_transaction.gender,
       df_lr_transaction.state,
       df_lr_transaction.createdate,
       df_lr_transaction.updatedate,
       df_lr_transaction.clientid,
       CASE WHEN (TRIM(df_lr_transaction.clientid) IS NULL OR 
                  TRIM(df_lr_transaction.clientid) =''     OR 
                  TRIM(df_lr_transaction.clientid)=' ')    OR 
                  TRIM(df_lr_transaction.clientid)= 'null'
                  THEN '0' ELSE '1' END AS isValidclientid,
       df_lr_transaction.dependentflag,
       df_lr_transaction.leadsource,
       df_lr_transaction.patientacctipk,
       df_toserve.fromglobalmrn,
       df_toserve.toglobalmrn,
       df_toserve.xrefsource
FROM df_lr_transaction
  INNER JOIN df_toserve
          ON 
          CAST (df_lr_transaction.transactionrange AS BIGINT) = CAST (df_toserve.transactionrange AS BIGINT) AND
          CAST (trim(df_lr_transaction.transactionkey) AS BIGINT) = CAST (trim(df_toserve.transactionkey) AS BIGINT)
""").withColumn("bc", lit(input_breadcrumb)).filter("isValidclientid='1'").drop("isValidclientid").dropDuplicates()

# COMMAND ----------

df_lr_transaction_x_toserve.createOrReplaceTempView("df_lr_transaction_x_toserve")

# COMMAND ----------

cleansing_sql_01 = """
SELECT A.*,
       CONCAT(A.payerid,"_",A.coverageid) AS leadid,
       CASE
         WHEN (A.firstname IS NULL AND A.lastname IS NULL AND A.dob IS NULL AND A.ssn IS NULL AND A.gender IS NULL) THEN '0'
         ELSE '1'
       END AS isdemovalid,
       CASE WHEN LENGTH(TRIM(A.dob)) > 9
            THEN CAST(
               concat(
                      date_format(A.dob,'yyyy'),"-",
                      date_format(A.dob,'MM'),"-",
                      date_format(A.dob,'dd')
                      ) AS STRING)
            ELSE
                CAST(
                      concat(
                             SUBSTR(A.dob,1,4),"-",
                             SUBSTR(A.dob,5,2),"-",
                             SUBSTR(A.dob,7,2)
                             ) AS STRING)
            END AS formated_dob,
       CAST(regexp_replace (regexp_replace (regexp_replace (regexp_replace ((SPLIT (A.createdate,"\\\.")[0]),"T",""),":",""),"-","")," ","") AS BIGINT) AS createdate_as_bigint,
       CAST(regexp_replace (regexp_replace (regexp_replace (regexp_replace ((SPLIT (A.updatedate,"\\\.")[0]),"T",""),":",""),"-","")," ","") AS BIGINT) AS updatedate_as_bigint
FROM df_lr_transaction_x_toserve A
"""

# COMMAND ----------

df_lr_transaction_x_toserve = spark.sql(cleansing_sql_01)

# COMMAND ----------

df_lr_transaction_x_toserve = df_lr_transaction_x_toserve.filter("isdemovalid = 1").filter("coverageid != ''").filter("payerid != ''").dropDuplicates()

# COMMAND ----------

for column in df_lr_transaction_x_toserve.columns:
    df_lr_transaction_x_toserve = df_lr_transaction_x_toserve.withColumn(column, regexp_replace(col(column),'\\\\',''))
    df_lr_transaction_x_toserve = df_lr_transaction_x_toserve.withColumn(column, regexp_replace(col(column),'@',''))
    df_lr_transaction_x_toserve = df_lr_transaction_x_toserve.withColumn(column, regexp_replace(col(column),'~',''))

# COMMAND ----------

df_lr_transaction_x_toserve.createOrReplaceTempView("df_lr_transaction_x_toserve")

# COMMAND ----------

cleansing_sql_02 = """               
SELECT
      A.transactionkey,
      A.leadid,
      A.coverageid,
      A.payerid,
      A.firstname,
      A.middlename,
      A.lastname,
      A.formated_dob,
      A.ssn,
      A.gender,
      A.state,
      A.clientid,
      A.dependentflag,
      A.bc,
      A.patientacctipk,
      A.leadsource,
      A.createdate_as_bigint,
      A.updatedate_as_bigint,
      CASE WHEN LENGTH(A.createdate_as_bigint) >= 14 THEN '1' ELSE '0' END AS isDateValid,
      A.fromglobalmrn,
      A.toglobalmrn,
      A.xrefsource,
      CAST(CONCAT(
                  SUBSTR(A.createdate_as_bigint,1,4),"-",
                  SUBSTR(A.createdate_as_bigint,5,2),"-",
                  SUBSTR(A.createdate_as_bigint,7,2)," ",
                  SUBSTR(A.createdate_as_bigint,9,2),":",
                  SUBSTR(A.createdate_as_bigint,11,2),":",
                  SUBSTR(A.createdate_as_bigint,13,2)
                  ) AS STRING) AS createdate,
      CAST(CONCAT(
                  SUBSTR(A.updatedate_as_bigint,1,4),"-",
                  SUBSTR(A.updatedate_as_bigint,5,2),"-",
                  SUBSTR(A.updatedate_as_bigint,7,2)," ",
                  SUBSTR(A.updatedate_as_bigint,9,2),":",
                  SUBSTR(A.updatedate_as_bigint,11,2),":",
                  SUBSTR(A.updatedate_as_bigint,13,2)
                  ) AS STRING) AS updatedate,
      A.isdemovalid
      FROM df_lr_transaction_x_toserve A
      """


# COMMAND ----------

df_lr_transaction_x_toserve = spark.sql(cleansing_sql_02).filter("isDateValid = '1'").drop("isDateValid").filter("coverageid != ''").filter("payerid != ''").dropDuplicates()

# COMMAND ----------

df_lr_transaction_x_toserve=df_lr_transaction_x_toserve.withColumnRenamed("formated_dob","dob")

# COMMAND ----------

df_lr_transaction_x_toserve.createOrReplaceTempView("df_lr_transaction_x_toserve")

if (input_source == "ich") | (input_source == "chc"):
    print("input_source   : " + input_source)
    df_edipayers_tupayeridmapping = spark.read.parquet(input_edipayers_tupayeridmapping).select("tupayerid", "edipayerfk").dropDuplicates()
    df_edipartner = spark.read.parquet(input_edipartner).filter("isenabledflag=='1'").filter("edipartnerpk > 0").select("edipayerfk", "edipartnerpk").dropDuplicates()
    df_edipartner_tu = df_edipayers_tupayeridmapping.join(df_edipartner, 'edipayerfk').selectExpr("CAST(tupayerid AS int) AS tupayerid", "edipartnerpk AS edipartnerfk")
    cond1 = when(col("tupayerid") == 10102, lit(30)).otherwise(col("edipartnerfk"))
    cond2 = when(col("tupayerid") == 10001, lit(82)).otherwise(col("edipartnerfk"))
    cond3 = when(col("tupayerid") == 10055, lit(8)).otherwise(col("edipartnerfk"))
    cond4 = when(col("tupayerid") == 10285, lit(71)).otherwise(col("edipartnerfk"))
    cond5 = when(col("tupayerid") == 11174, lit(479)).otherwise(col("edipartnerfk"))
    cond6 = when(col("tupayerid") == 11196, lit(547)).otherwise(col("edipartnerfk"))
    cond7 = when(col("tupayerid") == 10118, lit(91)).otherwise(col("edipartnerfk"))
    df_edipartner_tu = df_edipartner_tu.withColumn("edipartnerfk", cond1)
    df_edipartner_tu = df_edipartner_tu.withColumn("edipartnerfk", cond2)
    df_edipartner_tu = df_edipartner_tu.withColumn("edipartnerfk", cond3)
    df_edipartner_tu = df_edipartner_tu.withColumn("edipartnerfk", cond4)
    df_edipartner_tu = df_edipartner_tu.withColumn("edipartnerfk", cond5)
    df_edipartner_tu = df_edipartner_tu.withColumn("edipartnerfk", cond6)
    df_edipartner_tu = df_edipartner_tu.withColumn("edipartnerfk", cond7).dropDuplicates()
    df_edipartner_tu = df_edipartner_tu.selectExpr("edipartnerfk").dropDuplicates()
    df_edipartner_tu.createOrReplaceTempView("df_edipartner_tu")
    df_lr_transaction_x_toserve = df_lr_transaction_x_toserve.withColumn("hospitalfk", col("clientid")).withColumn("source", lit(input_source))
    df_lr_transaction_x_toserve.createOrReplaceTempView("df_lr_transaction_x_toserve")
    df_lr_transaction_x_toserve = spark.sql(""" SELECT d.*,
    CASE WHEN (TRIM(d.updatedate) IS NULL OR TRIM(d.updatedate) = '' OR TRIM(d.updatedate) = ' ') THEN TRIM(d.createdate) ELSE TRIM(d.updatedate) END AS updatedate_new FROM df_lr_transaction_x_toserve d
    """).drop("updatedate").withColumnRenamed("updatedate_new", "updatedate")
    df_lr_transaction_x_toserve.createOrReplaceTempView("df_lr_transaction_x_toserve")
    df_lr_transaction_x_toserve = spark.sql(""" SELECT * FROM df_lr_transaction_x_toserve WHERE payerid in (select DISTINCT edipartnerfk from df_edipartner_tu) """)
    df_lr_transaction_x_toserve.createOrReplaceTempView("df_lr_transaction_x_toserve")
    df_lr_transaction_x_toserve = spark.sql("""
                      SELECT
                      A.transactionkey,
                      A.leadid,
                      A.coverageid,
                      A.payerid,
                      A.firstname,
                      A.middlename,
                      A.lastname,
                      A.dob,
                      A.ssn,
                      A.state,
                      A.gender,
                      A.dependentflag,
                      A.clientid ,
                      A.bc,
                      A.createdate_as_bigint,
                      A.createdate,
                      A.createdate as createdate_min,
                      A.updatedate as updatedate_max,
                      A.hospitalfk,
                      A.source,A.fromglobalmrn,A.toglobalmrn,A.xrefsource,
                      A.leadsource,
                      A.isdemovalid
               FROM df_lr_transaction_x_toserve A
    """).dropDuplicates()
    df_lr_transaction_x_toserve.createOrReplaceTempView("df_lr_transaction_x_toserve")
    df_lr_transaction_x_toserve = spark.sql("""
    SELECT d.transactionkey,
       d.leadid,
       d.isdemovalid,
       d.dependentflag,
       d.createdate_as_bigint,
       d.fromglobalmrn,
       d.toglobalmrn,
       d.xrefsource,
	   CASE WHEN (TRIM(d.clientid)   IS NULL OR TRIM(d.clientid) = ''   OR TRIM(d.clientid) = ' ')   THEN '' ELSE TRIM(d.clientid)   END AS hcsystemfk,
       CASE WHEN (TRIM(d.hospitalfk) IS NULL OR TRIM(d.hospitalfk) = '' OR TRIM(d.hospitalfk) = ' ') THEN '' ELSE TRIM(d.hospitalfk) END AS hospitalfk,
       CASE WHEN (TRIM(d.leadsource) IS NULL OR TRIM(d.leadsource) = '' OR TRIM(d.leadsource) = ' ') THEN '' ELSE TRIM(d.leadsource) END AS leadsource,
       CASE WHEN (TRIM(d.source)     IS NULL OR TRIM(d.source) = ''     OR TRIM(d.source) = ' ')     THEN '' ELSE TRIM(d.source)     END AS source,
       CASE WHEN (TRIM(d.bc)         IS NULL OR TRIM(d.bc) = ''         OR TRIM(d.bc) = ' ')         THEN '' ELSE TRIM(d.bc)         END AS bc,
       STRUCT(
              CASE WHEN (TRIM(d.firstname)      IS NULL OR TRIM(d.firstname) = ''      OR TRIM(d.firstname) = ' ')      THEN ''                     ELSE TRIM(d.firstname)      END AS firstname,
              CASE WHEN (TRIM(d.middlename)     IS NULL OR TRIM(d.middlename) = ''     OR TRIM(d.middlename) = ' ')     THEN ''                     ELSE TRIM(d.middlename)     END AS middlename,
              CASE WHEN (TRIM(d.lastname)       IS NULL OR TRIM(d.lastname) = ''       OR TRIM(d.lastname) = ' ')       THEN ''                     ELSE TRIM(d.lastname)       END AS lastname,
              CASE WHEN (TRIM(d.dob)            IS NULL OR TRIM(d.dob) = ''            OR TRIM(d.dob) = ' ')            THEN ''                     ELSE TRIM(d.dob)            END AS dob,
              CASE WHEN (TRIM(d.ssn)            IS NULL OR TRIM(d.ssn) = ''            OR TRIM(d.ssn) = ' ')            THEN ''                     ELSE TRIM(d.ssn)            END AS ssn,
              CASE WHEN (TRIM(d.state)          IS NULL OR TRIM(d.state) = ''          OR TRIM(d.state) = ' ')          THEN ''                     ELSE TRIM(d.state)          END AS state,
              CASE WHEN (TRIM(d.dependentflag)  IS NULL OR TRIM(d.dependentflag) = ''  OR TRIM(d.dependentflag) = ' ')  THEN ''                     ELSE TRIM(d.dependentflag)  END AS dependentflag,
              CASE WHEN (TRIM(d.gender)         IS NULL OR TRIM(d.gender) = ''         OR TRIM(d.gender) = ' ')         THEN ''                     ELSE TRIM(d.gender)         END AS gender,
              CASE WHEN (TRIM(d.createdate_min) IS NULL OR TRIM(d.createdate_min) = '' OR TRIM(d.createdate_min) = ' ') THEN ''                     ELSE TRIM(d.createdate_min) END AS createdate,
              CASE WHEN (TRIM(d.leadsource)     IS NULL OR TRIM(d.leadsource) = ''     OR TRIM(d.leadsource) = ' ')     THEN ''                     ELSE TRIM(d.leadsource)     END AS leadsource,
              CASE WHEN (TRIM(d.updatedate_max) IS NULL OR TRIM(d.updatedate_max) = '' OR TRIM(d.updatedate_max) = ' ') THEN TRIM(d.createdate_min) ELSE TRIM(d.updatedate_max) END AS updatedate,
              CASE WHEN (TRIM(d.hospitalfk)     IS NULL OR TRIM(d.hospitalfk) = ''     OR TRIM(d.bc) = ' ')             THEN ''                     ELSE TRIM(d.hospitalfk)     END AS hospitalfk,
              CASE WHEN (TRIM(d.clientid)       IS NULL OR TRIM(d.clientid) = ''       OR TRIM(d.clientid) = ' ')       THEN ''                     ELSE TRIM(d.clientid)       END AS hcsystemfk,
              CASE WHEN (TRIM(d.bc)             IS NULL OR TRIM(d.bc) = ''             OR TRIM(d.bc) = ' ')             THEN ''                     ELSE TRIM(d.bc)             END AS bc,
              CASE WHEN (TRIM(d.source)         IS NULL OR TRIM(d.source) = ''         OR TRIM(d.source) = ' ')         THEN ''                     ELSE TRIM(d.source)         END AS source
              ) AS demographics
    FROM df_lr_transaction_x_toserve d 
    """)
    df_lr_transaction_x_toserve.repartition(20).write.mode("overwrite").parquet(output_demographics)
elif input_source == "fc":
    print("input_source   : " + input_source)
    df_lr_transaction_x_toserve = df_lr_transaction_x_toserve.withColumnRenamed("clientid", "hospitalfk").withColumn("source", lit(input_source))
    df_lr_transaction_x_toserve.createOrReplaceTempView("df_lr_transaction_x_toserve")
    df_lr_transaction_x_toserve = spark.sql("""
                                             SELECT d.transactionkey,
                                                d.leadid,
                                                d.isdemovalid,
                                                d.dependentflag,
                                                d.createdate_as_bigint,
                                                d.updatedate_as_bigint,
                                                d.fromglobalmrn,
                                                d.toglobalmrn,
                                                d.xrefsource,
                                                d.patientacctipk,
                                                CASE WHEN (TRIM(d.createdate) IS NULL OR TRIM(d.createdate) = '' OR TRIM(d.createdate) = ' ') THEN ''                 ELSE TRIM(d.createdate) END AS createdate,
                                                CASE WHEN (TRIM(d.updatedate) IS NULL OR TRIM(d.updatedate) = '' OR TRIM(d.updatedate) = ' ') THEN TRIM(d.createdate) ELSE TRIM(d.updatedate) END AS updatedate,
                                                CASE WHEN (TRIM(h.hcsystemfk) IS NULL OR TRIM(h.hcsystemfk) = '' OR TRIM(h.hcsystemfk) = ' ') THEN ''                 ELSE TRIM(h.hcsystemfk) END AS hcsystemfk,
                                                CASE WHEN (TRIM(d.hospitalfk) IS NULL OR TRIM(d.hospitalfk) = '' OR TRIM(d.hospitalfk) = ' ') THEN ''                 ELSE TRIM(h.hospitalfk) END AS hospitalfk,
                                                CASE WHEN (TRIM(d.leadsource) IS NULL OR TRIM(d.leadsource) = '' OR TRIM(d.leadsource) = ' ') THEN ''                 ELSE TRIM(d.leadsource) END AS leadsource,
                                                CASE WHEN (TRIM(d.source)     IS NULL OR TRIM(d.source) = ''     OR TRIM(d.source) = ' ')     THEN ''                 ELSE TRIM(d.source)     END AS source,
                                                CASE WHEN (TRIM(d.bc)         IS NULL OR TRIM(d.bc) = ''         OR TRIM(d.bc) = ' ')         THEN ''                 ELSE TRIM(d.bc)         END AS bc,
                                                STRUCT(
                                                       CASE WHEN (TRIM(d.firstname)     IS NULL OR TRIM(d.firstname) = ''     OR TRIM(d.firstname) = ' ')     THEN ''                 ELSE TRIM(d.firstname)     END AS firstname,
                                                       CASE WHEN (TRIM(d.middlename)    IS NULL OR TRIM(d.middlename) = ''    OR TRIM(d.middlename) = ' ')    THEN ''                 ELSE TRIM(d.middlename)    END AS middlename,
                                                       CASE WHEN (TRIM(d.lastname)      IS NULL OR TRIM(d.lastname) = ''      OR TRIM(d.lastname) = ' ')      THEN ''                 ELSE TRIM(d.lastname)      END AS lastname,
                                                       CASE WHEN (TRIM(d.dob)           IS NULL OR TRIM(d.dob) = ''           OR TRIM(d.dob) = ' ')           THEN ''                 ELSE TRIM(d.dob)           END AS dob,
                                                       CASE WHEN (TRIM(d.ssn)           IS NULL OR TRIM(d.ssn) = ''           OR TRIM(d.ssn) = ' ')           THEN ''                 ELSE TRIM(d.ssn)           END AS ssn,
                                                       CASE WHEN (TRIM(d.state)         IS NULL OR TRIM(d.state) = ''         OR TRIM(d.state) = ' ')         THEN ''                 ELSE TRIM(d.state)         END AS state,
                                                       CASE WHEN (TRIM(d.dependentflag) IS NULL OR TRIM(d.dependentflag) = '' OR TRIM(d.dependentflag) = ' ') THEN ''                 ELSE TRIM(d.dependentflag) END AS dependentflag,
                                                       CASE WHEN (TRIM(d.gender)        IS NULL OR TRIM(d.gender) = ''        OR TRIM(d.gender) = ' ')        THEN ''                 ELSE TRIM(d.gender)        END AS gender,
                                                       CASE WHEN (TRIM(d.createdate)    IS NULL OR TRIM(d.createdate) = ''    OR TRIM(d.createdate) = ' ')    THEN ''                 ELSE TRIM(d.createdate)    END AS createdate,
                                                       CASE WHEN (TRIM(d.leadsource)    IS NULL OR TRIM(d.leadsource) = ''    OR TRIM(d.leadsource) = ' ')    THEN ''                 ELSE TRIM(d.leadsource)    END AS leadsource,
                                                       CASE WHEN (TRIM(d.updatedate)    IS NULL OR TRIM(d.updatedate) = ''    OR TRIM(d.updatedate) = ' ')    THEN TRIM(d.createdate) ELSE TRIM(d.updatedate)    END AS updatedate,
                                                       CASE WHEN (TRIM(d.hospitalfk)    IS NULL OR TRIM(d.hospitalfk) = ''    OR TRIM(d.bc) = ' ')            THEN ''                 ELSE TRIM(d.hospitalfk)    END AS hospitalfk,
                                                       CASE WHEN (TRIM(h.hcsystemfk)    IS NULL OR TRIM(h.hcsystemfk) = ''    OR TRIM(h.hcsystemfk) = ' ')    THEN ''                 ELSE TRIM(h.hcsystemfk)    END AS hcsystemfk,
                                                       CASE WHEN (TRIM(d.bc)            IS NULL OR TRIM(d.bc) = ''            OR TRIM(d.bc) = ' ')            THEN ''                 ELSE TRIM(d.bc)            END AS bc,
                                                       CASE WHEN (TRIM(d.source)        IS NULL OR TRIM(d.source) = ''        OR TRIM(d.source) = ' ')        THEN ''                 ELSE TRIM(d.source)        END AS source
                                                       ) AS demographics
                                            FROM df_lr_transaction_x_toserve d INNER JOIN df_hospitals_x_hcsystems h 
                                            ON CAST(d.hospitalfk AS BIGINT) = CAST(h.hospitalfk AS BIGINT)
                                            """)
    df_lr_transaction_x_toserve.createOrReplaceTempView("df_lr_transaction_x_toserve")
    df_lr_transaction_x_toserve = spark.sql("""
    SELECT df_lr_transaction_x_toserve.*,
       df_patientaccts.clusteredacctfk
    FROM df_lr_transaction_x_toserve
    INNER JOIN df_patientaccts
          ON df_lr_transaction_x_toserve.patientacctipk = df_patientaccts.patientacctipk
         AND df_lr_transaction_x_toserve.hospitalfk = df_patientaccts.hospitalfk
    """)
    df_lr_transaction_x_toserve.createOrReplaceTempView("df_lr_transaction_x_toserve")
    fc_cleansing_sql = """
                    SELECT
                     A.transactionkey,
                     A.leadid,
                     A.isdemovalid,
                     A.createdate_as_bigint,
                     A.hcsystemfk,
                     A.hospitalfk,
                     A.dependentflag,
                     A.source,A.fromglobalmrn,A.toglobalmrn,A.xrefsource,
                     A.leadsource,
                     A.bc,
                     struct(
                       A.demographics.firstname as firstname,
                       A.demographics.middlename as middlename,
                       A.demographics.lastname as lastname,
                       A.demographics.dob as dob,
                       A.demographics.ssn as ssn,
                       A.demographics.gender as gender,
                       A.demographics.dependentflag as dependentflag ,
                       A.createdate_min as createdate,
                       A.updatedate_max as updatedate ,
                       A.demographics.hospitalfk as hospitalfk,
                       A.demographics.hcsystemfk as hcsystemfk,
                       A.demographics.bc as bc,
                       A.demographics.state as state ,
                       A.demographics.source as source ,
                       A.demographics.leadsource as leadsource
                         ) as demographics
                FROM (SELECT A.transactionkey,
                           A.leadid,
                           A.isdemovalid,
                           A.createdate_as_bigint,
                           A.hcsystemfk,
                           A.hospitalfk,
                           A.dependentflag,
                           A.source,A.fromglobalmrn,A.toglobalmrn,A.xrefsource,
                           max(A.createdate) over (PARTITION BY A.leadid,A.hospitalfk,A.hcsystemfk,A.clusteredacctfk ORDER BY A.createdate_as_bigint) as createdate_min,
                           max(A.updatedate) over (PARTITION BY A.leadid,A.hospitalfk,A.hcsystemfk,A.clusteredacctfk ORDER BY A.updatedate_as_bigint desc) as updatedate_max,
                           A.leadsource,
                           A.bc,
                           A.demographics,
                           RANK() OVER (PARTITION BY A.leadid,A.hospitalfk,A.hcsystemfk,A.clusteredacctfk ORDER BY A.updatedate_as_bigint DESC, A.dependentflag DESC) AS RNK
                    FROM df_lr_transaction_x_toserve A) A
              WHERE A.RNK = 1"""
    df_lr_transaction_x_toserve = spark.sql(fc_cleansing_sql).dropDuplicates()
    df_lr_transaction_x_toserve.repartition(20).write.mode("overwrite").parquet(output_demographics)
else:
    print("UNKNOWN SOURCE")
    exit(1)


# COMMAND ----------

