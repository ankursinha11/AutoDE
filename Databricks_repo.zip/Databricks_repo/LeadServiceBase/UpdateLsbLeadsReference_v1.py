# Databricks notebook source
# Created By:Abdul Shaik 
# Created On:6/18/2024
# Details: This script is to
#          STEP 1 - Read merged gmrnIds from gmrn_xref toserve
#          STEP 2 - Get fromgmrnid lsb leads from leadservicebase
#          STEP 3 - Assign fromgmrnid lsb leads to togmrnid 
#          STEP 4 - Add newgmrnid leads from LSB
#          STEP 5 - Remove duplicate demographics per _id+hcsystem_source
#          STEP 6 - Rollup on _id and collect hcsystemfk_source and demographics
#          STEP 7 - Transform to LSB format
#          STEP 8 - Insert/Update into LSB
#          STEP 9 - Prepare leads to be deleted
#          STEP 10 - Delete lsb leads
#          STEP 11 - Function to add to lsb helper 
#          STEP 12 - Add lead to LSB Helper for lookup in leaddiscovery
#          STEP 13 - Pass leads to Lead Propagation for lead generation

# COMMAND ----------

import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark import SparkContext
from pyspark.sql import SQLContext
from pyspark.sql import HiveContext
from pyspark.sql.types import *
from pyspark.sql import Row
import datetime
from pyspark import SparkContext, SparkConf
from pyspark.sql import *
from pyspark.sql import functions as F
from pyspark.sql.readwriter import *
import os
from delta.tables import *

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/common_util" 

# COMMAND ----------

dbutils.widgets.text("bc", "")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("gmrn_input", "")
dbutils.widgets.getArgument("gmrn_input")
gmrn_input= getArgument("gmrn_input")

dbutils.widgets.text("adls_staging", "")
dbutils.widgets.getArgument("adls_staging")
adls_staging= getArgument("adls_staging")

dbutils.widgets.text("adls_transform", "")
dbutils.widgets.getArgument("adls_transform")
adls_transform= getArgument("adls_transform")

dbutils.widgets.text("lsb_path", "")
dbutils.widgets.getArgument("lsb_path")
lsb_path= getArgument("lsb_path")

dbutils.widgets.text("LeadlookupHelper_path", "")
dbutils.widgets.getArgument("LeadlookupHelper_path")
LeadlookupHelper_path= getArgument("LeadlookupHelper_path")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

gmrn_input = gmrn_input+bc+'/*'
lsb_path = lsb_path
adls_staging_gmrn_merge = adls_staging + 'gmrn_update'+ '/gmrn_merge/'+ bc
adls_staging_ready_to_load_lsb = adls_staging + 'gmrn_update'+'/ready_to_load_lsb/' + bc
adls_staging_ready_to_delete_lsb = adls_staging + 'gmrn_update'+'/ready_to_delete_lsb/' + bc
LeadlookupHelper_path = LeadlookupHelper_path
adls_leadpropagation_path= adls_transform+'updateLsbLeadsRef/gmrnid/lsb_leads/' + bc

print("bc:",bc)
print("gmrn_input:",gmrn_input)
print("lsb_path:",lsb_path)
print("adls_staging:",adls_staging)
print("adls_staging_gmrn_merge:",adls_staging_gmrn_merge)
print("adls_staging_ready_to_load_lsb:",adls_staging_ready_to_load_lsb)
print("adls_staging_ready_to_delete_lsb:",adls_staging_ready_to_delete_lsb)
print("LeadlookupHelper_path:",LeadlookupHelper_path)
print("adls_leadpropagation_path:",adls_leadpropagation_path)

# COMMAND ----------

# DBTITLE 1,Read merged gmrnIds from gmrn_xref toserve
gmrn_merged = spark.read.parquet(gmrn_input).dropDuplicates()

# gmrn_merged.count()# 10474

# COMMAND ----------

# DBTITLE 1,Get fromgmrnid lsb leads from leadservicebase
lsb = spark.read.format("delta").load(lsb_path)
lsb_delta = gmrn_merged.join(lsb, concat(lit("G_"), gmrn_merged.fromglobalmrn) == lsb.identity)
# lsb_delta.count()#9690

# COMMAND ----------

# DBTITLE 1,Assign fromgmrnid lsb leads to togmrnid
lsb_delta = lsb_delta.withColumn("_id", concat(lit("G_"), lsb_delta.toglobalmrn, lit("_"), lsb_delta.leadid))
lsb_delta = lsb_delta.withColumn("identity", concat(lit("G_"), lsb_delta.toglobalmrn))

#write to stage for tracking
lsb_delta.repartition(100).write.mode("overwrite").parquet(adls_staging_gmrn_merge)
# lsb_delta.count()#9690

# COMMAND ----------

# DBTITLE 1,Add newgmrnid leads from LSB
lsb = spark.read.format("delta").load(lsb_path)
lsb_g =lsb.filter(col("_id").startswith('G'))
drop_cols = ("fromglobalmrn", "toglobalmrn")
lsb_delta = spark.read.parquet(adls_staging_gmrn_merge).drop(*drop_cols)

lsb_curr = lsb_g.join(lsb_delta, "_id").select(lsb_g["*"])
lsb_all = lsb_curr.union(lsb_delta)

lsb1 = lsb_all.select("*",explode_outer("demographics"))
# lsb1.display()

# COMMAND ----------

# DBTITLE 1,Remove duplicate demographics per _id+hcsystem_source
lsb1.createOrReplaceTempView("lsb1")
lsb2_sql = """ SELECT
                _id,
                key as hcsystemfk_source,
                identity,
                min(leadcreatedate) over (PARTITION BY _id, key) as leadcreatedate,
                leadid,
                max(leadupdatedate) over (PARTITION BY _id, key) as leadupdatedate,
                min(lsbcreatedate) over (PARTITION BY _id, key) as lsbcreatedate,
                date_format(current_timestamp(), "yyyy-MM-dd HH:mm:ss") as lsbupdatedate,
                value as demographics,
                ROW_NUMBER() OVER (PARTITION BY _id, key ORDER BY leadupdatedate DESC) AS RNK
            FROM lsb1
            """
lsb2 = spark.sql(lsb2_sql).filter("RNK == 1").drop("RNK")
# lsb2.count()#16163


# COMMAND ----------

# DBTITLE 1,Rollup on _id and collect hcsystemfk_source and demographics
lsb2.createOrReplaceTempView("lsb2")
lsb3_sql = """ 
            SELECT
                _id,
                sort_array(collect_list(hcsystemfk_source) over (PARTITION BY _id)) as hcsystemfk_source_concat,
                identity,
                min(leadcreatedate) over (PARTITION BY _id) as leadcreatedate,
                leadid,
                max(leadupdatedate) over (PARTITION BY _id) as leadupdatedate,
                min(lsbcreatedate) over (PARTITION BY _id) as lsbcreatedate,
                lsbupdatedate,
                sort_array(collect_list(struct(hcsystemfk_source, demographics)) over (PARTITION BY _id)) as demographics_list,
                ROW_NUMBER() OVER (PARTITION BY _id ORDER BY leadupdatedate DESC) AS RNK
            FROM lsb2 
            """
lsb3 = spark.sql(lsb3_sql).filter("RNK == 1").drop("RNK")
# lsb3.count()#9655
# lsb3.filter("_id == 'G_215258031_322_9282821418'").display()


# COMMAND ----------

# DBTITLE 1,Transform to LSB format
lsb4 = lsb3.withColumn('hcsystemfk_source', array_join('hcsystemfk_source_concat' , '|')).drop("hcsystemfk_source_concat")
lsb5 = lsb4.withColumn("demographics", map_from_entries("demographics_list")).drop("demographics_list")
lsb6 = lsb5.select('_id', 'hcsystemfk_source', 'identity', 'leadcreatedate', 'leadid', 'leadupdatedate', 'lsbcreatedate', 'lsbupdatedate', 'demographics')
lsb6.repartition(100).write.mode("overwrite").parquet(adls_staging_ready_to_load_lsb)
# lsb6.count()#9655

# COMMAND ----------

# DBTITLE 1,Insert/Update into LSB
lsb = DeltaTable.forPath(spark, lsb_path)
lsb.alias("curr").merge(lsb6.alias("new_data"), 'curr._id == new_data._id').whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()

# get the last operation
lastOperationDF = lsb.history(2).filter("operation = 'MERGE'")
inserts = lastOperationDF.select(collect_list("operationMetrics.numTargetRowsInserted"))
updates = lastOperationDF.select(collect_list("operationMetrics.numTargetRowsUpdated"))

print("Number of rows inserted into the target table: " + str(inserts.first()[0]) )
print("Number of rows updated in the target table: " +  str(updates.first()[0]) )


# COMMAND ----------

# DBTITLE 1,Prepare leads to be deleted
#prep delete transaction

# Read gmrnids merged
gmrn_merged = spark.read.parquet(adls_staging_gmrn_merge).select("fromglobalmrn", "toglobalmrn")

# Read leads we inserted/updated above
lsb_u = spark.read.parquet(adls_staging_ready_to_load_lsb)

# Check leads availability in LSB to delete
gmrn_d = gmrn_merged.join(lsb_u, concat(lit('G_'), col("toglobalmrn")) == col("identity")).select(col("fromglobalmrn"), col("leadid").alias("leadid_n"))
lsb = spark.read.format("delta").load(lsb_path)
lsb_d = lsb.join(gmrn_d, concat(lit('G_'), col("fromglobalmrn"), lit('_'), col("leadid_n")) == col("_id")).select("_id").distinct()
  
# print("Count of matching _id's for deletion : " + str(lsb_d.count()))
lsb_d.repartition(100).write.mode("overwrite").parquet(adls_staging_ready_to_delete_lsb)


# COMMAND ----------

# DBTITLE 1,Delete lsb leads
lsb = DeltaTable.forPath(spark, lsb_path)
lsb_d = spark.read.parquet(adls_staging_ready_to_delete_lsb)
lsb.alias("curr").merge(lsb_d.alias("deletes"), 'curr._id == deletes._id').whenMatchedDelete().execute()

# get the last operation
lastOperationDF = lsb.history(1)
lodf_deletes = lastOperationDF.select(collect_list("operationMetrics.numTargetRowsMatchedDeleted"))
print("Number of rows deleted in the target table: " + str(lodf_deletes.first()[0]))

# COMMAND ----------

# DBTITLE 1,Function to add to lsb helper
def AddToLeadlookupHelper(df, LeadlookupHelper_path):
    df1 = df.withColumnRenamed("identity","lookupvalue").select(col("lookupvalue"),col("_id"), col("source"))
    df2 = df1.withColumn("recordcreatedate", date_format(current_timestamp(), "yyyy-MM-dd HH:mm:ss" ) )
    df3 = df2.withColumn("keyname", when(col("lookupvalue").startswith("S") , "ssn") 
                         .when(col("lookupvalue").startswith("P"), "permid")
                         .when(col("lookupvalue").startswith("G"), "globalmrnifk")
                         .when(col("lookupvalue").startswith("C"), "clusteredacctfk")
                         .when(col("lookupvalue").startswith("M"), "medicalrecnum")
                         .otherwise("Unknown"))
    df4 = df3.dropDuplicates()
    df4.repartition(20).write.partitionBy("keyname").mode("append").parquet(LeadlookupHelper_path)

# COMMAND ----------

# DBTITLE 1,Add lead to LSB Helper for lookup in leaddiscovery
lsb6 = spark.read.parquet(adls_staging_ready_to_load_lsb)
lsb_helper = lsb6.select("_id", "identity", "hcsystemfk_source",)
lsb_helper = lsb_helper.withColumn("hcsystemfk_source_list", split(lsb_helper.hcsystemfk_source,'\|'))
lsb_helper = lsb_helper.withColumn("hcsystemfk_source_temp", explode(col("hcsystemfk_source_list"))).drop("hcsystemfk_source_list").drop("hcsystemfk_source")

lsb_helper = lsb_helper.withColumn("hcsystemfk_source_split",split(lsb_helper.hcsystemfk_source_temp,'_')).drop("hcsystemfk_source_temp")
lsb_helper = lsb_helper.withColumn("source",lsb_helper.hcsystemfk_source_split.getItem(1)).drop("hcsystemfk_source_split").dropDuplicates()

AddToLeadlookupHelper(lsb_helper, LeadlookupHelper_path)
# lsb_helper.display()# 


# COMMAND ----------

# DBTITLE 1,Pass leads to Lead Propagation for lead generation
lsb_ready_to_load_lsb=spark.read.parquet(adls_staging_ready_to_load_lsb)
# lsb_ready_to_load_lsb.display()
lsb_transform=lsb_ready_to_load_lsb.select(col("_id").alias("_id_updated"),
                                           col("identity").alias("identity_updated"),
                                           col("leadcreatedate").alias("leadcreatedate_updated"),
                                           col("leadid").alias("leadid_updated"),
                                           col("leadupdatedate").alias("leadupdatedate_updated"),
                                           col("lsbcreatedate").alias("lsbcreatedate_updated"),
                                           col("lsbupdatedate").alias("lsbupdatedate_updated"),
                                           explode(lsb_ready_to_load_lsb.demographics)).drop(lsb_ready_to_load_lsb.demographics,lsb_ready_to_load_lsb.hcsystemfk_source).withColumnRenamed("key","hcsystemfk_source_updated")
# lsb_transform.display()
lsb_final = lsb_transform.select(lsb_transform['*'], 
                                 col("value.dob").alias("dob_updated"), 
                                 col("value.firstname").alias("firstname_updated"), 
                                 col("value.hospitalfk").alias("hospitalfk_updated"),
                                 col("value.gender").alias("gender_updated"),
                                 col("value.lastname").alias("lastname_updated"),
                                 col("value.leadsource").alias("leadsource_updated"),
                                 col("value.middlename").alias("middlename_updated"),
                                 col("value.ssn").alias("ssn_updated"),
                                 col("value.state").alias("state_updated"),
                                 col("value.updatedate").alias("updatedate_updated"),
                                 col("value.xrefsource").alias("xrefsource_updated")).drop("value")
# lsb_final.display()
lsb_final.write.parquet(adls_leadpropagation_path)