// Databricks notebook source
import org.apache.spark.sql.{DataFrame}
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._
import scala.io.Source
import scala.collection._
import java.time.format.DateTimeFormatter
import java.time.LocalDate
import java.time.LocalDateTime
import io.delta.tables._
import spark.implicits._
import org.apache.spark.sql.expressions.{Window, WindowSpec}
import org.apache.spark.sql.types._
import org.apache.spark.sql.Column
import org.apache.spark.sql.expressions.UserDefinedFunction

// COMMAND ----------

// DBTITLE 1,adls access
// MAGIC %python
// MAGIC spark.conf.set( "fs.azure.account.key.divyaprodstorageact1.dfs.core.windows.net","0yOD1SCSgZwOHAlWBJgYDEv4+EJXpuNOhprl+BW1zte8lVhst8L59ZTRZD6MBnWwsCToZszWjZ6Z+ASt4XW8iw==")

// COMMAND ----------

// DBTITLE 1,Defining getParquetData function - reads the parquet file and drops duplicate
def getParquetData(hdfsPath: String): DataFrame = {
  return spark.read.parquet(hdfsPath + "/*").dropDuplicates()
}

// COMMAND ----------

// DBTITLE 1,Defining writeParquetData function
def writeParquetData(df: DataFrame, hdfs_path: String, mode: String): Unit = {
  df.dropDuplicates().repartition(10).write.mode(mode).parquet(hdfs_path)
}

// COMMAND ----------

// DBTITLE 1,Defining getReferenceId function 
def getReferenceId(df: DataFrame, list_column: String ,source_val: String, temp_op_path_formatted: String,df1: DataFrame): Unit = {
  val df2 = df.withColumn("sourcekey",lit(source_val))
  val joinkeys_ref = Seq("transactionkey", "sourcekey")
  val df3 =  df2.alias("to_serve").join(df1.alias("df1"),joinkeys_ref).select("to_serve.*",list_column,"xrefsource")
  val df4 = df3.withColumnRenamed(list_column,("lookupvalue"))
  writeParquetData(df4: DataFrame, temp_op_path_formatted: String, "overwrite")
}

// COMMAND ----------

// DBTITLE 1,Defining getFilteredParquetData function
def getFilteredParquetData(hdfsPath: String, column_to_get: String): DataFrame = {
  val df: DataFrame = spark.read.parquet(hdfsPath).filter(trim(col(column_to_get)) =!= "")
  val df1: DataFrame = df.withColumn(column_to_get, trim(col(column_to_get)))
  return df1
}

// COMMAND ----------

def prepareDeltaLakeTable2(temp_op_path1:String, num_partition:Int) : DataFrame ={
  spark.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")

  val df1: DataFrame = getParquetData(temp_op_path1)

  val df2 = df1.repartition(num_partition, col("_id"))
              .withColumn("dob", $"new_col".getItem(6))
              .withColumn("firstname", $"new_col".getItem(4))
              .withColumn("gender", $"new_col".getItem(8))
              .withColumn("hospitalfk", $"new_col".getItem(10))
              .withColumn("lastname", $"new_col".getItem(5))
              .withColumn("leadsource", $"new_col".getItem(13))
              .withColumn("middlename", $"new_col".getItem(7))
              .withColumn("ssn", $"new_col".getItem(11))
              .withColumn("state", $"new_col".getItem(14))
              .withColumn("updatedate", $"new_col".getItem(9))
              .withColumn("xrefsource", $"new_col".getItem(12))
  val df3 = df2.withColumn("identity", $"new_col".getItem(0))
              .withColumn("leadcreatedate", $"new_col".getItem(15))
              .withColumn("leadupdatedate", $"new_col".getItem(9))
              .withColumn("lsbcreatedate",lit(""))
              .withColumn("lsbupdatedate",lit(""))
              .withColumn("hcsystemfk_source", $"new_col".getItem(3))
  val df4 = df3.select($"_id",$"hcsystemfk_source",$"identity", $"leadcreatedate", $"leadid",$"leadupdatedate", $"lsbcreatedate", $"lsbupdatedate", $"dob", $"firstname",$"gender",$"hospitalfk",$"lastname",$"leadsource",$"middlename",$"ssn",$"state",$"updatedate",$"xrefsource")

  val df5 = df4.withColumn("leadupdatedate",to_timestamp(unix_timestamp(col("leadupdatedate"), "yyyy-MM-dd HH:mm:ss").cast("timestamp")))
             .withColumn("leadcreatedate",to_timestamp(unix_timestamp(col("leadcreatedate"), "yyyy-MM-dd HH:mm:ss").cast("timestamp")))

  return df5
}


// COMMAND ----------

// DBTITLE 1,Defining getLatestDemogValues func
//get the latest non null demographics values
def getLatestDemogValues(df:DataFrame) : DataFrame ={
	val windowSpecRowNum = Window.partitionBy("_id","hcsystemfk_source").orderBy(col("leadupdatedate").desc)
  val windowSpec  = Window.partitionBy("_id","hcsystemfk_source").orderBy(col("leadupdatedate"))
  val windowSpec_dates = Window.partitionBy("_id","hcsystemfk_source")
	val windowSpec_id = Window.partitionBy("_id")
	val windowSpec2  = Window.partitionBy("_id","hcsystemfk_source").orderBy(col("updatedate").desc)

  val df1 = df.withColumn("firstname_trimmed", when(trim(col("firstname")) === "" || 
							            									trim(col("firstname")) === " " || 
                                            trim(col("firstname")) === "null", null)
							            									.otherwise(col("firstname")))
						  .withColumn("dob_trimmed", when(trim(col("dob")) === "" || 
							            									trim(col("dob")) === " " ||							
							            									trim(col("dob")) === "null", null)
							            									.otherwise(col("dob")))
						  .withColumn("gender_trimmed", when(trim(col("gender")) === "" || 
							            									trim(col("gender")) === " " ||							
							            									trim(col("gender")) === "null", null)
							            									.otherwise(col("gender")))
						  .withColumn("updatedate_trimmed", when(trim(col("updatedate")) === "" || 
							            									trim(col("updatedate")) === " " ||							
							            									trim(col("updatedate")) === "null", null)
							            									.otherwise(col("updatedate")))
						  .withColumn("lastname_trimmed", when(trim(col("lastname")) === "" || 
							            									trim(col("lastname")) === " " ||							
							            									trim(col("lastname")) === "null", null)
							            									.otherwise(col("lastname")))
						  .withColumn("middlename_trimmed", when(trim(col("middlename")) === "" || 
							            									trim(col("middlename")) === " " ||							
							            									trim(col("middlename")) === "null", null)
							            									.otherwise(col("middlename")))
						  .withColumn("ssn_trimmed", when(trim(col("ssn")) === "" || 
							            									trim(col("ssn")) === " " ||							
							            									trim(col("ssn")) === "null", null)
							            									.otherwise(col("ssn")))
						  .withColumn("state_trimmed", when(trim(col("state")) === "" || 
							            									trim(col("state")) === " " ||							
							            									trim(col("state")) === "null", null)
							            									.otherwise(col("state")))
							.withColumn("leadupdatedate", max(col("leadupdatedate")).over(windowSpec_id))
              .withColumn("leadcreatedate", min(col("leadcreatedate")).over(windowSpec_id))

	//get first/latest update date non-null values for the below demog
  val df2 = df1.withColumn("firstname", first(col("firstname_trimmed"), ignoreNulls=true).over(windowSpec2))
               .withColumn("dob", first(col("dob_trimmed"), ignoreNulls=true).over(windowSpec2))
               .withColumn("gender", first(col("gender_trimmed"), ignoreNulls=true).over(windowSpec2))
               .withColumn("lastname", first(col("lastname_trimmed"), ignoreNulls=true).over(windowSpec2))
               .withColumn("middlename", first(col("middlename_trimmed"), ignoreNulls=true).over(windowSpec2))
               .withColumn("ssn", first(col("ssn_trimmed"), ignoreNulls=true).over(windowSpec2))
               .withColumn("state", first(col("state_trimmed"), ignoreNulls=true).over(windowSpec2))
               .withColumn("updatedate", first(col("updatedate_trimmed"), ignoreNulls=true).over(windowSpec2))

  val df3 = df2.withColumn("hospitalfk_concat_set", collect_set(col("hospitalfk")).over(windowSpec))
						   .withColumn("xrefsource_concat_set", collect_set(col("xrefsource")).over(windowSpec))
						   .withColumn("leadsource_concat_set", collect_set(col("leadsource")).over(windowSpec))
               .withColumn("hospitalfk",concat_ws("|",col("hospitalfk_concat_set")))
						   .withColumn("xrefsource",concat_ws("|",col("xrefsource_concat_set")))
						   .withColumn("leadsource",concat_ws("|",col("leadsource_concat_set")))
           
  val df4 = df3.withColumn("row_num", row_number().over(windowSpecRowNum))
               .drop("firstname_trimmed","dob_trimmed","gender_trimmed","updatedate_trimmed",
                     "lastname_trimmed","middlename_trimmed","ssn_trimmed","state_trimmed", 
                     "hospitalfk_concat_set", "xrefsource_concat_set", "leadsource_concat_set")

  
  val df5 = df4.filter($"row_num" === 1).drop($"row_num")
  //display(df5)                     
  return df5
}

// COMMAND ----------

// DBTITLE 1,Defining getLSBJoinDataset - join input_df3 and lsb 
def getLSBJoinDataset(df:DataFrame, lsb_delta_df: DataFrame) :DataFrame ={
  val distinctIdValues = df.select("_id").distinct()
	
	val matching_lsb_df  = lsb_delta_df.alias("lsb").join(distinctIdValues,Seq("_id"),"inner").select("lsb.*")
	val explode_lsb_df1 = matching_lsb_df.select($"*",explode_outer($"demographics")).drop("hcsystemfk_source","demographics") 
	
	//drop the concat hcsystemfk_ource and get exploded value from the key in the below line 
	val explode_lsb_df2 = explode_lsb_df1.withColumnRenamed("key", "hcsystemfk_source")

	val explode_lsb_df3 = explode_lsb_df2.select($"_id",$"hcsystemfk_source",$"identity",$"leadcreatedate",$"leadid",$"leadupdatedate",$"lsbcreatedate",$"lsbupdatedate",$"value.dob",$"value.firstname",$"value.gender",$"value.hospitalfk",$"value.lastname",$"value.leadsource",$"value.middlename",$"value.ssn",$"value.state",$"value.updatedate",$"value.xrefsource").drop("value") 
	//Renamecolumns
	val new_column_names=explode_lsb_df3.withColumnRenamed("_id", "id").columns.map(c=>"LSB_" + c)
	val explode_lsb_df4 = explode_lsb_df3.toDF(new_column_names:_*)

	val join_cond = (explode_lsb_df4("LSB_id") === df("_id") && explode_lsb_df4("LSB_hcsystemfk_source") === df("hcsystemfk_source"))

	val join_df1  = df.join(explode_lsb_df4,join_cond,joinType="left") //matching recs from input_df and lsb on id and hcsystemfk_source

  val join_lsb_df1 = explode_lsb_df4.join(df, join_cond, joinType="leftanti") //lsb recs with same id but hcsystemfk_source not in the input - these need to be preserved in the final lsb
  val join_lsb_df2 = join_lsb_df1.withColumn("_id", lit(null: String))
												 .withColumn("hcsystemfk_source",lit(null: String))
												 .withColumn("identity",lit(null: String))
												 .withColumn("leadcreatedate",lit(null: String))
												 .withColumn("leadid",lit(null: String))
												 .withColumn("leadupdatedate",lit(null: String))
												 .withColumn("lsbcreatedate",lit(null: String))
												 .withColumn("lsbupdatedate",lit(null: String))
												 .withColumn("dob",lit(null: String))
												 .withColumn("firstname",lit(null: String))
												 .withColumn("gender",lit(null: String))
												 .withColumn("hospitalfk",lit(null: String))
												 .withColumn("lastname",lit(null: String))
												 .withColumn("leadsource",lit(null: String))
												 .withColumn("middlename",lit(null: String))
												 .withColumn("ssn",lit(null: String))
												 .withColumn("state",lit(null: String))
												 .withColumn("updatedate",lit(null: String))
												 .withColumn("xrefsource",lit(null: String))

	val join_lsb_df3 = join_lsb_df2.select("_id","hcsystemfk_source","identity","leadcreatedate","leadid","leadupdatedate","lsbcreatedate","lsbupdatedate",
	"dob","firstname","gender","hospitalfk","lastname","leadsource","middlename","ssn","state","updatedate","xrefsource","LSB_id","LSB_hcsystemfk_source","LSB_identity","LSB_leadcreatedate","LSB_leadid","LSB_leadupdatedate","LSB_lsbcreatedate","LSB_lsbupdatedate","LSB_dob","LSB_firstname","LSB_gender","LSB_hospitalfk","LSB_lastname","LSB_leadsource","LSB_middlename","LSB_ssn","LSB_state","LSB_updatedate","LSB_xrefsource")

	val union_df = join_df1.union(join_lsb_df3)
	return union_df
}

// COMMAND ----------

// DBTITLE 1,concatValues - udf
def concatValues(concat_val: String): String = {
    val trimmedList4: List[String] = concat_val.split("\\|").map(_.trim).toList.distinct
    var ret1_val = trimmedList4.mkString("|")

    return ret1_val

  }
//register function as UDF
val concatValuesUdf = udf[String, String] (concatValues)

// COMMAND ----------

// DBTITLE 1,Defining getConcatValues
def getConcatValues(join_df:DataFrame) :DataFrame ={
	val windowSpec_id_updated = Window.partitionBy("_id_updated")
  val lsb_windowSpec  = Window.partitionBy("LSB_id","LSB_hcsystemfk_source").orderBy(col("LSB_leadupdatedate"))

	val df1 = join_df.withColumn("_id_updated", when(trim($"LSB_id") === "" || 
																					  trim($"LSB_id") === "null" || 
													   							  trim($"LSB_id") === "NULL" || 
																						trim($"LSB_id").isNull, $"_id")
												 							.when(trim($"_id") === "" || 
																			      trim($"_id") === "null" || 
																			      trim($"_id") === "NULL" || 
																						trim($"_id").isNull, $"LSB_id")
												 							.otherwise($"_id"))

  val df2 = df1.withColumn("hcsystemfk_source_set", collect_set(col("hcsystemfk_source")).over(windowSpec_id_updated))
                          .withColumn("LSB_hcsystemfk_source_set", collect_set(col("LSB_hcsystemfk_source")).over(windowSpec_id_updated))
                          .withColumn("hcsystemfk_source_ct",concat_ws("|",col("LSB_hcsystemfk_source_set"),col("hcsystemfk_source_set")))
                          .withColumn("hcsystemfk_source_concat", concatValuesUdf(col("hcsystemfk_source_ct")))
                          .withColumn("LSB_hospitalfk_set", collect_set(col("LSB_hospitalfk")).over(lsb_windowSpec))
						              .withColumn("LSB_xrefsource_set", collect_set(col("LSB_xrefsource")).over(lsb_windowSpec))
						              .withColumn("LSB_leadsource_set", collect_set(col("LSB_leadsource")).over(lsb_windowSpec))
                          .withColumn("hospitalfk_concat",concat_ws("|",col("LSB_hospitalfk_set"),col("hospitalfk")))
						              .withColumn("xrefsource_concat",concat_ws("|",col("LSB_xrefsource_set"),col("xrefsource")))
						              .withColumn("leadsource_concat",concat_ws("|",col("LSB_leadsource_set"),col("leadsource")))
                          .withColumn("hospitalfk_updated", concatValuesUdf(col("hospitalfk_concat")))
                          .withColumn("xrefsource_updated", concatValuesUdf(col("xrefsource_concat")))
                          .withColumn("leadsource_updated", concatValuesUdf(col("leadsource_concat")))
                          .drop("hcsystemfk_source_set","LSB_hcsystemfk_source_set","hcsystemfk_source_ct",
                          "LSB_hospitalfk_set","hospitalfk_concat","LSB_xrefsource_set","xrefsource_concat",
                          "LSB_leadsource_set","leadsource_concat")

	return df2
}

// COMMAND ----------

// DBTITLE 1,Defining getCleansedDataset
def getCleansedDataset(concat_df:DataFrame, joinDataWithUpdates:String) : DataFrame ={
  val df1 = concat_df.withColumn("hcsystemfk_source_updated", coalesce($"hcsystemfk_source", $"LSB_hcsystemfk_source"))
                     .withColumn("identity_updated", coalesce($"identity", $"LSB_identity"))
                     .withColumn("leadid_updated", coalesce($"leadid", $"LSB_leadid"))
                     .withColumn("dob_updated", coalesce($"dob", $"LSB_dob"))
									   .withColumn("firstname_updated",coalesce($"firstname", $"LSB_firstname"))
                     .withColumn("gender_updated",coalesce($"gender", $"LSB_gender"))
                     .withColumn("lastname_updated",coalesce($"lastname", $"LSB_lastname"))
                     .withColumn("middlename_updated",coalesce($"middlename", $"LSB_middlename"))
 									   .withColumn("ssn_updated", coalesce($"ssn", $"LSB_ssn"))
                     .withColumn("state_updated", coalesce($"state", $"LSB_state"))
 									   .withColumn("updatedate_updated", coalesce($"updatedate", $"LSB_updatedate"))
                     .withColumn("leadcreatedate_updated",coalesce($"LSB_leadcreatedate",$"leadcreatedate")) //LSB values should be updated in case of new create date coming in
									   .withColumn("leadupdatedate_updated", coalesce($"leadupdatedate", $"LSB_leadupdatedate")) //Input values should be updated in case of new create date coming in
									   .withColumn("lsbcreatedate_updated",  when($"LSB_lsbcreatedate".isNotNull, $"LSB_lsbcreatedate")
																					                .otherwise(lit(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format(LocalDateTime.now()))))
									   .withColumn("lsbupdatedate_updated",  lit(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format(LocalDateTime.now())))

  val df2 = df1.select("_id","LSB_id","_id_updated","hcsystemfk_source","LSB_hcsystemfk_source","hcsystemfk_source_updated","hcsystemfk_source_concat","identity","LSB_identity","identity_updated","leadcreatedate","LSB_leadcreatedate","leadcreatedate_updated","leadid","LSB_leadid","leadid_updated","leadupdatedate","LSB_leadupdatedate","leadupdatedate_updated","lsbcreatedate","LSB_lsbcreatedate","lsbcreatedate_updated","lsbupdatedate","LSB_lsbupdatedate","lsbupdatedate_updated","dob","LSB_dob","dob_updated","firstname","LSB_firstname","firstname_updated","gender","LSB_gender","gender_updated","hospitalfk","LSB_hospitalfk","hospitalfk_updated","lastname","LSB_lastname","lastname_updated","leadsource","LSB_leadsource","leadsource_updated","middlename","LSB_middlename","middlename_updated","ssn","LSB_ssn","ssn_updated","state","LSB_state","state_updated","updatedate","LSB_updatedate","updatedate_updated","xrefsource","LSB_xrefsource","xrefsource_updated")

	df2.repartition(100).write.mode("overwrite").parquet(joinDataWithUpdates)

  return df2
}

// COMMAND ----------

// DBTITLE 1,Defining getFinalMapDataset
def getFinalMapDataset(clean_df:DataFrame, mapDataPath:String) : DataFrame ={
  
  val map_df1 = clean_df.select("_id_updated","hcsystemfk_source_updated","hcsystemfk_source_concat","identity_updated","leadcreatedate_updated","leadid_updated","leadupdatedate_updated","lsbcreatedate_updated","lsbupdatedate_updated","dob_updated","firstname_updated","gender_updated","hospitalfk_updated","lastname_updated","leadsource_updated","middlename_updated","ssn_updated","state_updated","updatedate_updated","xrefsource_updated")

  val map_df2 = map_df1.withColumnRenamed("_id_updated", "_id")
                       .withColumnRenamed("hcsystemfk_source_updated", "hcsystemfk_source")
                       .withColumnRenamed("identity_updated", "identity")
                       .withColumnRenamed("leadcreatedate_updated", "leadcreatedate")
                       .withColumnRenamed("leadid_updated", "leadid")
                       .withColumnRenamed("leadupdatedate_updated", "leadupdatedate")
                       .withColumnRenamed("lsbcreatedate_updated", "lsbcreatedate")
                       .withColumnRenamed("lsbupdatedate_updated", "lsbupdatedate")
                       .withColumnRenamed("dob_updated", "dob")
                       .withColumnRenamed("firstname_updated", "firstname")
                       .withColumnRenamed("gender_updated", "gender")
                       .withColumnRenamed("hospitalfk_updated", "hospitalfk")
                       .withColumnRenamed("lastname_updated", "lastname")
                       .withColumnRenamed("leadsource_updated", "leadsource")
                       .withColumnRenamed("middlename_updated", "middlename")
                       .withColumnRenamed("ssn_updated", "ssn")
                       .withColumnRenamed("state_updated", "state")
                       .withColumnRenamed("updatedate_updated", "updatedate")
                       .withColumnRenamed("xrefsource_updated", "xrefsource")

  val map_df3 = map_df2.withColumn("concat_col", concat_ws("~",$"dob",$"firstname",$"gender",$"hospitalfk",$"lastname",$"leadsource",$"middlename",$"ssn",$"state",$"updatedate",$"xrefsource"))

  val map_df4 = map_df3.withColumn("demo1", map($"hcsystemfk_source",$"concat_col"))

  val map_df5 = map_df4.withColumn("demographics", map_from_arrays(map_keys($"demo1"),
                          expr("""transform(map_values(demo1), x -> (dob, firstname,gender,hospitalfk,lastname,leadsource,middlename,ssn,state,updatedate,xrefsource))""")))
                      .drop("dob","firstname","gender","hospitalfk","lastname","leadsource","middlename","ssn","state","updatedate","xrefsource","concat_col","demo1")

  val map_df6 = map_df5.select($"*",explode_outer($"demographics"))

  val windowSpec_id = Window.partitionBy("_id").orderBy(col("_id"))

  val map_df7 = map_df6.withColumn("rn", row_number().over(windowSpec_id))
               .withColumn(
                    "demo_new", 
                    array_sort(collect_list(struct("key", "value")).over(windowSpec_id)))
                .withColumn("demographics", map_from_entries($"demo_new"))
                .drop("key","value","demo_new","hcsystemfk_source").filter("rn = 1")

  val map_df8 = map_df7.withColumnRenamed("hcsystemfk_source_concat", "hcsystemfk_source").drop("rn")
	
  map_df8.repartition(100).write.mode("overwrite").parquet(mapDataPath)

  return map_df8
}


// COMMAND ----------

// DBTITLE 1,Defining getLeadLookupDataset function
  def getLeadLookupDataset(df:DataFrame,source:String,leadlookupoppath:String) :Unit ={

    val curr_datetime_leadlookup = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format(LocalDateTime.now())
    val df1 = df.withColumnRenamed("identity","lookupvalue").select(col("lookupvalue"),col("_id"))
    val df2 = df1.withColumn("source",lit(source))
    val df3 = df2.withColumn("recordcreatedate",lit(curr_datetime_leadlookup))
    val df4 = df3.withColumn("keyname", when(df3("lookupvalue").startsWith("S") , "ssn")
                         .when(df3("lookupvalue").startsWith("P"), "permid")
                         .when(df3("lookupvalue").startsWith("G"), "globalmrnifk")
                         .when(df3("lookupvalue").startsWith("C"), "clusteredacctfk")
                         .when(df3("lookupvalue").startsWith("M"), "medicalrecnum")
                         .otherwise("Unknown"))
    val df5 = df4.dropDuplicates()
    df5.repartition(20).write.partitionBy("keyname").mode("append").parquet(leadlookupoppath)
  }


// COMMAND ----------

def finalUpsertIntoLSBTable(deltalake_output:String, final_df:DataFrame) : Unit ={
  val deltaTableLSB = DeltaTable.forPath(spark, deltalake_output)

  deltaTableLSB.as("lsb").merge(final_df.as("new_data"),"lsb._id = new_data._id")
  .whenMatched()
  .updateAll()
  .whenNotMatched()
  .insertAll()
  .execute()

  //get the last operation
  val lastOperationDF = deltaTableLSB.history(1)
  println("Number of rows inserted into the target table: " + lastOperationDF.select($"operationMetrics.numTargetRowsInserted").as[String].head)
  println("Number of rows updated in the target table: " + lastOperationDF.select($"operationMetrics.numTargetRowsUpdated").as[String].head)

}

// COMMAND ----------

// DBTITLE 1,Main common function for PopulateLsbLeadsReference which calls all other functions
def UpsertIntoLSBTable(num_partition: Int, deltalake_output:String, temp_op_path1:String, source:String, temp_op_path3:String, temp_op_path4:String, lsb_delta_df: DataFrame, leadlookupoppath:String) :Unit ={
  val input_df2 = prepareDeltaLakeTable2(temp_op_path1, num_partition)
  val input_df3 = getLatestDemogValues(input_df2)
  val join_df = getLSBJoinDataset(input_df3, lsb_delta_df)
  val concat_df = getConcatValues(join_df)
  val cleansed_df = getCleansedDataset(concat_df, temp_op_path3)
  val final_df = getFinalMapDataset(cleansed_df, temp_op_path4)
  getLeadLookupDataset(final_df,source,leadlookupoppath)
  finalUpsertIntoLSBTable(deltalake_output, final_df)
}