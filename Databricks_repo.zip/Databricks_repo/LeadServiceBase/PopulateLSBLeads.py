# Databricks notebook source
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", "-1")
spark.conf.set("spark.sql.shuffle.partitions", "auto")

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# dbutils.widgets.text('serveSource','fc') 
# dbutils.widgets.text('serveInputBc','20230917T21')
# dbutils.widgets.text('pathHdfsToServe','abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/data/leadrepo/publish/toserve/ich_import/es_postbdf/')
# dbutils.widgets.text('pathHdfsTransactionCooked','abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/data/leadrepo/publish/cooked/lr_xref_gmrnid_transaction/')
# dbutils.widgets.text('pathHdfs','abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/data/escan_data_ingestion')

# #Output Path
# dbutils.widgets.text('pathHdfsLeadDemoOutput','abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/data/leadrepo/scratch/leadservicebase/json_demog/ich')
# dbutils.widgets.text('config_file_path','abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/data/leadservicebase/leadservicebase_create/config.txt')
# dbutils.widgets.text('scratch_path','abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/data/leadrepo/scratch/leadservicebase')


# COMMAND ----------

dbutils.widgets.text('serveSource','')
dbutils.widgets.text('serveInputBc','')
dbutils.widgets.text('pathHdfsToServe','')
dbutils.widgets.text('pathHdfsTransactionCooked','')
dbutils.widgets.text('pathHdfs','')
#Output Path
dbutils.widgets.text('pathHdfsLeadDemoOutput','')
dbutils.widgets.text('config_file_path','')
dbutils.widgets.text('scratch_path','')

serveSource = dbutils.widgets.get("serveSource")
serveInputBc = dbutils.widgets.get("serveInputBc")
pathHdfsToServe = dbutils.widgets.get("pathHdfsToServe")
pathHdfsTransactionCooked = dbutils.widgets.get("pathHdfsTransactionCooked")
pathHdfs = dbutils.widgets.get("pathHdfs")
pathHdfsLeadDemoOutput = dbutils.widgets.get("pathHdfsLeadDemoOutput")
config_file_path = dbutils.widgets.get("config_file_path")
scratch_path = dbutils.widgets.get("scratch_path")

dbutils.widgets.text('storageaccount','')
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text("notificationtype","")
notificationtype=dbutils.widgets.get("notificationtype")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

def mapFile(config_file_path):
    files = spark.read.text(config_file_path).collect()
    mapped_lines = []
    for row in files:
        row_value = row.value  
        if (row_value != '') and (not row_value.startswith(";;;")):
            line = row_value.split(':')
        mapped_lines.append(line)
    return(dict(mapped_lines))    

# COMMAND ----------

def main():
    print("Control in Main")
    mp = mapFile(config_file_path)
    source_val = mp.get(serveSource)
    if notificationtype in ('ie_xref_lsb','es_xref_lsb'):
        print(notificationtype)
        outputDf = getDemograhicsAsStruct_ich(serveSource, serveInputBc, pathHdfsToServe, pathHdfsTransactionCooked, pathHdfs, source_val, scratch_path)
        outputDf.dropDuplicates().write.mode("overwrite").parquet(pathHdfsLeadDemoOutput + "/" + serveSource + "/" + serveInputBc + "/" )
    else:
        outputDf = getDemograhicsAsStruct(serveSource, serveInputBc, pathHdfsToServe, pathHdfsTransactionCooked, pathHdfs, source_val, scratch_path)
        outputDf.dropDuplicates().write.mode("overwrite").parquet(pathHdfsLeadDemoOutput + "/" + serveSource + "/" + serveInputBc + "/" )

# COMMAND ----------

def getParquetData(hdfsPath):
    return spark.read.parquet(hdfsPath).dropDuplicates()

# COMMAND ----------

def getFilteredParquetData(hdfsPath , column_name, source_value):
    df = spark.read.parquet(hdfsPath).filter(col(column_name) == source_value)
    return df

def getFilteredDeltaData(hdfsPath , column_name, source_value):
    df = spark.read.format('delta').load(hdfsPath).filter(col(column_name) == source_value)
    return df


# COMMAND ----------

def extract_tupayer_data(hdfs_tupayer_path):
    print("Control in extract_tupayer_data")
    tupayer_data = spark.read.parquet(hdfs_tupayer_path + "/edipayers_tupayeridmapping/current/*").select("tupayerid", "edipayerfk")
    edipartner_data = spark.read.parquet(hdfs_tupayer_path + "/edipartners/current/*")
    edipartner_data1 = edipartner_data.filter(((col("isenabledflag")) == 1) & (col("edipartnerpk") > 0)).select("edipayerfk", "edipartnerpk")
    joinkeys2 = ["edipayerfk"]
    p = tupayer_data.join(edipartner_data1, joinkeys2).select((col("tupayerid")).cast("int"), col("edipartnerpk").alias("edipartnerfk"))
    cond = when(col("tupayerid") == 10118, lit(91)).otherwise(col("edipartnerfk"))
    cond1 = when(col("tupayerid") == 10102, lit(30)).otherwise(col("edipartnerfk"))
    cond2 = when(col("tupayerid") == 10001, lit(82)).otherwise(col("edipartnerfk"))
    cond3 = when(col("tupayerid") == 10055, lit(8)).otherwise(col("edipartnerfk"))
    p1 = p.withColumn("edipartnerfk", cond).withColumn("edipartnerfk", cond1).withColumn("edipartnerfk", cond2).withColumn("edipartnerfk", cond3)
    return p1

# COMMAND ----------

# transactionCookedDf = spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/leadrepo/publish/cooked/lr_transaction/")
# transactionCookedDf=transactionCookedDf.withColumn("transactionkey", trim("transactionkey"))
# transactionCookedDf=transactionCookedDf.withColumn("transactionkey", col("transactionkey").cast("bigint"))
# print("transactionCookedDf")
# a=transactionCookedDf.filter("verifiedsource =='ich'" ).selectExpr("lr_creatingmodule","lr_createdate").dropDuplicates()
# a.createOrReplaceTempView("a")
# spark.sql(""" select * from a order by a.lr_createdate desc""" ).show(10,False)

# COMMAND ----------

def getDemograhicsAsStruct(serveSource, serveInputBc, pathHdfsToServe, pathHdfsTransactionCooked, pathHdfs, source_val,scratch_pat): 
    print("CONTROL in getDemograhicsAsStruct")
    p_factor = 5;
    pathHdfsToServe = pathHdfsToServe + serveInputBc + '/'
    toServeDf = getParquetData(pathHdfsToServe).select("transactionkey", "hospitalfk")
    toServeDf.createOrReplaceTempView("toServeDf")
    toServeDf=spark.sql("""SELECT CAST(TRIM(transactionkey) AS BIGINT) AS transactionkey, hospitalfk FROM toServeDf""")
    toServeDf=toServeDf.withColumn("transactionrange", (col("transactionkey").cast("bigint") % p_factor).cast("bigint")).dropDuplicates()
    #adding new column clientid (i.e. hospitalfk)  for the sharding composite key - join
    toServeDf=toServeDf.withColumn("clientid", col("hospitalfk"))

    print("toServeDf")
    # toServeDf.show()


    transactionCookedDf = getFilteredParquetData(pathHdfsTransactionCooked, "sourcekey", source_val)
    transactionCookedDf=transactionCookedDf.withColumn("transactionkey", trim("transactionkey"))
    transactionCookedDf=transactionCookedDf.withColumn("transactionkey", col("transactionkey").cast("bigint"))
    print("transactionCookedDf")
    # transactionCookedDf.show()


    pathHdfsHcsystems = pathHdfs + "/hcsystems/current/*"
    pathHdfsHospitals = pathHdfs + "/hospitals/current/*"
    pathHdfspa = pathHdfs + "/patientaccts/current/20991231"
    hcsystemsDf = getParquetData(pathHdfsHcsystems).selectExpr("hcsystempk as hcsystemfk").dropDuplicates()
    hospitalDf = getParquetData(pathHdfsHospitals).selectExpr("hospitalpk as hospitalfk", "hcsystemfk").dropDuplicates()
    hospitalXhcsystemsDf = hospitalDf.join(hcsystemsDf,["hcsystemfk","hcsystemfk"], "inner").select("hospitalfk", "hcsystemfk").dropDuplicates()
    print('hospitalXhcsystemsDf created')

    pa=spark.read.format('delta').load(pathHdfspa).selectExpr("patientacctipk", "hospitalfk", "clusteredacctfk").dropDuplicates()
    print("pa")

    #adding clientid (hospitalfk) in the join for composite key
    joinkeys = ["transactionrange", "transactionkey", "clientid"]

    joinedDf = transactionCookedDf.join(toServeDf, joinkeys, "inner").select(
      transactionCookedDf["transactionkey"],
      transactionCookedDf["coverageid"],
      transactionCookedDf["payerid"],
      transactionCookedDf["firstname"],
      transactionCookedDf["middlename"],
      transactionCookedDf["lastname"],
      transactionCookedDf["dob"],
      transactionCookedDf["ssn"],
      transactionCookedDf["gender"],
      transactionCookedDf["createdate"],
      transactionCookedDf["updatedate"],
      transactionCookedDf["clientid"],
      transactionCookedDf["state"],
      transactionCookedDf["sourcepatientacctifk"].alias("patientacctipk"),
      transactionCookedDf["dependentflag"],
      transactionCookedDf["verifiedsource"].alias("leadsource")
    ).withColumn("bc", lit(serveInputBc)).filter("clientid is not null").dropDuplicates()

    joinedDf.write.mode("overwrite").parquet(scratch_path + "/joinedf/" + serveInputBc )
    print(scratch_path + "/joinedf/" + serveInputBc)
    joinedDf_read = spark.read.parquet(scratch_path + "/joinedf/" + serveInputBc)
    # joinedDf_read.show()

    joinedDf_read.createOrReplaceTempView("JOINED")

    sparkSql01 ="""SELECT A.*,
                    CONCAT(A.payerid,"_",A.coverageid) AS leadid,
                    CASE
                    WHEN (A.firstname IS NULL AND A.lastname IS NULL AND A.dob IS NULL AND A.ssn IS NULL AND A.gender IS NULL) THEN '0'
                    ELSE '1'
                    END AS isdemovalid,
                    CASE WHEN LENGTH(TRIM(A.dob)) > 9
                        THEN CAST(
                            concat(
                                    date_format(A.dob,'yyyy'),"-",
                                    date_format(A.dob,'MM'),"-",
                                    date_format(A.dob,'dd')
                                    ) AS STRING)
                        ELSE
                            CAST(
                                    concat(
                                        SUBSTR(A.dob,1,4),"-",
                                        SUBSTR(A.dob,5,2),"-",
                                        SUBSTR(A.dob,7,2)
                                        ) AS STRING)
                        END AS formated_dob,
                    CAST(regexp_replace (regexp_replace (regexp_replace (regexp_replace ((SPLIT (cast(A.createdate as timestamp),"\\\.")[0]),"T",""),":",""),"-","")," ","") AS BIGINT) AS createdate_as_bigint,
                    CAST(regexp_replace (regexp_replace (regexp_replace (regexp_replace ((SPLIT (cast(A.updatedate as timestamp),"\\\.")[0]),"T",""),":",""),"-","")," ","") AS BIGINT) AS updatedate_as_bigint
                    FROM JOINED A
                           """
    temp = spark.sql(sparkSql01).filter(col("isdemovalid") == 1).dropDuplicates()
    print("SPARKSQL01 executed")

    temp.write.mode("overwrite").parquet(scratch_path + "/joinedf_stage2_temp/" + serveInputBc)
    temp_read = spark.read.parquet(scratch_path + "/joinedf_stage2_temp/" + serveInputBc)
    print(scratch_path + "/joinedf_stage2_temp/" + serveInputBc)

    for column in temp_read.columns:
        temp_read = temp_read.withColumn(column, regexp_replace(col(column),'\\\\',''))
        temp_read = temp_read.withColumn(column, regexp_replace(col(column),'@',''))
        temp_read = temp_read.withColumn(column, regexp_replace(col(column),'~',''))

    temp_read.createOrReplaceTempView("CLEANSED")
    print("Control aftre temp_read ")
    sparkSql02 ="""      SELECT
                         A.transactionkey,
                         A.leadid,
                         A.coverageid,
                         A.payerid,
                         A.dependentflag,
                         A.firstname,
                         A.middlename,
                         A.lastname,
                         A.formated_dob                                                                                                                             AS dob,
                        A.ssn,
                        A.gender,
                        A.state,
                        A.clientid,
                        A.bc,
                        A.patientacctipk,
                        A.leadsource,
                        A.createdate_as_bigint,
                        A.updatedate_as_bigint,
                        CASE WHEN LENGTH(A.createdate_as_bigint) >= 14 THEN '1' ELSE '0' END AS isDateValid,
                        CAST(CONCAT(
                                    SUBSTR(A.createdate_as_bigint,1,4),"-",
                                    SUBSTR(A.createdate_as_bigint,5,2),"-",
                                    SUBSTR(A.createdate_as_bigint,7,2)," ",
                                    SUBSTR(A.createdate_as_bigint,9,2),":",
                                    SUBSTR(A.createdate_as_bigint,11,2),":",
                                    SUBSTR(A.createdate_as_bigint,13,2)
                                    ) AS STRING) AS createdate,
                        CAST(CONCAT(
                                    SUBSTR(A.updatedate_as_bigint,1,4),"-",
                                    SUBSTR(A.updatedate_as_bigint,5,2),"-",
                                    SUBSTR(A.updatedate_as_bigint,7,2)," ",
                                    SUBSTR(A.updatedate_as_bigint,9,2),":",
                                    SUBSTR(A.updatedate_as_bigint,11,2),":",
                                    SUBSTR(A.updatedate_as_bigint,13,2)
                                    ) AS STRING) AS updatedate,
                        A.isdemovalid
                        FROM CLEANSED A """
    cleansedDf = spark.sql(sparkSql02).filter("isDateValid = 1").drop("isDateValid").filter("coverageid != ''").filter("payerid != ''").dropDuplicates()
    print("Control after cleansedDf ")


    if ((serveSource == "fc") or (serveSource == "hfc") or (serveSource == "mh")) :
      print("SERVERSOURCE = "+serveSource)
      cleansedDf2 = cleansedDf.withColumnRenamed("clientid", "hospitalfk").withColumn("source", lit(serveSource));
      print("cleansedDf2 done")
      finalCleansedDf = cleansedDf2.join(hospitalXhcsystemsDf, ["hospitalfk"], "inner").select(
        cleansedDf2["transactionkey"],
        cleansedDf2["leadid"],
        cleansedDf2["isdemovalid"],
        cleansedDf2["createdate_as_bigint"],
        cleansedDf2["patientacctipk"],
        cleansedDf2["updatedate_as_bigint"],
        when(hospitalXhcsystemsDf["hcsystemfk"].isNull(), "").otherwise(hospitalXhcsystemsDf["hcsystemfk"]).alias("hcsystemfk"),
        when(cleansedDf2["hospitalfk"].isNull(), "").otherwise(cleansedDf2["hospitalfk"]).alias("hospitalfk"),
        when(cleansedDf2["source"].isNull(), "").otherwise(cleansedDf2["source"]).alias("source"),
        when(cleansedDf2["leadsource"].isNull(), "").otherwise(cleansedDf2["leadsource"]).alias("leadsource"),
        when(cleansedDf2["bc"].isNull(), "").otherwise(cleansedDf2["bc"]).alias("bc"),
        when(cleansedDf2["dependentflag"].isNull(), "").otherwise(cleansedDf2["dependentflag"]).alias("dependentflag"),
        when(cleansedDf2["createdate"].isNull(), "").otherwise(cleansedDf2["createdate"]).alias("createdate"),
        when(cleansedDf2["updatedate"].isNull(), cleansedDf2["createdate"]).otherwise(cleansedDf2["updatedate"]).alias("updatedate"),
        struct(
          when(cleansedDf2["firstname"].isNull(), "").otherwise(cleansedDf2["firstname"]).alias("firstname"),
          when(cleansedDf2["middlename"].isNull(), "").otherwise(cleansedDf2["middlename"]).alias("middlename"),
          when(cleansedDf2["lastname"].isNull(), "").otherwise(cleansedDf2["lastname"]).alias("lastname"),
          when(cleansedDf2["dob"].isNull(), "").otherwise(cleansedDf2["dob"]).alias("dob"),
          when(cleansedDf2["ssn"].isNull(), "").otherwise(cleansedDf2["ssn"]).alias("ssn"),
          when(cleansedDf2["gender"].isNull(), "").otherwise(cleansedDf2["gender"]).alias("gender"),
          when(cleansedDf2["state"].isNull(), "").otherwise(cleansedDf2["state"]).alias("state"),
          when(cleansedDf2["dependentflag"].isNull(), "").otherwise(cleansedDf2["dependentflag"]).alias("dependentflag"),
          when(cleansedDf2["createdate"].isNull(), "").otherwise(cleansedDf2["createdate"]).alias("createdate"),
          when(cleansedDf2["updatedate"].isNull(), cleansedDf2["createdate"]).otherwise(cleansedDf2["updatedate"]).alias("updatedate"),
          when(cleansedDf2["hospitalfk"].isNull(), "").otherwise(cleansedDf2["hospitalfk"]).alias("hospitalfk"),
          when(hospitalXhcsystemsDf["hcsystemfk"].isNull(), "").otherwise(hospitalXhcsystemsDf["hcsystemfk"]).alias("hcsystemfk"),
          when(cleansedDf2["bc"].isNull(), "").otherwise(cleansedDf2["bc"]).alias("bc"),
          when(cleansedDf2["source"].isNull(), "").otherwise(cleansedDf2["source"]).alias("source"),
          when(cleansedDf2["leadsource"].isNull(), "").otherwise(cleansedDf2["leadsource"]).alias("leadsource")
        ).alias("demographics")
      ).dropDuplicates()
      print('before join')


      joinkeys1 = ["patientacctipk", "hospitalfk"]


      joinedpa = finalCleansedDf.alias("fcd").join(pa, joinkeys1, "inner").select(
        "fcd.*",
        "clusteredacctfk"
      ).dropDuplicates()
      print('after join')

      joinedpa.createOrReplaceTempView("FC_CLEANSED")


      sparkSql03 ="""
                    SELECT
                     A.transactionkey,
                     A.leadid,
                     A.isdemovalid,
                     A.createdate_as_bigint,
                     A.hcsystemfk,
                     A.hospitalfk,
                     A.source,
                     A.leadsource,
                     A.bc,
                     struct(
                      A.demographics.firstname as firstname,
                      A.demographics.middlename as middlename,
                      A.demographics.lastname as lastname,
                      A.demographics.dob as dob,
                      A.demographics.ssn as ssn,
                      A.demographics.gender as gender,
                      A.demographics.dependentflag as dependentflag ,
                      A.createdate_min as createdate,
                      A.updatedate_max as updatedate ,
                      A.demographics.hospitalfk as hospitalfk,
                      A.demographics.hcsystemfk as hcsystemfk,
                      A.demographics.bc as bc,
                      A.demographics.source as source ,
                      A.demographics.state as state ,
                      A.demographics.leadsource as leadsource
                     ) as demographics
                   FROM (SELECT A.transactionkey,
                            A.leadid,
                            A.isdemovalid,
                            A.createdate_as_bigint,
                            A.hcsystemfk,
                            A.hospitalfk,
                            A.source,
                            A.leadsource,
                            A.bc,
                            max(A.createdate) over (PARTITION BY A.leadid,A.hospitalfk,A.hcsystemfk,A.clusteredacctfk ORDER BY A.createdate_as_bigint) as createdate_min,
                            max(A.updatedate) over (PARTITION BY A.leadid,A.hospitalfk,A.hcsystemfk,A.clusteredacctfk ORDER BY A.updatedate_as_bigint desc) as updatedate_max,
                            A.demographics,
                            RANK() OVER (PARTITION BY A.leadid,A.hospitalfk,A.hcsystemfk,A.clusteredacctfk ORDER BY A.updatedate_as_bigint DESC , A.dependentflag DESC) AS RNK
                     FROM FC_CLEANSED A) A
              WHERE A.RNK = 1"""

      finalCleansedDf2 = spark.sql(sparkSql03).dropDuplicates()
      print('after sql')
      return finalCleansedDf2
    
    elif ((serveSource == "ich") or (serveSource == "chc") ):
      print("Contron In : ICH Block")
      cleansedTemp = cleansedDf.withColumn("hospitalfk", col("clientid")).withColumn("source", lit(serveSource))
      cleansedTemp2 = cleansedTemp.withColumn("updatedate", when(col("updatedate").isNull(), col("createdate")).otherwise(col("updatedate")))
      tu_payer_mapping = extract_tupayer_data(pathHdfs)
      a = tu_payer_mapping.select("edipartnerfk").dropDuplicates()
      cleansedTemp2.createOrReplaceTempView("tbl1")
      a.createOrReplaceTempView("tbl2")

      sql2  = """select * from tbl1 where payerid in (select distinct edipartnerfk from tbl2)"""

      cleansedTemp3 = spark.sql(sql2)

      cleansedTemp3.createOrReplaceTempView("ICH_CLEANSED")

      sparkSql03 ="""
                      SELECT
                      A.transactionkey,
                      A.leadid,
                      A.coverageid,
                      A.payerid,
                      A.firstname,
                      A.middlename,
                      A.lastname,
                      A.dob,
                      A.ssn,
                      A.gender,
                      A.state,
                      A.clientid as hcsystemfk,
                      A.bc,
                      A.createdate_as_bigint,
                      A.createdate,
                      A.createdate as createdate_min,
                      A.updatedate as updatedate_max,
                      A.hospitalfk,
                      A.source,
                      A.dependentflag,
                      A.leadsource,
                      A.isdemovalid
               FROM ICH_CLEANSED A
               """

      cleansedDf2 = spark.sql(sparkSql03).dropDuplicates()


      finalCleansedDf = cleansedDf2.select(
        cleansedDf2["transactionkey"],
        cleansedDf2["leadid"],
        cleansedDf2["isdemovalid"],
        cleansedDf2["dependentflag"],
        cleansedDf2["createdate_as_bigint"],
        when(cleansedDf2["hcsystemfk"].isNull(), "").otherwise(cleansedDf2["hcsystemfk"]).alias("hcsystemfk"),
        when(cleansedDf2["hospitalfk"].isNull(), "").otherwise(cleansedDf2["hospitalfk"]).alias("hospitalfk"),
        when(cleansedDf2["source"].isNull(), "").otherwise(cleansedDf2["source"]).alias("source"),
        when(cleansedDf2["leadsource"].isNull(), "").otherwise(cleansedDf2["leadsource"]).alias("leadsource"),
        when(cleansedDf2["bc"].isNull(), "").otherwise(cleansedDf2["bc"]).alias("bc"),
        struct(
          when(cleansedDf2["firstname"].isNull(), "").otherwise(cleansedDf2["firstname"]).alias("firstname"),
          when(cleansedDf2["state"].isNull(), "").otherwise(cleansedDf2["state"]).alias("state"),
          when(cleansedDf2["middlename"].isNull(), "").otherwise(cleansedDf2["middlename"]).alias("middlename"),
          when(cleansedDf2["lastname"].isNull(), "").otherwise(cleansedDf2["lastname"]).alias("lastname"),
          when(cleansedDf2["dob"].isNull(), "").otherwise(cleansedDf2["dob"]).alias("dob"),
          when(cleansedDf2["ssn"].isNull(), "").otherwise(cleansedDf2["ssn"]).alias("ssn"),
          when(cleansedDf2["gender"].isNull(), "").otherwise(cleansedDf2["gender"]).alias("gender"),
          when(cleansedDf2["dependentflag"].isNull(), "").otherwise(cleansedDf2["dependentflag"]).alias("dependentflag"),
          when(cleansedDf2["createdate_min"].isNull(), "").otherwise(cleansedDf2["createdate_min"]).alias("createdate"),
          when(cleansedDf2["updatedate_max"].isNull(), cleansedDf2["createdate_min"]).otherwise(cleansedDf2["updatedate_max"]).alias("updatedate"),
          when(cleansedDf2["hospitalfk"].isNull(), "").otherwise(cleansedDf2["hospitalfk"]).alias("hospitalfk"),
          when(cleansedDf2["hcsystemfk"].isNull(), "").otherwise(cleansedDf2["hcsystemfk"]).alias("hcsystemfk"),
          when(cleansedDf2["bc"].isNull(), "").otherwise(cleansedDf2["bc"]).alias("bc"),
          when(cleansedDf2["source"].isNull(), "").otherwise(cleansedDf2["source"]).alias("source"),
          when(cleansedDf2["leadsource"].isNull(), "").otherwise(cleansedDf2["leadsource"]).alias("leadsource")
        ).alias("demographics")
      )
      return finalCleansedDf


    else:
      print("invalid Source :" + serveSource );
      return null

# COMMAND ----------

def getDemograhicsAsStruct_ich(serveSource, serveInputBc, pathHdfsToServe, pathHdfsTransactionCooked, pathHdfs, source_val,scratch_pat): 
    print("CONTROL in getDemograhicsAsStruct_ich")
    p_factor = 5;
    pathHdfsToServe = pathHdfsToServe + serveInputBc + '/'
    toServeDf = getParquetData(pathHdfsToServe).select("transactionkey","dependentflag","xrefsource","identity")
    toServeDf.createOrReplaceTempView("toServeDf")
    toServeDf=spark.sql("""SELECT CAST(TRIM(transactionkey) AS BIGINT) AS transactionkey,dependentflag,xrefsource,identity FROM toServeDf""")
    toServeDf=toServeDf.withColumn("transactionrange", (col("transactionkey").cast("bigint") % p_factor).cast("bigint")).dropDuplicates()
    print("toServeDf")
    # toServeDf.show()

    transactionCookedDf = getFilteredParquetData(pathHdfsTransactionCooked, "sourcekey", source_val)
    transactionCookedDf=transactionCookedDf.withColumn("transactionkey", trim("transactionkey"))
    transactionCookedDf=transactionCookedDf.withColumn("transactionkey", col("transactionkey").cast("bigint"))
    print("transactionCookedDf")
    # transactionCookedDf.show()


    pathHdfsHcsystems = pathHdfs + "/hcsystems/current/*"
    pathHdfsHospitals = pathHdfs + "/hospitals/current/*"
    pathHdfspa = pathHdfs + "/patientaccts/current/20991231"
    hcsystemsDf = getParquetData(pathHdfsHcsystems).selectExpr("hcsystempk as hcsystemfk").dropDuplicates()
    hospitalDf = getParquetData(pathHdfsHospitals).selectExpr("hospitalpk as hospitalfk", "hcsystemfk").dropDuplicates()
    hospitalXhcsystemsDf = hospitalDf.join(hcsystemsDf,["hcsystemfk","hcsystemfk"], "inner").select("hospitalfk", "hcsystemfk").dropDuplicates()
    print('hospitalXhcsystemsDf created')

    pa=spark.read.format('delta').load(pathHdfspa).selectExpr("patientacctipk", "hospitalfk", "clusteredacctfk").dropDuplicates()
    print("pa")

    joinkeys = ["transactionrange", "transactionkey","dependentflag"]

    joinedDf = transactionCookedDf.join(toServeDf, joinkeys, "inner").select(
      transactionCookedDf["transactionkey"],
      transactionCookedDf["coverageid"],
      transactionCookedDf["payerid"],
      transactionCookedDf["firstname"],
      transactionCookedDf["middlename"],
      transactionCookedDf["lastname"],
      transactionCookedDf["dob"],
      transactionCookedDf["ssn"],
      transactionCookedDf["gender"],
      transactionCookedDf["createdate"],
      transactionCookedDf["updatedate"],
      transactionCookedDf["clientid"],
      transactionCookedDf["state"],
      transactionCookedDf["sourcepatientacctifk"].alias("patientacctipk"),
      transactionCookedDf["dependentflag"],
      transactionCookedDf["verifiedsource"].alias("leadsource"),
      toServeDf["xrefsource"],
      toServeDf["identity"]
    ).withColumn("bc", lit(serveInputBc)).filter("clientid is not null").dropDuplicates()

    joinedDf.write.mode("overwrite").parquet(scratch_path + "/joinedf/" + serveInputBc )
    print(scratch_path + "/joinedf/" + serveInputBc)
    joinedDf_read = spark.read.parquet(scratch_path + "/joinedf/" + serveInputBc)
    # joinedDf_read.show()

    joinedDf_read.createOrReplaceTempView("JOINED")

    sparkSql01 ="""SELECT A.*,
                    CONCAT(A.payerid,"_",A.coverageid) AS leadid,
                    CASE
                    WHEN (A.firstname IS NULL AND A.lastname IS NULL AND A.dob IS NULL AND A.ssn IS NULL AND A.gender IS NULL) THEN '0'
                    ELSE '1'
                    END AS isdemovalid,
                    CASE WHEN LENGTH(TRIM(A.dob)) > 9
                        THEN CAST(
                            concat(
                                    date_format(A.dob,'yyyy'),"-",
                                    date_format(A.dob,'MM'),"-",
                                    date_format(A.dob,'dd')
                                    ) AS STRING)
                        ELSE
                            CAST(
                                    concat(
                                        SUBSTR(A.dob,1,4),"-",
                                        SUBSTR(A.dob,5,2),"-",
                                        SUBSTR(A.dob,7,2)
                                        ) AS STRING)
                        END AS formated_dob,
                    CAST(regexp_replace (regexp_replace (regexp_replace (regexp_replace ((SPLIT (cast(A.createdate as timestamp),"\\\.")[0]),"T",""),":",""),"-","")," ","") AS BIGINT) AS createdate_as_bigint,
                    CAST(regexp_replace (regexp_replace (regexp_replace (regexp_replace ((SPLIT (cast(A.updatedate as timestamp),"\\\.")[0]),"T",""),":",""),"-","")," ","") AS BIGINT) AS updatedate_as_bigint
                    FROM JOINED A
                           """
    temp = spark.sql(sparkSql01).filter(col("isdemovalid") == 1).dropDuplicates()
    print("SPARKSQL01 executed")

    temp.write.mode("overwrite").parquet(scratch_path + "/joinedf_stage2_temp/" + serveInputBc)
    temp_read = spark.read.parquet(scratch_path + "/joinedf_stage2_temp/" + serveInputBc)
    print(scratch_path + "/joinedf_stage2_temp/" + serveInputBc)

    for column in temp_read.columns:
        temp_read = temp_read.withColumn(column, regexp_replace(col(column),'\\\\',''))
        temp_read = temp_read.withColumn(column, regexp_replace(col(column),'@',''))
        temp_read = temp_read.withColumn(column, regexp_replace(col(column),'~',''))

    temp_read.createOrReplaceTempView("CLEANSED")
    print("Control aftre temp_read ")
    sparkSql02 ="""      SELECT
                         A.transactionkey,
                         A.leadid,
                         A.coverageid,
                         A.payerid,
                         A.dependentflag,
                         A.firstname,
                         A.middlename,
                         A.lastname,
                         A.formated_dob                                                                                                        AS dob,
                        A.ssn,
                        A.gender,
                        A.state,
                        A.clientid,
                        A.bc,
                        A.patientacctipk,
                        A.leadsource,
                        A.createdate_as_bigint,
                        A.updatedate_as_bigint,
                        CASE WHEN LENGTH(A.createdate_as_bigint) >= 14 THEN '1' ELSE '0' END AS isDateValid,
                        CAST(CONCAT(
                                    SUBSTR(A.createdate_as_bigint,1,4),"-",
                                    SUBSTR(A.createdate_as_bigint,5,2),"-",
                                    SUBSTR(A.createdate_as_bigint,7,2)," ",
                                    SUBSTR(A.createdate_as_bigint,9,2),":",
                                    SUBSTR(A.createdate_as_bigint,11,2),":",
                                    SUBSTR(A.createdate_as_bigint,13,2)
                                    ) AS STRING) AS createdate,
                        CAST(CONCAT(
                                    SUBSTR(A.updatedate_as_bigint,1,4),"-",
                                    SUBSTR(A.updatedate_as_bigint,5,2),"-",
                                    SUBSTR(A.updatedate_as_bigint,7,2)," ",
                                    SUBSTR(A.updatedate_as_bigint,9,2),":",
                                    SUBSTR(A.updatedate_as_bigint,11,2),":",
                                    SUBSTR(A.updatedate_as_bigint,13,2)
                                    ) AS STRING) AS updatedate,
                        A.isdemovalid,
                        A.xrefsource,
                        A.identity
                        FROM CLEANSED A """
    cleansedDf = spark.sql(sparkSql02).filter("isDateValid = 1").drop("isDateValid").filter("coverageid != ''").filter("payerid != ''").dropDuplicates()
    print("Control after cleansedDf ")


    if ((serveSource == "fc") or (serveSource == "hfc") or (serveSource == "mh")) :
      print("SERVERSOURCE = "+serveSource)
      cleansedDf2 = cleansedDf.withColumnRenamed("clientid", "hospitalfk").withColumn("source", lit(serveSource));
      print("cleansedDf2 done")
      finalCleansedDf = cleansedDf2.join(hospitalXhcsystemsDf, ["hospitalfk"], "inner").select(
        cleansedDf2["transactionkey"],
        cleansedDf2["leadid"],
        cleansedDf2["isdemovalid"],
        cleansedDf2["createdate_as_bigint"],
        cleansedDf2["patientacctipk"],
        cleansedDf2["updatedate_as_bigint"],
        when(hospitalXhcsystemsDf["hcsystemfk"].isNull(), "").otherwise(hospitalXhcsystemsDf["hcsystemfk"]).alias("hcsystemfk"),
        when(cleansedDf2["hospitalfk"].isNull(), "").otherwise(cleansedDf2["hospitalfk"]).alias("hospitalfk"),
        when(cleansedDf2["source"].isNull(), "").otherwise(cleansedDf2["source"]).alias("source"),
        when(cleansedDf2["leadsource"].isNull(), "").otherwise(cleansedDf2["leadsource"]).alias("leadsource"),
        when(cleansedDf2["bc"].isNull(), "").otherwise(cleansedDf2["bc"]).alias("bc"),
        when(cleansedDf2["dependentflag"].isNull(), "").otherwise(cleansedDf2["dependentflag"]).alias("dependentflag"),
        when(cleansedDf2["createdate"].isNull(), "").otherwise(cleansedDf2["createdate"]).alias("createdate"),
        when(cleansedDf2["updatedate"].isNull(), cleansedDf2["createdate"]).otherwise(cleansedDf2["updatedate"]).alias("updatedate"),
        struct(
          when(cleansedDf2["firstname"].isNull(), "").otherwise(cleansedDf2["firstname"]).alias("firstname"),
          when(cleansedDf2["middlename"].isNull(), "").otherwise(cleansedDf2["middlename"]).alias("middlename"),
          when(cleansedDf2["lastname"].isNull(), "").otherwise(cleansedDf2["lastname"]).alias("lastname"),
          when(cleansedDf2["dob"].isNull(), "").otherwise(cleansedDf2["dob"]).alias("dob"),
          when(cleansedDf2["ssn"].isNull(), "").otherwise(cleansedDf2["ssn"]).alias("ssn"),
          when(cleansedDf2["gender"].isNull(), "").otherwise(cleansedDf2["gender"]).alias("gender"),
          when(cleansedDf2["state"].isNull(), "").otherwise(cleansedDf2["state"]).alias("state"),
          when(cleansedDf2["dependentflag"].isNull(), "").otherwise(cleansedDf2["dependentflag"]).alias("dependentflag"),
          when(cleansedDf2["createdate"].isNull(), "").otherwise(cleansedDf2["createdate"]).alias("createdate"),
          when(cleansedDf2["updatedate"].isNull(), cleansedDf2["createdate"]).otherwise(cleansedDf2["updatedate"]).alias("updatedate"),
          when(cleansedDf2["hospitalfk"].isNull(), "").otherwise(cleansedDf2["hospitalfk"]).alias("hospitalfk"),
          when(hospitalXhcsystemsDf["hcsystemfk"].isNull(), "").otherwise(hospitalXhcsystemsDf["hcsystemfk"]).alias("hcsystemfk"),
          when(cleansedDf2["bc"].isNull(), "").otherwise(cleansedDf2["bc"]).alias("bc"),
          when(cleansedDf2["source"].isNull(), "").otherwise(cleansedDf2["source"]).alias("source"),
          when(cleansedDf2["leadsource"].isNull(), "").otherwise(cleansedDf2["leadsource"]).alias("leadsource")
        ).alias("demographics")
      ).dropDuplicates()
      print('before join')


      joinkeys1 = ["patientacctipk", "hospitalfk"]


      joinedpa = finalCleansedDf.alias("fcd").join(pa, joinkeys1, "inner").select(
        "fcd.*",
        "clusteredacctfk"
      ).dropDuplicates()
      print('after join')

      joinedpa.createOrReplaceTempView("FC_CLEANSED")


      sparkSql03 ="""
                    SELECT
                     A.transactionkey,
                     A.leadid,
                     A.isdemovalid,
                     A.createdate_as_bigint,
                     A.hcsystemfk,
                     A.hospitalfk,
                     A.source,
                     A.leadsource,
                     A.bc,
                     struct(
                      A.demographics.firstname as firstname,
                      A.demographics.middlename as middlename,
                      A.demographics.lastname as lastname,
                      A.demographics.dob as dob,
                      A.demographics.ssn as ssn,
                      A.demographics.gender as gender,
                      A.demographics.dependentflag as dependentflag ,
                      A.createdate_min as createdate,
                      A.updatedate_max as updatedate ,
                      A.demographics.hospitalfk as hospitalfk,
                      A.demographics.hcsystemfk as hcsystemfk,
                      A.demographics.bc as bc,
                      A.demographics.source as source ,
                      A.demographics.state as state ,
                      A.demographics.leadsource as leadsource
                     ) as demographics
                   FROM (SELECT A.transactionkey,
                            A.leadid,
                            A.isdemovalid,
                            A.createdate_as_bigint,
                            A.hcsystemfk,
                            A.hospitalfk,
                            A.source,
                            A.leadsource,
                            A.bc,
                            max(A.createdate) over (PARTITION BY A.leadid,A.hospitalfk,A.hcsystemfk,A.clusteredacctfk ORDER BY A.createdate_as_bigint) as createdate_min,
                            max(A.updatedate) over (PARTITION BY A.leadid,A.hospitalfk,A.hcsystemfk,A.clusteredacctfk ORDER BY A.updatedate_as_bigint desc) as updatedate_max,
                            A.demographics,
                            RANK() OVER (PARTITION BY A.leadid,A.hospitalfk,A.hcsystemfk,A.clusteredacctfk ORDER BY A.updatedate_as_bigint DESC , A.dependentflag DESC) AS RNK
                     FROM FC_CLEANSED A) A
              WHERE A.RNK = 1"""

      finalCleansedDf2 = spark.sql(sparkSql03).dropDuplicates()
      print('after sql')
      return finalCleansedDf2
    
    elif ((serveSource == "ich") or (serveSource == "chc") ):
      print("Contron In : ICH Block")
      cleansedTemp = cleansedDf.withColumn("hospitalfk", col("clientid")).withColumn("source", lit(serveSource))
      cleansedTemp2 = cleansedTemp.withColumn("updatedate", when(col("updatedate").isNull(), col("createdate")).otherwise(col("updatedate")))
      tu_payer_mapping = extract_tupayer_data(pathHdfs)
      a = tu_payer_mapping.select("edipartnerfk").dropDuplicates()
      cleansedTemp2.createOrReplaceTempView("tbl1")
      a.createOrReplaceTempView("tbl2")

      sql2  = """select * from tbl1 where payerid in (select distinct edipartnerfk from tbl2)"""

      cleansedTemp3 = spark.sql(sql2)

      cleansedTemp3.createOrReplaceTempView("ICH_CLEANSED")

      sparkSql03 ="""
                      SELECT
                      A.transactionkey,
                      A.leadid,
                      A.coverageid,
                      A.payerid,
                      A.firstname,
                      A.middlename,
                      A.lastname,
                      A.dob,
                      A.ssn,
                      A.gender,
                      A.state,
                      A.clientid as hcsystemfk,
                      A.bc,
                      A.createdate_as_bigint,
                      A.createdate,
                      A.createdate as createdate_min,
                      A.updatedate as updatedate_max,
                      A.hospitalfk,
                      A.source,
                      A.dependentflag,
                      A.leadsource,
                      A.isdemovalid,
                      A.xrefsource,
                      A.identity
               FROM ICH_CLEANSED A
               """

      cleansedDf2 = spark.sql(sparkSql03).dropDuplicates()


      finalCleansedDf = cleansedDf2.select(
        cleansedDf2["transactionkey"],
        cleansedDf2["leadid"],
        cleansedDf2["isdemovalid"],
        cleansedDf2["dependentflag"],
        cleansedDf2["createdate_as_bigint"],
        when(cleansedDf2["hcsystemfk"].isNull(), "").otherwise(cleansedDf2["hcsystemfk"]).alias("hcsystemfk"),
        when(cleansedDf2["hospitalfk"].isNull(), "").otherwise(cleansedDf2["hospitalfk"]).alias("hospitalfk"),
        when(cleansedDf2["source"].isNull(), "").otherwise(cleansedDf2["source"]).alias("source"),
        when(cleansedDf2["leadsource"].isNull(), "").otherwise(cleansedDf2["leadsource"]).alias("leadsource"),
        when(cleansedDf2["bc"].isNull(), "").otherwise(cleansedDf2["bc"]).alias("bc"),
        struct(
          when(cleansedDf2["firstname"].isNull(), "").otherwise(cleansedDf2["firstname"]).alias("firstname"),
          when(cleansedDf2["state"].isNull(), "").otherwise(cleansedDf2["state"]).alias("state"),
          when(cleansedDf2["middlename"].isNull(), "").otherwise(cleansedDf2["middlename"]).alias("middlename"),
          when(cleansedDf2["lastname"].isNull(), "").otherwise(cleansedDf2["lastname"]).alias("lastname"),
          when(cleansedDf2["dob"].isNull(), "").otherwise(cleansedDf2["dob"]).alias("dob"),
          when(cleansedDf2["ssn"].isNull(), "").otherwise(cleansedDf2["ssn"]).alias("ssn"),
          when(cleansedDf2["gender"].isNull(), "").otherwise(cleansedDf2["gender"]).alias("gender"),
          when(cleansedDf2["dependentflag"].isNull(), "").otherwise(cleansedDf2["dependentflag"]).alias("dependentflag"),
          when(cleansedDf2["createdate_min"].isNull(), "").otherwise(cleansedDf2["createdate_min"]).alias("createdate"),
          when(cleansedDf2["updatedate_max"].isNull(), cleansedDf2["createdate_min"]).otherwise(cleansedDf2["updatedate_max"]).alias("updatedate"),
          when(cleansedDf2["hospitalfk"].isNull(), "").otherwise(cleansedDf2["hospitalfk"]).alias("hospitalfk"),
          when(cleansedDf2["hcsystemfk"].isNull(), "").otherwise(cleansedDf2["hcsystemfk"]).alias("hcsystemfk"),
          when(cleansedDf2["bc"].isNull(), "").otherwise(cleansedDf2["bc"]).alias("bc"),
          when(cleansedDf2["source"].isNull(), "").otherwise(cleansedDf2["source"]).alias("source"),
          when(cleansedDf2["leadsource"].isNull(), "").otherwise(cleansedDf2["leadsource"]).alias("leadsource")
        ).alias("demographics"),
        cleansedDf2["xrefsource"],
        cleansedDf2["identity"].alias("lookupvalue")
      )
      finalCleansedDf = finalCleansedDf.withColumn("sourcekey",lit(source_val))
      return finalCleansedDf
    
    else:
      print("invalid Source :" + serveSource );
      return null

# COMMAND ----------

if __name__ == '__main__':
    main()

# COMMAND ----------


