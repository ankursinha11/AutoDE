// Databricks notebook source
import org.apache.spark.sql.{DataFrame}
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.{col, _}
import scala.collection.Map
import io.delta.tables._
import org.apache.spark.sql.expressions.{Window, WindowSpec}
import scala.io.Source
import scala.collection._
import java.time.format.DateTimeFormatter
import java.time.LocalDate
import java.time.LocalDateTime
import io.delta.tables._
import spark.implicits._
import org.apache.spark.sql.types._
import org.apache.spark.sql.Column
import org.apache.spark.sql.expressions.UserDefinedFunction

// COMMAND ----------

// dbutils.widgets.text("hdfs_path","abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/divya/data/leadrepo/scratch/leadservicebase/json_demog/")
// dbutils.widgets.text("deltalake_output","abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/divya/data/test_leadrepo/publish/served/divya_leadservicebase_clusterid")
// dbutils.widgets.text("id_column","transactionkey")
// dbutils.widgets.text("store_path","abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/divya/data/leadrepo/publish/cooked/lr_xref_ssn_mrn_cluster_transaction")
// dbutils.widgets.text("list_column","clusteredacctfk")
// dbutils.widgets.text("num_partition","2500")
// val num_partition=dbutils.widgets.get("num_partition").toInt

// dbutils.widgets.text("column_to_get","lookupvalue")
// val column_to_get=dbutils.widgets.get("column_to_get")

// dbutils.widgets.text("sec_index_name","idx_transkey")
// val sec_index_name=dbutils.widgets.get("sec_index_name")

// dbutils.widgets.text("config_file_path","abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/data/leadservicebase/leadservicebase_create/config.txt")
// val config_file_path=dbutils.widgets.get("config_file_path")

// dbutils.widgets.text("source","fc")
// val source=dbutils.widgets.get("source")

// dbutils.widgets.text("hospitalfk_field_name","hospitalfk")
// val hospitalfk_field_name=dbutils.widgets.get("hospitalfk_field_name")

// dbutils.widgets.text("source_col","sourcekey")
// val source_col=dbutils.widgets.get("source_col")

// dbutils.widgets.text("temp_op_path","abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/divya/data/leadrepo/scratch/leadservicebase/")
// val temp_op_path=dbutils.widgets.get("temp_op_path")

// dbutils.widgets.text("user","phd9appl")
// val user=dbutils.widgets.get("user")

// dbutils.widgets.text("bc","20230915T00")
// val bc=dbutils.widgets.get("bc")

// dbutils.widgets.text("leadlookupoppath","abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/divya/data/leadrepo/publish/cooked/leadservicebasehelper/")
// val leadlookupoppath=dbutils.widgets.get("leadlookupoppath")

// COMMAND ----------

// DBTITLE 1,Input Parameters
dbutils.widgets.text("hdfs_path","")
val hdfs_path=dbutils.widgets.get("hdfs_path")

dbutils.widgets.text("deltalake_output","")
val deltalake_output=dbutils.widgets.get("deltalake_output")

dbutils.widgets.text("id_column","")
val id_column=dbutils.widgets.get("id_column")

dbutils.widgets.text("store_path","")
val store_path=dbutils.widgets.get("store_path")

dbutils.widgets.text("list_column","")
val list_column=dbutils.widgets.get("list_column")

dbutils.widgets.text("num_partition","")
val num_partition=dbutils.widgets.get("num_partition").toInt

dbutils.widgets.text("column_to_get","")
val column_to_get=dbutils.widgets.get("column_to_get")

dbutils.widgets.text("sec_index_name","")
val sec_index_name=dbutils.widgets.get("sec_index_name")

dbutils.widgets.text("config_file_path","")
val config_file_path=dbutils.widgets.get("config_file_path")

dbutils.widgets.text("source","")
val source=dbutils.widgets.get("source")

dbutils.widgets.text("hospitalfk_field_name","")
val hospitalfk_field_name=dbutils.widgets.get("hospitalfk_field_name")

dbutils.widgets.text("source_col","")
val source_col=dbutils.widgets.get("source_col")

dbutils.widgets.text("temp_op_path","")
val temp_op_path=dbutils.widgets.get("temp_op_path")

dbutils.widgets.text("user","")
val user=dbutils.widgets.get("user")

dbutils.widgets.text("bc","")
val bc=dbutils.widgets.get("bc")

dbutils.widgets.text("leadlookupoppath","")
val leadlookupoppath=dbutils.widgets.get("leadlookupoppath")

dbutils.widgets.text("storageaccount","")
val storageaccount=dbutils.widgets.get("storageaccount")

// COMMAND ----------

// DBTITLE 1,ADLS Access
// MAGIC %python
// MAGIC dbutils.widgets.text("storageaccount","")
// MAGIC storageaccount=dbutils.widgets.get("storageaccount")
// MAGIC spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

// COMMAND ----------

// MAGIC %run "/Insleads-code/LeadServiceBase/common/LeadServiceBase-Common"

// COMMAND ----------

def getReferenceIdHosp(df: DataFrame, list_column: String, source_val: String, temp_op_path_formatted: String, df1: DataFrame): Unit = {
    val df2 = df.withColumn("sourcekey", lit(source_val))
    val joinkeys_ref = Seq("transactionkey", "hospitalfk", "sourcekey")
    val df3 = df2.alias("to_serve").join(df1.alias("df1"), joinkeys_ref).select("to_serve.*", list_column, "xrefsource")
    val df4 = df3.withColumnRenamed(list_column,("lookupvalue"))
    // df4.show(20)
    print(temp_op_path_formatted)
    writeParquetData(df4: DataFrame, temp_op_path_formatted: String, "overwrite")
  }

// COMMAND ----------

def prepareDeltalakeHosp(df: DataFrame, column_to_get: String, param_val: String, source: String, id_column_name: String, hospitalfk_field_name: String, num_partition: Int, deltalake_output: String, temp_op_path1: String,bad_record_path: String): Unit = {
    val df1 = df.withColumn(column_to_get, concat_ws("_", lit(param_val), col(hospitalfk_field_name), col(column_to_get)))
    val df2 = df1.withColumn("new_id", concat_ws("_", col("hcsystemfk"), col("source")))
    // display(df2)
    val df3 = df2.select(
      col(column_to_get),
      concat_ws(".", lit("demographics"), col("new_id")).alias("demo_id"),
      col("leadid"),
      concat_ws("~",
        col("lookupvalue"),
        concat_ws(".", lit("demographics"), col("new_id")).alias("new_id"),
        col("source"),
        col("new_id").alias("demo_key"),
        col("demographics.firstname"),
        col("demographics.lastname"),
        col("demographics.dob"),
        col("demographics.middlename"),
        col("demographics.gender"),
        col("demographics.updatedate"),
        col("demographics.hospitalfk"),
        col("demographics.ssn").alias("ssn"),
        col("xrefsource").alias("xrefsource"),
        col("demographics.leadsource").alias("leadsource"),
        col("demographics.state").alias("state"),
        col("demographics.createdate").alias("leadcreatedate")
      ).alias("concat_columns"))
    val df4 = df3.withColumn("_id", concat_ws("_", col(column_to_get), col("leadid")))

    val df5 = df4.withColumn("new_col",split(col("concat_columns"),"~"))

    val df6 = df5.withColumn("size_new_col",size(col("new_col")))

    val df7 = df6.filter(col("size_new_col") === 16)

    val df8 = df6.filter(col("size_new_col") =!= 16) // bad records
    print(temp_op_path1)
    print(bad_record_path)
    writeParquetData(df7: DataFrame, temp_op_path1: String, "overwrite")
    writeParquetData(df8: DataFrame, bad_record_path: String, "overwrite")
  }

// COMMAND ----------

def mapFileHosp(configFilePath: String): Map[String, String] = {
  import spark.implicits._

  val files = spark.read.text(configFilePath).as[String].collect()
  var mappedLines = List.empty[Array[String]]

  for (row <- files) {
    val rowValue = row.trim
    if (rowValue != "" && !rowValue.startsWith(";;;")) {
      val line = rowValue.split(':')
      mappedLines = mappedLines :+ line
    }
  }
  mappedLines.map(pair => pair(0) -> pair(1)).toMap
}

// COMMAND ----------

  val hp = hospitalfk_field_name
  val mp: Map[String, String] = mapFileHosp(config_file_path)
  val source_val = mp.getOrElse(source, null)
  val param_val = mp.getOrElse(list_column, null)
  val id_column_name = id_column

// COMMAND ----------

  val temp_op_path_formatted = temp_op_path + "/new_" + list_column + "_" + source + "_lookupvalue/"
  val temp_op_path1 = temp_op_path + "/new_" + list_column + "_" + source + "_maprdbinput/"
  val temp_op_path2 = temp_op_path + "/new_" + list_column + "_" + source + "_insert_response/" + bc + "/"
  //lsb and input join 
  val temp_op_path3 = temp_op_path + "/new_" + list_column + "_" + source + "_lsb_join/" + bc + "/"
  //before upsert into lsb
  val temp_op_path4 = temp_op_path + "/new_" + list_column + "_" + source + "_map_op/" + bc + "/"
  val bad_record_path = temp_op_path + "/bad_record/"  + source + "/" + bc + "/"
  val lsb_temp_path = temp_op_path + "/lsb_parquet_temp/" + bc + "/"

// COMMAND ----------

// DBTITLE 1,Reading json_demog, lr_xref_xxx_transactionid & lsb_delta_df
val json_demog: DataFrame = getParquetData(hdfs_path + "/" + source + "/" + bc + "/")

val lr_xref_gmrnid_df:DataFrame = spark.read.format("delta").load(store_path)
val lsb_delta_df = spark.read.format("delta").load(deltalake_output)

// COMMAND ----------


  getReferenceIdHosp(json_demog, list_column, source_val, temp_op_path_formatted, lr_xref_gmrnid_df)
  val df4: DataFrame = getFilteredParquetData(temp_op_path_formatted, column_to_get)
  prepareDeltalakeHosp(df4, column_to_get, param_val, source, id_column_name, hospitalfk_field_name, num_partition.toInt, deltalake_output, temp_op_path1,bad_record_path)



// COMMAND ----------

UpsertIntoLSBTable(num_partition.toInt, deltalake_output, temp_op_path1, source, temp_op_path3, temp_op_path4, lsb_delta_df, leadlookupoppath)

// COMMAND ----------

// Number of rows inserted into the target table: 579286
// Number of rows updated in the target table: 1931749


// COMMAND ----------

  // val df6: DataFrame = getParquetData(temp_op_path1)
  // display(df6)
  // val df7: DataFrame = df6.withColumn("new_col",regexp_replace($"new_col","\"",""))//.withColumn("new_col",regexp_replace($"new_col","\"[","[")).withColumn("new_col",regexp_replace($"new_col","\"]","]"))
  // display(df7)
  // val df2 = df7.repartition(num_partition, col("_id"))
  //           .withColumn("dob", $"new_col".getItem(0))
  //           .withColumn("firstname", $"new_col".getItem(4))
  //           .withColumn("gender", $"new_col".getItem(8))
  //           .withColumn("hospitalfk", $"new_col".getItem(10))
  //           .withColumn("lastname", $"new_col".getItem(5))
  //           .withColumn("leadsource", $"new_col".getItem(13))
  //           .withColumn("middlename", $"new_col".getItem(7))
  //           .withColumn("ssn", $"new_col".getItem(11))
  //           .withColumn("state", $"new_col".getItem(14))
  //           .withColumn("updatedate", $"new_col".getItem(9))
  //           .withColumn("xrefsource", $"new_col".getItem(12))
  // `lsb`.`leadid`, `lsb`.`_id`, `lsb`.`demo_id`, `lsb`.`new_col`, `lsb`.`lookupvalue`

// COMMAND ----------

