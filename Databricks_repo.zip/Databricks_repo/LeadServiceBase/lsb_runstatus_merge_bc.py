# Databricks notebook source
from pyspark.sql.functions import *
import datetime
from pyspark.sql.types import *
from  pyspark.sql.functions import input_file_name
from pyspark.sql.window import Window
from pyspark import StorageLevel
from delta.tables import * 

# COMMAND ----------


# dbutils.widgets.text('lsb_source','fc')
# dbutils.widgets.text('lsb_notificationtype','fc_xref_lsb')
# dbutils.widgets.text('lsb_toserve','abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/data/leadrepo/publish/toserve/')
# dbutils.widgets.text('lsb_bc_merge_threshold','5')

# COMMAND ----------

dbutils.widgets.text('lsb_source','')
lsb_source = dbutils.widgets.get("lsb_source")

dbutils.widgets.text('lsb_notificationtype','')
lsb_notificationtype = dbutils.widgets.get("lsb_notificationtype")

dbutils.widgets.text('lsb_toserve','')
lsb_toserve = dbutils.widgets.get("lsb_toserve")

dbutils.widgets.text('lsb_bc_merge_threshold','')
lsb_bc_merge_threshold = dbutils.widgets.get("lsb_bc_merge_threshold")

dbutils.widgets.text('storageaccount','')
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text('cosmosEndpoint','')
cosmosEndpoint = dbutils.widgets.get("cosmosEndpoint")

dbutils.widgets.text('cosmosDatabaseName','')
cosmosDatabaseName = dbutils.widgets.get("cosmosDatabaseName")

dbutils.widgets.text('cosmosContainerName','')
cosmosContainerName = dbutils.widgets.get("cosmosContainerName")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))
cosmosMasterKey = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-cosmos-insleads-kvsecret")

# COMMAND ----------

def readFromCosmos(Endpoint,MasterKey,DatabaseName,ContainerName):
    readConf = {
    "spark.cosmos.accountEndpoint" : Endpoint,
    "spark.cosmos.accountKey" : MasterKey,
    "spark.cosmos.database" : DatabaseName,
    "spark.cosmos.container" : ContainerName
}
    df_read = spark.read.format("cosmos.oltp").options(**readConf).option("spark.cosmos.read.inferSchema.enabled", "true").load()
    return df_read

# COMMAND ----------

def writeToCosmos(dfWrite,Endpoint,MasterKey,DatabaseName,ContainerName):
    writeConf = {
    "spark.cosmos.accountEndpoint" : Endpoint,
    "spark.cosmos.accountKey" : MasterKey,
    "spark.cosmos.database" : DatabaseName,
    "spark.cosmos.container" : ContainerName,
    "spark.cosmos.write.strategy" : "ItemOverwrite"
}
    dfWrite.write.format('cosmos.oltp').options(**writeConf).mode('append').save()

# COMMAND ----------

lsb_bc_merge_threshold = int(lsb_bc_merge_threshold)
lsb_notificationtype = str(lsb_notificationtype)
lsb_source = str(lsb_source)

if lsb_notificationtype == 'ie_xref_lsb':
    lsb_bc_merge_threshold = int(25)
    lsb_toserve = lsb_toserve + "/ich_import/" + "/ie_postbdf/" + "/"
    filterExprNotification = "notificationtype = '" + lsb_notificationtype + "'"
    #filterExprSql = """ SELECT * FROM runstatus WHERE CAST(processed AS INT) = 0 AND """ + filterExprNotification + """ ORDER BY createdon ASC"""
    filterExprSql = """ SELECT * FROM runstatus WHERE  lower(trim(processed))='unprocessed' AND """ + filterExprNotification + """ ORDER BY createdon ASC"""
    field = [StructField("transactionkey", StringType(), True),
             StructField("sourcekey", StringType(), True),
             StructField("dependentflag", StringType(), True),
             StructField("identity", StringType(), True),
             StructField("xrefsource", StringType(), True)
             ]
    schema = StructType(field)
elif lsb_notificationtype == 'es_xref_lsb':
    lsb_bc_merge_threshold = int(25)
    lsb_toserve = lsb_toserve + "/ich_import/" + "/es_postbdf/" + "/"
    filterExprNotification = "notificationtype = '" + lsb_notificationtype + "'"
    #filterExprSql = """ SELECT * FROM runstatus WHERE CAST(processed AS INT) = 0 AND """ + filterExprNotification + """ ORDER BY createdon ASC"""
    filterExprSql = """ SELECT * FROM runstatus WHERE  lower(trim(processed))='unprocessed' AND """ + filterExprNotification + """ ORDER BY createdon ASC"""
    field = [StructField("transactionkey", StringType(), True),
             StructField("sourcekey", StringType(), True),
             StructField("dependentflag", StringType(), True),
             StructField("identity", StringType(), True),
             StructField("xrefsource", StringType(), True)
             ]
    schema = StructType(field)
elif lsb_notificationtype == 'fc_xref_lsb':
    lsb_toserve = lsb_toserve + "/fc_import/"
    lsb_bc_merge_threshold = int(50)
    filterExprNotification = "notificationtype = '" + lsb_notificationtype + "'"
    #filterExprSql = """ SELECT * FROM runstatus WHERE CAST(processed AS INT) = 0 AND """ + filterExprNotification + """ ORDER BY createdon ASC"""
    filterExprSql = """ SELECT * FROM runstatus WHERE  lower(trim(processed))='unprocessed' AND """ + filterExprNotification + """ ORDER BY createdon ASC"""
    field = [StructField("transactionkey", StringType(), True),
             StructField("hospitalfk", StringType(), True),
             StructField("patientacctifk", StringType(), True),
             StructField("payerid", StringType(), True),
             StructField("coverageid", StringType(), True),
             StructField("bc", StringType(), True)
             ]
    schema = StructType(field)
elif lsb_notificationtype == 'hfc_xref_lsb':
    lsb_toserve = lsb_toserve + "/hfc_import/"
    lsb_bc_merge_threshold = int(2)
    filterExprNotification = "notificationtype = '" + lsb_notificationtype + "'"
    #filterExprSql = """ SELECT * FROM runstatus WHERE CAST(processed AS INT) = 0 AND """ + filterExprNotification + """ ORDER BY createdon ASC"""
    filterExprSql = """ SELECT * FROM runstatus WHERE  lower(trim(processed))='unprocessed' AND """ + filterExprNotification + """ ORDER BY createdon ASC"""
    field = [StructField("transactionkey", StringType(), True),
             StructField("hospitalfk", StringType(), True),
             StructField("patientacctifk", StringType(), True),
             StructField("payerid", StringType(), True),
             StructField("coverageid", StringType(), True),
             StructField("bc", StringType(), True)
             ]
    schema = StructType(field)
elif lsb_notificationtype == 'mh_xref_lsb':
    lsb_toserve = lsb_toserve + "/mh_import/"
    lsb_bc_merge_threshold = int(2)
    filterExprNotification = "notificationtype = '" + lsb_notificationtype + "'"
    #filterExprSql = """ SELECT * FROM runstatus WHERE CAST(processed AS INT) = 0 AND """ + filterExprNotification + """ ORDER BY createdon ASC"""
    filterExprSql = """ SELECT * FROM runstatus WHERE  lower(trim(processed))='unprocessed' AND """ + filterExprNotification + """ ORDER BY createdon ASC"""
    field = [StructField("transactionkey", StringType(), True),
             StructField("hospitalfk", StringType(), True),
             StructField("patientacctifk", StringType(), True),
             StructField("payerid", StringType(), True),
             StructField("coverageid", StringType(), True),
             StructField("bc", StringType(), True)
             ]
    schema = StructType(field)
elif ((lsb_notificationtype == 'es_lsb_famc')|(lsb_notificationtype == 'ie_lsb_famc')|(lsb_notificationtype == 'fc_lsb_famc')):
    lsb_toserve = lsb_toserve
    lsb_bc_merge_threshold = int(10)
    filterExprNotification = "notificationtype = '" + lsb_notificationtype + "'"
    #filterExprSql = """ SELECT * FROM runstatus WHERE CAST(processed AS INT) = 0 AND """ + filterExprNotification + """ ORDER BY createdon ASC"""
    filterExprSql = """ SELECT * FROM runstatus WHERE  lower(trim(processed))='unprocessed' AND """ + filterExprNotification + """ ORDER BY createdon ASC"""
    field = [StructField("transactionkey", StringType(), True),
             StructField("sourcekey", StringType(), True),
             StructField("permid", StringType(), True),
             StructField("lr_createdate", StringType(), True),
             StructField("lr_creatingmodule", StringType(), True),
             StructField("_id", StringType(), True),
             StructField("xrefsource", StringType(), True),
             StructField("audittrail", StringType(), True),
             StructField("hospitalfk", StringType(), True)
             ]
    #field = [StructField("transactionkey", StringType(), True),
    #         StructField("hospitalfk", StringType(), True),
    #         StructField("patientacctifk", StringType(), True),
    #         StructField("payerid", StringType(), True),
    #         StructField("coverageid", StringType(), True),
    #         StructField("bc", StringType(), True)
    #         ]
    schema = StructType(field)
elif lsb_notificationtype == 'globalmrnmerge_xref_lsb':
    lsb_toserve = lsb_toserve + "/gmrn/"
    lsb_bc_merge_threshold = int(25)
    filterExprNotification = "notificationtype = '" + lsb_notificationtype + "'"
    #filterExprSql = """ SELECT * FROM runstatus WHERE CAST(processed AS INT) = 0 AND """ + filterExprNotification + """ ORDER BY createdon ASC"""
    filterExprSql = """ SELECT * FROM runstatus WHERE  lower(trim(processed))='unprocessed' AND """ + filterExprNotification + """ ORDER BY createdon ASC"""
    field = [StructField("fromglobalmrn", StringType(), True),
             StructField("toglobalmrn", StringType(), True),
             StructField("transactionkey", StringType(), True),
             StructField("xrefsource", StringType(), True),
             StructField("source", StringType(), True)
             ]
    schema = StructType(field)
else:
    pass

print("lsb_toserve : " + lsb_toserve)
print("filterExprSql : " + filterExprSql)
print("lsb_bc_merge_threshold : " + str(lsb_bc_merge_threshold))
print("schema : " + str(schema))

# COMMAND ----------

# df_read_run_status = spark.read.format("delta").table("lsb_runstatus")
print("cosmosEndpoint" + str(cosmosEndpoint))
print("cosmosMasterKey" + str(cosmosMasterKey))
print("cosmosDatabaseName" + str(cosmosDatabaseName))
print("cosmosContainerName" + str(cosmosContainerName))


import uuid
spark.conf.set("spark.sql.catalog.cosmosCatalog", "com.azure.cosmos.spark.CosmosCatalog")
spark.conf.set("spark.sql.catalog.cosmosCatalog.spark.cosmos.accountEndpoint", cosmosEndpoint)
spark.conf.set("spark.sql.catalog.cosmosCatalog.spark.cosmos.accountKey", cosmosMasterKey)
spark.conf.set("spark.sql.catalog.cosmosCatalog.spark.cosmos.views.repositoryPath", "/viewDefinitions" + str(uuid.uuid4()))


#df_read_run_status = spark.read.format("cosmos.oltp").options(**readConf).option("spark.cosmos.read.inferSchema.enabled", "true").load()

df_read_run_status = readFromCosmos(cosmosEndpoint,cosmosMasterKey,cosmosDatabaseName,cosmosContainerName)
df_read_run_status.show(2,False)
df_read_run_status.createOrReplaceTempView("runstatus")
data = spark.sql(filterExprSql).limit(lsb_bc_merge_threshold)

# ll = [('20231116T07','2023-11-16 21:28:57.842'),('20231117T07','2023-11-17 21:28:57.842')]
# data = spark.createDataFrame(ll,['bc','createdon'])

data.persist()

if data.count() < 2:
    print("do nothing")
else:
    print("BC TO BE MERGED")
    # data.show(lsb_bc_merge_threshold, False)
    min_createdon = data.selectExpr("createdon").sort("createdon").limit(1)
    min_createdon = [str(row.createdon) for row in min_createdon.collect()][0]
    # min_bc = data.selectExpr("bc").sort("bc").limit(1)
    min_bc = data.selectExpr("bc", "createdon").sort("createdon").selectExpr("bc").limit(1)
    min_bc = [str(row.bc) for row in min_bc.collect()][0]
    min_bc_path = str(lsb_toserve + min_bc)
    merged_bc = str(min_bc + '_MERGED')
    # merged_bc_path = lsb_toserve + merged_bc
    merged_bc_path = lsb_toserve + merged_bc
    print("MIN BC : " + min_bc)
    print("MIN BC PATH : " + min_bc_path)
    print("MERGED BC : " + merged_bc_path)
    print("MERGED BC PATH : " + merged_bc)
    bc_in_play = data.selectExpr("bc")
    bc_array = [str(row.bc) for row in bc_in_play.collect()]
    # making an empty data-set
    served = spark.createDataFrame(sc.emptyRDD(), schema)
    served.printSchema()

    for i in bc_array:
        served_path = lsb_toserve + i + "/"
        print(served_path)
        df_bc = spark.read.option("mergeSchema", "true").parquet(served_path)
        for column in df_bc.columns:
            new_column = column.lower()
            df_bc = df_bc.withColumnRenamed(column, new_column)
        for column in df_bc.columns:
            df_bc = df_bc.withColumn(column, trim(col(column)))
        served = served.unionAll(df_bc)
        print("READ COMPLETE " + str(served_path))
        df_bc.unpersist()

    served.printSchema()

    if lsb_notificationtype == 'globalmrnmerge_xref_lsb':
        served = served.dropDuplicates().repartition(1)
        served.write.partitionBy("source").mode("overwrite").parquet(merged_bc_path)
        served.unpersist()
    elif lsb_notificationtype == 'fc_xref_lsb':
        served = served.drop("bc")
        served = served.dropDuplicates()
        served = served.withColumn("bc", lit(str(min_bc)))
        served = served.repartition(10)
        served.write.mode("overwrite").parquet(merged_bc_path)
        served.unpersist()
    else:
        served.dropDuplicates().repartition(10).write.mode("overwrite").parquet(merged_bc_path)
        served.unpersist()

    # delta_tbl = DeltaTable.forPath(spark,'dbfs:/user/hive/warehouse/lsb_runstatus')
    data_updated = data.withColumn("processedon", lit('merged_to_bc_' + min_bc)).withColumn("processed", when(col('bc') == min_bc,lit('unprocessed')).otherwise(lit('processed')))
    # delta_tbl.alias("raw").merge(data_updated.alias("delta"), expression).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()
    dbutils.fs.rm(min_bc_path,True)
    print("DELETED FOLDER : " + min_bc_path)
    dbutils.fs.mv(merged_bc_path,min_bc_path,recurse=True)
    print("RENAMED FOLDER : " + merged_bc_path + " TO " + min_bc_path)
    writeToCosmos(data_updated,cosmosEndpoint,cosmosMasterKey,cosmosDatabaseName,cosmosContainerName)
    print("UPDATED COSMOSDB : " + cosmosDatabaseName + " WITH processed FLAGS")
    data.unpersist()

# COMMAND ----------

# StructType([StructField('transactionkey', StringType(), True), StructField('sourcekey', StringType(), True), StructField('permid', StringType(), True), StructField('lr_createdate', StringType(), True), StructField('lr_creatingmodule', StringType(), True), StructField('_id', StringType(), True), StructField('xrefsource', StringType(), True), StructField('audittrail', StringType(), True)])