# Databricks notebook source
# DBTITLE 1,pyspark utilities
import os
import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
from pyspark import SparkContext
from pyspark.conf import SparkConf
import subprocess
from pyspark.sql.functions import input_file_name
from pyspark.sql.window import Window
from pyspark import StorageLevel
import os
import pyspark

# COMMAND ----------

# DBTITLE 1,Input Parameters
dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc = getArgument("bc")

dbutils.widgets.text("input_ca_permid_trans", "")
dbutils.widgets.getArgument("input_ca_permid_trans")
input_ca_permid_trans= getArgument("input_ca_permid_trans")

dbutils.widgets.text("input_lr_transaction","")
dbutils.widgets.getArgument("input_lr_transaction")
input_lr_transaction= getArgument("input_lr_transaction")

dbutils.widgets.text("input_permid_x_patientaccts","")
dbutils.widgets.getArgument("input_permid_x_patientaccts")
input_permid_x_patientaccts= getArgument("input_permid_x_patientaccts")

dbutils.widgets.text("output_stage","")
dbutils.widgets.getArgument("output_stage")
output_stage= getArgument("output_stage")

dbutils.widgets.text("run_type","")
dbutils.widgets.getArgument("run_type")
run_type= getArgument("run_type")

dbutils.widgets.text("feed_source","")
dbutils.widgets.getArgument("feed_source")
feed_source= getArgument("feed_source")

dbutils.widgets.text("dataingestion_path","")
dbutils.widgets.getArgument("dataingestion_path")
dataingestion_path= getArgument("dataingestion_path")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

# COMMAND ----------

# DBTITLE 1,ADLS access
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# DBTITLE 1,base path
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

# DBTITLE 1,complete paths with bc
input_ca_permid_trans=baseurl+input_ca_permid_trans+feed_source[:3]+'xref_famc/'+bc
input_lr_transaction=baseurl+input_lr_transaction
input_permid_x_patientaccts=baseurl+input_permid_x_patientaccts
output_stage_01_ca_x_transaction=baseurl+output_stage+feed_source+'/'+bc+'/output_stage_01_ca_x_transaction'
output_stage_02_ca_x_transaction_deduped=baseurl+output_stage+feed_source+'/'+bc+'/output_stage_02_ca_x_transaction_deduped'
output_stage_03_ca_x_perm_x_patientaccts=baseurl+output_stage+feed_source+'/'+bc+'/output_stage_03_ca_x_perm_x_patientaccts'
input_edipayers_tupayeridmapping = baseurl+dataingestion_path + 'edipayers_tupayeridmapping/current/20991231/'
input_edipartners = baseurl+dataingestion_path + 'edipartners/current/20991231/'

print("bc:",bc)
print("input_ca_permid_trans:",input_ca_permid_trans)
print("input_lr_transaction:",input_lr_transaction)
print("input_permid_x_patientaccts:",input_permid_x_patientaccts)
print("output_stage_01_ca_x_transaction:",output_stage_01_ca_x_transaction)
print("output_stage_02_ca_x_transaction_deduped:",output_stage_02_ca_x_transaction_deduped)
print("output_stage_03_ca_x_perm_x_patientaccts:",output_stage_03_ca_x_perm_x_patientaccts)
print("input_edipayers_tupayeridmapping:",input_edipayers_tupayeridmapping)
print("input_edipartners:",input_edipartners)

# COMMAND ----------

# DBTITLE 1,get permid and transaction key from famc_lr_xref_permid_transaction
data_ca = spark.read.parquet(input_ca_permid_trans).selectExpr("permid", "transactionkey", "sourcekey","hospitalfk").dropDuplicates()
data_ca.createOrReplaceTempView("data_ca")
data_ca = spark.sql("""
SELECT 
permid,
transactionkey,
(CAST(sourcekey AS BIGINT)) AS sourcekey,
hospitalfk
FROM data_ca
""")
data_ca.createOrReplaceTempView("data_ca")

# COMMAND ----------

# DBTITLE 1,get coverage info from lr_transaction
data_transaction = spark.read.parquet(input_lr_transaction)
data_transaction.createOrReplaceTempView("data_transaction")
data_transaction = spark.sql("""
SELECT data_transaction.transactionkey, 
       data_transaction.verifiedsource AS leadsource,
       data_transaction.coverageid,
       data_transaction.lr_creatingmodule,
       data_transaction.sourcekey,
       data_transaction.clientid as hospitalfk,
       data_transaction.payerid
FROM data_transaction
""")
data_transaction.createOrReplaceTempView("data_transaction")


# COMMAND ----------

tupayer_data = spark.read.parquet(input_edipayers_tupayeridmapping).select("tupayerid", "edipayerfk")
edipartner_data = spark.read.parquet(input_edipartners).filter("isenabledflag=='1'").filter("familyclusteringenabledflag=='1'").filter("edipartnerpk > 0").select("edipayerfk", "edipartnerpk").dropDuplicates()
tupayer_data = tupayer_data.join(edipartner_data, 'edipayerfk').selectExpr("CAST(tupayerid AS int) AS tupayerid", "edipartnerpk AS edipartnerfk")
cond1 = when(col("tupayerid") == 10102, lit(30)).otherwise(col("edipartnerfk"))
cond2 = when(col("tupayerid") == 10001, lit(82)).otherwise(col("edipartnerfk"))
cond3 = when(col("tupayerid") == 10055, lit(8)).otherwise(col("edipartnerfk"))
cond4 = when(col("tupayerid") == 10285, lit(71)).otherwise(col("edipartnerfk"))
cond5 = when(col("tupayerid") == 11174, lit(479)).otherwise(col("edipartnerfk"))
cond6 = when(col("tupayerid") == 11196, lit(547)).otherwise(col("edipartnerfk"))
tupayer_data = tupayer_data.withColumn("edipartnerfk", cond1)
tupayer_data = tupayer_data.withColumn("edipartnerfk", cond2)
tupayer_data = tupayer_data.withColumn("edipartnerfk", cond3)
tupayer_data = tupayer_data.withColumn("edipartnerfk", cond4)
tupayer_data = tupayer_data.withColumn("edipartnerfk", cond5)
tupayer_data = tupayer_data.withColumn("edipartnerfk", cond6).dropDuplicates()
tupayer_data = tupayer_data.selectExpr("edipartnerfk").dropDuplicates()

tupayer_data.createOrReplaceTempView("tupayer_data")

data_transaction = spark.sql("""select * from data_transaction where payerid in (select distinct edipartnerfk from tupayer_data)""")
data_transaction.createOrReplaceTempView("data_transaction")

# COMMAND ----------

# DBTITLE 1,join lr_xref_permid_transaction and lr_transaction
#clientid field in lr_transaction has hospitalfk in fc data and client in ich data
print(f"notification type : {feed_source}")
data_ca = spark.sql("""
    SELECT data_ca.permid,
           data_transaction.transactionkey,
           data_transaction.coverageid,
           CASE 
               WHEN data_ca.sourcekey='1' THEN 'fc' 
               WHEN data_ca.sourcekey='2' THEN 'ich' 
               ELSE 'XX' 
           END AS leadsource,
           data_transaction.sourcekey,
           data_transaction.hospitalfk,
           data_transaction.payerid
    FROM data_ca
    JOIN data_transaction
         ON CAST (data_ca.sourcekey AS BIGINT) = CAST (data_transaction.sourcekey AS BIGINT)
        AND CAST (data_ca.transactionkey AS BIGINT) = CAST (data_transaction.transactionkey AS BIGINT)
        AND CAST (data_ca.hospitalfk AS INT) = CAST (data_transaction.hospitalfk AS INT)
""")

# COMMAND ----------

# DBTITLE 1,output_stage_01_ca_x_transaction
data_ca = data_ca.dropDuplicates()
output_partitions = 10
if run_type == 'base':
    output_partitions = 1000
data_ca.repartition(output_partitions).write.mode('overwrite').parquet(output_stage_01_ca_x_transaction)
data_ca.unpersist()
data_transaction.unpersist()
print("COMPLETE : STAGE : 01 : output_stage_01_ca_x_transaction : " + output_stage_01_ca_x_transaction)

# COMMAND ----------

# DBTITLE 1,output_stage_02_ca_x_transaction_deduped
data_ca = spark.read.parquet(output_stage_01_ca_x_transaction)

for column in data_ca.columns:
    data_ca = data_ca.withColumn(column, trim(col(column)))
    data_ca = data_ca.withColumn(column, when(col(column).isNull(), 'XX').otherwise(col(column)))
    data_ca = data_ca.withColumn(column, when(col(column) == '', 'XX').otherwise(col(column)))
    data_ca = data_ca.withColumn(column, when(upper(col(column)) == 'NULL', 'XX').otherwise(col(column)))

data_ca.createOrReplaceTempView("data_ca")
data_ca = spark.sql(""" SELECT * FROM data_ca WHERE coverageid <> 'XX' """)
data_ca.createOrReplaceTempView("data_ca")

data_ca = spark.sql("""
SELECT permid,
       coverageid,
       leadsource,
       sourcekey,
       hospitalfk,
       payerid,
       transactionkey,
       ROW_NUMBER() OVER (PARTITION BY permid,coverageid,leadsource,sourcekey,payerid ORDER BY CAST(transactionkey AS BIGINT) DESC) AS RNK
FROM data_ca
""").filter("RNK=='1'").drop("RNK")

data_ca.repartition(output_partitions).write.mode('overwrite').parquet(output_stage_02_ca_x_transaction_deduped)
data_ca.unpersist()

print("COMPLETE : STAGE : 02 : output_stage_02_ca_x_transaction_deduped : " + output_stage_02_ca_x_transaction_deduped)

# COMMAND ----------

# DBTITLE 1,output_stage_03_ca_x_perm_x_patientaccts
data_ca = spark.read.parquet(output_stage_02_ca_x_transaction_deduped)
data_ca.createOrReplaceTempView("data_ca")

data_permid_patientaccts = spark.read.parquet(input_permid_x_patientaccts).filter(col("matchind").isin('IM','M1')).selectExpr("permid", "patientacctifk","hospitalfk").dropDuplicates()
data_permid_patientaccts.createOrReplaceTempView("data_permid_patientaccts")

data_ca = spark.sql("""SELECT data_ca.*,data_permid_patientaccts.patientacctifk,data_permid_patientaccts.hospitalfk AS hospitalfk_permidpatientacct FROM data_ca LEFT JOIN data_permid_patientaccts ON TRIM(data_ca.permid) = TRIM(data_permid_patientaccts.permid) """)
data_ca.dropDuplicates().repartition(output_partitions).write.mode('overwrite').parquet(output_stage_03_ca_x_perm_x_patientaccts)
data_ca.unpersist()
data_permid_patientaccts.unpersist()
print("COMPLETE : STAGE : 03 : output_stage_03_ca_x_perm_x_patientaccts : " + output_stage_03_ca_x_perm_x_patientaccts)
