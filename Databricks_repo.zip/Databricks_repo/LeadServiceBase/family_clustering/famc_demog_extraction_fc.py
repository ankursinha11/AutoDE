# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("output_stage","")
dbutils.widgets.getArgument("output_stage")
output_stage= getArgument("output_stage")

dbutils.widgets.text("input_foundcoverage","")
dbutils.widgets.getArgument("input_foundcoverage")
input_foundcoverage= getArgument("input_foundcoverage")

dbutils.widgets.text("run_type","")
dbutils.widgets.getArgument("run_type")
run_type= getArgument("run_type")

dbutils.widgets.text("feed_source","")
dbutils.widgets.getArgument("feed_source")
feed_source= getArgument("feed_source")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))
spark.conf.set('spark.sql.shuffle.partitions','auto')

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

from pyspark.sql.functions import *
# import datetime
from pyspark.sql.types import *
# import subprocess
# from  pyspark.sql.functions import input_file_name

# COMMAND ----------

output_stage_03_ca_x_perm_x_patientaccts = baseurl+output_stage +feed_source + '/'+ bc +'/'+ 'output_stage_03_ca_x_perm_x_patientaccts'
input_foundcoverage = baseurl + input_foundcoverage
output_stage_04_ca_x_fc_demographics = baseurl + output_stage + feed_source + '/'+ bc +'/'+ 'output_stage_04_ca_x_fc_demographics'
output_stage_05_ca_x_fc_demographics_deduped_matched = baseurl+output_stage + feed_source + '/'+ bc +'/'+ 'output_stage_05_ca_x_fc_demographics_deduped_matched'
output_stage_05_ca_x_fc_demographics_deduped_unmatched = baseurl+output_stage + feed_source + '/'+ bc +'/'+ 'output_stage_05_ca_x_fc_demographics_deduped_unmatched'
print("bc:",bc)
print("output_stage_03_ca_x_perm_x_patientaccts:",output_stage_03_ca_x_perm_x_patientaccts)
print("input_foundcoverage:",input_foundcoverage)
print("output_stage_04_ca_x_fc_demographics:",output_stage_04_ca_x_fc_demographics)
print("output_stage_05_ca_x_fc_demographics_deduped_matched:",output_stage_05_ca_x_fc_demographics_deduped_matched)
print("output_stage_05_ca_x_fc_demographics_deduped_unmatched:",output_stage_05_ca_x_fc_demographics_deduped_unmatched)

# COMMAND ----------

output_partitions = 10
if run_type == 'base':
    output_partitions = 1000

# COMMAND ----------

data_ca = spark.read.parquet(output_stage_03_ca_x_perm_x_patientaccts)
data_ca.createOrReplaceTempView("data_ca")

data_foundcoverage = spark.read.format("delta").load(input_foundcoverage)
# data_foundcoverage = data_foundcoverage.filter("hitstatus in ('0','1','2')") #Updated on 11/25/2024 for picking hitstatus 1,2 records
data_foundcoverage = data_foundcoverage.filter("hitstatus in ('1','2')")
data_foundcoverage.createOrReplaceTempView("data_foundcoverage")

data_foundcoverage = spark.sql("""
SELECT patientacctifk,
       hospitalfk,
       firstname,
       middlename,
       lastname,
       gender,
       dob,
       ssn,
       addr,
       city,
       state,
       zip,
       CAST(regexp_replace (regexp_replace (regexp_replace (regexp_replace ((SPLIT (cast(createdate as timestamp),"\\\.")[0]),"T",""),":",""),"-","")," ","") AS BIGINT)             AS createdate_as_bigint,
       CAST(regexp_replace (regexp_replace (regexp_replace (regexp_replace ((SPLIT (cast(updatedate as timestamp),"\\\.")[0]),"T",""),":",""),"-","")," ","") AS BIGINT)             AS updatedate_as_bigint
FROM data_foundcoverage
""")
data_foundcoverage.createOrReplaceTempView("data_foundcoverage")

# COMMAND ----------


#for column in data_foundcoverage.columns:
#    data_foundcoverage = data_foundcoverage.withColumn(column, trim(col(column)))
#    data_foundcoverage = data_foundcoverage.withColumn(column, when(col(column).isNull(), 'XX').otherwise(col(column)))
#    data_foundcoverage = data_foundcoverage.withColumn(column, when(col(column) == '', 'XX').otherwise(col(column)))
#    data_foundcoverage = data_foundcoverage.withColumn(column, when(col(column) == 'null', 'XX').otherwise(col(column)))
#    data_foundcoverage = data_foundcoverage.withColumn(column, upper(col(column)))

data_ca = spark.sql("""
SELECT data_ca.*,
       --data_foundcoverage.hospitalfk,
       data_foundcoverage.firstname,
       data_foundcoverage.middlename,
       data_foundcoverage.lastname,
       data_foundcoverage.gender,
       data_foundcoverage.dob,
       data_foundcoverage.ssn,
       data_foundcoverage.addr,
       data_foundcoverage.city,
       data_foundcoverage.state,
       data_foundcoverage.zip,
       data_foundcoverage.createdate_as_bigint,
       data_foundcoverage.updatedate_as_bigint
FROM data_ca
  LEFT JOIN data_foundcoverage ON CAST(data_ca.patientacctifk AS BIGINT) = CAST(data_foundcoverage.patientacctifk AS BIGINT)
  AND CAST(data_ca.hospitalfk_permidpatientacct AS INT) = CAST(data_foundcoverage.hospitalfk AS INT)
""")

# COMMAND ----------

data_ca.dropDuplicates().repartition(output_partitions).write.mode('overwrite').parquet(output_stage_04_ca_x_fc_demographics)
data_ca.unpersist()
data_foundcoverage.unpersist()
print("COMPLETE : STAGE : 04 : output_stage_04_ca_x_fc_demographics : " + output_stage_04_ca_x_fc_demographics)

# COMMAND ----------

data_ca = spark.read.parquet(output_stage_04_ca_x_fc_demographics)
for column in data_ca.columns:
    data_ca = data_ca.withColumn(column, trim(col(column)))
    data_ca = data_ca.withColumn(column, when(col(column).isNull(), 'XX').otherwise(col(column)))
    data_ca = data_ca.withColumn(column, when(col(column) == '', 'XX').otherwise(col(column)))
    data_ca = data_ca.withColumn(column, when(upper(col(column)) == 'NULL', 'XX').otherwise(col(column)))
    data_ca = data_ca.withColumn(column, upper(col(column)))
#data_ca = data_ca.drop("leadsource").withColumn("leadsource",lit('fm')).drop("patientacctifk").withColumn("patientacctifk",lit('00000000000')).drop("transactionkey").withColumn("transactionkey",lit('00000000000')).dropDuplicates()
data_ca = data_ca.withColumn("transactionkey",lit('00000000000')).dropDuplicates()
data_ca.createOrReplaceTempView("data_ca")

# COMMAND ----------

data_ca_nx = spark.sql("""
SELECT data_ca.permid,
       data_ca.transactionkey,
       data_ca.coverageid,
       data_ca.leadsource,
       data_ca.sourcekey,
       data_ca.hospitalfk,
       data_ca.payerid,
       data_ca.patientacctifk,
       data_ca.hospitalfk_permidpatientacct,
       data_ca.firstname,
       data_ca.middlename,
       data_ca.lastname,
       data_ca.gender,
       data_ca.dob,
       data_ca.ssn,
       data_ca.addr,
       data_ca.city,
       data_ca.state,
       data_ca.zip,
       data_ca.createdate_as_bigint,
       data_ca.updatedate_as_bigint,
       ROW_NUMBER() OVER (PARTITION BY data_ca.permid,data_ca.coverageid,data_ca.hospitalfk,data_ca.leadsource,data_ca.payerid ORDER BY data_ca.updatedate_as_bigint DESC, data_ca.ssn DESC, data_ca.dob DESC ) AS RNK
FROM data_ca
WHERE data_ca.createdate_as_bigint <> 'XX'
--AND   data_ca.updatedate_as_bigint <> 'XX'
""")
data_ca_nx = data_ca_nx.filter("RNK=='1'").drop("RNK") #.dropDuplicates()

# COMMAND ----------

data_ca_xx = spark.sql("""
SELECT data_ca.permid,
       data_ca.transactionkey,
       data_ca.coverageid,
       data_ca.leadsource,
       data_ca.sourcekey,
       data_ca.hospitalfk,
       data_ca.payerid,
       data_ca.patientacctifk,
       data_ca.hospitalfk_permidpatientacct,
       data_ca.firstname,
       data_ca.middlename,
       data_ca.lastname,
       data_ca.gender,
       data_ca.dob,
       data_ca.ssn,
       data_ca.addr,
       data_ca.city,
       data_ca.state,
       data_ca.zip,
       data_ca.createdate_as_bigint,
       data_ca.updatedate_as_bigint
FROM data_ca
WHERE data_ca.createdate_as_bigint = 'XX'
AND   data_ca.updatedate_as_bigint = 'XX'
""").dropDuplicates()

# COMMAND ----------

data_ca=data_ca_nx.union(data_ca_xx)

data_ca.createOrReplaceTempView("data_ca")

data_ca=spark.sql("""
SELECT data_ca.permid,
       data_ca.transactionkey,
       data_ca.coverageid,
       data_ca.leadsource,
       data_ca.sourcekey,
       data_ca.hospitalfk,
       data_ca.payerid,
       data_ca.patientacctifk,
       data_ca.hospitalfk_permidpatientacct,
       data_ca.firstname,
       data_ca.middlename,
       data_ca.lastname,
       data_ca.gender,
       data_ca.dob,
       data_ca.ssn,
       data_ca.addr,
       data_ca.city,
       data_ca.state,
       data_ca.zip,
       data_ca.createdate_as_bigint,
       data_ca.updatedate_as_bigint,
	   CASE WHEN (data_ca.firstname='XX' AND data_ca.updatedate_as_bigint='XX') THEN '0' ELSE '1' END AS demo_quality
FROM data_ca
""")
data_ca.createOrReplaceTempView("data_ca")

# COMMAND ----------

data_ca=spark.sql("""
SELECT data_ca.permid,
       data_ca.transactionkey,
       data_ca.coverageid,
       data_ca.leadsource,
       data_ca.sourcekey,
       data_ca.hospitalfk,
       data_ca.payerid,
       data_ca.patientacctifk,
       data_ca.hospitalfk_permidpatientacct,
       data_ca.firstname,
       data_ca.middlename,
       data_ca.lastname,
       data_ca.gender,
       data_ca.dob,
       data_ca.ssn,
       data_ca.addr,
       data_ca.city,
       data_ca.state,
       data_ca.zip,
       data_ca.createdate_as_bigint,
       data_ca.updatedate_as_bigint,
       data_ca.updatedate_as_bigint as demographicsupdatedate_as_bigint,
       data_ca.updatedate_as_bigint as trgupdatedate_as_bigint,
       cast(demo_quality as int) as demo_quality,
       RANK() OVER (PARTITION BY data_ca.permid,data_ca.coverageid,data_ca.hospitalfk,data_ca.leadsource,data_ca.payerid ORDER BY CAST(demo_quality AS INT) DESC) AS RNK
FROM data_ca
""").filter("RNK=='1'").drop("RNK")

# COMMAND ----------

data_ca_matched =   data_ca.filter("demo_quality=1").drop("demo_quality").dropDuplicates()
data_ca_unmatched = data_ca.filter("demo_quality=0").dropDuplicates()

# COMMAND ----------

data_ca_matched.repartition(output_partitions).write.mode('overwrite').parquet(output_stage_05_ca_x_fc_demographics_deduped_matched)

# COMMAND ----------

data_ca_unmatched.repartition(output_partitions).write.mode('overwrite').parquet(output_stage_05_ca_x_fc_demographics_deduped_unmatched)

# COMMAND ----------

data_ca_matched = spark.read.parquet(output_stage_05_ca_x_fc_demographics_deduped_matched)
data_ca_matched.createOrReplaceTempView("data_ca_matched")
data_ca_unmatched = spark.read.parquet(output_stage_05_ca_x_fc_demographics_deduped_unmatched)
data_ca_unmatched.createOrReplaceTempView("data_ca_unmatched")

# COMMAND ----------

data_ca_matched_unmatched_join = spark.sql('''
select data_ca_unmatched.permid,
data_ca_matched.permid as permid_matched,
data_ca_unmatched.transactionkey,
data_ca_unmatched.coverageid,
data_ca_unmatched.leadsource,
data_ca_unmatched.sourcekey,
data_ca_unmatched.hospitalfk,
data_ca_unmatched.payerid,
data_ca_unmatched.patientacctifk,
data_ca_unmatched.hospitalfk_permidpatientacct,
data_ca_matched.firstname,
data_ca_matched.middlename,
data_ca_matched.lastname,
data_ca_matched.gender,
data_ca_matched.dob,
data_ca_matched.ssn,
data_ca_matched.addr,
data_ca_matched.city,
data_ca_matched.state,
data_ca_matched.zip,
data_ca_matched.createdate_as_bigint,
data_ca_matched.updatedate_as_bigint,
data_ca_matched.demographicsupdatedate_as_bigint,
data_ca_matched.trgupdatedate_as_bigint 
from data_ca_unmatched
left join data_ca_matched
on data_ca_unmatched.permid = data_ca_matched.permid''')
data_ca_matched_unmatched_join = data_ca_matched_unmatched_join.dropDuplicates()
data_ca_matched_unmatched_join.createOrReplaceTempView("data_ca_matched_unmatched_join")

# COMMAND ----------

data_ca_matched1 = spark.sql('''
select permid,
transactionkey,
coverageid,
leadsource,
sourcekey,
hospitalfk,
payerid,
patientacctifk,
hospitalfk_permidpatientacct,
firstname,
middlename,
lastname,
gender,
dob,
ssn,
addr,
city,
state,
zip,
createdate_as_bigint,
updatedate_as_bigint,
demographicsupdatedate_as_bigint,
trgupdatedate_as_bigint from data_ca_matched_unmatched_join
where permid_matched is not null
''')

# COMMAND ----------

#data_ca_matched_final = data_ca_matched.union(data_ca_matched1).dropDuplicates()
data_ca_matched1.repartition(output_partitions).write.mode('append').parquet(output_stage_05_ca_x_fc_demographics_deduped_matched)

# COMMAND ----------

data_ca_unmatched_final = spark.sql('''
select permid,
transactionkey,
coverageid,
leadsource,
sourcekey,
hospitalfk,
payerid,
patientacctifk,
hospitalfk_permidpatientacct,
firstname,
middlename,
lastname,
gender,
dob,
ssn,
addr,
city,
state,
zip,
createdate_as_bigint,
updatedate_as_bigint,
demographicsupdatedate_as_bigint,
trgupdatedate_as_bigint from data_ca_matched_unmatched_join
where permid_matched is null
''')

# COMMAND ----------

data_ca_unmatched_final = data_ca_unmatched_final.select("permid","coverageid","sourcekey","payerid","transactionkey","leadsource","patientacctifk","hospitalfk_permidpatientacct","hospitalfk").dropDuplicates()
data_ca_unmatched_final.repartition(output_partitions).write.mode('overwrite').parquet(output_stage_05_ca_x_fc_demographics_deduped_unmatched)
data_ca.unpersist()
print("COMPLETE : STAGE : 05 : output_stage_05_ca_x_fc_demographics_deduped : ")
