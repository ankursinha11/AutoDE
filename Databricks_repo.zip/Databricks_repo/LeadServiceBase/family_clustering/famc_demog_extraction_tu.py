# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("feed_source","")
dbutils.widgets.getArgument("feed_source")
feed_source= getArgument("feed_source")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("dataingestion_path","")
dbutils.widgets.getArgument("dataingestion_path")
dataingestion_path= getArgument("dataingestion_path")

dbutils.widgets.text("cdd_publish_path","")
dbutils.widgets.getArgument("cdd_publish_path")
cdd_publish_path= getArgument("cdd_publish_path")

dbutils.widgets.text("output_stage_path","")
dbutils.widgets.getArgument("output_stage_path")
output_stage_path= getArgument("output_stage_path")

dbutils.widgets.text("run_type","")
dbutils.widgets.getArgument("run_type")
run_type= getArgument("run_type")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

dataingestion_path =  baseurl + dataingestion_path
output_stage_path = baseurl + output_stage_path
cdd_publish_path = baseurl + cdd_publish_path
output_stage_05_ca_x_patientaccts_demographics_deduped = output_stage_path + feed_source + '/'+ bc +'/output_stage_05_ca_x_patientaccts_demographics_deduped/'
input_edipayers_tupayeridmapping = dataingestion_path + 'edipayers_tupayeridmapping/current/20991231/'
input_edipartners = dataingestion_path + 'edipartners/current/20991231/'
input_hospitals = dataingestion_path + 'hospitals/current/20991231/'
input_tu_consumer = cdd_publish_path + 'consumer/current/*/'
input_tu_address = cdd_publish_path + 'address/current/*/'
input_demographics =output_stage_path + feed_source + '/' + bc + '/'
output_stage_00_tupayerxedipartner = output_stage_path +feed_source + '/'+ bc +'/' + 'tupayerxedipartner/'
output_stage_00_tuconsumer_cleansed = output_stage_path  +feed_source + '/'+ bc +'/' + 'tuconsumer_cleansed/'
output_stage_05_ca_x_fc_demographics_deduped_matched = output_stage_path  +feed_source + '/'+ bc +'/' + 'output_stage_05_ca_x_fc_demographics_deduped_matched/'
output_stage_06_ca_x_patientaccts_demographics_tu = output_stage_path  +feed_source + '/'+ bc +'/' + 'output_stage_06_ca_x_patientaccts_demographics_tu/'
output_stage_07_ca_x_patientaccts_demographics_tu_cleansed = output_stage_path +feed_source + '/'+ bc +'/'+ 'output_stage_07_ca_x_patientaccts_demographics_tu_cleansed/'
output_stage_08_ca_x_patientaccts_demographics_tu_formatted = output_stage_path +feed_source + '/'+ bc +'/' + 'output_stage_08_ca_x_patientaccts_demographics_tu_formatted/'
output_stage_09_ca_x_patientaccts_demographics_tu_formatted_filtered = output_stage_path +feed_source + '/'+ bc +'/' + 'output_stage_09_ca_x_patientaccts_demographics_tu_formatted_filtered/'
output_stage_10_ca_x_demographics = output_stage_path +feed_source + '/'+ bc +'/' + 'output_stage_10_ca_x_demographics/'

print("input_edipayers_tupayeridmapping: ",input_edipayers_tupayeridmapping)
print("input_demographics: ",input_demographics)
print("output_stage_00_tupayerxedipartner: ",output_stage_00_tupayerxedipartner)
print("output_stage_05_ca_x_patientaccts_demographics_deduped: ",output_stage_05_ca_x_patientaccts_demographics_deduped)
print("output_stage_10_ca_x_demographics: ",output_stage_10_ca_x_demographics)

# COMMAND ----------

import os
import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
from pyspark import SparkContext
from pyspark.conf import SparkConf
import subprocess
from  pyspark.sql.functions import input_file_name
from pyspark.sql.window import Window
from pyspark import StorageLevel

# COMMAND ----------

output_partitions = 50
if run_type == 'base':
    output_partitions = 1000

# COMMAND ----------

data_tu = spark.read.format("parquet").load(input_tu_consumer)
data_tu.createOrReplaceTempView("data_tu")
data_tu = spark.sql("""
SELECT tukey    AS permid,
       ssn      AS tu_ssn,
       dob      AS tu_dob,
       frst_nme AS tu_firstname,
       midl_nme AS tu_middlename,
       last_nme AS tu_lastname
FROM data_tu
""").dropDuplicates()
data_tu.createOrReplaceTempView("data_tu")

data_tu_addr = spark.read.format("parquet").load(input_tu_address)
data_tu_addr.createOrReplaceTempView("data_tu_addr")
data_tu_addr = spark.sql("""
SELECT tukey                                                          AS permid,
       addr_seq_num,
       concat_ws(' ',addr_num,str_nme,str_typ_cde,unit_type,unit_num) AS tu_addr,
       city_nme                                                       AS tu_city,
       state_cde                                                      AS tu_state,
       zip_cde                                                        AS tu_zip,
       addr_frst_rptd_dte
FROM data_tu_addr WHERE addr_seq_num ='1'
""").drop("addr_seq_num").dropDuplicates()
data_tu_addr.createOrReplaceTempView("data_tu_addr")

data_tu = spark.sql("""
SELECT data_tu.permid,
       data_tu.tu_ssn,
       data_tu.tu_dob,
       data_tu.tu_firstname,
       data_tu.tu_middlename,
       data_tu.tu_lastname,
       data_tu_addr.tu_addr,
       data_tu_addr.tu_city,
       data_tu_addr.tu_state,
       data_tu_addr.tu_zip
FROM data_tu
  LEFT JOIN data_tu_addr ON TRIM(data_tu.permid) = TRIM(data_tu_addr.permid)
""").dropDuplicates()

for column in data_tu.columns:
    data_tu = data_tu.withColumn(column, trim(col(column)))
    data_tu = data_tu.withColumn(column, when(col(column).isNull(), 'XX').otherwise(col(column)))
    data_tu = data_tu.withColumn(column, when(col(column) == '', 'XX').otherwise(col(column)))
    data_tu = data_tu.withColumn(column, when(upper(col(column)) == 'NULL', 'XX').otherwise(col(column)))
    data_tu = data_tu.withColumn(column, upper(col(column)))


data_tu.dropDuplicates().repartition(output_partitions).write.mode('overwrite').parquet(output_stage_00_tuconsumer_cleansed)
data_tu.unpersist()
data_tu_addr.unpersist()

data_tu = spark.read.parquet(output_stage_00_tuconsumer_cleansed)
data_tu.createOrReplaceTempView("data_tu")

data_ca = spark.read.parquet(output_stage_05_ca_x_patientaccts_demographics_deduped)
data_ca = data_ca.drop("hospitalfk_permidpatientacct")
data_ca.createOrReplaceTempView("data_ca")

data_ca = spark.sql("""
SELECT data_ca.*,
       data_tu.tu_ssn,
       data_tu.tu_dob,
       data_tu.tu_firstname,
       data_tu.tu_middlename,
       data_tu.tu_lastname,
       data_tu.tu_addr,
       data_tu.tu_city,
       data_tu.tu_state,
       data_tu.tu_zip
FROM data_ca
  LEFT JOIN data_tu ON TRIM (data_ca.permid) = TRIM (data_tu.permid)
""")

data_ca.dropDuplicates().repartition(output_partitions).write.mode('overwrite').parquet(output_stage_06_ca_x_patientaccts_demographics_tu)
data_ca.unpersist()

print("COMPLETE : STAGE : 06")

data_ca = spark.read.parquet(output_stage_06_ca_x_patientaccts_demographics_tu)

for column in data_ca.columns:
    data_ca = data_ca.withColumn(column, trim(col(column)))
    data_ca = data_ca.withColumn(column, when(col(column).isNull(), 'XX').otherwise(col(column)))
    data_ca = data_ca.withColumn(column, when(col(column) == '', 'XX').otherwise(col(column)))
    data_ca = data_ca.withColumn(column, when(col(column) == 'null', 'XX').otherwise(col(column)))
    data_ca = data_ca.withColumn(column, upper(col(column)))

data_ca.createOrReplaceTempView("data_ca")

data_ca = spark.sql("""
SELECT transactionkey,
       permid,
       coverageid,
       leadsource,
       sourcekey,
       hospitalfk,
       payerid,
       patientacctifk,
       firstname,
       middlename,
       lastname,
       gender,
       CASE WHEN (firstname = tu_firstname AND lastname = tu_lastname AND dob='XX' AND tu_dob <>'XX') THEN tu_dob ELSE dob END AS dob,
       CASE WHEN (firstname = tu_firstname AND lastname = tu_lastname AND ssn='XX' AND tu_ssn <>'XX') THEN tu_ssn ELSE ssn END AS ssn,
       addr,
       city,
       state,
       zip,
       createdate_as_bigint,
       updatedate_as_bigint,
       demographicsupdatedate_as_bigint,
       trgupdatedate_as_bigint,  
       tu_ssn,
       tu_dob,
       tu_firstname,
       tu_middlename,
       tu_lastname,
       tu_addr,
       tu_city,
       tu_state,
       tu_zip
FROM data_ca
""")

data_ca.createOrReplaceTempView("data_ca")

data_ca = spark.sql("""
SELECT transactionkey,
       permid,
       coverageid,
       leadsource,
       sourcekey,
       hospitalfk,
       payerid,
       patientacctifk,
       CASE WHEN (updatedate_as_bigint='XX' AND demographicsupdatedate_as_bigint='XX' AND  trgupdatedate_as_bigint='XX') THEN tu_firstname  ELSE firstname  END AS firstname,
       CASE WHEN (updatedate_as_bigint='XX' AND demographicsupdatedate_as_bigint='XX' AND  trgupdatedate_as_bigint='XX') THEN tu_middlename ELSE middlename END AS middlename,
       CASE WHEN (updatedate_as_bigint='XX' AND demographicsupdatedate_as_bigint='XX' AND  trgupdatedate_as_bigint='XX') THEN tu_lastname   ELSE lastname   END AS lastname,
       gender,
       CASE WHEN (updatedate_as_bigint='XX' AND demographicsupdatedate_as_bigint='XX' AND  trgupdatedate_as_bigint='XX') THEN tu_dob   ELSE dob   END AS dob,
       CASE WHEN (updatedate_as_bigint='XX' AND demographicsupdatedate_as_bigint='XX' AND  trgupdatedate_as_bigint='XX') THEN tu_ssn   ELSE ssn   END AS ssn,
       CASE WHEN (updatedate_as_bigint='XX' AND demographicsupdatedate_as_bigint='XX' AND  trgupdatedate_as_bigint='XX') THEN tu_addr  ELSE addr  END AS addr,
       CASE WHEN (updatedate_as_bigint='XX' AND demographicsupdatedate_as_bigint='XX' AND  trgupdatedate_as_bigint='XX') THEN tu_city  ELSE city  END AS city,
       CASE WHEN (updatedate_as_bigint='XX' AND demographicsupdatedate_as_bigint='XX' AND  trgupdatedate_as_bigint='XX') THEN tu_state ELSE state END AS state,
       CASE WHEN (updatedate_as_bigint='XX' AND demographicsupdatedate_as_bigint='XX' AND  trgupdatedate_as_bigint='XX') THEN tu_zip   ELSE zip   END AS zip,
       createdate_as_bigint,
       updatedate_as_bigint,
       demographicsupdatedate_as_bigint,
       trgupdatedate_as_bigint,       
       tu_ssn,
       tu_dob,
       tu_firstname,
       tu_middlename,
       tu_lastname,
       tu_addr,
       tu_city,
       tu_state,
       tu_zip
FROM data_ca
""").dropDuplicates()

data_ca.createOrReplaceTempView("data_ca")
data_ca=spark.sql("""
SELECT transactionkey,
       permid,
       coverageid,
       leadsource,
       sourcekey,
       hospitalfk,
       payerid,
       patientacctifk,
       firstname,
       middlename,
       lastname,
       gender,
       dob,
       ssn,
       addr,
       city,
       state,
       zip,
       CASE WHEN createdate_as_bigint='XX'             THEN CAST(regexp_replace (regexp_replace (regexp_replace (regexp_replace ((SPLIT (CURRENT_TIMESTAMP(),"\\\.")[0]),"T",""),":",""),"-","")," ","") AS BIGINT) ELSE createdate_as_bigint END AS createdate_as_bigint,
       CASE WHEN updatedate_as_bigint='XX'             THEN CAST(regexp_replace (regexp_replace (regexp_replace (regexp_replace ((SPLIT (CURRENT_TIMESTAMP(),"\\\.")[0]),"T",""),":",""),"-","")," ","") AS BIGINT) ELSE updatedate_as_bigint END AS updatedate_as_bigint,
       CASE WHEN demographicsupdatedate_as_bigint='XX' THEN CAST(regexp_replace (regexp_replace (regexp_replace (regexp_replace ((SPLIT (CURRENT_TIMESTAMP(),"\\\.")[0]),"T",""),":",""),"-","")," ","") AS BIGINT) ELSE demographicsupdatedate_as_bigint END AS demographicsupdatedate_as_bigint,
       CASE WHEN trgupdatedate_as_bigint='XX'          THEN CAST(regexp_replace (regexp_replace (regexp_replace (regexp_replace ((SPLIT (CURRENT_TIMESTAMP(),"\\\.")[0]),"T",""),":",""),"-","")," ","") AS BIGINT) ELSE trgupdatedate_as_bigint END AS trgupdatedate_as_bigint,      
       tu_ssn,
       tu_dob,
       tu_firstname,
       tu_middlename,
       tu_lastname,
       tu_addr,
       tu_city,
       tu_state,
       tu_zip
FROM data_ca
""")
data_ca.dropDuplicates().repartition(output_partitions).write.mode('overwrite').parquet(output_stage_07_ca_x_patientaccts_demographics_tu_cleansed)
data_ca.unpersist()
print("COMPLETE : STAGE : 07")

data_fc = spark.read.parquet(output_stage_05_ca_x_fc_demographics_deduped_matched).select("transactionkey","permid","coverageid","leadsource","sourcekey","hospitalfk","payerid","patientacctifk","firstname","middlename","lastname","gender","dob","ssn","addr","city","state","zip","createdate_as_bigint","updatedate_as_bigint","demographicsupdatedate_as_bigint","trgupdatedate_as_bigint")

# data_ca = spark.read.parquet(output_stage_07_ca_x_patientaccts_demographics_tu_cleansed)
data_ca = spark.read.parquet(output_stage_07_ca_x_patientaccts_demographics_tu_cleansed).select("transactionkey","permid","coverageid","leadsource","sourcekey","hospitalfk","payerid","patientacctifk","firstname","middlename","lastname","gender","dob","ssn","addr","city","state","zip","createdate_as_bigint","updatedate_as_bigint","demographicsupdatedate_as_bigint","trgupdatedate_as_bigint")

data_ca = data_ca.unionAll(data_fc)
data_ca.createOrReplaceTempView("data_ca")

data_ca = spark.sql("""
SELECT A.transactionkey,
       A.permid,
       CAST(CONCAT (SUBSTR (A.createdate_as_bigint,1,4),"-",SUBSTR (A.createdate_as_bigint,5,2),"-",SUBSTR (A.createdate_as_bigint,7,2)," ",SUBSTR (A.createdate_as_bigint,9,2),":",SUBSTR (A.createdate_as_bigint,11,2),":",SUBSTR (A.createdate_as_bigint,13,2)) AS STRING) AS createdate,
       CAST(CONCAT (SUBSTR (A.updatedate_as_bigint,1,4),"-",SUBSTR (A.updatedate_as_bigint,5,2),"-",SUBSTR (A.updatedate_as_bigint,7,2)," ",SUBSTR (A.updatedate_as_bigint,9,2),":",SUBSTR (A.updatedate_as_bigint,11,2),":",SUBSTR (A.updatedate_as_bigint,13,2)) AS STRING) AS updatedate,
       A.coverageid,
       lower(leadsource) AS leadsource,
       A.sourcekey,
       A.hospitalfk,
       A.payerid,
       A.firstname,
       CASE
         WHEN A.middlename = 'XX' THEN ''
         ELSE A.middlename
       END AS middlename,
       A.lastname,
       CASE
         WHEN A.gender = 'XX' THEN ''
         ELSE A.gender
       END AS gender,
       --TRIM(regexp_replace (A.dob,"00:00:00",'')) AS dob,
       cast(Cast(TRIM(dob) as date) as string) as dob,
       CASE
         WHEN A.ssn = 'XX' THEN '000000000'
         ELSE A.ssn
       END AS ssn,
       A.addr,
       CASE
         WHEN A.city = 'XX' THEN ''
         ELSE A.city
       END AS city,
       CASE
         WHEN A.state = 'XX' THEN ''
         ELSE A.state
       END AS state,
       CASE
         WHEN A.zip = 'XX' THEN ''
         ELSE SUBSTR (A.zip,1,5)
       END AS zip,
       CASE WHEN (A.firstname = 'XX' AND A.lastname = 'XX' AND A.ssn = 'XX' AND A.dob = 'XX') THEN '0' ELSE '1' END AS isValidDemo
FROM data_ca A
""")
# Update criteria to validate demographics by checking (first name, last name, ssn) or (first name, last name, dob)

data_ca=data_ca.filter("isValidDemo=='1'").drop("isValidDemo")
data_ca.dropDuplicates().repartition(output_partitions).write.mode('overwrite').parquet(output_stage_08_ca_x_patientaccts_demographics_tu_formatted)
data_ca.unpersist()
print("COMPLETE : STAGE : 08")

# tupayer_data = spark.read.parquet(input_edipayers_tupayeridmapping).select("tupayerid", "edipayerfk")
# edipartner_data = spark.read.parquet(input_edipartners).filter("isenabledflag=='1'").filter("familyclusteringenabledflag=='1'").filter("edipartnerpk > 0").select("edipayerfk", "edipartnerpk").dropDuplicates()
# tupayer_data = tupayer_data.join(edipartner_data, 'edipayerfk').selectExpr("CAST(tupayerid AS int) AS tupayerid", "edipartnerpk AS edipartnerfk")
# cond1 = when(col("tupayerid") == 10102, lit(30)).otherwise(col("edipartnerfk"))
# cond2 = when(col("tupayerid") == 10001, lit(82)).otherwise(col("edipartnerfk"))
# cond3 = when(col("tupayerid") == 10055, lit(8)).otherwise(col("edipartnerfk"))
# cond4 = when(col("tupayerid") == 10285, lit(71)).otherwise(col("edipartnerfk"))
# cond5 = when(col("tupayerid") == 11174, lit(479)).otherwise(col("edipartnerfk"))
# cond6 = when(col("tupayerid") == 11196, lit(547)).otherwise(col("edipartnerfk"))
# tupayer_data = tupayer_data.withColumn("edipartnerfk", cond1)
# tupayer_data = tupayer_data.withColumn("edipartnerfk", cond2)
# tupayer_data = tupayer_data.withColumn("edipartnerfk", cond3)
# tupayer_data = tupayer_data.withColumn("edipartnerfk", cond4)
# tupayer_data = tupayer_data.withColumn("edipartnerfk", cond5)
# tupayer_data = tupayer_data.withColumn("edipartnerfk", cond6).dropDuplicates()
# tupayer_data = tupayer_data.selectExpr("edipartnerfk").dropDuplicates()
# tupayer_data.dropDuplicates().repartition(output_partitions).write.mode('overwrite').parquet(output_stage_00_tupayerxedipartner)
# tupayer_data.unpersist()
# edipartner_data.unpersist()

# tupayer_data = spark.read.parquet(output_stage_00_tupayerxedipartner)
# tupayer_data.createOrReplaceTempView("tupayer_data")

data_ca = spark.read.parquet(output_stage_08_ca_x_patientaccts_demographics_tu_formatted)
data_ca.createOrReplaceTempView("data_ca")

# data_ca = spark.sql("""select * from data_ca where payerid in (select distinct edipartnerfk from tupayer_data)""")
# data_ca.createOrReplaceTempView("data_ca")

data_hospitals = spark.read.parquet(input_hospitals)
data_hospitals = data_hospitals.selectExpr("hospitalpk as hospitalfk", "hcsystemfk").dropDuplicates()
data_hospitals.createOrReplaceTempView("data_hospitals")

data_ca = spark.sql("""
SELECT data_ca.*,
       CASE WHEN data_hospitals.hcsystemfk IS NULL THEN data_ca.hospitalfk ELSE data_hospitals.hcsystemfk END AS hcsystemfk
FROM data_ca
  LEFT OUTER JOIN data_hospitals ON CAST (data_ca.hospitalfk AS BIGINT) = CAST (data_hospitals.hospitalfk AS BIGINT)
""").withColumn("bc", lit(bc))

data_ca.createOrReplaceTempView("data_ca")
data_ca=spark.sql(""" SELECT *,CASE WHEN dob='XX' THEN '1800-01-01' ELSE dob END as dob_rev FROM data_ca """)
data_ca=data_ca.drop("dob").withColumnRenamed("dob_rev","dob")
data_ca.dropDuplicates().repartition(output_partitions).write.mode('overwrite').parquet(output_stage_09_ca_x_patientaccts_demographics_tu_formatted_filtered)
data_ca.unpersist()
print("COMPLETE : STAGE : 09")

data_ca = spark.read.parquet(output_stage_09_ca_x_patientaccts_demographics_tu_formatted_filtered)

from pyspark.sql.functions import udf

def ascii_ignore(x):
    return x.encode('ascii', 'ignore').decode('ascii')

ascii_udf = udf(ascii_ignore)


for column in data_ca.columns:
    data_ca = data_ca.withColumn(column, trim(col(column)))
    data_ca = data_ca.withColumn(column, when(upper(col(column)) == 'NONE','').otherwise(col(column)))
    data_ca = data_ca.withColumn(column, when(col(column).isNull(), '').otherwise(col(column)))
    data_ca = data_ca.withColumn(column, when(upper(col(column)) =='NULL', '').otherwise(col(column)))

for column in data_ca.columns:
    data_ca = data_ca.withColumn(column, regexp_replace(col(column),'\\@',''))
    data_ca = data_ca.withColumn(column, regexp_replace(col(column),'\\\@',''))
    data_ca = data_ca.withColumn(column, regexp_replace(col(column),'@',''))
    data_ca = data_ca.withColumn(column, regexp_replace(col(column),'~',''))
    data_ca = data_ca.withColumn(column, ascii_udf(col(column)))

data_ca.createOrReplaceTempView("data_ca")


data_ca = spark.sql("""
SELECT transactionkey,
       permid,    
       sourcekey,
       CONCAT(payerid,"_",coverageid) AS leadid,
       '1'                            AS isdemovalid,
       '0'                            AS dependentflag, /*--do we need dependent flag ??? */
       CAST(regexp_replace (regexp_replace (regexp_replace (regexp_replace ((SPLIT (cast(createdate as timestamp),"\\\.")[0]),"T",""),":",""),"-","")," ","") AS BIGINT) AS createdate_as_bigint,
       CASE WHEN CAST(TRIM(hcsystemfk) AS BIGINT) IS NULL THEN hospitalfk ELSE hcsystemfk END AS hcsystemfk,
       hospitalfk,
       'fm'                           AS source,
       CASE WHEN sourcekey='1' THEN 'fc'
            WHEN sourcekey='2' THEN 'ich'
            ELSE 'XX' END AS leadsource,
       bc,
       STRUCT(
              firstname,
              state,
              middlename,
              lastname,
              CASE WHEN dob='' THEN '1800-01-01' ELSE dob END as dob,
              ssn,
              gender,
              '0' AS dependentflag,  /* Do we need dependent flag column?? */
              createdate,
              CASE WHEN updatedate IS NULL THEN createdate ELSE updatedate END AS updatedate,
              hospitalfk,
              hcsystemfk,
              bc,
              'fm' AS source,
              'fm' AS xrefsource,
              CASE WHEN sourcekey='1' THEN 'fc'
                   WHEN sourcekey='2' THEN 'ich'
                   ELSE 'XX' END AS leadsource
              ) AS demographics
FROM data_ca
""")

data_ca.dropDuplicates().repartition(output_partitions).write.mode('overwrite').parquet(output_stage_10_ca_x_demographics)
data_ca.unpersist()

data_ca=spark.read.parquet(output_stage_10_ca_x_demographics)
# data_ca.write.partitionBy("sourcekey").mode('overwrite').parquet(input_demographics)
data_ca.where("sourcekey == '1'").write.mode('overwrite').parquet(input_demographics+'fc')
data_ca.where("sourcekey == '2'").write.mode('overwrite').parquet(input_demographics+'ich')
data_ca.unpersist()

print("COMPLETE : STAGE : 10")
