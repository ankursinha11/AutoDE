# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("feed_source","")
dbutils.widgets.getArgument("feed_source")
feed_source= getArgument("feed_source")

dbutils.widgets.text("run_type","")
dbutils.widgets.getArgument("run_type")
run_type= getArgument("run_type")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("output_stage","")
dbutils.widgets.getArgument("output_stage")
output_stage= getArgument("output_stage")

dbutils.widgets.text("input_patientaccts","")
dbutils.widgets.getArgument("input_patientaccts")
input_patientaccts= getArgument("input_patientaccts")


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))
spark.conf.set('spark.sql.shuffle.partitions','auto')

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

import os
import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
from pyspark import SparkContext
from pyspark.conf import SparkConf
import subprocess
from  pyspark.sql.functions import input_file_name
from pyspark.sql.window import Window
from pyspark import StorageLevel

# COMMAND ----------

output_stage_03_ca_x_perm_x_patientaccts = baseurl+output_stage +feed_source + '/'+ bc +'/'+ 'output_stage_05_ca_x_fc_demographics_deduped_unmatched'
input_patientaccts = baseurl + input_patientaccts
output_stage_04_ca_x_patientaccts_demographics = baseurl + output_stage + feed_source + '/'+ bc +'/'+ 'output_stage_04_ca_x_patientaccts_demographics'
output_stage_05_ca_x_patientaccts_demographics_deduped = baseurl+output_stage + feed_source + '/'+ bc +'/'+ 'output_stage_05_ca_x_patientaccts_demographics_deduped'
print("input_ca_breadcrumb:",bc)
print("output_stage_03_ca_x_perm_x_patientaccts:",output_stage_03_ca_x_perm_x_patientaccts)
print("input_patientaccts:",input_patientaccts)
print("output_stage_04_ca_x_patientaccts_demographics:",output_stage_04_ca_x_patientaccts_demographics)
print("output_stage_05_ca_x_patientaccts_demographics_deduped:",output_stage_05_ca_x_patientaccts_demographics_deduped)

# COMMAND ----------

data_ca = spark.read.parquet(output_stage_03_ca_x_perm_x_patientaccts)
data_ca.createOrReplaceTempView("data_ca")

data_patientaccts = spark.read.format("delta").load(input_patientaccts)
data_patientaccts.createOrReplaceTempView("data_patientaccts")
data_patientaccts = spark.sql("""
SELECT patientacctipk,
       hospitalfk,
       firstname,
       middlename,
       lastname,
       gender,
       dob,
       ssn,
       concat_ws(' ',addr1,addr2) as addr,
       city,
       state,
       zip,
       CAST(regexp_replace (regexp_replace (regexp_replace (regexp_replace ((SPLIT (cast(createdate as timestamp),"\\\.")[0]),"T",""),":",""),"-","")," ","") AS BIGINT)             AS createdate_as_bigint,
       CAST(regexp_replace (regexp_replace (regexp_replace (regexp_replace ((SPLIT (cast(updatedate as timestamp),"\\\.")[0]),"T",""),":",""),"-","")," ","") AS BIGINT)             AS updatedate_as_bigint,
       CAST(regexp_replace (regexp_replace (regexp_replace (regexp_replace ((SPLIT (cast(demographicsupdatedate as timestamp),"\\\.")[0]),"T",""),":",""),"-","")," ","") AS BIGINT) AS demographicsupdatedate_as_bigint,
       CAST(regexp_replace (regexp_replace (regexp_replace (regexp_replace ((SPLIT (cast(trgupdatedate as timestamp),"\\\.")[0]),"T",""),":",""),"-","")," ","") AS BIGINT)          AS trgupdatedate_as_bigint
FROM data_patientaccts
""")

data_patientaccts.createOrReplaceTempView("data_patientaccts")

# COMMAND ----------

data_ca = spark.sql("""
SELECT data_ca.*,
       --data_patientaccts.hospitalfk,
       data_patientaccts.firstname,
       data_patientaccts.middlename,
       data_patientaccts.lastname,
       data_patientaccts.gender,
       data_patientaccts.dob,
       data_patientaccts.ssn,
       data_patientaccts.addr,
       data_patientaccts.city,
       data_patientaccts.state,
       data_patientaccts.zip,
       data_patientaccts.createdate_as_bigint,
       data_patientaccts.updatedate_as_bigint,
       data_patientaccts.demographicsupdatedate_as_bigint,
       data_patientaccts.trgupdatedate_as_bigint
FROM data_ca
  LEFT JOIN data_patientaccts ON CAST(data_ca.patientacctifk AS BIGINT) = CAST(data_patientaccts.patientacctipk AS BIGINT)
  AND CAST(data_patientaccts.hospitalfk AS INT) = CAST(data_ca.hospitalfk_permidpatientacct AS INT)
""")
data_ca = data_ca.dropDuplicates()

# COMMAND ----------

output_partitions = 10
if run_type == 'base':
    output_partitions = 1000

# COMMAND ----------

data_ca.repartition(output_partitions).write.mode('overwrite').parquet(output_stage_04_ca_x_patientaccts_demographics)
data_ca.unpersist()
data_patientaccts.unpersist()
print("COMPLETE : STAGE : 04 : output_stage_04_ca_x_patientaccts_demographics : " + output_stage_04_ca_x_patientaccts_demographics)

# COMMAND ----------

data_ca = spark.read.parquet(output_stage_04_ca_x_patientaccts_demographics)

#Check if needed
for column in data_ca.columns:
    data_ca = data_ca.withColumn(column, trim(col(column)))
    data_ca = data_ca.withColumn(column, when(col(column).isNull(), 'XX').otherwise(col(column)))
    data_ca = data_ca.withColumn(column, when(col(column) == '', 'XX').otherwise(col(column)))
    data_ca = data_ca.withColumn(column, when(upper(col(column)) == 'NULL', 'XX').otherwise(col(column)))
    data_ca = data_ca.withColumn(column, upper(col(column)))


# data_ca = data_ca.drop("leadsource").withColumn("leadsource",lit('fm')).drop("patientacctifk").withColumn("patientacctifk",lit('00000000000')).drop("transactionkey").withColumn("transactionkey",lit('00000000000')).dropDuplicates()
data_ca = data_ca.drop("patientacctifk").withColumn("patientacctifk",lit('00000000000')).drop("transactionkey").withColumn("transactionkey",lit('00000000000')).dropDuplicates()
data_ca.createOrReplaceTempView("data_ca")

# COMMAND ----------

data_ca_nx = spark.sql("""
SELECT data_ca.permid,
       data_ca.transactionkey,
       data_ca.coverageid,
       data_ca.leadsource,
       data_ca.sourcekey,
       data_ca.hospitalfk,
       data_ca.payerid,
       data_ca.patientacctifk,
       data_ca.hospitalfk_permidpatientacct,
       data_ca.firstname,
       data_ca.middlename,
       data_ca.lastname,
       data_ca.gender,
       data_ca.dob,
       data_ca.ssn,
       data_ca.addr,
       data_ca.city,
       data_ca.state,
       data_ca.zip,
       data_ca.createdate_as_bigint,
       data_ca.updatedate_as_bigint,
       data_ca.demographicsupdatedate_as_bigint,
       data_ca.trgupdatedate_as_bigint,
       ROW_NUMBER() OVER (PARTITION BY data_ca.permid,data_ca.coverageid,data_ca.hospitalfk,data_ca.leadsource,data_ca.payerid ORDER BY data_ca.trgupdatedate_as_bigint DESC) AS RNK
FROM data_ca
WHERE data_ca.createdate_as_bigint <> 'XX'
AND   data_ca.updatedate_as_bigint <> 'XX'
AND   data_ca.demographicsupdatedate_as_bigint <> 'XX'
AND   data_ca.trgupdatedate_as_bigint <> 'XX'
""")
data_ca_nx = data_ca_nx.filter("RNK=='1'").drop("RNK")

# COMMAND ----------

data_ca_xx = spark.sql("""
SELECT data_ca.permid,
       data_ca.transactionkey,
       data_ca.coverageid,
       data_ca.leadsource,
       data_ca.sourcekey,
       data_ca.hospitalfk,
       data_ca.payerid,
       data_ca.patientacctifk,
       data_ca.hospitalfk_permidpatientacct,
       data_ca.firstname,
       data_ca.middlename,
       data_ca.lastname,
       data_ca.gender,
       data_ca.dob,
       data_ca.ssn,
       data_ca.addr,
       data_ca.city,
       data_ca.state,
       data_ca.zip,
       data_ca.createdate_as_bigint,
       data_ca.updatedate_as_bigint,
       data_ca.demographicsupdatedate_as_bigint,
       data_ca.trgupdatedate_as_bigint
FROM data_ca
WHERE data_ca.createdate_as_bigint = 'XX'
AND   data_ca.updatedate_as_bigint = 'XX'
AND   data_ca.demographicsupdatedate_as_bigint = 'XX'
AND   data_ca.trgupdatedate_as_bigint = 'XX'
""").dropDuplicates()

# COMMAND ----------

data_ca=data_ca_nx.union(data_ca_xx)

data_ca.createOrReplaceTempView("data_ca")

data_ca=spark.sql("""
SELECT data_ca.permid,
       data_ca.transactionkey,
       data_ca.coverageid,
       data_ca.leadsource,
       data_ca.sourcekey,
       data_ca.hospitalfk,
       data_ca.payerid,
       data_ca.patientacctifk,
       data_ca.hospitalfk_permidpatientacct,
       data_ca.firstname,
       data_ca.middlename,
       data_ca.lastname,
       data_ca.gender,
       data_ca.dob,
       data_ca.ssn,
       data_ca.addr,
       data_ca.city,
       data_ca.state,
       data_ca.zip,
       data_ca.createdate_as_bigint,
       data_ca.updatedate_as_bigint,
       data_ca.demographicsupdatedate_as_bigint,
       data_ca.trgupdatedate_as_bigint,
       CASE WHEN (data_ca.firstname='XX' AND data_ca.trgupdatedate_as_bigint='XX') THEN '0' ELSE '1' END AS demo_quality
FROM data_ca
""")
data_ca.createOrReplaceTempView("data_ca")

# COMMAND ----------

data_ca=spark.sql("""
SELECT data_ca.permid,
       data_ca.transactionkey,
       data_ca.coverageid,
       data_ca.leadsource,
       data_ca.sourcekey,
       data_ca.hospitalfk,
       data_ca.payerid,
       data_ca.patientacctifk,
       data_ca.hospitalfk_permidpatientacct,
       data_ca.firstname,
       data_ca.middlename,
       data_ca.lastname,
       data_ca.gender,
       data_ca.dob,
       data_ca.ssn,
       data_ca.addr,
       data_ca.city,
       data_ca.state,
       data_ca.zip,
       data_ca.createdate_as_bigint,
       data_ca.updatedate_as_bigint,
       data_ca.demographicsupdatedate_as_bigint,
       data_ca.trgupdatedate_as_bigint,
       RANK() OVER (PARTITION BY data_ca.permid,data_ca.coverageid,data_ca.hospitalfk,data_ca.leadsource,data_ca.payerid ORDER BY CAST(demo_quality AS INT) DESC) AS RNK
FROM data_ca
""").filter("RNK=='1'").drop("RNK")

data_ca = data_ca.dropDuplicates()

# COMMAND ----------

data_ca.repartition(output_partitions).write.mode('overwrite').parquet(output_stage_05_ca_x_patientaccts_demographics_deduped)
data_ca.unpersist()

print("COMPLETE : STAGE : 05 : output_stage_05_ca_x_patientaccts_demographics_deduped : " + output_stage_05_ca_x_patientaccts_demographics_deduped)
