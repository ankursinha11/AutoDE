// Databricks notebook source
// MAGIC %md 
// MAGIC this notebook performs activities from PopulateLsbLeadsReference.scala

// COMMAND ----------

import org.apache.spark.sql.{DataFrame}
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._
import scala.io.Source
import scala.collection._
import java.time.format.DateTimeFormatter
import java.time.LocalDate
import java.time.LocalDateTime
import io.delta.tables._
import spark.implicits._
import org.apache.spark.sql.expressions.{Window, WindowSpec}
import org.apache.spark.sql.types._
import org.apache.spark.sql.Column
import org.apache.spark.sql.expressions.UserDefinedFunction

// COMMAND ----------

// DBTITLE 1,Input Parameters
dbutils.widgets.text("hdfs_path","")
var hdfs_path=dbutils.widgets.get("hdfs_path")

dbutils.widgets.text("deltalake_output","")
var deltalake_output=dbutils.widgets.get("deltalake_output")

dbutils.widgets.text("id_column","")
val id_column=dbutils.widgets.get("id_column")

dbutils.widgets.text("store_path","")
var store_path=dbutils.widgets.get("store_path")

dbutils.widgets.text("list_column","")
val list_column=dbutils.widgets.get("list_column")

dbutils.widgets.text("num_partition","")
val num_partition=dbutils.widgets.get("num_partition")

dbutils.widgets.text("column_to_get","")
val column_to_get=dbutils.widgets.get("column_to_get")

dbutils.widgets.text("sec_index_name","")
val sec_index_name=dbutils.widgets.get("sec_index_name")

dbutils.widgets.text("config_file_path","")
var config_file_path=dbutils.widgets.get("config_file_path")

dbutils.widgets.text("source","")
val source=dbutils.widgets.get("source")

dbutils.widgets.text("hospitalfk_field_name","")
val hospitalfk_field_name=dbutils.widgets.get("hospitalfk_field_name")

dbutils.widgets.text("temp_op_path","")
var temp_op_path=dbutils.widgets.get("temp_op_path")

dbutils.widgets.text("user","")
val users=dbutils.widgets.get("user")

dbutils.widgets.text("feed_source","")
val feed_source=dbutils.widgets.get("feed_source")

dbutils.widgets.text("bc","")
val bc=dbutils.widgets.get("bc")

dbutils.widgets.text("leadlookupoppath","")
var leadlookupoppath=dbutils.widgets.get("leadlookupoppath")

dbutils.widgets.text("storageaccount","")
val storageaccount=dbutils.widgets.get("storageaccount")

dbutils.widgets.text("container","")
val container=dbutils.widgets.get("container")


// COMMAND ----------

// DBTITLE 1,ADLS Access
// MAGIC %python
// MAGIC dbutils.widgets.text("storageaccount","")
// MAGIC storageaccount=dbutils.widgets.get("storageaccount")
// MAGIC spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

// COMMAND ----------

// MAGIC %run "/Insleads-code/LeadServiceBase/common/LeadServiceBase-Common"

// COMMAND ----------

var baseurl=""
if (users == "na"){
  baseurl ="abfss://"+container+"@"+storageaccount+".dfs.core.windows.net"
}
else{
  baseurl ="abfss://"+container+"@"+storageaccount+".dfs.core.windows.net/" + users
}


// COMMAND ----------

config_file_path= baseurl+ config_file_path+"lsb_source_config.txt"
deltalake_output= baseurl+deltalake_output
hdfs_path=baseurl+ hdfs_path
leadlookupoppath=baseurl+leadlookupoppath
store_path=baseurl+store_path
temp_op_path=baseurl+temp_op_path

// COMMAND ----------

// DBTITLE 1,Defining mapFile function - get the scource and its source key from the config.txt file
def mapFile(filePath: String): Map[String, String] ={
    val file = spark.read.text(filePath)
    (for {
    row <- file.rdd.collect
    Array(key, value) = row.mkString(",").split(":")
  } yield key -> value).toMap
}

// COMMAND ----------

val hp = hospitalfk_field_name
val mp: Map[String, String] = mapFile(config_file_path)
val source_val = mp.getOrElse(source, null)
val param_val = mp.getOrElse(list_column, null)
val id_column_name = id_column

// COMMAND ----------

// DBTITLE 1,Reading json_demog, lr_xref_xxx_transactionid & lsb_delta_df
val json_demog: DataFrame = getParquetData(hdfs_path  + feed_source + "/" + bc + "/"+source+"/")
val lr_xref_df:DataFrame = spark.read.format("delta").load(store_path)
val lsb_delta_df = spark.read.format("delta").load(deltalake_output)

val temp_op_path_formatted = temp_op_path + "/new_" + list_column + "_" + source + "_lookupvalue/"
val temp_op_path1 = temp_op_path + "/new_" + list_column + "_"  + source + "_maprdbinput/"
val temp_op_path2 = temp_op_path + "/new_" + list_column + "_"  + source + "_insert_response/" + bc + "/"
//lsb and input join 
val temp_op_path3 = temp_op_path + "/new_" + list_column + "_"  + source + "_lsb_join/" + bc + "/"
//before upsert into lsb
val temp_op_path4 = temp_op_path + "/new_" + list_column + "_"  + source + "_map_op/" + bc + "/"

val bad_record_path = temp_op_path + "/bad_record/"  + source + "/" + bc + "/"
val lsb_temp_path = temp_op_path + "/lsb_parquet_temp/" + bc + "/"

// COMMAND ----------

// DBTITLE 1,Defining prepareDeltaLakeTable
def prepareDeltaLakeTable1(df: DataFrame, column_to_get: String, param_val: String, source: String, id_column_name: String, temp_op_path1: String,bad_record_path: String): Unit = {
  val df1 = df.withColumn(column_to_get, concat_ws("_", lit(param_val), col(column_to_get)))

  val df2 = df1.withColumn("new_id", concat_ws("_", col("hcsystemfk"), col("source")))

  val df3 = df2.select(
    col(column_to_get),
    concat_ws(".", lit("demographics"), col("new_id")).alias("demo_id"),
    col("leadid"),
    concat_ws("~",
      col("lookupvalue"),
      concat_ws(".", lit("demographics"), col("new_id")).alias("new_id"),
      col("source"),
      col("new_id").alias("demo_key"),
      col("demographics.firstname"),
      col("demographics.lastname"),
      col("demographics.dob"),
      col("demographics.middlename"),
      col("demographics.gender"),
      col("demographics.updatedate"),
      col("demographics.hospitalfk"),
      col("demographics.ssn").alias("ssn"),
      col("xrefsource").alias("xrefsource"),
      col("demographics.leadsource").alias("leadsource"),
      col("demographics.state").alias("state"),
      col("demographics.createdate").alias("leadcreatedate")
    ).alias("concat_columns"))
    
  val df4 = df3.withColumn("_id", concat_ws("_", col(column_to_get), col("leadid")))

  val df5 = df4.withColumn("new_col",split(col("concat_columns"),"~"))

  val df6 = df5.withColumn("size_new_col",size(col("new_col")))

  val df7 = df6.filter(col("size_new_col") === 16)
  
  val df8 = df6.filter(col("size_new_col") =!= 16)  // bad records

  writeParquetData( df7: DataFrame, temp_op_path1: String, "overwrite")
  writeParquetData( df8: DataFrame, bad_record_path: String, "overwrite")
}

// COMMAND ----------

// DBTITLE 1,Calling the functions - getFilteredParquetData & prepareDeltaLakeTable1
//getReferenceId(json_demog, list_column, source_val,temp_op_path_formatted,lr_xref_df)
//val input_df1: DataFrame = getFilteredParquetData(temp_op_path_formatted, column_to_get)
// var input_df1: DataFrame = spark.read.parquet("abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/data/leadservicebase/staging/famc/es_lsb_famc/20231116T07/output_stage_10_ca_x_demographics/")
// var input_df1: DataFrame = spark.read.parquet(hdfs_path  + feed_source + "/" + bc +"/output_stage_10_ca_x_demographics/")
var input_df1: DataFrame = spark.read.parquet(hdfs_path  + feed_source + "/" + bc + "/"+source+"/")
input_df1 = input_df1.withColumnRenamed(list_column,("lookupvalue"))
input_df1= input_df1.withColumn("xrefsource",lit("fm"))

// COMMAND ----------

prepareDeltaLakeTable1(input_df1, column_to_get, param_val, source, id_column_name, temp_op_path1,bad_record_path)

// COMMAND ----------

UpsertIntoLSBTable(num_partition.toInt, deltalake_output, temp_op_path1, source, temp_op_path3, temp_op_path4, lsb_delta_df, leadlookupoppath)
