# Databricks notebook source
from datetime import datetime
from pyspark.sql.functions import *

# COMMAND ----------

start=datetime.now()
print(start)

# COMMAND ----------

dbutils.widgets.text("hdfs_match_output", "")
hdfs_output = dbutils.widgets.get("hdfs_match_output")

dbutils.widgets.text("swift_mode", "0")
swift_mode = dbutils.widgets.get("swift_mode")

dbutils.widgets.text("storageaccount","")
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text("stagedPatientacctsTableName","")
stagedPatientacctsTableName = dbutils.widgets.get("stagedPatientacctsTableName")

dbutils.widgets.text("stagedGlobalmrndemographicsTableName","")
stagedGlobalmrndemographicsTableName = dbutils.widgets.get("stagedGlobalmrndemographicsTableName")

dbutils.widgets.text("mergedGlobalMrnTableName","")
mergedGlobalMrnTableName = dbutils.widgets.get("mergedGlobalMrnTableName")

# COMMAND ----------

# bc = "20250522T06"
# base_url = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data"
# hdfs_output = f"{base_url}/gmrn/staging/matches/merge/{bc}"
# swift_mode = "0"
# stagedPatientacctsTableName = f"regular_staged_patientaccts_{bc}"
# stagedGlobalmrndemographicsTableName = f"regular_staged_globalmrndemographics_{bc}"
# mergedGlobalMrnTableName = f"merged_global_mrn_{bc}"
# storageaccount = "prodicdstgdls"

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.skewJoin.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "auto")
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/tu_data_quality"

# COMMAND ----------

# MAGIC %run "/Insleads-code/GMRN/gmrn_merge/match_util"

# COMMAND ----------

selectedCols = ["globalmrnifk", "firstname", "dob", "lastname", "gender", "phone", "city", "state", "zip", "addrnum", "medicalrecnum", "ssn", "hhpermid", \
                "fn_valid", "dob_valid", "ln_valid", "gender_valid", "phone_valid", "city_valid", "state_valid", "zip_valid", "addrnum_valid", \
                "mrn_valid", "ssn_valid", "hhpermid_valid"]


# COMMAND ----------

if int(swift_mode) == 1:
    print("swift_mode ON")
    df_pa = spark.read.table(stagedPatientacctsTableName).select(selectedCols)
    df_gd = spark.read.table(stagedGlobalmrndemographicsTableName).select(selectedCols)
    df_pa_2 = df_pa.where((df_pa.dob_valid == 1) & \
                          (df_pa.fn_valid == 1) & \
                          (df_pa.ln_valid == 1) & \
                          (df_pa.gender_valid == 1)
                          )
    df_gd_2 = df_gd.where((df_gd.dob_valid == 1) & \
                          (df_gd.fn_valid == 1) & \
                          (df_gd.ln_valid == 1) & \
                          (df_gd.gender_valid == 1)
                          )
    left = df_pa_2.alias('left')
    right = df_gd_2.alias('right')
else:
    print("swift_mode OFF")
    df_all = spark.read.table(mergedGlobalMrnTableName).select(selectedCols)
    df_all = df_all.where((df_all.dob_valid == 1) & \
                          (df_all.fn_valid == 1) & \
                          (df_all.ln_valid == 1) & \
                          (df_all.gender_valid == 1)
                          )
    left = df_all.alias('left')
    right = df_all.alias('right')

# COMMAND ----------

selectCols = ["left." + s for s in left.schema.names] + ["right." + s for s in right.schema.names]
newCols = [s.replace('.', '_') for s in selectCols]
joinExpr = (left.gender == right.gender) & (left.globalmrnifk != right.globalmrnifk)
df2 = left.join(right, joinExpr).select(selectCols).toDF(*newCols)
df2 = df2.where((df2.left_ssn_valid == 0) | (df2.right_ssn_valid == 0))

# COMMAND ----------

whereExprs = {
    "sndxln": (df2.left_ln_valid == 1) & (df2.right_ln_valid == 1) & \
              (df2.left_lastname != df2.right_lastname) & \
              ((soundex(df2.left_lastname)) == (soundex(df2.right_lastname))),

    "sndxfn": (df2.left_fn_valid == 1) & (df2.right_fn_valid == 1) & \
              (df2.left_firstname != df2.right_firstname) & \
              ((soundex(df2.left_firstname)) == (soundex(df2.right_firstname))),

    "substrln": (df2.left_ln_valid == 1) & (df2.right_ln_valid == 1) & (contains_udf(df2.left_lastname, df2.right_lastname) == 1),

    "lastname": (df2.left_ln_valid == 1) & (df2.right_ln_valid == 1) & (df2.left_lastname == df2.right_lastname),

    "firstname": (df2.left_fn_valid == 1) & (df2.right_fn_valid == 1) & (df2.left_firstname == df2.right_firstname),

    "hhpermid": (df2.left_hhpermid_valid == 1) & (df2.right_hhpermid_valid == 1) & (comparelist_udf(df2.left_hhpermid, df2.right_hhpermid) == 1),

    "city": (df2.left_city_valid == 1) & (df2.right_city_valid == 1) & (trim(df2.left_city) == trim(df2.right_city)),

    "state": (df2.left_state_valid == 1) & (df2.right_state_valid == 1) & (trim(df2.left_state) == trim(df2.right_state)),

    "dob15": (df2.left_dob_valid == 1) & (df2.right_dob_valid == 1) & (abs(datediff(df2.left_dob, df2.right_dob)) < 5475),

    "dob": (df2.left_dob_valid == 1) & (df2.right_dob_valid == 1) & (trim(df2.left_dob) == trim(df2.right_dob)),

}

# COMMAND ----------

# 25     HMPermId~BadNullSSN~FN~LN~dob~Gender
# 34     HMPermId~BadNullSSN~FN~substrLN~dob~Gender

matchExprs = {

    "25": whereExprs.get("firstname") & whereExprs.get("lastname") & whereExprs.get("dob") & whereExprs.get("hhpermid"),
    "34": whereExprs.get("firstname") & whereExprs.get("substrln") & whereExprs.get("dob") & whereExprs.get("hhpermid")

}

# COMMAND ----------

selectExprGMRNs = ['left_globalmrnifk', 'right_globalmrnifk']

for matchType in matchExprs:
    result = df2.where(matchExprs[matchType]).select(selectExprGMRNs).withColumn("matchtype", lit(matchType))
    result.dropDuplicates().write.mode("overwrite").format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", delimiter="|").save(hdfs_output + "/" + matchType)

# COMMAND ----------

from datetime import datetime
end=datetime.now()
print(end)
delta=end-start
print(delta)
