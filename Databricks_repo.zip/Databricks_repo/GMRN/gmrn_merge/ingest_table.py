# Databricks notebook source
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import *
from datetime import datetime

# COMMAND ----------

start=datetime.now()
print(start)

# COMMAND ----------

dbutils.widgets.remove("tablename")
#dbutils.widgets.remove("opdir")

# COMMAND ----------

# SET parameters#
dbutils.widgets.text("publishdir","")
publishdir= dbutils.widgets.get("publishdir")

dbutils.widgets.text("opdir", "")
opdir= dbutils.widgets.get("opdir")

dbutils.widgets.text("datastagedir", "")
datastagedir= dbutils.widgets.get("datastagedir")

dbutils.widgets.text("tablename", "")
tablename= dbutils.widgets.get("tablename")

dbutils.widgets.text("bc", "")
bc = dbutils.widgets.get("bc")

dbutils.widgets.text("storageaccount","")
storageaccount=dbutils.widgets.get("storageaccount")


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# Creating keyValue Pair Dictionary for GMRN table uniq keys

pUniqKeyDictionary = {

    "globalmrndemographics": "globalmrndemographicsipk",
    "globalmrn": "globalmrnipk",
    "globalmrnxpacct": "globalmrnxpacctipk",
    "globalmrnxhospinsurancecodes": "globalmrnxhospinsurancecodespk",

}

# COMMAND ----------

pUniqKey = pUniqKeyDictionary.get(tablename)
pListUniqJoinCol = pUniqKey.split(",")

print("pListUniqJoinCol : " + str(pListUniqJoinCol))


# COMMAND ----------

# Reading the RAW data from Publish Dir
publishdir = publishdir+'/'+tablename+'/current/*'
df_raw = spark.read.parquet(publishdir)


# COMMAND ----------

# Extracting the Schema from RAW and appending isdeleted to it
pSchemaRaw = df_raw.schema
pLastColumn = [StructField("isdeleted", StringType(), True)]
pSchemaDelta = StructType(df_raw.schema.fields + pLastColumn)


# COMMAND ----------

# using the extracted Schema reading the DELTA (Ins and Del) files

#df_delta_delete = spark.read.format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", delimiter="\x01").schema(pSchemaDelta).load(datastagedir + tablename + "/" + bc + '/*delete*.dat').dropDuplicates()
#df_delta_insert = spark.read.format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", delimiter="\x01").schema(pSchemaDelta).load(datastagedir + tablename + "/" + bc + '/*delta*.dat').dropDuplicates()


# COMMAND ----------

# using the extracted Schema reading the DELTA (Ins and Del) files

df_delta_delete = spark.read.format("csv").options(delimiter="\x01").schema(pSchemaDelta).load(datastagedir + tablename + "/" + bc + '/*delete*.dat').dropDuplicates()
df_delta_insert = spark.read.format("csv").options(delimiter="\x01").schema(pSchemaDelta).load(datastagedir + tablename + "/" + bc + '/*delta*.dat').dropDuplicates()


# COMMAND ----------

# Appending pseudo colunm isdeleted to RAW dataframe
df_raw = df_raw.withColumn("isdeleted", lit(0))


# COMMAND ----------

# left-anti Join RAW DF vs DEL DF
df_raw_post_del = df_raw.join(broadcast(df_delta_delete), pListUniqJoinCol, 'leftanti').select(df_raw['*'])


# COMMAND ----------

# COOKED DF =  RAW(POST_DELETE) UNION DELTA_INS
df_cooked = df_raw_post_del.unionAll(df_delta_insert).drop("isdeleted")


# COMMAND ----------

# Write the COOKED_DF to STAGE dir
df_cooked.repartition(200).write.mode("overwrite").parquet(opdir + "/" + tablename + "/" + bc)