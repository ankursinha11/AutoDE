# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# HDPBCStatus
dbutils.widgets.text("path_conn_file", "")
path_conn_file= dbutils.widgets.get("path_conn_file")

dbutils.widgets.text("tablenamestatus", "")
tablenamestatus= dbutils.widgets.get("tablenamestatus")

dbutils.widgets.text("icddb","")
icddb= dbutils.widgets.get("icddb")

dbutils.widgets.text("bc","")
bc= dbutils.widgets.get("bc")

dbutils.widgets.text("storageaccount","")
storageaccount=dbutils.widgets.get("storageaccount")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

status_data = [Row(hdpprocess='GlobalMRN', breadcrumb = bc)]

# COMMAND ----------

status=spark.createDataFrame(status_data)\
    .withColumn("hdpinsertdt", date_format(current_timestamp(),"yyyy-MM-dd HH:mm:ss.SSS"))

# COMMAND ----------

status.write.format('jdbc').mode('append').option('driver', 'com.microsoft.sqlserver.jdbc.SQLServerDriver').option \
        ('url', path_conn_file).option('dbtable', icddb+tablenamestatus).save()