# Databricks notebook source
from datetime import datetime
from pyspark.sql.functions import *

# COMMAND ----------

start=datetime.now()
print(start)

# COMMAND ----------

dbutils.widgets.text("hdfs_match_output", "")
hdfs_output = dbutils.widgets.get("hdfs_match_output")

dbutils.widgets.text("hdfs_temp_path", "")
hdfs_temp_path = dbutils.widgets.get("hdfs_temp_path")

dbutils.widgets.text("swift_mode", "")
swift_mode = dbutils.widgets.get("swift_mode")

dbutils.widgets.text("storageaccount","")
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text("stagedPatientacctsTableName","")
stagedPatientacctsTableName = dbutils.widgets.get("stagedPatientacctsTableName")

dbutils.widgets.text("stagedGlobalmrndemographicsTableName","")
stagedGlobalmrndemographicsTableName = dbutils.widgets.get("stagedGlobalmrndemographicsTableName")

dbutils.widgets.text("mergedGlobalMrnTableName","")
mergedGlobalMrnTableName = dbutils.widgets.get("mergedGlobalMrnTableName")

# COMMAND ----------

# bc = "20250522T06"
# base_url = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data"
# hdfs_output = f"{base_url}/gmrn/staging/matches/merge/{bc}"
# hdfs_temp_path = f"{base_url}/gmrn/staging/gmrn_ssn/"
# swift_mode = "0"
# stagedPatientacctsTableName = f"regular_staged_patientaccts_{bc}"
# stagedGlobalmrndemographicsTableName = f"regular_staged_globalmrndemographics_{bc}"
# mergedGlobalMrnTableName = f"merged_global_mrn_{bc}"
# storageaccount = "prodicdstgdls"

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/tu_data_quality"

# COMMAND ----------

# MAGIC %run "/Insleads-code/GMRN/gmrn_merge/match_util"

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.skewJoin.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "auto")
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

selectedCols = ["globalmrnifk","firstname","dob","lastname","gender","phone","city","state","zip","addrnum","medicalrecnum","ssn","policyid","fn_valid","dob_valid","ln_valid","gender_valid","phone_valid","city_valid","state_valid","zip_valid","addrnum_valid","mrn_valid","ssn_valid","policyid_valid"]

# COMMAND ----------

if int(swift_mode)==1:
  df_pa = spark.read.table(stagedPatientacctsTableName).select(selectedCols)
  df_gd = spark.read.table(stagedGlobalmrndemographicsTableName).select(selectedCols)

  df_pa_2 = df_pa.where((df_pa.ssn_valid == 1) & (df_pa.fn_valid == 1))
  df_gd_2 = df_gd.where((df_gd.ssn_valid == 1) & (df_gd.fn_valid == 1))

  left = df_pa_2.alias('left')
  right= df_gd_2.alias('right')
else:
  df_all = spark.read.table(mergedGlobalMrnTableName).select(selectedCols)
  df_all = df_all.where((df_all.ssn_valid == 1) & (df_all.fn_valid == 1))

  left = df_all.alias('left')
  right= df_all.alias('right')


# COMMAND ----------

selectCols =  [ "left." + s for s in left.schema.names] +\
              [ "right." + s for s in right.schema.names]

newCols = [s.replace('.', '_') for s in selectCols]

# COMMAND ----------

joinExpr = (left.ssn == right.ssn)  & (left.firstname == right.firstname) & (left.globalmrnifk!=right.globalmrnifk) 
df = left.join(right,joinExpr,"inner").select(selectCols).toDF(*newCols)
df.dropDuplicates().write.mode("overwrite").format("parquet").save(hdfs_temp_path)

# COMMAND ----------

df = spark.read.parquet(hdfs_temp_path)

# COMMAND ----------

whereExprs = {
        "ssn":(df.left_ssn_valid == 1) & (df.right_ssn_valid == 1) & (trim(df.left_ssn) == trim(df.right_ssn)),
        "dob15":(df.left_dob_valid == 1) & (df.right_dob_valid == 1) & (abs(datediff(df.left_dob,df.right_dob))<5475),
        "dob":(df.left_dob_valid == 1) & (df.right_dob_valid == 1) &  (trim(df.left_dob) == trim(df.right_dob)),
        "lastname":(df.left_ln_valid == 1) & (df.right_ln_valid == 1)  & (trim(df.left_lastname) == trim(df.right_lastname)),
        "substrlastname":(df.left_ln_valid == 1) & (df.right_ln_valid == 1) & (contains_udf(df.left_lastname,df.right_lastname) == 1),
        "swappedlastname":(df.left_fn_valid == 1) & (df.right_ln_valid == 1)  & (trim(df.left_firstname) == trim(df.right_lastname)),
        "swappedfirstname":(df.left_ln_valid == 1) & (df.right_fn_valid == 1)  & (trim(df.left_lastname) == trim(df.right_firstname)),
        "phone":(df.left_phone_valid == 1) & (df.right_phone_valid == 1) & (trim(df.left_phone) == trim(df.right_phone)),
        "medicalrecnum":(df.left_mrn_valid == 1) & (df.right_mrn_valid == 1) &  (comparelist_udf(df.left_medicalrecnum,df.right_medicalrecnum) == 1),
        "city":(df.left_city_valid == 1) & (df.right_city_valid == 1) & (trim(df.left_city) == trim(df.right_city)),
        "state":(df.left_state_valid == 1) & (df.right_state_valid == 1) & (trim(df.left_state) == trim(df.right_state)),
        "zip":(df.left_zip_valid == 1) & (df.right_zip_valid == 1) & (trim(df.left_zip) == trim(df.right_zip)),
        "gender":(df.left_gender_valid == 1) & (df.right_gender_valid == 1) & (trim(df.left_gender) == trim(df.right_gender)),
        "addrnum":(df.left_addrnum_valid == 1) & (df.right_addrnum_valid == 1) & (df.left_zip_valid == 1) & (df.right_zip_valid == 1) & (trim(df.left_zip) == trim(df.right_zip)) & (address_udf(trim(df.left_addrnum),trim(df.right_addrnum)) == 1),
        "badnullssn":((df.left_ssn_valid == 0) | (df.right_ssn_valid == 0)),
        "soundexfn":(df.left_fn_valid ==1) & (df.right_fn_valid == 1) & (trim(df.left_firstname)!=trim(df.right_firstname)) &  (soundex(trim(df.left_firstname))==soundex(trim(df.right_firstname))),
		 "policyid" : (df.left_policyid_valid==1) & (df.right_policyid_valid ==1) & (comparelist_udf(df.left_policyid,df.right_policyid) == 1)
     }

matchExprs = {
    # 2     SSN~FN~SUBSTRLN~DOB~CityAndState~Gender
    "2":whereExprs.get("dob") & whereExprs.get("city") & whereExprs.get("state") & whereExprs.get("gender")  & whereExprs.get("substrlastname"),
    # 5     SSN~FN~SUBSTRLN~DOB~Gender~Phone
    "5":whereExprs.get("dob") & whereExprs.get("gender") &  whereExprs.get("phone") & whereExprs.get("substrlastname"),
    # 12    SSN~FN~SUBSTRLN~DOB15~CityAndState~Gender
    "12":whereExprs.get("city") & whereExprs.get("state") & whereExprs.get("gender") &  whereExprs.get("substrlastname") & whereExprs.get("dob15"),
    # 19    SSN~FN~LN~DOB~Gender
    "19":whereExprs.get("dob")  & whereExprs.get("lastname") & whereExprs.get("gender"),
    # 22    SSN~FN~DOB~CityAndState~AddrNum
    "22":whereExprs.get("dob") & whereExprs.get("city") & whereExprs.get("state") & whereExprs.get("addrnum"),
    # 23    SSN~FN~LN~DOB~Phone
    "23":whereExprs.get("lastname") & whereExprs.get("dob") & whereExprs.get("phone"),
    # 24    SSN~FN~DOB~CityAndState~MRN
    "24":whereExprs.get("dob") & whereExprs.get("city") & whereExprs.get("state") & whereExprs.get("medicalrecnum"),
    # 33    SSN~FN~DOB15~CityAndState~Phone
    "33":whereExprs.get("city") & whereExprs.get("state") & whereExprs.get("phone") & whereExprs.get("dob15"),
    # 35    SSN~FN~SUBSTRLN~DOB15~MRN
    "35":whereExprs.get("medicalrecnum") & whereExprs.get("dob15") &  whereExprs.get("substrlastname"),
    # 41    SSN~FN~DOB~Phone
    "41":whereExprs.get("dob") &  whereExprs.get("phone"),
    # 42    SSN~FN~DOB~Zip
    "42":whereExprs.get("dob") &  whereExprs.get("zip")   ,
    # 47    SSN~FN~DOB15~AddrNum
    "47":whereExprs.get("addrnum") & whereExprs.get("dob15"),
	# 30 PolicyId~SSN~FN~LN~DOB
    "30":whereExprs.get("dob")  & whereExprs.get("lastname") & whereExprs.get("policyid"),
    # 36 PolicyId~SSN~FN~SubstringLN~DOB15
    "36": whereExprs.get("substrlastname") & whereExprs.get("dob15") & whereExprs.get("policyid")

}

# COMMAND ----------

selectExprGMRNs = ['left_globalmrnifk','right_globalmrnifk']
for matchType in matchExprs:
   result = df.where(matchExprs[matchType]).select(selectExprGMRNs).withColumn("matchtype", lit(matchType))
   result.dropDuplicates().write.mode("overwrite").format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="|").save(hdfs_output + "/" + matchType)

# COMMAND ----------

joinExpr = (left.ssn == right.ssn)  & (left.globalmrnifk!=right.globalmrnifk)
df2 = left.join(right,joinExpr,"cross").select(selectCols).toDF(*newCols)

# COMMAND ----------

whereExprs2 = {
        "dob":(df2.left_dob_valid == 1) & (df2.right_dob_valid == 1) &  (trim(df2.left_dob) == trim(df2.right_dob)),
        "gender":(df2.left_gender_valid == 1) & (df2.right_gender_valid == 1) & (trim(df2.left_gender) == trim(df2.right_gender)),
        "swappedlastname":(df2.left_fn_valid == 1) & (df2.right_ln_valid == 1)  & (trim(df2.left_firstname) == trim(df2.right_lastname)),
        "swappedfirstname":(df2.left_ln_valid == 1) & (df2.right_fn_valid == 1)  & (trim(df2.left_lastname) == trim(df2.right_firstname)),
        "city":(df2.left_city_valid == 1) & (df2.right_city_valid == 1) & (trim(df2.left_city) == trim(df2.right_city)),
        "state":(df2.left_state_valid == 1) & (df2.right_state_valid == 1) & (trim(df2.left_state) == trim(df2.right_state))
     }

matchExprs2= {
  #18  SSN~SwappedFN~SwappedLN~DOB~CityAndState~Gender - Special consideration
  "18":whereExprs2.get("dob") & whereExprs2.get("city") & whereExprs2.get("state") & whereExprs2.get("gender") & whereExprs2.get("swappedfirstname") & whereExprs2.get("swappedlastname")
}

# COMMAND ----------

for matchType in matchExprs2:
    result = df2.where((matchExprs2[matchType])).select(selectExprGMRNs).withColumn("matchtype", lit(matchType))
    result.dropDuplicates().write.mode("overwrite").format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="|").save(hdfs_output + "/" + matchType)

# COMMAND ----------

from datetime import datetime
end=datetime.now()
print(end)
delta=end-start
print(delta)
exit()
