# Databricks notebook source
dbutils.widgets.text("hdfs_output", "")
hdfs_output = dbutils.widgets.get("hdfs_output")

dbutils.widgets.text("bc","")
bc = dbutils.widgets.get("bc")

dbutils.widgets.text("storageaccount","")
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text("stagedPatientacctsTableName","")
stagedPatientacctsTableName = dbutils.widgets.get("stagedPatientacctsTableName")

dbutils.widgets.text("stagedGlobalmrndemographicsTableName","")
stagedGlobalmrndemographicsTableName = dbutils.widgets.get("stagedGlobalmrndemographicsTableName")

# COMMAND ----------

# bc = "20250522T06"
# base_url = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data"
# hdfs_output = f"{base_url}/gmrn/staging/staged_all/merged_patientaccts_gmrndemo/"
# stagedPatientacctsTableName = f"regular_staged_patientaccts_{bc}"
# stagedGlobalmrndemographicsTableName = f"regular_staged_globalmrndemographics_{bc}"
# storageaccount = "prodicdstgdls"

# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions","auto")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

selectedCols = [
    "globalmrnifk",
    "firstname",
    "dob",
    "lastname",
    "gender",
    "phone",
    "city",
    "state",
    "zip",
    "addrnum",
    "medicaidnum",
    "medicarehic",
    "medicalrecnum",
    "permid",
    "ssn",
    "hhpermid",
    "policyid",
    "fn_valid",
    "dob_valid",
    "ln_valid",
    "gender_valid",
    "phone_valid",
    "city_valid",
    "state_valid",
    "zip_valid",
    "addrnum_valid",
    "mrn_valid",
    "ssn_valid",
    "hhpermid_valid",
    "policyid_valid",
    "mcr_valid",
    "mcd_valid",
    "pid_valid"
]

# COMMAND ----------

try:
    tableName = f"merged_global_mrn_{bc}"
    dropSql = f"DROP TABLE IF EXISTS {tableName}"
    cluterBySql = f"ALTER TABLE {tableName} CLUSTER BY (state, city, dob, firstname)"
    optimizeSql = f"OPTIMIZE {tableName}"
    spark.sql(dropSql)
    df_pa = spark.read.table(stagedPatientacctsTableName).select(selectedCols)
    df_gd = spark.read.table(stagedGlobalmrndemographicsTableName).select(selectedCols)
    data = df_pa.union(df_gd).dropDuplicates()
    data.write.mode("overwrite").format("delta").option("path", hdfs_output + bc).saveAsTable(tableName)
    spark.sql(cluterBySql)
    spark.sql(optimizeSql)
except Exception as e:
    raise Exception("Error creating a merged table for patient accts & globalmrndemographics: {}".format(e))

# COMMAND ----------

dbutils.notebook.exit({"mergedGlobalMrnTableName": tableName})
