# Databricks notebook source
from datetime import datetime
from pyspark.sql.functions import *

# COMMAND ----------

start=datetime.now()
print(start)

# COMMAND ----------

dbutils.widgets.text("hdfs_match_output", "")
hdfs_output = dbutils.widgets.get("hdfs_match_output")

dbutils.widgets.text("hdfs_temp_path", "")
hdfs_temp_path = dbutils.widgets.get("hdfs_temp_path")

dbutils.widgets.text("swift_mode", "")
swift_mode = dbutils.widgets.get("swift_mode")

dbutils.widgets.text("storageaccount","")
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text("stagedPatientacctsTableName","")
stagedPatientacctsTableName = dbutils.widgets.get("stagedPatientacctsTableName")

dbutils.widgets.text("stagedGlobalmrndemographicsTableName","")
stagedGlobalmrndemographicsTableName = dbutils.widgets.get("stagedGlobalmrndemographicsTableName")

dbutils.widgets.text("mergedGlobalMrnTableName","")
mergedGlobalMrnTableName = dbutils.widgets.get("mergedGlobalMrnTableName")

# COMMAND ----------

# bc = "20250522T06"
# base_url = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data"
# hdfs_output = f"{base_url}/gmrn/staging/matches/merge/{bc}"
# hdfs_temp_path = f"{base_url}/gmrn/staging/gmrn_simssn/"
# swift_mode = "0"
# stagedPatientacctsTableName = f"regular_staged_patientaccts_{bc}"
# stagedGlobalmrndemographicsTableName = f"regular_staged_globalmrndemographics_{bc}"
# mergedGlobalMrnTableName = f"merged_global_mrn_{bc}"
# storageaccount = "prodicdstgdls"

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/tu_data_quality"
# MAGIC

# COMMAND ----------

# MAGIC %run "/Insleads-code/GMRN/gmrn_merge/match_util"
# MAGIC

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.skewJoin.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "auto")
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

selectedCols=["globalmrnifk","firstname","dob","lastname","gender","city","state","medicalrecnum","ssn","hhpermid","policyid","fn_valid","dob_valid","ln_valid","gender_valid","city_valid","state_valid","mrn_valid","ssn_valid","hhpermid_valid","policyid_valid"]

# COMMAND ----------

if int(swift_mode)==1:
  df_pa = spark.read.table(stagedPatientacctsTableName).select(selectedCols)
  df_gd = spark.read.table(stagedGlobalmrndemographicsTableName).select(selectedCols)

  df_pa_2 = df_pa.where((df_pa.fn_valid == 1) & (df_pa.ln_valid == 1) & (df_pa.city_valid == 1) & (df_pa.state_valid == 1) & (df_pa.dob_valid == 1))
  df_gd_2 = df_gd.where((df_gd.fn_valid == 1) & (df_gd.ln_valid == 1) & (df_gd.city_valid == 1) & (df_gd.state_valid == 1) & (df_gd.dob_valid == 1))

  df_pa_2 = df_pa_2.withColumn("ssn",regexp_extract(df_pa_2.ssn,'\d+',0))
  df_gd_2 = df_gd_2.withColumn("ssn",regexp_extract(df_gd_2.ssn,'\d+',0))

  left = df_pa_2.alias('left')
  right= df_gd_2.alias('right')
else:
  df_all = spark.read.table(mergedGlobalMrnTableName).select(selectedCols)
  df_all = df_all.where((df_all.fn_valid == 1) & (df_all.ln_valid == 1) & (df_all.city_valid == 1) & (df_all.state_valid == 1) & (df_all.dob_valid == 1))
  df_all = df_all.withColumn("ssn",regexp_extract(df_all.ssn,'\d+',0))

  left = df_all.alias('left')
  right= df_all.alias('right')

# COMMAND ----------

selectCols =  [ "left." + s for s in left.schema.names] +\
              [ "right." + s for s in right.schema.names]

newCols = [s.replace('.', '_') for s in selectCols]

#Get dataframe based on join criteria and where expression
joinExpr = (left.dob == right.dob) & (left.lastname == right.lastname) & (left.globalmrnifk != right.globalmrnifk)

if int(swift_mode)==1:
  e=broadcast(left)
  df = right.join(broadcast(e),joinExpr).select(selectCols).toDF(*newCols)
else:
  df = left.join(right, joinExpr,"inner").select(selectCols).toDF(*newCols)

df = df.filter(((df.left_ssn_valid==1) & (df.right_ssn_valid==1)))
df = df.withColumn("leven_dist",levenshtein(df.left_ssn,df.right_ssn)).withColumn("abs_ssn_diff",abs(regexp_extract(df.left_ssn,'\d+',0)-regexp_extract(df.right_ssn,'\d+',0)))

# COMMAND ----------

df.dropDuplicates().write.mode("overwrite").format("parquet").save(hdfs_temp_path)

# COMMAND ----------

df = spark.read.parquet(hdfs_temp_path)

# COMMAND ----------

whereExprs = {
        "similarssn":(df.left_ssn_valid == 1) & (df.right_ssn_valid == 1) & (df.left_ssn != df.right_ssn) &  ((df.leven_dist==1) | ((df.leven_dist==2) & (df.abs_ssn_diff==9))),
        "medicalrecnum":(df.left_mrn_valid == 1) & (df.right_mrn_valid == 1) &  (comparelist_udf(df.left_medicalrecnum,df.right_medicalrecnum) == 1),
        "gender":(df.left_gender_valid == 1) & (df.right_gender_valid == 1) & (trim(df.left_gender) == trim(df.right_gender)),
        "city":(df.left_city_valid == 1) & (df.right_city_valid == 1) & (trim(df.left_city) == trim(df.right_city)),
        "state":(df.left_state_valid == 1) & (df.right_state_valid == 1) & (trim(df.left_state) == trim(df.right_state)),
        "hhpermid":(df.left_hhpermid_valid == 1) & (df.right_hhpermid_valid == 1) &  (comparelist_udf(df.left_hhpermid,df.right_hhpermid) == 1),
        "firstname":(df.left_fn_valid == 1) & (df.right_fn_valid == 1)  & (df.left_firstname == df.right_firstname),
        "sndxfn":( df.left_fn_valid == 1 ) & (df.right_fn_valid == 1 ) &  ( df.left_firstname != df.right_firstname ) &  ( (soundex(df.left_firstname)) == (soundex(df.right_firstname)) ),
        "policyid":(df.left_policyid_valid == 1) & (df.right_policyid_valid == 1) &  (comparelist_udf(df.left_policyid,df.right_policyid) == 1)
     }

matchExprs = {

    #1 SimSSN~FN~LN~DOB~CityAndState~Gender
    "1":whereExprs.get("firstname") & whereExprs.get("gender") & whereExprs.get("city") & whereExprs.get("state"),
    #6 SimSSN~FN~LN~DOB~CityAndState~MRN
    "6":whereExprs.get("firstname") & whereExprs.get("medicalrecnum") & whereExprs.get("city") & whereExprs.get("state"),
    #32 SimSSN~hhpermid~FN~LN~dob
    "32":whereExprs.get("firstname") & whereExprs.get("hhpermid"),
    #17	SimSSN~PolicyId~LN~DOB~City~State~SoundexFN
    "17":whereExprs.get("sndxfn") & whereExprs.get("city") & whereExprs.get("state") &  whereExprs.get("policyid") 
   
}

df=df.where(whereExprs.get("similarssn"))

# COMMAND ----------

selectExprGMRNs = ['left_globalmrnifk', 'right_globalmrnifk']
for matchType in matchExprs:
    result = df.where((matchExprs[matchType])).select(selectExprGMRNs).withColumn("matchtype", lit(matchType))
    result.dropDuplicates().write.mode("overwrite").format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="|").save(hdfs_output + "/" + matchType)

# COMMAND ----------

from datetime import datetime
end=datetime.now()
print(end)
delta=end-start
print(delta)
