# Databricks notebook source
# SET parameters#
dbutils.widgets.text("hdfs_repo_staging", "")
hdfs_repo_staging = dbutils.widgets.get("hdfs_repo_staging")

dbutils.widgets.text("hdfs_repo_publish", "")
hdfs_repo_publish = dbutils.widgets.get("hdfs_repo_publish")

dbutils.widgets.text("tablename", "")
tablename = dbutils.widgets.get("tablename")

dbutils.widgets.text("bc", "")
bc = dbutils.widgets.get("bc")

dbutils.widgets.text("storageaccount", "")
storageaccount = dbutils.widgets.get("storageaccount")

# COMMAND ----------

# bc = "20250522T06"
# base_url = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data"
# hdfs_repo_staging = f"{base_url}/gmrn/staging/sot/prepublish_op/"
# hdfs_repo_publish = f"{base_url}/gmrn/publish/"
# tablename = "globalmrndemographics"
# storageaccount = "prodicdstgdls"

# COMMAND ----------

#mount the storage account#
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))
spark.conf.set("spark.databricks.io.cache.enabled", "true")

# COMMAND ----------

hdfs_repo_staging = str(hdfs_repo_staging + "/" + tablename + "/" + bc+"/")
hdfs_repo_publish = str(hdfs_repo_publish + "/" + tablename + "/")
hdfs_repo_publish_current = str(hdfs_repo_publish + "/current/")
hdfs_repo_publish_archives = str(hdfs_repo_publish + "/archive/")

print("tablename " + tablename)
print("bc " + bc)
print("hdfs_repo_staging " + hdfs_repo_staging)
print("hdfs_repo_publish " + hdfs_repo_publish)
print("hdfs_repo_publish_current " + hdfs_repo_publish_current)
print("hdfs_repo_publish_archives " + hdfs_repo_publish_archives)

# COMMAND ----------

staging_bc = bc
print("staging_bc :" + staging_bc)
archive_bc = dbutils.fs.ls(hdfs_repo_publish_archives)
archive_bc = str(archive_bc).split("archive")[1].split(",")[0]
archive_bc = str(archive_bc).replace("'", "").replace("/","")
print("archive_bc :" + archive_bc)
current_bc = dbutils.fs.ls(hdfs_repo_publish_current)
current_bc = str(current_bc).split("current")[1].split(",")[0]
current_bc = str(current_bc).replace("'", "").replace("/","")
print("current_bc :" + current_bc)

# COMMAND ----------

data_staging_count = spark.read.parquet(hdfs_repo_staging).count()
print("data_staging_count : " + str(data_staging_count))

if data_staging_count > 0:
    rw_flag = 1
else:
    rw_flag = 0

print("rw_flag : " + str(rw_flag))

# COMMAND ----------

if rw_flag == 1:
    data_staging = spark.read.parquet(hdfs_repo_staging)
    print("MOVING  : STAGING --> CURRENT")
    print("STAGING : " + hdfs_repo_staging)
    print("CURRENT : " + hdfs_repo_publish_current + "/" + staging_bc)
    data_staging.write.mode("overwrite").parquet(hdfs_repo_publish_current + "/" + staging_bc)
    data_staging.unpersist()
    print("MOVING  : STAGING --> CURRENT : DONE")
    print("                                    ")
    data_current = spark.read.parquet(hdfs_repo_publish_current + "/" + current_bc)
    print("MOVING  : CURRENT --> ARCHIVE")
    print("CURRENT : " + hdfs_repo_publish_current + "/" + current_bc)
    print("ARCHIVE : " + hdfs_repo_publish_archives + "/" + current_bc)
    data_current.write.mode("overwrite").parquet(hdfs_repo_publish_archives + "/" + current_bc)
    data_current.unpersist()
else:
    print("Something went wrong with STAGING data in : " + hdfs_repo_staging)
    exit(1)

# COMMAND ----------

staging_bc = bc
print("staging_bc :" + staging_bc)
archive_bc = dbutils.fs.ls(hdfs_repo_publish_archives)
archive_bc = str(archive_bc).split("archive")[1].split(",")[0]
archive_bc = str(archive_bc).replace("'", "").replace("/", "")
print("archive_bc :" + archive_bc)
current_bc = dbutils.fs.ls(hdfs_repo_publish_current)
current_bc = str(current_bc).split("current")[1].split(",")[0]
current_bc = str(current_bc).replace("'", "").replace("/", "")
print("current_bc :" + current_bc)

if staging_bc == current_bc:
    print("staging_bc == current_bc")
    curr_del_flag = 0
else:
    print("staging_bc <> current_bc")
    curr_del_flag = 1

print("curr_del_flag " + str(curr_del_flag))

if curr_del_flag == 1:
    print("DELETE OLD CURRENT")
    old_hdfs_repo_publish_current = hdfs_repo_publish_current + "/" + current_bc
    print(old_hdfs_repo_publish_current)
    dbutils.fs.rm(old_hdfs_repo_publish_current, True)
else:
    print("NO CURRENT DELETION REQUIRED")

# COMMAND ----------

staging_bc = bc
print("staging_bc :" + staging_bc)
archive_bc = dbutils.fs.ls(hdfs_repo_publish_archives)
archive_bc = str(archive_bc).split("archive")[1].split(",")[0]
archive_bc = str(archive_bc).replace("'", "").replace("/", "")
print("archive_bc :" + archive_bc)
current_bc = dbutils.fs.ls(hdfs_repo_publish_current)
current_bc = str(current_bc).split("current")[1].split(",")[0]
current_bc = str(current_bc).replace("'", "").replace("/", "")
print("current_bc :" + current_bc)


if archive_bc == current_bc:
    print("archive_bc == current_bc")
    arch_del_flag = 0
else:
    print("archive_bc <> current_bc")
    arch_del_flag = 1

print("arch_del_flag " + str(arch_del_flag))

if arch_del_flag == 1:
    print("DELETE OLD ARCHIVE")
    old_hdfs_repo_publish_archives = hdfs_repo_publish_archives + "/" + archive_bc
    print(old_hdfs_repo_publish_archives)
    #dbutils.fs.rm(old_hdfs_repo_publish_archives, True)
else:
    print("NO ARCHIEVE DELETION REQUIRED")

# COMMAND ----------

staging_bc = bc
print("staging_bc :" + staging_bc)
archive_bc = dbutils.fs.ls(hdfs_repo_publish_archives)
archive_bc = str(archive_bc).split("archive")[1].split(",")[0]
archive_bc = str(archive_bc).replace("'", "").replace("/", "")
print("archive_bc :" + archive_bc)
current_bc = dbutils.fs.ls(hdfs_repo_publish_current)
current_bc = str(current_bc).split("current")[1].split(",")[0]
current_bc = str(current_bc).replace("'", "").replace("/", "")
print("current_bc :" + current_bc)
