# Databricks notebook source
from datetime import datetime
from pyspark.sql.functions import *

# COMMAND ----------

start=datetime.now()
print(start)

# COMMAND ----------

dbutils.widgets.text("hdfs_match_output", "")
hdfs_output = dbutils.widgets.get("hdfs_match_output")

dbutils.widgets.text("hdfs_temp_path","")
hdfs_temp_path = dbutils.widgets.get("hdfs_temp_path")

dbutils.widgets.text("swift_mode", "")
swift_mode = dbutils.widgets.get("swift_mode")

dbutils.widgets.text("storageaccount","")
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text("stagedPatientacctsTableName","")
stagedPatientacctsTableName = dbutils.widgets.get("stagedPatientacctsTableName")

dbutils.widgets.text("stagedGlobalmrndemographicsTableName","")
stagedGlobalmrndemographicsTableName = dbutils.widgets.get("stagedGlobalmrndemographicsTableName")

dbutils.widgets.text("mergedGlobalMrnTableName","")
mergedGlobalMrnTableName = dbutils.widgets.get("mergedGlobalMrnTableName")

# COMMAND ----------

# bc = "20250522T06"
# base_url = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data"
# hdfs_output = f"{base_url}/gmrn/staging/matches/merge/{bc}"
# hdfs_temp_path = f"{base_url}/gmrn/staging/gmrn_policy/"
# swift_mode = "0"
# stagedPatientacctsTableName = f"regular_staged_patientaccts_{bc}"
# stagedGlobalmrndemographicsTableName = f"regular_staged_globalmrndemographics_{bc}"
# mergedGlobalMrnTableName = f"merged_global_mrn_{bc}"
# storageaccount = "prodicdstgdls"

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/tu_data_quality"
# MAGIC

# COMMAND ----------

# MAGIC %run "/Insleads-code/GMRN/gmrn_merge/match_util"
# MAGIC

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.skewJoin.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "auto")
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

selectedCols=["globalmrnifk","firstname","dob","lastname","gender","city","state","zip","ssn","policyid","fn_valid","dob_valid","ln_valid","gender_valid","city_valid","state_valid","policyid_valid","ssn_valid","zip_valid"]

# COMMAND ----------

if int(swift_mode)==1:
  df_pa = spark.read.table(stagedPatientacctsTableName).select(selectedCols)
  df_gd = spark.read.table(stagedGlobalmrndemographicsTableName).select(selectedCols)

  df_pa_2 = df_pa.where( (df_pa.policyid_valid == 1) &\
                         (df_pa.dob_valid == 1) &\
                         (df_pa.city_valid == 1) &\
                         (df_pa.state_valid == 1) &\
                         (df_pa.gender_valid == 1)
                     )

  df_gd_2 = df_gd.where( (df_gd.policyid_valid == 1) &\
                         (df_gd.dob_valid == 1) &\
                         (df_gd.city_valid == 1) &\
                         (df_gd.state_valid == 1) &\
                         (df_gd.gender_valid == 1)
                     )

  df_pa_2 = df_pa_2.where(size(df_pa_2.policyid)<600)
  df_gd_2 = df_gd_2.where(size(df_gd_2.policyid)<600)

  left = df_pa_2.alias('left')
  right= df_gd_2.alias('right')
else:
  df_all = spark.read.table(mergedGlobalMrnTableName).select(selectedCols)
  df_all = df_all.where( (df_all.policyid_valid == 1) &\
                         (df_all.dob_valid == 1) &\
                         (df_all.city_valid == 1) &\
                         (df_all.state_valid == 1) &\
                         (df_all.gender_valid == 1)
                     )
  df_all = df_all.where(size(df_all.policyid)<600)

  left = df_all.alias('left')
  right= df_all.alias('right')

# COMMAND ----------

selectCols =  ["left." + s for s in left.schema.names]+["right." + s for s in right.schema.names]
newCols = [s.replace('.', '_') for s in selectCols]

joinExpr = ( left.dob == right.dob ) & \
           ( left.city == right.city ) & \
           ( left.state == right.state ) & \
           ( left.gender == right.gender) & \
           ( left.globalmrnifk!=right.globalmrnifk )

df1 = left.join(right, joinExpr,"inner").select(selectCols).toDF(*newCols)
df1 = df1.where(comparelist_udf(df1.left_policyid,df1.right_policyid)==1)

# COMMAND ----------

df1.dropDuplicates().write.mode("overwrite").format("parquet").save(hdfs_temp_path)

# COMMAND ----------

df1 = spark.read.parquet(hdfs_temp_path)

# COMMAND ----------

whereExprs = {

   "sndxln":( df1.left_ln_valid == 1 ) & (df1.right_ln_valid == 1 ) & \
            ( df1.left_lastname != df1.right_lastname ) & \
            ( (soundex(df1.left_lastname)) == (soundex(df1.right_lastname)) ),

   "sndxfn":( df1.left_fn_valid == 1 ) & (df1.right_fn_valid == 1 ) & \
            ( df1.left_firstname != df1.right_firstname ) & \
            ( (soundex(df1.left_firstname)) == (soundex(df1.right_firstname)) ),

 "substrln":(df1.left_ln_valid == 1) & (df1.right_ln_valid == 1) & (contains_udf(df1.left_lastname,df1.right_lastname) == 1),
 "lastname":(df1.left_ln_valid == 1) & (df1.right_ln_valid == 1)  & (df1.left_lastname == df1.right_lastname),
"firstname":(df1.left_fn_valid == 1) & (df1.right_fn_valid == 1)  & (df1.left_firstname == df1.right_firstname),

 "policyid":(df1.left_policyid_valid == 1) & (df1.right_policyid_valid == 1) & (comparelist_udf(df1.left_policyid,df1.right_policyid)==1)
}
#13 PolicyId~LN~DOB~City~State~Gender~SoundexFN
#14 PolicyId~FN~DOB~City~State~Gender~SubstringLN
#15 PolicyId~FN~DOB~City~State~Gender~SoundexLN


matchExprs = {
  "13": whereExprs.get("sndxfn") & whereExprs.get("lastname") ,#& whereExprs.get("policyid") ,
  "14": whereExprs.get("firstname") & whereExprs.get("substrln"),
  "15": whereExprs.get("sndxln") & whereExprs.get("firstname") #& whereExprs.get("policyid")
}

# COMMAND ----------

selectExprGMRNs = ['left_globalmrnifk', 'right_globalmrnifk']

for matchType in matchExprs:
  result = df1.where(matchExprs[matchType]).select(selectExprGMRNs).withColumn("matchtype", lit(matchType)) 
  result.dropDuplicates().write.mode("overwrite").format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="|").save(hdfs_output + "/" +  matchType)

# COMMAND ----------

from datetime import datetime
end=datetime.now()
print(end)
delta=end-start
print(delta)
