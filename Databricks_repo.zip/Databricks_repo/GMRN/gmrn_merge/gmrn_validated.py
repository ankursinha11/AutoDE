# Databricks notebook source
from pyspark.sql.functions import *
import datetime
from pyspark.sql.window import Window

# COMMAND ----------

datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]

# COMMAND ----------

dbutils.widgets.text("hdfs_data_input","")
hdfs_data_input = dbutils.widgets.get("hdfs_data_input")

dbutils.widgets.text("hdfs_gmrn_publish","")
hdfs_gmrn_publish = dbutils.widgets.get("hdfs_gmrn_publish")

dbutils.widgets.text("hdfs_output", "")
hdfs_output = dbutils.widgets.get("hdfs_output")

dbutils.widgets.text("hdfs_permid_input", "")
hdfs_permid_input = dbutils.widgets.get("hdfs_permid_input")

dbutils.widgets.text("hdfs_output_path", "")
hdfs_output_path = dbutils.widgets.get("hdfs_output_path")

dbutils.widgets.text("bc", "")
bc = dbutils.widgets.get("bc")

dbutils.widgets.text("storageaccount","")
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text("workflowtype","")
workflowtype = dbutils.widgets.get("workflowtype")

# COMMAND ----------

# bc = "20250522T06"
# base_url = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data"
# hdfs_data_input = f"{base_url}/dataingestion/publish/"
# hdfs_gmrn_publish = f"{base_url}/gmrn/publish/"
# hdfs_output = f"{base_url}/gmrn/staging/staged_all/staged_globalmrndemographics/"
# hdfs_permid_input = f"{base_url}/cdd/publish/permidpatientacctid/"
# hdfs_output_path = f"{base_url}/gmrn/staging/scratch/globalmrn/"
# storageaccount = "prodicdstgdls"
# workflowtype = "regular"

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/tu_data_quality"

# COMMAND ----------

spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)
spark.conf.set("spark.sql.shuffle.partitions","auto")
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

hdfs_output_path = hdfs_output_path  + bc + "/"
# Policy ID List generation
policyid = spark \
    .read.parquet(hdfs_gmrn_publish + "/globalmrnxhospinsurancecodes/current" + "/*") \
    .select("globalmrnifk", "inspolicyid")

# COMMAND ----------

for column in policyid.columns:
    policyid = policyid.withColumn(column, regexp_replace(col(column), r'[^\x00-\x7f]', r''))
    policyid = policyid.withColumn(column, trim(col(column)))

# COMMAND ----------

policyid = policyid.withColumn('inspolicyid', regexp_replace(policyid.inspolicyid, '[^A-Za-z0-9]', ''))

# COMMAND ----------

isValidPolicy_udf = udf(isValidPolicy, IntegerType())

# COMMAND ----------

policyid = policyid \
    .withColumn('policyid_valid', isValidPolicy_udf(policyid.inspolicyid))

# COMMAND ----------

policyid = policyid.filter(~policyid.inspolicyid.like("%000000"))

# COMMAND ----------

policyid = policyid \
    .dropDuplicates() \
    .filter(policyid.policyid_valid == 1)

# COMMAND ----------

policyidlist = policyid.groupBy("globalmrnifk") \
    .agg(collect_set("inspolicyid") \
         .alias("policyid"))

# COMMAND ----------

policyidlist.createOrReplaceTempView("policyidlist")

# COMMAND ----------

#already reading in gmrndemo_update so recurring step
gdemo = spark.read.parquet(hdfs_gmrn_publish + "/globalmrndemographics/current"+"/*")

# COMMAND ----------

gdemo = gdemo.filter(gdemo.ignoreflag != '1')

# COMMAND ----------

#repetative step from gmrndemo_update
for column in gdemo.columns:
    gdemo = gdemo.withColumn(column, regexp_replace(col(column), r'[^\x00-\x7f]', r''))
    gdemo = gdemo.withColumn(column, trim(col(column)))

# COMMAND ----------

pa = spark.read.format("delta").load(hdfs_data_input + "/patientaccts/current/20991231/").select('patientacctipk', 'hospitalfk', 'medicalrecnum')

# COMMAND ----------

#repetative step from gmrndemo_update
gmrnxpa = spark.read.parquet(hdfs_gmrn_publish + "/globalmrnxpacct/current" + "/*") \
    .select('globalmrnifk', 'patientacctifk', 'hospitalfk')

# COMMAND ----------

mrnlist = pa.join(gmrnxpa, (pa.patientacctipk == gmrnxpa.patientacctifk) & (pa.hospitalfk == gmrnxpa.hospitalfk ), "inner") \
    .select(gmrnxpa.globalmrnifk, pa.patientacctipk, pa.hospitalfk, pa.medicalrecnum)

# COMMAND ----------

isValidMRN_udf = udf(isValidMRN, IntegerType())

# COMMAND ----------

mrnlist = mrnlist.withColumn('mrn_valid', isValidMRN_udf(mrnlist.medicalrecnum))
mrnlist = mrnlist.dropDuplicates().filter(mrnlist.mrn_valid == 1)
mrnlist = mrnlist \
    .select("globalmrnifk", concat_ws('~', mrnlist.hospitalfk, mrnlist.medicalrecnum) \
            .alias("mrn_ids"))
mrnlist = mrnlist.groupBy("globalmrnifk").agg(collect_set("mrn_ids").alias("mrnlist"))

# COMMAND ----------

mrnlist.createOrReplaceTempView("gmrnxmrnlist")

# COMMAND ----------

permid = spark.read.option("recursiveFileLookup","true").parquet(hdfs_permid_input)

# COMMAND ----------

hh = permid.filter((permid.matchind == 'HM') | (permid.matchind == 'IM')) \
    .select('permid', 'magnetpermid').dropDuplicates()
hh = hh.groupBy("permid").agg(collect_set("magnetpermid").alias("hhlist"))
permid = permid.filter(permid.matchind == 'IM') \
    .select('patientacctifk', 'hospitalfk', 'permid')

# COMMAND ----------

hh.createOrReplaceTempView("hhview")

# COMMAND ----------

gmrnxpa.createOrReplaceTempView("globalmrnxpacct")
permid.createOrReplaceTempView("patientacctxpermid")
pa.createOrReplaceTempView("patientaccts")

# COMMAND ----------

globalSQL = """
SELECT  DISTINCT g.globalmrnifk,  pp.permid
FROM globalmrnxpacct g
LEFT JOIN patientacctxpermid pp ON g.patientacctifk = pp.patientacctifk AND g.hospitalfk = pp.hospitalfk
"""

# COMMAND ----------

df1 = spark.sql(globalSQL)

# COMMAND ----------

df1.write.mode("overwrite").parquet(hdfs_output_path + "globalsql/")

# COMMAND ----------

df1_read = spark.read.parquet(hdfs_output_path + "globalsql/")

# COMMAND ----------

df1_read.createOrReplaceTempView("permid")

# COMMAND ----------

SQL2 = """
SELECT p.globalmrnifk,  p.permid, hv.hhlist
FROM permid p
LEFT JOIN hhview hv ON hv.permid=p.permid
"""

# COMMAND ----------

df2 = spark.sql(SQL2)

# COMMAND ----------

df2.write.mode("overwrite").parquet(hdfs_output_path + "permidsql/")


# COMMAND ----------

df2_read = spark.read.parquet(hdfs_output_path + "permidsql/")

# COMMAND ----------

df2_read.createOrReplaceTempView("permid2")

# COMMAND ----------

gdemo.createOrReplaceTempView("globalmrndemographics")

# COMMAND ----------

joinSQL = """
SELECT
  g.globalmrnifk,
  g.firstname as firstname,
  g.lastname as lastname,
  g.dob as dob,
  g.ssn as ssn,
  g.gender as gender,
  g.addr1 as addrnum,
  g.city as city,
  g.state as state,
  g.zip as zip,
  g.phone1 as phone,
  g.medicaidnum as medicaidnum,
  g.medicarehic as medicarehic,
  mlist.mrnlist as medicalrecnum,
  gpa.hhlist as hhpermid,
  policyidlist.policyid as policyid,
  gpa.permid
FROM permid2 gpa
INNER JOIN globalmrndemographics g ON g.globalmrnifk=gpa.globalmrnifk
LEFT JOIN gmrnxmrnlist mlist ON mlist.globalmrnifk=gpa.globalmrnifk
LEFT JOIN policyidlist ON policyidlist.globalmrnifk=gpa.globalmrnifk
"""

# COMMAND ----------

pd_tmp = spark.sql(joinSQL)

# COMMAND ----------

pd_tmp.dropDuplicates().write.mode("overwrite").parquet(hdfs_output_path + "gdemoall/")

# COMMAND ----------

pd = spark.read.parquet(hdfs_output_path + "gdemoall/")

# COMMAND ----------

# Trim and remove non printable characters
for column in pd.columns:
    if (column != "medicalrecnum" and column != "policyid" and column != "hhpermid"):
        pd = pd.withColumn(column, regexp_replace(col(column), r'[^\x00-\x7f]', r''))
        pd = pd.withColumn(column, trim(col(column)))

# COMMAND ----------

# MAGIC %md 
# MAGIC Create validation UDF functions

# COMMAND ----------

isValidName_udf = udf(isValidName, IntegerType())
isValidDOB_udf = udf(isValidDOB, IntegerType())
isValidSSN_udf = udf(isValidSSN, IntegerType())
isValidGender_udf = udf(isValidGender, IntegerType())
isValidCity_udf = udf(isValidCity, IntegerType())
isValidState_udf = udf(isValidState, IntegerType())
isValidZip_udf = udf(isValidZip, IntegerType())
isValidPhone_udf = udf(isValidPhone, IntegerType())
isValidString_udf = udf(isValidString, IntegerType())
isValidMCD_udf = udf(isValidMCD, IntegerType())
isValidMCR_udf = udf(isValidMCR, IntegerType())
isValidPID_udf = udf(isValidPID, IntegerType())
isValidNumber_udf = udf(isNumber, IntegerType())

# COMMAND ----------

# MAGIC %md
# MAGIC cleanse and trim

# COMMAND ----------

pd = pd.withColumn('firstname', upper(pd.firstname))
pd = pd.withColumn('lastname', upper(pd.lastname))
pd = pd.withColumn('gender', upper(pd.gender))
pd = pd.withColumn('city', upper(pd.city))
pd = pd.withColumn('state', upper(pd.state))

# COMMAND ----------

# MAGIC %md
# MAGIC add validation columns

# COMMAND ----------

pd = pd.withColumn('addrnum', regexp_extract(pd.addrnum, '\d+', 0))
pd = pd.withColumn('zip', regexp_extract(pd.zip, '\d\d\d\d\d', 0))
pd = pd.withColumn('phone', regexp_replace(pd.phone, '[^0-9]', ''))
pd = pd.withColumn('dob', regexp_extract(pd.dob, '\d+-\d+-\d+', 0))
pd = pd.withColumn('city', regexp_replace(pd.city, '[^A-Za-z\s]', ''))
pd = pd.withColumn('city', regexp_replace(pd.city, 'XX', ''))
pd = pd.withColumn('city', regexp_replace(pd.city, 'YY', ''))
pd = pd.withColumn('city', trim(pd.city))
pd = pd.withColumn('state', regexp_replace(pd.state, 'XX', ''))
pd = pd.withColumn('state', regexp_replace(pd.state, 'YY', ''))
pd = pd.withColumn('state', regexp_replace(pd.state, '[^A-Za-z\s]', ''))
pd = pd.withColumn('state', trim(pd.state))

# COMMAND ----------

pd = pd.withColumn('fn_valid', isValidName_udf(pd.firstname))
pd = pd.withColumn('ln_valid', isValidName_udf(pd.lastname))
pd = pd.withColumn('dob_valid', isValidDOB_udf(pd.dob))
pd = pd.withColumn('gender_valid', isValidGender_udf(pd.gender))
pd = pd.withColumn('ssn_valid', isValidSSN_udf(pd.ssn))
pd = pd.withColumn('city_valid', isValidCity_udf(pd.city))
pd = pd.withColumn('state_valid', isValidState_udf(pd.state))
pd = pd.withColumn('zip_valid', isValidZip_udf(pd.zip))
pd = pd.withColumn('phone_valid', isValidPhone_udf(pd.phone))

# COMMAND ----------

new_mrn_valid = when(col("medicalrecnum").isNull(), 0).otherwise(1)
pd = pd.withColumn('mrn_valid', new_mrn_valid)

# COMMAND ----------

new_policy_valid = when(col("policyid").isNull(), 0).otherwise(1)
pd = pd.withColumn('policyid_valid', new_policy_valid)

# COMMAND ----------

new_hh_valid = when(col("hhpermid").isNull(), 0).otherwise(1)
pd = pd.withColumn('hhpermid_valid', new_hh_valid)

# COMMAND ----------

pd = pd.withColumn('mcr_valid', isValidMCR_udf(pd.medicarehic))
pd = pd.withColumn('mcd_valid', isValidMCD_udf(pd.medicaidnum))
pd = pd.withColumn('pid_valid', isValidPID_udf(pd.permid))
pd = pd.withColumn('addrnum_valid', isValidNumber_udf(pd.addrnum))

# COMMAND ----------

# DBTITLE 1,Write staged globalmrndemographics data to delta table
tableName = f"{workflowtype}_staged_globalmrndemographics_{bc}"
dropSql = f"DROP TABLE IF EXISTS {tableName}"
spark.sql(dropSql)
pd.dropDuplicates().write.mode("overwrite").format("delta").option("path", hdfs_output + bc).saveAsTable(tableName)
if workflowtype == 'aid':
    cluterBySql = f"ALTER TABLE {tableName} CLUSTER BY (state, city, dob, firstname)"
    optimizeSql = f"OPTIMIZE {tableName}"
    spark.sql(cluterBySql)
    spark.sql(optimizeSql)

# COMMAND ----------

datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]

# COMMAND ----------

dbutils.notebook.exit({"stagedGlobalmrndemographicsTableName": tableName})
