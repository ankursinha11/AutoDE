# Databricks notebook source
# MAGIC %scala
# MAGIC import org.apache.spark.graphx.GraphLoader
# MAGIC import org.apache.spark.sql.SparkSession

# COMMAND ----------


dbutils.widgets.text("bc","")
bc = dbutils.widgets.get("bc")

dbutils.widgets.text("edges_input","")
edges_input = dbutils.widgets.get("edges_input")

dbutils.widgets.text("storageaccount","")
storageaccount = dbutils.widgets.get("storageaccount")

# COMMAND ----------

# MAGIC %scala
# MAGIC dbutils.widgets.text("connections_output","")
# MAGIC var connections_output= dbutils.widgets.get("connections_output")

# COMMAND ----------

# bc = "20250522T06"
# base_url = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data"
# edges_input = f"{base_url}/gmrn/publish/graphx/{bc}/edges/"
# storageaccount = "prodicdstgdls"

# COMMAND ----------

# %scala
# var connections_output = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data/gmrn/publish/graphx/20250522T06/connections/"

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

def get_csv_file(directory_path):
    try:
        files_to_treat = dbutils.fs.ls(directory_path)
        for filename in files_to_treat:
            path = filename.path
            name = filename.name
            if name.startswith("part"):
                return path
    except Exception as e:
        print("Exception occurred in move_data notebook and get_csv_file function failure error message:")
        print(e)
        raise

# COMMAND ----------

edges_input=get_csv_file(edges_input)
edges_output="/FileStore/tables/gmrn_connections/edges1.csv"

# COMMAND ----------

dbutils.fs.cp(edges_input,edges_output,True)

# COMMAND ----------

# MAGIC %scala
# MAGIC
# MAGIC val input = "/FileStore/tables/gmrn_connections/edges1.csv"
# MAGIC import spark.implicits._
# MAGIC val graph = GraphLoader.edgeListFile(spark.sparkContext, input)

# COMMAND ----------

# MAGIC %scala
# MAGIC // val output = "abfss://npp@divyaprodstorageact1.dfs.core.windows.net/gmrn_edges_connections/gmrn_edges_connections/gmrn_edges_connections/cloud_connections"
# MAGIC val cc = graph.connectedComponents().vertices
# MAGIC val cc1 = spark.createDataFrame(cc).toDF("fromglobalmrn", "toglobalmrn").repartition(1)
# MAGIC cc1.write.mode("overwrite").format("parquet").save(s"$connections_output")
