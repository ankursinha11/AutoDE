# Databricks notebook source
from datetime import datetime
from dateutil.relativedelta import relativedelta
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

start=datetime.now()
print(start)

# COMMAND ----------

dbutils.widgets.text("hdfs_merge_input", "")
hdfs_merge_input = dbutils.widgets.get("hdfs_merge_input")

dbutils.widgets.text("hdfs_graph_output","")
hdfs_graph_output = dbutils.widgets.get("hdfs_graph_output")

dbutils.widgets.text("storageaccount","")
storageaccount = dbutils.widgets.get("storageaccount")

# COMMAND ----------

# bc = "20250522T06"
# base_url = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data"
# hdfs_merge_input = f"{base_url}/gmrn/staging/matches/merge/{bc}"
# hdfs_graph_output = f"{base_url}/gmrn/publish/graphx/{bc}"
# storageaccount = "prodicdstgdls"

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

hdfs_graph_output_vertices = hdfs_graph_output+"/vertices/"
hdfs_graph_output_edges =  hdfs_graph_output+"/edges/"

# COMMAND ----------

# This pyspark script runs through list of matches and produces vertices and edges with hash of pid and cid for graph connections
schema = StructType([
    StructField("pid", StringType()),
    StructField("cid", StringType()),
    StructField("mt",  IntegerType())
  ])

# COMMAND ----------

merge = spark.read.format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="|").schema(schema).load(hdfs_merge_input+"/*/*")

# COMMAND ----------

merge_pid = merge.select("pid")
merge_cid = merge.select(merge.cid.alias("pid"))
merge_flat = merge_pid.union(merge_cid).dropDuplicates()
list_union = merge_flat.withColumn("inc_id",monotonically_increasing_id()).select("inc_id","pid")

# hdfs_graph_output_vertices = hdfs_graph_output+"vertices/"

list_union.repartition(1).write.mode("overwrite").format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter=" ").save(hdfs_graph_output_vertices)

# COMMAND ----------

#load schema and the vertices using the schema
vschema = StructType([
    StructField("inc_id", StringType()),
    StructField("pid", StringType())
  ])

# COMMAND ----------

vertices = spark.read.format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter=" ").schema(vschema).load(hdfs_graph_output_vertices)

cdf = merge.groupBy("pid","cid").agg(min("mt").alias("mt"))
join_key = [ cdf.pid == vertices.pid ]
pp = cdf.join(vertices,join_key,'inner').select(cdf.pid,cdf.cid,vertices.inc_id.alias("pid_new"))

vertices.createOrReplaceTempView("tbl1")
pp.createOrReplaceTempView("tbl2")

pid_cid = spark.sql("select t2.pid, t2.cid, t2.pid_new as pid_hash, t1.inc_id as cid_hash \
                     from tbl1 t1 \
                     join tbl2 t2 \
                     on t1.pid=t2.cid")


graph_edges = pid_cid.select("pid_hash","cid_hash")
graph_edges.repartition(1).write.mode("overwrite").format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter=" ").save(hdfs_graph_output_edges)

# COMMAND ----------

from datetime import datetime
end=datetime.now()
print(end)
delta=end-start
print(delta)
