# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

dbutils.widgets.text("tablenamededup","")
tablenamededup=dbutils.widgets.get("tablenamededup")

dbutils.widgets.text("path_conn_file", "")
path_conn_file= dbutils.widgets.get("path_conn_file")

dbutils.widgets.text("sqoop_output_path_dedup","")
sqoop_output_path_dedup= dbutils.widgets.get("sqoop_output_path_dedup")

dbutils.widgets.text("icddb","")
icddb= dbutils.widgets.get("icddb")

dbutils.widgets.text("bc","")
bc= dbutils.widgets.get("bc")

dbutils.widgets.text("storageaccount","")
storageaccount=dbutils.widgets.get("storageaccount")

# COMMAND ----------

# tablenamededup = "GMRNDedupeStaging"
# path_conn_file = ""
# sqoop_output_path_dedup = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data/gmrn/publish/mergedecisions/"
# icddb = "zescantemp.dbo."
# bc = "20240829T06"
# storageaccount = "prodicdstgdls"

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

dedup_schema = StructType([
    StructField("ToGlobalMRNIFK", LongType(), True),
    StructField("FromGlobalMRNIFK", LongType(), True),
    StructField("MatchType", IntegerType(), True)   
    ])

# COMMAND ----------

dedup = spark.read.option("header",False).option("recursiveFileLookup","true").schema(dedup_schema).options(delimiter="|").format("csv").load(sqoop_output_path_dedup+"/"+bc+"/merge/")
dedup = dedup.withColumn("CreateDate", current_timestamp())
dedup = dedup.select("ToGlobalMRNIFK","FromGlobalMRNIFK","CreateDate","MatchType")

# COMMAND ----------

dedup.write.format('jdbc').mode('append').option('driver', 'com.microsoft.sqlserver.jdbc.SQLServerDriver').option \
        ('url', path_conn_file).option('dbtable', icddb+tablenamededup).save()
