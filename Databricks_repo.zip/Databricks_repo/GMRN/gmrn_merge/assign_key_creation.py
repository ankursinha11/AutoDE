# Databricks notebook source
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql.window import Window
from datetime import datetime

# COMMAND ----------

# start=datetime.now()
# print(start)

# COMMAND ----------

# SET parameters#
dbutils.widgets.text("hdfs_gmrn_publish" , "")
hdfs_gmrn_publish = dbutils.widgets.get("hdfs_gmrn_publish")

dbutils.widgets.text("hdfs_input" , "")
hdfs_input = dbutils.widgets.get("hdfs_input")

dbutils.widgets.text("hdfs_intmd_tmp_key_path" , "")
hdfs_intmd_tmp_key_path = dbutils.widgets.get("hdfs_intmd_tmp_key_path")

dbutils.widgets.text("hdfs_output" , "")
hdfs_output = dbutils.widgets.get("hdfs_output")

dbutils.widgets.text("storageaccount","")
storageaccount = dbutils.widgets.get("storageaccount")

# COMMAND ----------

# bc = "20250522T06"
# base_url = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data"
# hdfs_gmrn_publish = f"{base_url}/gmrn/publish/"
# hdfs_input = f"{base_url}/gmrn/publish/mergedecisions/{bc}"
# hdfs_intmd_tmp_key_path = f"{base_url}/gmrn/publish/globalmrn/sot/keycreationtmp/"
# hdfs_output = f"{base_url}/gmrn/staging/sot/gmrnassign/new-key/{bc}"
# storageaccount = "prodicdstgdls"

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

#declaration of variables
static_dd = '2099-12-31'
numeric_lit = 0

# COMMAND ----------

# define Schema
schema = StructType([
    StructField("pid", StringType()),
    StructField("cid", StringType()),
    StructField("mt",  IntegerType())
  ])

# COMMAND ----------

# DBTITLE 1,czcdgwzd
newassign_input = hdfs_input+"/newgmrn"
globalmrn_input = hdfs_gmrn_publish+"/globalmrn/current"
  # gmrn-merge/data/globalmrn/current/20230126T19

# COMMAND ----------

newassign_gmrn = spark.read.format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="|").schema(schema).load(newassign_input+"/*")
newassign_gmrn = newassign_gmrn.groupby("pid").agg(collect_list("cid").alias("cid"),min("mt").alias("mt"))

# COMMAND ----------

#define udf
def addpkvalue(val,row_number):
   val = val + row_number
   return val

# COMMAND ----------

#get the max value of globalmrnipk from existing table
globalmrn = spark.read.parquet(globalmrn_input+"/*")
globalmrn=globalmrn.withColumn("globalmrnipklong",globalmrn.globalmrnipk.cast(LongType()))
mxval = globalmrn.where(col("globalmrnipklong").isNotNull()) \
       .agg({"globalmrnipklong": "max"}).collect()[0][0]
numeric_lit = mxval
udf_addpkvalue = udf(addpkvalue, LongType())

# COMMAND ----------

#addidn static column to new assign
#creatiing PK
hdfs_intmd_tmp_key_path=hdfs_intmd_tmp_key_path+"newassign_gmrn/"
newassign_gmrn = newassign_gmrn.withColumn("staticdate",lit(static_dd))
newassign_gmrn_rownum = newassign_gmrn.withColumn("row_number", row_number().over(Window.partitionBy("staticdate").orderBy("staticdate")))
newassign_gmrn_stage = newassign_gmrn_rownum.withColumn("globalmrnipk",udf_addpkvalue(lit(numeric_lit),newassign_gmrn_rownum.row_number))
newassign_gmrn = newassign_gmrn_stage.select(newassign_gmrn_stage.pid,newassign_gmrn_stage.cid,newassign_gmrn_stage.globalmrnipk,newassign_gmrn_stage.mt)
newassign_gmrn.write.mode("overwrite").format("parquet").save(hdfs_intmd_tmp_key_path)

ng = spark.read.parquet(hdfs_intmd_tmp_key_path+"*")
# ng.show()
newassign_gmrn_flatten = ng.select(ng.pid,ng.globalmrnipk,explode(ng.cid).alias("cid"),ng.mt.alias("mt"))

# COMMAND ----------

#if it has link get the pid with new fk and cid with new fk and union to get all the patientid with pk in flatten structure

newassign_gmrn_flatten_simple = newassign_gmrn_flatten.select(newassign_gmrn_flatten.pid,newassign_gmrn_flatten.globalmrnipk,newassign_gmrn_flatten.mt).filter(newassign_gmrn_flatten.cid == '-1')

newassign_gmrn_flatten_nested_cid = newassign_gmrn_flatten.select(newassign_gmrn_flatten.cid,newassign_gmrn_flatten.globalmrnipk,newassign_gmrn_flatten.mt).filter(newassign_gmrn_flatten.cid != '-1').dropDuplicates()

newassign_gmrn_flatten_nested_pid = newassign_gmrn_flatten.select(newassign_gmrn_flatten.pid,newassign_gmrn_flatten.globalmrnipk,newassign_gmrn_flatten.mt).filter(newassign_gmrn_flatten.cid != '-1').dropDuplicates()

newassign_gmrn_flatten_nested = newassign_gmrn_flatten_nested_cid.union(newassign_gmrn_flatten_nested_pid)

newassign_gmrn_flatten_union = newassign_gmrn_flatten_simple.union(newassign_gmrn_flatten_nested)

# COMMAND ----------

#unique key written to nested and flatten dir
newassign_gmrn_flatten_union.write.mode("overwrite").parquet(hdfs_output)