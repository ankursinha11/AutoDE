# Databricks notebook source
import sys
from pyspark.storagelevel import StorageLevel
from pyspark.sql.types import *
from datetime import datetime
from pyspark.sql.functions import *
from pyspark.sql.functions import current_timestamp
import os
import sys
import subprocess


# COMMAND ----------

pip install adlfs

# COMMAND ----------

from adlfs import AzureBlobFileSystem

# COMMAND ----------

dbutils.widgets.text("gm_path", "")
gm_path= getArgument("gm_path")

dbutils.widgets.text("gpac_path","")
gpac_path= getArgument("gpac_path")

dbutils.widgets.text("gdemo_path", "")
gdemo_path= getArgument("gdemo_path")

dbutils.widgets.text("bc", "")
bc= dbutils.widgets.get("bc")

dbutils.widgets.text("gm_staging_path", "")
gm_staging_path= dbutils.widgets.get("gm_staging_path")

dbutils.widgets.text("gpac_staging_path", "")
gpac_staging_path= dbutils.widgets.get("gpac_staging_path")

dbutils.widgets.text("gdemo_staging_path", "")
gdemo_staging_path= dbutils.widgets.get("gdemo_staging_path")

dbutils.widgets.text("storageaccount","")
storageaccount=dbutils.widgets.get("storageaccount")

# COMMAND ----------

account_name = storageaccount
account_key = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret")
container_name = 'prod-icd-adls'

fs = AzureBlobFileSystem(account_name,account_key)

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

def get_csv_file(directory_path):
    try:
        files_to_treat = dbutils.fs.ls(directory_path)
        for filename in files_to_treat:
            path = filename.path
            name = filename.name
            if name.startswith("part"):
                return path
    except Exception as e:
        print("Exception occurred in move_data notebook and get_csv_file function failure error message:")
        print(e)
        raise

# COMMAND ----------

def generatefiles(source_path,delete_path,dest_path):
    try:
        if fs.exists(delete_path):
            dbutils.fs.rm(delete_path, True)
        if fs.exists(dest_path):
            dbutils.fs.rm(dest_path, True)

        if fs.exists(source_path):
            filepath = get_csv_file(source_path)
            dbutils.fs.mv(filepath, delete_path)
            df = spark.read.options(inferSchema='false').options(header='false').csv(delete_path)
            ct = str(df.count())
            dbutils.fs.put(dest_path, ct + " " + delete_path, True)
    except Exception as e:
        print("Exception occurred in move_data notebook and generatefiles function failure error message:")
        print(e)
        raise

# COMMAND ----------

gm_del_path=gm_path + "/del"
gm_ins_path = gm_path + "/ins"
gpac_del_path=gpac_path + "/del"
gpac_ins_path = gpac_path + "/ins"
gdemo_del_path=gdemo_path + "/del"
gdemo_ins_path = gdemo_path + "/ins"

gm_staging_delta_path = gm_staging_path + "/hdp_sot_delta_globalmrn_" + bc + ".dat"
gpac_staging_delta_path = gpac_staging_path + "/hdp_sot_delta_globalmrnxpacct_" + bc + ".dat"
gdemo_staging_delta_path = gdemo_staging_path + "/hdp_sot_delta_globalmrndemographics_" + bc + ".dat"
gm_staging_delete_path = gm_staging_path + "/hdp_sot_delete_globalmrn_" + bc + ".dat"
gpac_staging_delete_path = gpac_staging_path + "/hdp_sot_delete_globalmrnxpacct_" + bc + ".dat"
gdemo_staging_delete_path = gdemo_staging_path + "/hdp_sot_delete_globalmrndemographics_" + bc + ".dat"

gm_staging_delta_done_path = gm_staging_path + "/hdp_sot_delta_globalmrn_" + bc + ".done"
gpac_staging_delta_done_path = gpac_staging_path + "/hdp_sot_delta_globalmrnxpacct_" + bc + ".done"
gdemo_staging_delta_done_path = gdemo_staging_path + "/hdp_sot_delta_globalmrndemographics_" + bc + ".done"
gm_staging_delete_done_path = gm_staging_path + "/hdp_sot_delete_globalmrn_" + bc + ".done"
gpac_staging_delete_done_path = gpac_staging_path + "/hdp_sot_delete_globalmrnxpacct_" + bc + ".done"
gdemo_staging_delete_done_path = gdemo_staging_path + "/hdp_sot_delete_globalmrndemographics_" + bc + ".done"


# COMMAND ----------

generatefiles(gm_ins_path,gm_staging_delta_path,gm_staging_delta_done_path)

# COMMAND ----------

generatefiles(gm_del_path,gm_staging_delete_path,gm_staging_delete_done_path)

# COMMAND ----------

generatefiles(gpac_ins_path,gpac_staging_delta_path,gpac_staging_delta_done_path)

# COMMAND ----------

generatefiles(gpac_del_path,gpac_staging_delete_path,gpac_staging_delete_done_path)

# COMMAND ----------

generatefiles(gdemo_ins_path,gdemo_staging_delta_path,gdemo_staging_delta_done_path)

# COMMAND ----------

generatefiles(gdemo_del_path,gdemo_staging_delete_path, gdemo_staging_delete_done_path)

# COMMAND ----------

