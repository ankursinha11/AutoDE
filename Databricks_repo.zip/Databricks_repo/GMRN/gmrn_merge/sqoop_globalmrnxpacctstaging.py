# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

dbutils.widgets.text("tablenameacct","")
tablenameacct=dbutils.widgets.get("tablenameacct")

dbutils.widgets.text("path_conn_file", "")
path_conn_file= dbutils.widgets.get("path_conn_file")

dbutils.widgets.text("sqoop_output_path_acct","")
sqoop_output_path_acct= dbutils.widgets.get("sqoop_output_path_acct")

dbutils.widgets.text('hdfs_data_input',"")
hdfs_data_input= dbutils.widgets.get("hdfs_data_input")

dbutils.widgets.text("icddb","")
icddb= dbutils.widgets.get("icddb")

dbutils.widgets.text("bc","")
bc= dbutils.widgets.get("bc")

dbutils.widgets.text("storageaccount","")
storageaccount=dbutils.widgets.get("storageaccount")

# COMMAND ----------

# tablenameacct = "GlobalMRNxPacctstaging"
# path_conn_file = ""
# sqoop_output_path_acct = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data/gmrn/staging/sqoop-data/globalmrnxpacct/"
# hdfs_data_input = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data/dataingestion/publish/"
# icddb = "zescantemp.dbo."
# bc = "20240829T06"
# storageaccount = "prodicdstgdls"

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

acct_schema = StructType([
    StructField("GlobalMRNxPacctIPK", LongType(), False),
    StructField("GlobalMRNIFK", LongType(), False),
    StructField("HospitalFK", ShortType(), False),   
    StructField("PatientAcctIFK", LongType(), False),
    StructField("CreateDate", TimestampType(), True),
    StructField("isdeletedflag", StringType(), False)      
    ])

# COMMAND ----------

acct = spark.read.option("header",False).option("recursiveFileLookup","true").schema(acct_schema).options(delimiter="\x01").format("csv").load(sqoop_output_path_acct+"/"+bc)
# acct1=acct.filter(col("GlobalMRNxPacctIPK") == "-2147483390")

# COMMAND ----------

# DBTITLE 1,TEMPORARY PURGE LOGIC
acct.createOrReplaceTempView("acct")
# print("BEFORE PURGE COUNT : "+str(acct.count()))
purge=spark.read.format("parquet").load(hdfs_data_input + "hospitalpurge/current/20991231/")
purge=purge.filter("active=='1'").selectExpr("hospitalfk").dropDuplicates()
purge.createOrReplaceTempView("purge")
acct=spark.sql("""SELECT * FROM acct WHERE CAST(hospitalfk AS BIGINT) NOT IN (SELECT CAST(hospitalfk AS BIGINT) FROM purge)""").dropDuplicates()
# print("BEFORE PURGE COUNT : "+str(acct.count()))

# COMMAND ----------

acct.write.format('jdbc').mode('append').option('driver', 'com.microsoft.sqlserver.jdbc.SQLServerDriver').option('url', path_conn_file).option('dbtable', icddb+tablenameacct).save()
