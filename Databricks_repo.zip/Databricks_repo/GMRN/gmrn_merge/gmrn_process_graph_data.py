# Databricks notebook source
from pyspark.sql.types import *
from datetime import datetime
from pyspark.sql.functions import *

# COMMAND ----------

start=datetime.now()
print(start)

# COMMAND ----------

dbutils.widgets.text("hdfs_graph_input","")
hdfs_graph_input = dbutils.widgets.get("hdfs_graph_input")

dbutils.widgets.text("hdfs_merge_input", "")
hdfs_merge_input = dbutils.widgets.get("hdfs_merge_input")

dbutils.widgets.text("hdfs_scratch_dir", "")
hdfs_scratch_dir = dbutils.widgets.get("hdfs_scratch_dir")

dbutils.widgets.text("storageaccount","")
storageaccount = dbutils.widgets.get("storageaccount")

# COMMAND ----------

# bc = "20250522T06"
# base_url = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data"
# hdfs_graph_input = f"{base_url}/gmrn/publish/graphx/{bc}"
# hdfs_merge_input = f"{base_url}/gmrn/staging/matches/merge/{bc}"
# hdfs_scratch_dir = f"{base_url}/gmrn/staging/scratch/{bc}"
# storageaccount = "prodicdstgdls"

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

hdfs_input_graph_vertices = hdfs_graph_input+"/vertices/*"
hdfs_input_graph_connections= hdfs_graph_input+"/connections/*"

# COMMAND ----------

#   This pyspark script runs through list of connection op and gives back group number and min match type for each element
#reading vertices

schema = StructType([
    StructField("hashed_pid", StringType()),
    StructField("pid", StringType()),
  ])

#reading match op

schema_base_data = StructType([
    StructField("pid", StringType()),
    StructField("cid", StringType()),
    StructField("mt",  IntegerType())
  ])

# COMMAND ----------

#creating min mt for each pid and cid 

merge = spark.read.format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="|").schema(schema_base_data).load(hdfs_merge_input+"/*/*")
merge_pid= merge.select("pid","mt").dropDuplicates()
merge_cid= merge.select(merge.cid.alias("pid"),"mt").dropDuplicates()
merge_flat=merge_pid.union(merge_cid).dropDuplicates()
merge_mt=merge_flat.groupBy("pid").agg(min("mt").alias("mt"))
mm = merge_mt.alias("mm")

# COMMAND ----------

# reading vertices and connection op

a = spark.read.format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter=" ").schema(schema).load(hdfs_input_graph_vertices)
b = spark.read.parquet(hdfs_input_graph_connections)
# a.show()
# b.show()

# COMMAND ----------

#join with connection op to get original value of pid

join_cond_1 = [ a.hashed_pid == b.fromglobalmrn ]

c = a.join(b,join_cond_1,'inner') \
      .select(a.pid.alias("fromglobalmrn_pid"),a.hashed_pid.alias("fromglobalmrn_hashedpid"),b.fromglobalmrn,b.toglobalmrn )

# c.show()

# COMMAND ----------

##join with connection op to get original value of cid

join_cond_2 = [ a.hashed_pid == c.toglobalmrn ]

d = c.join(a,join_cond_2,'inner')
# d.show()
# d.printSchema()
d=d.select(d.pid,d.hashed_pid,d.fromglobalmrn,d.toglobalmrn,d.fromglobalmrn_pid,d.fromglobalmrn_hashedpid)

# COMMAND ----------

#selecting needed column

e = d.select(d.pid,d.fromglobalmrn_pid)

# group by first column to have all values in a list and creating unique id for each row 

f = e.groupBy("pid").agg(collect_list("fromglobalmrn_pid").alias("group_list")) 
                    
g = f.select(f.pid).withColumn("grp",monotonically_increasing_id())

# COMMAND ----------

g.write.mode("overwrite").parquet(hdfs_scratch_dir+"/grps")

# COMMAND ----------

g1=spark.read.parquet(hdfs_scratch_dir+"/grps")

h = g1.select(g1.pid,g1.grp)

join_cond3 = [h.pid == e.pid]

i = h.join(e,join_cond3,'inner') \
     .select(e.fromglobalmrn_pid.alias("pid"),h.grp)

# COMMAND ----------

#join with the base deduped dataset to get matchtype for each element 

join_key = [ mm.pid == i.pid ] 

j = i.join(mm,join_key,'inner') \
     .select(i.pid,i.grp,mm.mt)

#op path

hdfs_output_graph_connections=hdfs_graph_input+"/grpd_keys/"

#op with each element group and matchtype
j.repartition(200).write.mode("overwrite").parquet(hdfs_output_graph_connections)


# COMMAND ----------

from datetime import datetime
end=datetime.now()
print(end)
delta=end-start
print(delta)
