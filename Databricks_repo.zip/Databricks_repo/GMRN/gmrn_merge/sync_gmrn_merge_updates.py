# Databricks notebook source
# MAGIC %md
# MAGIC # Notebook Summary
# MAGIC
# MAGIC This notebook performs the following tasks:
# MAGIC - Reads PatientAcctsAddress and globalmrnfamilyassociations Unity Catalog tables.
# MAGIC - Reads gmrn merges from ADLS path /data/gmrn/publish/mergedecisions/20250915T01/merge
# MAGIC - Updates globalmrnifk in PatientAcctsAddress and globalmrnifk1, globalmrnifk2 in globalmrnfamilyassociations with new_gmrnid where prev_gmrnid matches from gmrn merges.
# MAGIC - update update_date with current time, bc updated with bc value and updatedby with user
# MAGIC - Writes the updated data to Parquet staging paths.
# MAGIC - Reads the staging data and writes it back to the original Unity Catalog tables.
# MAGIC
# MAGIC **Author:** [Abdul Shaik]  
# MAGIC **Date:** [2025-09-15] 

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window

# COMMAND ----------

dbutils.widgets.text("bc" , "")
bc= dbutils.widgets.get("bc")

dbutils.widgets.text("gmrn_merges_path_input" , "")
gmrn_merges_path_input= dbutils.widgets.get("gmrn_merges_path_input")

dbutils.widgets.text("gmrn_staging_path" , "")
gmrn_staging_path= dbutils.widgets.get("gmrn_staging_path")

dbutils.widgets.text("catalog_name","")
catalog_name= getArgument("catalog_name")


# COMMAND ----------

# DBTITLE 1,print parameters
databricks_user = 'app_databricks'

print(f"bc: {bc}")
print(f"gmrn_merges_path_input: {gmrn_merges_path_input}")
print(f"gmrn_staging_path: {gmrn_staging_path}")
print(f"catalog_name: {catalog_name}")
print(f"databricks_user: {databricks_user}")

# COMMAND ----------

# DBTITLE 1,1. Read PatientAcctsAddress and globalmrnfamilyassociations UC tables
# 1. Read PatientAcctsAddress and globalmrnfamilyassociations UC tables
patient_accts_address_df = spark.table(f"{catalog_name}.dataingestion.patientacctsaddress")
global_mrn_family_assoc_df = spark.table(f"{catalog_name}.dataingestion.globalmrnfamilyassociations")


# COMMAND ----------

# DBTITLE 1,2. Read gmrn merges from the specified ADLS path
# 2. Read gmrn merges from the specified ADLS path
gmrn_merges_schema = StructType([
    StructField("new_gmrnid", StringType()),
    StructField("prev_gmrnid", StringType()),
    StructField("matchtype", IntegerType())
])

gmrn_merges_df = spark.read.format("csv").options(
    timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",
    mode="FAILFAST",
    quote="",
    delimiter="|"
).schema(gmrn_merges_schema).load(gmrn_merges_path_input).dropDuplicates()

# COMMAND ----------

# DBTITLE 1,3. Update patientacctsaddress
# 3. Update globalmrnifk in patientacctsaddress with new_gmrnid where prev_gmrnid matches
updated_patient_accts_address_df = patient_accts_address_df.join(
    gmrn_merges_df,
    patient_accts_address_df.globalmrnifk == gmrn_merges_df.prev_gmrnid,
    "left"
).withColumn("globalmrnifk", when(gmrn_merges_df.new_gmrnid.isNotNull(), gmrn_merges_df.new_gmrnid).otherwise(patient_accts_address_df.globalmrnifk)
).withColumn("updatedate", when(gmrn_merges_df.new_gmrnid.isNotNull(), current_timestamp()).otherwise(patient_accts_address_df.updatedate)
).withColumn("bcupdated", when(gmrn_merges_df.new_gmrnid.isNotNull(), lit(bc)).otherwise(patient_accts_address_df.bcupdated)
).withColumn("updatedby", when(gmrn_merges_df.new_gmrnid.isNotNull(), lit(databricks_user)).otherwise(patient_accts_address_df.updatedby)
).drop("new_gmrnid", "prev_gmrnid", "matchtype")
updated_patient_accts_address_df.write.mode("overwrite").parquet( gmrn_staging_path + bc + "/updated_patient_accts_address")

# COMMAND ----------

# DBTITLE 1,4. Update globalmrnfamilyassociations
# 4. Update globalmrnifk1 and globalmrnifk2 in globalmrnfamilyassociations with new_gmrnid where prev_gmrnid matches
global_mrn_family_assoc_df.createOrReplaceTempView("globalmrnfamilyassociations_tmp")
gmrn_merges_df.createOrReplaceTempView("gmrn_merges_tmp")

gmfa_with_merge1 = spark.sql("""
                SELECT g1.*, m1.new_gmrnid 
                FROM globalmrnfamilyassociations_tmp g1
                LEFT JOIN gmrn_merges_tmp m1
                ON g1.globalmrnifk1 = m1.prev_gmrnid
                """)

gmfa_with_merge1 = gmfa_with_merge1.withColumn("globalmrnifk1", when(col("new_gmrnid").isNotNull(), col("new_gmrnid")).otherwise(col("globalmrnifk1"))
                                    ).withColumn("updatedate", when(col("new_gmrnid").isNotNull(), current_timestamp()).otherwise(col("updatedate"))
                                    ).withColumn("bcupdated", when(col("new_gmrnid").isNotNull(), lit(bc)).otherwise(col("bcupdated"))
                                    ).drop("new_gmrnid")
gmfa_with_merge1.createOrReplaceTempView("gmfa_with_merge1")

gmfa_with_merge2 = spark.sql("""
                 SELECT g2.*, m2.new_gmrnid 
                 FROM gmfa_with_merge1 g2
                 LEFT JOIN gmrn_merges_tmp m2
                 ON g2.globalmrnifk2 = m2.prev_gmrnid
                 """)

gmfa_with_merge2 = gmfa_with_merge2.withColumn("globalmrnifk2", when(col("new_gmrnid").isNotNull(), col("new_gmrnid")).otherwise(col("globalmrnifk2"))
                                    ).withColumn("updatedate", when(col("new_gmrnid").isNotNull(), current_timestamp()).otherwise(col("updatedate"))
                                    ).withColumn("bcupdated", when(col("new_gmrnid").isNotNull(), lit(bc)).otherwise(col("bcupdated"))
                                    ).drop("new_gmrnid")

gmfa_with_merge2.write.mode("overwrite").parquet(gmrn_staging_path + bc + "/updated_global_mrn_family_assoc")

# COMMAND ----------

# DBTITLE 1,5. Read staging paths and write back to original UC tables
# Read updated DataFrames from staging paths
updated_patient_accts_address_df = spark.read.parquet( gmrn_staging_path + bc + "/updated_patient_accts_address")
updated_global_mrn_family_assoc_df = spark.read.parquet( gmrn_staging_path + bc + "/updated_global_mrn_family_assoc")

# Remove duplicates on globalmrnifk and pick latest record on updatedate
deduped_patient_accts_address_df = updated_patient_accts_address_df.withColumn(
    "row_num", row_number().over(Window.partitionBy("hospitalfk", "patientacctifk", "globalmrnifk", "zip", "addresslistfk").orderBy(col("updatedate").desc())
    )).filter(col("row_num") == 1).drop("row_num")

# Remove duplicates on globalmrnifk1, globalmrnifk2 and pick latest record on updatedate
window_spec = Window.partitionBy("globalmrnifk1", "globalmrnifk2").orderBy(col("updatedate").desc())
deduped_global_mrn_family_assoc_df = updated_global_mrn_family_assoc_df.withColumn("row_num", row_number().over(window_spec)).filter(col("row_num") == 1).drop("row_num")

# Overwrite the original Unity Catalog tables with the updated data
deduped_patient_accts_address_df.write.format("delta").mode("overwrite").option(
    "overwriteSchema", "true"
).saveAsTable(f"{catalog_name}.dataingestion.patientacctsaddress")

deduped_global_mrn_family_assoc_df.write.format("delta").mode("overwrite").option(
    "overwriteSchema", "true"
).saveAsTable(f"{catalog_name}.dataingestion.globalmrnfamilyassociations")
