# Databricks notebook source
from pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime

# COMMAND ----------

start=datetime.now()
print(start)

# COMMAND ----------

# SET parameters#
dbutils.widgets.text("hdfs_match_input" , "")
hdfs_match_input = dbutils.widgets.get("hdfs_match_input")

dbutils.widgets.text("hdfs_group_input" , "")
hdfs_group_input = dbutils.widgets.get("hdfs_group_input")

dbutils.widgets.text("hdfs_output" , "")
hdfs_output = dbutils.widgets.get("hdfs_output")

dbutils.widgets.text("storageaccount","")
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text("workflowtype","")
workflowtype = dbutils.widgets.get("workflowtype")

dbutils.widgets.text("aid_assigned_gmrn_ouput","")
aid_assigned_gmrn_ouput = dbutils.widgets.get("aid_assigned_gmrn_ouput")

dbutils.widgets.text("bc","")
bc = dbutils.widgets.get("bc")

dbutils.widgets.text("stagedPatientacctsTableName","")
stagedPatientacctsTableName = dbutils.widgets.get("stagedPatientacctsTableName")

# COMMAND ----------

# bc = "20250522T06"
# base_url = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data"
# hdfs_match_input = f"{base_url}/gmrn/staging/matches/merge/{bc}"
# hdfs_group_input = f"{base_url}/gmrn/publish/graphx/{bc}"
# hdfs_output = f"{base_url}/gmrn/publish/mergedecisions/{bc}"
# storageaccount = "prodicdstgdls"
# stagedPatientacctsTableName = f"regular_staged_patientaccts_{bc}"
# workflowtype = "regular"
# aid_assigned_gmrn_ouput = f"{base_url}/gmrn/publish/globalmrnxpacct_swift/"

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

#define schema
schema = StructType([
    StructField("pid", StringType()),
    StructField("cid", StringType()),
    StructField("mt",  IntegerType())
  ])

# COMMAND ----------

a = spark.read.format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="|").schema(schema).load(hdfs_match_input +"/*")
# a.show()

# COMMAND ----------

groupedkeys = spark.read.parquet(hdfs_group_input+"/grpd_keys/*")
groupedkeys.createOrReplaceTempView("groupedkeys")

# COMMAND ----------

#aggregation by groups like, min key, min matchtype, number of patientaccts and globalmrns in a group
a1 = spark.sql("SELECT grp,min(pid) as pid,count(*) as panum,0 as num, min(mt) as mt\
                FROM groupedkeys\
                WHERE  instr(pid,'T')>0\
                GROUP by grp")

b1 = spark.sql("SELECT grp,min(cast(pid as bigint)) as pid,0 as panum, count(*) as num, min(mt) as mt\
                FROM groupedkeys\
                WHERE instr(pid,'T')=0\
                GROUP by grp")
c1 = a1.union(b1)

c1.createOrReplaceTempView("mingroupedkeys")

d1 = spark.sql("SELECT grp, min(pid) as pid,sum(panum) as panum,sum(num) as num,min(mt) as mt\
                FROM  mingroupedkeys\
                GROUP by grp")
# d1.show()

d1.createOrReplaceTempView("mingroupedkeys")

# COMMAND ----------

#create merge dataset
mergesql="SELECT b.pid,a.pid as cid,b.mt\
        FROM groupedkeys a\
        JOIN mingroupedkeys b on a.grp=b.grp and a.pid<>b.pid WHERE instr(a.pid,'T')=0 and instr(b.pid,'T')=0 and b.num<4"

merge=spark.sql(mergesql)
# merge.show()

# COMMAND ----------

#create initial assign dataset
assignsql="SELECT b.pid,a.pid as cid,b.mt,a.grp\
        FROM groupedkeys a\
        JOIN mingroupedkeys b on a.grp=b.grp and a.pid<>b.pid WHERE ((instr(a.pid,'T')>0 and instr(b.pid,'T')=0) or (instr(a.pid,'T')=0 and instr(b.pid,'T')>0) )"

assign=spark.sql(assignsql)
# assign.show()

# COMMAND ----------

#create initial new gmrn dataset
newgmrngensql="SELECT b.pid,a.pid as cid,b.mt\
        FROM groupedkeys a\
        JOIN mingroupedkeys b on a.grp=b.grp and a.pid<>b.pid WHERE instr(a.pid,'T')>0 and instr(b.pid,'T')>0"

newgmrn = spark.sql(newgmrngensql)
# newgmrn.show()

# COMMAND ----------

#only valid folks will get id
pa = spark.read.table(stagedPatientacctsTableName)

pa = pa.where((pa.fn_valid==1) & (pa.ln_valid==1) & (pa.dob_valid==1) & ((pa.ssn_valid==1) | (pa.mrn_valid==1)))\
       .select(col("globalmrnifk")\
       .alias("pid"))

b = groupedkeys.select("pid")

newgmrn_1=pa.subtract(b)

newgmrn_1=newgmrn_1\
          .withColumn("cid",lit("-1"))\
          .withColumn("mt",lit("-1"))

#create final new gmrn dataset
newgmrn=newgmrn.union(newgmrn_1)
# newgmrn_1.show()

# COMMAND ----------

#convoluted logic to figure out which are not merging, that way, the assignments need to change to original match
notmergesql = "SELECT pid as nmpid,grp as nmgrp\
               FROM mingroupedkeys\
               WHERE num>3"

notmerge=spark.sql(notmergesql)

cidsinneedofnewparent = assign\
			.join(notmerge,(assign.grp==notmerge.nmgrp),"inner")\
		 	.select(assign.cid,notmerge.nmgrp)

possiblenewparent = a\
		    .join(cidsinneedofnewparent,a.pid==cidsinneedofnewparent.cid)\
                    .where(~a.cid.contains('T'))\
                    .select(cidsinneedofnewparent.cid,a.cid.alias("newpid"),a.mt.alias("newmt"),cidsinneedofnewparent.nmgrp)

possiblenewparent = possiblenewparent\
		    .groupBy("nmgrp")\
	            .agg(min(possiblenewparent.newpid.cast(LongType())).alias("newparent"),min(possiblenewparent.newmt).alias("newmatchtype"))

# COMMAND ----------

#create new assign
newassign = assign\
	    .join(possiblenewparent, (assign.grp==possiblenewparent.nmgrp),"leftouter")\
            .select(\
               when(possiblenewparent.newparent.isNull(),assign.pid).otherwise(possiblenewparent.newparent).alias("pid"),\
               assign.cid,\
               when(possiblenewparent.newmatchtype.isNull(),assign.mt).otherwise(possiblenewparent.newmatchtype).alias("mt")\
             )

newassign = newassign.withColumn("cid",(regexp_replace('cid', 'T', '')))\
                     .select("cid","pid","mt")
# newassign.show()

# COMMAND ----------

#create new gmrn
newgmrn = newgmrn.withColumn("cid",(regexp_replace('cid', 'T', '')))\
                 .withColumn("pid",(regexp_replace('pid', 'T', '')))

# newgmrn.show()

# COMMAND ----------

newassign.repartition(1)\
          .write.mode("overwrite")\
          .format("csv")\
          .options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="|")\
          .save(hdfs_output+"/assign")

# COMMAND ----------

newgmrn.repartition(1)\
          .write.mode("overwrite")\
          .format("csv")\
          .options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="|")\
          .save(hdfs_output+"/newgmrn")

# COMMAND ----------

merge.repartition(1)\
          .write.mode("overwrite")\
          .format("csv")\
          .options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="|")\
          .save(hdfs_output+"/merge")

# COMMAND ----------

if workflowtype == "aid":
    print("AID MODE ASSIGN")
    aid_schema = StructType(
        [
            StructField("patientacctifk", StringType(), True),
            StructField("gmrnid", StringType(), True),
            StructField("gmrnmatchind", StringType(), True),
        ]
    )
    gmrnid = (
        spark.read.format("csv")
        .schema(aid_schema)
        .options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", delimiter="|")
        .load(hdfs_output + "/assign")
        .dropDuplicates()
    )
    gmrnid.show(10, False)
    # gmrnid = gmrnid.withColumn("bc", lit(bc))
    gmrnid = gmrnid.withColumn("hospitalfk", split("patientacctifk", "_")[1]) \
            .withColumn("patientacctifk", split("patientacctifk", "_")[0])
    aid_assigned_gmrn_ouput=aid_assigned_gmrn_ouput+"/"+bc
    gmrnid.write.mode("overwrite").parquet(aid_assigned_gmrn_ouput)
    dbutils.notebook.exit(0)
else:
    print("REGULAR")
    dbutils.notebook.exit(0)
