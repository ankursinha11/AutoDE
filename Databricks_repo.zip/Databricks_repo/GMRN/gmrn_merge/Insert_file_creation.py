# Databricks notebook source
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql.window import Window
from datetime import datetime

# COMMAND ----------

# SET parameters#
dbutils.widgets.text("hdfs_data_input" , "")
hdfs_data_input = dbutils.widgets.get("hdfs_data_input")

dbutils.widgets.text("hdfs_input" , "")
hdfs_input = dbutils.widgets.get("hdfs_input")

dbutils.widgets.text("hdfs_gmrn_publish","")
hdfs_gmrn_publish = dbutils.widgets.get("hdfs_gmrn_publish")

dbutils.widgets.text("hdfs_gmrnkey_output" , "")
hdfs_gmrnkey_output = dbutils.widgets.get("hdfs_gmrnkey_output")

dbutils.widgets.text("hdfs_intmd_tmp_key_path" , "")
hdfs_intmd_tmp_key_path = dbutils.widgets.get("hdfs_intmd_tmp_key_path")

dbutils.widgets.text("gm_his_path" , "")
gm_his_path = dbutils.widgets.get("gm_his_path")

dbutils.widgets.text("gpac_his_path" , "")
gpac_his_path = dbutils.widgets.get("gpac_his_path")

dbutils.widgets.text("gdemo_his_path" , "")
gdemo_his_path = dbutils.widgets.get("gdemo_his_path")

dbutils.widgets.text("gm_sqoop_path" , "")
gm_sqoop_path = dbutils.widgets.get("gm_sqoop_path")

dbutils.widgets.text("gpac_sqoop_path" , "")
gpac_sqoop_path = dbutils.widgets.get("gpac_sqoop_path")

dbutils.widgets.text("gdemo_sqoop_path" , "")
gdemo_sqoop_path = dbutils.widgets.get("gdemo_sqoop_path")

dbutils.widgets.text("gm_path" , "")
gm_path = dbutils.widgets.get("gm_path")

dbutils.widgets.text("gdemo_path" , "")
gdemo_path = dbutils.widgets.get("gdemo_path")

dbutils.widgets.text("gpac_path" , "")
gpac_path = dbutils.widgets.get("gpac_path")

dbutils.widgets.text("storageaccount","")
storageaccount = dbutils.widgets.get("storageaccount")

# COMMAND ----------

# bc = "20250522T06"
# base_url = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data"
# gdemo_his_path = f"{base_url}/dataingestion/publish/globalmrndemographicshistory/{bc}"
# gdemo_path = f"{base_url}/gmrn/staging/sot/tmp_op/globalxdemo/{bc}"
# gdemo_sqoop_path = f"{base_url}/gmrn/staging/sqoop-stage/globalmrndemo/{bc}"
# gm_his_path = f"{base_url}/dataingestion/publish/globalmrnhistory/{bc}"
# gm_path = f"{base_url}/gmrn/staging/sot/tmp_op/globalmrn/{bc}"
# gm_sqoop_path = f"{base_url}/gmrn/staging/sqoop-data/globalmrn/{bc}"
# gpac_his_path = f"{base_url}/dataingestion/publish/globalmrnxpaccthistory/{bc}"
# gpac_path = f"{base_url}/gmrn/staging/sot/tmp_op/globalmrnxpacct/{bc}"
# gpac_sqoop_path = f"{base_url}/gmrn/staging/sqoop-data/globalmrnxpacct/{bc}"
# hdfs_data_input = f"{base_url}/dataingestion/publish/"
# hdfs_gmrn_publish = f"{base_url}/gmrn/publish/"
# hdfs_gmrnkey_output = f"{base_url}/gmrn/staging/sot/gmrnassign/new-key/{bc}"
# hdfs_input = f"{base_url}/gmrn/publish/mergedecisions/{bc}"
# hdfs_intmd_tmp_key_path = f"{base_url}/gmrn/publish/globalmrn/sot/keycreationtmp/"
# storageaccount = "prodicdstgdls"

# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions","auto")
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

current_dt=datetime.today().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
static_dd = '2099-12-31'

# COMMAND ----------

#udf to create primary key
def addpkvalue(val,row_number):
   val = val + row_number
   return val

# COMMAND ----------

#schema for merge/asign o/p
schema = StructType([
    StructField("toglobalmrnifk", StringType()),
    StructField("fromglobalmrnifk", StringType()),
    StructField("matchtype",  IntegerType())
  ])

# COMMAND ----------

#reading files
assign_input = hdfs_input+"/assign"
merge_input = hdfs_input+"/merge"
globalmrn_input = hdfs_gmrn_publish+'/globalmrn/current'+'/*'
globalmrnxpacct_input = hdfs_gmrn_publish + '/globalmrnxpacct/current' +'/*'
globalmrndemographics_input = hdfs_gmrn_publish +'/globalmrndemographics/current' +'/*'
patientaccts_input = hdfs_data_input +'/patientaccts/current/20991231/'
hdfs_gmrnkey_output=hdfs_gmrnkey_output

# COMMAND ----------

globalmrn = spark.read.parquet(globalmrn_input)
gm = globalmrn.alias('gm')

# COMMAND ----------

#reading globalmrn,gmrnxpacct,gmrnxdemp and finding max key for them 

globalmrn = spark.read.parquet(globalmrn_input)
gm = globalmrn.alias('gm')

globalmrnxpacct = spark.read.parquet(globalmrnxpacct_input)
globalmrnxpacct = globalmrnxpacct.withColumn("globalmrnxpacctipklong",globalmrnxpacct.globalmrnxpacctipk.cast(LongType()))
mxval_globalmrnxpacct = globalmrnxpacct.where(col("globalmrnxpacctipklong").isNotNull()) \
       .agg({"globalmrnxpacctipklong": "max"}).collect()[0][0]
gpac = globalmrnxpacct.alias('gpac')

globalmrndemographics = spark.read.parquet(globalmrndemographics_input)
globalmrndemographics=globalmrndemographics.withColumn("globalmrndemographicsipklong",globalmrndemographics.globalmrndemographicsipk.cast(LongType()))
mxval_globalmrndemographics = globalmrndemographics.where(col("globalmrndemographicsipklong").isNotNull()) \
       .agg({"globalmrndemographicsipklong": "max"}).collect()[0][0]
gdemo = globalmrndemographics.alias('gdemo')

# COMMAND ----------

# reading pa 
# patientaccts = spark.read.parquet(patientaccts_input)
patientaccts = spark.read.format("delta").load(patientaccts_input)
pa = patientaccts.alias('pa')

# COMMAND ----------

#reading current merge op
merge_gmrn = spark.read.format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="|").schema(schema).load(merge_input+"/*")
merge = merge_gmrn.alias('merge')

# COMMAND ----------

#reading assign op and new assign op
assign_gmrn = spark.read.format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="|").schema(schema).load(assign_input+"/*")
assign_gmrn = assign_gmrn.withColumn("toglobalmrnifk_new", col("toglobalmrnifk")) \
                        .withColumn("toglobalmrnifk", split("toglobalmrnifk_new", "_")[0]) \
                        .withColumn("hospitalfk", split("toglobalmrnifk_new", "_")[1]) \
                        .drop("toglobalmrnifk_new")

new_key_assign = spark.read.parquet(hdfs_gmrnkey_output+"/*")
new_key_assign = new_key_assign.withColumn("pid_new", col("pid")) \
                        .withColumn("pid", split("pid_new", "_")[0]) \
                        .withColumn("hospitalfk", split("pid_new", "_")[1]) \
                        .drop("pid_new")

assign_gmrn_whole = assign_gmrn.union(new_key_assign) 
assign = assign_gmrn_whole.alias('assign')

# COMMAND ----------

#getting the min pid, hospitalfk for each new GMRNID
new_key_assign_grpd = new_key_assign.withColumn("row_number", row_number().over(Window.partitionBy("globalmrnipk").orderBy("pid", "hospitalfk"))).filter("row_number = 1").drop("row_number")
newassign = new_key_assign_grpd.alias('newassign')

# COMMAND ----------

#join cond for all the tables with merge o/p
join_key_gm = [ merge.fromglobalmrnifk == gm.globalmrnipk ]
join_key_gpac = [ merge.fromglobalmrnifk == gpac.globalmrnifk ]
join_key_gdemo = [ merge.fromglobalmrnifk == gdemo.globalmrnifk ]

# COMMAND ----------

# getting for delete records for globalmrn table added the isdeleted flag using merge o/p
joined_gm = gm.join(merge,join_key_gm,'inner') \
     .select(gm["*"],merge.toglobalmrnifk) 

# COMMAND ----------

joined_gm_del = joined_gm.drop("toglobalmrnifk")
joined_gm_del = joined_gm_del.withColumn("isdeletedflag",lit(1))
joined_gm_del = joined_gm_del.withColumn("createdate",lit(current_dt))
joined_gm_del = joined_gm_del.withColumn("dob", date_format("dob","yyyy-MM-dd HH:mm:ss.SSS"))

# COMMAND ----------

# joinng with merge o/p and gmrnxpacct table to get the deleted and new insert records
#union to be deleted and new inserted records in a single df

joined_gpac = gpac.join(merge,join_key_gpac,'inner') \
     .select(gpac["*"],merge.toglobalmrnifk) 
joined_gpac_del = joined_gpac.drop("toglobalmrnifk","globalmrnxpacctipklong")
joined_gpac_del = joined_gpac_del.withColumn("isdeletedflag",lit(1))
joined_gpac_del = joined_gpac_del.withColumn("createdate", date_format("createdate","yyyy-MM-dd HH:mm:ss.SSS"))

joined_gpac = joined_gpac.withColumn("createdate",lit(current_dt))
joined_gpac = joined_gpac.select(joined_gpac.globalmrnxpacctipk,joined_gpac.toglobalmrnifk,joined_gpac.hospitalfk,joined_gpac.patientacctifk,joined_gpac.createdate)
merged_gpac_ins = joined_gpac.withColumn("isdeletedflag",lit(0))

# COMMAND ----------

#joinng with merge o/p and gmrnxpacct table to get the deleted and new insert records
#union to be deleted and new inserted records in a single df

joined_gdemo =  gdemo.join(merge,join_key_gdemo,'inner') \
     .select(gdemo["*"],merge.toglobalmrnifk) 
joined_gdemo_del = joined_gdemo.drop("toglobalmrnifk","globalmrndemographicsipklong")
joined_gdemo_del = joined_gdemo_del.withColumn("isdeletedflag",lit(1))
joined_gdemo_del = joined_gdemo_del.withColumn("dob", date_format("dob","yyyy-MM-dd HH:mm:ss.SSS"))
joined_gdemo_del = joined_gdemo_del.withColumn("createdate", date_format("createdate","yyyy-MM-dd HH:mm:ss.SSS"))

joined_gdemo = joined_gdemo.withColumn("createdate",lit(current_dt))
joined_gdemo = joined_gdemo.select(joined_gdemo.globalmrndemographicsipk,joined_gdemo.toglobalmrnifk,joined_gdemo.patientacctifk, \
                                   joined_gdemo.hospitalfk,joined_gdemo.firstname,joined_gdemo.middlename,joined_gdemo.lastname, \
                                   joined_gdemo.suffix,joined_gdemo.dob,joined_gdemo.ssn,joined_gdemo.gender,\
                                   joined_gdemo.addr1,joined_gdemo.city,joined_gdemo.state,joined_gdemo.zip,\
                                   joined_gdemo.phone1,joined_gdemo.medicaidnum,joined_gdemo.medicarehic, \
                                   joined_gdemo.ignoreflag,joined_gdemo.createdate)
merged_gdemo_ins = joined_gdemo.withColumn("isdeletedflag",lit(0))
merged_gdemo_ins = merged_gdemo_ins.withColumn("dob", date_format("dob","yyyy-MM-dd HH:mm:ss.SSS"))

# COMMAND ----------

#declaring UDF to create the primary ket for each table 
udf_addpkvalue = udf(addpkvalue, LongType())

# COMMAND ----------

#join condition for assign o/p with PA to get the column for the tables 

assign_pa_join_key = [ (assign.toglobalmrnifk == pa.patientacctipk) & (assign.hospitalfk == pa.hospitalfk) ]
newassign_pa_join_key = [ (newassign.pid == pa.patientacctipk) & (newassign.hospitalfk == pa.hospitalfk) ]

# COMMAND ----------

#getting the new records for insert using globalmrn table and newgmrn o/p

assign_gm_input = newassign.join(pa,newassign_pa_join_key,'inner') \
                        .select(pa.createdate,pa.hospitalfk,pa.patientacctipk, \
                                pa.medicalrecnum,pa.ssn,pa.medicaidnum,pa.medicarehic, \
                                pa.dob,pa.firstname,pa.lastname,pa.phone1,substring(regexp_replace(pa.addr1, '\D', ''),-1,5).alias('streetnum'), \
                                pa.city,pa.zip,newassign.globalmrnipk)
assign_gm_stage = assign_gm_input.withColumn("createdate",lit(current_dt))
assign_gm = assign_gm_stage.select(assign_gm_stage.globalmrnipk,assign_gm_stage.createdate,assign_gm_stage.hospitalfk, \
                                   assign_gm_stage.patientacctipk,assign_gm_stage.medicalrecnum, \
                                   assign_gm_stage.ssn,assign_gm_stage.medicaidnum,assign_gm_stage.medicarehic,
                                   assign_gm_stage.dob,assign_gm_stage.firstname, \
                                   assign_gm_stage.lastname,assign_gm_stage.phone1, \
                                   assign_gm_stage.streetnum,assign_gm_stage.city,assign_gm_stage.zip)
gm_file_all = assign_gm.withColumn("isdeletedflag",lit(0))
gm_file_all = gm_file_all.withColumn("dob", date_format("dob","yyyy-MM-dd HH:mm:ss.SSS"))
gm_sqoop=gm_file_all.union(joined_gm_del)


# COMMAND ----------

#getting the new records for insert using gpac table and assign o/p
#union with merge o/p results inserts to have a single o/p
assign_gpac_input = assign.join(pa,assign_pa_join_key,'inner') \
                          .select(pa.hospitalfk,pa.patientacctipk,assign.fromglobalmrnifk,pa.createdate) 
assign_gpac_input = assign_gpac_input.withColumn("staticdate",lit(static_dd))
assign_gpac_input_rownum = assign_gpac_input.withColumn("row_number", row_number().over(Window.partitionBy("staticdate").orderBy("staticdate")))
assign_gpac_stage = assign_gpac_input_rownum.withColumn("globalmrnxpacctipk",udf_addpkvalue(lit(mxval_globalmrnxpacct),assign_gpac_input_rownum.row_number))
assign_gpac_stage = assign_gpac_stage.withColumn("createdate",lit(current_dt))
assign_gpac = assign_gpac_stage.select(assign_gpac_stage.globalmrnxpacctipk,assign_gpac_stage.fromglobalmrnifk, \
                                       assign_gpac_stage.hospitalfk,assign_gpac_stage.patientacctipk,assign_gpac_stage.createdate)
assign_gpac = assign_gpac.withColumn("isdeletedflag",lit(0))

# COMMAND ----------

#writing the keys to temp location for further processing 
assign_gpac.write.mode("overwrite").parquet(hdfs_intmd_tmp_key_path+"/gpac_merge/")


# COMMAND ----------

agpac = spark.read.parquet(hdfs_intmd_tmp_key_path+"/gpac_merge/*")
agpac = agpac.withColumn("createdate", date_format("createdate","yyyy-MM-dd HH:mm:ss.SSS"))
gpac_file_all = agpac.union(merged_gpac_ins)
gpac_sqoop=gpac_file_all.union(joined_gpac_del)

# COMMAND ----------

#getting the new records for insert using globalmrndemo table and newgmrn o/p
#union with merge o/p results inserts to have a single o/p
#to find out the pacct with same demographic data

assign_gdemo_pa = assign.join(pa,assign_pa_join_key,'inner') \
                           .select(pa.patientacctipk,pa.hospitalfk,pa.firstname,pa.middlename, \
                                   pa.lastname,pa.suffix,pa.dob,pa.ssn,pa.gender,pa.addr1,pa.city,pa.state,pa.zip,pa.phone1,\
                                   pa.medicaidnum,pa.medicarehic,assign.fromglobalmrnifk)

pa_stage = assign_gdemo_pa.withColumn("row_number", row_number().over(Window.partitionBy(assign_gdemo_pa.firstname,assign_gdemo_pa.middlename,assign_gdemo_pa.lastname,
                                   assign_gdemo_pa.fromglobalmrnifk, \
                                   assign_gdemo_pa.suffix,assign_gdemo_pa.dob,assign_gdemo_pa.ssn, \
                                   assign_gdemo_pa.gender,assign_gdemo_pa.addr1,assign_gdemo_pa.city, \
                                   assign_gdemo_pa.state,assign_gdemo_pa.zip,assign_gdemo_pa.phone1, \
                                   assign_gdemo_pa.medicaidnum,assign_gdemo_pa.medicarehic) \
                                .orderBy("patientacctipk", "hospitalfk"))) \
                                .filter("row_number = 1") \
                                .drop("row_number")

pa_join_pa_stage = [ (pa.patientacctipk == pa_stage.patientacctipk) & (pa.hospitalfk == pa_stage.hospitalfk) ]


# COMMAND ----------

#override pa
pa_deduped = pa.join(pa_stage,pa_join_pa_stage,'inner') \
       .select(pa_stage["*"],pa.createdate)

# COMMAND ----------

spark.conf.set ("spark.sql.analyzer.failAmbiguousSelfJoin", False)

# COMMAND ----------

#join key with deduped pa
assign_pa_deduped_join_key = [ (assign.toglobalmrnifk == pa_deduped.patientacctipk) & (assign.hospitalfk == pa_deduped.hospitalfk) ]
assign_gdemo_input = assign.join(pa_deduped,assign_pa_deduped_join_key,'inner') \
                           .select(pa_deduped.patientacctipk,pa_deduped.hospitalfk,pa_deduped.firstname,pa_deduped.middlename, \
                                   pa_deduped.lastname,pa_deduped.suffix,pa_deduped.dob,pa_deduped.ssn,pa_deduped.gender,pa_deduped.addr1,pa_deduped.city,pa_deduped.state,pa_deduped.zip,pa_deduped.phone1, \
                                   pa_deduped.medicaidnum,pa_deduped.medicarehic,pa_deduped.createdate,assign.fromglobalmrnifk,pa_deduped.fromglobalmrnifk)
assign_gdemo_input = assign_gdemo_input.withColumn("staticdate",lit(static_dd))
assign_gdemo_input = assign_gdemo_input.withColumn("ignoreflag",lit(0))
assign_gdemo_input_rownum = assign_gdemo_input.withColumn("row_number", row_number().over(Window.partitionBy("staticdate").orderBy("staticdate")))
assign_gdemo_stage = assign_gdemo_input_rownum.withColumn("globalmrndemographicsipk",udf_addpkvalue(lit(mxval_globalmrndemographics),assign_gdemo_input_rownum.row_number))
assign_gdemo_stage = assign_gdemo_stage.withColumn("createdate",lit(current_dt))
assign_gdemo = assign_gdemo_stage.select(assign_gdemo_stage.globalmrndemographicsipk,assign_gdemo_stage.fromglobalmrnifk,assign_gdemo_stage.patientacctipk, \
                                   assign_gdemo_stage.hospitalfk,assign_gdemo_stage.firstname,assign_gdemo_stage.middlename,assign_gdemo_stage.lastname, \
                                   assign_gdemo_stage.suffix,assign_gdemo_stage.dob,assign_gdemo_stage.ssn,assign_gdemo_stage.gender,\
                                   assign_gdemo_stage.addr1,assign_gdemo_stage.city,assign_gdemo_stage.state,assign_gdemo_stage.zip,\
                                   assign_gdemo_stage.phone1,assign_gdemo_stage.medicaidnum,assign_gdemo_stage.medicarehic, \
                                   assign_gdemo_stage.ignoreflag,assign_gdemo_stage.createdate)
assign_gdemo = assign_gdemo.withColumn("isdeletedflag",lit(0))
assign_gdemo = assign_gdemo.withColumn("dob", date_format("dob","yyyy-MM-dd HH:mm:ss.SSS"))

# COMMAND ----------

#writing the keys to temp location for further processing
assign_gdemo.write.mode("overwrite").parquet(hdfs_intmd_tmp_key_path+"/gdemo_merge/")

# COMMAND ----------

agdemo = spark.read.parquet(hdfs_intmd_tmp_key_path+"/gdemo_merge/*")
agdemo = agdemo.withColumn("dob", date_format("dob","yyyy-MM-dd HH:mm:ss.SSS"))
agdemo = agdemo.withColumn("createdate", date_format("createdate","yyyy-MM-dd HH:mm:ss.SSS"))
gdemo_file_all = agdemo.union(merged_gdemo_ins)
gdemo_sqoop = gdemo_file_all.union(joined_gdemo_del)

# COMMAND ----------

#writing out the history table
joined_gm_del.repartition(1).write.mode("overwrite").parquet(gm_his_path)
joined_gpac_del.repartition(1).write.mode("overwrite").parquet(gpac_his_path)
joined_gdemo_del.repartition(1).write.mode("overwrite").parquet(gdemo_his_path)

# COMMAND ----------

#writing out the sqoop output
gm_sqoop.repartition(1).write.mode("overwrite").option("nullValue",None).option("emptyValue",None).format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="\x01").save(gm_sqoop_path)
gpac_sqoop.repartition(1).write.mode("overwrite").option("nullValue",None).option("emptyValue",None).format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="\x01").save(gpac_sqoop_path)
gdemo_sqoop.repartition(1).write.mode("overwrite").option("nullValue",None).option("emptyValue",None).format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="\x01").save(gdemo_sqoop_path)

# COMMAND ----------

#writing out the deletes and inserts for each table
joined_gm_del.repartition(1).write.mode("overwrite").option("nullValue",None).option("emptyValue",None).format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="\x01").save(gm_path+'/del/')
joined_gpac_del.repartition(1).write.mode("overwrite").option("nullValue",None).option("emptyValue",None).format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="\x01").save(gpac_path+'/del/')
joined_gdemo_del.repartition(1).write.mode("overwrite").option("nullValue",None).option("emptyValue",None).format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="\x01").save(gdemo_path+'/del/')
gm_file_all.repartition(1).write.mode("overwrite").option("nullValue",None).option("emptyValue",None).format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="\x01").save(gm_path+'/ins/')
gpac_file_all.repartition(1).write.mode("overwrite").option("nullValue",None).option("emptyValue",None).format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="\x01").save(gpac_path+'/ins/')
gdemo_file_all.repartition(1).write.mode("overwrite").option("nullValue",None).option("emptyValue",None).format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="\x01").save(gdemo_path+'/ins/')
