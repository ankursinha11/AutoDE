# Databricks notebook source
import sys
import json
from pyspark.storagelevel import StorageLevel
from pyspark.sql.types import ArrayType, StringType, StructType, StructField
from datetime import datetime
from pyspark.sql.functions import lit,date_format
#import re
#from collections import deque

# COMMAND ----------

start=datetime.now()
print(start)

# COMMAND ----------

dbutils.widgets.text("hdfs_gdemo_update_path", "")
dbutils.widgets.text("hdfs_gdemo_sqoop_stage_path", "")
dbutils.widgets.text("hdfs_gdemo_sqoop_path", "")
dbutils.widgets.text('schema_file_path',"")
dbutils.widgets.text('schema_file_copy_path',"")
dbutils.widgets.text('hdfs_data_input',"")
dbutils.widgets.text('bc',"")




hdfs_gdemo_update_path = dbutils.widgets.get("hdfs_gdemo_update_path")
hdfs_gdemo_sqoop_stage_path = dbutils.widgets.get("hdfs_gdemo_sqoop_stage_path")
hdfs_gdemo_sqoop_path= dbutils.widgets.get("hdfs_gdemo_sqoop_path")
schema_file_path = dbutils.widgets.get("schema_file_path")
schema_file_copy_path = dbutils.widgets.get("schema_file_copy_path")
hdfs_data_input = dbutils.widgets.get("hdfs_data_input")
bc = dbutils.widgets.get("bc")

dbutils.widgets.text("storageaccount","")
storageaccount=dbutils.widgets.get("storageaccount")

# COMMAND ----------

# hdfs_gdemo_update_path = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data/gmrn/staging/sot/gmrndemo_update/globalmrndemographics/20240829T06"
# hdfs_gdemo_sqoop_stage_path = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data/gmrn/staging/sqoop-stage/globalmrndemo/20240829T06"
# hdfs_gdemo_sqoop_path = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data/gmrn/staging/sqoop-data/globalmrndemo/20240829T06"
# hdfs_data_input = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data/dataingestion/publish/"
# bc = "20240829T06"
# storageaccount = "prodicdstgdls"

# COMMAND ----------


spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

spark.sparkContext.setLogLevel("ERROR")

# COMMAND ----------

# MAGIC %md
# MAGIC ##Read Schema File

# COMMAND ----------

import json
globalmrndemographics_input = hdfs_data_input +'globalmrndemographics/current'+"/*" 

#reading the main base table to get schema 

globalmrndemographics = spark.read.parquet(globalmrndemographics_input)
globalmrndemographics=globalmrndemographics.withColumn("isdeletedflag",lit(1))
gdemo = globalmrndemographics.alias('gdemo')
gdemo_schema = gdemo.schema

# COMMAND ----------

# MAGIC %md
# MAGIC ##Reading the files

# COMMAND ----------


#reading the two files generated from merge and update process 
hdfs_gdemo_update_path=hdfs_gdemo_update_path+"/*.dat"
hdfs_gdemo_sqoop_stage_path=hdfs_gdemo_sqoop_stage_path+"/*"
gdemo_sqoop_stage = spark.read.format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="\x01").schema(gdemo_schema).load(hdfs_gdemo_sqoop_stage_path)
gdeo_stage_update = spark.read.format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="\x01").schema(gdemo_schema).load(hdfs_gdemo_update_path)

gdemo_stage_delete = gdeo_stage_update.filter(gdeo_stage_update.isdeletedflag==1)
gdemo_stage_delete.createOrReplaceTempView("gsd")
gdeo_stage_update = gdeo_stage_update.filter(gdeo_stage_update.isdeletedflag==0)

gdemo_union = gdemo_sqoop_stage.union(gdeo_stage_update)
gdemo_union.createOrReplaceTempView("gdu")

# COMMAND ----------


#creating the most updated records for one set of pa and hospitalfk

a_ins =  """
        SELECT * from gdu where isdeletedflag=0
        """
#getting the records which got merged and also in update
#creating the oldest record for each pa and hospitalfk for delete the record in sql server

a_join = """
            select g1.* 
              from 
               gsd g1 join (select distinct patientacctifk,hospitalfk from gdu where isdeletedflag=1) g2 
              on (g1.patientacctifk = g2.patientacctifk) and (g1.hospitalfk = g2.hospitalfk)
          """      

# COMMAND ----------

joinq = spark.sql(a_join)
gdemo_all = gdemo_union.union(joinq)
gdemo_all.createOrReplaceTempView("gda")

# COMMAND ----------

a_del =  """
        SELECT *
        FROM (
          SELECT *,
             ROW_NUMBER() OVER (PARTITION BY patientacctifk,hospitalfk ORDER BY createdate ASC) AS rownum
           FROM gda where isdeletedflag=1
          ) a
        WHERE a.rownum=1
        """

# COMMAND ----------

#running the query and union of delete and new record

b = spark.sql(a_ins).drop("rownum")
c = spark.sql(a_del).drop("rownum") 
d = c.union(b)
d = d.withColumn("dob", date_format("dob","yyyy-MM-dd HH:mm:ss.SSS"))
d = d.withColumn("createdate", date_format("createdate","yyyy-MM-dd HH:mm:ss.SSS"))

# COMMAND ----------

#writing the op for sqoop
d.repartition(1).write.mode("overwrite").option("nullValue",None).option("emptyValue",None).format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="\x01").save(hdfs_gdemo_sqoop_path)


# COMMAND ----------

from datetime import datetime

end=datetime.now()
print(end)
delta=end-start
print(delta)
