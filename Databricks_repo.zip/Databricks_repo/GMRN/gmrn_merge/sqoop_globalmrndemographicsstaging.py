# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

dbutils.widgets.text("tablenamedemo","")
tablenamedemo=dbutils.widgets.get("tablenamedemo")

dbutils.widgets.text("path_conn_file", "")
path_conn_file= dbutils.widgets.get("path_conn_file")

dbutils.widgets.text("sqoop_output_path_demo","")
sqoop_output_path_demo= dbutils.widgets.get("sqoop_output_path_demo")

dbutils.widgets.text('hdfs_data_input',"")
hdfs_data_input= dbutils.widgets.get("hdfs_data_input")

dbutils.widgets.text("icddb","")
icddb= dbutils.widgets.get("icddb")

dbutils.widgets.text("bc","")
bc= dbutils.widgets.get("bc")

dbutils.widgets.text("storageaccount","")
storageaccount=dbutils.widgets.get("storageaccount")

# COMMAND ----------

# tablenamedemo = "GlobalMRNdemographicsstaging"
# path_conn_file = ""
# sqoop_output_path_demo = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data/gmrn/staging/sqoop-data/globalmrndemo/"
# hdfs_data_input = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data/dataingestion/publish/"
# icddb = "zescantemp.dbo."
# bc = "20240829T06"
# storageaccount = "prodicdstgdls"

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

demo_schema = StructType([
    StructField("GlobalMRNdemographicsIPK", LongType(), False),
    StructField("GlobalMRNIFK", LongType(), False),  
    StructField("PatientAcctIFK", LongType(), False),
    StructField("HospitalFK", ShortType(), True),
    StructField("FirstName", StringType(), False),
    StructField("Middlename", StringType(), False),
    StructField("LastName", StringType(), True),
    StructField("Suffix", StringType(), False),
    StructField("DOB", TimestampType(), False),  
    StructField("SSN", StringType(), False),     
    StructField("Gender", StringType(), False),
    StructField("Addr1", StringType(), False),
    StructField("City", StringType(), False),
    StructField("State", StringType(), False),      
    StructField("Zip", StringType(), True),
    StructField("Phone1", StringType(), False),   
    StructField("MedicaidNum", StringType(), False),
    StructField("MedicareHIC", StringType(), False),      
    StructField("IgnoreFlag", StringType(), True),
    StructField("Createdate", TimestampType(), False),      
    StructField("isdeletedflag", StringType(), False)        
    ])

# COMMAND ----------

demo = spark.read.option("header",False).option("recursiveFileLookup","true").schema(demo_schema).options(delimiter="\x01").format("csv").load(sqoop_output_path_demo+"/"+bc)

# COMMAND ----------

# DBTITLE 1,TEMPORARY PURGE LOGIC
demo.createOrReplaceTempView("demo")
# print("BEFORE PURGE COUNT : "+str(demo.count()))
purge=spark.read.format("parquet").load(hdfs_data_input + "hospitalpurge/current/20991231/")
purge=purge.filter("active=='1'").selectExpr("hospitalfk").dropDuplicates()
purge.createOrReplaceTempView("purge")
demo=spark.sql("""SELECT * FROM demo WHERE CAST(hospitalfk AS BIGINT) NOT IN (SELECT CAST(hospitalfk AS BIGINT) FROM purge)""").dropDuplicates()
# print("BEFORE PURGE COUNT : "+str(demo.count()))

# COMMAND ----------

demo.write.format('jdbc').mode('append').option('driver', 'com.microsoft.sqlserver.jdbc.SQLServerDriver').option \
        ('url', path_conn_file).option('dbtable', icddb+tablenamedemo).save()
