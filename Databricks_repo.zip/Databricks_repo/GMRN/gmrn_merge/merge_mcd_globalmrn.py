# Databricks notebook source
from pyspark.sql.functions import *
from datetime import datetime

# COMMAND ----------

start=datetime.now()
print(start)

# COMMAND ----------

dbutils.widgets.text("hdfs_match_output" , "")
hdfs_output = dbutils.widgets.get("hdfs_match_output")

dbutils.widgets.text("hdfs_temp_path", "")
hdfs_temp_path = dbutils.widgets.get("hdfs_temp_path")

dbutils.widgets.text("swift_mode", "")
swift_mode = dbutils.widgets.get("swift_mode")

dbutils.widgets.text("storageaccount","")
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text("stagedPatientacctsTableName","")
stagedPatientacctsTableName = dbutils.widgets.get("stagedPatientacctsTableName")

dbutils.widgets.text("stagedGlobalmrndemographicsTableName","")
stagedGlobalmrndemographicsTableName = dbutils.widgets.get("stagedGlobalmrndemographicsTableName")

dbutils.widgets.text("mergedGlobalMrnTableName","")
mergedGlobalMrnTableName = dbutils.widgets.get("mergedGlobalMrnTableName")

# COMMAND ----------

# bc = "20250522T06"
# base_url = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data"
# hdfs_output = f"{base_url}/gmrn/staging/matches/merge/{bc}"
# hdfs_temp_path = f"{base_url}/gmrn/staging/gmrn_mcd/"
# swift_mode = "0"
# stagedPatientacctsTableName = f"regular_staged_patientaccts_{bc}"
# stagedGlobalmrndemographicsTableName = f"regular_staged_globalmrndemographics_{bc}"
# mergedGlobalMrnTableName = f"merged_global_mrn_{bc}"
# storageaccount = "prodicdstgdls"

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.skewJoin.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "auto")
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/tu_data_quality"

# COMMAND ----------

# MAGIC %run "/Insleads-code/GMRN/gmrn_merge/match_util"

# COMMAND ----------

selectedCols=["globalmrnifk","firstname","dob","lastname","phone","zip","addrnum","medicaidnum","fn_valid","dob_valid","ln_valid","phone_valid","zip_valid","addrnum_valid","mcd_valid"]

# COMMAND ----------

if int(swift_mode)==1:
  df_pa = spark.read.table(stagedPatientacctsTableName).select(selectedCols)
  df_gd = spark.read.table(stagedGlobalmrndemographicsTableName).select(selectedCols)

  df_pa_2 = df_pa.where( (df_pa.mcd_valid == 1) &\
                         (df_pa.fn_valid == 1) \
                       )

  df_gd_2 = df_gd.where( (df_gd.mcd_valid == 1) &\
                         (df_gd.fn_valid == 1) \
                       )

  left = df_pa_2.alias('left')
  right= df_gd_2.alias('right')
else:
  df_all = spark.read.table(mergedGlobalMrnTableName).select(selectedCols)
  df_all = df_all.where( (df_all.mcd_valid == 1) &\
                         (df_all.fn_valid == 1) \
                       )
  left = df_all.alias('left')
  right= df_all.alias('right')

# COMMAND ----------

# create MCD/FN based list
selectCols =  [ "left." + s for s in left.schema.names] +\
              [ "right." + s for s in right.schema.names]

newCols = [s.replace('.', '_') for s in selectCols]

# COMMAND ----------

# join based on criteria
joinExpr = (left.medicaidnum == right.medicaidnum) & (left.firstname == right.firstname) & (left.globalmrnifk!=right.globalmrnifk)
df = left.join(right, joinExpr).select(selectCols).toDF(*newCols)
df.dropDuplicates().write.mode("overwrite").format("parquet").save(hdfs_temp_path)

# COMMAND ----------

df = spark.read.parquet(hdfs_temp_path)

# COMMAND ----------

# building where expression each of the rules
whereExprs = {
    "dob15":(df.left_dob_valid == 1) & (df.right_dob_valid == 1) & (abs(datediff(df.left_dob,df.right_dob))<5475) ,
    "dob":(df.left_dob_valid == 1) & (df.right_dob_valid == 1) &  (df.left_dob == df.right_dob),
    "lastname":(df.left_ln_valid == 1) & (df.right_ln_valid == 1)  & (df.left_lastname== df.right_lastname),
    "phone":(df.left_phone_valid == 1) & (df.right_phone_valid == 1) & (df.left_phone == df.right_phone),
    "addrnum":(df.left_addrnum_valid == 1) & (df.right_addrnum_valid == 1) & (df.left_zip_valid == 1) & (df.right_zip_valid == 1) & (df.left_zip == df.right_zip) & (address_udf(df.left_addrnum,df.right_addrnum) == 1),
    "firstname":(df.left_fn_valid == 1) & (df.right_fn_valid == 1)  & (df.left_firstname == df.right_firstname)         
}

# COMMAND ----------

matchExprs = {
    #45 MCD + FN + DOB + LN
    "45":whereExprs.get("dob") & whereExprs.get("lastname") ,
    #49 MCD + FN + DOB15 + Addrnum
    "49":whereExprs.get("dob15") & whereExprs.get("addrnum")  ,
    #51 MCD + FN + DOB15 + PH
    "51":whereExprs.get("dob15") & whereExprs.get("phone")  
}

# COMMAND ----------

# writing out the mcr matches 
selectColsGMRNs = ['left_globalmrnifk','right_globalmrnifk']
for matchType in matchExprs:
    result = df.where(matchExprs[matchType]).select(selectColsGMRNs).withColumn("matchtype", lit(matchType))    
    result.dropDuplicates().write.mode("overwrite").format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="|").save(hdfs_output +"/" + matchType)
