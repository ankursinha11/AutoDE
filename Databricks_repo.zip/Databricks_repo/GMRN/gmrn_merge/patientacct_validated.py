# Databricks notebook source
# MAGIC %md
# MAGIC patientacct_validated

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
import datetime
from pyspark.sql.window import Window

# COMMAND ----------

dbutils.widgets.text("bc", "")
bc = dbutils.widgets.get("bc")

dbutils.widgets.text("hdfs_data_input","")
hdfs_data_input = dbutils.widgets.get("hdfs_data_input")

dbutils.widgets.text("hdfs_gmrn_publish","")
hdfs_gmrn_publish = dbutils.widgets.get("hdfs_gmrn_publish")

dbutils.widgets.text("hdfs_output", "")
hdfs_output = dbutils.widgets.get("hdfs_output")

dbutils.widgets.text("hdfs_permid_input", "")
hdfs_permid_input = dbutils.widgets.get("hdfs_permid_input")

dbutils.widgets.text("swift_mode","")
swift_mode = dbutils.widgets.get("swift_mode")

dbutils.widgets.text("storageaccount","")
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text("input_aid_patientaccts","")
input_aid_patientaccts = dbutils.widgets.get("input_aid_patientaccts")

dbutils.widgets.text("workflowtype","")
workflowtype = dbutils.widgets.get("workflowtype")

# COMMAND ----------

# bc = "20250522T06"
# base_url = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data"
# storageaccount = "prodicdstgdls"
# workflowtype = "regular"
# hdfs_data_input = f"{base_url}/dataingestion/publish/"
# hdfs_gmrn_publish = f"{base_url}/gmrn/publish/"
# hdfs_output = f"{base_url}/gmrn/staging/staged_all/staged_patientaccts/"
# hdfs_permid_input = f"{base_url}/cdd/publish/permidpatientacctid/"
# swift_mode = "0"
# input_aid_patientaccts = f"{base_url}/dataingestion/staging/input/patientaccts/"

# COMMAND ----------

spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)
spark.conf.set("spark.sql.shuffle.partitions","auto")
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/tu_data_quality"

# COMMAND ----------

selcols = ['patientacctipk', 'firstname', 'lastname', 'dob', 'ssn', 'gender', 'addr1', 'city', 'state', 'zip', 'phone1', 'medicaidnum', \
           'medicarehic', 'medicalrecnum', 'hospitalfk', 'createdate']

# COMMAND ----------

# DBTITLE 1,SWIFT LOGIC
if int(swift_mode) == 1:
    print("AID MODE")
    input_aid_patientaccts=input_aid_patientaccts+"/"+bc
    print("input_aid_patientaccts : "+str(input_aid_patientaccts))
    paccts=spark.read.parquet(input_aid_patientaccts).select(selcols)
    paccts.createOrReplaceTempView("paccts")
    patientacctsaccesscoordinator = spark.read.format("parquet").load(hdfs_data_input + "/patientacctsaccesscoordinator/current/20991231/")
    patientacctsaccesscoordinator = patientacctsaccesscoordinator.selectExpr("patientacctifk as patientacctipk","hospitalfk").dropDuplicates()
    filterBc="bcupdated=='"+bc+"'"
    path_aidpatientaccts = hdfs_data_input + "/aidpatientaccts/current/20991231/"
    aidpatientaccts = spark.read.format("delta").load(path_aidpatientaccts).filter(filterBc).selectExpr("patientacctifk as patientacctipk","hospitalfk").dropDuplicates()
    patientacctsaccesscoordinator = patientacctsaccesscoordinator.union(aidpatientaccts)
    patientacctsaccesscoordinator.createOrReplaceTempView("patientacctsaccesscoordinator")
    paccts=spark.sql("""SELECT paccts.* FROM paccts INNER JOIN patientacctsaccesscoordinator ON paccts.hospitalfk=patientacctsaccesscoordinator.hospitalfk AND paccts.patientacctipk=patientacctsaccesscoordinator.patientacctipk""")
    # print(str(paccts.count()))
else:
    print("REGULAR MODE")
    paccts = spark.read.format("delta").load(hdfs_data_input + "/patientaccts/current/20991231/").select(selcols)
    enddt = date_sub(current_date(), 365)
    paccts = paccts.where((paccts.createdate >= enddt))
    # print(str(paccts.count()))

# COMMAND ----------

for column in paccts.columns:
    paccts = paccts.withColumn(column, regexp_replace(col(column), r'[^\x00-\x7f]', r''))
    paccts = paccts.withColumn(column, trim(col(column)))

# COMMAND ----------

gmrnxpa = spark.read.parquet(hdfs_gmrn_publish + "/globalmrnxpacct/current" +"/*").select('globalmrnifk', 'patientacctifk', 'hospitalfk')

# COMMAND ----------

# MAGIC %md
# MAGIC Get All patients which are not yet in gmrnxpaccts

# COMMAND ----------

pa_query = """
            SELECT pa.*
            FROM {paccts} pa
            LEFT JOIN {gmrnxpa} gmrnxpa
                ON pa.patientacctipk = gmrnxpa.patientacctifk AND pa.hospitalfk = gmrnxpa.hospitalfk
            WHERE gmrnxpa.globalmrnifk IS NULL
        """

patientaccts = spark.sql(pa_query, paccts = paccts, gmrnxpa = gmrnxpa)

# COMMAND ----------

# MAGIC %md
# MAGIC Load permid x pacct and hhpermid list per pacct

# COMMAND ----------

permid = spark.read.option("recursiveFileLookup","true").parquet(hdfs_permid_input).dropDuplicates()

# COMMAND ----------

hh = permid.filter((permid.matchind == 'HM') | (permid.matchind == 'IM')).select('permid', 'magnetpermid').dropDuplicates()

# COMMAND ----------

hh = hh.groupBy("permid").agg(collect_set("magnetpermid").alias("hhlist"))

# COMMAND ----------

permid = permid.filter(permid.matchind == 'IM').select('patientacctifk', 'hospitalfk', 'permid')

# COMMAND ----------

hh.createOrReplaceTempView("hhview")
gmrnxpa.createOrReplaceTempView("globalmrnxpacct")
permid.createOrReplaceTempView("patientacctxpermid")
patientaccts.createOrReplaceTempView("patientaccts")

# COMMAND ----------

permid = """
SELECT  DISTINCT pa.patientacctipk, pa.hospitalfk, pp.permid
FROM patientaccts pa
LEFT JOIN patientacctxpermid pp ON pa.patientacctipk = pp.patientacctifk AND pa.hospitalfk = pp.hospitalfk
"""

# COMMAND ----------

df1 = spark.sql(permid)

# COMMAND ----------

df1.createOrReplaceTempView("permid")

# COMMAND ----------

hhpermid = """
SELECT p.patientacctipk, p.hospitalfk, p.permid, hv.hhlist
FROM permid p
LEFT JOIN hhview hv ON hv.permid=p.permid
"""

# COMMAND ----------

df2 = spark.sql(hhpermid)

# COMMAND ----------

df2.createOrReplaceTempView("hhpermid")

# COMMAND ----------

# MAGIC %md
# MAGIC Logic to get policyID for patientaccts

# COMMAND ----------

patientacctscodes = spark.read.format("delta").load(hdfs_data_input + "/patientacctscodes/current/20991231/")

# COMMAND ----------

hospinsurancecodes = spark.read.format("delta").load(hdfs_data_input + "/hospinsurancecodes/current/20991231/")

# COMMAND ----------

patientacctscodes.createOrReplaceTempView("patientacctscodes")
hospinsurancecodes.createOrReplaceTempView("hospinsurancecodes")

# COMMAND ----------

pacctscodesxpaccts = spark.sql("""SELECT c.patientacctifk,x.hospitalfk,c.insurancecode1,c.insurancecode2,c.insurancecode3,c.insurancecode4,\
                                          c.ins1policyid,c.ins2policyid,c.ins3policyid,c.ins4policyid \
                                   FROM   patientaccts x inner join patientacctscodes c on \
                                          c.hospitalfk=x.hospitalfk and c.patientacctifk=x.patientacctipk""")

# COMMAND ----------

pacctscodesxpaccts.createOrReplaceTempView("pacctpolicy")

# COMMAND ----------

policyid = spark.sql("""
 select patientacctifk,hospitalfk ,insurancecode ,inspolicy
 from (
 select c.patientacctifk,c.hospitalfk ,c.insurancecode1 as insurancecode ,c.ins1policyid as inspolicy
 from pacctpolicy c
 inner join hospinsurancecodes i on i.hospitalfk=c.hospitalfk and trim(upper(i.code)) = trim(upper(c.insurancecode1))
 where c.insurancecode1 !='' 
 UNION
 select c.patientacctifk,c.hospitalfk ,c.insurancecode2 as insurancecode ,c.ins2policyid as inspolicy
 from pacctpolicy c
 inner join hospinsurancecodes i on i.hospitalfk=c.hospitalfk and trim(upper(i.code)) = trim(upper(c.insurancecode2))
 where c.insurancecode2 !=''
 UNION
 select c.patientacctifk,c.hospitalfk ,c.insurancecode3 as insurancecode ,c.ins3policyid as inspolicy
 from pacctpolicy c
 inner join hospinsurancecodes i on i.hospitalfk=c.hospitalfk and trim(upper(i.code)) = trim(upper(c.insurancecode3))
 where c.insurancecode3 !='')
""")

# COMMAND ----------

policyid = policyid.withColumn('inspolicy', regexp_replace(policyid.inspolicy, '[^A-Za-z0-9]', ''))

# COMMAND ----------

isValidPolicy_udf = udf(isValidPolicy, IntegerType())

# COMMAND ----------

policyid = policyid.withColumn('policyid_valid', isValidPolicy_udf(policyid.inspolicy))

# COMMAND ----------

policyid = policyid.filter(~policyid.inspolicy.like("%000000"))

# COMMAND ----------

policyid = policyid \
    .dropDuplicates() \
    .filter(policyid.policyid_valid == 1)

# COMMAND ----------

policyid = policyid.groupBy(["patientacctifk", "hospitalfk"]).agg(collect_set("inspolicy").alias("policyid"))

# COMMAND ----------

policyid.createOrReplaceTempView("pacctpolicyid")

# COMMAND ----------

mrnlist = patientaccts.select("patientacctipk", "hospitalfk", "medicalrecnum")

# COMMAND ----------

isValidMRN_udf = udf(isValidMRN, IntegerType())

# COMMAND ----------

mrnlist = mrnlist.withColumn('mrn_valid', isValidMRN_udf(mrnlist.medicalrecnum))

# COMMAND ----------

mrnlist = mrnlist.dropDuplicates().filter(mrnlist.mrn_valid == 1)

# COMMAND ----------

mrnlist = mrnlist.select("patientacctipk", "hospitalfk", array(concat_ws('~', patientaccts.hospitalfk, patientaccts.medicalrecnum)).alias("mrnlist"))

# COMMAND ----------

# mrnlist = mrnlist.groupBy("patientacctipk","hospitalfk").agg(collect_set("mrn_id").alias("mrnlist"))
mrnlist.createOrReplaceTempView("mrnlist")

# COMMAND ----------

# MAGIC %md
# MAGIC Final Join to get all the required Data

# COMMAND ----------

joinSQL = """
SELECT
  concat("T", g.patientacctipk, "_", g.hospitalfk) as globalmrnifk,
  g.firstname as firstname,
  g.lastname as lastname,
  g.dob as dob,
  g.ssn as ssn,
  g.gender as gender,
  g.addr1 as addrnum,
  g.city as city,
  g.state as state,
  g.zip as zip,
  g.phone1 as phone,
  g.medicaidnum as medicaidnum,
  g.medicarehic as medicarehic,
  m.mrnlist as medicalrecnum,
  gpa.hhlist as hhpermid,
  p.policyid,
  gpa.permid
FROM hhpermid gpa
INNER JOIN patientaccts g ON g.patientacctipk = gpa.patientacctipk AND gpa.hospitalfk = g.hospitalfk
left join pacctpolicyid p on p.patientacctifk = g.patientacctipk AND p.hospitalfk = g.hospitalfk
left join mrnlist m on m.patientacctipk = g.patientacctipk AND m.hospitalfk = g.hospitalfk
"""

# COMMAND ----------

pd = spark.sql(joinSQL)

# COMMAND ----------

# Trim and remove non printable characters
# for column in pd.columns:
#  if (column != "medicalrecnum" and column != "policyid" and column != "hhpermid"):
#    pd = pd.withColumn(column, regexp_replace(col(column),r'[^\x00-\x7f]',r''))
#    pd = pd.withColumn(column, trim(col(column)))

# COMMAND ----------

# MAGIC %md
# MAGIC Create validation UDF functions

# COMMAND ----------

isValidName_udf = udf(isValidName, IntegerType())
isValidDOB_udf = udf(isValidDOB, IntegerType())
isValidSSN_udf = udf(isValidSSN, IntegerType())
isValidGender_udf = udf(isValidGender, IntegerType())
isValidCity_udf = udf(isValidCity, IntegerType())
isValidState_udf = udf(isValidState, IntegerType())
isValidZip_udf = udf(isValidZip, IntegerType())
isValidPhone_udf = udf(isValidPhone, IntegerType())
isValidString_udf = udf(isValidString, IntegerType())
isValidMCD_udf = udf(isValidMCD, IntegerType())
isValidMCR_udf = udf(isValidMCR, IntegerType())
isValidPID_udf = udf(isValidPID, IntegerType())
isValidNumber_udf = udf(isNumber, IntegerType())

# COMMAND ----------

# MAGIC %md
# MAGIC cleanse and trim

# COMMAND ----------

pd = pd.withColumn('firstname', upper(pd.firstname))
pd = pd.withColumn('lastname', upper(pd.lastname))
pd = pd.withColumn('gender', upper(pd.gender))
pd = pd.withColumn('city', upper(pd.city))
pd = pd.withColumn('state', upper(pd.state))
pd = pd.withColumn('addrnum', regexp_extract(pd.addrnum, '\d+', 0))
pd = pd.withColumn('zip', regexp_extract(pd.zip, '\d\d\d\d\d', 0))
pd = pd.withColumn('phone', regexp_replace(pd.phone, '[^0-9]', ''))
pd = pd.withColumn('dob', regexp_extract(pd.dob, '\d+-\d+-\d+', 0))
pd = pd.withColumn('city', regexp_replace(pd.city, '[^A-Za-z\s]', ''))
pd = pd.withColumn('city', regexp_replace(pd.city, 'XX', ''))
pd = pd.withColumn('city', regexp_replace(pd.city, 'YY', ''))
pd = pd.withColumn('city', trim(pd.city))
pd = pd.withColumn('state', regexp_replace(pd.state, 'XX', ''))
pd = pd.withColumn('state', regexp_replace(pd.state, 'YY', ''))
pd = pd.withColumn('state', regexp_replace(pd.state, '[^A-Za-z\s]', ''))
pd = pd.withColumn('state', trim(pd.state))


# COMMAND ----------

# MAGIC %md 
# MAGIC add validation columns

# COMMAND ----------

pd = pd.withColumn('fn_valid', isValidName_udf(pd.firstname))
pd = pd.withColumn('ln_valid', isValidName_udf(pd.lastname))
pd = pd.withColumn('dob_valid', isValidDOB_udf(pd.dob))
pd = pd.withColumn('gender_valid', isValidGender_udf(pd.gender))
pd = pd.withColumn('ssn_valid', isValidSSN_udf(pd.ssn))
pd = pd.withColumn('city_valid', isValidCity_udf(pd.city))
pd = pd.withColumn('state_valid', isValidState_udf(pd.state))
pd = pd.withColumn('zip_valid', isValidZip_udf(pd.zip))
pd = pd.withColumn('phone_valid', isValidPhone_udf(pd.phone))
new_mrn_valid = when(col("medicalrecnum").isNull(), 0).otherwise(1)
pd = pd.withColumn('mrn_valid', new_mrn_valid)
new_policy_valid = when(col("policyid").isNull(), 0).otherwise(1)
pd = pd.withColumn('policyid_valid', new_policy_valid)
new_hh_valid = when(col("hhpermid").isNull(), 0).otherwise(1)
pd = pd.withColumn('hhpermid_valid', new_hh_valid)
pd = pd.withColumn('mcr_valid', isValidMCR_udf(pd.medicarehic))
pd = pd.withColumn('mcd_valid', isValidMCD_udf(pd.medicaidnum))
pd = pd.withColumn('pid_valid', isValidPID_udf(pd.permid))
pd = pd.withColumn('addrnum_valid', isValidNumber_udf(pd.addrnum))

# COMMAND ----------

print(hdfs_output + "/" + bc)

# COMMAND ----------

# DBTITLE 1,Write staged patientaccts data to delta table
tableName = f"{workflowtype}_staged_patientaccts_{bc}"
dropSql = f"DROP TABLE IF EXISTS {tableName}"
spark.sql(dropSql)
pd.dropDuplicates().write.mode("overwrite").format("delta").option("path", hdfs_output + bc).saveAsTable(tableName)
if workflowtype == 'aid':
    cluterBySql = f"ALTER TABLE {tableName} CLUSTER BY (state, city, dob, firstname)"
    optimizeSql = f"OPTIMIZE {tableName}"
    spark.sql(cluterBySql)
    spark.sql(optimizeSql)

# COMMAND ----------

# data=spark.read.table(tableName)
# data.count()

# COMMAND ----------

dbutils.notebook.exit({"stagedPatientacctsTableName": tableName})
