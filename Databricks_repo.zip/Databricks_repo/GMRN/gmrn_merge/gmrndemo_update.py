# Databricks notebook source
# MAGIC %md
# MAGIC GMRN Merge

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
import datetime
from pyspark.sql.window import Window

# COMMAND ----------

dbutils.widgets.text("bc","")
bc = dbutils.widgets.get("bc")

dbutils.widgets.text("hdfs_gmrn_publish","")
hdfs_gmrn_publish = dbutils.widgets.get("hdfs_gmrn_publish")

dbutils.widgets.text("hdfs_data_input","")
hdfs_data_input = dbutils.widgets.get("hdfs_data_input")

dbutils.widgets.text("hdfs_gdemo_update_path", "")
hdfs_gdemo_update_path = dbutils.widgets.get("hdfs_gdemo_update_path")

dbutils.widgets.text("hdfs_prepublish_globalmrnxdemo_output", "")
hdfs_prepublish_globalmrnxdemo_output = dbutils.widgets.get("hdfs_prepublish_globalmrnxdemo_output")

dbutils.widgets.text("hdfs_intmd_tmp_key_path", "")
hdfs_intmd_tmp_key_path = dbutils.widgets.get("hdfs_intmd_tmp_key_path")

dbutils.widgets.text("storageaccount","")
storageaccount = dbutils.widgets.get("storageaccount")

# COMMAND ----------

# bc = "20250522T06"
# base_url = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data"
# hdfs_gmrn_publish = f"{base_url}/gmrn/publish/"
# hdfs_data_input = f"{base_url}/dataingestion/publish/"
# hdfs_gdemo_update_path = f"{base_url}/gmrn/staging/sot/tmp_op/gdemo_update/"
# hdfs_prepublish_globalmrnxdemo_output = f"{base_url}/gmrn/staging/sot/prepublish_op/globalmrndemographics/"
# hdfs_intmd_tmp_key_path = f"{base_url}/gmrn/publish/globalmrn/sot/keycreationtmp/"
# storageaccount = "prodicdstgdls"

# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions", "auto")
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

current_dt=datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]

# COMMAND ----------

def addpkvalue(val,row_number):
   val = val + row_number
   return val

# COMMAND ----------

# MAGIC %md
# MAGIC declaration of variables

# COMMAND ----------

static_dd = '2099-12-31'
numeric_lit = 0

# COMMAND ----------

date_range=datetime.datetime.now() - datetime.timedelta(days=1*7) # Actual
# date_range=datetime.datetime.now() - datetime.timedelta(days=1*150)  # temporary to work
# print(date_range)

# COMMAND ----------

gdemo = spark.read.parquet(hdfs_gmrn_publish + "/globalmrndemographics/current" + "/*")

# COMMAND ----------

gdemo1=gdemo.withColumn("globalmrndemographicsipklong",gdemo.globalmrndemographicsipk.cast(LongType()))

# COMMAND ----------

# MAGIC %md
# MAGIC getting the max key from existing gdemo table and formatting the columns

# COMMAND ----------

mxval = gdemo1.where(col("globalmrndemographicsipklong").isNotNull()) \
       .agg({"globalmrndemographicsipklong": "max"}).collect()[0][0]

# COMMAND ----------

numeric_lit = mxval

# COMMAND ----------

for column in gdemo.columns:
    gdemo = gdemo.withColumn(column, regexp_replace(col(column),r'[^\x00-\x7f]',r''))
    gdemo = gdemo.withColumn(column, trim(upper(col(column))))
    gdemo = gdemo.withColumn(column, (coalesce(col(column),lit(''))))

# COMMAND ----------

gdemo = gdemo.withColumn('dob',regexp_extract(gdemo.dob,'\d+-\d+-\d+',0))
gdemo = gdemo.withColumn('addr1',regexp_extract(gdemo.addr1,'\d+',0))

# COMMAND ----------

# MAGIC %md
# MAGIC list of pa columns for demo update check and taking only past 7 days demo change accounts and formatting the column for null etc .

# COMMAND ----------

pa_col = ['patientacctipk','hospitalfk','demographicsupdatedate','firstname','middlename','lastname','suffix','dob','ssn','gender','addr1','addr2','city','state','zip','phone1','medicaidnum','medicarehic']

# COMMAND ----------

# pa = DeltaTable.forPath(spark,hdfs_input+ "/patientaccts/current/20991231/").toDF().select(pa_col).filter(to_timestamp("demographicsupdatedate",'yyyy-MM-dd HH:mm:ss ZZ') > lit(date_range))
pa = spark.read.format("delta").load(hdfs_data_input+ "/patientaccts/current/20991231/").select(pa_col).filter(to_timestamp("demographicsupdatedate",'yyyy-MM-dd HH:mm:ss ZZ') > lit(date_range))

# COMMAND ----------

for column in pa.columns:
    pa = pa.withColumn(column, trim(upper(col(column))))
    pa = pa.withColumn(column, (coalesce(col(column),lit(''))))

# COMMAND ----------

pa = pa.withColumn('dob',regexp_extract(pa.dob,'\d+-\d+-\d+',0))
pa = pa.withColumn('addr1',concat_ws(' ',pa.addr1,pa.addr2)).drop('addr2')
pa = pa.withColumn('addr1',regexp_extract(pa.addr1,'\d+',0))

# COMMAND ----------

# MAGIC %md
# MAGIC joining to globalmrnxpacct to get records with gmrn assigned

# COMMAND ----------

gxpa = spark.read.parquet(hdfs_gmrn_publish+"/globalmrnxpacct/current" +"/*").select("globalmrnifk","patientacctifk","hospitalfk","createdate")

# COMMAND ----------

jn = [pa.patientacctipk == gxpa.patientacctifk, pa.hospitalfk == gxpa.hospitalfk]

# COMMAND ----------

# MAGIC %md
# MAGIC join cond for gmrninplay and pa to get only records where createdate < patientacctdemographic update date

# COMMAND ----------

colsforcompare=["globalmrnifk","firstname","middlename","lastname","dob","ssn","gender","addr1","city","state","zip","phone1","medicaidnum","medicarehic"]

# COMMAND ----------

gmrninplay = gxpa.join(pa,jn,"inner")\
                 .where(gxpa.createdate<pa.demographicsupdatedate)\
                 .select(gxpa.globalmrnifk,gxpa.patientacctifk,gxpa.hospitalfk,pa.firstname,pa.middlename,pa.lastname,pa.suffix,pa.dob,pa.ssn,pa.gender,pa.addr1,pa.city,pa.state,pa.zip,pa.phone1,pa.medicaidnum,pa.medicarehic)

# COMMAND ----------

# This gives the demographics that was originated/created by the very first patientaccifk & hospitalfk combination

group_cols = ["globalmrnifk","firstname","middlename","lastname","suffix","dob","ssn","gender","addr1","city","state","zip","phone1","medicaidnum","medicarehic"]

gmrninplay2 = gmrninplay.withColumn("row_number", row_number().over(Window.partitionBy(*group_cols).orderBy("patientacctifk", "hospitalfk"))).filter("row_number = 1").drop("row_number")

# COMMAND ----------

# MAGIC %md 
# MAGIC left_anti should give everything in gmrninplay and not exists in gmrndemo

# COMMAND ----------

gmrn_dup = gmrninplay2\
                 .join(gdemo,colsforcompare,"left_anti")\
                 .select(gmrninplay2['*']).dropDuplicates()

# COMMAND ----------

gmrn_dup = gmrn_dup.withColumn("ignoreflag",lit(0))

# COMMAND ----------

# MAGIC %md 
# MAGIC creating  records with updated colummn value and assign new key for them 

# COMMAND ----------

gmrn_formatted = gmrn_dup.withColumn("staticdate",lit(static_dd))

# COMMAND ----------

udf_addpkvalue = udf(addpkvalue, LongType())

# COMMAND ----------

gmrn_stage1 = gmrn_formatted\
                 .withColumn("row_number", row_number()\
                 .over(Window.partitionBy("staticdate")\
                 .orderBy("staticdate")))

# COMMAND ----------

# MAGIC %md 
# MAGIC prepare all columns

# COMMAND ----------

gmrn_stage2 = gmrn_stage1.withColumn("globalmrndemographicsipk",udf_addpkvalue(lit(numeric_lit),gmrn_stage1.row_number))

# COMMAND ----------

gmrn_stage2 = gmrn_stage2.select(gmrn_stage2.globalmrndemographicsipk,gmrn_stage2.globalmrnifk,gmrn_stage2.patientacctifk,gmrn_stage2.hospitalfk,gmrn_stage2.firstname,gmrn_stage2.middlename \
                                 ,gmrn_stage2.lastname,gmrn_stage2.suffix,gmrn_stage2.dob,gmrn_stage2.ssn,gmrn_stage2.gender,gmrn_stage2.addr1,gmrn_stage2.city,gmrn_stage2.state \
                                 ,gmrn_stage2.zip,gmrn_stage2.phone1,gmrn_stage2.medicaidnum,gmrn_stage2.medicarehic,gmrn_stage2.ignoreflag) 

# COMMAND ----------

gmrn_stage2 = gmrn_stage2.withColumn("dob", date_format("dob","yyyy-MM-dd HH:mm:ss.SSS"))
gmrn_stage2 = gmrn_stage2.withColumn("createdate",lit(current_dt))

# COMMAND ----------

# MAGIC %md 
# MAGIC writing out keys because of use of row_number sometimes messes things up

# COMMAND ----------

gmrn_stage2.write.mode("overwrite").parquet(hdfs_intmd_tmp_key_path+"/gdemo_update_keys/")

# COMMAND ----------

# MAGIC %md 
# MAGIC read the keys back again

# COMMAND ----------

gdemo_update = spark.read.parquet(hdfs_intmd_tmp_key_path+"/gdemo_update_keys/*")

# COMMAND ----------

gdemo_new = gdemo.unionAll(gdemo_update)

# COMMAND ----------

# gdemo_new.write.mode("overwrite").parquet(hdfs_prepublish_globalmrnxdemo_output+bc)
gdemo_new.write.mode("overwrite").parquet(hdfs_prepublish_globalmrnxdemo_output+ "/" + bc)

# COMMAND ----------

gmrn_update = gdemo_update.withColumn("isdeletedflag",lit(0))

# COMMAND ----------

# MAGIC %md write out the new records

# COMMAND ----------

gmrn_update.repartition(1).write.mode("overwrite").format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="\x01").save(hdfs_gdemo_update_path + bc+"/ins/")
