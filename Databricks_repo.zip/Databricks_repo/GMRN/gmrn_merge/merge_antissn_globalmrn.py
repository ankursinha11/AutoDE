# Databricks notebook source
from datetime import datetime
from pyspark.sql.functions import *

# COMMAND ----------

# DBTITLE 1,Start counter
start=datetime.now()
print(start)

# COMMAND ----------

dbutils.widgets.text("hdfs_match_output", "")
hdfs_output= dbutils.widgets.get("hdfs_match_output")

dbutils.widgets.text("hdfs_temp_path", "")
hdfs_temp_path= dbutils.widgets.get("hdfs_temp_path")

dbutils.widgets.text("swift_mode", "")
swift_mode= dbutils.widgets.get("swift_mode")

dbutils.widgets.text("storageaccount","")
storageaccount=dbutils.widgets.get("storageaccount")

dbutils.widgets.text("stagedPatientacctsTableName","")
stagedPatientacctsTableName = dbutils.widgets.get("stagedPatientacctsTableName")

dbutils.widgets.text("stagedGlobalmrndemographicsTableName","")
stagedGlobalmrndemographicsTableName = dbutils.widgets.get("stagedGlobalmrndemographicsTableName")

dbutils.widgets.text("mergedGlobalMrnTableName","")
mergedGlobalMrnTableName = dbutils.widgets.get("mergedGlobalMrnTableName")

# COMMAND ----------

# bc = "20250522T06"
# base_url = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data"
# hdfs_output = f"{base_url}/gmrn/staging/matches/merge/{bc}"
# hdfs_temp_path = f"{base_url}/gmrn/staging/gmrn_antisimssn/"
# swift_mode = "0"
# stagedPatientacctsTableName = f"regular_staged_patientaccts_{bc}"
# stagedGlobalmrndemographicsTableName = f"regular_staged_globalmrndemographics_{bc}"
# mergedGlobalMrnTableName = f"merged_global_mrn_{bc}"
# storageaccount = "prodicdstgdls"

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/tu_data_quality"
# MAGIC

# COMMAND ----------

# MAGIC %run "/Insleads-code/GMRN/gmrn_merge/match_util" 
# MAGIC

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.skewJoin.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "auto")
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

selectedCols=["globalmrnifk","firstname","dob","lastname","phone","city","state","zip","addrnum","medicalrecnum","ssn","fn_valid","dob_valid","ln_valid","phone_valid","city_valid","state_valid","zip_valid","addrnum_valid","mrn_valid","ssn_valid"]


# COMMAND ----------

if int(swift_mode)==1:
  df_pa = spark.read.table(stagedPatientacctsTableName).select(selectedCols)
  df_gd = spark.read.table(stagedGlobalmrndemographicsTableName).select(selectedCols)
 
  df_pa_2 = df_pa.where((df_pa.fn_valid == 1) & (df_pa.dob_valid == 1) & (df_pa.city_valid == 1) & (df_pa.state_valid == 1))
  df_gd_2 = df_gd.where((df_gd.fn_valid == 1) & (df_gd.dob_valid == 1) & (df_gd.city_valid == 1) & (df_gd.state_valid == 1)) 

  left = df_pa_2.alias('left')
  right= df_gd_2.alias('right')
else:
    df_all = spark.read.table(mergedGlobalMrnTableName).select(selectedCols)
    df_all = df_all.where((df_all.fn_valid == 1) & (df_all.dob_valid == 1) & (df_all.city_valid == 1) & (df_all.state_valid == 1))

    left = df_all.alias('left')
    right= df_all.alias('right')
 

# COMMAND ----------

selectCols =  [ "left." + s for s in left.schema.names] +\
              [ "right." + s for s in right.schema.names]

newCols = [s.replace('.', '_') for s in selectCols]

#FN,DOB,City,State, data frame is df
joinExpr = (left.dob == right.dob) & \
           (left.firstname == right.firstname) & \
           (left.city == right.city) & \
           (left.state == right.state) & \
           (left.globalmrnifk != right.globalmrnifk)

if int(swift_mode)==1:
  e=broadcast(left)
  df = right.join(broadcast(e),joinExpr).select(selectCols).toDF(*newCols)
else:
  df = left.join(right, joinExpr,"inner").select(selectCols).toDF(*newCols)

df=df.filter(((df.left_ssn_valid==1) & (df.right_ssn_valid==0)) | ((df.left_ssn_valid==0) & (df.right_ssn_valid==1)))

df.dropDuplicates().write.mode("overwrite").format("parquet").save(hdfs_temp_path)

# COMMAND ----------

df = spark.read.parquet(hdfs_temp_path)

# COMMAND ----------

whereExprs = {
        "phone":(df.left_phone_valid == 1) & (df.right_phone_valid == 1) & (trim(df.left_phone) == trim(df.right_phone)),
        "addrnum":(df.left_addrnum_valid == 1) & (df.right_addrnum_valid == 1) & (df.left_zip_valid == 1) & (df.right_zip_valid == 1) & (trim(df.left_zip) == trim(df.right_zip)) & (address_udf(trim(df.left_addrnum),trim(df.right_addrnum)) == 1),

     }

matchExprs = {
    #39 Anti-SSN~FN~DOB~CityAndState~AddrNum
    "39":whereExprs.get("addrnum") ,
    #43 Anti-SSN~FN~DOB~CityAndState~Phone
    "43":whereExprs.get("phone"),
}

# COMMAND ----------

selectExprGMRNs = ['left_globalmrnifk', 'right_globalmrnifk']
for matchType in matchExprs:
    result = df.where((matchExprs[matchType])).select(selectExprGMRNs).withColumn("matchtype", lit(matchType))
    result.dropDuplicates().write.mode("overwrite").format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="|").save(hdfs_output + "/" + matchType)

# COMMAND ----------

########SECOND SET of matches#######################################################
#FN,DOB,zip, dataframe is df3

if int(swift_mode)==1:
  df_pa = spark.read.table(stagedPatientacctsTableName).select(selectedCols)
  df_gd = spark.read.table(stagedGlobalmrndemographicsTableName).select(selectedCols)
 
  df_pa_2 = df_pa.where((df_pa.fn_valid == 1) & (df_pa.dob_valid == 1) & (df_pa.zip_valid == 1) &  (df_pa.addrnum_valid == 1))
  df_gd_2 = df_gd.where((df_gd.fn_valid == 1) & (df_gd.dob_valid == 1) & (df_gd.zip_valid == 1) &  (df_gd.addrnum_valid == 1))
  

  left = df_pa_2.alias('left')
  right= df_gd_2.alias('right')
else:
  df_all = spark.read.table(mergedGlobalMrnTableName).select(selectedCols)
  df_all = df_all.where((df_all.fn_valid == 1) & (df_all.dob_valid == 1) & (df_all.zip_valid == 1) & (df_all.addrnum_valid == 1))

  left = df_all.alias('left')
  right= df_all.alias('right')

# COMMAND ----------

df3 = spark.sql("""
  SELECT /*+ SKEW('left_side', ('dob', 'firstname', 'zip')) */
        left_side.globalmrnifk AS left_globalmrnifk,
        left_side.firstname AS left_firstname,
        left_side.dob AS left_dob,
        left_side.lastname AS left_lastname,
        left_side.phone AS left_phone,
        left_side.city AS left_city,
        left_side.state AS left_state,
        left_side.zip AS left_zip,
        left_side.addrnum AS left_addrnum,
        left_side.medicalrecnum AS left_medicalrecnum,
        left_side.ssn AS left_ssn,
        left_side.fn_valid AS left_fn_valid,
        left_side.dob_valid AS left_dob_valid,
        left_side.ln_valid AS left_ln_valid,
        left_side.phone_valid AS left_phone_valid,
        left_side.city_valid AS left_city_valid,
        left_side.state_valid AS left_state_valid,
        left_side.zip_valid AS left_zip_valid,
        left_side.addrnum_valid AS left_addrnum_valid,
        left_side.mrn_valid AS left_mrn_valid,
        left_side.ssn_valid AS left_ssn_valid,
        right_side.globalmrnifk AS right_globalmrnifk,
        right_side.firstname AS right_firstname,
        right_side.dob AS right_dob,
        right_side.lastname AS right_lastname,
        right_side.phone AS right_phone,
        right_side.city AS right_city,
        right_side.state AS right_state,
        right_side.zip AS right_zip,
        right_side.addrnum AS right_addrnum,
        right_side.medicalrecnum AS right_medicalrecnum,
        right_side.ssn AS right_ssn,
        right_side.fn_valid AS right_fn_valid,
        right_side.dob_valid AS right_dob_valid,
        right_side.ln_valid AS right_ln_valid,
        right_side.phone_valid AS right_phone_valid,
        right_side.city_valid AS right_city_valid,
        right_side.state_valid AS right_state_valid,
        right_side.zip_valid AS right_zip_valid,
        right_side.addrnum_valid AS right_addrnum_valid,
        right_side.mrn_valid AS right_mrn_valid,
        right_side.ssn_valid AS right_ssn_valid
  FROM {left} as left_side
  JOIN {right} as right_side
    ON left_side.dob = right_side.dob
    AND left_side.firstname = right_side.firstname
    AND left_side.zip = right_side.zip
    AND left_side.globalmrnifk <> right_side.globalmrnifk
""", left = left, right = right)

df3=df3.filter(((df3.left_ssn_valid==1) & (df3.right_ssn_valid==0)) | ((df3.left_ssn_valid==0) & (df3.right_ssn_valid==1)))

df3=df3.where(address_udf(trim(df3.left_addrnum),trim(df3.right_addrnum)) == 1)

# COMMAND ----------

whereExprs3 = {
        "lastname":(df3.left_ln_valid == 1) & (df3.right_ln_valid == 1)  & (trim(df3.left_lastname) == trim(df3.right_lastname)),
        "medicalrecnum":(df3.left_mrn_valid == 1) & (df3.right_mrn_valid == 1) &  (comparelist_udf(df3.left_medicalrecnum,df3.right_medicalrecnum) == 1),
     }

matchExprs3 = {
    #46 Anti-SSN~FN~DOB~AddrNum~MRN
    "46":whereExprs3.get("medicalrecnum"),
    #38 Anti-SSN~FN~LN~DOB~AddrNum
    "38":whereExprs3.get("lastname") 
}

# COMMAND ----------

selectExprGMRNs = ['left_globalmrnifk', 'right_globalmrnifk']

for matchType in matchExprs3:
    result = df3.where((matchExprs3[matchType])).select(selectExprGMRNs).withColumn("matchtype", lit(matchType))
    result.dropDuplicates().write.mode("overwrite").format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="|").save(hdfs_output + "/" + matchType)

# COMMAND ----------

if int(swift_mode)==1:
  df_pa = spark.read.table(stagedPatientacctsTableName).select(selectedCols)
  df_gd = spark.read.table(stagedGlobalmrndemographicsTableName).select(selectedCols)

  df_pa_2 = df_pa.where((df_pa.fn_valid == 1) & (df_pa.dob_valid == 1) & (df_pa.ln_valid == 1) & (df_pa.city_valid == 1) & (df_pa.state_valid == 1))
  df_gd_2 = df_gd.where((df_gd.fn_valid == 1) & (df_gd.dob_valid == 1) & (df_gd.ln_valid == 1) & (df_gd.city_valid == 1) & (df_gd.state_valid == 1))


  left = df_pa_2.alias('left')
  right= df_gd_2.alias('right')
else:
  df_all = spark.read.table(mergedGlobalMrnTableName).select(selectedCols)
  df_all = df_all.where((df_all.fn_valid == 1) & (df_all.dob_valid == 1) & (df_all.ln_valid == 1) & (df_all.city_valid == 1) & (df_all.state_valid == 1))
    
  left = df_all.alias('left')
  right= df_all.alias('right')

# COMMAND ----------

joinExpr = (left.dob == right.dob) & \
           (left.city == right.city) & \
           (left.state == right.state) & \
          (left.globalmrnifk != right.globalmrnifk)

# COMMAND ----------

df2= left.join(right, joinExpr,"inner").select(selectCols).toDF(*newCols)

df2=df2.filter(((df2.left_ssn_valid==1) & (df2.right_ssn_valid==0)) | ((df2.left_ssn_valid==0) & (df2.right_ssn_valid==1)))

# COMMAND ----------

whereExprs2 = {
        "swappedlastname":(df2.left_fn_valid == 1) & (df2.right_ln_valid == 1)  & (trim(df2.left_firstname) == trim(df2.right_lastname)),
        "swappedfirstname":(df2.left_ln_valid == 1) & (df2.right_fn_valid == 1)  & (trim(df2.left_lastname) == trim(df2.right_firstname)),
        "medicalrecnum":(df2.left_mrn_valid == 1) & (df2.right_mrn_valid == 1) &  (comparelist_udf(df2.left_medicalrecnum,df2.right_medicalrecnum) == 1)
     }

matchExprs2 = {
    #37 Anti-SSN~SwappedFN~SwappedLN~DOB~CityAndState~MRN
    "37":whereExprs2.get("swappedlastname") & whereExprs2.get("swappedfirstname") &  whereExprs2.get("medicalrecnum")
}

# COMMAND ----------

selectExprGMRNs = ['left_globalmrnifk', 'right_globalmrnifk']

for matchType in matchExprs2:
    result = df2.where((matchExprs2[matchType])).select(selectExprGMRNs).withColumn("matchtype", lit(matchType))
    result.dropDuplicates().write.mode("overwrite").format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="|").save(hdfs_output + "/" + matchType)

# COMMAND ----------

from datetime import datetime

end=datetime.now()
print(end)
delta=end-start
print(delta)
