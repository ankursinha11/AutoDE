# Databricks notebook source
pip install adlfs==2024.7.0

# COMMAND ----------

from adlfs import AzureBlobFileSystem

# COMMAND ----------

dbutils.widgets.text("bc", "")
bc = dbutils.widgets.get("bc")

dbutils.widgets.text("gmdemo_path", "")
gmdemo_path = dbutils.widgets.get("gmdemo_path")

dbutils.widgets.text("gdemo_staging_path", "")
gdemo_staging_path = dbutils.widgets.get("gdemo_staging_path")

dbutils.widgets.text("storageaccount","")
storageaccount = dbutils.widgets.get("storageaccount")

# COMMAND ----------

# bc = "20250522T06"
# base_url = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data"
# gmdemo_path = f"{base_url}/gmrn/staging/sot/tmp_op/gdemo_update/"
# gdemo_staging_path = f"{base_url}/gmrn/staging/sot/gmrndemo_update/globalmrndemographics/{bc}/"
# storageaccount = "prodicdstgdls"

# COMMAND ----------

account_name = storageaccount
account_key = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret")

fs = AzureBlobFileSystem(account_name,account_key)

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

def get_csv_file(directory_path):
    try:
        files_to_treat = dbutils.fs.ls(directory_path)
        for filename in files_to_treat:
            path = filename.path
            name = filename.name
            if name.startswith("part"):
                return path
    except Exception as e:
        print("Exception occurred in move_data_gdemo notebook and get_csv_file function failure error message:")
        print(e)
        raise

# COMMAND ----------

def generatefiles(source_path,delete_path,dest_path):
    try:
        if fs.exists(delete_path):
            dbutils.fs.rm(delete_path, True)
        if fs.exists(dest_path):
            dbutils.fs.rm(dest_path, True)

        if fs.exists(source_path):
            tempfilepath = get_csv_file(source_path)
            dbutils.fs.mv(tempfilepath, delete_path,True)
            df = spark.read.options(inferSchema='false').options(header='false').csv(delete_path)
            ct = str(df.count())
            dbutils.fs.put(dest_path, ct + " " + delete_path, True)
            dbutils.fs.rm(source_path, True)
    except Exception as e:
        print("Exception occurred in move_data_gdemo notebook and generatefiles function failure error message:")
        print(e)
        raise


# COMMAND ----------

gdemo_del_path=gmdemo_path + bc+ "/del/"
gdemo_ins_path = gmdemo_path + bc+ "/ins/"

gdemo_staging_delta_path = gdemo_staging_path + "hdp_sot_delta_globalmrndemographics_" + bc + ".dat"
gdemo_staging_delete_path = gdemo_staging_path + "hdp_sot_delete_globalmrndemographics_" + bc + ".dat"

gdemo_staging_delta_done_path = gdemo_staging_path + "hdp_sot_delta_globalmrndemographics_" + bc + ".done"
gdemo_staging_delete_done_path = gdemo_staging_path + "hdp_sot_delete_globalmrndemographics_" + bc + ".done"


# COMMAND ----------

generatefiles(gdemo_ins_path,gdemo_staging_delta_path,gdemo_staging_delta_done_path)

# COMMAND ----------

generatefiles(gdemo_del_path,gdemo_staging_delete_path, gdemo_staging_delete_done_path)
