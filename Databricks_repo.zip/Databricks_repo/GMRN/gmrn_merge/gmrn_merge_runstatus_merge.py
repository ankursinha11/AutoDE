# Databricks notebook source
from pyspark.sql.functions import *
import datetime
from pyspark.sql.types import *
from  pyspark.sql.functions import input_file_name
from pyspark.sql.window import Window
from pyspark import StorageLevel
from delta.tables import * 
from pyspark.sql.functions import col

# COMMAND ----------

# cosmosDatabaseName = "insleads"
# cosmosEndpoint = "https://prod-icd-stg-cosmos.documents.azure.com:443/"
# cosmosContainerName = "runstatus"
# notificationtype = "data_ingestion_patientaccts3"
# storageaccount = "prodicdstgdls"
# input_aid_patientaccts = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/maxc//data/dataingestion/staging/input/patientaccts/"

# COMMAND ----------

dbutils.widgets.text('notificationtype','')
notificationtype = dbutils.widgets.get("notificationtype")

dbutils.widgets.text('storageaccount','')
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text('cosmosEndpoint','')
cosmosEndpoint = dbutils.widgets.get("cosmosEndpoint")

dbutils.widgets.text('cosmosDatabaseName','')
cosmosDatabaseName = dbutils.widgets.get("cosmosDatabaseName")

dbutils.widgets.text('cosmosContainerName','')
cosmosContainerName = dbutils.widgets.get("cosmosContainerName")

dbutils.widgets.text("input_aid_patientaccts","")
input_aid_patientaccts=dbutils.widgets.get("input_aid_patientaccts")

# COMMAND ----------

def readFromCosmos(Endpoint,MasterKey,DatabaseName,ContainerName):
    readConf = {
    "spark.cosmos.accountEndpoint" : Endpoint,
    "spark.cosmos.accountKey" : MasterKey,
    "spark.cosmos.database" : DatabaseName,
    "spark.cosmos.container" : ContainerName,
}
    df_read = spark.read.format("cosmos.oltp").options(**readConf).option("spark.cosmos.read.inferSchema.enabled", "true").load()
    return df_read

def writeToCosmos(dfWrite,Endpoint,MasterKey,DatabaseName,ContainerName):
    writeConf = {
    "spark.cosmos.accountEndpoint" : Endpoint,
    "spark.cosmos.accountKey" : MasterKey,
    "spark.cosmos.database" : DatabaseName,
    "spark.cosmos.container" : ContainerName,
    "spark.cosmos.write.strategy" : "ItemOverwrite"
}
    dfWrite.write.format('cosmos.oltp').options(**writeConf).mode('append').save()

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))
cosmosMasterKey=dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-cosmos-insleads-kvsecret")
print("cosmosEndpoint" + str(cosmosEndpoint))
print("cosmosMasterKey" + str(cosmosMasterKey))
print("cosmosDatabaseName" + str(cosmosDatabaseName))
print("cosmosContainerName" + str(cosmosContainerName))

import uuid
spark.conf.set("spark.sql.catalog.cosmosCatalog", "com.azure.cosmos.spark.CosmosCatalog")
spark.conf.set("spark.sql.catalog.cosmosCatalog.spark.cosmos.accountEndpoint", cosmosEndpoint)
spark.conf.set("spark.sql.catalog.cosmosCatalog.spark.cosmos.accountKey", cosmosMasterKey)
spark.conf.set("spark.sql.catalog.cosmosCatalog.spark.cosmos.views.repositoryPath", "/viewDefinitions" + str(uuid.uuid4()))

# COMMAND ----------

notificationtype = str(notificationtype)

filterExprNotification = "notificationtype = '" + notificationtype + "'"
filterExprSql = """ SELECT * FROM runstatus WHERE  lower(trim(processed))='unprocessed' AND """ + filterExprNotification + """ ORDER BY createdon ASC"""

print("filterExprSql          : " + str(filterExprSql))
print("input_aid_patientaccts : " + str(input_aid_patientaccts))

# COMMAND ----------

df_read_run_status = readFromCosmos(cosmosEndpoint, cosmosMasterKey, cosmosDatabaseName, cosmosContainerName)
df_read_run_status.createOrReplaceTempView("runstatus")
data = spark.sql(filterExprSql)

data_aid = data.filter("workflowtype=='aid'")
data_regular = data.filter("workflowtype=='regular'")
data_aid_count = data_aid.count()
data_regular_count = data_regular.count()

# print("data               : " + str(data.count()))
# print("data_aid_count     : " + str(data_aid_count))
# print("data_regular_count : " + str(data_regular_count))

# COMMAND ----------

if data_aid_count > data_regular_count:
    # print("data_regular_count :" + str(data_regular_count))
    # print("data_aid_count :" + str(data_aid_count))
    print("AID has higher precedence over REGULAR")
    data = data_aid
    workflowtype="aid"
else:
    # print("data_regular_count :" + str(data_regular_count))
    # print("data_aid_count :" + str(data_aid_count))
    print("REGULAR mode initiated : MERGE BC needed")
    data = data_regular
    workflowtype="regular"

# COMMAND ----------

if workflowtype=='aid':
    print("AID MODE - TRUE")
    if data.count() <= 1:
        print("do nothing")
        # dbutils.notebook.exit({"workflowtype":workflowtype})
    else:
        print("change AID older bc's to processed")
        max_bc = data.filter("workflowtype=='aid'").selectExpr("bc", "createdon").sort("createdon", ascending=False).selectExpr("bc").limit(1)
        max_bc = [str(row.bc) for row in max_bc.collect()][0]
        print("MAX BC : " + max_bc)
        max_bc_data=spark.read.parquet(input_aid_patientaccts+"/"+max_bc)
        print("Retrieved BC Schema")      
        served=spark.createDataFrame(sc.emptyRDD(),max_bc_data.schema)
        print("Empty  DF Schema Creation")
        max_bc_data.unpersist()
        bc_in_play = data.selectExpr("bc").dropDuplicates()
        bc_array = [str(row.bc) for row in bc_in_play.collect()]
        for i in bc_array:
            print(str(i))
            served_path = input_aid_patientaccts+"/" + i
            print(served_path)
            df_bc = spark.read.option("mergeSchema", "true").parquet(served_path)
            for column in df_bc.columns:
                new_column = column.lower()
            df_bc = df_bc.withColumnRenamed(column, new_column)
            for column in df_bc.columns:
                df_bc = df_bc.withColumn(column, trim(col(column)))
            served = served.unionAll(df_bc)
        served.write.mode("overwrite").parquet(input_aid_patientaccts+"/"+max_bc)
        served.unpersist()
        print("BC MERGE DATA R/W Complete")
        data_updated = data.withColumn("processed", when(col('bc') == max_bc,lit('unprocessed')).otherwise(lit('processed'))).withColumn("processedon", when(col('bc') != max_bc,lit('Merged to bc:'+ max_bc)).otherwise(col('processedon')))
        writeToCosmos(data_updated,cosmosEndpoint,cosmosMasterKey,cosmosDatabaseName,cosmosContainerName)
        print("UPDATED COSMOSDB : " + cosmosDatabaseName + " WITH processed FLAGS")
        data.unpersist()
        # dbutils.notebook.exit({"workflowtype":workflowtype})
else :
    print("AID MODE - FALSE")
    if data.count() <= 1:
        print("do nothing")
        # dbutils.notebook.exit({"workflowtype":workflowtype})
    else:
        print("change older bc's to processed")
        max_bc = data.filter((col("workflowtype") == 'regular') | (col("workflowtype").isNull()) | (col("workflowtype") == '')).selectExpr("bc", "createdon").sort("createdon", ascending=False).selectExpr("bc").limit(1)
        max_bc = [str(row.bc) for row in max_bc.collect()][0]
        print("MAX BC : " + max_bc)
        data_updated = data.withColumn("processed", when(col('bc') == max_bc,lit('unprocessed')).otherwise(lit('processed'))).withColumn("processedon", when(col('bc') != max_bc,lit('Merged to bc:'+ max_bc)).otherwise(col('processedon')))
        writeToCosmos(data_updated,cosmosEndpoint,cosmosMasterKey,cosmosDatabaseName,cosmosContainerName)
        print("UPDATED COSMOSDB : " + cosmosDatabaseName + " WITH processed FLAGS")
        data.unpersist()
        # dbutils.notebook.exit({"workflowtype":workflowtype})

# COMMAND ----------

dbutils.notebook.exit({"workflowtype":workflowtype})
