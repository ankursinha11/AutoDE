# Databricks notebook source
from datetime import datetime
from pyspark.sql.functions import *

# COMMAND ----------

start=datetime.now()
print(start)

# COMMAND ----------

dbutils.widgets.text("hdfs_match_output", "")
hdfs_output= dbutils.widgets.get("hdfs_match_output")

dbutils.widgets.text("hdfs_temp_path", "")
hdfs_temp_path= dbutils.widgets.get("hdfs_temp_path")

dbutils.widgets.text("swift_mode", "")
swift_mode= dbutils.widgets.get("swift_mode")

dbutils.widgets.text("storageaccount","")
storageaccount=dbutils.widgets.get("storageaccount")

dbutils.widgets.text("stagedPatientacctsTableName","")
stagedPatientacctsTableName = dbutils.widgets.get("stagedPatientacctsTableName")

dbutils.widgets.text("stagedGlobalmrndemographicsTableName","")
stagedGlobalmrndemographicsTableName = dbutils.widgets.get("stagedGlobalmrndemographicsTableName")

dbutils.widgets.text("mergedGlobalMrnTableName","")
mergedGlobalMrnTableName = dbutils.widgets.get("mergedGlobalMrnTableName")

# COMMAND ----------

# bc = "20250522T06"
# base_url = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data"
# hdfs_output = f"{base_url}/gmrn/staging/matches/merge/{bc}"
# hdfs_temp_path = f"{base_url}/gmrn/staging/soundex_part02/"
# swift_mode = "0"
# stagedPatientacctsTableName = f"regular_staged_patientaccts_{bc}"
# stagedGlobalmrndemographicsTableName = f"regular_staged_globalmrndemographics_{bc}"
# mergedGlobalMrnTableName = f"merged_global_mrn_{bc}"
# storageaccount = "prodicdstgdls"

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/tu_data_quality"
# MAGIC

# COMMAND ----------

# MAGIC %run "/Insleads-code/GMRN/gmrn_merge/match_util"

# COMMAND ----------

# DBTITLE 1,Set the Spark configs
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.skewJoin.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "auto")
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

selectedCols = ["globalmrnifk", "firstname", "dob", "lastname", "gender", "phone", "city", "state", "zip", "addrnum", "medicalrecnum", "ssn", "hhpermid", \
"fn_valid", "dob_valid", "ln_valid", "gender_valid", "phone_valid", "city_valid", "state_valid", "zip_valid", "addrnum_valid", \
"mrn_valid", "ssn_valid", "hhpermid_valid"]

# COMMAND ----------

if int(swift_mode) == 1:
    df_pa = spark.read.table(stagedPatientacctsTableName).select(selectedCols)
    df_gd = spark.read.table(stagedGlobalmrndemographicsTableName).select(selectedCols)

    df_pa_2 = df_pa.where((df_pa.dob_valid == 1) & \
                          (df_pa.city_valid == 1) & \
                          (df_pa.state_valid == 1) & \
                          (df_pa.gender_valid == 1)
                          )

    df_gd_2 = df_gd.where((df_gd.dob_valid == 1) & \
                          (df_gd.city_valid == 1) & \
                          (df_gd.state_valid == 1) & \
                          (df_gd.gender_valid == 1)
                          )

    left = df_pa_2.alias('left')
    right = df_gd_2.alias('right')
else:
    df_all = spark.read.table(mergedGlobalMrnTableName).select(selectedCols)
    df_all = df_all.where((df_all.dob_valid == 1) & \
                          (df_all.city_valid == 1) & \
                          (df_all.state_valid == 1) & \
                          (df_all.gender_valid == 1)
                          )
    left = df_all.alias('left')
    right = df_all.alias('right')


# COMMAND ----------

df3 = spark.sql("""
  SELECT /*+ SKEW('left_side', ('state', 'city', 'dob', 'gender')) */
       left_side.globalmrnifk    AS left_globalmrnifk,
       left_side.firstname       AS left_firstname,
       left_side.dob             AS left_dob,
       left_side.lastname        AS left_lastname,
       left_side.gender          AS left_gender,
       left_side.phone           AS left_phone,
       left_side.city            AS left_city,
       left_side.state 		       AS left_state,
       left_side.zip             AS left_zip,
       left_side.addrnum         AS left_addrnum,
       left_side.medicalrecnum   AS left_medicalrecnum,
       left_side.ssn             AS left_ssn,
       left_side.hhpermid        AS left_hhpermid,
       left_side.fn_valid        AS left_fn_valid,
       left_side.dob_valid       AS left_dob_valid,
       left_side.ln_valid        AS left_ln_valid,
       left_side.gender_valid    AS left_gender_valid,
       left_side.phone_valid     AS left_phone_valid,
       left_side.city_valid      AS left_city_valid,
       left_side.state_valid     AS left_state_valid,
       left_side.zip_valid       AS left_zip_valid,
       left_side.addrnum_valid   AS left_addrnum_valid,
       left_side.mrn_valid       AS left_mrn_valid,
       left_side.ssn_valid       AS left_ssn_valid,
       left_side.hhpermid_valid  AS left_hhpermid_valid,
       right_side.globalmrnifk   AS right_globalmrnifk,
       right_side.firstname      AS right_firstname,
       right_side.dob            AS right_dob,
       right_side.lastname       AS right_lastname,
       right_side.gender         AS right_gender,
       right_side.phone          AS right_phone,
       right_side.city           AS right_city,
       right_side.state          AS right_state,
       right_side.zip            AS right_zip,
       right_side.addrnum        AS right_addrnum,
       right_side.medicalrecnum  AS right_medicalrecnum,
       right_side.ssn            AS right_ssn,
       right_side.hhpermid       AS right_hhpermid,
       right_side.fn_valid       AS right_fn_valid,
       right_side.dob_valid      AS right_dob_valid,
       right_side.ln_valid       AS right_ln_valid,
       right_side.gender_valid   AS right_gender_valid,
       right_side.phone_valid    AS right_phone_valid,
       right_side.city_valid     AS right_city_valid,
       right_side.state_valid    AS right_state_valid,
       right_side.zip_valid      AS right_zip_valid,
       right_side.addrnum_valid  AS right_addrnum_valid,
       right_side.mrn_valid      AS right_mrn_valid,
       right_side.ssn_valid      AS right_ssn_valid,
       right_side.hhpermid_valid AS right_hhpermid_valid
  FROM {left} as left_side
  JOIN {right} as right_side
    ON left_side.state = right_side.state
    AND left_side.city = right_side.city
    AND left_side.dob = right_side.dob
    AND left_side.gender = right_side.gender
    AND left_side.globalmrnifk <> right_side.globalmrnifk
""", left = left, right = right)

# COMMAND ----------

df3.write.mode("overwrite").format("parquet").save(hdfs_temp_path)

# COMMAND ----------

df3 = spark.read.parquet(hdfs_temp_path)

# COMMAND ----------

whereExprs = {
    "sndxln": (df3.left_ln_valid == 1) & (df3.right_ln_valid == 1) & \
              (df3.left_lastname != df3.right_lastname) & \
              ((soundex(df3.left_lastname)) == (soundex(df3.right_lastname))),

    "sndxfn": (df3.left_fn_valid == 1) & (df3.right_fn_valid == 1) & \
              (df3.left_firstname != df3.right_firstname) & \
              ((soundex(df3.left_firstname)) == (soundex(df3.right_firstname))),

    "substrln": (df3.left_ln_valid == 1) & (df3.right_ln_valid == 1) & (contains_udf(df3.left_lastname, df3.right_lastname) == 1),

    "lastname": (df3.left_ln_valid == 1) & (df3.right_ln_valid == 1) & (df3.left_lastname == df3.right_lastname),

    "firstname": (df3.left_fn_valid == 1) & (df3.right_fn_valid == 1) & (df3.left_firstname == df3.right_firstname),

    "mrn": (df3.left_mrn_valid == 1) & (df3.right_mrn_valid == 1) & (comparelist_udf(df3.left_medicalrecnum, df3.right_medicalrecnum) == 1),

    "hhpermid": (df3.left_hhpermid_valid == 1) & (df3.right_hhpermid_valid == 1) & (comparelist_udf(df3.left_hhpermid, df3.right_hhpermid) == 1)
}

matchExprs = {
    "7": whereExprs.get("sndxfn") & whereExprs.get("lastname") & whereExprs.get("mrn"),
    "10": whereExprs.get("firstname") & whereExprs.get("sndxln") & whereExprs.get("mrn"),
    "9": whereExprs.get("firstname") & whereExprs.get("substrln") & whereExprs.get("mrn"),
    "8": whereExprs.get("lastname") & whereExprs.get("sndxfn") & whereExprs.get("hhpermid"),
    "11": whereExprs.get("firstname") & whereExprs.get("sndxln") & whereExprs.get("hhpermid")

}

# COMMAND ----------

selectExprGMRNs = ['left_globalmrnifk', 'right_globalmrnifk']

for matchType in matchExprs:
    result = df3.where(matchExprs[matchType]).select(selectExprGMRNs).withColumn("matchtype", lit(matchType))
    result.dropDuplicates().write.mode("overwrite").format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", delimiter="|").save(hdfs_output + "/" + matchType)

# COMMAND ----------

from datetime import datetime
end=datetime.now()
print(end)
delta=end-start
print(delta)
