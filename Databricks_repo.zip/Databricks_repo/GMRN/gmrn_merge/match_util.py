# Databricks notebook source
import sys
from pyspark.sql.types import *
from pyspark.sql.functions import *

# COMMAND ----------

def rotation(str1,str2):
  str1 = str(str1)
  str2 = str(str2)
  strlen = len(str1)
  if str1 == str2:
    return 1
  elif len(str1)==len(str2):
    for i in range(strlen):
      tmp = str1[i:]+str1[:i]
      if(tmp ==str2):
        return 1
    return 0
  else:
    return 0

# COMMAND ----------

def contains(str1,str2):
  str1 = str(str1)
  str2 = str(str2)
  if str1 == str2:
    return 1
  elif len(str1)>2 and len(str2)>2 and (str1 in str2 or str2 in str1):
    return 1
  else:
    return 0

# COMMAND ----------

def comparelist(l, r):
   if l is None or  r is None:
     return 0
   ret=any(map(lambda v: v in r, l))
   if ret==True:
     return 1
   else:
     return 0

# COMMAND ----------

comparelist_udf =udf(comparelist,IntegerType())
contains_udf = udf(contains,IntegerType())
address_udf = udf(rotation,IntegerType())