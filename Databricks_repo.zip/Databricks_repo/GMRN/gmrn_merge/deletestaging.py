# Databricks notebook source
dbutils.widgets.text("dir", "")
dir = dbutils.widgets.get("dir")

dbutils.widgets.text("bc", "")
bc = dbutils.widgets.get("bc")

dbutils.widgets.text("storageaccount","")
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text("stagedPatientacctsTableName","")
stagedPatientacctsTableName = dbutils.widgets.get("stagedPatientacctsTableName")

dbutils.widgets.text("stagedGlobalmrndemographicsTableName","")
stagedGlobalmrndemographicsTableName = dbutils.widgets.get("stagedGlobalmrndemographicsTableName")

dbutils.widgets.text("mergedGlobalMrnTableName","")
mergedGlobalMrnTableName = dbutils.widgets.get("mergedGlobalMrnTableName")

# COMMAND ----------

# DBTITLE 1,SAMPLE INPUT
# bc = "20240829T06"
# dir = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data/gmrn/staging/staged_all/"
# storageaccount = "prodicdstgdls"
# stagedPatientacctsTableName = "regular_staged_patientaccts_20240829T06"
# stagedGlobalmrndemographicsTableName = "regular_staged_globalmrndemographics_20240829T06"
# mergedGlobalMrnTableName = "merged_global_mrn_20240829T06"

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

def file_exists(path):
    try:
        dbutils.fs.ls(path)
        return True
    except Exception as e:
        if 'java.io.FileNotFoundException' in str(e):
            return False
        else:
            raise

# COMMAND ----------

# Dropping staged patient_accts table and its files
dropSql = f"DROP TABLE IF EXISTS {stagedPatientacctsTableName}"
spark.sql(dropSql)

gm = dir + "/staged_globalmrndemographics/" + bc
gmisFilesTrue = file_exists(gm)
print("gmisFilesTrue : " + str(gmisFilesTrue))
if gmisFilesTrue:
    dbutils.fs.rm(gm, True)

# Dropping staged globalmrn_demographics table and its files
dropSql = f"DROP TABLE IF EXISTS {stagedGlobalmrndemographicsTableName}"
spark.sql(dropSql)

pa = dir + "/staged_patientaccts/" + bc
paisFilesTrue = file_exists(pa)
print("paisFilesTrue : " + str(paisFilesTrue))
if paisFilesTrue:
    dbutils.fs.rm(pa, True)

# Dropping merged_patientaccts_gmrndemo table and its files
if mergedGlobalMrnTableName == '':
    mergedGlobalMrnTableName = "dummy"
    print(mergedGlobalMrnTableName)

dropSql = f"DROP TABLE IF EXISTS {mergedGlobalMrnTableName}"
spark.sql(dropSql)

mrg = dir + "/merged_patientaccts_gmrndemo/" + bc
mrgisFilesTrue = file_exists(mrg)
print("mrgisFilesTrue : " + str(mrgisFilesTrue))
if mrgisFilesTrue:
    dbutils.fs.rm(mrg, True)
