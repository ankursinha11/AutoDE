# Databricks notebook source
pip install adlfs

# COMMAND ----------

import os
from datetime import datetime
from adlfs import AzureBlobFileSystem

# COMMAND ----------

dbutils.widgets.text("bc","")
dbutils.widgets.text('nps_status_path',"")

bc = dbutils.widgets.get('bc')
nps_status_path = dbutils.widgets.get('nps_status_path')

dbutils.widgets.text("storageaccount","")
storageaccount=dbutils.widgets.get("storageaccount")

# COMMAND ----------

nps_status_path = nps_status_path + bc

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

account_name = storageaccount
account_key = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret")
container_name = 'prod-icd-adls'

fs = AzureBlobFileSystem(account_name,account_key)

# COMMAND ----------

#Get current date in required format
now = datetime.now()
curr_date = now.strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
print(curr_date)

# COMMAND ----------

#Create nps_status_path if it doesn't exists
if not fs.exists(nps_status_path):
    fs.mkdirs(nps_status_path)
else:
    print('Exists')


# COMMAND ----------

#append the log file
with fs.open(nps_status_path+'log.bat','a') as f:
    f.write("GlobalMRN" + bc + curr_date )