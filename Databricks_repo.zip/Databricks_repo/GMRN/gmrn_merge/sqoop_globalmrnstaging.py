# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

dbutils.widgets.text("tablenamemrn","")
tablenamemrn=dbutils.widgets.get("tablenamemrn")

dbutils.widgets.text("path_conn_file", "")
path_conn_file= dbutils.widgets.get("path_conn_file")

dbutils.widgets.text("sqoop_output_path_mrn","")
sqoop_output_path_mrn= dbutils.widgets.get("sqoop_output_path_mrn")

dbutils.widgets.text('hdfs_data_input',"")
hdfs_data_input= dbutils.widgets.get("hdfs_data_input")

dbutils.widgets.text("icddb","")
icddb= dbutils.widgets.get("icddb")

dbutils.widgets.text("bc","")
bc= dbutils.widgets.get("bc")

dbutils.widgets.text("storageaccount","")
storageaccount=dbutils.widgets.get("storageaccount")

# COMMAND ----------

# tablenamemrn = "GlobalMRNStaging"
# path_conn_file = ""
# sqoop_output_path_mrn = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data/gmrn/staging/sqoop-data/globalmrn/"
# hdfs_data_input = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/vishnup/data/dataingestion/publish/"
# icddb = "zescantemp.dbo."
# bc = "20240829T06"
# storageaccount = "prodicdstgdls"

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

mrn_schema = StructType([
    StructField("GlobalMRNIPK", LongType(), False),
    StructField("CreateDate", TimestampType(), False),
    StructField("HospitalFK", ShortType(), False),   
    StructField("PatientAcctIFK", LongType(), False),
    StructField("MedicalRecNum", StringType(), True),
    StructField("SSN", StringType(), False),
    StructField("MedicaidNum", StringType(), False),
    StructField("MedicareHIC", StringType(), False),
    StructField("DOB", TimestampType(), False),   
    StructField("FirstName", StringType(), False),
    StructField("LastName", StringType(), True),
    StructField("PhoneNum", StringType(), False),
    StructField("StreetNum", StringType(), False),   
    StructField("City", StringType(), False),
    StructField("Zip", StringType(), True),
    StructField("isdeletedflag", IntegerType(), False)        
    ])

# COMMAND ----------

mrn = spark.read.option("header",False).option("recursiveFileLookup","true").schema(mrn_schema).options(delimiter="\x01").format("csv").load(sqoop_output_path_mrn+"/"+bc)
# dedup = dedup.withColumn("CreateDate", current_timestamp())

# COMMAND ----------

# DBTITLE 1,TEMPORARY PURGE LOGIC
mrn.createOrReplaceTempView("mrn")
print("BEFORE PURGE COUNT : "+str(mrn.count()))
purge=spark.read.format("parquet").load(hdfs_data_input + "hospitalpurge/current/20991231/")
purge=purge.filter("active=='1'").selectExpr("hospitalfk").dropDuplicates()
purge.createOrReplaceTempView("purge")
mrn=spark.sql("""SELECT * FROM mrn WHERE CAST(hospitalfk AS BIGINT) NOT IN (SELECT CAST(hospitalfk AS BIGINT) FROM purge)""").dropDuplicates()
print("BEFORE PURGE COUNT : "+str(mrn.count()))

# COMMAND ----------

mrn.write.format('jdbc').mode('append').option('driver', 'com.microsoft.sqlserver.jdbc.SQLServerDriver').option \
        ('url', path_conn_file).option('dbtable', icddb+tablenamemrn).save()
