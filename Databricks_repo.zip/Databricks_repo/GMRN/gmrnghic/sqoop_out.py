# Databricks notebook source
from pyspark.sql.functions import *

# COMMAND ----------

dbutils.widgets.text("tablename","")
dbutils.widgets.getArgument("tablename")
tablename= getArgument("tablename")

dbutils.widgets.text("path_conn_file", "")
dbutils.widgets.getArgument("path_conn_file")
path_conn_file= getArgument("path_conn_file")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("hdfs_ghic_sqoop_out","")
dbutils.widgets.getArgument("hdfs_ghic_sqoop_out")
hdfs_ghic_sqoop_out= getArgument("hdfs_ghic_sqoop_out")

dbutils.widgets.text("icddb","")
dbutils.widgets.getArgument("icddb")
icddb= getArgument("icddb")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
import os

# COMMAND ----------

# DBTITLE 1,set basepath
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user
print(baseurl)

# COMMAND ----------

gmrnxhicdelta_schema = StructType([
    StructField("globalmrnxhospinsurancecodespk", StringType(), True),
    StructField("globalmrnifk", StringType(), True),
    StructField("patientacctifk", StringType(), True),
    StructField("insurancecode", StringType(), True),
    StructField("inspolicyid", StringType(), True),
    StructField("createdate", StringType(), True),
    StructField("srcfoundcoverageifk", StringType(), True),
    StructField("hospitalfk", StringType(), True),
    StructField("isdeletedflag", StringType(), True)])

# COMMAND ----------

globalmrnxhospinsurancecodes= spark.read.csv(baseurl+hdfs_ghic_sqoop_out+bc, sep="\x01", schema=gmrnxhicdelta_schema)

# COMMAND ----------

globalmrnxhospinsurancecodes.write.format('jdbc').mode('append').option('driver', 'com.microsoft.sqlserver.jdbc.SQLServerDriver').option \
        ('url', path_conn_file).option('dbtable', icddb+tablename).save()