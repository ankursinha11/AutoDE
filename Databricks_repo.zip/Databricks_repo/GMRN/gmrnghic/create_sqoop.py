# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("hdfs_output_gmrnhic_history","")
dbutils.widgets.getArgument("hdfs_output_gmrnhic_history")
hdfs_output_gmrnhic_history= getArgument("hdfs_output_gmrnhic_history")

dbutils.widgets.text("hdfs_ghic_sqoop_out","")
dbutils.widgets.getArgument("hdfs_ghic_sqoop_out")
hdfs_ghic_sqoop_out= getArgument("hdfs_ghic_sqoop_out")

dbutils.widgets.text("hdfs_output_gmrnhic_pk","")
dbutils.widgets.getArgument("hdfs_output_gmrnhic_pk")
hdfs_output_gmrnhic_pk= getArgument("hdfs_output_gmrnhic_pk")

dbutils.widgets.text("tablename","")
dbutils.widgets.getArgument("tablename")
tablename= getArgument("tablename")


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user
print(baseurl)

# COMMAND ----------

hdfs_output_gmrnhic_pk= baseurl+ hdfs_output_gmrnhic_pk +bc
hdfs_output_gmrnhic_history= baseurl+hdfs_output_gmrnhic_history + bc
hdfs_ghic_sqoop_out= baseurl+hdfs_ghic_sqoop_out + bc

# COMMAND ----------

# Created By:Avishek
# Description: This script is for creating sqoop ready result for any given file

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
import os

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/create_config

# COMMAND ----------

#fs_common = "/dbfs/dbfs/FileStore/gmrn/ghic"
fs_common = "dbfs:/FileStore/gmrn/ghic"
fs_common1 = "/dbfs/FileStore/gmrn/ghic"

# COMMAND ----------

try:
    fs_details = dbutils.fs.ls(fs_common)
    for p in fs_details:
        if p.name != 'config_file_tables.dat':
            dbutils.fs.cp(baseurl+'/data/gmrn/config/config_file_tables.dat', fs_common+"/config_file_tables.dat")
except Exception as e:
    if 'java.io.FileAlreadyExistsException' in str(e):
        print('The file exists in the directory')
    else:
        print(e)

# COMMAND ----------

#dbutils.fs.cp(fs_common+'/config_file_tables.dat','/dbfs/FileStore/gmrn/ghic/config_file_tables.dat')

# COMMAND ----------

#schema for gmrndeltafiles

gmrnxhicdelta_schema = StructType([
    StructField("globalmrnxhospinsurancecodespk", StringType(), True),
    StructField("globalmrnifk", StringType(), True),
    StructField("patientacctifk", StringType(), True),
    StructField("hospitalfk", StringType(), True),
    StructField("insurancecode", StringType(), True),
    StructField("inspolicyid", StringType(), True),
    StructField("createdate", StringType(), True),
    StructField("srcfoundcoverageifk", StringType(), True),
    StructField("isdeletedflag", StringType(), True)])

#reading the update and insert files
#creating columns to be selected

config_path = fs_common1+"/config_file_tables.dat"

a =  createColumn(config_path,tablename,'columns')

selcolumns = '[' + a + ']'

table_stage = spark.read.format("csv").schema(gmrnxhicdelta_schema).options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",mode="FAILFAST", sep='\x01', quote="").load(hdfs_output_gmrnhic_pk)

table_stage = table_stage.select(eval(selcolumns)) \
                         .withColumn("isdeletedflag", lit("0"))

#reading history file 

table_delete = spark.read.parquet(hdfs_output_gmrnhic_history) \
                         .select(eval(selcolumns))  \
                         .withColumn("isdeletedflag", lit("1"))

table_sqoop = table_stage.union(table_delete)

table_sqoop = table_sqoop.withColumn("insurancecode",regexp_replace(col("insurancecode"),"\\\\", ""))
table_sqoop = table_sqoop.withColumn("insurancecode",regexp_replace(col("insurancecode"),'"', ''))	

table_sqoop.repartition(1).write.mode("overwrite").format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="\x01",emptyValue='').save(hdfs_ghic_sqoop_out)