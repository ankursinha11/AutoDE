# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("gmrn_insert","")
dbutils.widgets.getArgument("gmrn_insert")
gmrn_insert= getArgument("gmrn_insert")

dbutils.widgets.text("gmrn_delete","")
dbutils.widgets.getArgument("gmrn_delete")
gmrn_delete= getArgument("gmrn_delete")

dbutils.widgets.text("ghic_staging_path","")
dbutils.widgets.getArgument("ghic_staging_path")
ghic_staging_path= getArgument("ghic_staging_path")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("adls_path","")
dbutils.widgets.getArgument("adls_path")
adls_path= getArgument("adls_path")


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

ghic_staging_path=baseurl+adls_path+ghic_staging_path+bc
# gmrn_insert = baseurl +adls_path + gmrn_insert
gmrn_insert = baseurl + gmrn_insert +bc
gmrn_delete = baseurl + gmrn_delete +bc
print(ghic_staging_path)
print(gmrn_insert)
print(gmrn_delete)

print( "starting movement of globalmrnxhic files")



# COMMAND ----------

def fileCount(path):
    counter = 0
    files = dbutils.fs.ls(path)
    for file_path in files:
        if(file_path.name):
            counter += 1
    return counter

def return_csvpath(path):
    file = dbutils.fs.ls(path)
    for file_name in file:
        if(file_name.name.startswith('part')):
            return file_name.path

# COMMAND ----------

dbutils.fs.rm(ghic_staging_path, True)
df_insert = spark.read.csv(gmrn_insert, sep="\x01")
insert_file_count = fileCount(gmrn_insert)
if(insert_file_count > 0):
    if(insert_file_count > 2):
        df_insert.repartition(1).write.mode("overwrite").format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="\x01",   emptyValue='').save(ghic_staging_path+"/hdp_sot_delta_globalmrnxhospinsurancecodes_1" + bc)
        insert_path = return_csvpath(ghic_staging_path+"/hdp_sot_delta_globalmrnxhospinsurancecodes_1" + bc)
    else:
        insert_path = return_csvpath(gmrn_insert)
    
    dbutils.fs.cp(insert_path,ghic_staging_path+"/hdp_sot_delta_globalmrnxhospinsurancecodes_1" + bc+'.dat')
    dbutils.fs.rm(ghic_staging_path+"/hdp_sot_delta_globalmrnxhospinsurancecodes_1" + bc, True)
    filecount = df_insert.count()
    filecontent = str(filecount) + ' ' + ghic_staging_path+"/hdp_sot_delta_globalmrnxhospinsurancecodes_1" + bc+'.dat'
    dbutils.fs.put(ghic_staging_path+ "/hdp_sot_delta_globalmrnxhospinsurancecodes_1" + bc+'.done',filecontent, True  )

else:
    print("No insert data exist")

# COMMAND ----------

df_delete = spark.read.csv(gmrn_delete, sep="\x01")
delete_file_count = fileCount(gmrn_delete)
if(delete_file_count > 0):
    delete_path = return_csvpath(gmrn_delete)
    dbutils.fs.cp(delete_path,ghic_staging_path+"/hdp_sot_delete_globalmrnxhospinsurancecodes_1" + bc+'.dat')
    filecount = df_delete.count()
    filecontent = str(filecount) + ' ' + ghic_staging_path+"/hdp_sot_delete_globalmrnxhospinsurancecodes_1" + bc+'.dat'
    dbutils.fs.put(ghic_staging_path+ "/hdp_sot_delete_globalmrnxhospinsurancecodes_1" + bc+'.done',filecontent, True  )
else:
    print("No delete data exist")

# COMMAND ----------

print("file movement and stat creation is done")