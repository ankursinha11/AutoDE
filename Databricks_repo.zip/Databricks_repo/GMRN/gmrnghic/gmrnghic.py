# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("hdfs_input","")
dbutils.widgets.getArgument("hdfs_input")
hdfs_input= getArgument("hdfs_input")

dbutils.widgets.text("gmrn_publish_path","")
dbutils.widgets.getArgument("gmrn_publish_path")
gmrn_publish_path= getArgument("gmrn_publish_path")

dbutils.widgets.text("hdfs_output_gmrnhic_inserts","")
dbutils.widgets.getArgument("hdfs_output_gmrnhic_inserts")
hdfs_output_gmrnhic_inserts= getArgument("hdfs_output_gmrnhic_inserts")


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

hdfs_input = baseurl+hdfs_input
hdfs_output_gmrnhic_inserts = baseurl+hdfs_output_gmrnhic_inserts +bc
gmrn_publish_path = baseurl+gmrn_publish_path

# COMMAND ----------

#!/bin/python -e
#   Vineela Tatineni
#   05/21/2019
#   This pyspark script runs logic for GlobalMRN hospital insurance codes
#   It puts output in the publish/gmrnhic with the correct partition
#   We are taking data from escan and using below logic generating unique ghic records
#   The output flows into GMRNGHIC table in EDI

from pyspark.sql.types import *
from pyspark.sql import SparkSession
from datetime import datetime, timedelta
from pyspark.sql.functions import col,monotonically_increasing_id
from pyspark.sql.functions import unix_timestamp
from pyspark.sql.functions import trim
from pyspark.sql.functions import substring,coalesce
from pyspark.sql.functions import row_number,lit,min,max
from pyspark.sql.functions import regexp_replace
from pyspark.sql.functions import when
from functools import reduce
from pyspark.sql import DataFrame
from pyspark.sql.window import Window
import sys
import os
from pyspark import SparkContext
from pyspark.conf import SparkConf


# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

# Step 1- Configuration view with all the below tables
foundcoverage = extract_deltalake_data(
    spark, hdfs_input + "/foundcoverage/current/20991231/"
)
payerxstins = spark.read.parquet(
    hdfs_input + "/edipayersxstateinsurancenames/current/*"
)
gmrnxpacct = spark.read.parquet(gmrn_publish_path + "/globalmrnxpacct/current/*")
patientacctscodes = extract_deltalake_data(
    spark, hdfs_input + "/patientacctscodes/current/20991231/"
)
patientacctscodes = patientacctscodes.withColumn("insurancecode1", when(trim(patientacctscodes.insurancecode1) == '"',"").otherwise(patientacctscodes.insurancecode1))
patientacctscodes = patientacctscodes.withColumn("insurancecode2", when(trim(patientacctscodes.insurancecode2) == '"',"").otherwise(patientacctscodes.insurancecode2))
patientacctscodes = patientacctscodes.withColumn("insurancecode3", when(trim(patientacctscodes.insurancecode3) == '"',"").otherwise(patientacctscodes.insurancecode3))
patientacctscodes = patientacctscodes.withColumn("insurancecode4", when(trim(patientacctscodes.insurancecode4) == '"',"").otherwise(patientacctscodes.insurancecode4))

patientacctscodes = patientacctscodes.withColumn("insurancecode1", when(trim(patientacctscodes.insurancecode1) == '""',"").otherwise(patientacctscodes.insurancecode1))
patientacctscodes = patientacctscodes.withColumn("insurancecode2", when(trim(patientacctscodes.insurancecode2) == '""',"").otherwise(patientacctscodes.insurancecode2))
patientacctscodes = patientacctscodes.withColumn("insurancecode3", when(trim(patientacctscodes.insurancecode3) == '""',"").otherwise(patientacctscodes.insurancecode3))
patientacctscodes = patientacctscodes.withColumn("insurancecode4", when(trim(patientacctscodes.insurancecode4) == '""',"").otherwise(patientacctscodes.insurancecode4))

#patientacctscodes = patientacctscodes.filter("patientacctifk not in('3759389982','3759636922')")

hospinsurancecodes = extract_deltalake_data(
    spark, hdfs_input + "/hospinsurancecodes/current/20991231/"
)
gmrnxhic = spark.read.parquet(gmrn_publish_path + "/globalmrnxhospinsurancecodes/current/*")
tprcoverage = extract_deltalake_data(
    spark, hdfs_input + "/tprcoverage/current/20991231/"
)
tprcoverage = tprcoverage.where(~col("policynumber").like("%|%"))

foundcoverage.createOrReplaceTempView("foundcoverage")
payerxstins.createOrReplaceTempView("edipayersxstateinsurancenames")
gmrnxpacct.createOrReplaceTempView("globalmrnxpacct")
gmrnxhic.createOrReplaceTempView("globalmrnxhospinsurancecodes")
patientacctscodes.createOrReplaceTempView("patientacctscodes")
hospinsurancecodes.createOrReplaceTempView("hospinsurancecodes")
tprcoverage.createOrReplaceTempView("tprcoverage") 

# Step 2 - Get Records to update GlobalMRNxHospInsuranceCodes with TPR coverage
gmrnhic_tprcoverage = """
select x.globalmrnifk,f.patientacctifk,f.hospitalfk,s.stateinspayername as insurancecode,substr(t.policynumber, 1,20 ) as InsPolicyID,f.foundcoverageipk
from foundcoverage f 
inner join tprcoverage t on f.hospitalfk=t.hospitalfk and f.foundcoverageipk=t.foundcoverageifk
inner join edipayersxstateinsurancenames s  on s.srcedipartnerfk=f.edipartnerfk and upper(s.stateinspayername)=upper(t.coname)
inner join globalmrnxpacct x on x.hospitalfk=f.hospitalfk and x.patientacctifk=f.patientacctifk
left join globalmrnxhospinsurancecodes gxh  on gxh.globalmrnifk=x.globalmrnifk and upper(coalesce(gxh.inspolicyid,''))=upper(substr(t.policynumber, 1, 20))
where t.policynumber is not null and t.policynumber !='' and gxh.globalmrnifk is null
"""

gmrnhic_tprcoverage = spark.sql(gmrnhic_tprcoverage)

# Step 3 create view with patientacctscodes data including all insurance codes

dt = (
    spark.sql("SELECT date_add(MAX(createdate),-185) as maxval from globalmrnxpacct")
    .collect()[0]
    .asDict()["maxval"]
)

gmrnhic_patientacctcodes = spark.sql(
    """SELECT x.globalmrnifk,x.patientacctifk,x.hospitalfk,c.insurancecode1,c.insurancecode2,
c.insurancecode3,c.insurancecode4,c.ins1policyid,c.ins2policyid,c.ins3policyid,c.ins4policyid
from globalmrnxpacct x 
inner join patientacctscodes c on c.hospitalfk=x.hospitalfk and c.patientacctifk=x.patientacctifk and c.updatedate>'{0}'""".format(
        dt
    )
)

gmrnhic_patientacctcodes.createOrReplaceTempView("gmrnhic_patientacctcodes")

# step 4 Get Records by joining with each of the 4 insurance codes

gmrnhic_patientacctcodes_ins1 = """
select c.globalmrnifk,c.patientacctifk,c.hospitalfk ,c.insurancecode1 as insurancecode ,c.ins1policyid as inspolicy,'' as foundcoverageifk
from gmrnhic_patientacctcodes c
inner join hospinsurancecodes i on i.hospitalfk=c.hospitalfk and trim(upper(coalesce(i.code,'')))= trim(upper(coalesce(c.insurancecode1,'')))
left join globalmrnxhospinsurancecodes gxi on gxi.hospitalfk=c.hospitalfk and c.patientacctifk=gxi.patientacctifk 
and trim(upper(coalesce(c.insurancecode1,''))) = trim(upper(coalesce(gxi.insurancecode,''))) and trim(upper(coalesce(c.ins1policyid,''))) = trim(upper(coalesce(gxi.inspolicyid,'')))
where c.insurancecode1 !='' and gxi.insurancecode is null
"""

gmrnhic_patientacctcodes_ins2 = """
select c.globalmrnifk,c.patientacctifk,c.hospitalfk ,c.insurancecode2 as insurancecode ,c.ins2policyid as inspolicy ,'' as foundcoverageifk
from gmrnhic_patientacctcodes c
inner join hospinsurancecodes i on i.hospitalfk=c.hospitalfk and trim(upper(coalesce(i.code,'')))= trim(upper(coalesce(c.insurancecode2,'')))
left join globalmrnxhospinsurancecodes gxi on gxi.hospitalfk=c.hospitalfk and c.patientacctifk=gxi.patientacctifk 
and trim(upper(coalesce(c.insurancecode2,''))) = trim(upper(coalesce(gxi.insurancecode,''))) and trim(upper(coalesce(c.ins2policyid,''))) = trim(upper(coalesce(gxi.inspolicyid,''))) 
where c.insurancecode2 !='' and gxi.insurancecode is null
"""

gmrnhic_patientacctcodes_ins3 = """
select c.globalmrnifk,c.patientacctifk,c.hospitalfk ,c.insurancecode3 as insurancecode ,c.ins3policyid as inspolicy ,'' as foundcoverageifk
from gmrnhic_patientacctcodes c
inner join hospinsurancecodes i on i.hospitalfk=c.hospitalfk and trim(upper(coalesce(i.code,'')))= trim(upper(coalesce(c.insurancecode3,'')))
left join globalmrnxhospinsurancecodes gxi on gxi.hospitalfk=c.hospitalfk and c.patientacctifk=gxi.patientacctifk 
and trim(upper(coalesce(c.insurancecode3,''))) = trim(upper(coalesce(gxi.insurancecode,''))) and trim(upper(coalesce(c.ins3policyid,''))) = trim(upper(coalesce(gxi.inspolicyid,''))) 
where c.insurancecode3 !='' and gxi.insurancecode is null
"""

gmrnhic_patientacctcodes_ins4 = """
select c.globalmrnifk,c.patientacctifk,c.hospitalfk ,c.insurancecode4 as insurancecode ,c.ins4policyid as inspolicy, '' as foundcoverageifk
from gmrnhic_patientacctcodes c
inner join hospinsurancecodes i on i.hospitalfk=c.hospitalfk and trim(upper(coalesce(i.code,'')))= trim(upper(coalesce(c.insurancecode4,'')))
left join globalmrnxhospinsurancecodes gxi on gxi.hospitalfk=c.hospitalfk 
and c.patientacctifk=gxi.patientacctifk and trim(upper(coalesce(c.insurancecode4,''))) = trim(upper(coalesce(gxi.insurancecode,''))) 
and trim(upper(coalesce(c.ins4policyid,''))) = trim(upper(coalesce(gxi.inspolicyid,'')))
where c.insurancecode4 !='' and gxi.insurancecode is null
"""

gmrnhic_patientacctcodes_ins1 = spark.sql(gmrnhic_patientacctcodes_ins1)
gmrnhic_patientacctcodes_ins2 = spark.sql(gmrnhic_patientacctcodes_ins2)
gmrnhic_patientacctcodes_ins3 = spark.sql(gmrnhic_patientacctcodes_ins3)
gmrnhic_patientacctcodes_ins4 = spark.sql(gmrnhic_patientacctcodes_ins4)
# step 5 - Union all DataFrames , dedupe

gmrnhic1 = (
    gmrnhic_patientacctcodes_ins1.union(gmrnhic_patientacctcodes_ins2)
    .union(gmrnhic_patientacctcodes_ins3)
    .union(gmrnhic_patientacctcodes_ins4)
    .dropDuplicates()
)

gmrnhic_all = (
    gmrnhic1.union(gmrnhic_patientacctcodes_ins4)
    .union(gmrnhic_tprcoverage)
    .dropDuplicates()
)

gmrnhic_patientacctcodes_ins1.unpersist()
gmrnhic_patientacctcodes_ins2.unpersist()
gmrnhic_patientacctcodes_ins3.unpersist()
gmrnhic_patientacctcodes_ins4.unpersist()
gmrnhic1.unpersist()

gmrnhic = gmrnhic_all.withColumn("isdeltedflag", lit("I"))

gmrnhic = gmrnhic.withColumn(
    "insurancecode", regexp_replace(col("insurancecode"), "\\\\", "")
)
gmrnhic = gmrnhic.withColumn(
    "insurancecode", regexp_replace(col("insurancecode"), '"', "")
)

gmrnhic.repartition(1).write.mode("overwrite").format("csv").options(
    timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", delimiter="\x01", emptyValue=""
).save(hdfs_output_gmrnhic_inserts)