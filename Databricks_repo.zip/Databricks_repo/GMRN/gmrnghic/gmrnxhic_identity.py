# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("hdfs_input","")
dbutils.widgets.getArgument("hdfs_input")
hdfs_input= getArgument("hdfs_input")

dbutils.widgets.text("gmrn_publish_path","")
dbutils.widgets.getArgument("gmrn_publish_path")
gmrn_publish_path= getArgument("gmrn_publish_path")

dbutils.widgets.text("hdfs_output_gmrnhic_updates","")
dbutils.widgets.getArgument("hdfs_output_gmrnhic_updates")
hdfs_output_gmrnhic_updates= getArgument("hdfs_output_gmrnhic_updates")

dbutils.widgets.text("hdfs_output_gmrnhic_pk","")
dbutils.widgets.getArgument("hdfs_output_gmrnhic_pk")
hdfs_output_gmrnhic_pk= getArgument("hdfs_output_gmrnhic_pk")

dbutils.widgets.text("hdfs_output_gmrnhic_inserts","")
dbutils.widgets.getArgument("hdfs_output_gmrnhic_inserts")
hdfs_output_gmrnhic_inserts= getArgument("hdfs_output_gmrnhic_inserts")


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

hdfs_input = baseurl+hdfs_input
gmrn_publish_path= baseurl+ gmrn_publish_path
hdfs_output_gmrnhic_inserts = baseurl+hdfs_output_gmrnhic_inserts+bc+'/' 
hdfs_output_gmrnhic_pk = baseurl + hdfs_output_gmrnhic_pk + bc+'/'
hdfs_output_gmrnhic_updates = baseurl + hdfs_output_gmrnhic_updates + bc+'/'

# COMMAND ----------

#!/bin/python -e
#   Avishek Mallik
#   This script takes the input as hics update and inserts and create delta files and assign unique key to each new record

from pyspark.sql.types import *
from pyspark.sql import SparkSession
import datetime
from pyspark.sql.functions import col,monotonically_increasing_id
from pyspark.sql.functions import unix_timestamp,udf
from pyspark.sql.functions import trim
from pyspark.sql.functions import substring
from pyspark.sql.functions import row_number,lit,min,max
from functools import reduce
from pyspark.sql import DataFrame
from pyspark.sql.window import Window
import sys
import os

# COMMAND ----------

static_dd = '2099-12-31'
numeric_lit = 0
current_dt=datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]

#udf for creating incrmental unquie number 

def addpkvalue(val,row_number):
   val = val + int(row_number)
   return val

gmrnxhicdelta_schema = StructType([
    StructField("globalmrnifk", StringType(), True),
    StructField("patientacctifk", StringType(), True),
    StructField("hospitalfk", StringType(), True),
    StructField("insurancecode", StringType(), True),
    StructField("inspolicyid", StringType(), True),
    StructField("srcfoundcoverageifk", StringType(), True),
    StructField("isdeletedflag", StringType(), True)])


#Step 1- read all the datasets 

gmrnxhic=spark.read.parquet(gmrn_publish_path+"/globalmrnxhospinsurancecodes/current/*/")

gmrnxhic=gmrnxhic.withColumn("globalmrnxhospinsurancecodespkint",gmrnxhic.globalmrnxhospinsurancecodespk.cast("long"))
#mode="FAILFAST"

gmrnxhicupdate=spark.read.format("csv").schema(gmrnxhicdelta_schema).options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",mode="FAILFAST",sep='\x01', quote="").load(hdfs_output_gmrnhic_updates)

gmrnxhicinsert=spark.read.format("csv").schema(gmrnxhicdelta_schema).options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",mode="FAILFAST",sep='\x01', quote="").load(hdfs_output_gmrnhic_inserts)
#gmrnxhicinsert = gmrnxhicinsert.filter(gmrnxhicinsert.inspolicyid == '502801007')


# finding the max value from the globalmrnxhospinsurancecodes dataset

mxval = gmrnxhic.where(col("globalmrnxhospinsurancecodespkint").isNotNull()) \
       .agg({"globalmrnxhospinsurancecodespkint": "max"}).collect()[0][0]

#assigning the max value to the variable

numeric_lit = int(mxval) #change it to long

#print numeric_lit

#definng the udf

udf_addpkvalue = udf(addpkvalue, LongType())

#union of the updates and insert dataset to create the new records for insert

gmrnxhicinsert = gmrnxhicinsert.union(gmrnxhicupdate) 

#adding the staticdate volumn for rownum

gmrnxhicinsert = gmrnxhicinsert.withColumn("staticdate",lit(static_dd))

#create rownum for each row 

gmrnxhicinsert_rownum = gmrnxhicinsert.withColumn("row_number", row_number().over(Window.partitionBy("staticdate").orderBy("staticdate")))

#creating unique key by incrementing by 1 also adding createdate which current datetime

gmrnxhicnsert_stage = gmrnxhicinsert_rownum.withColumn("globalmrnxhospinsurancecodespk",udf_addpkvalue(lit(numeric_lit),gmrnxhicinsert_rownum.row_number)) \
                                           .withColumn("createdate",lit(current_dt))

#creating the daatframe with columns needed 

gmrnxhicnsert = gmrnxhicnsert_stage.select(gmrnxhicnsert_stage.globalmrnxhospinsurancecodespk,gmrnxhicnsert_stage.globalmrnifk,gmrnxhicnsert_stage.patientacctifk,gmrnxhicnsert_stage.hospitalfk \
                                           ,gmrnxhicnsert_stage.insurancecode,gmrnxhicnsert_stage.inspolicyid,gmrnxhicnsert_stage.createdate \
                                           ,gmrnxhicnsert_stage.srcfoundcoverageifk,gmrnxhicnsert_stage.isdeletedflag)

gmrnxhicnsert = gmrnxhicnsert.withColumn("isdeletedflag",lit("0"))

#writing out the results
#gmrnxhicnsert.show(5,False)

gmrnxhicnsert.repartition(10).write.mode("overwrite").format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="\x01",emptyValue='').save(hdfs_output_gmrnhic_pk)