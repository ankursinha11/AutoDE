# Databricks notebook source
import sys
import os
import subprocess
from pyspark.storagelevel import StorageLevel
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import *
from datetime import datetime

# COMMAND ----------

# SET parameters#
dbutils.widgets.text("prepublish_ghic_output","")
dbutils.widgets.getArgument("prepublish_ghic_output")
prepublish_ghic_output= getArgument("prepublish_ghic_output")

dbutils.widgets.text("publish_ghic_output", "")
dbutils.widgets.getArgument("publish_ghic_output")
publish_ghic_output= getArgument("publish_ghic_output")

dbutils.widgets.text("tablename", "")
dbutils.widgets.getArgument("tablename")
tablename= getArgument("tablename")


dbutils.widgets.text("bc", "")
dbutils.widgets.getArgument("bc")
bc = getArgument("bc")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

hdfs_repo_staging = baseurl + prepublish_ghic_output + tablename + "/" + bc + "/"
hdfs_repo_publish = baseurl + publish_ghic_output + tablename
#hdfs_repo_publish_current= hdfs_repo_publish + "/current/" + bc + "/"
hdfs_repo_publish_current= hdfs_repo_publish + "/current/" 
#hdfs_repo_publish_archives= hdfs_repo_publish + "/archive/"+bc+"/"
hdfs_repo_publish_archives= hdfs_repo_publish + "/archive/"


# COMMAND ----------

print(hdfs_repo_staging)
print(hdfs_repo_publish)
print(hdfs_repo_publish_current)
print(hdfs_repo_publish_archives)

# COMMAND ----------

try:
    staging_path = dbutils.fs.ls(hdfs_repo_staging) 
    if(len(staging_path) > 0):
        dbutils.fs.rm(hdfs_repo_publish_archives, True)
#    dbutils.fs.mkdirs(hdfs_repo_publish_current)
#    dbutils.fs.mkdirs(hdfs_repo_publish_archives)
    dbutils.fs.mv(hdfs_repo_publish_current, hdfs_repo_publish_archives, True)
    print("Migration from Current to Archive")
    dbutils.fs.mv(hdfs_repo_staging, hdfs_repo_publish_current+bc, True)
    print("Migration from pre_publish to publish")
except Exception as e:
    if 'java.io.FileAlreadyExistsException' in str(e):
        print('The file exists in the directory')