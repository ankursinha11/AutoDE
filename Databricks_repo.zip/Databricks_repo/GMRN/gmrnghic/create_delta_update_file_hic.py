# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("hdfs_input","")
dbutils.widgets.getArgument("hdfs_input")
hdfs_input= getArgument("hdfs_input")

dbutils.widgets.text("gmrn_publish_path","")
dbutils.widgets.getArgument("gmrn_publish_path")
gmrn_publish_path= getArgument("gmrn_publish_path")

dbutils.widgets.text("hdfs_output_gmrnhic_updates","")
dbutils.widgets.getArgument("hdfs_output_gmrnhic_updates")
hdfs_output_gmrnhic_updates= getArgument("hdfs_output_gmrnhic_updates")

dbutils.widgets.text("hdfs_output_gmrnhic_deletes","")
dbutils.widgets.getArgument("hdfs_output_gmrnhic_deletes")
hdfs_output_gmrnhic_deletes= getArgument("hdfs_output_gmrnhic_deletes")

dbutils.widgets.text("hdfs_output_gmrnhic_history","")
dbutils.widgets.getArgument("hdfs_output_gmrnhic_history")
hdfs_output_gmrnhic_history= getArgument("hdfs_output_gmrnhic_history")


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

hdfs_input = baseurl+hdfs_input
gmrn_publish_path= baseurl+ gmrn_publish_path
hdfs_output_gmrnhic_deletes = baseurl+hdfs_output_gmrnhic_deletes + bc+'/'
hdfs_output_gmrnhic_history = baseurl + hdfs_output_gmrnhic_history + bc+'/'
hdfs_output_gmrnhic_updates = baseurl + hdfs_output_gmrnhic_updates + bc+'/'

# COMMAND ----------

#!/bin/python -e
# Avishek Mallik
# Script to find out updates in GHIC table using merge output

from pyspark.sql.types import *
from pyspark.sql import SparkSession
from datetime import datetime, timedelta
from pyspark.sql.functions import col,monotonically_increasing_id,udf,trim
from pyspark.sql.functions import unix_timestamp
from pyspark.sql.functions import row_number,lit,min,max
from pyspark.sql import DataFrame
from pyspark.sql.window import Window
from pyspark.sql.types import LongType, StringType, StructField, StructType, BooleanType, ArrayType, IntegerType, TimestampType
import sys

# COMMAND ----------

#schema for the merge output 

merge_schema = StructType([
    StructField("toglobalmrnifk", StringType(), True),        
    StructField("fromglobalmrnifk", StringType(), True),
    StructField("matchtype", StringType(), True),
])

#reading GMRNHICS  data 

gmrnhics = spark.read.parquet(gmrn_publish_path+"/globalmrnxhospinsurancecodes/current/*")
gmrnxpacct= spark.read.parquet(gmrn_publish_path+"/globalmrnxpacct/current/*")

#join cond for gmrnxpacct and gmrnhics

join_cond = [ gmrnhics.hospitalfk == gmrnxpacct.hospitalfk , gmrnhics.patientacctifk == gmrnxpacct.patientacctifk , gmrnhics.globalmrnifk != gmrnxpacct.globalmrnifk ] 

#inner join gmrnhics and merge op to get the changes for gmrnid

joined_hic = gmrnhics.join(gmrnxpacct,join_cond,'inner') \
     .select(gmrnhics["*"],gmrnxpacct.globalmrnifk.alias('globalmrnifk_gmrnxpacct')).dropDuplicates()

#creating the delta file for gmrnhics with the updates 

gmrnhics_updates = joined_hic.select(joined_hic.globalmrnifk_gmrnxpacct,joined_hic.patientacctifk,joined_hic.hospitalfk \
             ,joined_hic.insurancecode,joined_hic.inspolicyid,joined_hic.srcfoundcoverageifk) \
      .withColumn("isdeletedflag", lit("2"))

#creating the log file with all the deletes/updates 

gmrnhics_history = joined_hic.select(joined_hic.globalmrnxhospinsurancecodespk,joined_hic.globalmrnifk,joined_hic.patientacctifk,joined_hic.hospitalfk \
             ,joined_hic.insurancecode,joined_hic.inspolicyid,joined_hic.createdate,joined_hic.srcfoundcoverageifk) \
      .withColumn("isdeletedflag", lit("1"))

#wrting out the delta file and logfile 

gmrnhics_updates.repartition(1).write.mode("overwrite").format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="\x01",emptyValue='').save(hdfs_output_gmrnhic_updates)
gmrnhics_history.repartition(1).write.mode("overwrite").format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="\x01",emptyValue='').save(hdfs_output_gmrnhic_deletes)

gmrnhics_history.repartition(100).write.mode("overwrite").parquet(hdfs_output_gmrnhic_history)