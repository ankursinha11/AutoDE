# Databricks notebook source
import sys
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import *
from datetime import datetime

# COMMAND ----------

start=datetime.now()
print(start)

# COMMAND ----------

# SET parameters#
dbutils.widgets.text("publishdir","")
dbutils.widgets.getArgument("publishdir")
publishdir= getArgument("publishdir")

dbutils.widgets.text("opdir", "")
dbutils.widgets.getArgument("opdir")
opdir= getArgument("opdir")

dbutils.widgets.text("datastagedir", "")
dbutils.widgets.getArgument("datastagedir")
datastagedir= getArgument("datastagedir")

dbutils.widgets.text("tablename", "")
dbutils.widgets.getArgument("tablename")
tablename= getArgument("tablename")

dbutils.widgets.text("bc", "")
dbutils.widgets.getArgument("bc")
bc = getArgument("bc")

dbutils.widgets.text("adls_path","")
dbutils.widgets.getArgument("adls_path")
adls_path= getArgument("adls_path")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

datastagedir = baseurl +datastagedir
opdir = baseurl+adls_path+opdir
publishdir = baseurl + publishdir
print(datastagedir)
print(opdir)
print(publishdir)

# COMMAND ----------

# Creating keyValue Pair Dictionary for GMRN table uniq keys

pUniqKeyDictionary = {

    "globalmrndemographics": "globalmrndemographicsipk",
    "globalmrn": "globalmrnipk",
    "globalmrnxpacct": "globalmrnxpacctipk",
    "globalmrnxhospinsurancecodes": "globalmrnxhospinsurancecodespk",

}

# COMMAND ----------

pUniqKey = pUniqKeyDictionary.get(tablename)
pListUniqJoinCol = pUniqKey.split(",")

print("pListUniqJoinCol : " + str(pListUniqJoinCol))


# COMMAND ----------

# Reading the RAW data from Publish Dir
publishdir = publishdir+'/'+tablename+'/current/*'
df_raw = spark.read.parquet(publishdir)


# COMMAND ----------

# Extracting the Schema from RAW and appending isdeleted to it
pSchemaRaw = df_raw.schema
pLastColumn = [StructField("isdeleted", StringType(), True)]
pSchemaDelta = StructType(df_raw.schema.fields + pLastColumn)


# COMMAND ----------

# using the extracted Schema reading the DELTA (Ins and Del) files

df_delta_delete = spark.read.format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", delimiter="\x01").schema(pSchemaDelta).load(datastagedir + tablename + "/" + bc + '/*delete*.dat').dropDuplicates()
df_delta_insert = spark.read.format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", delimiter="\x01").schema(pSchemaDelta).load(datastagedir + tablename + "/" + bc + '/*delta*.dat').dropDuplicates()


# COMMAND ----------

# Appending pseudo colunm isdeleted to RAW dataframe
df_raw = df_raw.withColumn("isdeleted", lit(0))


# COMMAND ----------

# left-anti Join RAW DF vs DEL DF
df_raw_post_del = df_raw.join(broadcast(df_delta_delete), pListUniqJoinCol, 'leftanti').select(df_raw['*'])


# COMMAND ----------

# COOKED DF =  RAW(POST_DELETE) UNION DELTA_INS
df_cooked = df_raw_post_del.unionAll(df_delta_insert).drop("isdeleted")


# COMMAND ----------

# Write the COOKED_DF to STAGE dir
df_cooked.repartition(200).write.mode("overwrite").parquet(opdir + "/" + tablename + "/" + bc)