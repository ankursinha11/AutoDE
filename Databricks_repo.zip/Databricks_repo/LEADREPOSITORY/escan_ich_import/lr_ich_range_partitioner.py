# Databricks notebook source
### /staging/input/ie/bc

####path_parsed - ie_prebdf pa rsed_all o/p
##path_blocked_clientid - static lookup file  
###path_to_serve - not needed
##path_tupayer_input - from data ingestion tables
##

# COMMAND ----------

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("cdd_dir","")
dbutils.widgets.getArgument("cdd_dir")
cdd_dir= getArgument("cdd_dir")

dbutils.widgets.text("path_input","")
dbutils.widgets.getArgument("path_input")
path_input= getArgument("path_input")

dbutils.widgets.text("path_output","")
dbutils.widgets.getArgument("path_output")
path_output= getArgument("path_output")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bcdate","")
dbutils.widgets.getArgument("bcdate")
bcdate= getArgument("bcdate")

dbutils.widgets.text("trange","")
dbutils.widgets.getArgument("trange")
trange= getArgument("trange")

dbutils.widgets.text("path_blocked_clientid","")
dbutils.widgets.getArgument("path_blocked_clientid")
path_blocked_clientid= getArgument("path_blocked_clientid")

dbutils.widgets.text("path_tupayer_input","")
dbutils.widgets.getArgument("path_tupayer_input")
path_tupayer_input= getArgument("path_tupayer_input")

dbutils.widgets.text("path_to_serve","")
dbutils.widgets.getArgument("path_to_serve")
path_to_serve= getArgument("path_to_serve")

dbutils.widgets.text("path_parsed","")
dbutils.widgets.getArgument("path_parsed")
path_parsed= getArgument("path_parsed")


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/schema_util

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

# spark.conf.set("fs.azure.account.key.divyaprodstorageact1.dfs.core.windows.net","0yOD1SCSgZwOHAlWBJgYDEv4+EJXpuNOhprl+BW1zte8lVhst8L59ZTRZD6MBnWwsCToZszWjZ6Z+ASt4XW8iw==")

# COMMAND ----------

# ### to test manually
# 
# path_input= "abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/karthik/data/cdd/ich_import/data/scratch/lr_ich_xml_parsed/transaction/25JUL2023-18"
# path_output = "abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/karthik/data/cdd/ich_import/data/cooked/lr_transaction/"
# path_to_serve = "abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/karthik/data/cdd/ich_import/data/toserve/ich_import/25JUL2023-18"
# tablename = "lr_ich_transaction"
# trange = 5
# path_blocked_clientid = "abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/karthik/data/cdd/ich_import/clientIdsToBlock/"
# path_tupayer_input = "abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/karthik/data/cdd/ich_import/data/publish/"
# path_parsed = "abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/karthik/data/cdd/ich_import/data/ie/parsed_all/25JUL2023-18"

# /leadrepo/data/transform/cooked/lr_transaction/


# COMMAND ----------



path_input_loc = baseurl + path_input + bcdate
path_output_loc = baseurl + path_output
path_to_serve_loc = baseurl + path_to_serve + bcdate
path_blocked_clientid_loc = baseurl + cdd_dir + path_blocked_clientid
path_tupayer_input_loc = baseurl + path_tupayer_input
path_parsed_loc = baseurl + cdd_dir + path_parsed + bcdate

path_input = path_input_loc
path_output = path_output_loc
path_to_serve = path_to_serve_loc
path_blocked_clientid = "abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/cdd/staging/input/clientIdsToBlock/"
path_tupayer_input = path_tupayer_input_loc
path_parsed = path_parsed_loc

# print(path_input)
print(cdd_dir,'\ninputPath: ',path_input,'\noutputPath: ',path_output, '\npath_to_serve: ',path_to_serve,'\npath_blocked_clientid: ',path_blocked_clientid,'\npath_tupayer_input: ',path_tupayer_input, '\npath_parsed: ',path_parsed  )


# COMMAND ----------

# %run Users/karthik.dodda@nthrive.com/tu_data_quality.py

# COMMAND ----------

import os
import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
from pyspark import SparkContext
from pyspark.conf import SparkConf
from configparser import SafeConfigParser
from pyspark.sql.functions import lower
from pyspark.sql.functions import *


def extract_csv_data(path_input, schema, path_blocked_clientid, path_parsed, isValidresponsetype):
    raw_data = spark.read.format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", quote="", delimiter='|').schema(schema).load(path_input).drop("xml_payer_request").drop("xml_payer_response").drop("xml_request_fields").dropDuplicates()

    # find all records that are in parsed not in the pig extracted ICD data
    parsed_schema = StructType([
        StructField("transactionkey", StringType()),
        StructField("createdate", StringType()),
        StructField("providerid", StringType()),
        StructField("providerlastnameorgname", StringType()),
        StructField("lastname", StringType()),
        StructField("firstname", StringType()),
        StructField("middlename", StringType()),
        StructField("gender", StringType()),
        StructField("dob", StringType()),
        StructField("ssn", StringType()),
        StructField("groupnumber", StringType()),
        StructField("subscribersuffixcode", StringType()),
        StructField("subscriberidcode", StringType()),
        StructField("coverageid", StringType()),
        StructField("addr", StringType()),
        StructField("state", StringType()),
        StructField("city", StringType()),
        StructField("zip", StringType()),
        StructField("subscriberaddressnumbers", StringType()),
        StructField("dateofservice", StringType()),
        StructField("responseresultext", StringType()),
        StructField("responsestatus", StringType()),
        StructField("payerid", StringType()),
        StructField("payerproviderid", StringType()),
        StructField("payerlastnameorgname", StringType()),
        StructField("clientid", StringType()),
        StructField("breadcrumbs", StringType()),
        StructField("dependentflag", StringType())
    ])

    parsed_data = spark.read.format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", quote="", delimiter='|').schema(parsed_schema).load(path_parsed)
    isValidResponseType_udf = udf(isValidResponseType, IntegerType())
    parsed_data = parsed_data.withColumn("isvalidresponse",isValidResponseType_udf(parsed_data.responsestatus,parsed_data.responseresultext))
    parsed_data = parsed_data.filter(parsed_data.isvalidresponse == 1)
    parsed_data = parsed_data.withColumn("coverageid", blank_as_null("coverageid"))
    parsed_data = parsed_data.withColumn("firstname", blank_as_null("firstname"))
    parsed_data = parsed_data.withColumn("lastname", blank_as_null("lastname"))
    parsed_data = parsed_data.withColumn("dob", blank_as_null("dob"))
    parsed_data = parsed_data.withColumn("ssn", blank_as_null("ssn"))
    parsed_data = parsed_data.withColumn("dependentflag", when(upper(trim(parsed_data.dependentflag))=="Y","1")\
                                                         .when(upper(trim(parsed_data.dependentflag))=="N","0")\
                                                         .otherwise(parsed_data.dependentflag))

    raw_data.createOrReplaceTempView("RAW_DATA")
    parsed_data.createOrReplaceTempView("PARSED_DATA")

    spark_sql_00 = """
        SELECT DISTINCT
        A.transactionkey,
        '2' as sourcekey,
        A.payerid,
        A.clientid,
        A.responsestatus,
        'ich' AS verifiedsource,
        A.groupnumber,
        A.coverageid,
        '' AS sourcepatientacctifk,
        '' AS hcsystemfk,
        A.firstname,
        A.middlename,
        A.lastname,
        A.gender,
        A.dob,
        A.ssn,
        A.addr,
        A.city,
        A.state,
        A.zip,
        A.dependentflag,
        A.createdate,
        '' as updatedate,
        0 AS isdeletedflag,
        current_timestamp() as lr_createdate,
        A.breadcrumbs AS lr_creatingmodule
       FROM PARSED_DATA A
       LEFT JOIN RAW_DATA R ON A.transactionkey==R.transactionkey
       WHERE R.transactionkey is null
         AND A.firstname is not null
         AND A.lastname is not null
         AND (A.dob is not null OR A.ssn is not null)
         AND A.coverageid is not null
      """

    new_raw_data = spark.sql(spark_sql_00)
    all_raw_data = raw_data.union(new_raw_data)
    all_raw_data.createOrReplaceTempView("ICH_RAW_DATA")

    spark_sql_01 = """
    SELECT
       DISTINCT
       A.transactionkey,
       A.sourcekey,
       A.payerid,
       A.clientid,
       A.responsestatus,
       A.verifiedsource,
       A.groupnumber,
       CASE
           WHEN LENGTH(REGEXP_REPLACE(TRIM(A.coverageid), '[^-a-zA-Z0-9]+', '')) > 3 THEN REGEXP_REPLACE(TRIM(A.coverageid), '[^-a-zA-Z0-9]+', '')
           ELSE 'XX'
           END AS coverageid,
       A.sourcepatientacctifk,
       A.hcsystemfk,
       A.firstname,
       A.middlename,
       A.lastname,
       A.gender,
       A.dob,
       A.ssn,
       A.addr,
       A.city,
       CASE WHEN (
                  LENGTH(UPPER(TRIM(A.state))) = '2' AND
                  UPPER(TRIM(A.state)) IN ('AL','AK','AZ','AR','CA','CO','CT','DE','DC','FL','GA','HI','ID','IL','IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VT','VA','WA','WV','WI','WY')
                  )
       THEN UPPER(TRIM(A.state))
       ELSE 'XX' END AS state,
       A.zip,
       A.dependentflag,
       A.createdate,
       A.updatedate,
       A.isdeletedflag,
       A.lr_createdate,
       A.lr_creatingmodule
FROM (SELECT A.*,
             CASE
               WHEN (A.firstname IS NULL AND A.lastname IS NULL AND A.dob IS NULL AND A.ssn IS NULL AND A.gender IS NULL) THEN '0'
               ELSE '1'
             END AS isdemovalid
      FROM ICH_RAW_DATA A) A
WHERE A.isdemovalid = 1"""
    raw_data = spark.sql(spark_sql_01).filter("coverageid <> 'XX'").dropDuplicates()
    blocked_data = spark.read.format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",  quote="", delimiter='\x01').load(path_blocked_clientid).dropDuplicates()
    blocked_data = blocked_data.withColumnRenamed("_c0", "clientid")
    raw_data = raw_data.join(blocked_data, "clientid", 'left').where(blocked_data.clientid.isNull()).select(raw_data['*']).dropDuplicates()
    for column in raw_data.columns:
        raw_data = raw_data.withColumn(column, trim(col(column)))
    raw_data = raw_data.withColumn("state", when(length(raw_data.state) > 2, lit('')).otherwise(raw_data.state))
    raw_data = raw_data.withColumn("state", when(raw_data.state == '.', lit('')).otherwise(raw_data.state))
    raw_data = raw_data.withColumn("state", when(raw_data.state == '-', lit('')).otherwise(raw_data.state))
    raw_data = raw_data.withColumn("state", when(raw_data.state == ',', lit('')).otherwise(raw_data.state))
    raw_data = raw_data.withColumn("state", when(raw_data.state == '_', lit('')).otherwise(raw_data.state))
    raw_data = raw_data.withColumn("state", when(raw_data.state == '__', lit('')).otherwise(raw_data.state))
    for c_name in raw_data.columns:
        raw_data = raw_data.withColumn(c_name, regexp_replace(c_name, 'NULL', ''))
    for c_name in raw_data.columns:
        raw_data = raw_data.withColumn(c_name, regexp_replace(c_name, 'null', ''))
    return raw_data



# COMMAND ----------

def isValidResponseType(responsestd,responseext):
     if responsestd is not None and str(responsestd).strip()=="3" and (responseext is None or str(responseext).strip()=="" or str(responseext).strip().lower()=="null"):
        return 0
     return 1

# COMMAND ----------

def extract_tupayer_data(hdfs_tupayer_path):
    tupayer_data = spark.read.parquet(hdfs_tupayer_path + "/edipayers_tupayeridmapping/current/*").select("tupayerid", "edipayerfk")
    edipartner_data = spark.read.parquet(hdfs_tupayer_path + "/edipartners/current/*")
    edipartner_data = edipartner_data.where(((edipartner_data.isenabledflag == 1) & (edipartner_data.edipartnerpk > 0))).select("edipayerfk", "edipartnerpk")
    p = tupayer_data.join(edipartner_data, (tupayer_data.edipayerfk == edipartner_data.edipayerfk)).select(tupayer_data.tupayerid.cast(IntegerType()), edipartner_data.edipartnerpk.alias("edipartnerfk"))
    # special considerations for certains payers
    cond = when(col("tupayerid") == 10118, lit(91)).otherwise(col("edipartnerfk"))
    cond1 = when(col("tupayerid") == 10102, lit(30)).otherwise(col("edipartnerfk"))
    cond2 = when(col("tupayerid") == 10001, lit(82)).otherwise(col("edipartnerfk"))
    cond3 = when(col("tupayerid") == 10055, lit(8)).otherwise(col("edipartnerfk"))
    p = p.withColumn("edipartnerfk", cond)
    p = p.withColumn("edipartnerfk", cond1)
    p = p.withColumn("edipartnerfk", cond2)
    p = p.withColumn("edipartnerfk", cond3).dropDuplicates()
    return p

# COMMAND ----------

def transform_data(df, df_tupayer, tablename, p_factor):
    if tablename == 'lr_ich_transaction':
        df_join = df.join(df_tupayer, (df.payerid == df_tupayer.tupayerid), "left").select(df["*"], df_tupayer.edipartnerfk)
        cond = when(col("edipartnerfk").isNull(), col("payerid")).otherwise(col("edipartnerfk"))
        df_join = df_join.withColumn("payerid", cond).drop("edipartnerfk")
        return df_join.withColumn("transactionrange", (df.transactionkey.cast("bigint") % p_factor).cast("bigint"))
    else:
        return df.withColumn("transactionrange", (df.transactionkey.cast("bigint") % p_factor).cast("bigint"))



# COMMAND ----------


def blank_as_null(x):
    return when(((trim(col(x)) != "") & (trim(lower(col(x))) != "null")), col(x)).otherwise(None)

# COMMAND ----------

def append_data(df, hdfs_path):
    df = df.repartition(15)
    df.write.partitionBy("transactionrange").mode("append").parquet(hdfs_path)
    return None

# COMMAND ----------

def toserve_data(df, hdfs_path):
    df = df.select(df.transactionkey, df.clientid.alias("hospitalfk"), df.payerid, df.coverageid, df.lr_creatingmodule.alias("bc")).dropDuplicates().repartition(20)
    df.write.mode("append").parquet(hdfs_path)
    return None

# COMMAND ----------

lr_ich_transaction_dbfs = "/dbfs/FileStore/lead_repository/ich_import/schema/lr_ich_transaction.schema"
#lr_transactiondemo_adls = "abfss://npp@divyaprodstorageact1.dfs.core.windows.net//sourcecode/leadrepository/workflows/escan_import_fc/schema/lr_transactiondemo.schema"
lr_ich_transaction_adls = baseurl+'/data/leadrepo/config/lr_ich_transaction.schema'

# COMMAND ----------

try:
    if(dbutils.fs.ls(lr_ich_transaction_dbfs)):
        #dbutils.fs.rm(lr_ich_transaction_dbfs, True)
        print("Schema file already exist")
except:
    print("Schema file doesn't exist")
    dbutils.fs.cp(lr_ich_transaction_adls, lr_ich_transaction_dbfs)

dbutils.fs.cp(lr_ich_transaction_adls, lr_ich_transaction_dbfs)
# transactionschema = createSchemaLine(lr_ich_transaction_dbfs)

# COMMAND ----------


def main():

    tablename = "lr_ich_transaction"

    # p_factor = parser.get('trange', 'trange')
    p_factor=trange
    # import schema_util
    # import tu_data_quality as tu
    # schema = schema_util.createSchemaLine(fs_common +"/" + tablename + ".schema")
    schema =createSchemaLine(lr_ich_transaction_dbfs)
    # spark = SparkSession.builder.appName("TU_LR_ICH_RANGE_PARTITIONER").getOrCreate()
    spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)
    # spark.sparkContext.setLogLevel("ERROR")
    df_tupayer = extract_tupayer_data(path_tupayer_input)
    # print(f"input1 file count {df_tupayer.count()}")
    df_raw = extract_csv_data(path_input, schema, path_blocked_clientid, path_parsed, isValidResponseType)
    # print(f"input1 file count {df_raw.count()}")
    df_cooked = transform_data(df_raw, df_tupayer, tablename, p_factor)
    # toserve_data(df_cooked, path_to_serve)
    # print(f"input1 file count {df_cooked.count()}")
    append_data(df_cooked, path_output)
    # spark.stop()
    return None



# COMMAND ----------

main()

# COMMAND ----------

# legacyLoc = r"abfss://npp@divyaprodstorageact1.dfs.core.windows.net/hcecdd/user/phd9appl/CDD/input/CDW/leadrepository/ich_import/data/cooked/lr_transaction/"
# currentLoc = r"abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/karthik/data/cdd/ich_import/data/cooked/my_code_output/"
# legacyDF =  spark.read.parquet(legacyLoc)
# currentDF =  spark.read.parquet(currentLoc)
# # legacyDF =  spark.read.schema(parsed_schema).csv(legacyLoc,sep='\u0001')
# # currentDF =  spark.read.schema(parsed_schema).csv(currentLoc,sep='|')
# legacyDF = legacyDF.drop('bcdate','CurrentDate','Xml_payer_request','Xml_payer_response','Xml_request_fields').na.fill("  ")
# currentDF = currentDF.drop('bcdate','CurrentDate','Xml_payer_request','Xml_payer_response','Xml_request_fields').na.fill("  ")
# print("Legacy ouput:",legacyDF.count()) 
# print("current output:",currentDF.count()) 
# differeceDF = legacyDF.subtract(currentDF)
# print("Difference: ",differeceDF.count())

# COMMAND ----------

# legacy_path_input= r"abfss://npp@divyaprodstorageact1.dfs.core.windows.net/hcecdd/user/phd9appl/CDD/input/CDW/leadrepository/ich_import/data/scratch/lr_ich_xml_parsed/transaction/25JUL2023-18/"
# schema =createSchemaLine(lr_ich_transaction_dbfs)
# #legacy_inputdf = spark.read.csv(legacy_path_input,sep="\u0001")
# legacy_inputdf=spark.read.format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", quote="", delimiter='\x01').schema(schema).load(legacy_path_input).drop("xml_payer_request").drop("xml_payer_response").drop("xml_request_fields").drop("lr_createdate").drop("lr_creatingmodule").dropDuplicates()
# print("current_input:",cuurent_inputdf.count())



# COMMAND ----------

# path_input= r"abfss://npp@divyaprodstorageact1.dfs.core.windows.net/hcecdd/user/phd9appl/CDD/input/CDW/leadrepository/ich_import/karthik/25JUL2023-18/"
# #cuurent_inputdf = spark.read.csv(path_input,sep="|")
# schema =createSchemaLine(lr_ich_transaction_dbfs)
# #legacy_inputdf = spark.read.csv(legacy_path_input,sep="\u0001")
# cuurent_inputdf=spark.read.format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", quote="", delimiter='|').schema(schema).load(path_input).drop("xml_payer_request").drop("xml_payer_response").drop("xml_request_fields").drop("lr_createdate").drop("lr_creatingmodule").dropDuplicates()
# print("current_input:",cuurent_inputdf.count())

# COMMAND ----------

# df=legacy_inputdf.subtract(cuurent_inputdf)
# df.count()

# COMMAND ----------

# display(df)

# COMMAND ----------

# transactionkey=105072786500
# df=legacy_inputdf.filter(col("transactionkey")==lit(transactionkey)).withColumn("tmp",lit(1)).union(cuurent_inputdf.filter(col("transactionkey")==lit(transactionkey)).withColumn("tmp",lit(2)))
# display(df)