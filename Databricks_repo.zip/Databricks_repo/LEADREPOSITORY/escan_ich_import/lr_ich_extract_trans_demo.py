# Databricks notebook source
#input same as ie_prebdf 

# COMMAND ----------

# DBTITLE 1,Input Variables:
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("cdd_dir","")
dbutils.widgets.getArgument("cdd_dir")
cdd_dir= getArgument("cdd_dir")

dbutils.widgets.text("input_path","")
dbutils.widgets.getArgument("input_path")
input_path= getArgument("input_path")

dbutils.widgets.text("output_path","")
dbutils.widgets.getArgument("output_path")
output_path= getArgument("output_path")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bcdate","")
dbutils.widgets.getArgument("bcdate")
bcdate= getArgument("bcdate")


# COMMAND ----------

# DBTITLE 1,Set Base URL

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

# spark.conf.set("fs.azure.account.key.divyaprodstorageact1.dfs.core.windows.net","0yOD1SCSgZwOHAlWBJgYDEv4+EJXpuNOhprl+BW1zte8lVhst8L59ZTRZD6MBnWwsCToZszWjZ6Z+ASt4XW8iw==")

# COMMAND ----------

###prod
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# #### use this box to test with manual params
#  ie_input_dir = 'abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/karthik/data/cdd/ich_import/ie/25JUL2023-18/'
# ie_output_dir= 'abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/karthik/data/lead_repository/publish/ie_output/lr_ich_xml_parsed/transaction/25JUL2023-18'

# COMMAND ----------

# DBTITLE 1,Setting up Input & Output Path
cdd_dir = cdd_dir.format(user)
ie_input_dir =  baseurl + cdd_dir + input_path +bcdate
ie_output_dir = baseurl + output_path +bcdate

print(cdd_dir,'\ninputPath: ',ie_input_dir,'\noutputPath: ',ie_output_dir)

# COMMAND ----------

# DBTITLE 1,Importing Dependencies:
from pyspark.sql.types import StringType,ArrayType
import xml.etree.ElementTree as ET
from pyspark.sql.functions import udf, split, lit, explode ,length,col

# COMMAND ----------

# DBTITLE 1,Reading Input & Generating Output:
from datetime import date
import re


def parse_xml(data,bcdate):
    
    root = ET.fromstring(data)    
    root_identity = [tmp for tmp in list(root) if tmp.tag.endswith('Identity')][0]
    root_Context = [tmp for tmp in list(root) if tmp.tag.endswith('Context')][0]
    node = [node for node in list(root) if node.tag.endswith('Requests')]
    SR = [node1 for node1 in list(node[0]) if node1.tag.endswith('SubmissionRequest')]
    PR = [node2 for node2 in list(SR[0]) if node2.tag.endswith('PayerResponse')][0]
    PReq = [tmp for tmp in list(SR[0]) if tmp.tag.endswith('PayerRequest')][0]
    Identity = [tmp for tmp in list(SR[0]) if tmp.tag.endswith('Identity')][0]
    RF = [tmp for tmp in list(SR[0]) if tmp.tag.endswith('RequestFields')][0]
    print("1")

    ST01 = None
    tmp = PR.find('.//ST')
    if tmp != None and 'ST01' in tmp.keys():
        ST01 = tmp.attrib['ST01']
        ST01 = ST01 if ST01 != None and ST01 != None else ''
    print("2")
    TraceNumber = [TN for TN in list(PReq) if TN.tag.endswith('TraceNumber')][0]
    TraceNumber = TraceNumber.text if TraceNumber != None and TraceNumber.text != None else ''

    ResponseResultStd = [tmp for tmp in list(PR) if tmp.tag.endswith('ResponseResultStd')][0]
    ResponseResultStd = ResponseResultStd.text if ResponseResultStd != None and ResponseResultStd.text != None else ''

    subscriberId = RF.find('.//subscriberId')
    subscriberId = subscriberId.text if subscriberId != None and subscriberId.text != None else ''
    print("3")
    print(f"ResponseResultStd  {ResponseResultStd}")
    print(f"TraceNumber {TraceNumber}")
    print(f"ST01 {ST01}")
    st01_val = ST01.strip() if ST01 is not None else ''
    is_st01_271 = st01_val.isdigit() and int(st01_val) == 271


    #if ResponseResultStd.strip() not in ['1','2','4','6'] and len(TraceNumber) > 0 :
    if ResponseResultStd and ResponseResultStd.strip() not in ['0','3','4','5','7','8','10','15','16','17','312','313','314'] and len(TraceNumber) > 0 and ResponseResultStd.lower()!="none" and is_st01_271:
        
        PayerId = [tmp for tmp in list(Identity) if tmp.tag.endswith('PayerId')][0]
        ClientId = [tmp for tmp in list(root_identity) if tmp.tag.endswith('ClientId')][0]
        
        Received = [tmp for tmp in list(root_Context) if tmp.tag.endswith('Received')][0]
        
        
        output_dict = {}
        
        col_PR = ['ST01','subscriberGroupNumber','dependentGroupNumber','subscriberCoverageId','dependentCoverageId','subscriberLastName','subscriberFirstName','subscriberMiddleName','subscriberAddress','subscriberCity','subscriberState','subscriberZip','subscriberDOB','subscriberGender','subscriberSSN','dependentLastName','dependentFirstName','dependentMiddleName','dependentAddress','dependentCity','dependentState','dependentZip','dependentDOB','dependentGender','dependentSSN']
        find_PR = ['.//ST','.//HL[@HL01="3"]/NM1/REF[@REF01="IG"]','.//HL[@HL01="4"]/NM1/REF[@REF01="IG"]','.//HL[@HL01="3"]/NM1[@NM108="MI"]','.//HL[@HL01="4"]/NM1[@NM108="MI"]','.//HL[@HL01="3"]/NM1','.//HL[@HL01="3"]/NM1','.//HL[@HL01="3"]/NM1','.//HL[@HL01="3"]/NM1/N3','.//HL[@HL01="3"]/NM1/N4','.//HL[@HL01="3"]/NM1/N4','.//HL[@HL01="3"]/NM1/N4','.//HL[@HL01="3"]/NM1/DMG','.//HL[@HL01="3"]/NM1/DMG','.//HL[@HL01="3"]/NM1/REF[@REF01="SY"]','.//HL[@HL01="4"]/NM1','.//HL[@HL01="4"]/NM1','.//HL[@HL01="4"]/NM1','.//HL[@HL01="4"]/NM1/N3','.//HL[@HL01="4"]/NM1/N4','.//HL[@HL01="4"]/NM1/N4','.//HL[@HL01="4"]/NM1/N4','.//HL[@HL01="4"]/NM1/DMG','.//HL[@HL01="4"]/NM1/DMG','.//HL[@HL01="4"]/NM1/REF[@REF01="SY"]']
        get_attrib_PR = ['ST01','REF02','REF02','NM109','NM109','NM103','NM104','NM105','N301','N401','N402','N403','DMG02','DMG03','REF02','NM103','NM104','NM105','N301','N401','N402','N403','DMG02','DMG03','REF02']

        for i in range(len(get_attrib_PR)):
            tmp = PR.find(find_PR[i])
            if tmp != None and get_attrib_PR[i] in tmp.keys():
                output_dict[col_PR[i]] = tmp.attrib[get_attrib_PR[i]]
            else:
                output_dict[col_PR[i]] = ''
        
        output_dict['TraceNumber'] = TraceNumber
        output_dict['PayerId'] = PayerId.text if PayerId != None and PayerId.text != None else ''
        output_dict['ClientId'] = ClientId.text if ClientId != None and ClientId.text != None else ''
        output_dict['ResponseResultStd'] = ResponseResultStd
        output_dict['Received'] = Received.text if Received != None and Received.text != None else ''
        output_dict['subscriberId'] = subscriberId
        output_dict['Sourcekey']='2'
        output_dict['PayerName']=''
        output_dict['VerifiedSource']='ich'
        output_dict['SubDependentflag']='0'
        output_dict['Dependentflag']='1'
        output_dict['Updatedate']=''
        output_dict['Isdeletedflag']='0'
        Xml_payer_request=re.findall('<PayerRequest>(.*)</PayerRequest>', data)
        if Xml_payer_request:
            Xml_payer_request=Xml_payer_request[0].replace('|','')
            output_dict['Xml_payer_request']=f"<PayerRequest>{Xml_payer_request}</PayerRequest>"
        else:
             output_dict['Xml_payer_request']=f"<PayerRequest></PayerRequest>"
        Xml_payer_response=re.findall('<PayerResponse>(.*)</PayerResponse>', data)
        if Xml_payer_response:
            Xml_payer_response=Xml_payer_response[0].replace('|','')
            output_dict['Xml_payer_response']=f'<PayerResponse>{Xml_payer_response}</PayerResponse>'
        else:
            output_dict['Xml_payer_response']=f'<PayerResponse></PayerResponse>'
        Xml_request_fields=re.findall('<RequestFields>(.*)</RequestFields>', data)
        if Xml_request_fields:
            Xml_request_fields=Xml_request_fields[0]
            output_dict['Xml_request_fields']=f'<RequestFields>{Xml_request_fields}</RequestFields>'
        else:
            output_dict['Xml_request_fields']=f'<RequestFields></RequestFields>'
        output_dict['bcdate'] = bcdate
        output_dict['CurrentDate']=str(date.today())
        output_dict['sourcepatientacctifk']=""
        output_dict['hcsystemfk']=""


        subscriber_cols=['TraceNumber','Sourcekey','PayerId','ClientId','ResponseResultStd','VerifiedSource','subscriberGroupNumber','subscriberCoverageId','sourcepatientacctifk','hcsystemfk','subscriberFirstName','subscriberMiddleName','subscriberLastName','subscriberGender','subscriberDOB','subscriberSSN','subscriberAddress','subscriberCity','subscriberState','subscriberZip','SubDependentflag','Received','Updatedate','Isdeletedflag','CurrentDate','bcdate','Xml_payer_request','Xml_payer_response','Xml_request_fields']

        dependent_cols=['TraceNumber','Sourcekey','PayerId','ClientId','ResponseResultStd','VerifiedSource','subscriberGroupNumber','subscriberCoverageId','sourcepatientacctifk','hcsystemfk','dependentFirstName','dependentMiddleName','dependentLastName','dependentGender','dependentDOB','dependentSSN','dependentAddress','dependentCity','dependentState','dependentZip','Dependentflag','Received','Updatedate','Isdeletedflag','CurrentDate','bcdate','Xml_payer_request','Xml_payer_response','Xml_request_fields']

        replaceCols = ['subscriberCoverageId','subscriberId','subscriberLastName','subscriberAddress','subscriberMiddleName','']

        if len(output_dict['dependentGroupNumber']) > 0 and output_dict['dependentGroupNumber'] and output_dict['dependentGroupNumber'].lower() != 'none':
            tmp = output_dict['dependentGroupNumber']
        elif len(output_dict['subscriberGroupNumber']) > 0 and output_dict['subscriberGroupNumber'] and output_dict['subscriberGroupNumber'].lower() != 'none':
            tmp = output_dict['subscriberGroupNumber']
        else:
            tmp ="  "
        output_dict["subscriberGroupNumber"] = tmp 

        if len(output_dict['dependentCoverageId']) > 0 and output_dict['dependentCoverageId'] and output_dict['dependentCoverageId'].lower() != 'none':
            tmp = output_dict['dependentCoverageId']
        elif len(output_dict["subscriberCoverageId"]) > 0 and output_dict['subscriberCoverageId'] and output_dict['subscriberCoverageId'].lower() != 'none':
            tmp = output_dict["subscriberCoverageId"]
        else:
            tmp = subscriberId
        output_dict["subscriberCoverageId"] = tmp 

        print(f"tmp ===> {tmp}")

        if output_dict["subscriberCoverageId"] and output_dict["subscriberCoverageId"].strip() != "" and output_dict["subscriberCoverageId"].lower() != "none":
                   
            resp1=[]
            for col in subscriber_cols:
                if col in replaceCols:
                    output_dict[col] = output_dict[col].replace('|','')
                    # output_dict[col] = output_dict[col]

                resp1.append(output_dict[col])

            resp2=[]
            for col in dependent_cols:
                resp2.append(output_dict[col])
            return ['|'.join(resp1),'|'.join(resp2)]
        else:
            return [""]
        
    else:
        return [""]
        

parse_xml_udf = udf(parse_xml, ArrayType(StringType()))

# COMMAND ----------

df = spark.read.text(ie_input_dir)
# print(f"input file count {df.count()}")
df = df.select(split("value",",",2).getItem(1).alias('value'))
df = df.withColumn("value", explode(parse_xml_udf(df['value'],lit(bcdate))))
# print(f"input1 file count {df.count()}")
df = df.filter(length(col("value")) > lit(0))
# print(f"input2 file count {df.count()}")
# display(df)
df.write.mode('overwrite').text(ie_output_dir)

# COMMAND ----------

# from pyspark.sql.types import *
# parsed_schema = StructType([
#     StructField("TraceNumber",StringType()),
#     StructField("Sourcekey",StringType()),
#     StructField("PayerId",StringType()),
#     StructField("ClientId",StringType()),
#     StructField("ResponseResultStd",StringType()),
#     StructField("VerifiedSource",StringType()),
#     StructField("subscriberGroupNumber",StringType()),
#     StructField("subscriberCoverageId",StringType()),
#     StructField("sourcepatientacctifk",StringType()),
# 	StructField("hcsystemfk",StringType()),
# 	StructField("subscriberFirstName",StringType()),
#     StructField("subscriberMiddleName",StringType()),
#     StructField("subscriberLastName",StringType()),
#     StructField("subscriberGender",StringType()),
#     StructField("subscriberDOB",StringType()),
#     StructField("subscriberSSN",StringType()),
#     StructField("subscriberAddress",StringType()),
#     StructField("subscriberCity",StringType()),
#     StructField("subscriberState",StringType()),
#     StructField("subscriberZip",StringType()),
#     StructField("Dependentflag",StringType()),
# 	StructField("Received",StringType()),
#     StructField("Updatedate",StringType()),
#     StructField("Isdeletedflag",StringType()),
#     StructField("CurrentDate",StringType()),
#     StructField("bcdate",StringType()),
#     StructField("Xml_payer_request",StringType()),
#     StructField("Xml_payer_response",StringType()),
#     StructField("Xml_request_fields",StringType())
# ])
