# Databricks notebook source
##  Created By: Abdul Shaik
##  Created On:10/17/2022
##  Details: This script is to
##         Get unique PermId relations from escan patientAccountsXpermId data set.

# COMMAND ----------

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("run_type","")
dbutils.widgets.getArgument("run_type")
run_type= getArgument("run_type")

dbutils.widgets.text("permIdPatientAcctIdDir","")
dbutils.widgets.getArgument("permIdPatientAcctIdDir")
permIdPatientAcctIdDir= getArgument("permIdPatientAcctIdDir")

dbutils.widgets.text("permIdRelationsDir","")
dbutils.widgets.getArgument("permIdRelationsDir")
permIdRelationsDir= getArgument("permIdRelationsDir")

dbutils.widgets.text("permIdRelationsStageDir","")
dbutils.widgets.getArgument("permIdRelationsStageDir")
permIdRelationsStageDir= getArgument("permIdRelationsStageDir")


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

import sys
import datetime
import subprocess
import os
import pyspark
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from delta.tables import *

# COMMAND ----------

bcdate=bc
permIdPatientAcctIdDir=baseurl+permIdPatientAcctIdDir
permIdRelationsDir=baseurl+permIdRelationsDir
permIdRelationsStageDir=baseurl+permIdRelationsStageDir+bc
print("bcdate:",bcdate)
print("permIdPatientAcctIdDir:",permIdPatientAcctIdDir)
print("permIdRelationsDir:",permIdRelationsDir)
print("permIdRelationsStageDir:",permIdRelationsStageDir)

# COMMAND ----------

def get_unique_permId_relations(spark,  permIdPatientAcctIdDir):
    print("DEBUG: Read permIds from " + str(permIdPatientAcctIdDir) + "\n")
    r_cols = ["permid","matchind","magnetpermid"]
    pxpac = readparquet(spark, permIdPatientAcctIdDir, '1', r_cols).dropDuplicates()
    pxpac_hm1 = pxpac.filter(col("matchind") == "HM").drop("matchind")

    print("DEBUG: Create reverse permIds relations \n")
    pxpac_hm2 = pxpac_hm1.select(col("magnetpermid").alias("permid"),col("permid").alias("magnetpermid"))
    pxpac_hm = pxpac_hm1.union(pxpac_hm2).dropDuplicates()

    print("DEBUG: Add create_date and update_date for tracking")
    pxpac_hm = pxpac_hm.withColumn("createdate", current_date())
    pxpac_hm = pxpac_hm.withColumn("updatedate", current_date())
    return pxpac_hm

# COMMAND ----------

if run_type == 'base':
    print("BASE")
    permIdPatientAcctIdDir = permIdPatientAcctIdDir + "/*"
    pxpac_hm = get_unique_permId_relations(spark,  permIdPatientAcctIdDir)
    print("DEBUG: Write unique permId relations to delta table" + str(permIdRelationsDir) + "\n")
    pxpac_hm.write.format("delta").mode("overwrite").save(permIdRelationsDir)
else:
    print("NON_BASE")
    permIdPatientAcctIdDir = permIdPatientAcctIdDir + bcdate
    pxpac_hm = get_unique_permId_relations(spark,  permIdPatientAcctIdDir)
    print("DEBUG: Write new relations to staging path")
    writeparquet(spark, pxpac_hm, permIdRelationsStageDir, 1, "overwrite")
    print("DEBUG: reconcile unique permId relations to delta table" + str(permIdRelationsDir) + "\n")
    key = "permid;magnetpermid"
    pJoinExpression = ""
    for column in key.split(";"):
        print(column)
        pJoinExpression = pJoinExpression + "raw." + column + "=delta." + column + " AND "
    pJoinExpression = pJoinExpression.strip(" AND")
    print(pJoinExpression)
    pxpac_raw = DeltaTable.forPath(spark, permIdRelationsDir)
    pxpac_raw.alias("raw").merge(pxpac_hm.alias("delta"), pJoinExpression) \
                        .whenMatchedUpdate(set =
                            {
                            "permid": "delta.permid",
                            "magnetpermid": "delta.magnetpermid",
                            "updatedate": "delta.updatedate",
                            }
                        ) \
                        .whenNotMatchedInsertAll().execute()
    print("DEBUG: reconcile unique permId relations to delta table :DONE")
    
    block_size = str(1024 * 1024 * 1024)
    spark.conf.set("spark.sql.files.maxPartitionBytes", block_size)
    print("DEBUG: Rewrite delta table for small files issue/performance")
    df_raw = DeltaTable.forPath(spark, permIdRelationsDir).toDF()
    df_raw.write.option("dataChange", "false").format("delta").mode("overwrite").save(permIdRelationsDir)
    df_raw.unpersist()