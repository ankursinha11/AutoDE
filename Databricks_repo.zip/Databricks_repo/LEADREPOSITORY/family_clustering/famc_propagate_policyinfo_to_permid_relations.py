# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("run_type","")
dbutils.widgets.getArgument("run_type")
run_type= getArgument("run_type")

dbutils.widgets.text("feed_source","")
dbutils.widgets.getArgument("feed_source")
feed_source= getArgument("feed_source")

dbutils.widgets.text("permIdRelationsStageDir","")
dbutils.widgets.getArgument("permIdRelationsStageDir")
permIdRelationsStageDir= getArgument("permIdRelationsStageDir")

dbutils.widgets.text("permIdRelationsDir","")
dbutils.widgets.getArgument("permIdRelationsDir")
permIdRelationsDir= getArgument("permIdRelationsDir")

dbutils.widgets.text("lr_xref_permid_transaction_dir","")
dbutils.widgets.getArgument("lr_xref_permid_transaction_dir")
lr_xref_permid_transaction_dir= getArgument("lr_xref_permid_transaction_dir")

dbutils.widgets.text("famc_lr_xref_permid_transaction_dir","")
dbutils.widgets.getArgument("famc_lr_xref_permid_transaction_dir")
famc_lr_xref_permid_transaction_dir= getArgument("famc_lr_xref_permid_transaction_dir")

dbutils.widgets.text("candidate_permid_transactions_dir","")
dbutils.widgets.getArgument("candidate_permid_transactions_dir")
candidate_permid_transactions_dir= getArgument("candidate_permid_transactions_dir")

dbutils.widgets.text("op_partitions","")
dbutils.widgets.getArgument("op_partitions")
op_partitions= getArgument("op_partitions")


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 
    

# COMMAND ----------

##  Created By: Abdul Shaik
##  Created On: 12/05/2022
##  Details: This script is to share policyinfo among permid relations.
##          -Get permid relations
##          -Get lr_xref_permid_transaction data for ich and fc coverage transactions
##          -Join and propagate transaction key to candidate permids
##          -Remove existing permid transactions in lr_xref_permid_transaction
##          -write to stage path

##  famc_permid_feed(es_xref_famc) = delta escan permid relations joined with all transactions
##  famc_ich_leads_feed(ie_xref_famc) = delta ICH transactions(leadrepository ie_postbdf xref) joined with all permid relations
##  famc_fc_leads_feed(fc_xref_famc) = delta FC lr xref data joined with all permid relations
import sys
import datetime
import subprocess
import os
import pyspark
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from delta.tables import *

# COMMAND ----------

bcdate=bc
permIdRelationsDir=baseurl+permIdRelationsDir
permIdRelationsStageDir=baseurl+permIdRelationsStageDir+bc
lr_xref_permid_transaction_dir=baseurl+lr_xref_permid_transaction_dir
candidate_permid_transactions_dir=baseurl+candidate_permid_transactions_dir+ feed_source + '/'+bc
famc_lr_xref_permid_transaction_dir=baseurl+famc_lr_xref_permid_transaction_dir
print("bcdate:",bc)
print("permIdRelationsDir:",permIdRelationsDir)
print("permIdRelationsStageDir:",permIdRelationsStageDir)
print("lr_xref_permid_transaction_dir:",lr_xref_permid_transaction_dir)
print("candidate_permid_transactions_dir:",candidate_permid_transactions_dir)
print("famc_lr_xref_permid_transaction_dir:",famc_lr_xref_permid_transaction_dir)
op_partitions=int(2000)
print(op_partitions)

# COMMAND ----------

def get_unique_permId_relations(spark,  run_type, feed_source, permIdRelationsDir, permIdRelationsStageDir, apir_cols):
    print("Run type: " + str(run_type) + "\n" + "feed_source: " + str(feed_source))
    if ((run_type == 'base') or (run_type == 'delta' and feed_source != 'es_xref_famc')):
        print("DEBUG: Read all unique permId relations from " + str(permIdRelationsDir) + "\n")
        apir = extract_deltalake_data(spark, permIdRelationsDir, apir_cols)
    else:
        print("DEBUG: Read delta unique permId relations from " + str(permIdRelationsStageDir) + "\n")
        apir = readparquet(spark, permIdRelationsStageDir + "/*", '1', apir_cols)
    return apir

def get_lr_xref_permid_transaction(spark,  run_type, feed_source, lr, lr_xref_permid_transaction_dir, bcdate):
    print("Run type: " + str(run_type) + "\n" + "feed_source: " +  str(feed_source))
    if ((run_type == 'delta') and (feed_source != "es_xref_famc")):
        print("DEBUG: Read delta lr transactions from " + str(lr_xref_permid_transaction_dir) + "\n")
        if (feed_source == "ie_xref_famc"): 
            sourcekey = "2" 
        else: 
            sourcekey = "1"
        lr = lr.filter((col("lr_creatingmodule") == lit(bcdate)) & (col("sourcekey") == sourcekey))       
    return lr

# COMMAND ----------

print("DEBUG: Get unique permId relations \n")
apir_cols = ["permid","magnetpermid"]
apir = get_unique_permId_relations(spark,  run_type, feed_source, permIdRelationsDir,permIdRelationsStageDir,apir_cols)

lr_cols = ["permid","transactionkey","sourcekey","lr_creatingmodule","hospitalfk"]
print("DEBUG: Read all lr transactions from " + str(lr_xref_permid_transaction_dir) + "\n")
lr = extract_deltalake_data(spark, lr_xref_permid_transaction_dir, lr_cols)
if(run_type == 'delta'):
    print("DEBUG: union of lr xref transactions and famc lr xref transactions")
    famc_lr = extract_deltalake_data(spark, famc_lr_xref_permid_transaction_dir, lr_cols)
    lr_all=famc_lr.union(lr) 

lr = get_lr_xref_permid_transaction(spark,  run_type, feed_source, lr, lr_xref_permid_transaction_dir, bcdate)

print("DEBUG: Propagate policyInfo to relations \n") 
if((run_type == 'delta') and (feed_source == "es_xref_famc")):
    lr = lr_all
ca_lr = apir.alias("p").join(lr.alias("l"), col("p.magnetpermid") == col("l.permid")).select("p.permid","transactionkey","sourcekey","hospitalfk").dropDuplicates()

print("DEBUG: Filter out existing transactions with same permId in lr_xref_permid_transaction \n") 
if(run_type == 'base'):
    lr_all = lr
ca = ca_lr.alias("c").join(lr_all.alias("l"), ["permid","transactionkey","hospitalfk"], 'leftanti').select(ca_lr["*"])

print("DEBUG: Write permId relations transactionInfo to " + str(candidate_permid_transactions_dir) + "\n")
writeparquet(spark, ca, candidate_permid_transactions_dir, op_partitions, "overwrite")
