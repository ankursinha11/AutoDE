# Databricks notebook source
##  Created By: Abdul Shaik
##  Created On: 12/09/2022
##  Details: This script is to prep family clustering data for LSB; load data to lr xref permid dataset.
##          -Read family clustering permid transaction data
##          -Transform data required for LR
##          -write to stage path and toserve path

##  Runs for permid feed, ich_leads feed and fc_leads feed 

# COMMAND ----------

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bcdate","")
dbutils.widgets.getArgument("bcdate")
bcdate= getArgument("bcdate")

dbutils.widgets.text("feed_source","")
dbutils.widgets.getArgument("feed_source")
feed_source= getArgument("feed_source")

dbutils.widgets.text("run_type","")
dbutils.widgets.getArgument("run_type")
run_type= getArgument("run_type")

dbutils.widgets.text("candidate_permid_transactions","")
dbutils.widgets.getArgument("candidate_permid_transactions")
candidate_permid_transactions= getArgument("candidate_permid_transactions")

dbutils.widgets.text("lr_xref_permid_transaction_stage","")
dbutils.widgets.getArgument("lr_xref_permid_transaction_stage")
lr_xref_permid_transaction_stage= getArgument("lr_xref_permid_transaction_stage")

dbutils.widgets.text("lr_xref_permid_transaction_toserve","")
dbutils.widgets.getArgument("lr_xref_permid_transaction_toserve")
lr_xref_permid_transaction_toserve= getArgument("lr_xref_permid_transaction_toserve")

dbutils.widgets.text("op_path","")
dbutils.widgets.getArgument("op_path")
op_path= getArgument("op_path")




# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------


if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

candidate_permid_transactions = baseurl+candidate_permid_transactions+feed_source+'/'+bcdate
# lr_xref_permid_transaction_stage = baseurl+lr_xref_permid_transaction_stage+bcdate
# lr_xref_permid_transaction_toserve = baseurl+lr_xref_permid_transaction_toserve+bcdate
lr_xref_permid_transaction_stage = baseurl+lr_xref_permid_transaction_stage+'famc_lr_xref_permid_transaction/'+feed_source+'/'+bcdate
lr_xref_permid_transaction_toserve = baseurl+lr_xref_permid_transaction_toserve+'famc_lr_xref_permid_transaction/'+feed_source+'/'+bcdate
op_path = baseurl+op_path
 
print("candidate_permid_transactions: ",candidate_permid_transactions)
print("lr_xref_permid_transaction_stage: ",lr_xref_permid_transaction_stage)
print("lr_xref_permid_transaction_toserve: ",lr_xref_permid_transaction_toserve)
print("op_path:",op_path)

# COMMAND ----------

import sys
import datetime
import subprocess
import os
import pyspark
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf


def transform_data(df, bcdate, current_dt):
    df = df.withColumn("lr_creatingmodule", lit(bcdate))
    df = df.withColumn("lr_createdate", lit(current_dt))
    df = df.withColumn("_id", concat_ws("-", df.permid, df.transactionkey, df.hospitalfk, df.sourcekey))
    df = df.withColumn("xrefsource", lit("fm"))
    df = df.withColumn("audittrail", concat_ws("~", df.permid, df.lr_creatingmodule))
    df = df.select("transactionkey" \
                   , "sourcekey" \
                   , "permid" \
                   , "lr_createdate" \
                   , "lr_creatingmodule", "_id", "xrefsource", "audittrail", "hospitalfk")
    return df



current_dt = datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    
print("DEBUG: Get candidate permId transactions from " + candidate_permid_transactions + "\n")
ca = readparquet(spark, candidate_permid_transactions, '0', "")

print("DEBUG: Transform famc permId transactions data to lrxref" + "\n")
ca = transform_data(ca, bcdate, current_dt)
   
if (run_type == "base"): 
    op_partitions = 2000
else: 
    op_partitions = 100
        
print("DEBUG: Write new permId transactions to " + str(lr_xref_permid_transaction_stage) + "\n")
writeparquet(spark, ca, lr_xref_permid_transaction_stage, op_partitions, "overwrite")

# Not using it in the next process 
# print("DEBUG: Write to serve path " + str(lr_xref_permid_transaction_toserve) + "\n") 
# ca = ca.select(ca.transactionkey, ca.sourcekey)
# writeparquet(spark, ca, lr_xref_permid_transaction_toserve, op_partitions, "overwrite")



# COMMAND ----------

if run_type == 'base':
    ca.write.format("delta").mode("overwrite").save(op_path + "famc_lr_xref_permid_transaction")
else:
    #In previous steps comparing against famc_lr_xref_permid_transaction
    ca.write.format("delta").mode("append").save(op_path + "famc_lr_xref_permid_transaction") 
    print("update done")
