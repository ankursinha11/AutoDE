# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("hdfs_path","")
dbutils.widgets.getArgument("hdfs_path")
hdfs_path= getArgument("hdfs_path")

# dbutils.widgets.text("hdfs_leadrepo_raw","")
# dbutils.widgets.getArgument("hdfs_leadrepo_raw")
# hdfs_leadrepo_raw= getArgument("hdfs_leadrepo_raw")

dbutils.widgets.text("hdfs_leadrepo_cooked","")
dbutils.widgets.getArgument("hdfs_leadrepo_cooked")
hdfs_leadrepo_cooked= getArgument("hdfs_leadrepo_cooked")

dbutils.widgets.text("hdfs_path_toserve","")
dbutils.widgets.getArgument("hdfs_path_toserve")
hdfs_path_toserve= getArgument("hdfs_path_toserve")

dbutils.widgets.text("trange","")
dbutils.widgets.getArgument("trange")
trange= getArgument("trange")

dbutils.widgets.text("fc_source_key","")
dbutils.widgets.getArgument("fc_source_key")
fc_source_key= getArgument("fc_source_key")

dbutils.widgets.text("leadrepo_dir","")
dbutils.widgets.getArgument("leadrepo_dir")
leadrepo_dir= getArgument("leadrepo_dir")

dbutils.widgets.text("num_of_days_fc","")
dbutils.widgets.getArgument("num_of_days_fc")
num_of_days_fc= getArgument("num_of_days_fc")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

hdfs_path= baseurl+ hdfs_path
hdfs_leadrepo_cooked= baseurl+leadrepo_dir + hdfs_leadrepo_cooked
# hdfs_leadrepo_raw=baseurl+hdfs_leadrepo_raw
hdfs_path_toserve= baseurl+leadrepo_dir+hdfs_path_toserve+"/"+bc

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/schema_util

# COMMAND ----------

lr_transactiondemo_dbfs = "/dbfs/FileStore/lead_repository/fc_import/schema/lr_transactiondemo.schema"
#lr_transactiondemo_adls = "abfss://npp@divyaprodstorageact1.dfs.core.windows.net//sourcecode/leadrepository/workflows/escan_import_fc/schema/lr_transactiondemo.schema"
lr_transactiondemo_adls = baseurl+'/data/leadrepo/config/lr_transactiondemo.schema'
fc_enddt = date_sub(current_date(), int(num_of_days_fc))

# COMMAND ----------

try:
    if(dbutils.fs.ls(lr_transactiondemo_dbfs)):
        #dbutils.fs.rm(lr_transactiondemo_dbfs, True)
        print("Schema file already exist")
except:
    print("Schema file doesn't exist")
    dbutils.fs.cp(lr_transactiondemo_adls, lr_transactiondemo_dbfs)

#dbutils.fs.cp(lr_transactiondemo_adls, lr_transactiondemo_dbfs)
transactionschema = createSchemaLine(lr_transactiondemo_dbfs)

# COMMAND ----------

spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)

fc_cols=["foundcoverageipk", "edipartnerfk", "hitstatus","currentinferredsourcemethodcode","firstname", "middlename",\
          "lastname", "gender", "addr", "dob", "ssn", "city", "state", "zip", "createdate","updatedate",\
         "hospitalfk","coverageid","patientacctifk","hospitalfk","groupnumber"]
cooked_cols=["transactionkey","sourcekey","payerid","clientid","responsestatus",\
             "verifiedsource","groupnumber","coverageid","sourcepatientacctifk","hcsystemfk","firstname", "middlename", "lastname",\
             "gender", "dob", "ssn","addr", "city", "state", "zip","dependentflag","createdate","updatedate","isdeletedflag",\
             "lr_createdate","lr_creatingmodule","transactionrange"]

partner_cols=["edipartnerpk","partnername"]
hosp_cols=["hospitalpk","hcsystemfk"]

# COMMAND ----------

def extract_delta_data( hdfs_path,cols = None):
    """Load data from Parquet file format.
    :param spark: Spark session object.
    :return: Spark DataFrame.
    """
    if cols == '' or cols is None:
       df=spark.read.format('delta').load(hdfs_path)
    else:
       df=spark.read.format('delta').load(hdfs_path).select(cols)
    return df

def extract_parquet_data( hdfs_path,cols = None):
    """Load data from Parquet file format.
    :param spark: Spark session object.
    :return: Spark DataFrame.
    """
    if cols == '' or cols is None:
       df=spark.read.format('parquet').load(hdfs_path)
    else:
       df=spark.read.format('parquet').load(hdfs_path).select(cols)
    return df

def extract_parquet_cookeddata(hdfs_path,cols,cooked_schema):
    try:
        dfcooked = spark.read.format('parquet').load(hdfs_path)
    except: 
        dfcooked = spark.createDataFrame([],cooked_schema)
    return dfcooked  

def transform_coverageid(dffinal):
    dffinal = dffinal.withColumn("coverageid",when((dffinal.coverageid.contains(dffinal.groupnumber))& (dffinal.groupnumber != '') \
                      ,substring_index(dffinal.coverageid,'-',1)).otherwise(dffinal.coverageid))
    return dffinal


def convert_set(input_set):
    s = list(input_set)
    str1 = '|'.join(str(e) for e in s)
    return str1

def transform_final(dffinal,dfediqueries,dfediqueryhitsmisses,sourcekey,trange,bc,cooked_cols):
    
    convertSet_udf = udf(convert_set, StringType())
    dffinal = dffinal.withColumn('sourcekey',lit(sourcekey))
    dffinal.createOrReplaceTempView("FC")

    #JIRA IDPRO-14892 10/16/2025
    dfediqueryhitsmisses = dfediqueryhitsmisses.where( dfediqueryhitsmisses.result.rlike('EB:([1-6])'))
    dfediqueryhitsmisses.createOrReplaceTempView("hitstatus")
    dfediqueries.createOrReplaceTempView("ediqueries")

    spark.sql("REFRESH TABLE hitstatus")
    spark.sql("REFRESH TABLE ediqueries")

    sql = """select foundcoverageipk as transactionkey
                        ,f.sourcekey
                        ,f.edipartnerfk as payerid
                        ,f.hospitalfk as clientid
                        ,m.result as responsestatus
                        ,f.currentinferredsourcemethodcode as verifiedsource
                        ,f.groupnumber
                        ,f.coverageid
                        ,f.patientacctifk as sourcepatientacctifk
                        ,f.hcsystemfk             
                        ,f.firstname              
                        ,f.middlename             
                        ,f.lastname               
                        ,f.gender                 
                        ,f.dob                    
                        ,f.ssn
                        ,f.addr                    
                        ,f.city                   
                        ,f.state                  
                        ,f.zip  
                        ,0 as dependentflag                  
                        ,f.createdate
                        ,f.updatedate
                        ,0 as isdeletedflag
                from FC f
                join ediqueries q on f.hospitalfk=q.hospitalfk and f.edipartnerfk=q.edipartnerfk and f.patientacctifk=q.patientacctifk
                join hitstatus m on q.ediquerypk=m.ediqueryfk and f.coverageid=m.policyid 
                order by foundcoverageipk, m.result"""
          

    fc_delta = spark.sql(sql)
    fc_delta = fc_delta.dropDuplicates()

    #temporary fix put in for merge of all BCBS baby partners to mamma BCBS partner 101
    lsttBCBSPartners=[66,93,94,95,121,122,124,125,135,142,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,182,184,185,186,187,188,189,190,191,192,193,194,195,196,197,198,408]
    cond= when(col("payerid").isin(lsttBCBSPartners),lit(101)).otherwise(col("payerid"))
    fc_delta = fc_delta.withColumn("payerid",cond)
    #temporary fix ends
    
    # Filter out EB6 responses for BCBS payers
    fc_delta = fc_delta.filter(~((col("payerid") == '101') & (fc_delta.responsestatus.like('%EB:6%'))))

    # Add responsestatus as collection
    fc_delta =fc_delta.groupBy("transactionkey","sourcekey","payerid","clientid","verifiedsource","groupnumber","coverageid","sourcepatientacctifk"\
                             ,"hcsystemfk","firstname","middlename","lastname","gender","dob","ssn","city","state","zip","dependentflag","createdate",\
                              "updatedate","isdeletedflag","addr")\
                     .agg(collect_set("responsestatus").alias("responsestatus"))
    fc_delta  = fc_delta.withColumn("responsestatus",convertSet_udf(fc_delta.responsestatus))      
    fc_delta = fc_delta.withColumn('lr_createdate',current_date().cast('string'))
    fc_delta = fc_delta.withColumn('lr_creatingmodule',lit(bc))
    fc_delta = fc_delta.select([col(c).cast("string") for c in fc_delta.columns])
    fc_delta = fc_delta.withColumn("transactionrange",((fc_delta.transactionkey).cast("bigint") % trange).cast("bigint"))
    fc_delta = fc_delta.select(cooked_cols)
    return fc_delta
  
def transform_delta(edipartner,dfdelta,dfcooked,hospitals,trange,sourcekey):

    dfdelta = dfdelta.filter(\
             ((dfdelta.firstname.isNotNull()) & (trim(dfdelta.firstname) != '')) | ((dfdelta.middlename.isNotNull()) & (trim(dfdelta.middlename)!='')) |\
             ((dfdelta.lastname.isNotNull())  & (trim(dfdelta.lastname) != ''))  | ((dfdelta.addr.isNotNull()) & (trim(dfdelta.addr) != '')) | \
             ((dfdelta.dob.isNotNull())  & (trim(dfdelta.dob) != ''))            | ((dfdelta.ssn.isNotNull()) & (trim(dfdelta.ssn) != ''))   | \
             ((dfdelta.city.isNotNull()) & (trim(dfdelta.city) != ''))           | ((dfdelta.state.isNotNull()) & (trim(dfdelta.state) != ''))|\
             ((dfdelta.zip.isNotNull()) & (trim(dfdelta.zip) != '')) )
    # dfdelta = dfdelta.filter(dfdelta.hitstatus.isin(1,2)) #Updated on 11/25/2024 for picking hitstatus 1,2 records
 
    dfinsert = dfdelta.join(hospitals,(dfdelta.hospitalfk==hospitals.hospitalpk))\
        .select(dfdelta.foundcoverageipk, dfdelta.edipartnerfk,dfdelta.currentinferredsourcemethodcode,dfdelta.groupnumber,\
        dfdelta.firstname, dfdelta.middlename,dfdelta.lastname,dfdelta.gender,dfdelta.addr,dfdelta.dob,dfdelta.ssn,dfdelta.city,\
        dfdelta.state,dfdelta.zip,dfdelta.createdate,dfdelta.updatedate,dfdelta.hospitalfk,hospitals.hcsystemfk,dfdelta.coverageid,\
        dfdelta.hospitalfk,dfdelta.patientacctifk)
    
    dffinal = dfinsert           
    dffinal = dffinal.join(edipartner, edipartner.edipartnerpk==dffinal.edipartnerfk).select(dffinal.foundcoverageipk, dffinal.edipartnerfk,\
                          edipartner.partnername,dffinal.currentinferredsourcemethodcode,dffinal.groupnumber,dffinal.firstname,dffinal.middlename,\
                          dffinal.lastname,dffinal.gender,dffinal.addr,dffinal.dob,dffinal.ssn,dffinal.city,dffinal.state,dffinal.zip,\
                          dffinal.createdate,dffinal.updatedate,dffinal.hospitalfk,dffinal.hcsystemfk,dffinal.coverageid,\
                          dffinal.hospitalfk,dffinal.hcsystemfk,dffinal.patientacctifk)
    return dffinal

def write_cooked(df,hdfs_leadrepo_cooked,hdfs_path_toserve):
    print("hdfs_leadrepo_cooked "+ hdfs_leadrepo_cooked)
    print("hdfs_path_toserve "+ hdfs_path_toserve)
    df=df.dropDuplicates()
    df.repartition(25).write.partitionBy("transactionrange").mode("append").parquet(hdfs_leadrepo_cooked) 
    df = df.filter(df.isdeletedflag == 0).select(df.transactionkey,df.clientid.alias("hospitalfk"),df.sourcepatientacctifk.alias("patientacctifk"),df.payerid,df.coverageid,df.lr_creatingmodule.alias("bc"))
    df.dropDuplicates().repartition(10).write.mode("append").parquet(hdfs_path_toserve)
    return None


# COMMAND ----------

fcismc_path = (hdfs_path+"/foundcoverageinferredsourcemethodcodes/current/20991231")
fcismc = extract_parquet_data(fcismc_path)
# Disabled on 10/17/2024 to address low volume issues
# fcismc = fcismc.withColumn("edisourcedflag",fcismc.edisourcedflag.cast(IntegerType())) 
# fcismc = fcismc.filter(fcismc.edisourcedflag==1)
fcismc= fcismc.filter("inferredflag=0") #Added this filter on 12/09/2024 to get the real verified records

# COMMAND ----------

# dfdelta = extract_parquet_data(hdfs_leadrepo_raw+'/'+ bc,fc_cols)
dfdelta = extract_delta_data(hdfs_path + "/foundcoverage/current/20991231/").select(fc_cols)
dfdelta = dfdelta.filter((dfdelta.updatedate >= fc_enddt) & (dfdelta.hitstatus.isin("1", "2")))
dfdelta = dfdelta.join(fcismc, fcismc.inferredsourcemethodcode == dfdelta.currentinferredsourcemethodcode).select(dfdelta["*"])

# COMMAND ----------

dfediqueries = extract_delta_data(hdfs_path +"/ediqueries/current/20991231/")
dfediqueryhitsmisses = extract_delta_data(hdfs_path+ "/ediqueryhitsandmisses/current/20991231/")
edipartner = extract_parquet_data( hdfs_path+"/edipartners/current/20991231/",partner_cols)
hospitals = extract_parquet_data(hdfs_path+"/hospitals/current/20991231/",hosp_cols)

dfcooked = extract_parquet_cookeddata(hdfs_leadrepo_cooked,cooked_cols,transactionschema)     

dfc = transform_delta(edipartner,dfdelta,dfcooked,hospitals,trange,fc_source_key)
dffinal = transform_coverageid(dfc)
cooked = transform_final(dffinal,dfediqueries,dfediqueryhitsmisses,fc_source_key,trange,bc,cooked_cols)

df_orig = extract_parquet_data(hdfs_leadrepo_cooked)
df_newcooked = cooked.subtract(df_orig)

# COMMAND ----------

write_cooked(df_newcooked, hdfs_leadrepo_cooked, hdfs_path_toserve)
