# Databricks notebook source
import os
import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
from pyspark import SparkContext
from pyspark.conf import SparkConf
from delta.tables import *

# COMMAND ----------

# 20230705T14
# abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/apundir/data/leadrepo/scratch/lr_xref_gmrnid_transaction/
# abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/apundir/data/leadrepo/toserve/gmrn/
# abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/apundir/data/leadrepo/scratch/lr_xref_gmrn_update/

# COMMAND ----------

# # SET parameters#
# dbutils.widgets.text("bc" , "20230920T21")
# bc= dbutils.widgets.get("bc")

# dbutils.widgets.text("gmrn_path_input" , "abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/apundir/data/CDD/output/globalmrn/mergedecisions/merge/")
# gmrn_path_input= dbutils.widgets.get("gmrn_path_input")

# dbutils.widgets.text("gmrn_xref_input" , "abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/apundir/data/leadrepo/scratch/lr_xref_gmrnid_transaction/")
# gmrn_xref_input= dbutils.widgets.get("gmrn_xref_input")

# dbutils.widgets.text("path_toserve" , "abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/apundir/data/leadrepo/toserve/gmrn/")
# path_toserve= dbutils.widgets.get("path_toserve")

# dbutils.widgets.text("gmrn_tmp_path" , "abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/apundir/data/leadrepo/scratch/lr_xref_gmrn_update/")
# gmrn_tmp_path= dbutils.widgets.get("gmrn_tmp_path")

# COMMAND ----------

# SET parameters#
dbutils.widgets.text("bc" , "")
bc= dbutils.widgets.get("bc")

dbutils.widgets.text("gmrn_path_input" , "")
gmrn_path_input= dbutils.widgets.get("gmrn_path_input")

dbutils.widgets.text("gmrn_xref_input" , "")
gmrn_xref_input= dbutils.widgets.get("gmrn_xref_input")

dbutils.widgets.text("path_toserve" , "")
path_toserve= dbutils.widgets.get("path_toserve")

dbutils.widgets.text("gmrn_tmp_path" , "")
gmrn_tmp_path= dbutils.widgets.get("gmrn_tmp_path")

dbutils.widgets.text('storageaccount','')
storageaccount = dbutils.widgets.get('storageaccount')

dbutils.widgets.text('loadtype','')
loadtype = dbutils.widgets.get('loadtype')

# COMMAND ----------

#mount the storage account#
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

gmrn_xref_input=gmrn_xref_input
gmrn_path_input=gmrn_path_input
path_toserve=path_toserve+bc+'/'
gmrn_tmp_path=gmrn_tmp_path

# COMMAND ----------

print(bc)
print(gmrn_xref_input)
print(gmrn_path_input)
print(path_toserve)
print(gmrn_tmp_path)

# COMMAND ----------

#define schema
schema = StructType([
    StructField("new_gmrnid", StringType()),
    StructField("prev_gmrnid", StringType()),
    StructField("matchtype",  IntegerType())
  ])

# COMMAND ----------

#reading the data from maprdb for getting gmrnid  :return: Spark DataFrame.

def extract_maprdb_data(spark, gmrn_xref_input):
    df = spark.read.format('delta').load(gmrn_xref_input)
    #df = spark.read.parquet(gmrn_xref_input +'/*')
    return df

# COMMAND ----------

    # reading the data for getting merged gmrnid:return: Spark DataFrame.
def extract_csv_data(spark, gmrn_path_input, schema):
        raw_data = spark.read.format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", mode="FAILFAST", quote="",delimiter="|").schema(schema).load(gmrn_path_input).dropDuplicates()
        return raw_data

# COMMAND ----------

    # This code is for getting the latest gmrnid from merge and create a audit trail:return:  Spark DataFrame
def transform_data(df1, df2, bc,path_toserve, table):
        join_key = [df1.gmrnid == df2.prev_gmrnid]
        df = df1.join(df2, join_key, 'inner') \
            .select(df1["*"], df2.new_gmrnid, concat_ws("~", df2.new_gmrnid, lit(bc)).alias("new_gmrnid_audittrail"))


        df_format_stage1 = df.withColumn("audittrail", concat_ws("-->", df.audittrail, df.new_gmrnid_audittrail))
        if(table=="chc_lr_xref_gmrnid_transaction"):
            print("Executing for: chc_lr_xref_gmrnid_transaction")
            df_format = df_format_stage1.select(df_format_stage1._id, df_format_stage1.audittrail,df_format_stage1.lr_createdate,df_format_stage1.lr_creatingmodule \
                                            ,df_format_stage1.sourcekey,df_format_stage1.transactionkey,df_format_stage1.xrefsource,\
                                            df_format_stage1.new_gmrnid.alias("gmrnid"),df_format_stage1.transactionkey_row,df_format_stage1.gmrnmatchind)
            #df_format.display()
            dfserve = df.select(df.gmrnid.alias("fromglobalmrn"), df.new_gmrnid.alias("toglobalmrn")) 
            print("Writing toserve for "+table)
            dfserve.write.mode("append").parquet(path_toserve)
        else:
            print("Executing for: "+table)
            df_format = df_format_stage1.select(df_format_stage1._id, df_format_stage1.audittrail,df_format_stage1.lr_createdate,df_format_stage1.lr_creatingmodule \
                                            ,df_format_stage1.sourcekey,df_format_stage1.transactionkey,df_format_stage1.xrefsource,\
                                            df_format_stage1.new_gmrnid.alias("gmrnid"), df_format_stage1.hospitalfk)
            #df_format.display()
            dfserve = df.select(df.gmrnid.alias("fromglobalmrn"), df.new_gmrnid.alias("toglobalmrn"))
            print("Writing toserve for:"+table) 
            dfserve.write.mode("append").parquet(path_toserve)
            

        return df_format


# COMMAND ----------

# This code to update gmrnid to the maprdb table :return none

def append_data(spark, df, hdfs_path, id_key):
    df.repartition(20).write.mode("overwrite").parquet(hdfs_path)
    return None


# COMMAND ----------

tables=["lr_xref_gmrnid_transaction","chc_lr_xref_gmrnid_transaction","mh_lr_xref_gmrnid_transaction","hfc_lr_xref_gmrnid_transaction"]

# COMMAND ----------

for table in tables:
    df_maprdb = extract_maprdb_data(spark, gmrn_xref_input+table)
    #df_maprdb.display()
    df_raw = extract_csv_data(spark, gmrn_path_input, schema)
    df_transformed = transform_data(df_maprdb, df_raw, bc,path_toserve+table, table)
    id_key = '_id'
    print("Appending df_transformed to: ", gmrn_tmp_path+table)
    append_data(spark, df_transformed, gmrn_tmp_path+table, id_key)
    df = spark.read.parquet(gmrn_tmp_path + table + '/*').dropDuplicates()
    if loadtype=="base":
        print("XREF LOAD_TYPE : "+loadtype)
        df = spark.read.parquet(gmrn_tmp_path +'/'+ table +'/*')
        df.write.format("delta").mode("overwrite").save(gmrn_xref_input+table)
    elif loadtype=="delta":
        print("XREF LOAD_TYPE : "+loadtype)
        # df_gmrn_delta.write.mode("append").format("delta").save(input_lr_xref_gmrnid_transaction)
        df_raw = DeltaTable.forPath(spark, gmrn_xref_input+table)
        df_raw.alias("raw").merge(df.alias("delta"), "raw._id=delta._id").whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()
        print("NON_BASE : RECONCILE : INSERT-UPDATE : DONE")

    else:
        print("XREF WRONG LOADTYE : "+loadtype)
        exit(1)
    print("DONE : "+table)
    print("------------------------------------------")

# COMMAND ----------


