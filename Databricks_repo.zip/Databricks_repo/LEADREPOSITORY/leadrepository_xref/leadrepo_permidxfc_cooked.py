# Databricks notebook source
#SET Parameters
dbutils.widgets.text('hdfs_path','')
hdfs_path = dbutils.widgets.get('hdfs_path')

dbutils.widgets.text('hdfs_leadrepo','')
hdfs_leadrepo = dbutils.widgets.get('hdfs_leadrepo')

dbutils.widgets.text('leadrepo_path_cooked','')
leadrepo_path_cooked = dbutils.widgets.get('leadrepo_path_cooked')

dbutils.widgets.text('permid_path','')
permid_path = dbutils.widgets.get('permid_path')

dbutils.widgets.text('bc','')
bc = dbutils.widgets.get('bc')

dbutils.widgets.text('fs_common','')
fs_common = dbutils.widgets.get('fs_common')

dbutils.widgets.text('config_temp','')
config_temp = dbutils.widgets.get('config_temp')

dbutils.widgets.text('storageaccount','')
storageaccount = dbutils.widgets.get('storageaccount')

# COMMAND ----------

# hdfs_path = "abfss://npp@divyaprodstorageact1.dfs.core.windows.net/hcedata/user/phd9appl/CDD/publish/escan/data/"
# hdfs_leadrepo = "abfss://npp@divyaprodstorageact1.dfs.core.windows.net/hceleads/user/phd9appl/leadrepo/data/raw/foundcoverage/20230419T20/*"
# leadrepo_path_cooked = "abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/apundir/data/leadrepo/scratch/"
# permid_path = "abfss://npp@divyaprodstorageact1.dfs.core.windows.net/hcedata/user/phd9appl/CDD/publish/escan/data/permidpatientacctid/20991231/"
# bc = "20230419T20"

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import datetime
from pyspark.sql.types import *

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------


def main():

    current_dt = datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    xrefsource = 'fc'
    spark = SparkSession.builder.appName("lr_xref_permid").getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    block_size = str(1024 * 1024 * 1024)
    spark.conf.set("spark.sql.files.maxPartitionBytes", block_size)

    fc_cols = ["foundcoverageipk", "hitstatus", "currentinferredsourcemethodcode", "patientacctifk", "isdeleted","hospitalfk"]
    df_raw = extract_parquet_data(spark, hdfs_leadrepo)

    # filtering out the edisourcedflag==1 records only
    fcismc_path = hdfs_path + "/foundcoverageinferredsourcemethodcodes/current/*"
    df_fcismc = extract_parquet_data(spark, fcismc_path)
    # Disabled on 10/17/2024 to address low volume issues
    # df_fcismc = df_fcismc.withColumn("edisourceflag", df_fcismc.edisourcedflag.cast(IntegerType()))
    # df_fcismc = df_fcismc.filter(df_fcismc.edisourcedflag == 1)
    #df_raw = df_raw.join(df_fcismc, trim(df_fcismc.inferredsourcemethodcode) == trim(df_raw.currentinferredsourcemethodcode)).select(df_raw['*'])
    df_fcismc= df_fcismc.filter("inferredflag=0") #Added this filter on 12/13/2024 to get the real verified records
    df_raw = df_raw.alias('df1').join(df_fcismc.alias('df2'), trim(col("df2.inferredsourcemethodcode")) == trim(col("df1.currentinferredsourcemethodcode"))).select(df_raw['*'])
    df_permid = extract_permid_parquet_data(spark, permid_path)
    dfxrefpermid = transform(spark, df_raw, df_permid, bc, current_dt, xrefsource)
    id_key = '_id'
    write_cooked(spark, dfxrefpermid, leadrepo_path_cooked, id_key)
    return None


def extract_permid_parquet_data(spark, permid_path):
    permid = spark.read.parquet(permid_path + "/*").filter(lower(col("matchind")) == 'im')
    return permid


def extract_parquet_data(spark, hdfs_path, cols=None):
    if cols == '' or cols is None:
        df = spark.read.parquet(hdfs_path)
    else:
        df = spark.read.parquet(hdfs_path).select(cols)
    return df


def extract_permid_csv_data(spark, permid_path):
    permidschema = StructType([
        StructField("permid", StringType()),
        StructField("patientacctifk", StringType()),
        StructField("matchind", StringType()),
        StructField("magnetpermid", StringType())
    ])
    permid = spark.read.format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", delimiter="|").schema(permidschema).load(permid_path).filter(lower(col("matchind")) == 'im')
    return permid


def transform(spark, df_raw, df_permid, bc, current_dt, xrefsource):
    # verifiedsource =['RE', 'IE', 'RS', 'FE', 'FI', 'CG', 'CM', 'FG', 'FJ', 'IM', 'CC', 'HG', 'OP', 'FN', 'PF', 'PP', 'UR', 'CR', 'PR', 'C3', 'F3', 'OR',\
    #                'LO', 'HM', 'LR', 'MM']
    #dfraw = df_raw.filter((df_raw.hitstatus.isin(0, 1, 2)) & (df_raw.isdeleted == 0))
    #dfraw = df_raw.filter((col("hitstatus").isin(0, 1, 2)) & (col("isdeleted") == 0))
    dfraw = df_raw.filter((col("hitstatus").isin(1, 2)) & (col("isdeleted") == 0))#Updated on 11/25/2024 for picking hitstatus 1,2 records
    #dfxref = dfraw.join(df_permid, df_permid.patientacctifk == dfraw.patientacctifk).select(df_permid.permid, dfraw.foundcoverageipk)

    dfxref = dfraw.alias('df1') \
    .join(
        df_permid.alias('df2'),
        (col("df1.patientacctifk") == col("df2.patientacctifk")) &
        (col("df1.hospitalfk") == col("df2.hospitalfk"))
    ) \
    .select(col("df2.permid"), col("df1.foundcoverageipk"), col("df1.hospitalfk"))

    dfxref = dfxref.withColumnRenamed("foundcoverageipk", "transactionkey")
    dfxref = dfxref.withColumn("lr_createdate", lit(current_dt)) \
        .withColumn("lr_creatingmodule", lit(bc)) \
        .withColumn("sourcekey", lit("1"))
    dfxref = dfxref.withColumn("_id", concat_ws("_", dfxref.permid, dfxref.transactionkey,dfxref.hospitalfk,dfxref.sourcekey))
    dfxref = dfxref.withColumn("xrefsource", lit(xrefsource))
    dfxref = dfxref.withColumn("audittrail", concat_ws("~", dfxref.permid, dfxref.lr_creatingmodule))
    dfxref = dfxref.dropDuplicates().select(dfxref.transactionkey, dfxref.sourcekey, dfxref.permid, dfxref.lr_createdate, dfxref.lr_creatingmodule, dfxref._id, dfxref.xrefsource, dfxref.audittrail, dfxref.hospitalfk)
    return dfxref


def write_cooked(spark, df, outputpath, id_key):
    df.repartition(200).write.mode("overwrite").parquet(outputpath + "/lr_xref_permid_transaction/")
    return None


if __name__ == '__main__':
    main()


# COMMAND ----------

output =  [{
    'tablename': 'lr_xref_permid_transaction'
}]
schema = StructType([StructField("tablename", StringType(), True)])
outputDf = spark.createDataFrame(output, schema)
outputDf.repartition(1).write.mode('append').format('json').save(config_temp)
