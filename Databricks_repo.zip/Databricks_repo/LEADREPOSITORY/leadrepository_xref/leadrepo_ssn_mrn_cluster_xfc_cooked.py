# Databricks notebook source
from pyspark.sql.functions import *
import datetime
from pyspark.sql.types import *
from delta.tables import * 

current_dt = datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]

# COMMAND ----------

#SET Parameters
dbutils.widgets.text('hdfs_path','')
hdfs_path = dbutils.widgets.get('hdfs_path')

dbutils.widgets.text('hdfs_leadrepo','')
hdfs_leadrepo = dbutils.widgets.get('hdfs_leadrepo')

dbutils.widgets.text('leadrepo_path_cooked','')
leadrepo_path_cooked = dbutils.widgets.get('leadrepo_path_cooked')

dbutils.widgets.text('bc','')
bc = dbutils.widgets.get('bc')

dbutils.widgets.text('fs_common','')
fs_common = dbutils.widgets.get('fs_common')

dbutils.widgets.text('config_temp','')
config_temp = dbutils.widgets.get('config_temp')

dbutils.widgets.text('config_file','')
config_file = dbutils.widgets.get('config_file')

dbutils.widgets.text('storageaccount','')
storageaccount = dbutils.widgets.get('storageaccount')

#'abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/apundir/data/leadrepo/config_temp/'
#'abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/apundir/data/leadrepo/config_file/'

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

#input
# hdfs_path = 'abfss://npp@divyaprodstorageact1.dfs.core.windows.net/hcedata/user/phd9appl/CDD/publish/escan/data'
# lr_fc_raw_path = 'abfss://npp@divyaprodstorageact1.dfs.core.windows.net/hceleads/user/phd9appl/leadrepo/data/raw/foundcoverage/20230419T20/*'
# bc = '20230419T20'
# fs_common = 'abfss://npp@divyaprodstorageact1.dfs.core.windows.net/sourcecode/leadrepository/common/
# abfss://npp@divyaprodstorageact1.dfs.core.windows.net/hceleads/user/phd9appl/leadrepo/data/raw/foundcoverage/20230419T20/*will call you in a bit
#output
# leadrepo_path_cooked = 'abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/apundir/data/leadrepo/scratch/'

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/tu_data_quality

# COMMAND ----------

xrefsource = 'fc'

# COMMAND ----------

def main():
    lr_patacc_raw_path = hdfs_path + "/patientaccts/current/20991231/"
    
    fcismc_path = hdfs_path + "/foundcoverageinferredsourcemethodcodes/current/*"
        
    df_fcismc = extract_parquet_data(fcismc_path)
    # Disabled on 10/17/2024 to address low volume issues
    # df_fcismc = df_fcismc.withColumn("edisourceflag",df_fcismc.edisourcedflag.cast(IntegerType()))
    # df_fcismc = df_fcismc.filter(df_fcismc.edisourcedflag==1)   
    df_fcismc= df_fcismc.filter("inferredflag=0") #Added this filter on 12/13/2024 to get the real verified records
    df_fc_raw = extract_parquet_data(hdfs_leadrepo).selectExpr("foundcoverageipk",
                                                                        "hitstatus",
                                                                    "hospitalfk",
                                                                        "patientacctifk",
                                                                        "currentinferredsourcemethodcode",
                                                                        "isdeleted").dropDuplicates()
    df_fc_raw = df_fc_raw.join(df_fcismc,trim(df_fcismc.inferredsourcemethodcode) == trim(df_fc_raw.currentinferredsourcemethodcode)).select(df_fc_raw['*'])

    df_patacc_raw = spark.read.format("delta").load(lr_patacc_raw_path).selectExpr("patientacctipk",
                                                                                "hospitalfk",
                                                                                "ssn",
                                                                                "clusteredacctfk",
                                                                                "medicalrecnum").dropDuplicates()

    df_xref_clust_ssn_mrn = transform(df_fc_raw, df_patacc_raw, bc, current_dt, xrefsource)
    id_key = '_id'

    #FIX START - this is a fix to refresh patientaccts parquet files so that any file name changes does not cause errors#
    df_patacc_raw.createOrReplaceTempView("patientaccts")
    #spark.sql("REFRESH TABLE patientaccts")     
    #FIX END   - this is a fix to refresh patientaccts parquet files so that any file name changes does not cause errors#

    df_xref_clust_ssn_mrn = df_xref_clust_ssn_mrn.withColumn('medicalrecnum', regexp_replace('medicalrecnum', '\\\\', '')) 
    df_xref_clust_ssn_mrn = df_xref_clust_ssn_mrn.withColumn('ssn', regexp_replace('ssn', '\\\\', '')) 
    df_xref_clust_ssn_mrn = df_xref_clust_ssn_mrn.withColumn('clusteredacctfk', regexp_replace('clusteredacctfk', '\\\\', ''))

    for column in df_xref_clust_ssn_mrn.columns: 
        df_xref_clust_ssn_mrn = df_xref_clust_ssn_mrn.withColumn(column, trim(col(column))) 
        df_xref_clust_ssn_mrn = df_xref_clust_ssn_mrn.withColumn(column, when(col(column).isNull(), '').otherwise(col(column)))

    write_cooked(df_xref_clust_ssn_mrn, leadrepo_path_cooked, id_key)
    return None

# COMMAND ----------

def check_validation(df,col):
    if col == "ssn":
       isValidSSN_udf = udf(isValidSSN, IntegerType())
       df = df.withColumn('ssn_valid',isValidSSN_udf(df.ssn))
       df = df.withColumn('ssn',when(df.ssn_valid==0,None).otherwise(df.ssn))
       df = df.drop("ssn_valid")
    if col == "medicalrecnum":
       isValidMRN_udf = udf(isValidMRN, IntegerType())
       df = df.withColumn('mrn_valid',isValidMRN_udf(df.medicalrecnum))
       df = df.withColumn('medicalrecnum',when(df.mrn_valid==0,None).otherwise(df.medicalrecnum))
       df = df.drop("mrn_valid")
    return df

# COMMAND ----------

def extract_parquet_data(hdfs_path, cols=None):
    if cols == '' or cols is None:
        df = spark.read.parquet(hdfs_path)
    else:
        df = spark.read.parquet(hdfs_path).select(cols)
    return df

# COMMAND ----------

def transform(df_fc_raw, df_patacc_raw, bc, current_dt, xrefsource):
    # df_fc_raw = df_fc_raw.filter((df_fc_raw.hitstatus.isin(0, 1, 2)) & (df_fc_raw.isdeleted == 0)).selectExpr("foundcoverageipk", "hospitalfk", "patientacctifk") #Updated on 11/25/2024 for picking hitstatus 1,2 records
    df_fc_raw = df_fc_raw.filter((df_fc_raw.hitstatus.isin(1, 2)) & (df_fc_raw.isdeleted == 0)).selectExpr("foundcoverageipk", "hospitalfk", "patientacctifk")
    
    df_patacc_raw = df_patacc_raw.withColumnRenamed("patientacctipk", "patientacctifk")

    join_keys = ["hospitalfk", "patientacctifk"]
    df_joined = df_fc_raw.join(df_patacc_raw, join_keys, 'inner').select(df_fc_raw['*'],df_patacc_raw["ssn"],df_patacc_raw["clusteredacctfk"],df_patacc_raw["medicalrecnum"]).dropDuplicates()
    
    df_joined = check_validation(df_joined,"ssn")
    df_joined = check_validation(df_joined,"medicalrecnum")
    
    df_joined = df_joined.withColumnRenamed("foundcoverageipk", "transactionkey").drop("patientacctifk")

    df_joined = df_joined.withColumn("lr_createdate", lit(current_dt)).withColumn("lr_creatingmodule", lit(bc)).withColumn("sourcekey", lit("1"))
    df_joined = df_joined.withColumn("_id", concat_ws("_", df_joined.transactionkey,df_joined.hospitalfk,df_joined.sourcekey))
    df_joined = df_joined.withColumn("xrefsource", lit(xrefsource))
    df_joined = df_joined.withColumn("audittrail", df_joined.lr_creatingmodule).dropDuplicates()
    df_joined = df_joined.select(df_joined.transactionkey,
                                 df_joined.sourcekey,
                                 df_joined.clusteredacctfk,
                                 df_joined.ssn,
                                 df_joined.hospitalfk,
                                 df_joined.medicalrecnum,
                                 df_joined.lr_createdate,
                                 df_joined.lr_creatingmodule,
                                 df_joined._id,
                                 df_joined.xrefsource,
                                 df_joined.audittrail)
    df_joined = df_joined.withColumn("hospitalfk", col("hospitalfk").cast('string'))
    df_joined = df_joined.filter((df_joined.ssn.isNotNull()) & (trim(df_joined.ssn) != '') | \
                                 (df_joined.medicalrecnum.isNotNull()) & (trim(df_joined.medicalrecnum) != '') |\
                                 (df_joined.clusteredacctfk.isNotNull()) & (trim(df_joined.clusteredacctfk) != '') )
                                 
    return df_joined

# COMMAND ----------

def write_cooked(df, outputpath, id_key):
    df.repartition(200).write.mode("overwrite").parquet(outputpath + "lr_xref_ssn_mrn_cluster_transaction/")
    return None

# COMMAND ----------

if __name__ == '__main__':
    main()

# COMMAND ----------

output =  [{
    'tablename': 'lr_xref_ssn_mrn_cluster_transaction'
}]
schema = StructType([StructField("tablename", StringType(), True)])
outputDf = spark.createDataFrame(output, schema)
outputDf.repartition(1).write.mode('append').format('json').save(config_temp)

# COMMAND ----------

config_df=spark.read.format('json').load(config_temp)
config_df.repartition(1).write.mode('overwrite').format('json').save(config_file)
