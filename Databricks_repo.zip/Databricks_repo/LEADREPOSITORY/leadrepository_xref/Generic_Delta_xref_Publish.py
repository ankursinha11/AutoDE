# Databricks notebook source
# #SET Parameter
dbutils.widgets.text('temp_op_path','')
temp_op_path = dbutils.widgets.get('temp_op_path')

dbutils.widgets.text('op_path','')
op_path = dbutils.widgets.get('op_path')

dbutils.widgets.text('tablename','' )
tablename = dbutils.widgets.get('tablename')

dbutils.widgets.text('load_type','')
load_type = dbutils.widgets.get('load_type')

dbutils.widgets.text('storageaccount','')
storageaccount = dbutils.widgets.get('storageaccount')

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
import datetime
from pyspark.sql.readwriter import *
from delta.tables import *

# COMMAND ----------

# # TEMP VARIABLE INIT
# from pyspark.sql.functions import *
# import datetime
# from pyspark.sql.types import *
# from  pyspark.sql.functions import input_file_name
# from pyspark.sql.window import Window
# from pyspark import StorageLevel
# from delta.tables import * 

# storageaccount="prodicddls"
# cosmosMasterKey = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-cosmos-insleads-kvsecret")
# cosmosContainerName="runstatus"
# cosmosDatabaseName="insleads"
# cosmosEndpoint="https://prod-icd-cosmos.documents.azure.com:443/"
# print("cosmosEndpoint :" + str(cosmosEndpoint))
# print("cosmosMasterKey :" + str(cosmosMasterKey))
# print("cosmosDatabaseName :" + str(cosmosDatabaseName))
# print("cosmosContainerName :" + str(cosmosContainerName))

# load_type="delta"
# op_path="abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/leadrepo/publish/cooked/"
# storageaccount="prodicddls"
# tablename="lr_xref_gmrnid_transaction"
# temp_op_path="abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/leadrepo/staging/scratch/lr_xref_gmrn_update/"

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/schema_util

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# tablename ="lr_xref_ssn_mrn_cluster_transaction"
# load_type = "delta"
# temp_op_path="abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/apundir/data/leadrepo/scratch/"
# op_path= "abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/apundir/data/leadrepo/cooked/"

# COMMAND ----------

print(temp_op_path)
print(op_path)
print(op_path)
print(tablename)

# COMMAND ----------

p_table_uniqkey_dictionary = {
    "lr_xref_gmrnid_transaction": "_id",
    "lr_xref_permid_transaction": "_id",
    "lr_xref_ssn_mrn_cluster_transaction":"_id,ssn,clusteredacctfk,medicalrecnum"}
# pjoinexpression = ""
# puniquecolname = p_table_uniqkey_dictionary.get(tablename)
# print(tablename)

# for column in puniquecolname.split(","):
#     print(column)
#     pjoinexpression = pjoinexpression + "raw." + column + "=delta." + column 
# print(pjoinexpression)

pjoinexpression = ""
puniquecolname = p_table_uniqkey_dictionary.get(tablename)
for column in puniquecolname.split(","):
    print(column)
    pjoinexpression = pjoinexpression + "raw." + column + "=delta." + column + " AND "

pjoinexpression = pjoinexpression.strip(" AND")
print(pjoinexpression)

# COMMAND ----------

#TEMP VAL SCRIPT
#print(temp_op_path + tablename)
#df = spark.read.parquet(temp_op_path + tablename + '/*')
#df.show(10,False)
#sourcekey = df.selectExpr("sourcekey").dropDuplicates().limit(1)
#sourcekey.show(10,False)
#sourcekey = [str(row.sourcekey) for row in sourcekey.collect()][0]

# COMMAND ----------

if load_type == 'base':
    df = spark.read.parquet(temp_op_path + tablename +'/*')
    df.write.format("delta").mode("overwrite").save(op_path + tablename)
else:
    df = spark.read.parquet(temp_op_path + tablename + '/*')
    sourcekey = df.selectExpr("sourcekey").dropDuplicates().limit(1)
    sourcekey = [str(row.sourcekey) for row in sourcekey.collect()][0]
    if tablename == 'lr_xref_permid_transaction' and sourcekey == '2':
        df.createOrReplaceTempView("data")
        df = spark.sql("""SELECT data.*, CASE WHEN UPPER(data.xrefsource) = 'IM' THEN '1' ELSE '2' END AS p_xrefsource FROM data""")
        df.createOrReplaceTempView("data")
        df = spark.sql("""SELECT transactionkey,
                                sourcekey,
                                permid,
                                lr_createdate,
                                lr_creatingmodule,
                                _id,
                                xrefsource,
                                audittrail,
                                hospitalfk,
                                ROW_NUMBER() OVER (PARTITION BY transactionkey,hospitalfk,sourcekey,permid ORDER BY p_xrefsource ASC) AS RNK
                        FROM data
                            """).filter("RNK=='1'").drop("RNK").dropDuplicates()
    else:
        print("not ich permid data")
    df_raw = DeltaTable.forPath(spark, op_path + tablename +'/')
    df=df.dropDuplicates()
    df_raw.alias("raw").merge(df.alias("delta"), pjoinexpression).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()
    print("update done")
    #spark.conf.set("spark.databricks.delta.retentionDurationCheck.enabled","false")
    #df_raw.vacuum(0)
    #print("vaccum done")
