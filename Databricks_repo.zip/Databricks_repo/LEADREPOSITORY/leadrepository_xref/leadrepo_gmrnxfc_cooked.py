# Databricks notebook source
#SET Parameters
dbutils.widgets.text('hdfs_path','')
hdfs_path = dbutils.widgets.get('hdfs_path')

dbutils.widgets.text('gmrn_path','')
gmrn_path = dbutils.widgets.get('gmrn_path')

dbutils.widgets.text('hdfs_leadrepo','')
hdfs_leadrepo = dbutils.widgets.get('hdfs_leadrepo')

dbutils.widgets.text('leadrepo_path_cooked','')
leadrepo_path_cooked = dbutils.widgets.get('leadrepo_path_cooked')

dbutils.widgets.text('bc','')
bc = dbutils.widgets.get('bc')

dbutils.widgets.text('fs_common','')
fs_common = dbutils.widgets.get('fs_common')

dbutils.widgets.text('config_temp','')
config_temp = dbutils.widgets.get('config_temp')

dbutils.widgets.text('config_file','')
config_file = dbutils.widgets.get('config_file')

dbutils.widgets.text('storageaccount','')
storageaccount = dbutils.widgets.get('storageaccount')

#'abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/apundir/data/leadrepo/config_temp/'
#'abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/apundir/data/leadrepo/config_file/'

# COMMAND ----------

print(fs_common)

# COMMAND ----------


    # hdfs_path = "abfss://npp@divyaprodstorageact1.dfs.core.windows.net/hcedata/user/phd9appl/CDD/publish/escan/data/"
    # hdfs_leadrepo = "abfss://npp@divyaprodstorageact1.dfs.core.windows.net/hceleads/user/phd9appl/leadrepo/data/raw/foundcoverage/20230419T20/*"
    # maprdbpath = "abfss://npp@divyaprodstorageact1.dfs.core.windows.net/hceleads/user/phd9appl/leadrepo/data/scratch/lr_xref_gmrnid_transaction/"
    # user = "phd9appl"
    # bc = "20230419T20"
    # fs_common = "abfss://npp@divyaprodstorageact1.dfs.core.windows.net/sourcecode/leadrepository/common/"

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
import datetime
import configparser

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------


def main():
    """Main ETL script definition.
    :return: None
    """
    xrefsource = "fc"
    id_key = "_id"
    spark = SparkSession.builder.appName("Lead Repo - xref gmrn FC").getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    block_size = str(1024 * 1024 * 1024)
    spark.conf.set("spark.sql.files.maxPartitionBytes", block_size)
    parser = configparser.ConfigParser()
    parser.read(fs_common + "/common.conf")
    # execute ETL pipeline
    current_dt = datetime.datetime.today().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    fc_cols = [
        "foundcoverageipk",
        "hitstatus",
        "currentinferredsourcemethodcode",
        "patientacctifk",
        "isdeleted",
        "hospitalfk"
    ]
    dfdelta = extract_parquet_data(spark, hdfs_leadrepo, fc_cols)
    # filtering out the edisourcedflag==1 records only
    fcismc_path = hdfs_path + "/foundcoverageinferredsourcemethodcodes/current/*"
    df_fcismc = extract_parquet_data(spark, fcismc_path)
    # Disabled on 10/17/2024 to address low volume issues
    # df_fcismc = df_fcismc.withColumn(
    #     "edisourceflag", df_fcismc.edisourcedflag.cast(IntegerType())
    # )
    # df_fcismc = df_fcismc.filter(df_fcismc.edisourcedflag == 1)
    df_fcismc= df_fcismc.filter("inferredflag=0") #Added this filter on 12/13/2024 to get the real verified records
    dfdelta = dfdelta.join(
        df_fcismc,
        trim(df_fcismc.inferredsourcemethodcode)
        == trim(dfdelta.currentinferredsourcemethodcode),
    ).select(dfdelta["*"])
    dfgmrn = extract_parquet_data(spark, gmrn_path + "globalmrnxpacct/current/*")
    dfxrefgmrn = transform_delta(spark, dfdelta, dfgmrn, bc, current_dt, xrefsource)
    write_cooked(spark, dfxrefgmrn, leadrepo_path_cooked, id_key)
    # log the success and terminate Spark application
    #spark.stop()
    return None


def extract_parquet_data(spark, hdfs_path, cols=None):
    if cols == "" or cols is None:
        df = spark.read.parquet(hdfs_path)
    else:
        df = spark.read.parquet(hdfs_path).select(cols)
    return df


def transform_delta(spark, dfdelta, dfgmrn, bc, current_dt, xrefsource):
    # dfraw = dfdelta.filter((dfdelta.hitstatus.isin(0, 1, 2)) & (dfdelta.isdeleted == 0))
    dfraw = dfdelta.filter((dfdelta.hitstatus.isin(1, 2)) & (dfdelta.isdeleted == 0))#Updated on 11/25/2024 for picking hitstatus 1,2 records
    dfxref = dfraw.join(dfgmrn, (dfgmrn.patientacctifk == dfraw.patientacctifk) & (dfgmrn.hospitalfk == dfraw.hospitalfk)).select(
        dfgmrn.globalmrnifk, dfraw.foundcoverageipk, dfraw.hospitalfk
    )
    dfxref = dfxref.withColumnRenamed("foundcoverageipk", "transactionkey")
    dfxref = dfxref.withColumn("sourcekey", lit("1"))
    dfxref = dfxref.withColumn("lr_createdate", lit(current_dt)).withColumn(
        "lr_creatingmodule", lit(bc)
    )
    dfxref = dfxref.withColumn(
        "_id",
        concat_ws("_", dfxref.globalmrnifk, dfxref.transactionkey,dfxref.hospitalfk,dfxref.sourcekey),
    ).dropDuplicates()
    dfxref = dfxref.withColumn("xrefsource", lit(xrefsource))
    dfxref = dfxref.withColumn(
        "audittrail", concat_ws("~", dfxref.globalmrnifk, dfxref.lr_creatingmodule)
    )
    dfxref = dfxref.select(
        dfxref.transactionkey,
        dfxref.sourcekey,
        dfxref.globalmrnifk.alias("gmrnid"),
        dfxref.lr_createdate,
        dfxref.lr_creatingmodule,
        dfxref._id,
        dfxref.xrefsource,
        dfxref.audittrail,
        dfxref.hospitalfk
    )
    return dfxref


def write_cooked(spark, df, outputpath, id_key):
    df.write.mode("overwrite").parquet(outputpath+"lr_xref_gmrnid_transaction/")
    return None


# entry point for PySpark ETL application
if __name__ == "__main__":
    main()


# COMMAND ----------

dbutils.fs.rm(config_temp, True)
dbutils.fs.rm(config_file, True)

# COMMAND ----------

output =  [{
    "tablename": "lr_xref_gmrnid_transaction"
}]
schema = StructType([StructField("tablename", StringType(), True)])
outputDf = spark.createDataFrame(output, schema)
outputDf.repartition(1).write.mode('append').format('json').save(config_temp)
