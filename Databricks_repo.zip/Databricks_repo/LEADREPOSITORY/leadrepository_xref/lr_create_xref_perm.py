# Databricks notebook source
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import datetime
from pyspark.sql.types import *
from pyspark.sql.window import Window
from pyspark.sql import functions as F
from pyspark.sql.functions import rank, col, row_number, udf
import re
from pyspark import SparkConf, SparkContext, SparkFiles

# COMMAND ----------

dbutils.widgets.text("data_input",'')
data_input = dbutils.widgets.get("data_input")

dbutils.widgets.text("module_name",'')
module_name = dbutils.widgets.get("module_name")

dbutils.widgets.text("maprdb_path",'')
maprdb_path = dbutils.widgets.get("maprdb_path")

dbutils.widgets.text("bc",'')
bc = dbutils.widgets.get("bc")

dbutils.widgets.text("path_toserve",'')
path_toserve = dbutils.widgets.get("path_toserve")

dbutils.widgets.text("fs_common",'')
fs_common = dbutils.widgets.get("fs_common")

dbutils.widgets.text("config_ich_temp",'')
config_ich_temp = dbutils.widgets.get("config_ich_temp")

dbutils.widgets.text("config_ich_file",'')
config_ich_file = dbutils.widgets.get("config_ich_file")

dbutils.widgets.text('storageaccount','')
storageaccount = dbutils.widgets.get('storageaccount')

#'abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/apundir/data/leadrepo/config_ich_temp/'
#'abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/apundir/data/leadrepo/config_ich_file/'

# COMMAND ----------

print("config_ich_file:",config_ich_file)
print("config_ich_temp:",config_ich_temp)
print("data_input:",data_input)
print("fs_common",fs_common)
print("maprdb_path",maprdb_path)
print("module_name",module_name)
print("path_toserve",path_toserve)

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# data_input = "abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/apundir/data/CDD/publish/"
# module_name = "es_postbdf"
# bc ="05JUN2023-18"

# COMMAND ----------

current_dt = datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/schema_util"

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/tu_data_quality"

# COMMAND ----------

# def createSchemaLine( schemaFile ) :
#     fields=[]
#     fh =  spark.read.text(schemaFile)
#     fileContent = fh.collect()
#     schemas = [schema[0] for schema in fileContent]
    
#     for field_name_type in schemas:
#         if not field_name_type.startswith("#"):
#             fieldNameType = field_name_type.split(',', 2)
#             fieldName = fieldNameType[0].strip()
#             fieldType = fieldNameType[1].strip()
#             if fieldType == "string":
#                 structField = StructField(fieldName, StringType(), True)
#                 fields.append(structField)
#             elif fieldType == "timestamp":
#                 structField = StructField(fieldName, TimestampType(), True)
#                 fields.append(structField)
#             elif fieldType == "int":
#                 structField = StructField(fieldName, IntegerType(), True)
#                 fields.append(structField)
#             elif fieldType == "integer":
#                 structField = StructField(fieldName, IntegerType(), True)
#                 fields.append(structField)
#             elif fieldType == "double":
#                 structField = StructField(fieldName, DoubleType(), True)
#                 fields.append(structField)
#             elif fieldType == "float":
#                 structField = StructField(fieldName, FloatType(), True)
#                 fields.append(structField)
#             elif fieldType == "decimal":
#                 structField = StructField(fieldName, DecimalType(), True)
#                 fields.append(structField)
#             elif fieldType == "smallint":
#                 structField = StructField(fieldName, ShortType(), True)
#                 fields.append(structField)
#             else:
#                 structField = StructField(fieldName, StringType(), True)
#                 fields.append(structField)
#     schema = StructType(fields)
#     return schema

# COMMAND ----------

schema = createSchemaLine(fs_common + "/lr_xref_parse.schema")
imrecs_schema = createSchemaLine(fs_common + "/lr_xref_parse_imrecs.schema")

# COMMAND ----------

def main():
    if (module_name == "ie_postbdf"):
        path_input = data_input + "/ie/imRecs/" + bc + "*"
        print(path_input)
    elif (module_name == "es_postbdf"):
        path_input = data_input + "/escanoutput/finalPolicyInfo/" + bc +"/"
        print(path_input)

    df_raw = extract_csv_data(path_input, schema,imrecs_schema,module_name)
    column_needed = ["iepermid", "tracenumber", "responseresultstd", "esmatchind", "dependentflag","hospitalfk"]
    df_cooked = transform_data(df_raw, column_needed, bc, current_dt)
    id_key = "_id"
    append_data(df_cooked, maprdb_path, id_key)
    toserve(df_cooked, path_toserve, bc, module_name)
    return None

# COMMAND ----------

# def filter_corrupted_imrecs_data(imrecs):
#     imrecs.createOrReplaceTempView("imrecs")
#     imrecs_cleaned = spark.sql(""" select iepermid, tracenumber, matchind as esmatchind,responseresultext,responseresultstd,
#                                    case when ((dependentfirstname is not null and trim(dependentfirstname) != "")
#                                         or (dependentlastname is not null and trim(dependentlastname) != "")
#                                         or (dependentdob is not null and trim(dependentdob) != "")
#                                         or (dependentssn is not null and trim(dependentssn) != ""))  then 't' else 'f'  end dependentflag
#                                     from imrecs
#                                     where tracenumber is null or length(tracenumber)<15
#                                 """)
#     return imrecs_cleaned 

# COMMAND ----------

def extract_csv_data(hdfs_path, schema,imrecs_schema,module_name):
    """
    reading the data for getting trans and permid
    :return: Spark DataFrame.
    """
    if (module_name == "ie_postbdf"):
      raw = spark.read.format("csv") \
                   .options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", mode="FAILFAST", quote="", delimiter="|") \
                   .schema(imrecs_schema).load(hdfs_path) \
                   .selectExpr("iepermid", "tracenumber", "matchind as esmatchind","responseresultext" ,"responseresultstd","dependentfirstname","dependentlastname",\
                    "dependentdob","dependentssn","custom1","clientid").dropDuplicates()
      raw_cleaned = raw.withColumn("dependentflag", when(raw.custom1.like('%00DS00ie00DEP00%'),lit('t')).otherwise(lit('f'))).drop("custom1")
        
        # raw_cleaned = filter_corrupted_imrecs_data(raw)
    else:
      raw_cleaned = spark.read.format("csv") \
                   .options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", mode="FAILFAST", quote="", delimiter="|") \
                   .schema(schema).load(hdfs_path) \
                   .selectExpr("iepermid", "tracenumber", "esmatchind","responseresultext" ,"responseresultstd","dependentflag","clientid").dropDuplicates()

    isValidResponseType_udf = udf(isValidResponseType, IntegerType())
    raw_cleaned = raw_cleaned.withColumn("isvalidresponse",isValidResponseType_udf(raw_cleaned.responseresultstd,raw_cleaned.responseresultext))
    raw_cleaned = raw_cleaned.filter(raw_cleaned.isvalidresponse == 1)
    raw_cleaned.createOrReplaceTempView("RAW_CSV")
    sqlQuery = """
    SELECT A.iepermid,
       A.tracenumber,
       A.responseresultstd,
       A.esmatchind, A.dependentflag, A.clientid AS hospitalfk
    FROM (SELECT A.iepermid,
             A.tracenumber,
             A.responseresultstd,
             A.esmatchind,A.dependentflag, A.clientid,
    RANK() OVER (PARTITION BY A.tracenumber ORDER BY A.dependentflag DESC) AS RNK
    FROM (SELECT iepermid,
                   tracenumber,
                   responseresultstd,
                   esmatchind,
                   CASE
                     WHEN LOWER(TRIM(dependentflag)) = 'f' THEN '0'
                     WHEN LOWER(TRIM(dependentflag)) = 't' THEN '1'
                     ELSE NULL
                   END AS dependentflag, clientid
            FROM RAW_CSV ) A) A
    WHERE A.RNK = 1
    """
    raw_data = spark.sql(sqlQuery).dropDuplicates()
    return raw_data

# COMMAND ----------

def transform_data(df, column_needed, bc, current_dt):
    """
    This code is for creating the partition coloumn depending on the mod value
    :return:  Spark DataFrame
    """

    df = df.select(column_needed) \
        .withColumn("lr_creatingmodule", lit(bc)) \
        .withColumn("lr_createdate", lit(current_dt)) \
        .withColumn("sourcekey", lit('2')) \
        .withColumnRenamed('iepermid', 'permid')
    df = df.withColumn("_id", concat_ws("-", df.permid, df.tracenumber, df.hospitalfk, df.sourcekey)).dropDuplicates()
    df = df.withColumn("xrefsource", lower(col("esmatchind")))
    df = df.withColumn("audittrail", concat_ws("~", df.permid, df.lr_creatingmodule))
    df = df.select(df.tracenumber.alias("transactionkey") \
                   , "sourcekey" \
                   , "permid" \
                   , "lr_createdate" \
                   , "lr_creatingmodule", "_id", "xrefsource", "audittrail","dependentflag","hospitalfk")
    return df

# COMMAND ----------

def append_data(df, hdfs_path, id_key):
    """
    This code append the data to the end dataset
    :return none
    """
    df1 = df.drop(df.dependentflag)
    df1.repartition(200).write.mode("overwrite").parquet(hdfs_path)
    return None

# COMMAND ----------

def toserve(df, toservepath, bc, notifysource):
    dfwrite = df.select(df.transactionkey, df.sourcekey, df.dependentflag, df.permid.alias('identity'), df.xrefsource)
    dfwrite = dfwrite.withColumn("identity", concat(lit('P_'),dfwrite.identity))
    dfwrite.repartition(50).write.mode("append").parquet(toservepath + "/" + notifysource + "/" + bc + "/")

# COMMAND ----------

if __name__ == '__main__':
    main()

# COMMAND ----------

dbutils.fs.rm(config_ich_temp, True)
dbutils.fs.rm(config_ich_file, True)

# COMMAND ----------

output =  [{
    "tablename": "lr_xref_permid_transaction"
}]
schema = StructType([StructField("tablename", StringType(), True)])
outputDf = spark.createDataFrame(output, schema)
outputDf.repartition(1).write.mode('append').format('json').save(config_ich_temp)
