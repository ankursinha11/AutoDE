# Databricks notebook source
from pyspark.sql.functions import *
import datetime
from pyspark.sql.types import *

# COMMAND ----------

dbutils.widgets.text('data_input','')
data_input = dbutils.widgets.get('data_input')

dbutils.widgets.text('module_name','')
module_name = dbutils.widgets.get('module_name')

dbutils.widgets.text('maprdb_path','')
maprdb_path = dbutils.widgets.get('maprdb_path')

dbutils.widgets.text('bc','')
bc = dbutils.widgets.get('bc')

dbutils.widgets.text('path_toserve','')
path_toserve = dbutils.widgets.get('path_toserve')

dbutils.widgets.text('fs_common','')
fs_common = dbutils.widgets.get('fs_common')

dbutils.widgets.text("config_ich_temp",'')
config_ich_temp = dbutils.widgets.get("config_ich_temp")

dbutils.widgets.text("config_ich_file",'')
config_ich_file = dbutils.widgets.get("config_ich_file")

dbutils.widgets.text('storageaccount','')
storageaccount = dbutils.widgets.get('storageaccount')

# path_input = "abfss://npp@divyaprodstorageact1.dfs.core.windows.net/hcecdd/user/gsingh/CDD/publish/es_cm2/finalPolicyInfo/finalPolicyInfo/20230514T08"
# user = "gsingh"
# #module_name = "ie_postbdf"
# module_name = "es_postbdf"

# maprdb_path = "abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/hceleads/user/apundir/test/scratch/es_postbdf"
# bc = "20230514T08"
# path_toserve = "abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/hceleads/user/apundir/test/toserve/20230514T08"
# fs_common = "abfss://npp@divyaprodstorageact1.dfs.core.windows.net/hceleads/user/phd9appl/leadrepo/oozie/ich_import"

current_dt = datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]

# COMMAND ----------

print("config_ich_file:",config_ich_file)
print("config_ich_temp:",config_ich_temp)
print("data_input:",data_input)
print("fs_common",fs_common)
print("maprdb_path",maprdb_path)
print("module_name",module_name)
print("path_toserve",path_toserve)

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/schema_util"

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/tu_data_quality"

# COMMAND ----------

def main():
    schema = createSchemaLine(fs_common + "/lr_xref_parse.schema")
    if (module_name == "ie_postbdf"):
        path_input = data_input + "/ie_cm2/finalPolicyInfo/" + bc + "/*"
        print(path_input)
    elif (module_name == "es_postbdf"):
        path_input = data_input + "/es_cm2/finalPolicyInfo/" + bc +"/*"
        print(path_input)
    df_raw = extract_csv_data(path_input, schema, current_dt, bc)
    id_key = "_id"
    append_to_maprdb(df_raw, maprdb_path, id_key)
    writetoserve(df_raw, module_name, path_toserve, bc)
    return None

# COMMAND ----------

def extract_csv_data(hdfs_path, schema, current_dt, bc):
    isValidGMRN_udf = udf(isValidGmrnid, IntegerType())
    isValidResponseType_udf = udf(isValidResponseType, IntegerType())
    raw_data = spark.read.format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", mode="FAILFAST", quote="", delimiter="|").schema(schema).load(hdfs_path).dropDuplicates()
    raw_data = raw_data.selectExpr("iepermid as gmrnid", "tracenumber as transactionkey", "responseresultstd","responseresultext","esmatchind","dependentflag","clientid")
    raw_data = raw_data.withColumn('gmrn_valid', isValidGMRN_udf(raw_data.gmrnid))
    raw_data = raw_data.filter(raw_data.gmrn_valid == 1)
    raw_data = raw_data.withColumn("isValidResponseType",isValidResponseType_udf(raw_data.responseresultstd,raw_data.responseresultext))
    raw_data = raw_data.filter(raw_data.isValidResponseType == 1)
    raw_data = raw_data.withColumn("lr_createdate", lit(current_dt)).withColumn("lr_creatingmodule", lit(bc)).withColumn("sourcekey", lit('2'))
    raw_data = raw_data.withColumn("_id", concat_ws("-", raw_data.gmrnid, raw_data.transactionkey, raw_data.clientid, raw_data.sourcekey)).dropDuplicates()
    raw_data = raw_data.withColumn("xrefsource", lower(col("esmatchind")))
    raw_data = raw_data.withColumn("audittrail", concat_ws("~", raw_data.gmrnid, raw_data.lr_creatingmodule))
    raw_data = raw_data.select("transactionkey" \
                               , "sourcekey" \
                               , "gmrnid" \
                               , "lr_createdate" \
                               , "lr_creatingmodule" \
                               , "_id", "xrefsource", "audittrail","dependentflag","clientid")
    raw_data = raw_data.withColumnRenamed("clientid","hospitalfk")
    return raw_data

# COMMAND ----------

def append_to_maprdb(df, hdfs_path, id_key):
    df1 = df.drop(df.dependentflag)
    df1.repartition(200).write.mode("overwrite").parquet(hdfs_path)

# COMMAND ----------

def writetoserve(df, notifysource, path_toserve, bc):
    dfwrite = df.select(df.transactionkey, df.sourcekey, df.dependentflag, df.gmrnid.alias('identity'), df.xrefsource)
    dfwrite = dfwrite.withColumn("dependentflag", when(lower(df.dependentflag) == 't', lit('1')).otherwise(lit('0'))).withColumn("identity", concat(lit('G_'),dfwrite.identity))
    #print("count",dfwrite.count())
    dfwrite.repartition(50).write.mode("append").parquet(path_toserve + "/" + notifysource + "/" + bc + "/")

# COMMAND ----------

if __name__ == '__main__':
    main()

# COMMAND ----------

output =  [{
    'tablename': 'lr_xref_gmrnid_transaction'
}]
schema = StructType([StructField("tablename", StringType(), True)])
outputDf = spark.createDataFrame(output, schema)
outputDf.repartition(1).write.mode('append').format('json').save(config_ich_temp)

# COMMAND ----------

config_df=spark.read.format('json').load(config_ich_temp)
config_df.repartition(1).write.mode('overwrite').format('json').save(config_ich_file)
