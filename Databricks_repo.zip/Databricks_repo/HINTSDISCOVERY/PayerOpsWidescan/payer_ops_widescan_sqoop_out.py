# Databricks notebook source
dbutils.widgets.text("tablename","")
dbutils.widgets.getArgument("tablename")
tablename= getArgument("tablename")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("hints_sqoop_out","")
dbutils.widgets.getArgument("hints_sqoop_out")
hints_sqoop_out= getArgument("hints_sqoop_out")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

hints = spark.read.parquet(baseurl+hints_sqoop_out+bc +'/final_hints')
hints=hints.drop("medicarehic","medicaidnum")

# COMMAND ----------

path_conn_file = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-transport-sql-insleads-cs")
hints.write.format('jdbc').mode('append').option('driver', 'com.microsoft.sqlserver.jdbc.SQLServerDriver').option \
        ('url', path_conn_file).option('dbtable',tablename).save()
