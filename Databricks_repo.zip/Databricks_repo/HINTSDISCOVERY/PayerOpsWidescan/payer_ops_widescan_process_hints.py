# Databricks notebook source
# DBTITLE 1,Common script
# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

# DBTITLE 1,Common Process leads script
# MAGIC %run /Insleads-code/LeadDiscovery/common/process_leads

# COMMAND ----------

# DBTITLE 1,Common hints_get_pa script
# MAGIC %run /Insleads-code/HINTSDISCOVERY/HintsGeneration/Common/hints_get_candidate_patientaccts

# COMMAND ----------

dbutils.widgets.text("dataingestion_publish_path", "")
dataingestion_publish_path = dbutils.widgets.get("dataingestion_publish_path")

dbutils.widgets.text("payeropswidescan_transform_path", "")
payeropswidescan_transform_path = dbutils.widgets.get("payeropswidescan_transform_path")

dbutils.widgets.text("bc", "")
bc = dbutils.widgets.get("bc")

dbutils.widgets.text("user", "")
user = dbutils.widgets.get("user")

dbutils.widgets.text("container", "")
container = dbutils.widgets.get("container")

dbutils.widgets.text("storageaccount", "")
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text("patientacctxhints_path", "")
patientacctxhints_path = dbutils.widgets.get("patientacctxhints_path")

dbutils.widgets.text("patientacctxleads_path", "")
patientacctxleads_path = dbutils.widgets.get("patientacctxleads_path")

# COMMAND ----------

# DBTITLE 1,Authentication
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# DBTITLE 1,I/P & O/P Paths
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

dataingestion_publish_path = baseurl+dataingestion_publish_path
payeropswidescan_transform_path = baseurl+payeropswidescan_transform_path
patientacctxhints_path= baseurl+patientacctxhints_path
patientacctxleads_path= baseurl+patientacctxleads_path

hdfs_admitdatelookup=payeropswidescan_transform_path+'/minmaxbyedipartnerfk/'+bc+'/*'
hdfs_input=payeropswidescan_transform_path+ bc +'/candidate_patientaccts/'
hdfs_scratch=payeropswidescan_transform_path+bc+'/'
final_hints_path=payeropswidescan_transform_path + bc +'/final_hints'


print("bc="+str(bc))
print("container="+str(container))
print("dataingestion_publish_path="+str(dataingestion_publish_path))
print("payeropswidescan_transform_path="+str(payeropswidescan_transform_path))
print("final_hints_path="+str(final_hints_path))
print("patientacctxhints_path="+str(patientacctxhints_path))
print("patientacctxleads_path="+str(patientacctxleads_path))
print("hdfs_admitdatelookup="+str(hdfs_admitdatelookup))
print("hdfs_scratch="+str(hdfs_scratch))
print("hdfs_input="+str(hdfs_input))

# COMMAND ----------

# DBTITLE 1,addedidatasourcefk function
def addedidatasourcefk(spark, all_hints):
    edi = all_hints.withColumn("edidatasourcefk",lit(56))
    return edi

# COMMAND ----------

# DBTITLE 1,Renaming edipartnerpk for using the common functions
all_leads_df=spark.read.parquet(hdfs_input)
all_leads_df=all_leads_df.withColumnRenamed("edipartnerpk","lsb_edipartnerfk")

# COMMAND ----------

# DBTITLE 1,filtering using common functions
#admitdate on partner
all_hints_admitdt_partner_df = filter_admitdt_partner_hints(spark, all_leads_df, hdfs_admitdatelookup)

#filter_commerical_tricare_edipartners
all_leads_ct_df = filter_commerical_tricare_edipartners(spark, all_hints_admitdt_partner_df, dataingestion_publish_path, hdfs_scratch)

#check if hpn is enabled
all_leads_hpn_df = filter_ifhpn_notenabled(spark, all_leads_ct_df, dataingestion_publish_path, hdfs_scratch)

#filter_mincharges_by_partner
all_leads_passmincharges_df = filter_mincharges_by_partner(spark, all_leads_hpn_df, dataingestion_publish_path, hdfs_scratch)

# COMMAND ----------

# DBTITLE 1,Check against patientacctxleads
paxleads_df=spark.read.format('delta').load(patientacctxleads_path)
missing_hints_df = (
            all_leads_passmincharges_df.join(
            paxleads_df,
            on = (
                (all_leads_passmincharges_df.hospitalfk==paxleads_df.hospitalfk)&
                (all_leads_passmincharges_df.lsb_edipartnerfk==paxleads_df.lsb_edipartnerfk)&
                (all_leads_passmincharges_df.patientacctifk==paxleads_df.patientacctifk)
            ),
            how="leftanti"))

# COMMAND ----------

# DBTITLE 1,vendor_ohi_records
birthmonth_hosp_df = spark.read.parquet(dataingestion_publish_path+'/birthmonthrequeryhospitals/current/20991231/')
birthmonth_hosp_df=birthmonth_hosp_df.filter("IsActive=1")
birthmonth_hospitals = [row.HospitalFK for row in birthmonth_hosp_df.select("HospitalFK").collect()]
birthmonth_hospitals_str = ','.join(str(hospital) for hospital in birthmonth_hospitals)

vendorknownohicoverages_df = spark.read.format('delta').load(dataingestion_publish_path+"/vendorknownohicoverages/current/20991231/")
vendorknownohibenefits_df=spark.read.format('delta').load(dataingestion_publish_path+"/vendorknownohibenefits/current/20991231/")
vendorknownohicoverages_df.createOrReplaceTempView("vendorknownohicoverages_tbl")
vendorknownohibenefits_df.createOrReplaceTempView("vendorknownohibenefits_tbl")

v_ohi_query=f"""SELECT vkc.PatientAcctIFK,
						   vkc.EDIPartnerFK,
							vkc.HospitalFK
					FROM vendorknownohicoverages_tbl vkc 
						JOIN vendorknownohibenefits_tbl vkb
							ON vkc.VendorKnownOHICoveragesPK = vkb.VendorKnownOHICoveragesFK
					WHERE vkc.HospitalFK IN ({birthmonth_hospitals_str})
						  AND vkb.BenefitEndDate > GETDATE()"""
vendor_ohi_records_df=spark.sql(v_ohi_query)

# COMMAND ----------

# DBTITLE 1,filter vendor_ohi_records
missing_ohi_candidates_df = missing_hints_df.join(
    vendor_ohi_records_df,
    (missing_hints_df.patientacctifk == vendor_ohi_records_df.PatientAcctIFK) &
    (missing_hints_df.lsb_edipartnerfk == vendor_ohi_records_df.EDIPartnerFK) &
    (missing_hints_df.hospitalfk == vendor_ohi_records_df.HospitalFK),
    how='leftanti'
)

# COMMAND ----------

# DBTITLE 1,ohibatchprocess & addedidatasourcefk
all_leads_ohi_df = ohibatchprocess(spark, missing_ohi_candidates_df, dataingestion_publish_path, hdfs_scratch)
all_leads_edidatasourcefk_df = addedidatasourcefk(spark, all_leads_ohi_df)

# COMMAND ----------

# DBTITLE 1,EB1 filter
enddt = date_sub(current_date(), 90)
hits_misses_df=spark.read.format('delta').load(dataingestion_publish_path+'/ediqueryhitsandmisses/current/20991231/')
hits_misses_df=hits_misses_df.filter((hits_misses_df.result.like("EB:1"))&(hits_misses_df.createdate >= enddt))
ediqueries_df=spark.read.format('delta').load(dataingestion_publish_path+'/ediqueries/current/20991231/')
hits_misses_df.createOrReplaceTempView("hits_misses")
ediqueries_df.createOrReplaceTempView("ediqueries")
all_leads_edidatasourcefk_df.createOrReplaceTempView("all_leads_edidatasourcefk_df")
hits_misses_final_df = spark.sql("""
    SELECT h.*
    FROM all_leads_edidatasourcefk_df h
    LEFT ANTI JOIN (
        SELECT
            hm.EDIPartnerFK,
            hm.hospitalfk,
            eq.patientacctifk
        FROM
            hits_misses hm
            JOIN ediqueries eq
                ON hm.ediqueryfk = eq.ediquerypk
                AND hm.hospitalfk = eq.hospitalfk
    ) hm
        ON h.patientacctifk = hm.patientacctifk
        AND h.lsb_edipartnerfk = hm.EDIPartnerFK
        AND h.hospitalfk = hm.hospitalfk
""")

# COMMAND ----------

# DBTITLE 1,Read Schema to sqoop & write out the final hints
hits_misses_final_df.createOrReplaceTempView("all_hints")

final_edi_df = spark.sql(""" 
    SELECT 
        CAST(patientacctifk AS LONG) AS patientacctifk,
        CAST(hospitalfk AS INT) AS hospitalfk,
        hospitalname,
        lsb_edipartnerfk AS edipartnerfk,
        'InProgress' AS PatientAcctXLeadStatus,
        CURRENT_TIMESTAMP() AS PatientAcctXLeadStatusUpdateDate,
        firstname,
        lastname,
        middlename,
        CAST(dob AS TIMESTAMP) AS dob,
        ssn,                 
        gender,
        state,
        CAST(NULL AS STRING) AS TraditionalIdentifier,
        CAST(admitdate AS TIMESTAMP) AS admitdate,
        CAST(dischargedate AS TIMESTAMP) AS dischargedate,
        CAST(NULL AS STRING) AS CoverageID,
        CAST(NULL AS STRING) AS FC_SSN,
        CAST(NULL AS STRING) AS FC_DOB,
        CAST(NULL AS STRING) AS FC_LastName,
        CAST(NULL AS STRING) AS FC_FirstName,
        CAST(clusteredacctfk AS INT) AS clusteredacctfk,
        CAST(totalcharges AS DECIMAL(32,4)) AS totalcharges,
        npi,
        CAST(NULL AS INT) AS UsingFamilyDataFlag,
        CAST(NULL AS INT) AS DemographicsHash,
        CAST(NULL AS STRING) AS LastAbiETLStartDate,
        edidatasourcefk,
        CAST(NULL AS STRING) AS EDIDataSourceTableKey,
        CAST(NULL AS STRING) AS AssociationSource,
        medicarehic,
        medicaidnum
    FROM all_hints
""")
final_edi_df.write.mode("overwrite").parquet(final_hints_path)

# COMMAND ----------

# DBTITLE 1,append final hints
new_hints_df = spark.read.parquet(final_hints_path).dropDuplicates()
new_hints_df=new_hints_df.drop("medicarehic","medicaidnum")
new_hints_df = new_hints_df.withColumn("breadcrumb", lit(bc))
new_hints_df.write.mode("append").format("delta").save(patientacctxhints_path)
