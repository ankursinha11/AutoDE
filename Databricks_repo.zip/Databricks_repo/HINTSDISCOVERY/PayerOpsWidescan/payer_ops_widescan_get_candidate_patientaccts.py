# Databricks notebook source
# MAGIC %run /Insleads-code/LeadDiscovery/common/get_candidate_patientaccts

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

# DBTITLE 1,imports
from pyspark.sql.functions import *

# COMMAND ----------

# DBTITLE 1,parameters
dbutils.widgets.text("storageaccount","")
storageaccount = dbutils.widgets.getArgument("storageaccount")

dbutils.widgets.text("container","")
container = dbutils.widgets.getArgument("container")

dbutils.widgets.text("bc","")
bc = dbutils.widgets.getArgument("bc")

dbutils.widgets.text("user","")
user = dbutils.widgets.getArgument("user")

dbutils.widgets.text("dataingestion_publish_path","")
dataingestion_publish_path = dbutils.widgets.getArgument("dataingestion_publish_path")

dbutils.widgets.text("payeropswidescan_transform_path","")
payeropswidescan_transform_path = dbutils.widgets.getArgument("payeropswidescan_transform_path")

dbutils.widgets.text("notificationtype","")
notificationtype = notificationtype = dbutils.widgets.getArgument("notificationtype")

dbutils.widgets.text("lead_mode_flag","")
lead_mode_flag = dbutils.widgets.getArgument("lead_mode_flag")

dbutils.widgets.text("num_of_days","")
num_of_days = dbutils.widgets.getArgument("num_of_days")

dbutils.widgets.text("birthmonth_hospitals","")
birthmonth_hospitals = dbutils.widgets.getArgument("birthmonth_hospitals")


# COMMAND ----------

# DBTITLE 1,calculate all the required i/p & o/p paths
if user == 'na': 
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

dataingestion_publish_path = baseurl+dataingestion_publish_path
payeropswidescan_transform_path = baseurl+payeropswidescan_transform_path
hdfs_admitdatelookup=payeropswidescan_transform_path+notificationtype+'/minmaxbyhospital/'+bc+'/*'

hdfs_scratch=payeropswidescan_transform_path+notificationtype+ '/' + bc + '/candidate_patientaccts/'
pa_path=dataingestion_publish_path+'/patientaccts/current/20991231/'

print("-------------------------------Inputs-------------------------------")
print("bc="+str(bc))
print("container="+str(container))
print("dataingestion_publish_path="+str(dataingestion_publish_path))
print("lead_mode_flag="+str(lead_mode_flag))
print("payeropswidescan_transform_path="+str(payeropswidescan_transform_path))
print("hdfs_admitdatelookup="+str(hdfs_admitdatelookup))
print("notificationtype="+str(notificationtype))
print("storageaccount="+str(storageaccount))
print("user="+str(user))
print("pa_path="+str(pa_path))
print("num_of_days="+str(num_of_days))
print("-------------------------------Outputs-------------------------------")
print("hdfs_scratch="+str(hdfs_scratch))


# COMMAND ----------

# DBTITLE 1,authenticate the storage acct
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# DBTITLE 1,get list of birthmonth hospitals
hosp_arr =''
if (birthmonth_hospitals!='na'):
    birthmonth_hospitals = birthmonth_hospitals.split(",")  
    print("birthmonth_hospitals="+str(birthmonth_hospitals))
else:
    birthmonth_hosp_df = readparquet(spark, dataingestion_publish_path + "/birthmonthrequeryhospitals/current/20991231", "0", 'na')
    birthmonth_hospitals = [row.HospitalFK for row in birthmonth_hosp_df.select("HospitalFK").collect()]
print("birthmonth_hospitals="+str(birthmonth_hospitals))

# COMMAND ----------

# DBTITLE 1,get admitdate_df and enddate
admitdate_df = readparquet(spark, hdfs_admitdatelookup, '0', 'na')
admitdate_df = admitdate_df.filter(admitdate_df.hospitalfk.isin(birthmonth_hospitals))
end_date = date_sub(current_date(), int(num_of_days))

# COMMAND ----------

# DBTITLE 1,read all the required data
edipartners_df = readparquet(spark, dataingestion_publish_path + "/edipartners/current/20991231", "0", 'na')

vsnap_selected_cols = ["patientacctifk", "hospitalfk", "knownmcaidflag", "primarymcaidflag", "hasmedicareflag", "knowntricareflag", "secondarymcaid_afterinsuranceflag","createdate"]
vsnapflags_df = extract_deltalake_data(spark, dataingestion_publish_path + "/vsnappatientacctsflags/current/20991231/", vsnap_selected_cols)
vsnapflags_df = vsnapflags_df.join(admitdate_df, admitdate_df.hospitalfk == vsnapflags_df.hospitalfk).select(vsnapflags_df['*'])
vsnapflags_df = vsnapflags_df.withColumn('patientacctifk', vsnapflags_df.patientacctifk.cast("long"))
vsnapflags_df = vsnapflags_df.withColumnRenamed('createdate', 'vsnapflags_createdate')
vsnapflags_df = vsnapflags_df.withColumnRenamed('hospitalfk', 'vsnapflags_hospitalfk')

opsedipayershospitals_df = readparquet(spark, dataingestion_publish_path + "/opsedipayershospitals/current/20991231", "0", 'na')

hospitalattributes_df = readparquet(spark, dataingestion_publish_path + "/hospitalattributes/current/*", '0', 'na')
hospitalattributevalues_df = readparquet(spark, dataingestion_publish_path + "/hospitalattributevalues/current/*", '0', 'na')
hospattr_values_joined_df = hospattributes(spark, hospitalattributes_df, hospitalattributevalues_df)

hosp_ins_selected_cols = ["hospinsurancecodepk", "hospitalfk", "code", "codedesc", "hospcodestatusfk" ,"mcare", "secondarytomcaid", "edipayerfk" ]
hospinsurancecodes_df = extract_deltalake_data(spark, dataingestion_publish_path + "hospinsurancecodes/current/20991231/", hosp_ins_selected_cols)

paacctcodes_selected_cols = [ "patientacctifk", "hospitalfk", "insurancecode1", "insurancecode2", "insurancecode3"  ]
patientacctcodes_df =  extract_deltalake_data(spark, dataingestion_publish_path + "/patientacctscodes/current/20991231/", paacctcodes_selected_cols)

edipayers_df = readparquet(spark, dataingestion_publish_path + "/edipayers/current/20991231", "0", 'na')

# COMMAND ----------

# DBTITLE 1,get last 90 days patientaccts
patientaccts_df = get_patientacct(spark, pa_path, lead_mode_flag, end_date, bc, admitdate_df, vsnapflags_df)

# COMMAND ----------

# DBTITLE 1,filter the patientaccts born in current week
patientaccts_df.createOrReplaceTempView("patientaccts_tbl")
patientaccts_df = spark.sql("""
    SELECT * FROM patientaccts_tbl pa
    WHERE WEEKOFYEAR(pa.DOB) = WEEKOFYEAR(current_date())
""")
#discharge date filter
patientaccts_df = patientaccts_df.withColumn("dischargedate", trim(col("dischargedate")))
patientaccts_df = patientaccts_df.withColumn("dischargedate", when(col("dischargedate") == '', None).otherwise(col("dischargedate")))
patientaccts_df = patientaccts_df.filter((patientaccts_df.dischargedate.isNull()) | (patientaccts_df.dischargedate >= current_date()))

# COMMAND ----------

# DBTITLE 1,commercial patientaccts
paccts_commercial_df = getcandidateacctsfilter_ll(spark, patientaccts_df, patientacctcodes_df, hospattr_values_joined_df, hospinsurancecodes_df, edipayers_df)

# COMMAND ----------

# DBTITLE 1,get all the ops enabled partners
birthmonth_hospitals_str = ','.join(map(str, birthmonth_hospitals))

query = f"""
        SELECT DISTINCT ep.EDIPartnerPK, op.hospitalfk
        FROM opsedipayershospitals_tbl op
        JOIN edipartners_tbl ep ON op.EDIPayerFK = ep.EDIPayerFK
        WHERE op.HospitalFK IN ({birthmonth_hospitals_str})
        AND op.EnableFlag = 1 AND ep.isenabledflag=1
        ORDER BY EDIPartnerPK
        """
opsedipayershospitals_df.createOrReplaceTempView("opsedipayershospitals_tbl")
edipartners_df.createOrReplaceTempView("edipartners_tbl")

opspayers_edipartner_mapping_df = spark.sql(query)
opspayers_edipartner_mapping_df=opspayers_edipartner_mapping_df.select("EDIPartnerPK","hospitalfk")

# COMMAND ----------

# DBTITLE 1,tag all the partners with every patientacct
patientaccts_x_partners_df = paccts_commercial_df.join(opspayers_edipartner_mapping_df, 'hospitalfk').select(paccts_commercial_df["*"], opspayers_edipartner_mapping_df.EDIPartnerPK)
#write patientaccts for further processing
patientaccts_x_partners_df.write.mode("overwrite").parquet(hdfs_scratch)
