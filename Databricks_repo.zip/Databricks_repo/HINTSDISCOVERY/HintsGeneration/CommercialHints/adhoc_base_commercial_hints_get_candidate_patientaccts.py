# Databricks notebook source
#   Divya Vandana
#   09/06/2024
#   This pyspark script is used to get candidate accounts for Commercial Hints FC
#   Revision History:

# bc="20240618T16"
# container="prod-icd-stg-adls"
# dataingestion_publish_path="/data/dataingestion/publish/"
# hintsgeneration_transform_path="/data/hintsdiscovery/transform/scratch/commercial_hints/"
# storageaccount="prodicdstgdls"
# user="divya"

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/tu_data_quality

# COMMAND ----------

# MAGIC %run /Insleads-code/LeadDiscovery/common/process_leads

# COMMAND ----------

# MAGIC %run /Insleads-code/LeadDiscovery/common/get_candidate_patientaccts

# COMMAND ----------

# MAGIC %run ../Common/hints_get_candidate_patientaccts

# COMMAND ----------

dbutils.widgets.text("dataingestion_publish_path", "")
dataingestion_publish_path = dbutils.widgets.get("dataingestion_publish_path")

dbutils.widgets.text("hintsgeneration_transform_path", "")
hintsgeneration_transform_path = dbutils.widgets.get("hintsgeneration_transform_path")

dbutils.widgets.text("bc", "")
bc = dbutils.widgets.get("bc")

dbutils.widgets.text("user", "")
user = dbutils.widgets.get("user")

dbutils.widgets.text("container", "")
container = dbutils.widgets.get("container")

dbutils.widgets.text("storageaccount", "")
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text("num_of_days_hints", "")
num_of_days_hints = dbutils.widgets.get("num_of_days_hints")

dbutils.widgets.text("patientacctxhints_path", "")
patientacctxhints_path = dbutils.widgets.get("patientacctxhints_path")

dbutils.widgets.text("patientacctxleads_path", "")
patientacctxleads_path = dbutils.widgets.get("patientacctxleads_path")


# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

dataingestion_publish_path = baseurl+dataingestion_publish_path
hintsgeneration_transform_path = baseurl+hintsgeneration_transform_path
patientacctxhints_path= baseurl+patientacctxhints_path
patientacctxleads_path= baseurl+patientacctxleads_path

hdfs_admitdatelookup=hintsgeneration_transform_path+'/minmaxbyedipartnerfk/'+bc+'/*'
hdfs_scratch=hintsgeneration_transform_path+bc+'/'
pa_path=dataingestion_publish_path+'/patientaccts/current/20991231/'
edipartners_path = dataingestion_publish_path + '/edipartners/current/20991231'
edipartnertype_path = dataingestion_publish_path + '/edipartnertype/current/20991231'
hpn_path = dataingestion_publish_path + '/hospitalprovidernums/current/20991231'
hintFC_path=dataingestion_publish_path+'/hintfoundcoverage/current/20991231/'


print("bc="+str(bc))
print("container="+str(container))
print("dataingestion_publish_path="+str(dataingestion_publish_path))
print("hintsgeneration_transform_path="+str(hintsgeneration_transform_path))
print("patientacctxhints_path="+str(patientacctxhints_path))
print("patientacctxleads_path="+str(patientacctxleads_path))
print("hdfs_admitdatelookup="+str(hdfs_admitdatelookup))
print("hdfs_scratch="+str(hdfs_scratch))

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
import datetime
import getpass
import os
import sys
import subprocess

# COMMAND ----------

# DBTITLE 1,Get active hospital vsnap records
admitdate = readparquet(spark, hdfs_admitdatelookup, '0', 'na')
admitdate_lkp = admitdate.select("hospitalfk").dropDuplicates()
enddt = date_sub(current_date(), int(num_of_days_hints))

#filter the active hospitals from admitdt lookup
vsnapcols = ["patientacctifk", "hospitalfk", "knownmcaidflag", "primarymcaidflag", "hasmedicareflag", "knowntricareflag", "secondarymcaid_afterinsuranceflag","createdate"]
vsnapflags = extract_deltalake_data(spark, dataingestion_publish_path + "/vsnappatientacctsflags/current/20991231/", vsnapcols)
vsnapflags = vsnapflags.join(admitdate_lkp, admitdate_lkp.hospitalfk == vsnapflags.hospitalfk).select(vsnapflags['*'])
vsnapflags = vsnapflags.withColumn('patientacctifk', vsnapflags.patientacctifk.cast("long"))
vsnapflags = vsnapflags.withColumnRenamed('createdate', 'vsnapflags_createdate')
vsnapflags = vsnapflags.withColumnRenamed('hospitalfk', 'vsnapflags_hospitalfk')

# COMMAND ----------

# DBTITLE 1,Read hintfc and join with vsnap
#Read Delta Hintfoundcoverage records
hintFC = extract_deltalake_data(spark, hintFC_path)
hintFC = hintFC.withColumn('patientacctifk', hintFC.patientacctifk.cast("long"))
hintFC = hintFC.filter(hintFC.updatedate >= enddt)

#join hintfc with vsnapflags
hints_vsnap_df = hintFC.join(vsnapflags,
        (hintFC.patientacctifk == vsnapflags.patientacctifk) & 
        (hintFC.hospitalfk == vsnapflags.vsnapflags_hospitalfk)).drop(vsnapflags.vsnapflags_hospitalfk,vsnapflags.patientacctifk)

# COMMAND ----------

# DBTITLE 1,map payer to partner and get enabled partners
edipartners = readparquet(spark, edipartners_path, '0', 'na')
hints_partner_df  = get_edipartner(spark, hints_vsnap_df, edipartners)
writeparquet(spark, hints_partner_df, hdfs_scratch + "/hints_partner", 0, "overwrite")

# COMMAND ----------

# DBTITLE 1,get enabled edipartners from hpn
hpn = extract_parquet_data(spark,dataingestion_publish_path + "hospitalprovidernums/current/20991231/")
hints_partner = readparquet(spark, hdfs_scratch + "/hints_partner/", "0", "na")
get_enabled_edipartners_hpn(spark, hints_partner, hpn)

# COMMAND ----------

# DBTITLE 1,filter_commerical_tricare_edipartners
#calling common filter_commerical_tricare_edipartners function from process leads
hints_partner_tmp = readparquet(spark, hdfs_scratch + "/get_enabled_edipartners_hpn/", "0", "na")
hints_partner_tmp = hints_partner_tmp.withColumn('lsb_edipartnerfk', hints_partner_tmp.edipartnerpk)
all_hints = filter_commerical_tricare_edipartners(spark, hints_partner_tmp, dataingestion_publish_path, hdfs_scratch).drop('edipartnerpk')
writeparquet(spark, all_hints, hdfs_scratch + "/all_hints", 0, "overwrite")

# COMMAND ----------

# DBTITLE 1,get_patientacct
#joining all_hints with patientaccts to get totalcharges column
all_hints_tmp = readparquet(spark, hdfs_scratch + "/all_hints/", "0", "na")
all_hintsxpa = get_patientacct(spark, pa_path, all_hints_tmp, enddt, bc, admitdate)
writeparquet(spark, all_hintsxpa, hdfs_scratch + "/all_hintsxpa", 0, "overwrite")

# COMMAND ----------

# DBTITLE 1,filter_mincharges_by_partner
#calling common filter_mincharges_by_partner function from process leads
all_hintsxpa_tmp = readparquet(spark, hdfs_scratch + "/all_hintsxpa/", "0", "na")
all_hints_mincharges_by_partner  = filter_mincharges_by_partner(spark, all_hintsxpa_tmp, dataingestion_publish_path, hdfs_scratch)
writeparquet(spark, all_hints_mincharges_by_partner, hdfs_scratch + "/all_hints_mincharges_by_partner", 0, "overwrite")
all_hints_mincharges_by_partner_tmp = readparquet(spark, hdfs_scratch + "/all_hints_mincharges_by_partner/", "0", "na")

# COMMAND ----------

# DBTITLE 1,apply commercial filters
# get hospital attributevalues
edipayers = readparquet(spark, dataingestion_publish_path + "/edipayers/current/*", '0', 'na')
ha = readparquet(spark, dataingestion_publish_path + "/hospitalattributes/current/*", '0', 'na')
hav = readparquet(spark, dataingestion_publish_path + "/hospitalattributevalues/current/*", '0', 'na')
havalues = hospattributes(spark, ha, hav)

hiccolumns = ["hospinsurancecodepk", "hospitalfk", "code", "codedesc", "hospcodestatusfk" ,"mcare", "secondarytomcaid", "edipayerfk" ]
hic = extract_deltalake_data(spark, dataingestion_publish_path + "hospinsurancecodes/current/20991231/", hiccolumns)

patientacctcodescolumns = [ "patientacctifk", "hospitalfk", "insurancecode1", "insurancecode2", "insurancecode3"  ]
patientacctcodes =  extract_deltalake_data(spark, dataingestion_publish_path + "/patientacctscodes/current/20991231/", patientacctcodescolumns )

candidates = getcandidateacctsfilter_ll(spark, all_hints_mincharges_by_partner_tmp, patientacctcodes, havalues, hic, edipayers)
writeparquet(spark, candidates, hdfs_scratch + "/getcandidateacctsfilter_ll", 0, "overwrite")

# COMMAND ----------

# DBTITLE 1,Create temp found coverage data
#get the temp found coverage - creating foundcoverage scratch data to avoid read and write conflicts in code
create_temp_data(spark, dataingestion_publish_path, hdfs_scratch)

# COMMAND ----------

# DBTITLE 1,filter_ifexistsinfc_hints
# Filter out if any leads already in Foundcoverage 
candidates_df = readparquet(spark, hdfs_scratch + "/getcandidateacctsfilter_ll", "0", "na")
filter_ifexistsinfc_hints(spark, candidates_df, dataingestion_publish_path, hdfs_scratch) 
notinfc_df = readparquet(spark, hdfs_scratch + "/filter_ifexistsinfc/", "0", "na")

# COMMAND ----------

# DBTITLE 1,ohi_batchprocess
all_leads_ohi = ohibatchprocess(spark, notinfc_df, dataingestion_publish_path, hdfs_scratch)
writeparquet(spark, all_leads_ohi, hdfs_scratch + "/all_leads_ohi", 0, "overwrite")
all_leads_ohi_tmp = readparquet(spark, hdfs_scratch + "/all_leads_ohi/", "0", "na")

# COMMAND ----------

# DBTITLE 1,besthintselection
besthintselection(spark, all_leads_ohi_tmp, bc, hdfs_scratch)
best_hints = readparquet(spark, hdfs_scratch + "/besthintselection/", "0", "na")

# COMMAND ----------

# DBTITLE 1,FOR BASERUN
patientacctxleads = spark.read.format('delta').load(patientacctxleads_path)
final_hints = best_hints.join(
    patientacctxleads,
    (best_hints.hospitalfk == patientacctxleads.hospitalfk) &
    (patientacctxleads.lsb_edipartnerfk == best_hints.edipartnerfk) &
    (patientacctxleads.patientacctifk == best_hints.patientacctifk),
    how='leftanti'
)
final_hints.write.format('parquet').mode('overwrite').save(hdfs_scratch + '/final_hints')

# COMMAND ----------

if (final_hints.isEmpty()):
    ret_val = 0
else:
    ret_val = 1

dbutils.notebook.exit(ret_val)
