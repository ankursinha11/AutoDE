# Databricks notebook source
# MAGIC %run /Insleads-code/LeadDiscovery/common/createlookup_maxminadmitdays

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from functools import reduce

# COMMAND ----------

dbutils.widgets.text("dataingestion_publish_path","")
dbutils.widgets.getArgument("dataingestion_publish_path")
dataingestion_publish_path= getArgument("dataingestion_publish_path")

dbutils.widgets.text("hintsgeneration_transform_path","")
dbutils.widgets.getArgument("hintsgeneration_transform_path")
hintsgeneration_transform_path= getArgument("hintsgeneration_transform_path")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

print("bc="+str(bc))
print("dataingestion_publish_path="+str(dataingestion_publish_path))
print("hintsgeneration_transform_path="+str(hintsgeneration_transform_path))

print("container="+str(container))
print("storageaccount="+str(storageaccount))
print("user="+str(user))


if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

dataingestion_publish_path = baseurl+dataingestion_publish_path
hintsgeneration_transform_path = baseurl+hintsgeneration_transform_path

hdfs_output_edipartnerfk=hintsgeneration_transform_path+'/minmaxbyedipartnerfk/'+bc+'/'
hdfs_input=dataingestion_publish_path
hdfs_output=hintsgeneration_transform_path+'/minmaxbyhospital/'+bc+'/'

print("--------------------------------------------------------------------------------")
print("bc="+str(bc))

print("dataingestion_publish_path="+str(dataingestion_publish_path))
print("hintsgeneration_transform_path="+str(hintsgeneration_transform_path))

print("container="+str(container))
print("storageaccount="+str(storageaccount))
print("user="+str(user))

print("--------------------------------------------------------------------------------")
print("hdfs_output_edipartnerfk="+str(hdfs_output_edipartnerfk))
print("hdfs_input="+str(hdfs_input))
print("hdfs_output="+str(hdfs_output))

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# MAGIC %md
# MAGIC ##Hints Generation: create admit date lookup

# COMMAND ----------

# using python util to read the arquet
hp = readparquet(spark, hdfs_input + "/hospitals/current/*/", '0', 'na')
hp = hp.filter(col("active") == '1')
hpn = readparquet(spark, hdfs_input + "/hospitalprovidernums/current/*/", '0', 'na')
hpn = hpn.filter(col("enabled") == '1')
edis = readparquet(spark, hdfs_input + "/edisubmitters/current/*/", '0', 'na')
ep = readparquet(spark, hdfs_input + "/edipartners/current/*/", '0', 'na')
epp = readparquet(spark, hdfs_input + "/edipartnertype/current/*/", '0', 'na')
epp = epp.filter((col("iscommercial") == '1') | (col("istricare") == '1'))
edienv = readparquet(spark, hdfs_input + "/edipartner270settings/current/*/", '0', 'na')
epso = readparquet(spark, hdfs_input + "/edipartnersubmittersoverrides/current/*/", '0', 'na')
ephsso = readparquet(spark, hdfs_input + "/edipartnerhospital270settingsoverrides/current/*/", '0', 'na')

#Get minmaxbyedipartnerfk
a = createlookupbypartnerfk(spark, hp, hpn, edis, ep, edienv, epso, ephsso,epp)
# using python util to write out
writeparquet(spark, a, hdfs_output_edipartnerfk,1, "overwrite")
