# Databricks notebook source
#   Divya Vandana
#   09/09/2024
#   This pyspark script is used to get candidate accounts for

# COMMAND ----------

def getpatientacctswithadmitdt_hints(spark, patientaccts, hospadmitdate):
    patientaccts.createOrReplaceTempView("pa")
    hospadmitdate.createOrReplaceTempView("ha")
        #if the admitdate is in the future, check if it is within 30 days of the immediate future
    paccts = spark.sql("""
                      SELECT pa.*
                      FROM pa inner join ha 
                      on CAST(pa.hospitalfk AS BIGINT) = CAST(ha.hospitalfk AS BIGINT) 
                      AND CAST(pa.lsb_edipartnerfk AS BIGINT) = CAST(ha.edipartnerpk AS BIGINT)
                      WHERE
                      (   (pa.admitdate between date_sub(current_date(),int(ha.maxsearchduration)) and date_sub(current_date(),int(ha.minsearchduration)))
                       OR (pa.admitdate between current_date() and date_add(current_date(),30))
                      )""")
    return paccts

# COMMAND ----------

#getting the pa_acct 
def get_patientacct(spark, pa_path, df, enddt, bc, hospadmitdate):
    pacctscols = ["patientacctipk", "hospitalfk", "firstname", "middlename", "lastname", "ssn", "dob", "gender","state", "admitdate", "referraldate", "dischargedate", "medicalrecnum", "clusteredacctfk", "totalcharges","demographicsupdatedate", "medicarehic", "medicaidnum", "trgupdatedate", "currentbalance"]

    allpatientaccts = extract_deltalake_data(spark, pa_path, pacctscols)
    allpatientaccts = allpatientaccts.withColumn('totalcharges', allpatientaccts.totalcharges.cast("decimal(32,4)"))
    allpatientaccts = allpatientaccts.withColumn('patientacctipk', allpatientaccts.patientacctipk.cast("long"))
    allpatientaccts = allpatientaccts.filter(allpatientaccts.totalcharges > 0)
    

    #Join HintFC and allpatientaccts  
    hintfcxpa = df.join(
        allpatientaccts,
        (df.hospitalfk == allpatientaccts.hospitalfk) &
        (df.patientacctifk == allpatientaccts.patientacctipk)
        ).drop(allpatientaccts.hospitalfk,allpatientaccts.patientacctipk)

    # apply admit date filters for patientaccts
    allpatientaccts = getpatientacctswithadmitdt_hints(spark, hintfcxpa, hospadmitdate) 

    return allpatientaccts

# COMMAND ----------

# Map edi_payer to edi_partner and filter out disabled partners
def get_edipartner(spark, df, edipartners):
    df_partner = df.join(edipartners,(df.edipayerfk == edipartners.edipayerfk),"inner").filter("isenabledflag='1'").select(df['*'],edipartners.edipartnerpk).dropDuplicates()
    return df_partner

# COMMAND ----------

def filter_ifexistsinfc_hints(spark, all_hints, hdfs_input, hdfs_scratch):
    hdfs_scratch_fc_data = hdfs_scratch + "/tmpdata/foundcoverage"
    fc = readparquet(spark, hdfs_scratch_fc_data, "0", "na")

    all_hints_c = all_hints.join(fc, (all_hints.hospitalfk == fc.hospitalfk) & \
                                 (all_hints.lsb_edipartnerfk == fc.edipartnerfk) & \
                                 (all_hints.patientacctifk == fc.patientacctifk) , "leftanti").select(all_hints['*'])
    
    all_leads_hash = all_hints_c.withColumn('demohash', hash(concat_ws(":", upper(trim(all_hints_c.firstname)), upper(trim(all_hints_c.lastname)),trim(all_hints_c.ssn), trim(all_hints_c.dob), upper(trim(all_hints_c.state)))))

    writeparquet(spark, all_leads_hash, hdfs_scratch+'/filter_ifexistsinfc', 0, "overwrite")

    return all_leads_hash

# COMMAND ----------

def besthintselection(spark, all_leads, bc, hdfs_scratch):
    lf1 = all_leads
    lf1.createOrReplaceTempView('lf1')
    final = spark.sql("""
    SELECT
           patientacctifk,
           hospitalfk,
           hospitalname,
           lsb_edipartnerfk AS edipartnerfk,
           'InProgress' AS PatientAcctXLeadStatus,
           GETDATE() AS PatientAcctXLeadStatusUpdateDate,
           firstname,
           lastname,
           middlename,
           dob,
           ssn,
           gender,
           state,
           '' AS TraditionalIdentifier,
           admitdate,
           dischargedate,
           '' AS CoverageID,
           '' AS FC_SSN,
           '' AS FC_DOB,
           '' AS FC_LastName,
           '' AS FC_FirstName,
           clusteredacctfk,
           totalcharges,
           npi,
           0 AS UsingFamilyDataFlag,
           demohash AS DemographicsHash,
           '' AS LastAbiETLStartDate,
           edidatasourcefk,
           updatedate,
           CAST(hintfoundcoveragepk AS VARCHAR(50)) AS EDIDataSourceTableKey,
           '' AS AssociationSource,
           ROW_NUMBER() OVER (PARTITION BY hospitalfk,patientacctifk,lsb_edipartnerfk 
           ORDER BY CAST(updatedate AS TIMESTAMP) DESC,demohash DESC) AS rn
    FROM lf1
    """)
    final = final.filter("rn = 1").drop("rn","updatedate")
    writeparquet(spark, final, hdfs_scratch+'/besthintselection', 0, "overwrite")

    return final

# COMMAND ----------

def get_enabled_edipartners_hpn(spark, df, hpn):
    enabled_edipartners = df.join(hpn, (df.hospitalfk == hpn.hospitalfk) &(df.edipartnerpk == hpn.edipartnerfk)).filter(hpn.enabled=='1').select(df['*']).dropDuplicates()
    writeparquet(spark, enabled_edipartners, hdfs_scratch+'/get_enabled_edipartners_hpn', 0, "overwrite")

# COMMAND ----------

def filter_admitdt_partner_hints(spark, all_leads, hdfs_admitdt_path):
    hospadmitdate = extract_parquet_data(spark, hdfs_admitdt_path)
    
    hospadmitdate = hospadmitdate.withColumn('maxsearchduration',hospadmitdate.maxsearchduration.cast(IntegerType())).withColumn('minsearchduration',hospadmitdate.minsearchduration.cast(IntegerType()))
    all_leads.createOrReplaceTempView("leads")
    hospadmitdate.createOrReplaceTempView("ha")
    leads = spark.sql("""
                      SELECT pa.*
                      FROM leads pa inner join ha ON pa.hospitalfk = ha.hospitalfk
                        AND pa.lsb_edipartnerfk = ha.edipartnerpk
                      WHERE
                      (   (pa.admitdate between date_sub(current_date(),ha.maxsearchduration) and date_sub(current_date(),ha.minsearchduration))
                       OR (pa.admitdate between current_date() and date_add(current_date(),366))
                      )""")
    return leads
