# Databricks notebook source
# DBTITLE 1,Input Parameters
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("hints_input","")
dbutils.widgets.getArgument("hints_input")
hints_input= getArgument("hints_input")

dbutils.widgets.text("hints_output","")
dbutils.widgets.getArgument("hints_output")
hints_output= getArgument("hints_output")

# COMMAND ----------

# DBTITLE 1,Storage Account Access
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na':
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

# DBTITLE 1,full paths
hints_input = baseurl + hints_input + '/'+ bc + '/final_hints'
hints_output = baseurl + hints_output
print("hints_input:", hints_input)
print("hints_output:", hints_output)

# COMMAND ----------

# DBTITLE 1,Import
from pyspark.sql.types import *
from pyspark.sql.functions import *

# COMMAND ----------

# DBTITLE 1,Input Data and Adding Breadcrumb
new_hints = spark.read.parquet(hints_input).dropDuplicates()
new_hints = new_hints.withColumn("breadcrumb", lit(bc))

# COMMAND ----------

# DBTITLE 1,Append new hints to patientacctsxhints

new_hints.write.mode("append").format("delta").save(hints_output)
