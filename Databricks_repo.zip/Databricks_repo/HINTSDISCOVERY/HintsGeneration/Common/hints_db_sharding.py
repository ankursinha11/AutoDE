# Databricks notebook source
dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("hints_sqoop_out","")
dbutils.widgets.getArgument("hints_sqoop_out")
hints_sqoop_out= getArgument("hints_sqoop_out")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("edipayer_config_file", "")
dbutils.widgets.getArgument("edipayer_config_file")
edipayer_config_file = getArgument("edipayer_config_file")

dbutils.widgets.text("maxRecordsPerFile", "")
dbutils.widgets.getArgument("maxRecordsPerFile")
maxRecordsPerFile = getArgument("maxRecordsPerFile")

dbutils.widgets.text("workflow_name", "")
dbutils.widgets.getArgument("workflow_name")
workflow_name = getArgument("workflow_name")

dbutils.widgets.text("dataingestion_publish_path", "")
dbutils.widgets.getArgument("dataingestion_publish_path")
dataingestion_publish_path = getArgument("dataingestion_publish_path")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

#setting the baseurl
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user
print("baseurl: ", baseurl)


#setting the edi_payer_baseurl
edi_payer_baseurl ='abfss://edi-payer-leads@'+storageaccount+'.dfs.core.windows.net'

print("edi_payer_baseurl:", edi_payer_baseurl)

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
import uuid

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

# Read the config file to get the shards
config_path = baseurl + dataingestion_publish_path + "/partnerxrefconfig/current/20991231/"
configcols = ["edipartnerfk", "databaseshardname"]

df_shard_config = extract_deltalake_data(spark,config_path, configcols)

#Output shards path
shard_path = edi_payer_baseurl + "/shards_inprogress/"

# COMMAND ----------

#Read the hints file
hints = spark.read.parquet(baseurl+hints_sqoop_out+bc +'/final_hints')

hints = hints.withColumn("uniqueid", concat_ws("_",hints.hospitalfk, hints.patientacctifk, expr("uuid()")))

# COMMAND ----------

#Read the patientaccts
pa_path = baseurl + dataingestion_publish_path + "/patientaccts/current/20991231/"

pacctscols = ["patientacctipk", "hospitalfk", "medicarehic", "medicaidnum"]
pa = extract_deltalake_data(spark,pa_path, pacctscols)

# COMMAND ----------

#Join hints and pa
hints_pa_join_df = hints.join(pa, (hints.patientacctifk == pa.patientacctipk) & (hints.hospitalfk == pa.hospitalfk), "left").select(hints["*"], pa["medicarehic"],pa["medicaidnum"])

hints_pa_join_df.createOrReplaceTempView('hints_pa_join_df')

# COMMAND ----------

bc_value = bc

hints_df = spark.sql(f'''
select 
uniqueid,
'{bc_value}' as breadcrumb,
patientacctifk,
hospitalfk, 
hospitalname,
firstname, 
lastname,
middlename, 
dob,
ssn, 
gender, 
state,
admitdate, 
dischargedate, 
clusteredacctfk, 
totalcharges,
npi,
edipartnerfk as lsb_edipartnerfk,
CoverageID as lsb_coverageid,
CAST(NULL AS VARCHAR(1)) AS  lsb_leadsource,
CAST(NULL AS VARCHAR(1)) AS  lsb_xrefsource,
CAST(NULL AS VARCHAR(1)) AS  lsb_firstname,
CAST(NULL AS VARCHAR(1)) AS  lsb_middlename,
CAST(NULL AS VARCHAR(1)) AS  lsb_lastname,
CAST(NULL AS VARCHAR(1)) AS  lsb_gender,
CAST(NULL AS VARCHAR(1)) AS  lsb_dob,
CAST(NULL AS VARCHAR(1)) AS  lsb_ssn,
CAST(NULL AS VARCHAR(1)) AS  lsb_state,
UsingFamilyDataFlag AS usefamilydataflag,
edidatasourcefk,
edidatasourcetablekey, 
associationsource,
medicarehic, 
medicaidnum
from hints_pa_join_df
''')

# COMMAND ----------

join_df = hints_df.join(df_shard_config, hints_df.lsb_edipartnerfk == df_shard_config.edipartnerfk, "left").select(hints_df["*"], df_shard_config["databaseshardname"])

join_df2 = join_df.withColumn("databaseshardname", coalesce(col("databaseshardname"), lit("default_shard")))\
                  .withColumn("workflow_name", lit(workflow_name))\
                  .withColumn("bc", lit(bc+"-HT"))

# COMMAND ----------

import pyspark.sql.functions as F
from pyspark.sql.types import IntegerType, TimestampType, DecimalType, LongType

join_df3 = join_df2.withColumn("patientacctifk", F.col("patientacctifk").cast(LongType()))\
	.withColumn("hospitalfk", F.col("hospitalfk").cast(IntegerType()))\
  .withColumn("dob", F.to_timestamp(F.col("dob")))\
	.withColumn("admitdate", F.col("admitdate").cast(TimestampType()))\
	.withColumn("dischargedate", F.col("dischargedate").cast(TimestampType()))\
	.withColumn("clusteredacctfk", F.col("clusteredacctfk").cast(IntegerType()))\
	.withColumn("totalcharges", F.col("totalcharges").cast(DecimalType(38,2)))\
	.withColumn("lsb_edipartnerfk", F.col("lsb_edipartnerfk").cast(IntegerType()))\
	.withColumn("lsb_dob", F.col("lsb_dob").cast(TimestampType()))\
	.withColumn("edidatasourcefk", F.col("edidatasourcefk").cast(IntegerType()))

# COMMAND ----------

join_df3.coalesce(1)\
        .write.option("maxRecordsPerFile", maxRecordsPerFile)\
        .mode("overwrite")\
        .partitionBy("databaseshardname","workflow_name","bc")\
        .parquet(shard_path)

# COMMAND ----------


