# Databricks notebook source
import sys
import os
import subprocess
from pyspark.storagelevel import StorageLevel
from pyspark.sql import *
from pyspark.sql.functions import *
from pyspark.sql.types import *
from datetime import datetime

# COMMAND ----------

# SET parameters#
dbutils.widgets.text("staging_output","")
dbutils.widgets.getArgument("staging_output")
staging_output= getArgument("staging_output")

dbutils.widgets.text("publish_policyhelper_output", "")
dbutils.widgets.getArgument("publish_policyhelper_output")
publish_policyhelper_output= getArgument("publish_policyhelper_output")

# dbutils.widgets.text("bc", "")
# dbutils.widgets.getArgument("bc")
# bc = getArgument("bc")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

hdfs_repo_staging = baseurl + staging_output 
hdfs_repo_publish = baseurl + publish_policyhelper_output
print(hdfs_repo_staging)
print(hdfs_repo_publish)

# COMMAND ----------

try:
    staging_path = dbutils.fs.ls(hdfs_repo_staging) 
    if(len(staging_path) > 0):
        dbutils.fs.rm(hdfs_repo_publish, True)
        dbutils.fs.mv(hdfs_repo_staging, hdfs_repo_publish, True)
    print("Migration from Staging to Publish")
except Exception as e:
    if 'java.io.FileAlreadyExistsException' in str(e):
        print('The file does not exists in the directory')