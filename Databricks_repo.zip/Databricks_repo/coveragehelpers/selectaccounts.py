# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("hdfs_repo_input","")
dbutils.widgets.getArgument("hdfs_repo_input")
hdfs_repo_input= getArgument("hdfs_repo_input")

dbutils.widgets.text("hdfs_input","")
dbutils.widgets.getArgument("hdfs_input")
hdfs_input= getArgument("hdfs_input")

dbutils.widgets.text("hdfs_output","")
dbutils.widgets.getArgument("hdfs_output")
hdfs_output= getArgument("hdfs_output")

dbutils.widgets.text("hdfs_trackhelper_input","")
dbutils.widgets.getArgument("hdfs_trackhelper_input")
hdfs_trackhelper_input= getArgument("hdfs_trackhelper_input")


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

hdfs_input = baseurl+hdfs_input
hdfs_repo_input = baseurl+hdfs_repo_input 
hdfs_output = baseurl + hdfs_output+ bc + '/'
hdfs_trackhelper_input = baseurl + hdfs_trackhelper_input + bc + '/'
print(hdfs_input)
print(hdfs_repo_input)
print(hdfs_output)
print(hdfs_trackhelper_input)

# COMMAND ----------

helperRepo = spark.read.parquet(hdfs_repo_input)

# hosppartnerlst = spark.read.parquet(hdfs_input+"/hpdhospitalpartnerlastrespstatus/current/*")

foundcoverage= extract_deltalake_data(spark, hdfs_input+"/foundcoverage/current/20991231").select("patientacctifk","hospitalfk","edipartnerfk","coverageid")

hospitalprovidernums = spark.read.parquet(hdfs_input+"/hospitalprovidernums/current/*").select("hospitalfk","edipartnerfk","enabled","edi270generateinqueueflag") \
                                                                                        .filter((col('enabled') == '1' ))

trackhelper = spark.read.parquet(hdfs_trackhelper_input)   

trackhelper.createOrReplaceTempView("trackhelper")
# hosppartnerlst.createOrReplaceTempView("hosppartnerlst")
helperRepo.createOrReplaceTempView("helperrepo")

hp =helperRepo.alias("hp")

fc = foundcoverage.alias('fc')
hpn = hospitalprovidernums.alias('hpn')


## Just get the oner patientacct with max(Admitdate) or max(lastrespreceiveddate) for a demohash-hospitalfk combination

dt = spark.sql("""
SELECT *
FROM ( 
  SELECT h.*,
     ROW_NUMBER() OVER (PARTITION BY hr.demohash,h.hcsystemfk ORDER BY to_timestamp(hr.admitdate,"yyyy-MM-dd HH:mm:ss.SSS") DESC) AS rownum
     FROM trackhelper h inner join helperrepo hr on hr.hospitalfk=h.hospitalfk and hr.patientacctifk=h.patientacctifk
                        where h.visible=1 and h.active=1  
  ) a
  where rownum=1""")

dt=dt.alias("dt")
dt = dt.join(hp,(dt.patientacctifk == hp.patientacctifk) & (dt.hospitalfk==hp.hospitalfk),"inner")\
       .select("hp.patientacctpk","hp.patientacctifk","hp.hospitalfk","hp.admitdate","hp.dischargedate","hp.firstname","hp.middlename","hp.lastname","hp.dob","hp.ssn","hp.gender","hp.state","hp.clusteredacctfk","hp.demographicschecksum","hp.demographicsupdatedate","hp.coverageid","dt.edipartnerfk","hp.repodate","dt.lastgenerateddate","dt.edisourcedateforpasscomparison")
      
# dt.createOrReplaceTempView("dt")

# dt = spark.sql("""select hp.patientacctpk,hp.patientacctifk,hp.hospitalfk,hp.admitdate,hp.dischargedate,hp.firstname,hp.middlename,hp.lastname,hp.dob,hp.ssn,hp.gender,hp.state,hp.clusteredacctfk,hp.demographicschecksum,hp.demographicsupdatedate,hp.coverageid,dt.edipartnerfk,hp.repodate,dt.lastgenerateddate,dt.edisourcedateforpasscomparison from dt inner join helperrepo hp on dt.patientacctifk = hp.patientacctifk and dt.hospitalfk=hp.hospitalfk """)

joined_dt_fc = dt.join(fc,(dt.patientacctifk == fc.patientacctifk) & \
                          (dt.hospitalfk == fc.hospitalfk) & \
                          (dt.edipartnerfk == fc.edipartnerfk) & \
                          (dt.coverageid == fc.coverageid)
                    ,"left_anti") \
              .select(dt["*"])

jdf = joined_dt_fc.alias('jdf')

joined_dt_vpn_fc = jdf.join(hpn,(jdf.hospitalfk == hpn.hospitalfk) & \
                                         (jdf.edipartnerfk  == hpn.edipartnerfk) \
                                             ) \
                               .select(jdf.patientacctpk,jdf.patientacctifk,jdf.hospitalfk,jdf.admitdate,jdf.dischargedate,jdf.firstname,jdf.middlename,jdf.lastname,\
                                       jdf.dob,jdf.ssn,jdf.gender,jdf.state,jdf.clusteredacctfk,jdf.demographicschecksum,jdf.demographicsupdatedate,jdf.coverageid,dt.edipartnerfk,\
                                       jdf.repodate,dt.lastgenerateddate,dt.edisourcedateforpasscomparison)

joined_dt_vpn_fc.dropDuplicates().repartition(1).write.mode("overwrite").option("nullValue",None).option("emptyValue",None).format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="\x01").save(hdfs_output)
# joined_dt_vpn_fc.dropDuplicates().repartition(1).write.mode("overwrite").format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="\x01").save(hdfs_output)
