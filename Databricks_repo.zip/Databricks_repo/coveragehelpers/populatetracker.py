# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("hdfs_repo_input","")
dbutils.widgets.getArgument("hdfs_repo_input")
hdfs_repo_input= getArgument("hdfs_repo_input")

dbutils.widgets.text("hdfs_input","")
dbutils.widgets.getArgument("hdfs_input")
hdfs_input= getArgument("hdfs_input")

dbutils.widgets.text("hdfs_output","")
dbutils.widgets.getArgument("hdfs_output")
hdfs_output= getArgument("hdfs_output")


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.types import *
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark import SparkContext
from pyspark.conf import SparkConf

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

hdfs_input = baseurl+hdfs_input
hdfs_repo_input = baseurl+hdfs_repo_input
hdfs_output = baseurl + hdfs_output + bc + '/'
print(hdfs_input)
print(hdfs_repo_input)
print(hdfs_output)

# COMMAND ----------

repo_cols=["patientacctifk","hospitalfk","admitdate",'demographicsupdatedate',"repodate","coveragetype","demohash","coverageid"]

helperrepo = spark.read.parquet(hdfs_repo_input).select(repo_cols)
helperrepo = helperrepo.where( (datediff(current_date(),helperrepo.admitdate.cast(TimestampType())) < 1095 ) & (helperrepo.coveragetype == "medicare"))

# Get Hospital and PASS data

hospital = spark.read\
                .parquet(hdfs_input +"/hospitals/current/*")\
                .select("hospitalpk","hcsystemfk","medicarehetsonlyflag","enablemedicaresearch","visible","active")

#pacctstatestatus = common_util.extract_deltalake_data(spark, hdfs_input +"/patientacctstatestatus/current/20991231/").select("patientacctifk","hospitalfk","edipartnerfk","lastgenerateddate","status")

pacctstatestatus = extract_deltalake_data(spark, hdfs_input +"/patientacctstatestatus/current/20991231/").select("patientacctifk","hospitalfk","edipartnerfk","lastgenerateddate","status")

#pacctstatestatus = spark.read.parquet(hdfs_input +"/patientacctstatestatus/current/20991231/").selectExpr("patientacctifk","hospitalfk","edipartnerfk","lastgenerateddate","status").dropDuplicates()


hp = helperrepo.alias('hp')
pas = pacctstatestatus.alias('pas')
h = hospital.alias('h')

# Step 1 : Join helperRepo with hospitals to get edipartnerfk 
repohetsvsdish = hp.join(h,(h.hospitalpk == hp.hospitalfk))\
                   .select(hp.patientacctifk,hp.hospitalfk,hp.demohash,h.hcsystemfk, \
                           hp.demographicsupdatedate,hp.repodate,h.medicarehetsonlyflag,h.active,h.visible,hp.coverageid)

repohetsvsdish = repohetsvsdish.withColumn("edipartnerfk", when((col("medicarehetsonlyflag") == 0) ,lit(92)).otherwise(lit(82)))


## Step 2 : Join repohetsvsdhis to pass table to get lastgenerated date
rp = repohetsvsdish.alias('rp')

repotrack = rp.join(pas,\
                   (pas.patientacctifk==rp.patientacctifk) &\
                   (pas.hospitalfk==rp.hospitalfk) &\
                   (pas.edipartnerfk==rp.edipartnerfk),"left")\
              .select(\
                      rp.patientacctifk,rp.hcsystemfk,rp.hospitalfk,rp.edipartnerfk,rp.repodate,rp.active,rp.visible,rp.coverageid, \
                      rp.demographicsupdatedate,pas.lastgenerateddate,pas.status.alias("passtatus"),rp.demohash\
                     )
repotrack=repotrack.withColumn("lastgenerateddate",date_format("lastgenerateddate","yyyy-MM-dd HH:mm:ss.SSS"))

repotrack.createOrReplaceTempView('rt')

# Step 3 : Get row no by demohash

dt = spark.sql("SELECT h.*,\
     ROW_NUMBER() OVER (PARTITION BY h.demohash,h.hcsystemfk order by lastgenerateddate desc) AS rowno\
     FROM rt h")


cond_2 = when(\
               col("demographicsupdatedate").cast(TimestampType())>col("lastgenerateddate").cast(TimestampType())\
               ,lit(1)\
             )\
         .otherwise(lit(0))
cond_1 = when(\
              col("repodate").cast(TimestampType())>col("lastgenerateddate").cast(TimestampType())\
              ,lit(1))\
         .otherwise(cond_2)
cond_0 = when(\
               col("lastgenerateddate").cast(TimestampType()).isNull()\
               ,lit(1))\
         .otherwise(cond_1)

repotrack=dt.withColumn("markforselection",cond_0)


## Get the distinct demohash which have been sent before or already got generated

demohash = repotrack.filter("rowno==1 and markforselection == 0").dropDuplicates().select("demohash")

demohash.createOrReplaceTempView("demohash")
repotrack.createOrReplaceTempView("repotrack")

trackhelper = spark.sql("select r.* from repotrack r left join demohash d on d.demohash=r.demohash \
                         where d.demohash is null")

#trackhelper.show(5,False)
## filter out the once which are not marked for selection

trackhelper=trackhelper.where(trackhelper.markforselection==1)


cond_2 = when(\
               (col("demographicsupdatedate").cast(TimestampType())>col("repodate").cast(TimestampType()))\
               ,col("demographicsupdatedate").cast(TimestampType())\
             )\
         .otherwise(col("repodate").cast(TimestampType()))
cond_1 = when(\
               (col("lastgenerateddate").cast(TimestampType())>cond_2)\
               ,col("lastgenerateddate").cast(TimestampType())\
             )\
         .otherwise(cond_2)
cond_0 = when(\
               col("lastgenerateddate").cast(TimestampType()).isNull()\
               ,cond_2\
             )\
         .otherwise(cond_1)

trackhelper = trackhelper.withColumn("edisourcedateforpasscomparison",date_format(cond_0,"yyyy-MM-dd HH:mm:ss.SSS"))
trackhelper.dropDuplicates().repartition(100).write.mode("overwrite").parquet(hdfs_output)
