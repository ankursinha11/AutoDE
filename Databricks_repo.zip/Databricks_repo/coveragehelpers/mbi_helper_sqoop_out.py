# Databricks notebook source
from pyspark.sql.functions import *

# COMMAND ----------

dbutils.widgets.text("tablename","")
dbutils.widgets.getArgument("tablename")
tablename= getArgument("tablename")

dbutils.widgets.text("path_conn_file", "")
dbutils.widgets.getArgument("path_conn_file")
path_conn_file= getArgument("path_conn_file")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("hdfs_mbi_sqoop_out","")
dbutils.widgets.getArgument("hdfs_mbi_sqoop_out")
hdfs_mbi_sqoop_out= getArgument("hdfs_mbi_sqoop_out")

dbutils.widgets.text("icddb","")
dbutils.widgets.getArgument("icddb")
icddb= getArgument("icddb")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

# COMMAND ----------

# spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
import os

# COMMAND ----------

mbi_schema=StructType([StructField('patientacctpk', StringType(), True),
                    StructField('patientacctifk', StringType(), True),
                    StructField('hospitalfk', IntegerType(), True),
                    StructField('admitdate', StringType(), True), 
                    StructField('dischargedate', StringType(), True), 
                    StructField('firstname', StringType(), True), 
                    StructField('middlename', StringType(), True), 
                    StructField('lastname', StringType(), True), 
                    StructField('dob', StringType(), True), 
                    StructField('ssn', StringType(), True), 
                    StructField('gender', StringType(), True), 
                    StructField('state', StringType(), True), 
                    StructField('clusteredacctfk', StringType(), True), 
                    StructField('demographicschecksum', StringType(), True), 
                    StructField('demographicsupdatedate', StringType(), True), 
                    StructField('coverageid', StringType(), True), 
                    StructField('edipartnerfk', IntegerType(), True), 
                    StructField('repodate', StringType(), True), 
                    StructField('lastgenerateddate', StringType(), True), 
                    StructField('edisourcedateforpasscomparison', StringType(), True)])

# COMMAND ----------

hdppacctstobegeneratedmcare= spark.read.csv(baseurl+hdfs_mbi_sqoop_out+bc, sep="\x01", schema=mbi_schema).select ("patientacctifk","hospitalfk","edipartnerfk","firstname","lastname","middlename","dob","ssn","gender","state","admitdate","dischargedate","coverageid","clusteredacctfk")
hdppacctstobegeneratedmcare.createOrReplaceTempView('hdppacctstobegeneratedmcare')

# COMMAND ----------

hdppacctstobegeneratedmcare = spark.sql('''
select patientacctifk,
hospitalfk, 
CAST(NULL AS VARCHAR(1)) AS HospitalName,
edipartnerfk, 
'InProgress' AS PatientAcctXLeadStatus, 
CAST(NULL AS VARCHAR(1)) AS PatientAcctXLeadStatusUpdateDate, 
firstname, 
lastname,
middlename, 
dob,
ssn, 
gender, 
state,
CAST(NULL AS VARCHAR(1)) AS TraditionalIdentifier, 
admitdate, 
dischargedate, 
coverageid, 
CAST(NULL AS VARCHAR(1)) AS FC_SSN, 
CAST(NULL AS VARCHAR(1)) AS FC_DOB, 
CAST(NULL AS VARCHAR(1)) AS FC_LastName, 
CAST(NULL AS VARCHAR(1)) AS FC_FirstName, 
clusteredacctfk, 
CAST(NULL AS VARCHAR(1)) AS TotalCharges,
CAST(NULL AS VARCHAR(1)) AS NPI,
CAST(NULL AS VARCHAR(1)) AS UsingFamilyDataFlag,
CAST(NULL AS binary) AS DemographicsHash,
CAST(NULL AS VARCHAR(1)) AS LastAbiETLStartDate, 
'53' as EDIDatasourceFK,
CAST(NULL AS VARCHAR(1)) AS EDIDataSourceTableKey, 
CAST(NULL AS VARCHAR(1)) AS AssociationSource,
current_timestamp as CreateDate,
CAST(NULL AS VARCHAR(1)) AS CreatedBy, 
current_timestamp UpdateDate,
CAST(NULL AS VARCHAR(1)) AS UpdatedBy,
'0' as WorkflowModifierMask,
CAST(NULL AS VARCHAR(1)) AS PayerConnectQueueName 
from hdppacctstobegeneratedmcare
''')

# COMMAND ----------

hdppacctstobegeneratedmcare.write.format('jdbc').mode('append').option('driver', 'com.microsoft.sqlserver.jdbc.SQLServerDriver').option \
        ('url', path_conn_file).option('dbtable', icddb+tablename).save()