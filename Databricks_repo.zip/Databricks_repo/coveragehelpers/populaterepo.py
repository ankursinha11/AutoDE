# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

# dbutils.widgets.text("bc","")
# dbutils.widgets.getArgument("bc")
# bc= getArgument("bc")

dbutils.widgets.text("hdfs_data_input","")
dbutils.widgets.getArgument("hdfs_data_input")
hdfs_data_input= getArgument("hdfs_data_input")

dbutils.widgets.text("gmrn_data_input","")
dbutils.widgets.getArgument("gmrn_data_input")
gmrn_data_input= getArgument("gmrn_data_input")

dbutils.widgets.text("hdfs_repo_input","")
dbutils.widgets.getArgument("hdfs_repo_input")
hdfs_repo_input= getArgument("hdfs_repo_input")

dbutils.widgets.text("hdfs_repo_output","")
dbutils.widgets.getArgument("hdfs_repo_output")
hdfs_repo_output= getArgument("hdfs_repo_output")

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

hdfs_repo_input = baseurl + hdfs_repo_input
hdfs_data_input = baseurl + hdfs_data_input
hdfs_repo_output = baseurl + hdfs_repo_output
gmrn_data_input = baseurl + gmrn_data_input
print("hdfs_repo_input: ",hdfs_repo_input)
print("hdfs_data_input: ",hdfs_data_input)
print("hdfs_repo_output: ",hdfs_repo_output)
print("gmrn_data_input:", gmrn_data_input )

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

# Created By:Supriya
# Created On:11/07/2019
# Description: Helper repo update script

# from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
from delta.tables import *
# import sys
import datetime 


# import common_util


spark = SparkSession.builder.appName("Coverage Helper Repo").getOrCreate()


#STEP 1 - read current repo 
#param coveragesource=medicare
repo_schema=StructType([
        StructField('patientacctpk',StringType()),
        StructField('patientacctifk',StringType()),
        StructField('admitdate',StringType()),
        StructField('dischargedate',StringType()),
        StructField('firstname',StringType()),
        StructField('middlename',StringType()),
        StructField('lastname',StringType()),
        StructField('dob',StringType()),
        StructField('ssn',StringType()),
        StructField('gender',StringType()),
        StructField('state',StringType()),
        StructField('clusteredacctfk',StringType()),
        StructField('demographicschecksum',StringType()),
        StructField('demographicsupdatedate',StringType()),
        StructField('demohash',StringType()),
        StructField('coverageid',StringType()),
        StructField('repodate',StringType()),
        StructField('coveragetype',StringType()),
        StructField('hospitalfk',IntegerType())
])

repo_cols=["patientacctpk","patientacctifk","hospitalfk","admitdate","dischargedate","firstname","middlename","lastname","dob","ssn","gender","state","clusteredacctfk","demographicschecksum","demographicsupdatedate","demohash","repodate","coverageid","coveragetype"]


try:
  repo=spark.read.parquet(hdfs_repo_input).select(repo_cols)
except:
  repo=spark.createDataFrame([],repo_schema).select(repo_cols)


repo = repo.where(repo.coveragetype == "medicare")
#repo.show()
#STEP 2 - read current data

pa_cols = ["patientacctpk","patientacctipk","hospitalfk","admitdate",\
           "dischargedate","firstname","middlename","lastname","dob",\
           "ssn","gender","state","clusteredacctfk","demographicschecksum",\
           "demographicsupdatedate","medicarehic"\
          ]

#candidate patientaccts
pa = extract_deltalake_data(spark,hdfs_data_input +"/patientaccts/current/20991231/").select(pa_cols)

pa = pa.where( datediff(current_date(),pa.admitdate.cast(TimestampType())) < 1095 )

#this is to handle deletes from te repo for patentacct demographic change where 
pa_select = pa.select("hospitalfk","patientacctipk","medicarehic")


pa_1=pa.where(pa.medicarehic.rlike("^[1-9][AC-HJKMNPQRT-Y][0-9AC-HJKMNPQRT-Y][0-9][AC-HJKMNPQRT-Y][0-9AC-HJKMNPQRT-Y][0-9][AC-HJKMNPQRT-Y][AC-HJKMNPQRT-Y][0-9][0-9]$"))

pa_2=pa_1.withColumnRenamed("medicarehic","coverageid")
ghic=spark.read.parquet(gmrn_data_input+"/globalmrnxhospinsurancecodes/current/*").select("hospitalfk","patientacctifk","inspolicyid")
newcols = ["patientacctpk","patientacctipk",pa["hospitalfk"],"admitdate","dischargedate","firstname","middlename","lastname",\
           "dob","ssn","gender","state","clusteredacctfk","demographicschecksum","demographicsupdatedate"] + [ghic["inspolicyid"]]

#candidate ghic data
ghic_1 = ghic\
           .join(pa,((pa.patientacctipk==ghic.patientacctifk) & (pa.hospitalfk==ghic.hospitalfk)),"inner")\
           .where(ghic.inspolicyid.rlike("^[1-9][AC-HJKMNPQRT-Y][0-9AC-HJKMNPQRT-Y][0-9][AC-HJKMNPQRT-Y][0-9AC-HJKMNPQRT-Y][0-9][AC-HJKMNPQRT-Y][AC-HJKMNPQRT-Y][0-9][0-9]$"))\
           .select(newcols)

ghic_2 = ghic_1\
           .withColumnRenamed("inspolicyid","coverageid")
final = pa_2.union(ghic_2).dropDuplicates()


final = final\
           .withColumn("demohash",hash(concat_ws(":", lower(trim(final.coverageid)),lower(trim(final.firstname)),lower(trim(final.lastname)),lower(trim(final.dob)),lower(trim(final.ssn)))))\
           .withColumn("coveragetype",lit("medicare"))\
           .withColumnRenamed("patientacctipk","patientacctifk")

final=final.join(repo,((final.hospitalfk==repo.hospitalfk) & (final.patientacctifk==repo.patientacctifk)),"left").select(final['*'],repo.repodate).select(repo_cols)

current_dt=datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]

new_repodate = when( col("repodate").isNull() ,lit(current_dt)).otherwise(col("repodate"))
final = final.withColumn('repodate',new_repodate).select(repo_cols)
final = final.withColumn('repodate',final.repodate.cast(StringType()))

for column in final.columns:
  if (column == "dob" or column == "admitdate" or column == "dischargedate" or column == "demographicsupdatedate"):
    final = final.withColumn(column, date_format(column,"yyyy-MM-dd HH:mm:ss.SSS"))



#STEP 3 - figure out updated/new accounts
#get hospitals in play

hospinplay=final.select("hospitalfk").dropDuplicates()

#getting only those hospitals which we want in the repo
repoadj = repo\
            .join(hospinplay,repo.hospitalfk==hospinplay.hospitalfk,"inner")\
            .select(repo['*'])

#join repo with pa and see if coverageid no longer an MBI to get a list of deletes from the repo
#to_delete = repo.join(pa_select,((repo.hospitalfk==pa_select.hospitalfk) & (repo.patientacctifk==pa_select.patientacctipk)))\
#                .where((pa_select.medicarehic!=repo.coverageid) & (~pa_select.medicarehic.rlike("^[1-9][AC-HJKMNPQRT-Y][0-9AC-HJKMNPQRT-Y][0-9][AC-HJKMNPQRT-Y][0-9AC-HJKMNPQRT-Y][0-9][AC-HJKMNPQRT-Y][AC-HJKMNPQRT-Y][0-9][0-9]$")))\
#               .select(repo['*'])

#repoadj=repoadj.subtract(to_delete)


final.cache()
repoadj.cache()

a=repoadj.subtract(final)
b=final.subtract(repoadj)


#check if there is anything new or updates
try:
  a_count=len(a.head(1))
except:
  a_count=0

try:
  b_count=len(b.head(1))
except:
  b_count=0


#updates to old accounts and/or new accounts 
if b_count>0:
  c=repoadj.intersect(final)
  d=a.union(b).union(c)
  d=d.dropDuplicates()
  window = Window.\
              partitionBy('hospitalfk','patientacctifk').\
              orderBy(d.demographicsupdatedate.cast(TimestampType()).desc())
  repo_out = d.withColumn("rnk",row_number().over(window))

  repo_out = repo_out.filter("rnk=1").drop("rnk")

  repo_out.repartition(5).write.partitionBy("hospitalfk","coveragetype").mode("overwrite").parquet(hdfs_repo_output)
# else:
#   exit()
