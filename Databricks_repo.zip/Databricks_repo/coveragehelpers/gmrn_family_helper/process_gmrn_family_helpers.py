# Databricks notebook source
# DBTITLE 1,Notebook calls
# MAGIC %run /Insleads-code/LeadDiscovery/common/process_leads

# COMMAND ----------

# MAGIC %run /Insleads-code/LeadDiscovery/common/get_candidate_patientaccts

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

# MAGIC %run /Insleads-code/LeadDiscovery/common/createlookup_maxminadmitdays

# COMMAND ----------

# DBTITLE 1,Imports
from pyspark.sql.functions import *
from functools import reduce

# COMMAND ----------

# DBTITLE 1,Input parameters
dbutils.widgets.text("bc","") 
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("catalog_name","")
dbutils.widgets.getArgument("catalog_name")
catalog_name= getArgument("catalog_name")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

# COMMAND ----------

# DBTITLE 1,Storage acccount authentication
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# DBTITLE 1,Baseurl
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 
print(f"base url: {baseurl}")

# COMMAND ----------

# DBTITLE 1,Input Paths
dataingestion_publish_path = baseurl+'/data/dataingestion/publish/'
gmrn_helpers_transform_path = baseurl+'/data/coveragehelpers/transform/gmrn_helpers/'+ bc +'-GF/'
coverage_helpers_publish_path = baseurl+'/data/coveragehelpers/publish/'
minmaxbyhospital_path = gmrn_helpers_transform_path +'minmaxbyhospital/'
minmaxbyedipartnerfk_path = gmrn_helpers_transform_path +'minmaxbyedipartnerfk/'

print(f"dataingestion_publish_path: {dataingestion_publish_path}")
print(f"gmrn_helpers_transform_path: {gmrn_helpers_transform_path}")
print(f"coverage_helpers_publish_path: {coverage_helpers_publish_path}")
print(f"minmaxbyhospital_path: {minmaxbyhospital_path}")
print(f"minmaxbyedipartnerfk_path: {minmaxbyedipartnerfk_path}")

# COMMAND ----------

# DBTITLE 1,read all required data
gmrn_fam_assoc_selected_cols = ['globalmrnifk1','globalmrnifk2','bcupdated']
gmrn_fam_assoc_df = spark.read.table(f"{catalog_name}.cdd.globalmrnfamilyassociations").select(*gmrn_fam_assoc_selected_cols)
gmrn_fam_assoc_delta_df = gmrn_fam_assoc_df.filter(col("bcupdated") == bc).drop("bcupdated")

gmrn_fam_assoc_one_year_df1 = gmrn_fam_assoc_df.withColumn(
    "bcupdated",
    to_date("bcupdated", "yyyyMMdd'T'HH")
)
gmrn_lower_bound_date = date_sub(current_date(), 365) #parameterize in future
gmrn_fam_assoc_one_year_df = gmrn_fam_assoc_one_year_df1.filter(col("bcupdated") > gmrn_lower_bound_date).drop("bcupdated")

lsb_selected_columns = ['_id','identity','hcsystemfk_source','demographics','leadupdatedate']
lsb_df = spark.read.format("delta").load(baseurl+'/data/leadservicebase/publish/served/leadservicebase/').select(*lsb_selected_columns)
lsb_df = lsb_df.filter((lsb_df._id.startswith("G_")) & (lsb_df.hcsystemfk_source.contains("ich") | lsb_df.hcsystemfk_source.contains("_fc"))) 

lsb_lower_bound_date = date_sub(current_date(), 1) #parameterize in future
lsb_delta_df = lsb_df.filter(col("leadupdatedate") > lsb_lower_bound_date)

bad_gmrns_selected_cols = ['gmrnifk']
bad_gmrns_df = spark.read.table(f"{catalog_name}.dataingestion.patientmatchingblockallowgmrn").select(*bad_gmrns_selected_cols) 
                                                 
gmrnxpatientaccts_df = spark.read.parquet(baseurl+"/data/gmrn/publish/globalmrnxpacct/current/*")

vsnap_selected_cols = ["patientacctifk", "hospitalfk","createdate"]
vsnapflags_df = spark.read.format('delta').load(dataingestion_publish_path + "/vsnappatientacctsflags/current/20991231/" ).select(*vsnap_selected_cols)
vsnapflags_df = vsnapflags_df.withColumn('patientacctifk', vsnapflags_df.patientacctifk.cast("long"))
vsnapflags_df = vsnapflags_df.withColumnRenamed('createdate', 'vsnapflags_createdate')
vsnapflags_df = vsnapflags_df.withColumnRenamed('hospitalfk', 'vsnapflags_hospitalfk')

end_date = date_sub(current_date(), 30)

hospitals_df = spark.read.parquet(dataingestion_publish_path+'/hospitals/current/20991231')
hospitals_df = hospitals_df.filter("active=1")

paxleads_df = spark.read.format('delta').load(baseurl+'/data/leaddiscovery/publish/patientacctxlead/')

medicaid_helpers_df = spark.read.format("delta").load(coverage_helpers_publish_path + 'paxmedicaidhelper/')

existing_helpers_df = spark.read.format("delta").load(coverage_helpers_publish_path + 'patientacctxhelper/') 

# COMMAND ----------

# DBTITLE 1,def_get_patientacct_gmrn_helper
def get_patientacct_gmrn_helper(spark,pa_path,enddt,bc,hospadmitdate,vsnapflags):
   pacctscols = ["patientacctipk", "hospitalfk", "firstname", "middlename", "lastname", "ssn", "dob", "gender",
               "state", "admitdate", "referraldate",
               "dischargedate", "medicalrecnum", "clusteredacctfk", "totalcharges", "createdate", "updatedate",
               "demographicsupdatedate", "medicarehic", "medicaidnum", "trgupdatedate", "currentbalance"]
   
   allpatientaccts = spark.read.format("delta").load(pa_path).select(*pacctscols)
   allpatientaccts = allpatientaccts.withColumn('totalcharges', allpatientaccts.totalcharges.cast("decimal(32,4)"))
   allpatientaccts = allpatientaccts.withColumn('patientacctipk', allpatientaccts.patientacctipk.cast("long"))
   allpatientaccts = allpatientaccts.filter(allpatientaccts.totalcharges > 0)
        # apply admit date filters for patientaccts
   allpatientaccts = getpatientacctswithadmitdt(spark, allpatientaccts, hospadmitdate)
   dup_cols = ("vsnapflags_hospitalfk", "patientacctipk", "vsnapflags_createdate")
   allpatientaccts = allpatientaccts.join(vsnapflags, (allpatientaccts.patientacctipk == vsnapflags.patientacctifk) & (allpatientaccts.hospitalfk == vsnapflags.vsnapflags_hospitalfk))\
                                 .filter(((allpatientaccts.trgupdatedate >= enddt) | (allpatientaccts.admitdate >= enddt)) |(vsnapflags.vsnapflags_createdate >= enddt)) \
                                 .drop(*dup_cols)
   return allpatientaccts

# COMMAND ----------

# DBTITLE 1,create min max admitdate lookups
hp = readparquet(spark, dataingestion_publish_path + "/hospitals/current/*/", '0', 'na')
hp = hp.filter(col("active") == '1')
hpn = readparquet(spark, dataingestion_publish_path + "/hospitalprovidernums/current/*/", '0', 'na')
hpn = hpn.filter(col("enabled") == '1')
edis = readparquet(spark, dataingestion_publish_path + "/edisubmitters/current/*/", '0', 'na')
ep = readparquet(spark, dataingestion_publish_path + "/edipartners/current/*/", '0', 'na')
ep = ep.filter(col("isenabledflag") == '1')
epp = readparquet(spark, dataingestion_publish_path + "/edipartnertype/current/*/", '0', 'na')
epp = epp.filter((col("ismedicare") != '1')) #not propagating medicare leads
edienv = readparquet(spark, dataingestion_publish_path + "/edipartner270settings/current/*/", '0', 'na')
epso = readparquet(spark, dataingestion_publish_path + "/edipartnersubmittersoverrides/current/*/", '0', 'na')
ephsso = readparquet(spark, dataingestion_publish_path + "/edipartnerhospital270settingsoverrides/current/*/", '0', 'na')

b = createlookup(spark, hp, hpn, edis, ep, edienv, epso, ephsso,epp)
a = createlookupbypartnerfk(spark, hp, hpn, edis, ep, edienv, epso, ephsso,epp)
# using python util to write out
writeparquet(spark, b, minmaxbyhospital_path,1, "overwrite")
writeparquet(spark, a, minmaxbyedipartnerfk_path,1, "overwrite")

# COMMAND ----------

# DBTITLE 1,Get pa & check hospital admitdate
minmaxbyhospital_df = spark.read.parquet(minmaxbyhospital_path)
paaccts_df = get_patientacct_gmrn_helper(spark, dataingestion_publish_path+'/patientaccts/current/20991231', end_date, bc, minmaxbyhospital_df, vsnapflags_df)

# COMMAND ----------

# DBTITLE 1,swap delta gmrn relations & get leads from all lsb
#delta associations
gmrn_delta_fam_assoc_swapped_df = gmrn_fam_assoc_delta_df.select(
    col("globalmrnifk2").alias("globalmrnifk1"),
    col("globalmrnifk1").alias("globalmrnifk2")
)
#get bidirectional relations in a single df
gmrn_fam_assoc_delta_df = gmrn_fam_assoc_delta_df.union(gmrn_delta_fam_assoc_swapped_df).distinct()
#remove bad gmrns 
filtered_delta_gmrns_df = gmrn_fam_assoc_delta_df.join(bad_gmrns_df, gmrn_fam_assoc_delta_df.globalmrnifk1 == bad_gmrns_df.gmrnifk, "leftanti")

#delta associations X full lsb
associated_leads_df = filtered_delta_gmrns_df.join(
    lsb_df,
    concat(lit("G_"), filtered_delta_gmrns_df.globalmrnifk2.cast("string")) == lsb_df.identity
).select(
    filtered_delta_gmrns_df.globalmrnifk1,
    lsb_df._id,
    lsb_df.demographics,
    lsb_df.leadupdatedate
)

# COMMAND ----------

# DBTITLE 1,swap last 1 year gmrn relations & get leads from delta lsb
#all associations
gmrn_fam_assoc_swapped_df = gmrn_fam_assoc_one_year_df.select(
    col("globalmrnifk2").alias("globalmrnifk1"),
    col("globalmrnifk1").alias("globalmrnifk2")
)
#get bidirectional relations in a single df
gmrn_family_assoc_df = gmrn_fam_assoc_one_year_df.union(gmrn_fam_assoc_swapped_df).distinct()
#remove bad gmrns 
filtered_gmrns_df = gmrn_family_assoc_df.join(bad_gmrns_df, gmrn_family_assoc_df.globalmrnifk1 == bad_gmrns_df.gmrnifk, "leftanti")


#full associations X delta lsb
associated_delta_leads_df = filtered_gmrns_df.join(
    lsb_delta_df,
    concat(lit("G_"), filtered_gmrns_df.globalmrnifk2.cast("string")) == lsb_delta_df.identity
).select(
    filtered_gmrns_df.globalmrnifk1,
    lsb_delta_df._id,
    lsb_delta_df.demographics,
    lsb_delta_df.leadupdatedate
)

# COMMAND ----------

# DBTITLE 1,explode associated_leads_df
lsb_explode_df1 = associated_leads_df.select('*', explode(col("demographics")).alias("key","value")).drop("demographics")
lsb_explode_df2 = lsb_explode_df1.withColumnRenamed("key", "hcsystemfk_source")
lsb_explode_df = lsb_explode_df2.withColumn("lsb_hospitalfk", col("value").hospitalfk).drop("value")

# COMMAND ----------

# DBTITLE 1,explode associated_delta_leads_df
delta_lsb_explode_df1 = associated_delta_leads_df.select('*', explode(col("demographics")).alias("key","value")).drop("demographics")
delta_lsb_explode_df2 = delta_lsb_explode_df1.withColumnRenamed("key", "hcsystemfk_source")
delta_lsb_explode_df3 = delta_lsb_explode_df2.withColumn("demog_updatedate", col("value").updatedate)

delta_lsb_explode_df3 = delta_lsb_explode_df3.withColumn(
    "demog_updatedate",
    to_date(col("demog_updatedate"))  
)


delta_lsb_explode_df4 = delta_lsb_explode_df3.filter(col("demog_updatedate") > lsb_lower_bound_date)
delta_lsb_explode_df = delta_lsb_explode_df4.withColumn("lsb_hospitalfk", col("value").hospitalfk).drop("value").drop("demog_updatedate")

# COMMAND ----------

# DBTITLE 1,union associated all leads & delta leads
associated_all_leads_df = lsb_explode_df.union(delta_lsb_explode_df)

# COMMAND ----------

# DBTITLE 1,split 'hcsystemfk_source' & explode 'lsb_hospitalfk'
lsb_hcsystem_source_split_df1 = associated_all_leads_df.withColumn("hcsystemfk", split("hcsystemfk_source", "_")[0])\
                                                         .withColumn("source", split("hcsystemfk_source", "_")[1]).drop("hcsystemfk_source")

lsb_hcsystem_source_split_df = lsb_hcsystem_source_split_df1.filter((col("source") == "ich") | (col("source") == "fc"))


lsb_hospital_split_df1 = lsb_hcsystem_source_split_df.withColumn("lsb_hospitalfk", split("lsb_hospitalfk", "\\|"))
lsb_hospital_split_df = lsb_hospital_split_df1.withColumn("lsb_hospitalfk", explode("lsb_hospitalfk"))

# COMMAND ----------

# DBTITLE 1,get  patientacctifk to gmrnid
associated_paaccts_df = lsb_hospital_split_df.join(
    gmrnxpatientaccts_df,
    lsb_hospital_split_df.globalmrnifk1 == gmrnxpatientaccts_df.globalmrnifk.cast("int")
).select(
    gmrnxpatientaccts_df.patientacctifk,
    gmrnxpatientaccts_df.hospitalfk,
    lsb_hospital_split_df["*"]
)

# COMMAND ----------

# DBTITLE 1,Join with patientaccts to get demogs
all_helpers_demog_df1 = associated_paaccts_df.join(
    paaccts_df,
    (associated_paaccts_df.patientacctifk == paaccts_df.patientacctifk) & (associated_paaccts_df.hospitalfk == paaccts_df.hospitalfk)
).select(
    associated_paaccts_df["*"],
    paaccts_df.firstname,
    paaccts_df.middlename,
    paaccts_df.lastname,
    paaccts_df.admitdate,
    paaccts_df.dischargedate,
    paaccts_df.clusteredacctfk,
    paaccts_df.dob,
    paaccts_df.ssn,
    paaccts_df.gender,
    paaccts_df.state,
    paaccts_df.totalcharges,
    paaccts_df.medicarehic,
    paaccts_df.medicaidnum
)
all_helpers_demog_df1.write.mode("overwrite").parquet(gmrn_helpers_transform_path + 'all_helpers_demogs/')

# COMMAND ----------

# DBTITLE 1,check coverageid length
all_helpers_demog_df1 = spark.read.parquet(gmrn_helpers_transform_path + 'all_helpers_demogs/')
all_helpers_demog_df = all_helpers_demog_df1.withColumn("lsb_edipartnerfk", split(all_helpers_demog_df1["_id"], "_")[2]) \
                                            .withColumn("lsb_coverageid", split(all_helpers_demog_df1["_id"], "_")[3])

# Remove leading, trailing 'NULL' (case-insensitive) as well null string from lsb_coverageid
all_helpers_demog_df = all_helpers_demog_df.withColumn("lsb_coverageid",regexp_replace(regexp_replace(regexp_replace(all_helpers_demog_df.lsb_coverageid, r"^(?i)null+", ""),r"(?i)null+$", ""),r"^(?i)null+$", "" ))

all_helpers_demog_df = all_helpers_demog_df.filter(
    (length(trim(all_helpers_demog_df.lsb_coverageid)) > 5) &
    (length(trim(all_helpers_demog_df.lsb_coverageid)) <= 25)
)

# COMMAND ----------

# DBTITLE 1,hpn filter
all_helpers_hpn_df = filter_ifhpn_notenabled(spark, all_helpers_demog_df, dataingestion_publish_path,gmrn_helpers_transform_path)

# COMMAND ----------

# DBTITLE 1,Check against patientacctxleads
all_helpers_chk_paxleads_df = (
            all_helpers_hpn_df.join(
            paxleads_df,
            on = (
                (all_helpers_hpn_df.hospitalfk==paxleads_df.hospitalfk.cast("int"))&
                (all_helpers_hpn_df.lsb_edipartnerfk==paxleads_df.lsb_edipartnerfk)&
                (all_helpers_hpn_df.patientacctifk==paxleads_df.patientacctifk)&
                (upper(all_helpers_hpn_df.lsb_coverageid) == upper(paxleads_df.lsb_coverageid))
            ),
            how="leftanti"))

# COMMAND ----------

# DBTITLE 1,apply walling off
#get non ich records
all_helpers_chk_paxleads_df = all_helpers_chk_paxleads_df.withColumnRenamed("source","lsb_source")
all_helpers_fc_source_df1 = all_helpers_chk_paxleads_df.filter(all_helpers_chk_paxleads_df.lsb_source=="fc")
all_helpers_fc_source_df = all_helpers_fc_source_df1.withColumn("lsb_leadsourcevalue", lit("FC"))

all_helpers_walling_off_df = applywallingoff(spark, all_helpers_fc_source_df, dataingestion_publish_path, gmrn_helpers_transform_path)
all_helpers_walling_off_df = all_helpers_walling_off_df.drop("lsb_leadsourcevalue")

#get ich records
all_helpers_ich_source_df = all_helpers_chk_paxleads_df.filter(all_helpers_chk_paxleads_df.lsb_source=="ich") 

#combine ich & non-ich records
all_helpers_union_df = all_helpers_walling_off_df.union(all_helpers_ich_source_df)  

# COMMAND ----------

# DBTITLE 1,exclude foundcoverage's
create_temp_data(spark, dataingestion_publish_path, gmrn_helpers_transform_path)
all_helpers_excluded_fc_df = filter_ifexistsinfc(spark, all_helpers_union_df, dataingestion_publish_path, gmrn_helpers_transform_path)

# COMMAND ----------

# DBTITLE 1,admitdate check on partner
all_helpers_cov_len_df = filter_coverageid_len_admitdt(spark, all_helpers_excluded_fc_df, minmaxbyedipartnerfk_path,gmrn_helpers_transform_path)

# COMMAND ----------

# DBTITLE 1,def blacklisted partnerpolicyid
def filter_blacklisted_partnerpolicyid_gmrn_helper(spark, all_leads, blacklist_accts, hdfs_scratch):
    blacklist_accts.createOrReplaceTempView("partnerpolicyidblacklists")
    all_leads.createOrReplaceTempView("lead")

    leads = spark.sql(""" SELECT l.*
                               FROM lead l 
                               JOIN partnerpolicyidblacklists bl
                                     ON  bl.edipartnerfk = l.lsb_edipartnerfk
                                     AND ( ( bl.coverageid = l.lsb_coverageid )
				      	OR ( bl.coverageid LIKE '%' || l.lsb_coverageid || '%' )
					OR ( l.lsb_coverageid LIKE '%' || bl.coverageid || '%' ) )
                      """)
    return all_leads.subtract(leads) 

# COMMAND ----------

# DBTITLE 1,filter blacklisted partnerpolicyid
blcol = ["edipartnerfk", "coverageid"]
blacklist_accts = extract_parquet_data(spark, dataingestion_publish_path + "/partnerpolicyidblacklists/current/*", blcol)
all_helpers_blk_df = filter_blacklisted_partnerpolicyid_gmrn_helper(spark, all_helpers_cov_len_df, blacklist_accts, gmrn_helpers_transform_path)

# COMMAND ----------

# DBTITLE 1,mincharges_by_partner filter
all_helpers_mincharges_by_partner  = filter_mincharges_by_partner(spark, all_helpers_blk_df, dataingestion_publish_path, gmrn_helpers_transform_path)

# COMMAND ----------

# DBTITLE 1,Check against all helpers
missing_helpers_df1 = (
          all_helpers_mincharges_by_partner.join(
          existing_helpers_df,
          on = (
               (all_helpers_mincharges_by_partner.hospitalfk == existing_helpers_df.hospitalfk ) &
               (all_helpers_mincharges_by_partner.lsb_edipartnerfk == existing_helpers_df.edipartnerfk) &
               (all_helpers_mincharges_by_partner.patientacctifk == existing_helpers_df.patientacctifk) &
               (upper(all_helpers_mincharges_by_partner.lsb_coverageid) == upper(existing_helpers_df.CoverageID))
          ),
    how='leftanti'
))

# COMMAND ----------

# DBTITLE 1,Check against medicaidhelpers
missing_helpers_df2 = (
          missing_helpers_df1.join(
          medicaid_helpers_df,
          on = (
               (missing_helpers_df1.hospitalfk == medicaid_helpers_df.hospitalfk ) &
               (missing_helpers_df1.lsb_edipartnerfk == medicaid_helpers_df.edipartnerfk) &
               (missing_helpers_df1.patientacctifk == medicaid_helpers_df.patientacctifk) &
               (upper(missing_helpers_df1.lsb_coverageid) == upper(medicaid_helpers_df.CoverageID))
          ),
    how='leftanti'
))

# COMMAND ----------

# DBTITLE 1,get npi & hospitalname for payer hospitals
missing_helpers_ohi_df = ohibatchprocess(spark, missing_helpers_df2, dataingestion_publish_path, gmrn_helpers_transform_path)
missing_helpers_ohi_df.createOrReplaceTempView("missing_helpers_ohi_tbl")

# COMMAND ----------

# DBTITLE 1,target table mapping
new_helpers_df = spark.sql(""" 
    SELECT 
        CAST(patientacctifk AS LONG) AS patientacctifk,
        CAST(hospitalfk AS INT) AS hospitalfk,
        hospitalname,
        lsb_edipartnerfk AS edipartnerfk,
        'InProgress' AS PatientAcctXLeadStatus,
        CURRENT_TIMESTAMP() AS PatientAcctXLeadStatusUpdateDate,
        firstname,
        lastname,
        middlename,
        CAST(dob AS TIMESTAMP) AS dob,
        ssn,                 
        gender,
        state,
        CAST(NULL AS STRING) AS TraditionalIdentifier,
        CAST(admitdate AS TIMESTAMP) AS admitdate,
        CAST(dischargedate AS TIMESTAMP) AS dischargedate,
        lsb_coverageid AS CoverageID,
        CAST(NULL AS STRING) AS FC_SSN,
        CAST(NULL AS STRING) AS FC_DOB,
        CAST(NULL AS STRING) AS FC_LastName,
        CAST(NULL AS STRING) AS FC_FirstName,
        CAST(clusteredacctfk AS INT) AS clusteredacctfk,
        CAST(totalcharges AS DECIMAL(32,4)) AS totalcharges,
        npi, 
        CAST(NULL AS INT) AS UsingFamilyDataFlag,
        CAST(NULL AS INT) AS DemographicsHash,
        CAST(NULL AS STRING) AS LastAbiETLStartDate,
        '60' AS edidatasourcefk, 
        CAST(NULL AS STRING) AS EDIDataSourceTableKey,
        CAST(NULL AS STRING) AS AssociationSource,
        medicarehic,
        medicaidnum,
        row_number() OVER(PARTITION BY patientacctifk,hospitalfk,lsb_edipartnerfk,upper(lsb_coverageid) ORDER BY CAST(leadupdatedate AS TIMESTAMP) desc) AS rownum
    FROM missing_helpers_ohi_tbl
""").dropDuplicates()
new_helpers_df = new_helpers_df.filter(new_helpers_df.rownum == 1).drop("rownum")

# COMMAND ----------

# DBTITLE 1,write to sqoop input
new_helpers_df.write.mode("overwrite").parquet(gmrn_helpers_transform_path + 'final_helpers')

# COMMAND ----------

# DBTITLE 1,append to patientacctxhelper
#add bc with extension
new_helpers_final_df = new_helpers_df.withColumn("breadcrumb", lit(bc + "-GF"))
new_helpers_final_df.write.mode("append").format("delta").save(coverage_helpers_publish_path + 'patientacctxhelper')

# COMMAND ----------

# DBTITLE 1,delete the temp data
dbutils.fs.rm(gmrn_helpers_transform_path+"/tmpdata",True)
