# Databricks notebook source
dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("helpers_transform_path","")
dbutils.widgets.getArgument("helpers_transform_path")
helpers_transform_path= getArgument("helpers_transform_path")

tablename = 'ICDTransport.dbo.PatientAcctXLead'

path_conn_file = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-transport-sql-insleads-cs")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 
print(baseurl)

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

helpers = spark.read.parquet(baseurl+helpers_transform_path+bc +'/final_helpers')
helpers=helpers.drop("medicarehic","medicaidnum")

# COMMAND ----------

helpers.write.format('jdbc').mode('append').option('driver', 'com.microsoft.sqlserver.jdbc.SQLServerDriver').option \
        ('url', path_conn_file).option('dbtable',tablename).save()
