# Databricks notebook source
import sys
import math
from datetime import datetime
from pyspark.storagelevel import StorageLevel
from pyspark.sql.types import *
from datetime import datetime
from pyspark.sql.functions import *
import re
from collections import deque
from delta.tables import *

# COMMAND ----------

dbutils.widgets.text('input_bc','')
input_bc = dbutils.widgets.get("input_bc")

dbutils.widgets.text('input_mh_toserve','')
input_mh_toserve = dbutils.widgets.get("input_mh_toserve")

dbutils.widgets.text('input_base_tables','')
input_base_tables = dbutils.widgets.get("input_base_tables")

dbutils.widgets.text('input_lr_xref_ssn_mrn_clusterid','')
input_lr_xref_ssn_mrn_clusterid = dbutils.widgets.get("input_lr_xref_ssn_mrn_clusterid")

dbutils.widgets.text('storageaccount','')
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text('container','')
container = dbutils.widgets.get("container")

dbutils.widgets.text('loadtype','')
loadtype = dbutils.widgets.get("loadtype")

dbutils.widgets.text('user','')
user = dbutils.widgets.get("user")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user=='na':
    username=""
else :
    username=user

print("user= "+ user+" username= "+username)

# COMMAND ----------

baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'

if username=='':
    print("RUNNING AS PROD USER")
    input_mh_toserve=baseurl+input_mh_toserve+"/"+input_bc
    input_foundcoverages=baseurl+input_base_tables+"/foundcoverage/current/20991231/"
    input_foundcoverageinferredsourcemethodcodes=baseurl+input_base_tables+"/foundcoverageinferredsourcemethodcodes/current/20991231/"
    input_patientaccts=baseurl+input_base_tables+"/patientaccts/current/20991231/"
    input_lr_xref_ssn_mrn_clusterid=baseurl+"/"+input_lr_xref_ssn_mrn_clusterid
else :
    print("RUNNING AS LOCAL USER "+username)
    input_mh_toserve=baseurl+"/"+username+"/"+input_mh_toserve+"/"+input_bc
    input_foundcoverages=baseurl+input_base_tables+"/foundcoverage/current/20991231/"
    input_foundcoverageinferredsourcemethodcodes=baseurl+input_base_tables+"/foundcoverageinferredsourcemethodcodes/current/20991231/"
    input_patientaccts=baseurl+input_base_tables+"/patientaccts/current/20991231/"
    input_lr_xref_ssn_mrn_clusterid=baseurl+"/"+username+"/"+input_lr_xref_ssn_mrn_clusterid

print("input_bc="+ input_bc)
print("input_mh_toserve="+ input_mh_toserve)
print("input_foundcoverages="+ input_foundcoverages)
print("input_foundcoverageinferredsourcemethodcodes="+ input_foundcoverageinferredsourcemethodcodes)
print("input_patientaccts="+ input_patientaccts)
print("input_lr_xref_ssn_mrn_clusterid="+ input_lr_xref_ssn_mrn_clusterid)


# COMMAND ----------

# DBTITLE 1,Determining Participating Hospitals 
df_mh_delta=spark.read.parquet(input_mh_toserve)
df_mh_delta.createOrReplaceTempView("df_mh_delta")
df_hfc_hospital_in_play=df_mh_delta.selectExpr("hospitalfk").dropDuplicates()
df_hfc_hospital_in_play.createOrReplaceTempView("df_hfc_hospital_in_play")


df_patacc_raw = spark.read.format("delta").load(input_patientaccts).selectExpr("patientacctipk",
                                                                              "hospitalfk",
                                                                              "ssn",
                                                                              "clusteredacctfk",
                                                                              "medicalrecnum").dropDuplicates()

df_patacc_raw.createOrReplaceTempView("patientaccts")
df_patacc_raw=spark.sql(""" SELECT * FROM patientaccts WHERE hospitalfk IN ( SELECT hospitalfk FROM df_hfc_hospital_in_play) """)
df_patacc_raw.createOrReplaceTempView("patientaccts")

# COMMAND ----------

df_xref=spark.sql("""SELECT df_mh_delta.*,
       patientaccts.ssn,
       patientaccts.clusteredacctfk,
       patientaccts.medicalrecnum
FROM df_mh_delta
  INNER JOIN patientaccts
          ON df_mh_delta.hospitalfk = patientaccts.hospitalfk
         AND df_mh_delta.patientacctifk = patientaccts.patientacctipk
         """).drop("patientacctifk","coverageid","payerid").dropDuplicates()

# COMMAND ----------

# MAGIC %run /Insleads-code/Common-Util/tu_data_quality

# COMMAND ----------

def check_validation(df,col):
    if col == "ssn":
       isValidSSN_udf = udf(isValidSSN, IntegerType())
       df = df.withColumn('ssn_valid',isValidSSN_udf(df.ssn))
       df = df.withColumn('ssn',when(df.ssn_valid==0,None).otherwise(df.ssn))
       df = df.drop("ssn_valid")
    if col == "medicalrecnum":
       isValidMRN_udf = udf(isValidMRN, IntegerType())
       df = df.withColumn('mrn_valid',isValidMRN_udf(df.medicalrecnum))
       df = df.withColumn('medicalrecnum',when(df.mrn_valid==0,None).otherwise(df.medicalrecnum))
       df = df.drop("mrn_valid")
    return df

# COMMAND ----------

df_xref = check_validation(df_xref,"ssn")
df_xref = check_validation(df_xref,"medicalrecnum")

# COMMAND ----------

df_xref.createOrReplaceTempView("df_xref")
df_xref=spark.sql("""
        SELECT df_xref.transactionkey,
       '6' AS sourcekey,
       df_xref.bc AS lr_creatingmodule,
       CURRENT_DATE() AS lr_createdate,
       df_xref.ssn AS ssn,
       df_xref.clusteredacctfk AS clusteredacctfk,
       df_xref.medicalrecnum AS medicalrecnum,
       'mh' AS xrefsource,
       df_xref.bc AS audittrail,
       CONCAT(df_xref.transactionkey,'_',df_xref.hospitalfk,'_','6') AS _id,
       df_xref.hospitalfk
FROM df_xref""")
df_xref.createOrReplaceTempView("df_xref")

# COMMAND ----------

# DBTITLE 1,Loading GMRN_XREF data to hfc_lr_xref_gmrnid_transaction table
if loadtype=="base":
    print("XREF LOAD_TYPE : "+loadtype)
    df_xref.write.format("delta").save(input_lr_xref_ssn_mrn_clusterid)
elif loadtype=="delta":
    print("XREF LOAD_TYPE : "+loadtype)
    # df_xref.write.mode("append").format("delta").save(input_lr_xref_ssn_mrn_clusterid)
    df_raw = DeltaTable.forPath(spark, input_lr_xref_ssn_mrn_clusterid)
    df_raw.alias("raw").merge(df_xref.alias("delta"), "raw._id=delta._id").whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()
    print("NON_BASE : RECONCILE : INSERT-UPDATE : DONE")
else:
    print("XREF WRONG LOADTYE : "+loadtype)
    exit(1)
