# Databricks notebook source
import sys
import math
from datetime import datetime
from pyspark.storagelevel import StorageLevel
from pyspark.sql.types import *
from datetime import datetime
from pyspark.sql.functions import *
import re
from collections import deque
from delta.tables import *

# COMMAND ----------

dbutils.widgets.text('input_bc','')
input_bc = dbutils.widgets.get("input_bc")

dbutils.widgets.text('input_mh_toserve','')
input_mh_toserve = dbutils.widgets.get("input_mh_toserve")

dbutils.widgets.text('input_base_tables','')
input_base_tables = dbutils.widgets.get("input_base_tables")

dbutils.widgets.text('input_lr_xref_gmrnid_transaction','')
input_lr_xref_gmrnid_transaction = dbutils.widgets.get("input_lr_xref_gmrnid_transaction")

dbutils.widgets.text('storageaccount','')
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text('container','')
container = dbutils.widgets.get("container")

dbutils.widgets.text('loadtype','')
loadtype = dbutils.widgets.get("loadtype")

dbutils.widgets.text('user','')
user = dbutils.widgets.get("user")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user=='na':
    username=""
else :
    username=user

print("user= "+ user+" username= "+username)

# COMMAND ----------

if username=='':
    print("RUNNING AS PROD USER")
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else :
    print("RUNNING AS LOCAL USER "+username)
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+username

input_lr_xref_gmrnid_transaction=baseurl+input_lr_xref_gmrnid_transaction
input_mh_toserve=baseurl+input_mh_toserve+"/"+input_bc
input_globalmrnxpacct=baseurl+"/data/gmrn/publish/globalmrnxpacct/current/*"
input_temp=baseurl+"/data/leadrepo/transform/scratch/mh/"+input_bc
    
print("input_lr_xref_gmrnid_transaction="+ input_lr_xref_gmrnid_transaction)
print("input_bc="+ input_bc)
print("input_mh_toserve="+ input_mh_toserve)
print("input_globalmrnxpacct="+ input_globalmrnxpacct)
print("input_temp="+ input_temp)

# COMMAND ----------

# DBTITLE 1,Determining Participating Hospitals 
df_mh_delta=spark.read.parquet(input_mh_toserve)
df_mh_delta.createOrReplaceTempView("df_mh_delta")
df_hfc_hospital_in_play=df_mh_delta.selectExpr("hospitalfk").dropDuplicates()
df_hfc_hospital_in_play.createOrReplaceTempView("df_hfc_hospital_in_play")

# COMMAND ----------

# DBTITLE 1,Reading base globalmrnxpacct and deduping
df_globalmrnxpacct=spark.read.parquet(input_globalmrnxpacct).selectExpr("globalmrnifk as gmrnid","hospitalfk","patientacctifk","createdate")
df_globalmrnxpacct.createOrReplaceTempView("df_globalmrnxpacct")

df_globalmrnxpacct=spark.sql("""SELECT * FROM df_globalmrnxpacct WHERE hospitalfk IN (SELECT hospitalfk FROM df_hfc_hospital_in_play)""")
df_globalmrnxpacct.createOrReplaceTempView("df_globalmrnxpacct")

df_globalmrnxpacct=spark.sql("""SELECT patientacctifk,hospitalfk,gmrnid,ROW_NUMBER() OVER (PARTITION BY patientacctifk,hospitalfk ORDER BY createdate DESC) AS rnk FROM df_globalmrnxpacct""")
df_globalmrnxpacct=df_globalmrnxpacct.filter("rnk=='1'").drop("rnk")

df_globalmrnxpacct.repartition(250).write.mode("overwrite").parquet(input_temp+"/gmrn_dedeuped/")
df_globalmrnxpacct.unpersist()

# COMMAND ----------

# DBTITLE 1,Reading deduped globalmrnxpacct  data
df_globalmrnxpacct=spark.read.parquet(input_temp+"/gmrn_dedeuped/")
df_globalmrnxpacct.createOrReplaceTempView("df_globalmrnxpacct")

# COMMAND ----------

# DBTITLE 1,Generating GMRN_XREF data
df_gmrn_delta=spark.sql("""
        SELECT CURRENT_DATE()  AS lr_createdate,
               df_mh_delta.bc AS lr_creatingmodule,
               df_globalmrnxpacct.gmrnid AS gmrnid,
               '6' AS sourcekey,
               df_mh_delta.transactionkey,
               df_mh_delta.hospitalfk
FROM df_mh_delta
  INNER JOIN df_globalmrnxpacct
          ON df_mh_delta.hospitalfk = df_globalmrnxpacct.hospitalfk
         AND df_mh_delta.patientacctifk = df_globalmrnxpacct.patientacctifk
         """)
df_gmrn_delta.createOrReplaceTempView("df_gmrn_delta")
df_gmrn_delta=spark.sql("""
       SELECT CONCAT(df_gmrn_delta.gmrnid,'_',df_gmrn_delta.transactionkey,'_',df_gmrn_delta.hospitalfk,'_',df_gmrn_delta.sourcekey) AS _id,
              CONCAT(df_gmrn_delta.gmrnid,'~',df_gmrn_delta.lr_creatingmodule) AS audittrail,
              df_gmrn_delta.lr_createdate,
              df_gmrn_delta.lr_creatingmodule,
              df_gmrn_delta.gmrnid,
              df_gmrn_delta.sourcekey,
              df_gmrn_delta.transactionkey,
              'mh' AS xrefsource,
              df_gmrn_delta.hospitalfk
FROM df_gmrn_delta """).dropDuplicates()

# COMMAND ----------

# DBTITLE 1,Loading GMRN_XREF data to hfc_lr_xref_gmrnid_transaction table
if loadtype=="base":
    print("XREF LOAD_TYPE : "+loadtype)
    df_gmrn_delta.write.format("delta").save(input_lr_xref_gmrnid_transaction)
elif loadtype=="delta":
    print("XREF LOAD_TYPE : "+loadtype)
    # df_gmrn_delta.write.mode("append").format("delta").save(input_lr_xref_gmrnid_transaction)
    df_raw = DeltaTable.forPath(spark, input_lr_xref_gmrnid_transaction)
    df_raw.alias("raw").merge(df_gmrn_delta.alias("delta"), "raw._id=delta._id").whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()
    print("NON_BASE : RECONCILE : INSERT-UPDATE : DONE")

else:
    print("XREF WRONG LOADTYE : "+loadtype)
    exit(1)
