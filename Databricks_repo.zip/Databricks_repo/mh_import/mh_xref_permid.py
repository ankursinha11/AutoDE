# Databricks notebook source
import sys
import math
from datetime import datetime
from pyspark.storagelevel import StorageLevel
from pyspark.sql.types import *
from datetime import datetime
from pyspark.sql.functions import *
import re
from collections import deque
from delta.tables import *

# COMMAND ----------

dbutils.widgets.text('input_bc','')
input_bc = dbutils.widgets.get("input_bc")

dbutils.widgets.text('input_mh_toserve','')
input_mh_toserve = dbutils.widgets.get("input_mh_toserve")

dbutils.widgets.text('input_base_tables','')
input_base_tables = dbutils.widgets.get("input_base_tables")

dbutils.widgets.text('input_lr_xref_permid_transaction','')
input_lr_xref_permid_transaction = dbutils.widgets.get("input_lr_xref_permid_transaction")

dbutils.widgets.text('storageaccount','')
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text('container','')
container = dbutils.widgets.get("container")

dbutils.widgets.text('loadtype','')
loadtype = dbutils.widgets.get("loadtype")

dbutils.widgets.text('user','')
user = dbutils.widgets.get("user")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user=='na':
    username=""
else :
    username=user

print("user= "+ user+" username= "+username)

# COMMAND ----------

if username=='':
    print("RUNNING AS PROD USER")
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else :
    print("RUNNING AS LOCAL USER "+username)
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+username

input_lr_xref_permid_transaction=baseurl+input_lr_xref_permid_transaction
input_mh_toserve=baseurl+input_mh_toserve+"/"+input_bc
input_permidpatientacctid=baseurl+"/data/cdd/publish/permidpatientacctid/*"

print("input_lr_xref_permid_transaction="+ input_lr_xref_permid_transaction)
print("input_bc="+ input_bc)
print("input_mh_toserve="+ input_mh_toserve)
print("input_permidpatientacctid="+ input_permidpatientacctid)

# COMMAND ----------

# DBTITLE 1,Reading to_serve and permidpatientacctid
df_mh_delta=spark.read.parquet(input_mh_toserve).selectExpr("transactionkey","bc","patientacctifk","hospitalfk")
df_mh_delta = df_mh_delta.withColumn("hospitalfk", df_mh_delta["hospitalfk"].cast("short"));
df_mh_delta.createOrReplaceTempView("df_mh_delta")

df_permidpatientacctid=spark.read.parquet(input_permidpatientacctid).filter("matchind in ('IM','M1')").selectExpr("permid","patientacctifk","hospitalfk")
df_permidpatientacctid.createOrReplaceTempView("df_permidpatientacctid")

# COMMAND ----------

# DBTITLE 1,Generating PERMID_XREF data
df_permid_delta=spark.sql("""
        SELECT CURRENT_DATE()  AS lr_createdate, 
              df_mh_delta.bc AS lr_creatingmodule,
              df_permidpatientacctid.permid AS permid,
              '6' AS sourcekey,
              df_mh_delta.transactionkey,
              cast(df_mh_delta.hospitalfk as string) as hospitalfk
       FROM df_mh_delta
       INNER JOIN df_permidpatientacctid
              ON df_mh_delta.patientacctifk = df_permidpatientacctid.patientacctifk
              AND df_mh_delta.hospitalfk = df_permidpatientacctid.hospitalfk
         """)
df_permid_delta.createOrReplaceTempView("df_permid_delta")
df_permid_delta=spark.sql("""
       SELECT CONCAT(df_permid_delta.permid,'_',df_permid_delta.transactionkey,'_',df_permid_delta.hospitalfk,'_',df_permid_delta.sourcekey) AS _id,
              CONCAT(df_permid_delta.permid,'~',df_permid_delta.lr_creatingmodule) AS audittrail,
              df_permid_delta.lr_createdate,
              df_permid_delta.lr_creatingmodule,
              df_permid_delta.permid,
              df_permid_delta.sourcekey,
              df_permid_delta.transactionkey,
              'mh' AS xrefsource,
              df_permid_delta.hospitalfk
       FROM df_permid_delta """).dropDuplicates()

# COMMAND ----------

# DBTITLE 1,Loading PEMRID_XREF data to mh_lr_xref_permid_transaction table
if loadtype=="base":
    print("XREF LOAD_TYPE : "+loadtype)
    df_permid_delta.write.format("delta").save(input_lr_xref_permid_transaction)
elif loadtype=="delta":
    print("XREF LOAD_TYPE : "+loadtype)
    # df_permid_delta.write.mode("append").format("delta").save(input_lr_xref_permid_transaction)
    df_raw = DeltaTable.forPath(spark, input_lr_xref_permid_transaction)
    df_raw.alias("raw").merge(df_permid_delta.alias("delta"), "raw._id=delta._id").whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()
    print("NON_BASE : RECONCILE : INSERT-UPDATE : DONE")
else:
    print("XREF WRONG LOADTYE : "+loadtype)
    exit(1)
