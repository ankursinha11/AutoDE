# Databricks notebook source
# DBTITLE 1,Initialize Python Libraries
from pyspark.sql.types import *
from pyspark.sql.functions import *
import re
from collections import deque

# COMMAND ----------

# DBTITLE 1,Sample Input-QA
#RUNNING AS LOCAL USER maxc
#input_lr_transaction=abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/maxc//data/leadrepo/publish/cooked/mh_lr_transaction/
#input_mh_delta=abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/maxc//data/leadrepo/staging/input/raw/medicarecoverage//20231218T10
#input_bc=20231218T10
#input_mh_toserve=abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/maxc//data/leadrepo/publish/toserve/mh_import//20231218T10
#input_temp=abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/maxc//data/leadrepo/transform/scratch/mh/20231218T10
#input_medicarecoverage=abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/maxc//data/dataingestion/publish//medicarecoverage/current/20991231/
#input_hospitals=abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/maxc//data/dataingestion/publish//hospitals/current/20991231/
#input_edipartners=abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/maxc//data/dataingestion/publish//edipartners/current/20991231/
#input_foundcoverage=abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/maxc//data/dataingestion/publish//foundcoverage/current/20991231/

# COMMAND ----------

# DBTITLE 1,Initialize the input-output parameters.
dbutils.widgets.text('input_bc','')
input_bc = dbutils.widgets.get("input_bc")

dbutils.widgets.text('input_mh_delta','')
input_mh_delta = dbutils.widgets.get("input_mh_delta")

dbutils.widgets.text('input_mh_toserve','')
input_mh_toserve = dbutils.widgets.get("input_mh_toserve")

dbutils.widgets.text('input_base_tables','')
input_base_tables = dbutils.widgets.get("input_base_tables")

dbutils.widgets.text('input_lr_transaction','')
input_lr_transaction = dbutils.widgets.get("input_lr_transaction")

dbutils.widgets.text('storageaccount','')
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text('container','')
container = dbutils.widgets.get("container")

dbutils.widgets.text('loadtype','')
loadtype = dbutils.widgets.get("loadtype")

dbutils.widgets.text('user','')
user = dbutils.widgets.get("user")

# COMMAND ----------

# DBTITLE 1,Initialize Access Keys
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# DBTITLE 1,basepath
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

# DBTITLE 1,Setting Fully Qualified Base Parameters

input_lr_transaction=baseurl+input_lr_transaction
input_mh_delta=baseurl+input_mh_delta+"/"+input_bc
input_mh_toserve=baseurl+input_mh_toserve+"/"+input_bc
input_temp=baseurl+"/data/leadrepo/transform/scratch/mh/"+input_bc
input_medicarecoverage=baseurl+input_base_tables+"/medicarecoverage/current/20991231/"
input_hospitals=baseurl+input_base_tables+"/hospitals/current/20991231/"
input_edipartners=baseurl+input_base_tables+"/edipartners/current/20991231/"
input_edipartnertype=baseurl+input_base_tables+"/edipartnertype/current/20991231/"
input_foundcoverage=baseurl+input_base_tables+"/foundcoverage/current/20991231/"

print("input_lr_transaction="+ input_lr_transaction)
print("input_mh_delta="+ input_mh_delta)
print("input_bc="+ input_bc)
print("input_mh_toserve="+ input_mh_toserve)
print("input_temp="+ input_temp)
print("input_medicarecoverage="+ input_medicarecoverage)
print("input_hospitals="+ input_hospitals)
print("input_edipartners="+ input_edipartners)
print("input_edipartnertype="+ input_edipartnertype)
print("input_foundcoverage="+ input_foundcoverage)

# COMMAND ----------

# DBTITLE 1,Determining Load Type Base or Delta
if loadtype=="base":
    print("LOAD_TYPE : "+loadtype)
    df_mh_delta=spark.read.format("delta").load(input_medicarecoverage).selectExpr("FoundCoverageIFK","HospitalFK","PatientAcctIFK","CreateDate","UpdateDate","MedicareCoverageIPK","inferredsourcemethodcode","MedicareHIC")
elif loadtype=="delta":
    print("LOAD_TYPE : "+loadtype)
    df_mh_delta=spark.read.parquet(input_mh_delta).selectExpr("FoundCoverageIFK","HospitalFK","PatientAcctIFK","CreateDate","UpdateDate","MedicareCoverageIPK","inferredsourcemethodcode","MedicareHIC")
else:
    print("WRONG LOADTYE : "+loadtype)
    exit(1)

# COMMAND ----------

for column in df_mh_delta.columns:
    df_mh_delta = df_mh_delta.withColumn(column, trim(col(column)))
    df_mh_delta = df_mh_delta.withColumn(column, upper(col(column)))
    df_mh_delta = df_mh_delta.withColumn(column, when(col(column).isNull(), '').otherwise(col(column)))
    df_mh_delta = df_mh_delta.withColumn(column, when(upper(col(column)) == 'NULL', '').otherwise(col(column)))

df_mh_delta.createOrReplaceTempView("df_mh_delta")
df_mh_delta=spark.sql(""" SELECT * FROM df_mh_delta WHERE TRIM(MedicareHIC) IS NOT NULL AND TRIM(MedicareHIC) <> '' """)
df_mh_delta.createOrReplaceTempView("df_mh_delta")
df_mh_delta=spark.sql(""" SELECT * FROM df_mh_delta WHERE LENGTH(TRIM(MedicareHIC)) > 0 """)
df_mh_delta = df_mh_delta.where(df_mh_delta.MedicareHIC.rlike("^[1-9][AC-HJKMNPQRT-Y][0-9AC-HJKMNPQRT-Y][0-9][AC-HJKMNPQRT-Y][0-9AC-HJKMNPQRT-Y][0-9][AC-HJKMNPQRT-Y][AC-HJKMNPQRT-Y][0-9][0-9]$"))
df_mh_delta.createOrReplaceTempView("df_mh_delta")

# COMMAND ----------

df_hospital_in_play=df_mh_delta.selectExpr("HospitalFK").dropDuplicates()
df_hospital_in_play.createOrReplaceTempView("df_hospital_in_play")

# COMMAND ----------

# DBTITLE 1,Reading Base Hospital and Edipartners Data and FoundCoverages
df_hospitals=spark.read.format("parquet").load(input_hospitals).selectExpr("hospitalpk as hospitalfk","hcsystemfk").dropDuplicates()
df_hospitals.createOrReplaceTempView("df_hospitals")

df_edipartners=spark.read.format("parquet").load(input_edipartners).filter("isenabledflag=='1'")
df_edipartners.createOrReplaceTempView("df_edipartners")

df_edipartnertype=spark.read.format("parquet").load(input_edipartnertype).filter(("ismedicare<>'1' AND iscommercial <> '1'"))
df_edipartnertype.createOrReplaceTempView("df_edipartnertype")

#Get the non commercial and non medicare partners
df_edipartners_mh = spark.sql("""select ep.edipartnerpk
                    from df_edipartners ep
                    join  df_edipartnertype epp
                    on ep.edipartnertypefk = epp.edipartnertypepk
                    """)
df_edipartners_mh.createOrReplaceTempView("df_edipartners_mh")

df_foundcoverage=spark.read.format("delta").load(input_foundcoverage)
df_foundcoverage.createOrReplaceTempView("df_foundcoverage")
df_foundcoverage=spark.sql(""" SELECT * FROM df_foundcoverage 
                        --    WHERE TRIM(hitstatus) IN ('0','1','2')
                           WHERE TRIM(hitstatus) IN ('1','2')  
                           AND hospitalfk IN (SELECT hospitalfk FROM df_hospital_in_play) 
                           """)#Updated on 11/25/2024 for picking hitstatus 1,2 records
df_foundcoverage.createOrReplaceTempView("df_foundcoverage")

df_foundcoverage = spark.sql(""" SELECT df_foundcoverage.* FROM df_foundcoverage 
                  INNER JOIN df_edipartners_mh ON df_foundcoverage.edipartnerfk = df_edipartners_mh.edipartnerpk 
                  """).dropDuplicates()
df_foundcoverage.createOrReplaceTempView("df_foundcoverage")


# COMMAND ----------

# DBTITLE 1,Reading MH Input Join HOSPITAL Join EDIPARTNES to fetch demographics with hcsystem and payerid
df_mh_delta.createOrReplaceTempView("df_mh_delta")
df_mh_delta=spark.sql("""
                          SELECT 
			     df_mh_delta.MedicareCoverageIPK      AS transactionkey,
                          df_mh_delta.patientacctifk           AS sourcepatientacctifk,
                          df_mh_delta.MedicareHIC              AS coverageid,
                          df_mh_delta.inferredsourcemethodcode AS verifiedsource,
                          df_mh_delta.createdate,
                          df_mh_delta.updatedate,
                          df_mh_delta.HospitalFK               AS clientid,
                   SUBSTR(df_foundcoverage.dob,1,10)                AS dob,
                          df_foundcoverage.firstname,
                          df_foundcoverage.gender,
                          df_foundcoverage.lastname,
                          df_foundcoverage.middlename,
                          df_foundcoverage.ssn,
                          df_foundcoverage.addr,
                          df_foundcoverage.city,
                          df_foundcoverage.state,
                          82 as payerid,
                   SUBSTR(df_foundcoverage.zip,1,5)    AS zip,
                          CURRENT_DATE()           AS lr_createdate,
                          '6'                      AS sourcekey,
                          ''                       AS responsestatus,
                          ''                       AS groupnumber,
                          df_hospitals.hcsystemfk
                          FROM df_mh_delta 
                          INNER JOIN df_hospitals ON df_mh_delta.hospitalfk=df_hospitals.hospitalfk 
                          INNER JOIN df_foundcoverage ON 
                          df_mh_delta.HospitalFK=df_foundcoverage.hospitalfk AND 
                          df_mh_delta.FoundCoverageIFK=df_foundcoverage.foundcoverageipk AND 
                          df_mh_delta.PatientAcctIFK=df_foundcoverage.patientacctifk
                          """).withColumn("lr_creatingmodule",lit(input_bc)).withColumn("dependentflag", lit('0'))

df_mh_delta.createOrReplaceTempView("df_mh_delta")

# COMMAND ----------

# DBTITLE 1,Append MH data to LR_TRANSACTION
trange=int(5)
df_mh_delta = df_mh_delta.withColumn("transactionrange",((df_mh_delta.transactionkey).cast("bigint") % trange).cast("bigint"))
df_mh_delta.dropDuplicates().repartition(10).write.mode("append").partitionBy("transactionrange").parquet(input_lr_transaction)

# COMMAND ----------

# DBTITLE 1,Write MH data to SERVED
filterExpr="lr_creatingmodule=='"+input_bc+"'"
print(filterExpr)
df_mh_delta=spark.read.parquet(input_lr_transaction).filter(filterExpr)
df_mh_delta=df_mh_delta.selectExpr("transactionkey","clientid as hospitalfk","sourcepatientacctifk as patientacctifk","payerid","coverageid","lr_creatingmodule as bc").dropDuplicates()
df_mh_delta.repartition(10).write.mode("overwrite").parquet(input_mh_toserve)
df_mh_delta.unpersist()
