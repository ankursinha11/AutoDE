# Databricks notebook source
# This script is to log bdf file transmission details into cosmos db table
#bc = '20210413T00'
#datasource = 'es_swift'
#status = 'SENT'
#maprdbtrackingtable = "bdfstatus"
#fs_common = "/shared/hdfs/user/afshaik/CDD/oozie/bcs_permid_swift"
#this uses cosmos db jar

# COMMAND ----------

import sys
from pyspark.sql import SparkSession
import datetime
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.conf import SparkConf
from pyspark import SparkContext

# COMMAND ----------

dbutils.widgets.text("datasource","")
dbutils.widgets.getArgument("datasource")
datasource= getArgument("datasource")

dbutils.widgets.text("status", "")
dbutils.widgets.getArgument("status")
status= getArgument("status")

dbutils.widgets.text("cosmosdbtrackingtable", "")
dbutils.widgets.getArgument("cosmosdbtrackingtable")
cosmosdbtrackingtable= getArgument("cosmosdbtrackingtable")

dbutils.widgets.text("bc", "")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("cosmosendpoint", "")
dbutils.widgets.getArgument("cosmosendpoint")
cosmosendpoint = getArgument("cosmosendpoint")

# COMMAND ----------

import uuid
#cosmosEndpoint = "https://prod-icd-cosmos.documents.azure.com:443/"
#cosmosMasterKey = "l9yTfWvUEPuOtMO3lr4ibhdpaZd2c5Ii4C2c85LhJjZ2G9XYrub9Eqbh6LG7GuhmTMIRCSKnbJwFACDbyoAjpw=="
cosmosMasterKey = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-cosmos-insleads-kvsecret")
#cosmosMasterKey = "l9yTfWvUEPuOtMO3lr4ibhdpaZd2c5Ii4C2c85LhJjZ2G9XYrub9Eqbh6LG7GuhmTMIRCSKnbJwFACDbyoAjpw=="
cosmosdb = "insleads"
#cosmosContainerName = maprdbtable

cfg = {
  "spark.cosmos.accountEndpoint" : cosmosendpoint,
  "spark.cosmos.accountKey" : cosmosMasterKey,
  "spark.cosmos.database" : cosmosdb,
  "spark.cosmos.container" : cosmosdbtrackingtable,
}

# Configure Catalog Api to be used
spark.conf.set("spark.sql.catalog.cosmosCatalog", "com.azure.cosmos.spark.CosmosCatalog")
spark.conf.set("spark.sql.catalog.cosmosCatalog.spark.cosmos.accountEndpoint", cosmosendpoint)
spark.conf.set("spark.sql.catalog.cosmosCatalog.spark.cosmos.accountKey", cosmosMasterKey)
spark.conf.set("spark.sql.catalog.cosmosCatalog.spark.cosmos.views.repositoryPath", "/viewDefinitions" + str(uuid.uuid4()))

# create an Azure Cosmos DB database using catalog api
#spark.sql("CREATE DATABASE IF NOT EXISTS cosmosCatalog.{};".format(cosmosDatabaseName))

# create an Azure Cosmos DB container using catalog api
#spark.sql("CREATE TABLE IF NOT EXISTS cosmosCatalog.{}.{} using cosmos.oltp TBLPROPERTIES(partitionKeyPath = '/id', manualThroughput = '1100')".format(cosmosdb, cosmosdbtrackingtable))

# COMMAND ----------

def readfromcosmosdb(config):
    filterExpr1 = "id == '" + datasource+'-'+bc+ "'"
    df = spark.read.format("cosmos.oltp").options(**cfg).option("spark.cosmos.read.inferSchema.enabled", "true").load()
    if 'id' in df.columns:
        df = df.filter(filterExpr1).limit(1)
    return df

def writetocosmosdb(df,config):
    df.write.format("cosmos.oltp").options(**cfg).mode("APPEND").save()
    return df

# COMMAND ----------

schema = StructType([
StructField("id", StringType(), True),
StructField("bc", StringType(), True),
StructField("current_date", StringType(), True),
StructField("datasource", StringType(), True),
StructField("received_date", StringType(), True),
StructField("send_date", StringType(), True),
StructField("status", StringType(), True)
])

# COMMAND ----------

if status ==  "SENT":
    print('status:',status)
    current_dt = datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    item = [(datasource+'-'+bc, bc,current_dt, datasource,'',current_dt,status)]
    df = spark.createDataFrame(item,schema)
    writetocosmosdb(df, cfg)
else:
    print('status:',status)
    send_date = str(readfromcosmosdb(cfg).collect()[0]["send_date"])
    current_dt = datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    item = [(datasource+'-'+bc, bc,current_dt,datasource,current_dt,send_date,status)]
    df = spark.createDataFrame(item,schema)
    writetocosmosdb(df, cfg)    

# COMMAND ----------

#display(df)