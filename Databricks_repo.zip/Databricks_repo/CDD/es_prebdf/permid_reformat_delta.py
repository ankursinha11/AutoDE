# Databricks notebook source
#pyspark version for permid_reformat_delta.pig

# COMMAND ----------

#%declare cdd_dir /user/$user/CDD
#%declare inputDir '$cdd_dir/output/$datasource/bdf_validated/$bc'
#%declare outputDir '$cdd_dir/output/$datasource/bdf/$bc
#register /opt/mapr/pig/pig-0.1*/contrib/piggybank/java/piggybank.jar
#register $pig_udfs/parquet-pig-bundle-1.10.0.jar

# COMMAND ----------

dbutils.widgets.text("cdd_dir","")
dbutils.widgets.getArgument("cdd_dir")
cdd_dir= getArgument("cdd_dir")

dbutils.widgets.text("bc", "")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("datasource", "")
dbutils.widgets.getArgument("datasource")
datasource= getArgument("datasource")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

cdd_dir = baseurl+cdd_dir

print("bc:",bc)
print("cdd_dir:",cdd_dir)

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/common_util" 

# COMMAND ----------

inputDir  = cdd_dir+"/transform/"+datasource+"/bdf_validated/"+bc
outputDir = cdd_dir+"/transform/"+datasource+"/bdf/"+bc

# COMMAND ----------

#print(inputDir)
#print(outputDir)
#FixedwidthColumnlengths = [64,50,50,50,1,9,10,75,75,30,2,5,5,20,32,64]

# COMMAND ----------

FixedwidthColumnlengths = {'ID':64,'FN':50,'MN':50,'LN':50,'Gender':1,'SSN':9,'DOB':10,'Address':75,'Address2':75,'City':30,'State':2,'Zip':5,'Zip4':5,'Phone':20,'Custom1':32,'Custom2':64}

# COMMAND ----------

goodID = readparquet(spark,inputDir, "0", "na")

# COMMAND ----------

from pyspark.sql.functions import concat, format_string

#just = r"%-{width}s".format(width=20)
#rjust = r"%{width}s".format(width=20)

goodIDFixed = goodID.select(
    concat(*[format_string(r"%{width}s".format(width = i),c) for (c,i) in zip(goodID.columns,FixedwidthColumnlengths.values())]).alias("fixedWidth")
)

# COMMAND ----------

goodIDFixed.coalesce(1).write.format("text").mode('overwrite').save(outputDir)