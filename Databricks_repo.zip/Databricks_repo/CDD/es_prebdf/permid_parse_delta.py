# Databricks notebook source
# Created By:Abdul Shaik 
# Created On:3/30/2021
# Details: This script is to
#           - parse and reconcile patientaccts delta
#           - get upserts based on demographics and store to HDFS

#   bc = "20210607T11"
#   user = "afshaik"
#   tablename = "patientaccts"
#   key = "patientacctipk"
#   reconcilekey = "updatedate"
#   orderkey = "patientacctipk"
#   fs_common = "/shared/hdfs/user/afshaik/CDD/oozie/bcs_permid_swift"
#   hdfs_input ="/hceleads/user/phd9appl/leadrepo/data/raw/patientaccts/"
#   hdfs_staging ="/user/afshaik/CDD/output/escan/trackpatientacctbcs/patientaccts/"
#   hdfs_publish ="/user/afshaik/CDD/publish/escan/data/trackpatientacctbcs/current/20991231/"
# Revision: Abdul Shaik on 1/25/2021 for delta lake version change

# COMMAND ----------

import sys
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql import Row
import datetime
from pyspark.sql import *
from pyspark.sql import functions as F
from pyspark.sql.readwriter import *
import os
#import subprocess
from delta.tables import *

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/common_util" 

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/tu_data_quality"

# COMMAND ----------

dbutils.widgets.text("tablename","")
dbutils.widgets.getArgument("tablename")
tablename= getArgument("tablename")

dbutils.widgets.text("key", "")
dbutils.widgets.getArgument("key")
key= getArgument("key")

dbutils.widgets.text("bc", "")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("orderkey","")
dbutils.widgets.getArgument("orderkey")
orderkey= getArgument("orderkey")

dbutils.widgets.text("reconcilekey", "")
dbutils.widgets.getArgument("reconcilekey")
reconcilekey= getArgument("reconcilekey")

dbutils.widgets.text("hdfs_input", "")
dbutils.widgets.getArgument("hdfs_input")
hdfs_input= getArgument("hdfs_input")

dbutils.widgets.text("hdfs_staging", "")
dbutils.widgets.getArgument("hdfs_staging")
hdfs_staging= getArgument("hdfs_staging")

dbutils.widgets.text("hdfs_publish", "")
dbutils.widgets.getArgument("hdfs_publish")
hdfs_publish= getArgument("hdfs_publish")

dbutils.widgets.text("hdfs_pre_publish", "")
dbutils.widgets.getArgument("hdfs_pre_publish")
hdfs_pre_publish= getArgument("hdfs_pre_publish")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

hdfs_staging = baseurl+hdfs_staging
hdfs_input = baseurl+hdfs_input+bc
hdfs_publish = baseurl+hdfs_publish
hdfs_pre_publish = baseurl+hdfs_pre_publish

print("bc:",bc)
print("hdfs_staging:",hdfs_staging)
print("hdfs_input:",hdfs_input)
print("hdfs_publish:",hdfs_publish)
print("hdfs_pre_publish:",hdfs_pre_publish)

# COMMAND ----------

#appname = "bcs_permid_swift_parse"
#spark = common_util.getsparksession(appname)
#spark.sparkContext.setLogLevel("ERROR")
spark.sql("SET spark.databricks.delta.retentionDurationCheck.enabled = false")
spark.sql("SET spark.databricks.optimizer.dynamicPartitionPruning = true")
spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)

# COMMAND ----------

bdf_req_cols = ['hospitalfk', 'patientacctipk', 'firstname', 'lastname', 'middlename', 'addr1', 'addr2', 'city', 'state', 'zip', 'gender', 'phone1', 'dob', 'ssn']

# COMMAND ----------

df_delta_reconciled = readparquet(spark, hdfs_input + '/*', "0", "na").withColumn("HospitalFK", col("HospitalFK").cast("short")) \
    .withColumn("DemographicsUpdateDate", col("DemographicsUpdateDate").cast("timestamp")) \
    .filter("isdeleted == '0'").dropDuplicates()

# COMMAND ----------

def reconcile_data(spark, df_delta, key, reconcilekey, orderkey):
    print("Reconcile delta data")
    df_delta.createOrReplaceTempView("vw_df_delta")
    delta_reconcile_sql = """
    SELECT *
    FROM (
    SELECT *,
        ROW_NUMBER() OVER (PARTITION BY """ + key + """ ORDER BY """ + reconcilekey + """ DESC) AS rownum
    FROM vw_df_delta
    ) a
    WHERE a.rownum=1 AND a.isdeleted=0
    ORDER BY """ + orderkey
    df_delta_reconciled = spark.sql(delta_reconcile_sql)
    df_delta_reconciled = df_delta_reconciled.drop("rownum")
    return df_delta_reconciled

# COMMAND ----------

def merge_delta_data(spark, df_delta, key, delta_lake_path):
    print("Delta Writing : " + delta_lake_path )
    #from delta.tables import *
    pJoinExpression = ""
    for column in key.split(";"):
        print(column)
        pJoinExpression = pJoinExpression + "raw." + column + "=delta." + column + " AND "
    pJoinExpression = pJoinExpression.strip(" AND")
    print(pJoinExpression)
    df_raw = DeltaTable.forPath(spark, delta_lake_path)
    df_raw.alias("raw").merge(df_delta.alias("delta"), pJoinExpression).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()
    spark.read.format("delta").load(delta_lake_path).dropDuplicates().repartition(2567).write.option("dataChange", "true").format("delta").mode("overwrite").save(delta_lake_path)
    df_raw = DeltaTable.forPath(spark, delta_lake_path)
    df_raw.vacuum(0)
    return None

# COMMAND ----------

publishpath = dbutils.fs.ls(hdfs_pre_publish)
#publishpath
#len(path)

# COMMAND ----------

if (len(publishpath) == 1):
    for i in publishpath:
        print(i.path)
        if i.path == hdfs_publish:
            print("PUBLISH PATH FOUND   : LOADING DELTA : " + hdfs_publish)
            df_current = extract_deltalake_data(spark, hdfs_publish, '') 
            df_delta_upserts = df_delta_reconciled.join(df_current, (df_delta_reconciled["PatientAcctIPK"] == df_current["patientacctipk"]) & (df_delta_reconciled["HospitalFK"] == df_current["hospitalfk"]) & 
            (df_delta_reconciled["DemographicsUpdateDate"] == df_current["demographicsupdatedate"]), 'leftanti').select(df_delta_reconciled['*'])

            print ("Write BDF required columns to HDFS")
            df_cooked = df_delta_upserts.select(bdf_req_cols).dropDuplicates()
            writeparquet(spark, df_cooked, hdfs_staging + "/" + bc, 10, "overwrite")

            print("Write PAipk and demographics_update_date to Delta lake for cross reference.")
            df_delta_demog=df_delta_upserts.selectExpr("patientacctipk", 'hospitalfk', "demographicsupdatedate").dropDuplicates()
            merge_delta_data(spark, df_delta_demog, "patientacctipk;hospitalfk;demographicsupdatedate", hdfs_publish)

else:
    print("PUBLISH PATH MISSING : LOADING BASE : " + hdfs_publish)
    df_delta_demog=df_delta_reconciled.selectExpr("patientacctipk","hospitalfk","demographicsupdatedate").dropDuplicates()
    df_delta_demog.repartition(2567).write.format("delta").mode("overwrite").save(hdfs_publish)
    print ("Write BDF required columns to HDFS")
    writeparquet(spark, df_cooked, hdfs_staging + "/" + bc, 10, "overwrite")    
