# Databricks notebook source
# MAGIC %md
# MAGIC this notebook perform activities from put_bdf_swift.sh 

# COMMAND ----------

# DBTITLE 1,define input variables
dbutils.widgets.text("datasource","")
dbutils.widgets.getArgument("datasource")
datasource= getArgument("datasource")

dbutils.widgets.text("cdd_dir", "")
dbutils.widgets.getArgument("cdd_dir")
cdd_dir= getArgument("cdd_dir")

dbutils.widgets.text("bc", "")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

cdd_dir = baseurl+cdd_dir

# COMMAND ----------

# DBTITLE 1,display widget values
print(bc)
print(cdd_dir)
print(datasource)

# COMMAND ----------

#nfs_dir=/shared/hdfs$cdd_dir 
nfs_dir = cdd_dir+"/transform/"+datasource+"/package_bdf/"

# COMMAND ----------

print( "removing any remnants of previous run for same bc")
#filelist = dbutils.fs.ls(nfs_dir) #list of folder/files
#print(filelist)
#print(nfs_dir+bc)

# COMMAND ----------

# DBTITLE 1,to delete existing/same bc folders from previous runs
for i in dbutils.fs.ls(nfs_dir):
    if i.path == nfs_dir+bc+'/':
        dbutils.fs.rm(nfs_dir+bc,True)

# COMMAND ----------

# DBTITLE 1,to create directory for current run
dbutils.fs.mkdirs(nfs_dir+bc)

# COMMAND ----------

#srcfile = "abfss://nprod-icd-dev-adls@nprodicddevadlsst.dfs.core.windows.net/CddTest1" # $cdd_dir/output/$datasource/bdf/$BC
#tgtfile = "abfss://nprod-icd-dev-adls@nprodicddevadlsst.dfs.core.windows.net/CDDTest" # temp folder
#$cdd_dir/output/$datasource/bdf/$BC

# COMMAND ----------

FixedwidthDF = spark.read.text(cdd_dir+"/transform/"+datasource+"/bdf/"+bc)

# COMMAND ----------

maxfilesize = 15000000000 #for 15GB
#maxfilesize = 500000000 #1 GB testing

# COMMAND ----------

# DBTITLE 1,calculate size of input files
inputfilesize = 0
for i in dbutils.fs.ls(cdd_dir+"/transform/"+datasource+"/bdf/"+bc):
    inputfilesize = inputfilesize+i.size
#print(inputfilesize)

# COMMAND ----------

totalnooffiles = int(inputfilesize/maxfilesize)+1 # to write to multiple 15 GB files
print(totalnooffiles)

# COMMAND ----------

#FixedwidthDF.repartition(totalnooffiles).write.mode("overwrite").option("maxPartitionBytes",maxfilesize).text(nfs_dir+"/"+bc+"/mergetemp") # writes to multiple equal size files

# COMMAND ----------

# DBTITLE 1,write to output files compressed
FixedwidthDF.repartition(totalnooffiles).write.mode("overwrite").option("maxPartitionBytes",maxfilesize).text(nfs_dir+"/"+bc+"/mergetemp")

# COMMAND ----------

nfs_dir+"/"+bc+"/mergetemp"

# COMMAND ----------

#dbutils.fs.ls(nfs_dir+"/"+bc+"/mergedtxt")
#$datasource-$BC-
#cd nfs_dir/$BC
#FixedwidthDF.repartition(totalnooffiles).write.mode("overwrite").option("maxPartitionBytes",maxfilesize).option("compression","deflate").text(nfs_dir+"/"+bc+"/mergetemp") # writes to multiple equal size files

# COMMAND ----------

# DBTITLE 1,moving and renaming files created
for i in dbutils.fs.ls(nfs_dir+"/"+bc+"/mergetemp"):
    if '.txt' in i.path and totalnooffiles >0:
        dbutils.fs.mv(i.path,nfs_dir+"/"+bc+"/"+datasource+"-"+bc+'-'+str(totalnooffiles))
        totalnooffiles=totalnooffiles-1

# COMMAND ----------

#use adf copy activity to zip files and alo to update to Ftp site (once available)