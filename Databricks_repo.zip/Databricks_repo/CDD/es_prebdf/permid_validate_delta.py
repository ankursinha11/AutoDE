# Databricks notebook source
# Details: This script is to validate the patientaccts delta data from ABI as part of bcs permid assignment process.

# COMMAND ----------

import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.conf import SparkConf
from pyspark import SparkContext
spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/common_util" 

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/tu_data_quality"

# COMMAND ----------


dbutils.widgets.text("hdfs_input","")
dbutils.widgets.getArgument("hdfs_input")
hdfs_input= getArgument("hdfs_input")

dbutils.widgets.text("hdfs_output", " ")
dbutils.widgets.getArgument("hdfs_output")
hdfs_output= getArgument("hdfs_output")

dbutils.widgets.text("hdfs_reject", " ")
dbutils.widgets.getArgument("hdfs_reject")
hdfs_reject= getArgument("hdfs_reject")

dbutils.widgets.text("bc", " ")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("hdfs_scrub_output", " ")
dbutils.widgets.getArgument("hdfs_scrub_output")
hdfs_scrub_output= getArgument("hdfs_scrub_output")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

hdfs_input = baseurl+hdfs_input
hdfs_output = baseurl+hdfs_output
hdfs_reject = baseurl+hdfs_reject
hdfs_scrub_output = baseurl+hdfs_scrub_output

print("bc:",bc)
print("hdfs_input:",hdfs_input)
print("hdfs_output:",hdfs_output)
print("hdfs_reject:",hdfs_reject)
print("hdfs_scrub_output:",hdfs_scrub_output)

# COMMAND ----------

#print("Scrub and validate delta")  
#cleanpa = validate_delta(goodpa, bc)
#cleanpa = cleanpa.select(bdf_req_cols).dropDuplicates()

# COMMAND ----------

def filter_badpa(spark, df_delta, hdfs_reject):
    badpa = df_delta.filter(df_delta.patientacctipk.isNull() | (df_delta.patientacctipk == '') | df_delta.patientacctipk.rlike("[^0-9]") | df_delta.hospitalfk.isNull() | (df_delta.hospitalfk == ''))
    goodpa = df_delta.exceptAll(badpa)
    badpa = badpa.dropDuplicates()
    writeparquet(spark, badpa, hdfs_reject, 1, "overwrite")
    return goodpa

# COMMAND ----------

def validate_delta(df_delta, bc):
    # Trim, conv to upcase and remove non printable characters
    for column in df_delta.columns:
        df_delta = df_delta.withColumn(column, regexp_replace(col(column), r'[^\x00-\x7f]', r''))
        df_delta = df_delta.withColumn(column, trim(col(column)))
        df_delta = df_delta.withColumn(column, upper(col(column)))

    # Create validation UDF functions
    isValidName_udf = udf(isValidName, IntegerType())
    isValidDOB_udf = udf(isValidDOB, IntegerType())
    isValidSSN_udf = udf(isValidSSN, IntegerType())
    isValidCity_udf = udf(isValidCity, IntegerType())
    isValidState_udf = udf(isValidState, IntegerType())
    isValidPhone_udf = udf(isValidPhone, IntegerType())
    isValidZip5_udf = udf(isValidZip5, IntegerType())
    isValidString_udf = udf(isValidString, IntegerType())
    isValidNumber_udf = udf(isNumber, IntegerType())

    # Cleanse and trim
    pa = df_delta.withColumn('zip5',df_delta.zip[1:5])
    pa = pa.withColumn('zip4',pa.zip[6:9])
    pa = pa.withColumn('ssn', regexp_replace(pa.ssn, '-', ''))
    pa = pa.withColumn('phone1', regexp_replace(pa.phone1, '[^0-9]', ''))
    pa = pa.withColumn('city', regexp_replace(pa.city, 'XX', ''))
    pa = pa.withColumn('city', regexp_replace(pa.city, 'YY', ''))
    pa = pa.withColumn('city', regexp_replace(pa.city, '[^A-Za-z\s]', ''))
    pa = pa.withColumn('city', trim(pa.city))
    pa = pa.withColumn('state', regexp_replace(pa.state, 'XX', ''))
    pa = pa.withColumn('state', regexp_replace(pa.state, 'YY', ''))
    pa = pa.withColumn('state', regexp_replace(pa.state, '[^A-Za-z\s]', ''))
    pa = pa.withColumn('state', trim(pa.state))

    # Replace invalid or null with ""
    pa = pa.withColumn('ID', concat_ws("_",pa.hospitalfk,pa.patientacctipk))
    pa = pa.withColumn('FN', when(isValidName_udf(pa.firstname) == 1, pa.firstname).otherwise(''))
    pa = pa.withColumn('MN', when(isValidString_udf(pa.middlename) == 1, pa.middlename).otherwise(''))
    pa = pa.withColumn('LN', when(isValidName_udf(pa.lastname) == 1, pa.lastname).otherwise(''))
    pa = pa.withColumn('Gender', when(isValidString_udf(pa.gender) == 1, pa.gender).otherwise(''))
    pa = pa.withColumn('SSN', when(isValidSSN_udf(pa.ssn) == 1, pa.ssn).otherwise(''))
    pa = pa.withColumn('DOB', when(isValidDOB_udf(pa.dob) == 1, to_date(pa.dob, 'yyyy-MM-dd')).otherwise(''))
    pa = pa.withColumn('Address', when(isValidString_udf(pa.addr1) == 1, pa.addr1).otherwise(''))
    pa = pa.withColumn('Address2', when(isValidString_udf(pa.addr2) == 1, pa.addr2).otherwise(''))
    pa = pa.withColumn('City', when(isValidCity_udf(pa.city) == 1, pa.city).otherwise(''))
    pa = pa.withColumn('State', when(isValidState_udf(pa.state) == 1, pa.state).otherwise(''))
    pa = pa.withColumn('Zip', when(isValidZip5_udf(pa.zip5) == 1, pa.zip5).otherwise(''))
    pa = pa.withColumn('Zip4', when(isValidString_udf(pa.zip4) == 1, pa.zip4).otherwise(''))
    pa = pa.withColumn('Phone', when(isValidPhone_udf(pa.phone1) == 1, pa.phone1).otherwise(''))
    pa = pa.withColumn('Custom1', lit('es_swift'))
    pa = pa.withColumn('Custom2', lit(bc))

    #Adding columns for postbdf to merge back orig pa data
    pa = pa.withColumn('GMRNId', lit(''))
    pa = pa.withColumn('HospId', pa.hospitalfk)
    pa = pa.withColumn('PatientAcctId', pa.patientacctipk)
    pa = pa.withColumn('Address1', pa.Address)
    pa = pa.withColumn('CoverageKnownFlag', lit(''))

    return pa

# COMMAND ----------


print("Read parsed delta patientaccts")
df_delta = readparquet(spark, hdfs_input + bc + '/*', "0", "na").dropDuplicates()

print("Validate PAIPK(ID)- if not valid reject and store recs in file")
goodpa = filter_badpa(spark, df_delta,  hdfs_reject + "/" + bc)

print("Scrub and validate delta")
cleanpa = validate_delta(goodpa, bc)

print("Save scrubbed patientaccts to HDFS for es_swift_postbdf process to merge back with pa'accts orig data")
postbdf_req_cols = ['GMRNId', 'HospId', 'PatientAcctId', 'FN', 'MN', 'LN', 'Gender', 'DOB', 'SSN', 'Phone', 'Address1', 'Address2', 'City', 'State', 'Zip', 'Zip4', 'CoverageKnownFlag']
origpa = cleanpa.select(postbdf_req_cols).dropDuplicates()
writecsv(spark, origpa, hdfs_scrub_output + "/" + bc, 10, "overwrite", "|")

bdf_req_cols = ['ID', 'FN', 'MN', 'LN', 'Gender', 'SSN', 'DOB', 'Address', 'Address2', 'City', 'State', 'Zip', 'Zip4', 'Phone', 'Custom1', 'Custom2']
print("Save clean patientaccts to HDFS")
cleanpa = cleanpa.select(bdf_req_cols).dropDuplicates()
writeparquet(spark, cleanpa, hdfs_output + "/" + bc, 10, "overwrite")
