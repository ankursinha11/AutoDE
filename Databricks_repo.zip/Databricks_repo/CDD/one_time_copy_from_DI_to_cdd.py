# Databricks notebook source
dbutils.widgets.text("catalog_name","")
catalog_name=dbutils.widgets.get("catalog_name")

dbutils.widgets.text("source_schema","")
source_schema=dbutils.widgets.get("source_schema")

dbutils.widgets.text("dest_schema","")
dest_schema=dbutils.widgets.get("dest_schema")

# COMMAND ----------

# DBTITLE 1,copy AddressList
sql_stmt = f"""
INSERT INTO {catalog_name}.{dest_schema}.AddressList
SELECT * FROM {catalog_name}.{source_schema}.AddressList
"""
spark.sql(sql_stmt)

# COMMAND ----------

# DBTITLE 1,copy GlobalMRNFamilyAssociations
sql_stmt = f"""
INSERT INTO {catalog_name}.{dest_schema}.GlobalMRNFamilyAssociations
SELECT * FROM {catalog_name}.{source_schema}.GlobalMRNFamilyAssociations
"""
spark.sql(sql_stmt)

# COMMAND ----------

# DBTITLE 1,copy PatientAcctsAddress
sql_stmt = f"""
INSERT INTO {catalog_name}.{dest_schema}.PatientAcctsAddress
SELECT * FROM {catalog_name}.{source_schema}.PatientAcctsAddress
"""
spark.sql(sql_stmt)
