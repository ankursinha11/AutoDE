# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("input_path","")
dbutils.widgets.getArgument("input_path")
input_path= getArgument("input_path")

dbutils.widgets.text("output_path","")
dbutils.widgets.getArgument("output_path")
output_path= getArgument("output_path")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bcdate","")
dbutils.widgets.getArgument("bcdate")
bcdate= getArgument("bcdate")

dbutils.widgets.text("cdd_dir","")
dbutils.widgets.getArgument("cdd_dir")
cdd_dir= getArgument("cdd_dir")


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 


input_path = baseurl + cdd_dir + input_path + bcdate 



rej_output_path = baseurl + cdd_dir + output_path + 'rejected/' + bcdate 
fil_output_path = baseurl + cdd_dir + output_path + 'filtered/' + bcdate 
bad_output_path = baseurl + cdd_dir + output_path + 'wBadChars/' + bcdate 

print(cdd_dir,'\ninputPath: ',input_path,'\noutputPath: ',rej_output_path,'\n',fil_output_path,'\n',bad_output_path)

# COMMAND ----------

# DBTITLE 1,Common Util
# MAGIC %run "/Insleads-code/Common-Util/common_util"

# COMMAND ----------

import sys,re
from pyspark.sql.types import *
from pyspark.sql.functions import *

# COMMAND ----------

input_schema= StructType([
     StructField("TraceNumber", StringType(), True),
     StructField("Received", StringType(), True),
     StructField("providerId", StringType(), True),
     StructField("providerLastNameOrgName", StringType(), True),
     StructField("subscriberLastName", StringType(), True),
     StructField("subscriberFirstName", StringType(), True),
     StructField("subscriberMiddleName", StringType(), True),
     StructField("subscriberGender", StringType(), True),
     StructField("subscriberDOB", StringType(), True),
     StructField("subscriberSSN", StringType(), True),
     StructField("subscriberGroupNumber", StringType(), True),
     StructField("subscriberSuffixCode", StringType(), True),
     StructField("subscriberIdCode", StringType(), True),
     StructField("subscriberId", StringType(), True),
     StructField("subscriberAddress", StringType(), True),
     StructField("subscriberState", StringType(), True),
     StructField("subscriberCity", StringType(), True),
     StructField("subscriberZip", StringType(), True),
     StructField("dependentLastName", StringType(), True),
     StructField("dependentFirstName", StringType(), True),
     StructField("dependentGender", StringType(), True),
     StructField("dependentDOB", StringType(), True),
     StructField("dependentSSN", StringType(), True),
     StructField("dateOfService", StringType(), True),
     StructField("ResponseResultExt", StringType(), True),
     StructField("ResponseResultStd", StringType(), True),
     StructField("payerId", StringType(), True),
     StructField("payerProviderId", StringType(), True),
     StructField("payerLastNameOrgName", StringType(), True),
     StructField("clientId", StringType(), True),
     StructField("breadcrumb", StringType(), True)
])


# COMMAND ----------

# df=spark.read.csv(baseurl+input_path+'23MAY2023-18',schema=input_schema,sep="|")
df=spark.read.csv(input_path,schema=input_schema,sep="|")

# COMMAND ----------

ieSubRecords = df.filter(
    (df["dependentFirstName"].isNull() | (df["dependentFirstName"] == "") | (df["dependentFirstName"] == "XX")) &
    (df["dependentLastName"].isNull() | (df["dependentLastName"] == "") | (df["dependentLastName"] == "XX")) &
    (df["dependentDOB"].isNull() | (df["dependentDOB"] == "") | (df["dependentDOB"] == "00000000")) &
    (df["dependentSSN"].isNull() | (df["dependentSSN"] == "") | (df["dependentSSN"] == "000000000")) &
    (df["dependentGender"].isNull() | (df["dependentGender"] == "") | (df["dependentGender"] == "X"))
)
ieDepRecords = df.subtract(ieSubRecords)

# COMMAND ----------

ieSubs = ieSubRecords.select('TraceNumber',lit('00DS00ie00SUB00'), 
  'breadcrumb', 
  'subscriberFirstName', 'subscriberMiddleName', 'subscriberLastName', 
  'subscriberDOB', 'subscriberSSN', lit(''), 'subscriberAddress', 
  'subscriberCity','subscriberState', 'subscriberZip', lit(''), lit(''), 'subscriberGender')

ieDepSubs = ieDepRecords.select('TraceNumber',lit('00DS00ie00DEPSUB00'), 
  'breadcrumb', 
  'subscriberFirstName', 'subscriberMiddleName', 'subscriberLastName', 
  'subscriberDOB', 'subscriberSSN', lit(''), 'subscriberAddress', 
  'subscriberCity','subscriberState', 'subscriberZip', lit(''), lit(''), 'subscriberGender')

# COMMAND ----------

ieDeps = ieDepRecords.select(concat(lit('D'),'TraceNumber'),lit('00DS00ie00DEP00'), 
  'breadcrumb', 
  'dependentFirstName', lit(''), 'dependentLastName', 
  'dependentDOB', 'dependentSSN', lit(''), 'subscriberAddress', 
  'subscriberCity','subscriberState', 'subscriberZip', lit(''), lit(''), 'dependentGender')

# COMMAND ----------

ieAll = ieSubs.union(ieDepSubs).union(ieDeps)

# COMMAND ----------

fdf =ieAll.toDF('ID','Custom1','Custom2','FN','MN','LN','DOB','SSN', 'Phone','Address','City', 'State','Zip', 'Zip4', 'Address2','Gender')

# COMMAND ----------

badID=fdf.filter((fdf["ID"].isNull()) | (fdf["ID"]  == "") | ~(fdf["ID"].rlike('(D)?[0-9]+') ) )
# |  (~fdf["ID"].startswith('D') )
goodID=fdf.filter(fdf["ID"].isNotNull() & (fdf["ID"]  != "") & (fdf["ID"].rlike('(D)?[0-9]+') )  )
#& (fdf["ID"].startswith('D') )

# COMMAND ----------

import math
def hasMultibyteChar(*args):
  for arg in args:
    for i in arg:
      if (ord(i) <= 31 or ord(i) >= 127):
        return True;
  return False;

# COMMAND ----------

hasMultibyteCharudf = udf(hasMultibyteChar,BooleanType())

# COMMAND ----------

badRecs = goodID.filter(
    hasMultibyteCharudf(
        when(col("FN").isNull(), "").otherwise(col("FN")),
        when(col("MN").isNull(), "").otherwise(col("MN")),
        when(col("LN").isNull(), "").otherwise(col("LN")),
        when(col("Address").isNull(), "").otherwise(col("Address"))
    )
)

goodRecs = goodID.filter(
    ~hasMultibyteCharudf(
        when(col("FN").isNull(), "").otherwise(col("FN")),
        when(col("MN").isNull(), "").otherwise(col("MN")),
        when(col("LN").isNull(), "").otherwise(col("LN")),
        when(col("Address").isNull(), "").otherwise(col("Address"))
    )
)

# COMMAND ----------

badID.write.mode("overwrite").csv(rej_output_path,sep="|")

# COMMAND ----------

badRecs.write.mode("overwrite").csv(bad_output_path,sep="|")

# COMMAND ----------

goodRecs.write.mode("overwrite").csv(fil_output_path,sep="|")
