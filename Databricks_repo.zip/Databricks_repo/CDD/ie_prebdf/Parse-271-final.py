# Databricks notebook source
pip install elementpath==4.1.4

# COMMAND ----------

# DBTITLE 1,Input Variables:
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("cdd_dir","")
dbutils.widgets.getArgument("cdd_dir")
cdd_dir= getArgument("cdd_dir")

dbutils.widgets.text("input_path","")
dbutils.widgets.getArgument("input_path")
input_path= getArgument("input_path")

dbutils.widgets.text("output_path","")
dbutils.widgets.getArgument("output_path")
output_path= getArgument("output_path")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bcdate","")
dbutils.widgets.getArgument("bcdate")
bcdate= getArgument("bcdate")


##DEFINING INPUT AND OUTPUT PATHS:
# ie_output_dir = "abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/karthik/data/cdd/transform/ie/parsed271"
# baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
# cdd_dir = cdd_dir.format(user)
# input_path = baseurl + input_path.format(cdd_dir, bcdate)
# output_path = baseurl + output_path.format(cdd_dir,bcdate)
# print(cdd_dir,'\ninputPath: ',input_path,'\noutputPath: ',output_path)

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))


# COMMAND ----------

# DBTITLE 1,Set Base URL

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

# DBTITLE 1,Setting up Input & Output Path

input_path = baseurl + cdd_dir + input_path + bcdate
output_path = baseurl + cdd_dir + output_path  + bcdate 
print(cdd_dir,'\ninputPath: ',input_path,'\noutputPath: ',output_path)




# COMMAND ----------

# DBTITLE 1,Importing Dependencies:

from pyspark.sql.types import StringType
import xml.etree.ElementTree as ET
from pyspark.sql.functions import udf, split 


ie_output_dir = output_path
ie_input_dir = input_path
ie_input_dir,ie_output_dir


# COMMAND ----------

# DBTITLE 1,Parsing XML:
def parse_xml(data):
    resp3 = None
    root = ET.fromstring(data)    
    node = [node for node in list(root) if node.tag.endswith('Requests')]
    node1 = [node1 for node1 in list(node[0]) if node1.tag.endswith('SubmissionRequest')]
    PR = [node2 for node2 in list(node1[0]) if node2.tag.endswith('PayerResponse')][0]
    tracenumber = [TN for TN in list(PR) if TN.tag.endswith('TraceNumber')][0].text
    subscriberid = PR.find(".//HL[@HL01='3']/NM1[@NM108='MI']")
    depsubscriberid = PR.find(".//HL[@HL01='4']/NM1[@NM108='MI']")
    try:
        if depsubscriberid != None:
            resp3 = "{}|{}".format(tracenumber, depsubscriberid.attrib['NM109'].upper().replace('-','').replace(' ',''))
        elif subscriberid != None:
            resp3 = "{}|{}".format(tracenumber, subscriberid.attrib['NM109'].upper().replace('-','').replace(' ',''))
        else:
            resp3 = "{}|".format(tracenumber)
    except:
        resp3 = "{}|".format(tracenumber)
    return resp3

parse_xml_udf = udf(parse_xml, StringType())


# COMMAND ----------

# DBTITLE 1,Generating Output:

df = spark.read.text(ie_input_dir)
df = df.select(split("value",",",2).getItem(1).alias('value'))
df = df.withColumn("value", parse_xml_udf(df['value']))
df.write.mode('overwrite').text(ie_output_dir)