# Databricks notebook source
pip install elementpath==4.1.4

# COMMAND ----------

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("cdd_dir","")
dbutils.widgets.getArgument("cdd_dir")
cdd_dir= getArgument("cdd_dir")

dbutils.widgets.text("input_path","")
dbutils.widgets.getArgument("input_path")
input_path= getArgument("input_path")

dbutils.widgets.text("output_path","")
dbutils.widgets.getArgument("output_path")
output_path= getArgument("output_path")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bcdate","")
dbutils.widgets.getArgument("bcdate")
bcdate= getArgument("bcdate")


##DEFINING INPUT AND OUTPUT PATHS:
# baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
# cdd_dir = cdd_dir.format(user)
# input_path = baseurl + input_path.format(cdd_dir, bcdate)
# output_path = baseurl + output_path.format(cdd_dir,bcdate)
# print(cdd_dir,'\ninputPath: ',input_path,'\noutputPath: ',output_path)




# COMMAND ----------

# DBTITLE 1,Set Base URL

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

# DBTITLE 1,Setting up Input & Output Path

data_path_input = baseurl + cdd_dir + input_path + bcdate
data_path_opt2 = baseurl + cdd_dir + output_path  + bcdate 
print('\ninputPath: ',data_path_input,'\noutputPath: ',data_path_opt2)

data_path_temp = "/".join(data_path_input.split("/")[:-2]) + "/271_cleansed_tmp"
data_path_opt1 = "/".join(data_path_input.split("/")[:-2]) + "/271_cleansed_lr"
print("data_path_temp: ",data_path_temp,"\ndata_path_opt1: ",data_path_opt1)

# COMMAND ----------

# used for test
# data_path_input = "abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/cdd/intermediate_tmp/ie/271_parsed/20231017T17"
# data_path_opt2 = "abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/cdd/transform/output/parsed_270/20231017T17"

# data_path_temp = "/".join(data_path_input.split("/")[:-2]) + "/271_cleansed_tmp"
# data_path_opt1 = "/".join(data_path_input.split("/")[:-2]) + "/271_cleansed_lr"
# print("data_path_temp: ",data_path_temp,"\ndata_path_opt1: ",data_path_opt1)

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

import datetime
from pyspark.sql.functions import *
import datetime
from pyspark.sql.types import *
from  pyspark.sql.functions import input_file_name

# conf = SparkConf()
# sc = SparkContext(conf=conf)
# sc.setLogLevel('ERROR')

# data_path_input = "abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/karthik/data/cdd/intermediate_tmp/ie/271_parsed"
# data_path_temp = "abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/karthik/data/cdd/intermediate_tmp/ie/271_cleansed_tmp"
# data_path_opt1 = "abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/karthik/data/cdd/intermediate_tmp/ie/271_cleansed_lr"
# data_path_opt2 = "abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/karthik/data/cdd/intermediate_tmp/ie/parsed_270"


parsed_schema = StructType([
    StructField("St01", StringType()),
    StructField("TraceNumber", StringType()),
    StructField("PayerId", StringType()),
    StructField("ClientId", StringType()),
    StructField("ResponseResultStd", StringType()),
    StructField("ResponseResultExt", StringType()),
    StructField("subscriberGroupNumber", StringType()),
    StructField("dependentGroupNumber", StringType()),
    StructField("subscriberCoverageId", StringType()),
    StructField("dependentCoverageId", StringType()),
    StructField("subscriberId", StringType()),
    StructField("Received", StringType()),
    StructField("providerId", StringType()),
    StructField("providerLastNameOrgName", StringType()),
    StructField("payerProviderId", StringType()),
    StructField("payerLastNameOrgName", StringType()),
    StructField("dateOfService", StringType()),
    StructField("subscriberSuffixCode", StringType()),
    StructField("subscriberIdCode", StringType()),
    StructField("subscriberLastName", StringType()),
    StructField("subscriberFirstName", StringType()),
    StructField("subscriberMiddleName", StringType()),
    StructField("subscriberAddress", StringType()),
    StructField("subscriberCity", StringType()),
    StructField("subscriberState", StringType()),
    StructField("subscriberZip", StringType()),
    StructField("subscriberDOB", StringType()),
    StructField("subscriberGender", StringType()),
    StructField("subscriberSSN", StringType()),
    StructField("dependentLastName", StringType()),
    StructField("dependentFirstName", StringType()),
    StructField("dependentMiddleName", StringType()),
    StructField("dependentAddress", StringType()),
    StructField("dependentCity", StringType()),
    StructField("dependentState", StringType()),
    StructField("dependentZip", StringType()),
    StructField("dependentDOB", StringType()),
    StructField("dependentGender", StringType()),
    StructField("dependentSSN", StringType())
    ,StructField("breadcrumb", StringType())
])

cdd_data = spark.read.format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", delimiter='|').schema(parsed_schema).load(data_path_input).dropDuplicates()


# COMMAND ----------


for column in cdd_data.columns:
    cdd_data = cdd_data.withColumn(column, trim(col(column)))
    cdd_data = cdd_data.withColumn(column, when(col(column).isNull(), None).otherwise(col(column)))
    cdd_data = cdd_data.withColumn(column, when(col(column) == '', None).otherwise(col(column)))
    cdd_data = cdd_data.withColumn(column, when(col(column) == 'null', None).otherwise(col(column)))
    cdd_data = cdd_data.withColumn(column, upper(col(column)))

cdd_data.createOrReplaceTempView("cdd_data")
# Removing invalid TraceNumber
cdd_data = spark.sql("""SELECT * FROM cdd_data WHERE TRIM(TraceNumber) IS NOT NULL OR TRIM(TraceNumber) <> '' """)

cdd_data.createOrReplaceTempView("cdd_data")
# Removing Invalid Responses

# Snippet from PYTHON UTIL 
# def isValidResponseType(responsestd, responseext):
#     if responsestd is not None and str(responsestd).strip() == "3" and (responseext is None or str(responseext).strip() == "" or str(responseext).strip().lower() == "null"):
#         return 0
#     return 1

# OLD Filter Logic
# cdd_data = spark.sql("""SELECT * FROM cdd_data WHERE CAST(TRIM(ResponseResultStd) AS BIGINT) <> 3 AND (TRIM(ResponseResultExt) <> '' OR TRIM(ResponseResultExt) IS NOT NULL)""")

# NEW Filter Logic as per python util function
# cdd_data = spark.sql("""
# SELECT cdd_data.*,
#        CASE
#          WHEN (cdd_data.ResponseResultStd IS NOT NULL AND cdd_data.ResponseResultStd = '3' AND (cdd_data.ResponseResultExt IS NULL OR TRIM(cdd_data.ResponseResultExt) = '' OR LOWER(TRIM(cdd_data.ResponseResultExt))='null')) THEN '0'
#          ELSE '1'
#        END AS isValidResponseType
# FROM cdd_data
# """).filter("isValidResponseType=='1'").drop("isValidResponseType")

cdd_data=spark.sql(""" SELECT * FROM cdd_data WHERE CAST(ResponseResultStd AS BIGINT) NOT IN ('0','3','4','5','7','8','10','15','16','17','312','313','314') """)

cdd_data.createOrReplaceTempView("cdd_data")

# Removing everything other than 271 response
cdd_data = spark.sql("""SELECT * FROM cdd_data WHERE CAST(TRIM(St01) AS BIGINT) ='271'""").drop("St01")

cdd_data.createOrReplaceTempView("cdd_data")
# Removing the VA Veteran Records
cdd_data = spark.sql(""" SELECT * FROM cdd_data WHERE CAST(TRIM(ClientId) AS BIGINT) <> '100515' """)

for column in cdd_data.columns:
    cdd_data = cdd_data.withColumn(column, trim(col(column)))
    cdd_data = cdd_data.withColumn(column, when(col(column).isNull(), 'XX').otherwise(col(column)))
    cdd_data = cdd_data.withColumn(column, when(col(column) == '', 'XX').otherwise(col(column)))
    cdd_data = cdd_data.withColumn(column, when(col(column) == 'null', 'XX').otherwise(col(column)))

cdd_data.dropDuplicates().repartition(20).write.mode('overwrite').parquet(data_path_temp)
cdd_data.unpersist()

cdd_data = spark.read.parquet(data_path_temp)
cdd_data = cdd_data.repartition(200)
cdd_data.createOrReplaceTempView("cdd_data")
cdd_data = spark.sql("""
SELECT TraceNumber,
       PayerId,
       ClientId,
       ResponseResultStd,
       ResponseResultExt,
       CASE
         WHEN (TRIM(subscriberGroupNumber) IS NULL OR
               TRIM(subscriberGroupNumber) = ' ' OR
               TRIM(subscriberGroupNumber) = '' OR
               TRIM(subscriberGroupNumber) = 'null' OR
               TRIM(subscriberGroupNumber) = 'XX') THEN 'XX'
         ELSE REGEXP_REPLACE(TRIM(subscriberGroupNumber),'[^-a-zA-Z0-9]+', '')
       END AS subscriberGroupNumber,
       CASE
         WHEN (TRIM(dependentGroupNumber) IS NULL OR
               TRIM(dependentGroupNumber) = ' ' OR
               TRIM(dependentGroupNumber) = '' OR
               TRIM(dependentGroupNumber) = 'null' OR
               TRIM(dependentGroupNumber) = 'XX') THEN 'XX'
         ELSE REGEXP_REPLACE(TRIM(dependentGroupNumber),'[^-a-zA-Z0-9]+', '')
       END AS dependentGroupNumber,
       CASE
         WHEN (TRIM(subscriberCoverageId) IS NULL OR
               TRIM(subscriberCoverageId) = ' ' OR
               TRIM(subscriberCoverageId) = '' OR
               TRIM(subscriberCoverageId) = 'null' OR
               TRIM(subscriberCoverageId) = 'XX') THEN 'XX'
         ELSE REGEXP_REPLACE(TRIM(subscriberCoverageId),'[^-a-zA-Z0-9]+', '')
       END AS subscriberCoverageId,
       CASE
         WHEN (TRIM(dependentCoverageId) IS NULL OR
               TRIM(dependentCoverageId) = ' ' OR
               TRIM(dependentCoverageId) = '' OR
               TRIM(dependentCoverageId) = 'null' OR
               TRIM(dependentCoverageId) = 'XX') THEN 'XX'
         ELSE REGEXP_REPLACE(TRIM(dependentCoverageId),'[^-a-zA-Z0-9]+', '')
       END AS dependentCoverageId,
       CASE
         WHEN (TRIM(subscriberId) IS NULL OR
               TRIM(subscriberId) = ' ' OR
               TRIM(subscriberId) = '' OR
               TRIM(subscriberId) = 'null' OR
               TRIM(subscriberId) = 'XX') THEN 'XX'
         ELSE REGEXP_REPLACE(TRIM(subscriberId),'[^-a-zA-Z0-9]+', '')
       END AS subscriberId,
       Received,
       providerId,
       providerLastNameOrgName,
       payerProviderId,
       payerLastNameOrgName,
       dateOfService,
       subscriberSuffixCode,
       subscriberIdCode,
       subscriberLastName,
       subscriberFirstName,
       subscriberMiddleName,
       subscriberAddress,
       subscriberCity,
       subscriberState,
       subscriberZip,
       subscriberDOB,
       subscriberGender,
       REGEXP_REPLACE(TRIM(subscriberSSN),'-','') as subscriberSSN,
       dependentLastName,
       dependentFirstName,
       dependentMiddleName,
       dependentAddress,
       dependentCity,
       dependentState,
       dependentZip,
       dependentDOB,
       dependentGender,
       REGEXP_REPLACE(TRIM(dependentSSN),'-','') as dependentSSN,
       breadcrumb
FROM cdd_data
""")

cdd_data.createOrReplaceTempView("cdd_data")

cdd_data = spark.sql("""
SELECT TraceNumber,
       PayerId,
       ClientId,
       ResponseResultStd,
       ResponseResultExt,
       CASE WHEN (subscriberGroupNumber = 'XX' AND dependentGroupNumber <> 'XX') THEN dependentGroupNumber  ELSE subscriberGroupNumber END AS subscriberGroupNumber,
       dependentGroupNumber,
       CASE WHEN (subscriberCoverageId = 'XX'  AND dependentCoverageId  <> 'XX')  THEN dependentCoverageId  ELSE subscriberCoverageId  END AS subscriberCoverageId,
       CASE WHEN (dependentCoverageId  = 'XX'  AND subscriberCoverageId <> 'XX')  THEN subscriberCoverageId ELSE dependentCoverageId   END AS dependentCoverageId,
       subscriberId,
       Received,
       providerId,
       providerLastNameOrgName,
       payerProviderId,
       payerLastNameOrgName,
       dateOfService,
       subscriberSuffixCode,
       subscriberIdCode,
       subscriberLastName,
       subscriberFirstName,
       subscriberMiddleName,
       subscriberAddress,
       subscriberCity,
       CASE
          WHEN (
                LENGTH(UPPER(TRIM(subscriberState))) = '2' AND
                UPPER(TRIM(subscriberState)) IN ('AS','GU','MP','PR','VI','UM','AL','AK','AZ','AR','CA','CO','CT','DE','DC','FL','GA','HI','ID','IL','IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VT','VA','WA','WV','WI','WY')
                ) THEN subscriberState
          ELSE 'XX' END AS subscriberState,
       subscriberZip,
       CASE WHEN subscriberDOB='XX' THEN '00000000' ELSE subscriberDOB END AS subscriberDOB,
       CASE WHEN UPPER(TRIM(subscriberGender)) IN ('M','F') THEN subscriberGender ELSE 'X' END AS subscriberGender,
       REGEXP_REPLACE(TRIM(subscriberSSN),'[^-a-zA-Z0-9]+', '') AS subscriberSSN,
       dependentLastName,
       dependentFirstName,
       dependentMiddleName,
       dependentAddress,
       dependentCity,
       CASE
          WHEN (
                LENGTH(UPPER(TRIM(dependentState))) = '2' AND
                UPPER(TRIM(dependentState)) IN ('AS','GU','MP','PR','VI','UM','AL','AK','AZ','AR','CA','CO','CT','DE','DC','FL','GA','HI','ID','IL','IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VT','VA','WA','WV','WI','WY')
                ) THEN dependentState
          ELSE 'XX' END AS dependentState,
       dependentZip,
       CASE WHEN dependentDOB='XX' THEN '00000000' ELSE dependentDOB END AS dependentDOB,
       CASE WHEN UPPER(TRIM(dependentGender)) IN ('M','F') THEN dependentGender ELSE 'X' END AS dependentGender,
       REGEXP_REPLACE(TRIM(dependentSSN),'[^-a-zA-Z0-9]+', '')                               AS dependentSSN,
       breadcrumb
FROM cdd_data
""")

for column in cdd_data.columns:
    cdd_data = cdd_data.withColumn(column, trim(col(column)))
    cdd_data = cdd_data.withColumn(column, when(col(column).isNull(), 'XX').otherwise(col(column)))
    cdd_data = cdd_data.withColumn(column, when(col(column) == '', 'XX').otherwise(col(column)))
    cdd_data = cdd_data.withColumn(column, when(col(column) == 'null', 'XX').otherwise(col(column)))

cdd_data.createOrReplaceTempView("cdd_data")

cdd_data = spark.sql("""
SELECT TraceNumber,
       PayerId,
       ClientId,
       ResponseResultStd,
       ResponseResultExt,
       subscriberGroupNumber,
       dependentGroupNumber,
       CASE WHEN (REGEXP_REPLACE(subscriberCoverageId,"-","") = 'XX' AND REGEXP_REPLACE(subscriberId,"-","") <> 'XX') THEN REGEXP_REPLACE(subscriberId,"-","") ELSE REGEXP_REPLACE(subscriberCoverageId,"-","") END AS subscriberCoverageId,
       CASE WHEN (REGEXP_REPLACE(dependentCoverageId,"-","") = 'XX'  AND REGEXP_REPLACE(subscriberCoverageId,"-","") = 'XX'  AND REGEXP_REPLACE(subscriberId,"-","") <> 'XX') THEN REGEXP_REPLACE(subscriberId,"-","") ELSE REGEXP_REPLACE(dependentCoverageId,"-","")  END AS dependentCoverageId,
       REGEXP_REPLACE(subscriberId,"-","") AS subscriberId,
       Received,
       providerId,
       providerLastNameOrgName,
       payerProviderId,
       payerLastNameOrgName,
       dateOfService,
       subscriberSuffixCode,
       subscriberIdCode,
       subscriberLastName,
       subscriberFirstName,
       subscriberMiddleName,
       CASE WHEN (subscriberLastName <>'XX' AND subscriberLastName=dependentLastName AND subscriberCoverageId <>'XX' AND subscriberZip='XX' AND subscriberCity='XX' AND subscriberState='XX' AND subscriberAddress='XX' AND dependentAddress <> 'XX') THEN dependentAddress ELSE subscriberAddress END AS subscriberAddress,
       CASE WHEN (subscriberLastName <>'XX' AND subscriberLastName=dependentLastName AND subscriberCoverageId <>'XX' AND subscriberZip='XX' AND subscriberCity='XX' AND subscriberState='XX' AND subscriberAddress='XX' AND dependentCity <> 'XX')    THEN dependentCity    ELSE subscriberCity    END AS subscriberCity,
       CASE WHEN (subscriberLastName <>'XX' AND subscriberLastName=dependentLastName AND subscriberCoverageId <>'XX' AND subscriberZip='XX' AND subscriberCity='XX' AND subscriberState='XX' AND subscriberAddress='XX' AND dependentState <> 'XX')   THEN dependentState   ELSE subscriberState   END AS subscriberState,
       CASE WHEN (subscriberLastName <>'XX' AND subscriberLastName=dependentLastName AND subscriberCoverageId <>'XX' AND subscriberZip='XX' AND subscriberCity='XX' AND subscriberState='XX' AND subscriberAddress='XX' AND dependentZip <> 'XX')     THEN dependentZip     ELSE subscriberZip     END AS subscriberZip,
       subscriberDOB,
       subscriberGender,
       CASE WHEN CAST(subscriberSSN AS BIGINT) IS NULL THEN CAST('000000000' AS STRING) ELSE CAST(subscriberSSN AS STRING) END AS subscriberSSN,
       dependentLastName,
       dependentFirstName,
       dependentMiddleName,
       dependentAddress,
       dependentCity,
       dependentState,
       dependentZip,
       dependentDOB,
       dependentGender,
       CASE WHEN CAST(dependentSSN AS BIGINT) IS NULL THEN CAST('000000000' AS STRING) ELSE CAST(dependentSSN AS STRING)   END AS dependentSSN,
       breadcrumb
FROM cdd_data
""")

cdd_data.createOrReplaceTempView("cdd_data")
cdd_data = spark.sql("""SELECT * FROM cdd_data WHERE (subscriberCoverageId <> 'XX' OR dependentCoverageId <> 'XX' OR subscriberId <> 'XX') """)
cdd_data.createOrReplaceTempView("cdd_data")
cdd_data = spark.sql("""
SELECT 
      cdd_data.*,
CASE WHEN (
           cdd_data.subscriberFirstName = 'XX'  AND
           cdd_data.subscriberLastName = 'XX'   AND
           cdd_data.subscriberMiddleName = 'XX' AND
           cdd_data.subscriberAddress = 'XX'    AND
           cdd_data.subscriberZip = 'XX'        AND
           cdd_data.subscriberCity = 'XX'       AND
           cdd_data.subscriberState = 'XX'      AND
           cdd_data.subscriberDOB = '00000000'  AND
           cdd_data.subscriberSSN = '000000000' AND
           cdd_data.dependentFirstName = 'XX'   AND
           cdd_data.dependentLastName = 'XX'    AND
           cdd_data.dependentMiddleName = 'XX'  AND
           cdd_data.dependentDOB = '00000000'   AND
           cdd_data.dependentSSN = '000000000'  AND
           cdd_data.dependentAddress = 'XX'     AND
           cdd_data.dependentCity = 'XX'        AND
           cdd_data.dependentState = 'XX'       AND
           cdd_data.dependentZip = 'XX' 
		   ) THEN '0' ELSE '1' END AS isValidDemographic
FROM cdd_data
""")
cdd_data = cdd_data.filter("isValidDemographic=='1'").drop("isValidDemographic")
cdd_data.dropDuplicates().repartition(15).write.mode('overwrite').parquet(data_path_opt1)
cdd_data.unpersist()

cdd_data = spark.read.parquet(data_path_opt1)
cdd_data.createOrReplaceTempView("cdd_data")
cdd_data = spark.sql("""
SELECT traceNumber,
       Received,
       providerId,
       providerLastNameOrgName,
       subscriberLastName,
       subscriberFirstName,
       subscriberMiddleName,
       subscriberGender,
       subscriberDOB,
       subscriberSSN,
       subscriberGroupNumber,
       subscriberSuffixCode,
       subscriberIdCode,
       subscriberId,
       subscriberAddress,
       subscriberState,
       subscriberCity,
       subscriberZip,
       dependentLastName,
       dependentFirstName,
       dependentGender,
       dependentDOB,
       dependentSSN,
       dateOfService,
       ResponseResultExt,
       ResponseResultStd,
       payerId,
       payerProviderId,
       payerLastNameOrgName,
       clientId,
       breadcrumb
FROM cdd_data
""")



cdd_data.dropDuplicates().repartition(15).write.mode('overwrite').format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", header="false", delimiter='|').save(data_path_opt2)
