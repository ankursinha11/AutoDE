# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("cdd_dir","")
dbutils.widgets.getArgument("cdd_dir")
cdd_dir= getArgument("cdd_dir")

dbutils.widgets.text("input_parsed_path","")
dbutils.widgets.getArgument("input_parsed_path")
input_parsed_path= getArgument("input_parsed_path")

dbutils.widgets.text("input_parsed271_path","")
dbutils.widgets.getArgument("input_parsed271_path")
input_parsed271_path= getArgument("input_parsed271_path")

dbutils.widgets.text("output_path","")
dbutils.widgets.getArgument("output_path")
output_path= getArgument("output_path")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bcdate","")
dbutils.widgets.getArgument("bcdate")
bcdate= getArgument("bcdate")



##DEFINING INPUT AND OUTPUT PATHS:
# ie_output_dir = "abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/karthik/data/cdd/transform/ie/parsed271"
# baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
# cdd_dir = cdd_dir.format(user)

# input_parsed = baseurl + input_parsed_path.format(cdd_dir, bcdate)
# input_parsed271 = baseurl + input_parsed271_path.format(cdd_dir, bcdate)
# output_parsed = baseurl + output_path.format(cdd_dir,bcdate)
# print("input_parsed:",input_parsed,'\ninput_parsed271: ',input_parsed271,'\noutputPath: ',output_parsed)


# COMMAND ----------

# DBTITLE 1,Set Base URL

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

# DBTITLE 1,Setting up Input & Output Path

# data_path_input = baseurl + cdd_dir + input_path + bcdate
# data_path_opt2 = baseurl + cdd_dir + output_path  + bcdate 

input_parsed = baseurl + cdd_dir + input_parsed_path + bcdate 
input_parsed271 = baseurl + cdd_dir + input_parsed271_path + bcdate
output_parsed = baseurl + cdd_dir+ output_path + bcdate
print("input_parsed:",input_parsed,'\ninput_parsed271: ',input_parsed271,'\noutputPath: ',output_parsed)

# COMMAND ----------



# #output from cdd cleanse demographics
# input_parsed = "abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/karthik/data/cdd/intermediate_tmp/ie/parsed_270"

# #output from ie parsed 271
# input_parsed271 = "abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/karthik/data/cdd/transform/ie/parsed271/20230625T20"

# output_parsed = "abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/karthik/data/cdd/intermediate_tmp/ie/ie-eval-parse-output"

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, trim, when,upper, regexp_replace



parsed = spark.read.option("delimiter", "|").csv(input_parsed).toDF(
    "traceNumber", "Received", "providerId", "providerLastNameOrgName",
    "subscriberLastName", "subscriberFirstName", "subscriberMiddleName",
    "subscriberGender", "subscriberDOB", "subscriberSSN", "subscriberGroupNumber",
    "subscriberSuffixCode", "subscriberIdCode", "subscriberId", "subscriberAddress",
    "subscriberState", "subscriberCity", "subscriberZip", "dependentLastName",
    "dependentFirstName", "dependentGender", "dependentDOB", "dependentSSN",
    "dateOfService", "ResponseResultExt", "ResponseResultStd", "payerId",
    "payerProviderId", "payerLastNameOrgName", "clientId"
    , "breadcrumb"
)


# COMMAND ----------

# # parsed.show(1,False)

# # spark.sql("select replace('hello-world', '-')").show()a
# # parsed271 = spark.read.text(input_parsed271)#.toDF("traceNumber271", "subscriberId271")
# parsed271.show(1,False)

# COMMAND ----------


parsed271 = spark.read.option("delimiter", "|").csv(input_parsed271).toDF(
    "traceNumber271", "subscriberId271"
)

a = parsed.join(parsed271, parsed["traceNumber"] == parsed271["traceNumber271"], "left")


# (subscriberId271 is null OR TRIM(subscriberId271) == '' ? subscriberId : subscriberId271) as subscriberId,
b = a.withColumn(
    "subscriberId",
    # when((col("subscriberId271").isNull()| (trim(col("subscriberId271")) == "")),col("subscriberId")).otherwise(col("subscriberId271"))
    # when((col("subscriberId271").isNull() | (trim(col("subscriberId271")) == "")),trim(upper(col("subscriberId"))).otherwise(trim(upper(col("subscriberId271")))))
    when((col("subscriberId271").isNull() | (trim(col("subscriberId271")) == "")),trim(upper(regexp_replace(col("subscriberId"), "[-]", "")))
    ).otherwise(trim(upper(regexp_replace(col("subscriberId271"), "[-]", ""))))
    # when( ,
    # col("subscriberId"),
    # col("subscriberId271")
).select(
    "traceNumber", "Received", "providerId", "providerLastNameOrgName",
    "subscriberLastName", "subscriberFirstName", "subscriberMiddleName",
    "subscriberGender", "subscriberDOB", "subscriberSSN", "subscriberGroupNumber",
    "subscriberSuffixCode", "subscriberIdCode", "subscriberId", "subscriberAddress",
    "subscriberState", "subscriberCity", "subscriberZip", "dependentLastName",
    "dependentFirstName", "dependentGender", "dependentDOB", "dependentSSN",
    "dateOfService", "ResponseResultExt", "ResponseResultStd", "payerId",
    "payerProviderId", "payerLastNameOrgName", "clientId"
    , "breadcrumb"
)

b.write.mode("overwrite").option("delimiter", "|").csv(output_parsed)