# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("cdd_dir","")
dbutils.widgets.getArgument("cdd_dir")
cdd_dir= getArgument("cdd_dir")

dbutils.widgets.text("input_ie_parsed","")
dbutils.widgets.getArgument("input_ie_parsed")
input_ie_parsed= getArgument("input_ie_parsed")

dbutils.widgets.text("input_client_ids","")
dbutils.widgets.getArgument("input_client_ids")
input_client_ids= getArgument("input_client_ids")

dbutils.widgets.text("output_path","")
dbutils.widgets.getArgument("output_path")
output_path= getArgument("output_path")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bcdate","")
dbutils.widgets.getArgument("bcdate")
bcdate= getArgument("bcdate")


#DEFINING INPUT AND OUTPUT PATHS:
# ie_output_dir = "abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/karthik/data/cdd/transform/ie/parsed271"
# baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
# cdd_dir = cdd_dir.format(user)


# input_ie_parsed = cdd/transform/output/ie/parsed/20230625T20
# input_client_ids = 'prod-icd-dev-adls/karthik/data/cdd/staging/input/clientIdsToBlock'

# COMMAND ----------

# DBTITLE 1,Set Base URL
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

# DBTITLE 1,Setting up Input & Output Path
input_ie_parsed = baseurl + cdd_dir +  input_ie_parsed  + bcdate
input_client_ids = baseurl + cdd_dir + input_client_ids
output_path = baseurl + cdd_dir+ output_path + bcdate
print('input_ie_parsed:',input_ie_parsed,'\ninput_client_ids: ',input_client_ids,'\noutputPath: ',output_path)

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

from pyspark.sql.types import StringType
from pyspark.sql.functions import udf,col, expr, substring

def getAddrNum(inp):
  inData = ''.join([i if (ord(i) > 47 and ord(i) < 58) else '' for i in inp]) #"".join(map(getDigits, args));
  return inData

getAddrNum_udf = udf(getAddrNum, StringType())

# COMMAND ----------

#
# # Define the UDF using streaming_python
# spark.udf.register("utiludf", lambda x: x)

# Load the data
ieAll = spark.read.option("delimiter", "|").csv(input_ie_parsed, header=False)



# Rename the columns
ieAll = ieAll.toDF("TraceNumber", "Received", "providerId", "providerLastNameOrgName", "subscriberLastName",
                   "subscriberFirstName", "subscriberMiddleName", "subscriberGender", "subscriberDOB",
                   "subscriberSSN", "subscriberGroupNumber", "subscriberSuffixCode", "subscriberIdCode",
                   "subscriberId", "subscriberAddress", "subscriberState", "subscriberCity", "subscriberZip",
                   "dependentLastName", "dependentFirstName", "dependentGender", "dependentDOB", "dependentSSN",
                   "dateOfService", "ResponseResultExt", "ResponseResultStd", "payerId", "payerProviderId",
                   "payerLastNameOrgName", "clientId", "breadCrumbs")


# Load the clientIdsToBlock data
clientIdToBlock = spark.read.option("delimiter", "|").csv(input_client_ids, header=False)
clientIdToBlock = clientIdToBlock.toDF("cidToBlock")

# Perform the left outer join
leftOuterJoin = ieAll.join(clientIdToBlock, ieAll.clientId == clientIdToBlock.cidToBlock, "left_outer")

# Filter out the rows with matched clientIds
ieAllParsed = leftOuterJoin.filter(col("cidToBlock").isNull())

# Process the ieSubs data
ieSubs = ieAllParsed.withColumn("subscriberZip", substring(col("subscriberZip"), 0, 5)) \
    .withColumn("subscriberAddressNumbers", getAddrNum_udf(col("subscriberAddress"))) \
    .withColumn("depFlag", expr("'N'")) \
    .select("TraceNumber", "Received", "providerId", "providerLastNameOrgName", "subscriberLastName",
            "subscriberFirstName", "subscriberMiddleName", "subscriberGender", "subscriberDOB",
            "subscriberSSN", "subscriberGroupNumber", "subscriberSuffixCode", "subscriberIdCode",
            "subscriberId", "subscriberAddress", "subscriberState", "subscriberCity", "subscriberZip",
            "subscriberAddressNumbers", "dateOfService", "ResponseResultExt", "ResponseResultStd",
            "payerId", "payerProviderId", "payerLastNameOrgName", "clientId", "breadCrumbs", "depFlag")
# display(ieAllParsed.select("subscriberAddress").limit(100))


# COMMAND ----------

# Process the ieDeps data
ieDepsTmp = ieAllParsed.filter((col("dependentFirstName") != "") |
                               (col("dependentLastName") != "") |
                               (col("dependentDOB") != "") |
                               (col("dependentSSN") != "") |
                               (col("dependentGender") != ""))

ieDeps = ieDepsTmp.withColumn("subscriberZip", substring(col("subscriberZip"), 0, 5)) \
    .withColumn("subscriberLastName", col("dependentLastName")) \
    .withColumn("subscriberFirstName", col("dependentFirstName")) \
    .withColumn("subscriberMiddleName", expr("''")) \
    .withColumn("subscriberGender", col("dependentGender")) \
    .withColumn("subscriberDOB", col("dependentDOB")) \
    .withColumn("subscriberSSN", col("dependentSSN")) \
    .withColumn("subscriberAddressNumbers", getAddrNum_udf(col("subscriberAddress"))) \
    .withColumn("depFlag", expr("'Y'")) \
    .select("TraceNumber", "Received", "providerId", "providerLastNameOrgName", "subscriberLastName",
            "subscriberFirstName", "subscriberMiddleName", "subscriberGender", "subscriberDOB",
            "subscriberSSN", "subscriberGroupNumber", "subscriberSuffixCode", "subscriberIdCode",
            "subscriberId", "subscriberAddress", "subscriberState", "subscriberCity", "subscriberZip",
            "subscriberAddressNumbers", "dateOfService", "ResponseResultExt", "ResponseResultStd",
            "payerId", "payerProviderId", "payerLastNameOrgName", "clientId", "breadCrumbs", "depFlag")

# Union the ieSubs and ieDeps data
ieAllOnlyDemoU = ieSubs.union(ieDeps)

# Rename the columns and select the required columns
ie = ieAllOnlyDemoU.select("TraceNumber", "Received", "providerId", "providerLastNameOrgName", "subscriberLastName",
                           "subscriberFirstName", "subscriberMiddleName", "subscriberGender", "subscriberDOB",
                           "subscriberSSN", "subscriberGroupNumber", "subscriberSuffixCode", "subscriberIdCode",
                           "subscriberId", "subscriberAddress", "subscriberState", "subscriberCity", "subscriberZip",
                           "subscriberAddressNumbers", "dateOfService", "ResponseResultExt", "ResponseResultStd",
                           "payerId", "payerProviderId", "payerLastNameOrgName", "clientId", "breadCrumbs", "depFlag")

# Write the output to the specified location
ie.write.mode('overwrite').option("delimiter", "|").csv(output_path, header=False)