# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("cdd_dir","")
dbutils.widgets.getArgument("cdd_dir")
cdd_dir= getArgument("cdd_dir")

dbutils.widgets.text("input_path","")
dbutils.widgets.getArgument("input_path")
input_path= getArgument("input_path")

dbutils.widgets.text("output_path","")
dbutils.widgets.getArgument("output_path")
output_path= getArgument("output_path")

dbutils.widgets.text("output_bdf_parquet","")
dbutils.widgets.getArgument("output_bdf_parquet")
output_bdf_parquet= getArgument("output_bdf_parquet")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bcdate","")
dbutils.widgets.getArgument("bcdate")
bcdate= getArgument("bcdate")


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

# DBTITLE 1,Common Util
# MAGIC %run "/Insleads-code/Common-Util/common_util"

# COMMAND ----------

bdf_pipe=baseurl+cdd_dir+input_path+bcdate
bdf_parquet = baseurl+cdd_dir+output_bdf_parquet+bcdate
bdf_output =baseurl+cdd_dir+output_path+bcdate

# COMMAND ----------

print(baseurl+cdd_dir+output_bdf_parquet+bcdate)

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
import sys


def blank_as_null(x):
    return when( ( (trim(col(x)) != "") & (trim(lower(col(x))) != "null" ) ), col(x)).otherwise(None)


#def main():
#    hdfs_bdf_pipe = sys.argv[1]    #/hcecdd/user/phd9appl/CDD/output/ie/bdf_pipe/bc
#    hdfs_bdf_parquet = sys.argv[2] #/hcecdd/user/phd9appl/CDD/output/ie/bdf_parquet/bc
#    hdfs_bdf_output = sys.argv[3]   #/hcecdd/user/phd9appl/CDD/output/ie/bdf_deduped/bc

#    spark = SparkSession.builder.appName("Dedupe ICH").getOrCreate()

parsed_schema = StructType([
    StructField("transactionkey", StringType()),
    StructField("fn", StringType()),
    StructField("mn", StringType()),
    StructField("ln", StringType()),
    StructField("gender", StringType()),
    StructField("ssn", StringType()),
    StructField("dob", StringType()),
    StructField("address", StringType()),
    StructField("address2", StringType()),
    StructField("city", StringType()),
    StructField("state", StringType()),
    StructField("zip", StringType()),
    StructField("zip4", StringType()),
    StructField("phone", StringType()),
    StructField("custom1", StringType()),
    StructField("custom2", StringType())
    ])
df = spark.read.format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="|").schema(parsed_schema).load(bdf_pipe)

df = df.withColumn("fn",blank_as_null("fn"))
df = df.withColumn("mn",blank_as_null("mn"))
df = df.withColumn("ln",blank_as_null("ln"))
df = df.withColumn("gender",blank_as_null("gender"))
df = df.withColumn("ssn",blank_as_null("ssn"))
df = df.withColumn("dob",blank_as_null("dob"))
df = df.withColumn("address",blank_as_null("address"))
df = df.withColumn("address2",blank_as_null("address2"))
df = df.withColumn("city",blank_as_null("city"))
df = df.withColumn("state",blank_as_null("state"))
df = df.withColumn("zip",blank_as_null("zip"))
df = df.withColumn("zip4",blank_as_null("zip4"))
df = df.withColumn("phone",blank_as_null("phone"))

df1 = df.where(\
        ~df.fn.isNull() |\
        ~df.mn.isNull() |\
        ~df.ln.isNull() |\
        ~df.gender.isNull() |\
        ~df.ssn.isNull() |\
        ~df.dob.isNull() |\
        ~df.address.isNull() |\
        ~df.address2.isNull() |\
        ~df.city.isNull() |\
        ~df.state.isNull() |\
        ~df.zip.isNull() |\
        ~df.zip4.isNull() |\
        ~df.phone.isNull() \
         )

df2 = df1.groupBy("fn","mn","ln","gender","ssn","dob","address","address2","city","state","zip","zip4","phone","custom1","custom2" )\
            .agg( min("transactionkey").alias("mintransactionkey"), collect_list("transactionkey").alias("listtransactionkeys") )\
            .select("mintransactionkey","listtransactionkeys")

df2_a = df2.withColumn("transactionkey",explode(df2.listtransactionkeys)).select("mintransactionkey","transactionkey")

df2_a.repartition(5).write.mode("overwrite").parquet(baseurl+cdd_dir+output_bdf_parquet+bcdate)

df3 = df1.groupBy(\
            "fn","mn","ln","gender","ssn","dob","address","address2","city","state","zip","zip4","phone","custom1","custom2" )\
            .agg( min("transactionkey").alias("transactionkey"))\
            .select("transactionkey", "fn","mn","ln","gender","ssn","dob","address","address2","city","state","zip","zip4","phone","custom1","custom2")

df3.repartition(5).write.format("csv").mode("overwrite").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ",delimiter="|",emptyValue='').save(bdf_output)