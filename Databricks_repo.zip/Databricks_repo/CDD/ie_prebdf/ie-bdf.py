# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("input_path","")
dbutils.widgets.getArgument("input_path")
input_path= getArgument("input_path")

dbutils.widgets.text("output_path","")
dbutils.widgets.getArgument("output_path")
output_path= getArgument("output_path")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bcdate","")
dbutils.widgets.getArgument("bcdate")
bcdate= getArgument("bcdate")

dbutils.widgets.text("cdd_dir","")
dbutils.widgets.getArgument("cdd_dir")
cdd_dir= getArgument("cdd_dir")


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

# DBTITLE 1,Common Util
# MAGIC %run "/Insleads-code/Common-Util/common_util"

# COMMAND ----------

import sys,re
from pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime

# COMMAND ----------

goodIDSchema = StructType([
    StructField("ID", StringType(), True),
	StructField("Custom1", StringType(), True),
    StructField("Custom2", StringType(), True),
    StructField("FN", StringType(), True),
	StructField("MN", StringType(), True),
	StructField("LN", StringType(), True),
    StructField("DOB", StringType(), True),
	StructField("SSN", StringType(), True),
	StructField("Phone", StringType(), True),
    StructField("Address", StringType(), True),
	StructField("City", StringType(), True),
	StructField("State", StringType(), True),
    StructField("Zip", StringType(), True),
	StructField("Zip4", StringType(), True),
	StructField("Address2", StringType(), True),
    StructField("Gender", StringType(), True)
])

# COMMAND ----------

#goodID = spark.read.csv("abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/ramcharan/data/cdd/transform/output/ie/filtered/28JUNE2023/", goodIDSchema,sep="|")

# COMMAND ----------

goodID = spark.read.csv(baseurl+cdd_dir+input_path+'filtered/'+bcdate, goodIDSchema,sep="|")

# COMMAND ----------

goodID_path = baseurl+cdd_dir+input_path+'filtered/'+bcdate
print(goodID_path)

# COMMAND ----------

blankDates = goodID.filter((goodID["DOB"].isNull()) | (goodID["DOB"] == ""))
nonBlankDates = goodID.filter((goodID["DOB"] != ""))

# COMMAND ----------

def isValidDate(inDate):
  strDate = str(inDate)#.encode().decode("utf-8")
  #display(strDate)
  for fmt in ["%Y%m%d", "%Y-%m-%d"]:
    try:
      if(strDate.startswith('0')):
          return False
      dt = datetime.strptime(strDate, fmt)
      if(dt.year < 1900):
          return False
      return True;
    except ValueError:
      pass;
  return False;

# COMMAND ----------

pyudf=udf(isValidDate,BooleanType())

# COMMAND ----------

goodDates=nonBlankDates.filter(pyudf(col("DOB")))

# COMMAND ----------

def addDashesToDate(inDate):
  strDate = str(inDate).encode().decode("utf-8");
  for fmt in ["%Y%m%d", "%Y-%m-%d"]:
    try:
      dt = datetime.strptime(strDate, fmt)
      return dt.strftime("%Y-%m-%d")
    except ValueError:
      pass;
  return "";

# COMMAND ----------

pudf=udf(addDashesToDate)

# COMMAND ----------

formattedGoodDates = goodDates.withColumn("DOB", pudf("DOB"))
badDates=nonBlankDates.filter(~pyudf(col("DOB")))
blankedBadDates = badDates.withColumn("DOB", lit(''))
postDateCleansing = blankDates.union(formattedGoodDates).union(blankedBadDates)

# COMMAND ----------

blankSSNs = postDateCleansing.filter((postDateCleansing["SSN"].isNull()) | (postDateCleansing["SSN"] == ""))
nonBlankSSNs=postDateCleansing.filter((postDateCleansing["SSN"] != ''))
nonBlankSSNsNoDashes = nonBlankSSNs.withColumn("SSN", regexp_replace(col("SSN"), '-', "")) 

# COMMAND ----------

goodSSNs = nonBlankSSNsNoDashes.filter( (length(col("SSN")) == 9 ) & (col("SSN").rlike('[0-9]+')) & (col("SSN") != '111111111') & (col("SSN") != '222222222') & (col("SSN")!= '333333333') & (col("SSN") != '444444444') & (col("SSN") != '555555555') & (col("SSN") != '666666666') & (col("SSN")!= '777777777') & (col("SSN") !=  '888888888') & (col("SSN") != '999999999') & (col("SSN") != '000000000') & (col("SSN") != '123456789') & (col("SSN")!= '987654321'))
badSSNs = nonBlankSSNsNoDashes.filter( (length(col("SSN")) != 9 ) | ~(col("SSN").rlike('[0-9]+')) | (col("SSN") == '111111111') | (col("SSN") == '222222222') | (col("SSN")== '333333333') | (col("SSN") == '444444444') | (col("SSN") == '555555555') | (col("SSN") == '666666666') | (col("SSN")== '777777777') | (col("SSN") ==  '888888888') | (col("SSN") == '999999999') | (col("SSN") == '000000000') | (col("SSN") == '123456789') | (col("SSN")== '987654321'))
blankedBadSSNs =  badSSNs.withColumn("SSN",lit(''))

# COMMAND ----------

postSSNCleansing = blankSSNs.union(goodSSNs).union(blankedBadSSNs)

# COMMAND ----------

blankZips = postSSNCleansing.filter((postSSNCleansing["Zip"].isNull()) | (postSSNCleansing["Zip"] == ""))
nonBlankZips = postSSNCleansing.filter( (postSSNCleansing["Zip"] != ''))
goodZips =  nonBlankZips.filter( (length(col("Zip")) == 5 ) & (col("Zip").rlike('^[0-9]*$')) & (col("Zip")  != '00000') & (col("Zip")  != '00001') &  ((col("Zip")) > '00500'))
badZips= nonBlankZips.filter( (length(col("Zip")) != 5 ) | ~(col("Zip").rlike('^[0-9]*$')) | (col("Zip")  == '00000') | (col("Zip")  == '00001') |  (( col("Zip")) <= '00500'))
blankedBadZips =  badZips.withColumn("Zip",lit(''))

# COMMAND ----------

postZipCleansing = blankZips.union(goodZips).union(blankedBadZips)

# COMMAND ----------

BDF = postZipCleansing

# COMMAND ----------

def remove_non_ascii(text):
    return ''.join([i if (ord(i) > 31 and ord(i) < 127) else ' ' for i in text]);

# COMMAND ----------

def getCleanString(*args):
  inData = "".join(map(remove_non_ascii, args));
  return inData;

# COMMAND ----------

getCleanStringtoUDF = udf(getCleanString, StringType())

# COMMAND ----------

BDF = BDF.select(trim(col("ID")).alias('ID'), 
  trim(getCleanStringtoUDF(when(col('FN').isNull(), '').otherwise(col('FN')))).alias('FN') , 
  trim(getCleanStringtoUDF(when(col('MN').isNull(), '').otherwise(col('MN')))).alias('MN') , 
  trim(getCleanStringtoUDF(when(col('LN').isNull(), '').otherwise(col('LN')))).alias('LN') , 
  trim(col('Gender')).alias('Gender'), 
  trim(col('SSN')).alias('SSN'), 
  trim(col('DOB')).alias('DOB'),
  trim(col('Address')).alias('Address'),
  trim(col('Address2')).alias('Address2'),
  trim(col('City')).alias('City'),
  trim(col('State')).alias('State'),
  trim(col('Zip')).alias('Zip'),
  trim(col('Zip4')).alias('Zip4'),
  trim(col('Phone')).alias('Phone'),
  trim(col('Custom1')).alias('Custom1'),
  trim(getCleanStringtoUDF(when(col('Custom2').isNull(), '').otherwise(col('Custom2')))).alias('Custom2') )

# COMMAND ----------

BDF.write.mode("overwrite").csv(baseurl+cdd_dir+output_path+bcdate,sep="|")