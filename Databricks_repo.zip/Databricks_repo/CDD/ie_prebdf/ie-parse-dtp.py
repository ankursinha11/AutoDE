# Databricks notebook source
dbutils.widgets.text("cdd_dir","")
dbutils.widgets.getArgument("cdd_dir")
cdd_dir= getArgument("cdd_dir")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("input_path","")
dbutils.widgets.getArgument("input_path")
inputBaseDir= getArgument("input_path")

dbutils.widgets.text("output_path","")
dbutils.widgets.getArgument("output_path")
outputBaseDir= getArgument("output_path")

dbutils.widgets.text("bcdate","")
dbutils.widgets.getArgument("bcdate")
bcdate= getArgument("bcdate")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")


# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user  

# COMMAND ----------

# DBTITLE 1,adls access
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))
spark.sparkContext._jsc.hadoopConfiguration().set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# DBTITLE 1,Common Util
# MAGIC %run "/Insleads-code/Common-Util/common_util"

# COMMAND ----------

ie_input_dir= baseurl + cdd_dir + inputBaseDir  +bcdate
ie_input_dir


# COMMAND ----------

ie_output_dire= baseurl + cdd_dir + outputBaseDir  +bcdate
ie_output_dire

# COMMAND ----------

import sys,re
from pyspark.sql.types import *

# COMMAND ----------

def parse_dtp(line):
    seg = re.compile('\"(.*?)\"')

    dtp = re.compile('<HL HL01=".*?" HL02=".*?" HL03="(.*?)" HL04=".*?"><TRN.*?DTP DTP01="(.*?)" DTP02="(.*?)" DTP03="(.*?)"')

    dtp_seg = re.compile('NM1><HL HL01=".*?<DTP.*?/>')
    dtp_tag = re.compile('<DTP')

    out = {}
    output = '' 

    lineout = ''

    for line in line :

       m = dtp_tag.search(line)
       if m is None:
          continue

       tag  = re.compile('<TraceNumber>(.+?)</')
       m = tag.search(line)
       if m:
          tracenumber = m.group(1)
       else:
          tracenumber = '';
     
       q =  dtp_seg.findall(line)
       if q:
          for i in range(len(q)):

             dtpline = q[i]
             m = dtp.search(dtpline)

             if m:
               output= tracenumber + '|'  + m.group(1) + '|'  + m.group(2) + '|' + m.group(3) + '|' + m.group(4)   
    return output               


# COMMAND ----------

input_data = spark.read.text(ie_input_dir)

# COMMAND ----------

# display(input_data)

# COMMAND ----------

parsed_data = input_data.rdd.map(parse_dtp)

# COMMAND ----------

parsed_data = parsed_data.filter(lambda x: x is not None).filter(lambda x: x != "")

# COMMAND ----------

# display(parsed_data)

# COMMAND ----------

try:
    if(dbutils.fs.ls(ie_output_dire)):
        dbutils.fs.rm(ie_output_dire, True)
        print("Directory Cleaned Successfully")
except:
    print("Directory doesn't exist")

# COMMAND ----------

parsed_data.coalesce(70).saveAsTextFile(ie_output_dire)