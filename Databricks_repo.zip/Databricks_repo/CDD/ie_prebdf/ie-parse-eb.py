# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("cdd_dir","")
dbutils.widgets.getArgument("cdd_dir")
cdd_dir= getArgument("cdd_dir")

dbutils.widgets.text("input_path","")
dbutils.widgets.getArgument("input_path")
input_path= getArgument("input_path")

dbutils.widgets.text("output_path","")
dbutils.widgets.getArgument("output_path")
output_path= getArgument("output_path")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bcdate","")
dbutils.widgets.getArgument("bcdate")
bcdate= getArgument("bcdate")


##DEFINING INPUT AND OUTPUT PATHS:
# ie_output_dir = "abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/karthik/data/cdd/transform/ie/parsed271"



# input: {}/staging/input/ie/{}
# ouput : <value>/workspace/hcecdd/user/${wf:user()}/CDD/output/ie/eb_segment/${wf:actionData('get-date')['date']}/</value>


# COMMAND ----------

# DBTITLE 1,Set Base URL

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

# DBTITLE 1,Setting up Input & Output Path

# data_path_input = baseurl + cdd_dir + input_path + bcdate
# data_path_opt2 = baseurl + cdd_dir + output_path  + bcdate 


input_path = baseurl + cdd_dir + input_path + bcdate 
output_path = baseurl + cdd_dir + output_path + bcdate 
print(cdd_dir,'\ninputPath: ',input_path,'\noutputPath: ',output_path)


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))


# COMMAND ----------

from pyspark.sql.types import StructType,StructField,StringType,Row
import sys,re


def remove_non_ascii(text):
    return ''.join([i if (ord(i) > 31 and ord(i) < 127) else ' ' for i in text])

def parser_eb(line):
    line = line[0]
    addr = re.compile('.*?N3 N301=\"([\w\s]+)\"/><N4 N401=\"([\s\w]+)\" N402=\"(\w+)\"\sN403=\"(\w+)\"/>')

    eb = re.compile('(EB EB01=.*?)>')

    seg = re.compile('\"(.*?)\"')

    eb03 = re.compile('EB03.(\d+)=\"[\w\d]*\" EB04')

    received = re.compile ('<Received>(\d\d\d\d)-(\d\d)-(\d\d).*?</Received>')

    submission = re.compile ('</Submission>')

    out = {}
    output = '' 

    # lineout = ''

    a=['TraceNumber',
       'subscriberLastName',
       'subscriberState',
       'subscriberCity',
       'subscriberZip',
       'ResponseResultExt',
       'ResponseResultStd']



# for line in data: #sys.stdin:
    # line = line.strip()
    # line = line.replace('\t',' ')
    # line = line.replace('|',' ')
    # line = remove_non_ascii(line)
    for i in a:
        tag  = re.compile('<(' + i +')>(.+?)</')
        m = tag.search(line)
        if m:
            out[i] = m.group(2)
        else:
            out[i] = '';
    m =  received.search(line)
    if m:
        year = m.group(1)
        month = m.group(2)
        day = m.group(3)
    try: 
        if out['subscriberLastName']:
            addr = re.compile(out['subscriberLastName'] +'\"(.*?)N3 N301=\"([\w\s]+)\"/><N4 N401=\"([\s\w]+)\" N402=\"(\w+)\"\sN403=\"(\w+)\"/>')
            m =  addr.search(line)
            if m:
                out['subscriberAddress'] = m.group(2)
                out['subscriberCity'] = m.group(3)
                out['subscriberState'] = m.group(4)
                out['subscriberZip'] = m.group(5)
    except: 
        pass 
    try: 
        header = out['TraceNumber']  \
              + "|" + year  + "-" + month  + "-" + day \
              + "|" + out['ResponseResultStd'] \
              + "|" + out['ResponseResultExt'] \
              + "|" + out['subscriberCity'] \
              + "|" + out['subscriberState'] \
              + "|" + out['subscriberZip'] 
    except: 
        pass 
    output_final = []
    q =  eb.findall(line)
    if q:
        for i in range(len(q)):
            ebline = q[i]
            m = eb03.search(ebline)
            rnge = 1 
            if m:
                rnge = int(m.group(1))
                for b in range(rnge):
                    m =  seg.findall(ebline)
                    if m:
                        output = output + "|" + m[0] + "|" + m[1] + "|" + m[2+b] 
                        for i in range(rnge+2,len(m)):
                            output = output + "|" + m[i]
                        try:
                            output_final.append(Row(header + output))
                            output = ''
                        except:
                            pass
    return output_final
lines = spark.read.text(input_path)
lines = lines.rdd.flatMap(parser_eb)
schema = StructType([StructField("value", StringType(), True)])
df = lines.toDF(schema) 
df.filter("value!=''").coalesce(200).write.mode("overwrite").text(output_path)