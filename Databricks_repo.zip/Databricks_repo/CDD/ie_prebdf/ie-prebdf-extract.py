# Databricks notebook source
# MAGIC %md
# MAGIC spark_jdbc_extract_fnf

# COMMAND ----------

import sys
import os
import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
from pyspark import SparkContext
from pyspark.conf import SparkConf
import subprocess

# COMMAND ----------

dbutils.widgets.text("tablename","")
dbutils.widgets.getArgument("tablename")
tablename= getArgument("tablename")

dbutils.widgets.text("path_conn_file", "")
dbutils.widgets.getArgument("path_conn_file")
path_conn_file= getArgument("path_conn_file")

dbutils.widgets.text("path_publish", "")
dbutils.widgets.getArgument("path_publish")
path_publish= getArgument("path_publish")

# COMMAND ----------

# ADLS access
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# --driver-class-path /shared/hdfs/user/phd9appl/escan_data_ingestion/oozie/ingest_table/lib/sqljdbc4.jar --jars /shared/hdfs/user/phd9appl/escan_data_ingestion/oozie/ingest_table/lib/sqljdbc4.jar
# hospitalprovidernums
# hospitalattributevalues
# hospitalattributes
# hospitals
# edipayers
# edipartners
# opsedipayershospitals
# edipayeropsoutofregionconfig
# edipayeropslottoconfig
# edipayerzipcodelookup
# edipayersxstateinsurancenames
# hcsystems

# path_conn_file = "/hcedata/user/phd9appl/connection_details/connect_prod_escan_spark_read_jdbc.txt"
# path_publish = "/user/phd9uat/tmp/hospitalprovidernums/20210709T10"
# tablename = "hospitalprovidernums"
#spark = SparkSession.builder.appName('SPARK_JDBC_EXTRACT_FNF' + tablename).getOrCreate()

# COMMAND ----------

#spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)

# COMMAND ----------

#df_conn = spark.read.format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", delimiter="\x01").load(path_conn_file)

# COMMAND ----------

#string_connection = str(df_conn.collect()[0]['_c0'])

# COMMAND ----------

string_query_extraction = "SELECT * from escan.dbo." + tablename
print("string_query_extraction : " + string_query_extraction)

# COMMAND ----------

string_query_extraction = "SELECT tracenumber,message from (select tracenumber,message from oltp.MessageXml as msgxml with (nolock) join OLTP.UserRequest ur with (nolock) on msgxml.userrequestid=ur.userrequestid join OLTP.Submission s with (nolock) on ur.SubmissionId= s.SubmissionId  where tracenumber > ${wf:actionData('maxtn')['tracenumber']} and s.clientid != 100515 and s.clientid != 100000 and s.clientid != 100523 and s.clientid != 0 and s.userid != 2344720) XML  WHERE $CONDITIONS"
print("string_query_extraction : " + string_query_extraction)


# COMMAND ----------

		    SELECT tracenumber,message from (select tracenumber,message from oltp.MessageXml as msgxml with (nolock) join OLTP.UserRequest ur with (nolock) on msgxml.userrequestid=ur.userrequestid join OLTP.Submission s with (nolock) on ur.SubmissionId= s.SubmissionId  where tracenumber >0 and s.clientid != 100515 and s.clientid != 100000 and s.clientid != 100523 and s.clientid != 0 and s.userid != 2344720) XML  WHERE $CONDITIONS   
    
    # 
    
    

   # "abfss://ie-prebdf-23may2023@divyaprodstorageact1.dfs.core.windows.net/Karthik/bdf_output/"


# COMMAND ----------


SELECT tracenumber,message from (select tracenumber,message from oltp.MessageXml as msgxml with (nolock) join OLTP.UserRequest ur with (nolock) on msgxml.userrequestid=ur.userrequestid join OLTP.Submission s with (nolock) on ur.SubmissionId= s.SubmissionId  where tracenumber > ${wf:actionData('maxtn')['tracenumber']} and s.clientid != 100515 and s.clientid != 100000 and s.clientid != 100523 and s.clientid != 0 and s.userid != 2344720) XML  WHERE $CONDITIONS


SELECT tracenumber,message from (select tracenumber,message from oltp.MessageXml as msgxml with (nolock) join OLTP.UserRequest ur with (nolock) on msgxml.userrequestid=ur.userrequestid join OLTP.Submission s with (nolock) on ur.SubmissionId= s.SubmissionId  where tracenumber > ${wf:actionData('maxtn')['tracenumber']} and s.clientid != 100515 and s.clientid != 100000  and s.clientid != 100523 and s.clientid != 0  and s.userid != 2344720) XML  WHERE $CONDITIONS 



SELECT tracenumber,message from (select tracenumber,message from oltp.MessageXml as msgxml with (nolock) join OLTP.UserRequest ur with (nolock) on msgxml.userrequestid=ur.userrequestid join OLTP.Submission s with (nolock) on ur.SubmissionId= s.SubmissionId  where tracenumber > ${wf:actionData('maxtn')['tracenumber']} and s.clientid != 100515 and s.clientid != 100000 and s.clientid != 100523 and s.clientid != 0 and s.userid != 2344720) XML  WHERE $CONDITIONS


# COMMAND ----------





# COMMAND ----------

df_data = spark.read.format("jdbc").option("url", path_conn_file).option("query", string_query_extraction).load().dropDuplicates()

# COMMAND ----------

for column in df_data.columns:
    new_column = column.lower()
    df_data = df_data.withColumnRenamed(column, new_column)

# COMMAND ----------

for column in df_data.columns:
    df_data = df_data.withColumn(column, trim(col(column)))
    df_data = df_data.withColumn(column, when(col(column).isNull(), None).otherwise(col(column)))
    df_data = df_data.withColumn(column, when(col(column) == '', None).otherwise(col(column)))
    df_data = df_data.withColumn(column, when(col(column) == 'null', None).otherwise(col(column)))

# COMMAND ----------

for column in df_data.columns:
    df_data = df_data.withColumn(column, when(col(column) == 'true', '1').when(col(column) == 'false', '0').otherwise(col(column)))

# COMMAND ----------

df_data.printSchema()
df_data = df_data.repartition(1)

# COMMAND ----------

print("WRITING TO THE ADLS : ")
df_data.write.mode("overwrite").parquet("abfss://ie-prebdf-23may2023@divyaprodstorageact1.dfs.core.windows.net/Karthik/bdf_output/current/20991231")
df_data.unpersist()
print("WRITING COMPLETE : ")

# COMMAND ----------

#spark.stop()
#exit(0)