# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("cdd_dir","")
dbutils.widgets.getArgument("cdd_dir")
cdd_dir= getArgument("cdd_dir")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bcdate","")
dbutils.widgets.getArgument("bcdate")
bcdate= getArgument("bcdate")

dbutils.widgets.text("input_path","")
dbutils.widgets.getArgument("input_path")
input_path= getArgument("input_path")

dbutils.widgets.text("output_path","")
dbutils.widgets.getArgument("output_path")
output_path= getArgument("output_path")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

CDD = baseurl + cdd_dir
nfs_dir = baseurl + cdd_dir

# COMMAND ----------

# DBTITLE 1,Common Util
# MAGIC %run "/Insleads-code/Common-Util/common_util"

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
import sys

# COMMAND ----------

schema_bdf = StructType([StructField("value", StringType())])

# COMMAND ----------

CDD

# COMMAND ----------

print(CDD+input_path+bcdate)

# COMMAND ----------

# DBTITLE 1,checking the total length of record and filtering if it is not equal to 542 characters
df_bdf = spark.read.text(CDD+input_path+bcdate)
df_bdf = df_bdf.withColumn("lengths",length("value"))
df_bdf = df_bdf.filter("lengths= 542").drop("lengths")

# COMMAND ----------

source_path = dbutils.fs.ls(CDD+input_path+bcdate)

# COMMAND ----------

for file_name in source_path:
    if 'part' in file_name.path:
        print(file_name)
        dbutils.fs.cp(file_name.path, nfs_dir+output_path+bcdate+'/merge/merge.txt' )

# COMMAND ----------

inputfilesize = 0
for i in dbutils.fs.ls(CDD+input_path+bcdate):
    inputfilesize = inputfilesize+i.size

# COMMAND ----------

inputfilesize

# COMMAND ----------

maxfilesize = 15000000000 #for 15GB
totalnooffiles = int(inputfilesize/maxfilesize)+1 # to write to multiple 15 GB files
print(totalnooffiles)

# COMMAND ----------

df_bdf.repartition(totalnooffiles).write.mode("overwrite").option("maxPartitionBytes",maxfilesize).text(nfs_dir+output_path+bcdate+'/merge_temp/')

# COMMAND ----------

# MAGIC %md renaming files

# COMMAND ----------

for i in dbutils.fs.ls(nfs_dir+output_path+bcdate+'/merge_temp/'):
    if 'part' in i.path and totalnooffiles >0:
        dbutils.fs.mv(i.path,nfs_dir+output_path+bcdate+'/merge/'+"/"+"ie"+"-"+bcdate+'-'+str(totalnooffiles))
        totalnooffiles=totalnooffiles-1

# COMMAND ----------

# dbutils.fs.ls('abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/karthik/data/cdd/transform/output/ie/package_bdf/20230625T20/merge/')

# COMMAND ----------

# Zipping the files using ADL