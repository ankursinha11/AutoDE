# Databricks notebook source

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("db_names","")
dbutils.widgets.getArgument("db_names")
db_names = getArgument("db_names")

dbutils.widgets.text("conn_string", "")
dbutils.widgets.getArgument("conn_string")
conn_string = getArgument("conn_string")

dbutils.widgets.text("output_path", "")
dbutils.widgets.getArgument("output_path")
output_path = getArgument("output_path")

dbutils.widgets.text("max_received_date_path", "")
dbutils.widgets.getArgument("max_received_date_path")
max_received_date_path = getArgument("max_received_date_path")

dbutils.widgets.text("received_logs", "")
dbutils.widgets.getArgument("received_logs")
received_logs = getArgument("received_logs")

dbutils.widgets.text("is_fd", "")
dbutils.widgets.getArgument("is_fd")
is_fd = getArgument("is_fd")


# COMMAND ----------

if user == 'na' or user =='': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

output_path = baseurl + output_path + bc + '/'
max_received_date_path = baseurl + max_received_date_path
received_logs = baseurl + received_logs
db_names = db_names.lower().split(",")
print("output_path: ",output_path)
print("max_received_date_path: ",max_received_date_path)
print("received_logs_path: ",received_logs)
print("db_names: ",db_names)
print("conn_string: ",conn_string)
print("is_fd: ",is_fd)

# COMMAND ----------

#prod code
fd_query_string = """select tracenumber,message from oltp.MessageXml as msgxml with (nolock)"""


from pyspark.sql.functions import max,concat_ws,regexp_replace,col
from pyspark.sql.types import LongType
from pyspark.sql.functions import max,concat_ws
from pyspark.sql.functions import *
from pyspark.sql import *


for db in db_names:
    print(f"===Starting: {db}===")
    conn_string_temp = conn_string.format(db = db)
    print("conn_string_temp: ",conn_string_temp)
    if(is_fd=='1'):
        print("***Running Full Dump***")
        query_string = fd_query_string
    else:
        print(f"Getting max Received: ")
        received_date_path = f"{max_received_date_path}{db}"
        trace_df = spark.read.csv(received_date_path)
        # max_tracenumber = trace_df.select("_c0").collect()[0][0]
        max_received_adls = trace_df.select("_c0").collect()[0][0]
        max_query_string_DB = f"""(select   min(tracenumber) as mintracevalue,
                                            max(tracenumber) as maxtracevalue, 
                                            max(received) as maxreceiveddate 
                                    from 
                                            oltp.MessageXmlExtended as msgxml with (nolock)  
                                    where  
                                            received > convert(datetime, substring('{max_received_adls}',0,20))) as T"""
        df_db = spark.read.format("jdbc").option("url", conn_string_temp).option("dbtable", max_query_string_DB).load()
        df_db=df_db.cache()
        min_tracenumber_DB=df_db.select("mintracevalue").collect()[0][0]
        max_tracenumber_DB = df_db.select("maxtracevalue").collect()[0][0]
        max_received_date_DB = df_db.select("maxreceiveddate").collect()[0][0]
        
        print("Creating query: ")
        query_string = f"""(select  tracenumber,
                                    message 
                            from 
                                    oltp.MessageXmlExtended as msgxml with (nolock)  
                            where 
                                    received > convert(datetime, substring('{max_received_adls}',0,20))
                            and     
                                    received <= dateadd(HOUR, -12,convert(datetime, substring('{max_received_date_DB}',0,20)))) as T"""
    
    if max_received_date_DB is None:
        print(f"there is no new data to retrive after last max received date from {db}")
    else:
        print("query_string : " + query_string)
        # out_path = f"{output_path}{bc}/{db}"
        out_path = f"{output_path}{db}"
        print(f"output path: {out_path}")
        print(f"Reading: {db}")
        df_data = spark.read.format("jdbc").option("url", conn_string_temp).option("fetchsize",2000).option("numPartitions",16).option("dbtable", query_string).option("lowerBound", min_tracenumber_DB).option("upperBound", max_tracenumber_DB).option("partitionColumn","tracenumber").load()
        #data_load_count = df_data.count()
        df_data = df_data.withColumn("message", regexp_replace(col("message"),"\n",""))
        df_data = df_data.withColumn("value", concat_ws(',', df_data.tracenumber, df_data.message))
        print(f"Writing: {db}")
        df_data.select("value").write.mode("overwrite").text(out_path)
        # print(df_data.count())
        print(f"Dumped Successfully: {db}")


# COMMAND ----------

if max_received_date_DB is None:
    print("no update required for max_received_date stored")
else:
    op_path=spark.read.text(out_path)
    data_load_count=op_path.count()
    received_date_df = spark.createDataFrame([ Row(max_received = max_received_date_DB )])
    received_date_df.write.mode("overwrite").csv(received_date_path)
    log_df = spark.createDataFrame([Row(Database = db, Query = query_string, RecordLoaded = data_load_count,Max_Received_date =  max_received_date_DB, Min_TraceNumber = min_tracenumber_DB, Max_TraceNumber = max_tracenumber_DB, Bcdate = bc )])
    log_df.write.mode("append").parquet(received_logs)
    df_data.unpersist()
    # display(received_date_df)