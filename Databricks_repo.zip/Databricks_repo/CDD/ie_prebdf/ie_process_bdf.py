# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bcdate","")
dbutils.widgets.getArgument("bcdate")
bcdate= getArgument("bcdate")

dbutils.widgets.text("cdd_dir","")
dbutils.widgets.getArgument("cdd_dir")
cdd_dir= getArgument("cdd_dir")

dbutils.widgets.text("input_path","")
dbutils.widgets.getArgument("input_path")
input_path= getArgument("input_path")

dbutils.widgets.text("output_path","")
dbutils.widgets.getArgument("output_path")
output_path= getArgument("output_path")


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# DBTITLE 1,Common Utils
# MAGIC %run "/Insleads-code/Common-Util/common_util"

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

input_bdf = baseurl+cdd_dir+input_path+bcdate
output_bdf = baseurl+cdd_dir+output_path+bcdate

# COMMAND ----------

print(output_bdf)

# COMMAND ----------

forBDF= spark.read.csv(input_bdf,sep="|")

# COMMAND ----------

forBDF = forBDF.na.fill("")

# COMMAND ----------

schema = [
    "ID", "FN", "MN", "LN", "Gender", "SSN", "DOB", "Address", "Address2",
    "City", "State", "Zip", "Zip4", "Phone", "Custom1", "Custom2"
]

# Assign the schema to the DataFrame
forBDF = forBDF.toDF(*schema)

# COMMAND ----------

# DBTITLE 1,Check for non-ascii values
from pyspark.sql import functions as F
dff=forBDF.select([
    F.regexp_replace(col, '[^\x00-\x7F]', "").alias(col) 
    for col in forBDF.columns])

# COMMAND ----------

from pyspark.sql.functions import concat, format_string
FixedwidthColumnlengths = {'ID':64,'FN':50,'MN':50,'LN':50,'Gender':1,'SSN':9,'DOB':10,'Address':75,'Address2':75,'City':30,'State':2,'Zip':5,'Zip4':5,'Phone':20,'Custom1':32,'Custom2':64}
#just = r"%-{width}s".format(width=20)
#rjust = r"%{width}s".format(width=20)

outdf1 = dff.select(
    concat(*[format_string(r"%{width}s".format(width = i),c) for (c,i) in zip(dff.columns,FixedwidthColumnlengths.values())]).alias("fixedWidth")
)

# COMMAND ----------

outdf1.coalesce(1).write.format("text").mode('overwrite').save(output_bdf)
