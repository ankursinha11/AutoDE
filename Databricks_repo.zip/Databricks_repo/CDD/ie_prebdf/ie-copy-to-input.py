# Databricks notebook source
pip install elementpath==4.1.4

# COMMAND ----------

# DBTITLE 1,Input Variables
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("cdd_dir","")
dbutils.widgets.getArgument("cdd_dir")
cdd_dir= getArgument("cdd_dir")

dbutils.widgets.text("input_path","")
dbutils.widgets.getArgument("input_path")
input_path= getArgument("input_path")

dbutils.widgets.text("output_path","")
dbutils.widgets.getArgument("output_path")
output_path= getArgument("output_path")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bcdate","")
dbutils.widgets.getArgument("bcdate")
bcdate= getArgument("bcdate")


# COMMAND ----------

# DBTITLE 1,Set Base URL

if user == 'na' or user == '': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

# DBTITLE 1,Setting up Input & Output Path
folders =  ['rttransactionstore', 'rttransactionstore_ds1', 'rttransactionstore_ds2']
input_path = baseurl + cdd_dir + input_path + bcdate + '/'
output_path = baseurl + cdd_dir + output_path  + bcdate 
print(cdd_dir,'\ninputPath: ',input_path,'\noutputPath: ',output_path)

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

def file_exists(dir):
  try:
    dbutils.fs.ls(dir)
  except:
    return False  
  return True


# COMMAND ----------

# DBTITLE 1,udf for ClientId and UserId
from pyspark.sql.types import StringType, StructType, StructField
import xml.etree.ElementTree as ET

def parse_xml(data):
    resp = []
    root = ET.fromstring(data)    
    root_identity = [tmp for tmp in list(root) if tmp.tag.endswith('Identity')][0]
    ClientId = [tmp for tmp in list(root_identity) if tmp.tag.endswith('ClientId')][0]
    UserId = [tmp for tmp in list(root_identity) if tmp.tag.endswith('UserId') and not tmp.tag.endswith('DatabaseImpersonationUserId')][0]
    
    output_dict = {}
    
    output_dict['ClientId'] = ClientId.text if ClientId != None and ClientId.text != None else ''
    output_dict['UserId'] = UserId.text if UserId != None and UserId.text != None else ''
    return (output_dict['ClientId'],output_dict['UserId'])

schema = StructType([
    StructField("clientid",StringType(),False),
    StructField("userid",StringType(),False)
])
parse_xml_udf = udf(parse_xml, schema)

# COMMAND ----------

# DBTITLE 1,Reading & Writing:

# spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# # Load the input data as a DataFrame
# A = spark.read.text(input_path)

# # Write the DataFrame to the output path
# A.write.mode('overwrite').text(output_path)

# COMMAND ----------

from pyspark.sql.functions import regexp_replace,col,split
for i in range(len(folders)):
    inp_path = f"{input_path}{folders[i]}"
    print(f"input path: {inp_path}")
    if file_exists(inp_path) == True:    
        df = spark.read.text(inp_path)
        df = df.withColumn("tmp",split("value",",",2)[1])
        df = df.withColumn("tmp", parse_xml_udf(df['tmp']))
        df = df.filter("(tmp.clientid not in ('100515','100000','100523','0')) and (tmp.userid != '2344720') ").select("value")
        mode = "overwrite" if i==0 else "append"
        df.write.mode(mode).text(output_path)
        # df.display()
        print(output_path)
    else:
        print("Directory Not Exists")

# COMMAND ----------

# from pyspark.sql.functions import max,concat_ws,regexp_replace,col
# #  abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/cdd/staging/ie/sqoop/20230908T18/
# parquet_loc = "abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/cdd/staging/input/ie/20231016T23/"
# output_loc = "abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/cdd/staging/input/ie/20231017T23/"
               
# df = spark.read.text(parquet_loc)
# df = df.withColumn("message", regexp_replace(col("message"),"\n",""))
# df = df.withColumn("value", concat_ws(',', df.tracenumber, df.message))
# df.select("value").write.mode("overwrite").text(output_loc)
# # df.filter("tracenumber == '110520004014'").select("value").limit(1).collect()
# # display(df.limit(1))