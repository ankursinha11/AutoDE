# Databricks notebook source
pip install elementpath==4.1.4

# COMMAND ----------

# DBTITLE 1,Input Variables:
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("cdd_dir","")
dbutils.widgets.getArgument("cdd_dir")
cdd_dir= getArgument("cdd_dir")

dbutils.widgets.text("input_path","")
dbutils.widgets.getArgument("input_path")
input_path= getArgument("input_path")

dbutils.widgets.text("output_path","")
dbutils.widgets.getArgument("output_path")
output_path= getArgument("output_path")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bcdate","")
dbutils.widgets.getArgument("bcdate")
bcdate= getArgument("bcdate")


# #DEFINING INPUT AND OUTPUT PATHS:
# ie_output_dir = "abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/karthik/data/cdd/transform/ie/parsed271"
# baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
# cdd_dir = cdd_dir.format(user)
# input_path = baseurl + input_path.format(cdd_dir, bcdate)
# output_path = baseurl + output_path.format(cdd_dir,bcdate)
# print(cdd_dir,'\ninputPath: ',input_path,'\noutputPath: ',output_path)


# COMMAND ----------

# DBTITLE 1,Set Base URL

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# DBTITLE 1,Setting up Input & Output Path

input_path = baseurl + cdd_dir + input_path + bcdate
output_path = baseurl + cdd_dir + output_path  + bcdate 
print(cdd_dir,'\ninputPath: ',input_path,'\noutputPath: ',output_path)

# COMMAND ----------

# DBTITLE 1,Importing Dependencies:
from pyspark.sql.types import StringType
import xml.etree.ElementTree as ET
from pyspark.sql.functions import udf, split, lit 


ie_output_dir = output_path
ie_input_dir = input_path
ie_input_dir,ie_output_dir

# COMMAND ----------

# DBTITLE 1,Parsing XML Code:
# ie_input_dir = "test-xml.txt"
# ie_output_dir = "out.txt"

def parse_xml(data,bcdate):
    resp = []
    root = ET.fromstring(data)    
    root_identity = [tmp for tmp in list(root) if tmp.tag.endswith('Identity')][0]
    root_Context = [tmp for tmp in list(root) if tmp.tag.endswith('Context')][0]
    node = [node for node in list(root) if node.tag.endswith('Requests')]
    SR = [node1 for node1 in list(node[0]) if node1.tag.endswith('SubmissionRequest')]
    PR = [node2 for node2 in list(SR[0]) if node2.tag.endswith('PayerResponse')][0]
    PReq = [tmp for tmp in list(SR[0]) if tmp.tag.endswith('PayerRequest')][0]
    Identity = [tmp for tmp in list(SR[0]) if tmp.tag.endswith('Identity')][0]
    RF = [tmp for tmp in list(SR[0]) if tmp.tag.endswith('RequestFields')][0]
    
    TraceNumber = [TN for TN in list(PReq) if TN.tag.endswith('TraceNumber')][0]
    PayerId = [tmp for tmp in list(Identity) if tmp.tag.endswith('PayerId')][0]
    ClientId = [tmp for tmp in list(root_identity) if tmp.tag.endswith('ClientId')][0]
    ResponseResultStd = [tmp for tmp in list(PR) if tmp.tag.endswith('ResponseResultStd')][0]
    ResponseResultExt = [tmp for tmp in list(PR) if tmp.tag.endswith('ResponseResultExt')][0]
    Received = [tmp for tmp in list(root_Context) if tmp.tag.endswith('Received')][0]
    subscriberId = RF.find('.//subscriberId')
    providerId = RF.find('.//providerId')
    providerLastNameOrgName =  RF.find('.//providerLastNameOrgName')
    payerProviderId =  RF.find('.//payerProviderId')
    payerLastNameOrgName =  RF.find('.//payerLastNameOrgName')
    dateOfService =  RF.find('.//dateOfService')
    subscriberSuffixCode =  RF.find('.//subscriberSuffixCode')
    subscriberIdCode =  RF.find('.//subscriberIdCode')
    
    output_dict = {}
    
    col_PR = ['st01','subscriberGroupNumber','dependentGroupNumber','subscriberCoverageId','dependentCoverageId','subscriberLastName','subscriberFirstName','subscriberMiddleName','subscriberAddress','subscriberCity','subscriberState','subscriberZip','subscriberDOB','subscriberGender','subscriberSSN','dependentLastName','dependentFirstName','dependentMiddleName','dependentAddress','dependentCity','dependentState','dependentZip','dependentDOB','dependentGender','dependentSSN']
    find_PR = ['.//ST','.//HL[@HL01="3"]/NM1/REF[@REF01="IG"]','.//HL[@HL01="4"]/NM1/REF[@REF01="IG"]','.//HL[@HL01="3"]/NM1[@NM108="MI"]','.//HL[@HL01="4"]/NM1[@NM108="MI"]','.//HL[@HL01="3"]/NM1','.//HL[@HL01="3"]/NM1','.//HL[@HL01="3"]/NM1','.//HL[@HL01="3"]/NM1/N3','.//HL[@HL01="3"]/NM1/N4','.//HL[@HL01="3"]/NM1/N4','.//HL[@HL01="3"]/NM1/N4','.//HL[@HL01="3"]/NM1/DMG','.//HL[@HL01="3"]/NM1/DMG','.//HL[@HL01="3"]/NM1/REF[@REF01="SY"]','.//HL[@HL01="4"]/NM1','.//HL[@HL01="4"]/NM1','.//HL[@HL01="4"]/NM1','.//HL[@HL01="4"]/NM1/N3','.//HL[@HL01="4"]/NM1/N4','.//HL[@HL01="4"]/NM1/N4','.//HL[@HL01="4"]/NM1/N4','.//HL[@HL01="4"]/NM1/DMG','.//HL[@HL01="4"]/NM1/DMG','.//HL[@HL01="4"]/NM1/REF[@REF01="SY"]']
    get_attrib_PR = ['ST01','REF02','REF02','NM109','NM109','NM103','NM104','NM105','N301','N401','N402','N403','DMG02','DMG03','REF02','NM103','NM104','NM105','N301','N401','N402','N403','DMG02','DMG03','REF02']

    for i in range(len(get_attrib_PR)):
        tmp = PR.find(find_PR[i])
        if tmp != None and get_attrib_PR[i] in tmp.keys():
            output_dict[col_PR[i]] = tmp.attrib[get_attrib_PR[i]]
        else:
            output_dict[col_PR[i]] = ''
    
    output_dict['TraceNumber'] = TraceNumber.text if TraceNumber != None and TraceNumber.text != None else ''
    output_dict['PayerId'] = PayerId.text if PayerId != None and PayerId.text != None else ''
    output_dict['ClientId'] = ClientId.text if ClientId != None and ClientId.text != None else ''
    output_dict['ResponseResultStd'] = ResponseResultStd.text if ResponseResultStd != None and ResponseResultStd.text != None else ''
    output_dict['ResponseResultExt'] = ResponseResultExt.text if ResponseResultExt != None and ResponseResultExt.text != None else ''
    output_dict['Received'] = Received.text if Received != None and Received.text != None else ''
    output_dict['subscriberId'] = subscriberId.text if subscriberId != None and subscriberId.text != None else ''
    output_dict['providerId'] = providerId.text if providerId != None and providerId.text != None else ''
    output_dict['providerLastNameOrgName'] = providerLastNameOrgName.text if providerLastNameOrgName != None and providerLastNameOrgName.text != None else ''
    output_dict['payerProviderId'] = payerProviderId.text if payerProviderId != None and payerProviderId.text != None else ''
    output_dict['payerLastNameOrgName'] = payerLastNameOrgName.text if payerLastNameOrgName != None and payerLastNameOrgName.text != None else ''
    output_dict['dateOfService'] = dateOfService.text if dateOfService != None and dateOfService.text != None else ''
    output_dict['subscriberSuffixCode'] = subscriberSuffixCode.text if subscriberSuffixCode != None and subscriberSuffixCode.text != None else ''
    output_dict['subscriberIdCode'] = subscriberIdCode.text if subscriberIdCode != None and subscriberIdCode.text != None else ''
    output_dict['bcdate'] = bcdate
    finalCols = ['st01','TraceNumber','PayerId','ClientId','ResponseResultStd','ResponseResultExt','subscriberGroupNumber','dependentGroupNumber','subscriberCoverageId','dependentCoverageId','subscriberId','Received','providerId','providerLastNameOrgName','payerProviderId','payerLastNameOrgName','dateOfService','subscriberSuffixCode','subscriberIdCode','subscriberLastName','subscriberFirstName','subscriberMiddleName','subscriberAddress','subscriberCity','subscriberState','subscriberZip','subscriberDOB','subscriberGender','subscriberSSN','dependentLastName','dependentFirstName','dependentMiddleName','dependentAddress','dependentCity','dependentState','dependentZip','dependentDOB','dependentGender','dependentSSN','bcdate']
    replaceCols = ['subscriberCoverageId','subscriberId','subscriberLastName','subscriberAddress','subscriberMiddleName','']
    for col in finalCols:
        if col in replaceCols:
            output_dict[col] = output_dict[col].replace('|','')
        resp.append(output_dict[col])
    return '|'.join(resp)

parse_xml_udf = udf(parse_xml, StringType())


# COMMAND ----------

# output_dict = {}
# output_dict['subscriberId'] = 'Hello||'
# output_dict['tst'] = 'Hello||'
# print(output_dict)
# finalCols = ['subscriberId','tst']
# replaceCols = ['subscriberId']
# for col in finalCols:
#     if col in replaceCols:
#         output_dict[col] = output_dict[col].replace('|','')
# print(output_dict)

# COMMAND ----------

# DBTITLE 1,Reading Input & Generating Output:
df = spark.read.text(ie_input_dir)
df = df.select(split("value",",",2).getItem(1).alias('value'))
df = df.withColumn("value", parse_xml_udf(df['value'],lit(bcdate)))
df.write.mode('overwrite').text(ie_output_dir)

# COMMAND ----------


from pyspark.sql.types import *
parsed_schema = StructType([
    StructField("St01", StringType()),
    StructField("TraceNumber", StringType()),
    StructField("PayerId", StringType()),
    StructField("ClientId", StringType()),
    StructField("ResponseResultStd", StringType()),
    StructField("ResponseResultExt", StringType()),
    StructField("subscriberGroupNumber", StringType()),
    StructField("dependentGroupNumber", StringType()),
    StructField("subscriberCoverageId", StringType()),
    StructField("dependentCoverageId", StringType()),
    StructField("subscriberId", StringType()),
    StructField("Received", StringType()),
    StructField("providerId", StringType()),
    StructField("providerLastNameOrgName", StringType()),
    StructField("payerProviderId", StringType()),
    StructField("payerLastNameOrgName", StringType()),
    StructField("dateOfService", StringType()),
    StructField("subscriberSuffixCode", StringType()),
    StructField("subscriberIdCode", StringType()),
    StructField("subscriberLastName", StringType()),
    StructField("subscriberFirstName", StringType()),
    StructField("subscriberMiddleName", StringType()),
    StructField("subscriberAddress", StringType()),
    StructField("subscriberCity", StringType()),
    StructField("subscriberState", StringType()),
    StructField("subscriberZip", StringType()),
    StructField("subscriberDOB", StringType()),
    StructField("subscriberGender", StringType()),
    StructField("subscriberSSN", StringType()),
    StructField("dependentLastName", StringType()),
    StructField("dependentFirstName", StringType()),
    StructField("dependentMiddleName", StringType()),
    StructField("dependentAddress", StringType()),
    StructField("dependentCity", StringType()),
    StructField("dependentState", StringType()),
    StructField("dependentZip", StringType()),
    StructField("dependentDOB", StringType()),
    StructField("dependentGender", StringType()),
    StructField("dependentSSN", StringType())
    ,StructField("breadcrumb", StringType())
])

# finalCols = ['st01','TraceNumber','PayerId','ClientId','ResponseResultStd','ResponseResultExt','subscriberGroupNumber','dependentGroupNumber','subscriberCoverageId','dependentCoverageId','subscriberId','Received','providerId','providerLastNameOrgName','payerProviderId','payerLastNameOrgName','dateOfService','subscriberSuffixCode','subscriberIdCode','subscriberLastName','subscriberFirstName','subscriberMiddleName','subscriberAddress','subscriberCity','subscriberState','subscriberZip','subscriberDOB','subscriberGender','subscriberSSN','dependentLastName','dependentFirstName','dependentMiddleName','dependentAddress','dependentCity','dependentState','dependentZip','dependentDOB','dependentGender','dependentSSN','bcdate']