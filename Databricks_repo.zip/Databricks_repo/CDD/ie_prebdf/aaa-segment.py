# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("cdd_dir","")
dbutils.widgets.getArgument("cdd_dir")
cdd_dir= getArgument("cdd_dir")

dbutils.widgets.text("input_path","")
dbutils.widgets.getArgument("input_path")
input_path= getArgument("input_path")

dbutils.widgets.text("output_path","")
dbutils.widgets.getArgument("output_path")
output_path= getArgument("output_path")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bcdate","")
dbutils.widgets.getArgument("bcdate")
bcdate= getArgument("bcdate")


##DEFINING INPUT AND OUTPUT PATHS:



# input: {}/staging/input/ie/{}
# ouput : <value>/workspace/hcecdd/user/${wf:user()}/CDD/output/ie/eb_segment/${wf:actionData('get-date')['date']}/</value>


# COMMAND ----------

# DBTITLE 1,Set Base URL

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

# DBTITLE 1,Setting up Input & Output Path

# data_path_input = baseurl + cdd_dir + input_path + bcdate
# data_path_opt2 = baseurl + cdd_dir + output_path  + bcdate 


input_path = baseurl + cdd_dir + input_path + bcdate 
output_path = baseurl + cdd_dir + output_path + bcdate 
print(cdd_dir,'\ninputPath: ',input_path,'\noutputPath: ',output_path)


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

from pyspark.sql.types import StructType,StructField,StringType,Row
import sys,re

# input_path = 'input/'
# output_path = 'output/'


def parse_aaa_segment(line):
    line = line[0]
    seg = re.compile('\"(.*?)\"')

    aaa = re.compile('<HL HL01=".*?" HL02=".*?" HL03="(.*?)".*?AAA AAA01="(.*?)" AAA02="(.*?)" AAA03="(.*?)" AAA04="(.*?)"')

    aaa_seg = re.compile('<HL HL01=".*?<AAA.*?/>')
    aaa_tag = re.compile('<AAA')

    out = []
    # output = '' 

    # lineout = ''

#     for line in sys.stdin:
    m = aaa_tag.search(line)
    if m is None:
        return out

    tag  = re.compile('<TraceNumber>(.+?)</')
    m = tag.search(line)
    if m:
        tracenumber = m.group(1)
    else:
        tracenumber = '';

    q =  aaa_seg.findall(line)
    if q:
        for i in range(len(q)):

            aaaline = q[i]
            m = aaa.search(aaaline)

            if m:
                output= tracenumber + '|'  + m.group(1) + '|'  + m.group(2) + '|' + m.group(3) + '|' + m.group(4) + '|' + m.group(5)  
                out.append( Row(output))
    return out


lines = spark.read.text(input_path)
lines = lines.rdd.flatMap(parse_aaa_segment)

schema = StructType([StructField("value", StringType(), True)])

df = lines.toDF(schema) 
df.filter("value!=''").write.mode("overwrite").text(output_path)