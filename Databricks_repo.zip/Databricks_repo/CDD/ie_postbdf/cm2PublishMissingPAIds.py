# Databricks notebook source
#cm2PublishMissingPAIds.pig

# COMMAND ----------

# DBTITLE 1,input parameters
dbutils.widgets.text("publishBaseDir","")
dbutils.widgets.getArgument("publishBaseDir")
publishBaseDir= getArgument("publishBaseDir")

dbutils.widgets.text("bc", "")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("outputBaseDir","")
dbutils.widgets.getArgument("outputBaseDir")
outputBaseDir= getArgument("outputBaseDir")


dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

# COMMAND ----------

# DBTITLE 1,set base path
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

# DBTITLE 1,adls access
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if dbutils.fs.ls(baseurl+publishBaseDir+'ie_cm2/missingPAIds/current/'):
    dbutils.fs.mv(baseurl+publishBaseDir+'ie_cm2/missingPAIds/current/',baseurl+publishBaseDir+'ie_cm2/missingPAIds/prev/',True)
dbutils.fs.cp(baseurl+outputBaseDir+'missingPAIds/'+bc,baseurl+publishBaseDir+'ie_cm2/missingPAIds/current/'+bc,True)