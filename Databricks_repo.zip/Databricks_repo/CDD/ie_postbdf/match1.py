# Databricks notebook source
#match1.pig

# COMMAND ----------

# DBTITLE 1,input parameters
dbutils.widgets.text("outputBaseDir","")
dbutils.widgets.getArgument("outputBaseDir")
outputBaseDir= getArgument("outputBaseDir")

dbutils.widgets.text("inputPreBDF","")
dbutils.widgets.getArgument("inputPreBDF")
inputPreBDF= getArgument("inputPreBDF")


dbutils.widgets.text("tupath","")
dbutils.widgets.getArgument("tupath")
tupath= getArgument("tupath")

dbutils.widgets.text("bc", "")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

# COMMAND ----------

# DBTITLE 1,set basepath
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

# DBTITLE 1,import common util
# MAGIC %run "/Insleads-code/Common-Util/common_util"

# COMMAND ----------

# DBTITLE 1,import dateValidation
# MAGIC %run "/Insleads-code/Common-Util/dateValidation" 

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# DBTITLE 1,adls access
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# DBTITLE 1,not used
# MAGIC %md
# MAGIC preBDFschema = StructType([
# MAGIC     StructField("traceNumber", StringType(), True),
# MAGIC 	StructField("Received", StringType(), True),
# MAGIC     StructField("providerId", StringType(), True),
# MAGIC     StructField("providerLastNameOrgName", StringType(), True),
# MAGIC 	StructField("subscriberLastName", StringType(), True),
# MAGIC     StructField("subscriberFirstName", StringType(), True),
# MAGIC     StructField("subscriberMiddleName", StringType(), True),
# MAGIC     StructField("subscriberGender", StringType(), True),
# MAGIC     StructField("subscriberDOB", StringType(), True),
# MAGIC     StructField("subscriberSSN", StringType(), True),
# MAGIC 	StructField("subscriberGroupNumber", StringType(), True),
# MAGIC     StructField("subscriberSuffixCode", StringType(), True),
# MAGIC     StructField("subscriberIdCode", StringType(), True),
# MAGIC 	StructField("subscriberId", StringType(), True),
# MAGIC     StructField("subscriberAddress", StringType(), True),
# MAGIC     StructField("subscriberState", StringType(), True),
# MAGIC 	StructField("subscriberCity", StringType(), True),
# MAGIC     StructField("subscriberZip", StringType(), True),
# MAGIC     StructField("dependentLastName", StringType(), True),
# MAGIC 	StructField("dependentFirstName", StringType(), True),
# MAGIC     StructField("dependentGender", StringType(), True),
# MAGIC 	StructField("dependentDOB", StringType(), True),
# MAGIC     StructField("dependentSSN", StringType(), True),
# MAGIC     StructField("dateOfService", StringType(), True),
# MAGIC 	StructField("ResponseResultExt", StringType(), True),
# MAGIC     StructField("ResponseResultStd", StringType(), True),
# MAGIC     StructField("payerId", StringType(), True),
# MAGIC 	StructField("payerProviderId", StringType(), True),
# MAGIC     StructField("payerLastNameOrgName", StringType(), True),
# MAGIC     StructField("clientId", StringType(), True),
# MAGIC     StructField("breadCrumbs", StringType(), True)
# MAGIC ])

# COMMAND ----------

#preBDF = spark.read.csv(baseurl+inputPreBDF,sep="|") #not used

# COMMAND ----------

# DBTITLE 1,not used
# MAGIC %md
# MAGIC preBDF = preBDF.select(
# MAGIC     col("_c0").alias("traceNumber"),
# MAGIC 	col("_c1").alias("Received"),
# MAGIC     col("_c2").alias("providerId"),
# MAGIC     col("_c3").alias("providerLastNameOrgName"),
# MAGIC 	col("_c4").alias("subscriberLastName"),
# MAGIC     col("_c5").alias("subscriberFirstName"),
# MAGIC     col("_c6").alias("subscriberMiddleName"),
# MAGIC     col("_c7").alias("subscriberGender"),
# MAGIC     col("_c8").alias("subscriberDOB"),
# MAGIC     col("_c9").alias("subscriberSSN"),
# MAGIC 	col("_c10").alias("subscriberGroupNumber"),
# MAGIC     col("_c11").alias("subscriberSuffixCode"),
# MAGIC     col("_c12").alias("subscriberIdCode"),
# MAGIC 	col("_c13").alias("subscriberId"),
# MAGIC     col("_c14").alias("subscriberAddress"),
# MAGIC     col("_c15").alias("subscriberState"),
# MAGIC 	col("_c16").alias("subscriberCity"),
# MAGIC     col("_c17").alias("subscriberZip"),
# MAGIC     col("_c18").alias("dependentLastName"),
# MAGIC 	col("_c19").alias("dependentFirstName"),
# MAGIC     col("_c20").alias("dependentGender"),
# MAGIC 	col("_c21").alias("dependentDOB"),
# MAGIC     col("_c22").alias("dependentSSN"),
# MAGIC     col("_c23").alias("dateOfService"),
# MAGIC 	col("_c24").alias("ResponseResultExt"),
# MAGIC     col("_c25").alias("ResponseResultStd"),
# MAGIC     col("_c26").alias("payerId"),
# MAGIC 	col("_c27").alias("payerProviderId"),
# MAGIC     col("_c28").alias("payerLastNameOrgName"),
# MAGIC     col("_c29").alias("clientId"),
# MAGIC     col("_c30").alias("breadCrumbs")
# MAGIC     )

# COMMAND ----------

IE1schema = StructType([
    StructField("traceNumber", StringType(), True),
	StructField("Received", StringType(), True),
    StructField("providerId", StringType(), True),
    StructField("providerLastNameOrgName", StringType(), True),
	StructField("subscriberLastName", StringType(), True),
    StructField("subscriberFirstName", StringType(), True),
    StructField("subscriberMiddleName", StringType(), True),
    StructField("subscriberGender", StringType(), True),
    StructField("subscriberDOB", StringType(), True),
    StructField("subscriberSSN", StringType(), True),
	StructField("subscriberGroupNumber", StringType(), True),
    StructField("subscriberSuffixCode", StringType(), True),
    StructField("subscriberIdCode", StringType(), True),
	StructField("subscriberId", StringType(), True),
    StructField("subscriberAddress", StringType(), True),
    StructField("subscriberState", StringType(), True),
	StructField("subscriberCity", StringType(), True),
    StructField("subscriberZip", StringType(), True),
    StructField("dependentLastName", StringType(), True),
	StructField("dependentFirstName", StringType(), True),
    StructField("dependentGender", StringType(), True),
	StructField("dependentDOB", StringType(), True),
    StructField("dependentSSN", StringType(), True),
    StructField("dateOfService", StringType(), True),
	StructField("ResponseResultExt", StringType(), True),
    StructField("ResponseResultStd", StringType(), True),
    StructField("payerId", StringType(), True),
	StructField("payerProviderId", StringType(), True),
    StructField("payerLastNameOrgName", StringType(), True),
    StructField("clientId", StringType(), True),
    StructField("breadCrumbs", StringType(), True)
])

# COMMAND ----------

IE1 = spark.read.csv(baseurl+outputBaseDir+'nopermid/'+bc,sep="|")

# COMMAND ----------

    IE1 = IE1.select(
    col("_c0").alias("traceNumber"),
	col("_c1").alias("Received"),
    col("_c2").alias("providerId"),
    col("_c3").alias("providerLastNameOrgName"),
	col("_c4").alias("subscriberLastName"),
    col("_c5").alias("subscriberFirstName"),
    col("_c6").alias("subscriberMiddleName"),
    col("_c7").alias("subscriberGender"),
    col("_c8").alias("subscriberDOB"),
    col("_c9").alias("subscriberSSN"),
	col("_c10").alias("subscriberGroupNumber"),
    col("_c11").alias("subscriberSuffixCode"),
    col("_c12").alias("subscriberIdCode"),
	col("_c13").alias("subscriberId"),
    col("_c14").alias("subscriberAddress"),
    col("_c15").alias("subscriberState"),
	col("_c16").alias("subscriberCity"),
    col("_c17").alias("subscriberZip"),
    col("_c18").alias("dependentLastName"),
	col("_c19").alias("dependentFirstName"),
    col("_c20").alias("dependentGender"),
	col("_c21").alias("dependentDOB"),
    col("_c22").alias("dependentSSN"),
    col("_c23").alias("dateOfService"),
	col("_c24").alias("ResponseResultExt"),
    col("_c25").alias("ResponseResultStd"),
    col("_c26").alias("payerId"),
	col("_c27").alias("payerProviderId"),
    col("_c28").alias("payerLastNameOrgName"),
    col("_c29").alias("clientId"),
    col("_c30").alias("breadCrumbs")
    )

# COMMAND ----------

for i in dbutils.fs.ls(baseurl+tupath):
    tupath = i.path

# COMMAND ----------

# TUCONSUMER = readcsv(spark,tupath,tuconsumerschema,'|','0','na')
TUCONSUMER = spark.read.parquet(tupath)

# COMMAND ----------

transformDate_udf = udf(transformDate,StringType())

# COMMAND ----------

TUSUBSET = TUCONSUMER.select("TUKEY","FRST_NME","LAST_NME","DOB")

# COMMAND ----------

TUSUBSET = TUSUBSET.withColumn("DOB",transformDate_udf(TUCONSUMER["DOB"]))

# COMMAND ----------

F1 = IE1.filter("subscriberDOB is not null and subscriberDOB !=''")

# COMMAND ----------

D1 = F1.dropDuplicates()

# COMMAND ----------

joincondition = [D1["subscriberFirstName"] == TUSUBSET["FRST_NME"],D1["subscriberLastName"] == TUSUBSET["LAST_NME"],D1["subscriberDOB"] == TUSUBSET["DOB"]]

# COMMAND ----------

J1 = D1.join(TUSUBSET,on=joincondition,how="inner")

# COMMAND ----------

G1 = J1.select("traceNumber",
		"Received",
		"providerId",
		"providerLastNameOrgName",
		"subscriberLastName",
		"subscriberFirstName",
		"subscriberMiddleName",
		"subscriberGender",
		"subscriberDOB",
		"subscriberSSN",
		"subscriberGroupNumber",
		"subscriberSuffixCode",
		"subscriberIdCode",
		"subscriberId",
		"subscriberAddress",
		"subscriberState",
		"subscriberCity",
		"subscriberZip",
		"dependentLastName",
		"dependentFirstName",
		"dependentGender",
		"dependentDOB",
		"dependentSSN",
		"dateOfService",
		"ResponseResultExt",
		"ResponseResultStd",
		"payerId",
		"payerProviderId",
		"payerLastNameOrgName",
		"clientId",
		"breadCrumbs",
		lit('').alias('cust1'),
		lit('').alias('cust2'),
		lit('').alias('cust3'),
		lit('').alias('cust4'),
		lit('').alias('cust5'),
		"TUKEY",
		lit('M1').alias('cust6'),  
		lit('').alias('cust7')
		)

# COMMAND ----------

G2 = G1.groupBy("traceNumber").agg(count("traceNumber").alias("tncount"))

# COMMAND ----------

G3 = G2.filter("tncount == 1")

# COMMAND ----------

G4 = G3.join(G1,"traceNumber","inner")

# COMMAND ----------

G5 = G4.select("traceNumber",
		"Received",
		"providerId",
		"providerLastNameOrgName",
		"subscriberLastName",
		"subscriberFirstName",
		"subscriberMiddleName",
		"subscriberGender",
		"subscriberDOB",
		"subscriberSSN",
		"subscriberGroupNumber",
		"subscriberSuffixCode",
		"subscriberIdCode",
		"subscriberId",
		"subscriberAddress",
		"subscriberState",
		"subscriberCity",
		"subscriberZip",
		"dependentLastName",
		"dependentFirstName",
		"dependentGender",
		"dependentDOB",
		"dependentSSN",
		"dateOfService",
		"ResponseResultExt",
		"ResponseResultStd",
		"payerId",
		"payerProviderId",
		"payerLastNameOrgName",
		"clientId",
		"breadCrumbs",
		when(col("cust1") == "", None).otherwise(col("cust1")).alias("cust1"),
		when(col("cust2") == "", None).otherwise(col("cust2")).alias("cust2"),
		when(col("cust3") == "", None).otherwise(col("cust3")).alias("cust3"),
		when(col("cust4") == "", None).otherwise(col("cust4")).alias("cust4"),
		when(col("cust5") == "", None).otherwise(col("cust5")).alias("cust5"),
		"TUKEY",
		"cust6",  
		when(col("cust7") == "", None).otherwise(col("cust7")).alias("cust7"),
		)

# COMMAND ----------

writecsv(spark,G5,baseurl+outputBaseDir+'imRecs/'+bc+'-M1',1,'overwrite','|')
