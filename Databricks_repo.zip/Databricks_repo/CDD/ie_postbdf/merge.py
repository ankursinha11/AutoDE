# Databricks notebook source
#merge.pig

# COMMAND ----------

# DBTITLE 1,input parameters
dbutils.widgets.text("inputPostBDFDir","")
dbutils.widgets.getArgument("inputPostBDFDir")
inputPostBDFDir= getArgument("inputPostBDFDir")

dbutils.widgets.text("outputBaseDir","")
dbutils.widgets.getArgument("outputBaseDir")
outputBaseDir= getArgument("outputBaseDir")

dbutils.widgets.text("ieDedupeDir","")
dbutils.widgets.getArgument("ieDedupeDir")
ieDedupeDir= getArgument("ieDedupeDir")

dbutils.widgets.text("inputPreBDF","")
dbutils.widgets.getArgument("inputPreBDF")
inputPreBDF= getArgument("inputPreBDF")

dbutils.widgets.text("bc", "")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

# COMMAND ----------

# DBTITLE 1,set baseurl
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

# DBTITLE 1,import common util
# MAGIC %run "/Insleads-code/Common-Util/common_util"

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
import re

# COMMAND ----------

# DBTITLE 1,adls access
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

preBDFschema = StructType([
    StructField("traceNumber", StringType(), True),
	StructField("Received", StringType(), True),
    StructField("providerId", StringType(), True),
    StructField("providerLastNameOrgName", StringType(), True),
	StructField("subscriberLastName", StringType(), True),
    StructField("subscriberFirstName", StringType(), True),
    StructField("subscriberMiddleName", StringType(), True),
    StructField("subscriberGender", StringType(), True),
    StructField("subscriberDOB", StringType(), True),
    StructField("subscriberSSN", StringType(), True),
	StructField("subscriberGroupNumber", StringType(), True),
    StructField("subscriberSuffixCode", StringType(), True),
    StructField("subscriberIdCode", StringType(), True),
	StructField("subscriberId", StringType(), True),
    StructField("subscriberAddress", StringType(), True),
    StructField("subscriberState", StringType(), True),
	StructField("subscriberCity", StringType(), True),
    StructField("subscriberZip", StringType(), True),
    StructField("dependentLastName", StringType(), True),
	StructField("dependentFirstName", StringType(), True),
    StructField("dependentGender", StringType(), True),
	StructField("dependentDOB", StringType(), True),
    StructField("dependentSSN", StringType(), True),
    StructField("dateOfService", StringType(), True),
	StructField("ResponseResultExt", StringType(), True),
    StructField("ResponseResultStd", StringType(), True),
    StructField("payerId", StringType(), True),
	StructField("payerProviderId", StringType(), True),
    StructField("payerLastNameOrgName", StringType(), True),
    StructField("clientId", StringType(), True),
    StructField("breadCrumbs", StringType(), True)
])

# COMMAND ----------

preBDF = spark.read.csv(baseurl+inputPreBDF+bc,sep="|")

# COMMAND ----------

    preBDF = preBDF.select(
    col("_c0").alias("traceNumber"),
	col("_c1").alias("Received"),
    col("_c2").alias("providerId"),
    col("_c3").alias("providerLastNameOrgName"),
	col("_c4").alias("subscriberLastName"),
    col("_c5").alias("subscriberFirstName"),
    col("_c6").alias("subscriberMiddleName"),
    col("_c7").alias("subscriberGender"),
    col("_c8").alias("subscriberDOB"),
    col("_c9").alias("subscriberSSN"),
	col("_c10").alias("subscriberGroupNumber"),
    col("_c11").alias("subscriberSuffixCode"),
    col("_c12").alias("subscriberIdCode"),
	col("_c13").alias("subscriberId"),
    col("_c14").alias("subscriberAddress"),
    col("_c15").alias("subscriberState"),
	col("_c16").alias("subscriberCity"),
    col("_c17").alias("subscriberZip"),
    col("_c18").alias("dependentLastName"),
	col("_c19").alias("dependentFirstName"),
    col("_c20").alias("dependentGender"),
	col("_c21").alias("dependentDOB"),
    col("_c22").alias("dependentSSN"),
    col("_c23").alias("dateOfService"),
	col("_c24").alias("ResponseResultExt"),
    col("_c25").alias("ResponseResultStd"),
    col("_c26").alias("payerId"),
	col("_c27").alias("payerProviderId"),
    col("_c28").alias("payerLastNameOrgName"),
    col("_c29").alias("clientId"),
    col("_c30").alias("breadCrumbs")
    )

# COMMAND ----------

#IEBDF = spark.read.text(baseurl+inputPostBDFDir+bc+'/*_cbeMatchAppend.dat') #to load only matchappend file like es_swift_postbdf
IEBDF = spark.read.text(baseurl+inputPostBDFDir+bc+'/*.dat')

# COMMAND ----------

IEBDF = IEBDF.select(
		col("value").substr(50,15).alias("TN"),
		col("value").substr(447,32).alias("Custom1"),
		col("value").substr(479,64).alias("Custom2"),
		col("value").substr(543,3).alias("FileNum"),
		col("value").substr(546,12).alias("RecordNum"),
		col("value").substr(558,12).alias("MagnetPermId"),
		col("value").substr(570,12).alias("PermId"),
		col("value").substr(582,2).alias("MatchInd"),
		col("value").substr(584,12).alias("LinkId")
		)

# COMMAND ----------

IEBDF = IEBDF.withColumn("FileNum",col("FileNum").cast("integer"))

# COMMAND ----------

IEBDF = IEBDF.select(*[trim(col(c)).alias(c) for c in IEBDF.columns])

# COMMAND ----------

IEBDF = IEBDF.select(*[when(col(c) == "", None).otherwise(col(c)).alias(c) for c in IEBDF.columns])

# COMMAND ----------

maptn_1_columns = ['mintransactionkey','transactionkey']

# COMMAND ----------

maptn_1 = readparquet(spark,baseurl+ieDedupeDir+ bc + '/*', "1",maptn_1_columns)

# COMMAND ----------

maptn_1 = maptn_1.select(*[trim(col(c)).alias(c) for c in maptn_1.columns])

# COMMAND ----------

maptn_2 = maptn_1.join(IEBDF,maptn_1["mintransactionkey"] == IEBDF["TN"],"inner")

# COMMAND ----------

postBDF_1 = maptn_2.select(
    	col("transactionkey").alias("traceNumber"), # from maptn_1
        col("Custom1").alias("Custom1"),
		col("Custom2").alias("Custom2"),
		col("FileNum").alias("FileNum"),
		col("RecordNum").alias("RecordNum"),
		col("MagnetPermId").alias("MagnetPermId"),
		col("PermId").alias("PermId"),
		col("MatchInd").alias("MatchInd"),
		col("LinkId").alias("LinkId")
)

# COMMAND ----------

postBDF = postBDF_1.select(
    expr("CASE WHEN traceNumber LIKE 'D%' THEN REGEXP_EXTRACT(traceNumber,'D([0-9]*)',1) ELSE traceNumber END").alias("traceNumber"),
    col("Custom1"),
    col("Custom2"),
    col("FileNum"),
    col("RecordNum"),
    col("MagnetPermId"),
    col("PermId"),
    col("MatchInd"),
    col("LinkId")
	)


# COMMAND ----------

JOINED = preBDF.join(postBDF,"traceNumber","inner")

# COMMAND ----------

	OUT = JOINED.select(
		col("traceNumber"),
		col("Received"),
		col("providerId"),
		col("providerLastNameOrgName"),
		col("subscriberLastName"),
		col("subscriberFirstName"),
		col("subscriberMiddleName"),
		col("subscriberGender"),
		col("subscriberDOB"),
		col("subscriberSSN"),
		col("subscriberGroupNumber"),
		col("subscriberSuffixCode"),
		col("subscriberIdCode"),
		col("subscriberId"),
		col("subscriberAddress"),
		col("subscriberState"),
		col("subscriberCity"),
		col("subscriberZip"),
		col("dependentLastName"),
		col("dependentFirstName"),
		col("dependentGender"),
		col("dependentDOB"),
		col("dependentSSN"),
		col("dateOfService"),
		col("ResponseResultExt"),
		col("ResponseResultStd"),
		col("payerId"),
		col("payerProviderId"),
		col("payerLastNameOrgName"),
		col("clientId"),
		trim(col("breadCrumbs")).alias("breadCrumbs"),
        col("Custom1"),
		col("Custom2"),
		col("FileNum"),
		col("RecordNum"),
		col("MagnetPermId"),
		col("PermId"),
		col("MatchInd"),
		col("LinkId")
		)

# COMMAND ----------

writecsv(spark,OUT,baseurl+outputBaseDir+'allRecs/'+bc,1,'overwrite',"|")

# COMMAND ----------

IM = OUT.filter("MatchInd == 'IM'")

# COMMAND ----------

writecsv(spark,IM,baseurl+outputBaseDir+'imRecs/'+bc,1,'overwrite',"|")

# COMMAND ----------

postBDFRejects = spark.read.text(baseurl+inputPostBDFDir+bc+'/*_cbeEditRejects.dat')

# COMMAND ----------

postBDFRejects = postBDFRejects.select(
		col("value").substr(50,15).alias("TN"),
		col("value").substr(447,32).alias("Custom1"),
		col("value").substr(479,64).alias("Custom2"),
		col("value").substr(543,3).alias("FileNum"),
		col("value").substr(546,12).alias("RecordNum"),
		col("value").substr(558,12).alias("MagnetPermId"),
		col("value").substr(570,12).alias("PermId"),
		col("value").substr(582,2).alias("MatchInd"),
		col("value").substr(584,12).alias("LinkId")
		)

# COMMAND ----------

postBDFRejects = postBDFRejects.withColumn("FileNum",col("FileNum").cast("integer"))

# COMMAND ----------

postBDFRejects = postBDFRejects.select(*[trim(col(c)).alias(c) for c in postBDFRejects.columns])

# COMMAND ----------

postBDFRejects = postBDFRejects.select(*[when(col(c) == "", None).otherwise(col(c)).alias(c) for c in postBDFRejects.columns])

# COMMAND ----------

postBDFNoHits = spark.read.text(baseurl+inputPostBDFDir+bc+'/*_cbeNoHits.dat')

# COMMAND ----------

postBDFNoHits = postBDFNoHits.select(
		col("value").substr(50,15).alias("TN"),
		col("value").substr(447,32).alias("Custom1"),
		col("value").substr(479,64).alias("Custom2"),
		col("value").substr(543,3).alias("FileNum"),
		col("value").substr(546,12).alias("RecordNum"),
		col("value").substr(558,12).alias("MagnetPermId"),
		col("value").substr(570,12).alias("PermId"),
		col("value").substr(582,2).alias("MatchInd"),
		col("value").substr(584,12).alias("LinkId")
		)

# COMMAND ----------

postBDFNoHits = postBDFNoHits.withColumn("FileNum",col("FileNum").cast("integer"))

# COMMAND ----------

postBDFNoHits = postBDFNoHits.select(*[trim(col(c)).alias(c) for c in postBDFNoHits.columns])

# COMMAND ----------

postBDFNoHits = postBDFNoHits.select(*[when(col(c) == "", None).otherwise(col(c)).alias(c) for c in postBDFNoHits.columns])

# COMMAND ----------

NH = postBDFNoHits.select("TN")

# COMMAND ----------

writecsv(spark,NH,baseurl+outputBaseDir+'nohits/'+bc,1,'overwrite',"|")

# COMMAND ----------

RJ = postBDFRejects.select("TN")

# COMMAND ----------

writecsv(spark,RJ,baseurl+outputBaseDir+'rejects/'+bc,1,'overwrite',"|")

# COMMAND ----------

NOHITREJ = postBDFNoHits.union(postBDFRejects)

# COMMAND ----------

JOINEDNHRJ = preBDF.join(NOHITREJ,NOHITREJ["TN"]==preBDF["traceNumber"],"inner")

# COMMAND ----------

NHRJ = JOINEDNHRJ.select(
		col("traceNumber"),
		col("Received"),
		col("providerId"),
		col("providerLastNameOrgName"),
		col("subscriberLastName"),
		col("subscriberFirstName"),
		col("subscriberMiddleName"),
		col("subscriberGender"),
		col("subscriberDOB"),
		col("subscriberSSN"),
		col("subscriberGroupNumber"),
		col("subscriberSuffixCode"),
		col("subscriberIdCode"),
		col("subscriberId"),
		col("subscriberAddress"),
		col("subscriberState"),
		col("subscriberCity"),
		col("subscriberZip"),
		col("dependentLastName"),
		col("dependentFirstName"),
		col("dependentGender"),
		col("dependentDOB"),
		col("dependentSSN"),
		col("dateOfService"),
		col("ResponseResultExt"),
		col("ResponseResultStd"),
		col("payerId"),
		col("payerProviderId"),
		col("payerLastNameOrgName"),
		col("clientId"),
		trim(col("breadCrumbs")).alias("breadCrumbs")
		)

# COMMAND ----------

writecsv(spark,NHRJ,baseurl+outputBaseDir+'nopermid/'+bc,1,'overwrite',"|")