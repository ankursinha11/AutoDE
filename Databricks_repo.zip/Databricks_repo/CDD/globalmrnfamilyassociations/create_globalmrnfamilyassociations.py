# Databricks notebook source
# DBTITLE 1,Source Table List
# Data Sources
# 1. PatientAcctsAddress
# 2. TUSourcedFamilyMemberLink
# 3. GlobalMRNxPacct
# 4. GlobalMRNFamilyAssociations
# 5. PatientMatchingBlockAllowGMRN
# 6. AddressList
# 7. escanglobalparameters

# COMMAND ----------

# DBTITLE 1,Imports
from pyspark.sql.functions import *
from pyspark.sql.types import LongType
from pyspark.sql.window import Window
import datetime

# COMMAND ----------

# DBTITLE 1,Input Parameters
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("catalog_name","")
dbutils.widgets.getArgument("catalog_name")
catalog_name= getArgument("catalog_name")

publish_schema = 'cdd'

# COMMAND ----------

# container = "prod-icd-stg-adls"
# storageaccount = "prodicdstgdls"
# user = "vishnup"
# bc = "20250912T13"
# catalog_name = "prod_icd_stg_leadgen_catalog"

# COMMAND ----------

# DBTITLE 1,Set the Spark Configs
spark.conf.set("fs.azure.account.key." + storageaccount + ".dfs.core.windows.net", dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

# DBTITLE 1,Set the path variables
escanGlobalParametersPath = f"{baseurl}/data/dataingestion/publish/escanglobalparameters/current/20991231/"
tuSorcedFamilyMemberLinkPath = f"{baseurl}/data/cdd/publish/tu/tusourcedfamilymemberlink/current/20991231/"
addressListTable = f"{catalog_name}.{publish_schema}.AddressList"
globalMRNFamilyAssociationsTable = f"{catalog_name}.{publish_schema}.GlobalMRNFamilyAssociations"
patientAcctsAddressTable = f"{catalog_name}.{publish_schema}.PatientAcctsAddress"
globalMRNxPacctPath = f"{baseurl}/data/gmrn/publish/globalmrnxpacct/current/*"
PatientMatchingBlockAllowGMRNTable = f"{catalog_name}.dataingestion.PatientMatchingBlockAllowGMRN"

# COMMAND ----------

# DBTITLE 1,Read all the data sources
# escanglobalparameters_df = spark.read.parquet(escanGlobalParametersPath)
# lastGlobalMRNFamilyAssociationsDate_str = escanglobalparameters_df.where(col("Description") == 'LastGlobalMRNFamilyAssociationsDate').select("ParamValue").collect()[0][0]
# lastGlobalMRNFamilyAssociationsDate = datetime.datetime.strptime(lastGlobalMRNFamilyAssociationsDate_str, '%Y-%m-%d %H:%M:%S')
# globalMRNFamilyAssociationsStartDate = lastGlobalMRNFamilyAssociationsDate - datetime.timedelta(days=2)
# globalMRNFamilyAssociationsEndDate = datetime.datetime.now()
#print('globalMRNFamilyAssociationsEndDate:',globalMRNFamilyAssociationsEndDate)
globalMRNFamilyAssociationsStartDate = datetime.datetime.now() - datetime.timedelta(days=7)
print('globalMRNFamilyAssociationsStartDate:',globalMRNFamilyAssociationsStartDate)
tusourcedfamilymemberlink_df = spark.read.format('delta').load(tuSorcedFamilyMemberLinkPath).where(col("CreateDate") >= to_timestamp(lit(globalMRNFamilyAssociationsStartDate)))
AddressList_df = spark.read.table(addressListTable)
globalmrnfamilyassociations_df = spark.read.table(globalMRNFamilyAssociationsTable)
PatientAcctsAddress_df = spark.read.table(patientAcctsAddressTable)
PatientAcctsAddress_df = PatientAcctsAddress_df.withColumn("globalmrnifk", col("globalmrnifk").cast("string"))
gmrnxpacct_df = spark.read.parquet(globalMRNxPacctPath)
PatientMatchingBlockAllowGMRN_df = spark.read.table(PatientMatchingBlockAllowGMRNTable)
PatientMatchingBlockAllowGMRN_df = PatientMatchingBlockAllowGMRN_df.withColumn("gmrnifk", col("gmrnifk").cast("string"))

# COMMAND ----------

# DBTITLE 1,Tusourcedfamilymemberlink gmrn associations
tuQuery = """
            SELECT gmp1.GlobalMRNIFK, gmp2.GlobalMRNIFK  as MemberGlobalMRNIFK 
	        FROM {tusourcedfamilymemberlink_df} t
	        LEFT JOIN {gmrnxpacct_df} gmp1 ON cast(gmp1.HospitalFK as string) = t.HospitalFK1 AND gmp1.PatientAcctIFK = t.PatientAcctIFK1
	        LEFT JOIN {gmrnxpacct_df} gmp2 ON cast(gmp2.HospitalFK as string) = t.HospitalFK2 AND gmp2.PatientAcctIFK = t.PatientAcctIFK2
            WHERE gmp1.GlobalMRNIFK IS NOT NULL AND gmp2.GlobalMRNIFK IS NOT NULL
        """

TUSourcedFamilyMembersTemp_df = spark.sql(tuQuery, tusourcedfamilymemberlink_df = tusourcedfamilymemberlink_df, gmrnxpacct_df = gmrnxpacct_df)

tuQueryFinal = """
                  SELECT GlobalMRNIFK, MemberGlobalMRNIFK,
                  ROW_NUMBER() OVER(PARTITION BY GlobalMRNIFK, MemberGlobalMRNIFK ORDER BY GlobalMRNIFK, MemberGlobalMRNIFK)  as Row_Num
	              FROM {TUSourcedFamilyMembersTemp_df}
               """

TUSourcedFamilyMembersFinal_df = spark.sql(tuQueryFinal, TUSourcedFamilyMembersTemp_df = TUSourcedFamilyMembersTemp_df)
TUSourcedFamilyMembersFinal_df = TUSourcedFamilyMembersFinal_df.filter("Row_Num=1")

TUFamilyMembers_Query = """
                            SELECT DISTINCT     
                            (CASE WHEN cast(TUFam.GlobalMRNIFK as long) < cast(TUFam.MemberGlobalMRNIFK as long) THEN TUFam.GlobalMRNIFK ELSE TUFam.MemberGlobalMRNIFK END) GlobalMRNIFK,    
                            (CASE WHEN cast(TUFam.GlobalMRNIFK as long) < cast(TUFam.MemberGlobalMRNIFK as long) THEN TUFam.MemberGlobalMRNIFK ELSE TUFam.GlobalMRNIFK END) MemberGlobalMRNIFK,    
                            CAST(1 AS INT) UsingPermID,    
                            CAST(NULL AS INT) AddressListFK 
                            FROM {TUSourcedFamilyMembersFinal_df} TUFam        
                            WHERE TUFam.GlobalMRNIFK <> TUFam.MemberGlobalMRNIFK    
                            AND NOT EXISTS (SELECT  1 FROM {PatientMatchingBlockAllowGMRN_df} pmbg WHERE TUFam.GlobalMRNIFK = pmbg.GMRNIFK limit 1)
                            AND NOT EXISTS (SELECT  1 FROM {PatientMatchingBlockAllowGMRN_df} pmbg WHERE TUFam.MemberGlobalMRNIFK = pmbg.GMRNIFK limit 1)
                            """

TUFamilyMembers_df = spark.sql(TUFamilyMembers_Query, TUSourcedFamilyMembersFinal_df = TUSourcedFamilyMembersFinal_df, PatientMatchingBlockAllowGMRN_df = PatientMatchingBlockAllowGMRN_df)

TUGlobalMRNFamilyAssociationsInserts_Query = """
                                        SELECT  f.GlobalMRNIFK, f.MemberGlobalMRNIFK, f.UsingPermID, f.AddressListFK    
	                                    FROM {TUFamilyMembers_df} f    
	                                    LEFT JOIN {globalmrnfamilyassociations_df} gmrn     
	                                    ON f.GlobalMRNIFK = cast(gmrn.GlobalMRNIFK1 as string) 
	                                    AND f.MemberGlobalMRNIFK = cast(gmrn.GlobalMRNIFK2 as string)
	                                    WHERE gmrn.GlobalMRNIFK1 IS NULL 
                                    """
TUGlobalMRNFamilyAssociationsInserts_df = spark.sql(TUGlobalMRNFamilyAssociationsInserts_Query, TUFamilyMembers_df = TUFamilyMembers_df, globalmrnfamilyassociations_df = globalmrnfamilyassociations_df)
TUGlobalMRNFamilyAssociationsInserts_df = TUGlobalMRNFamilyAssociationsInserts_df.dropDuplicates()

# COMMAND ----------

# DBTITLE 1,Address based gmrn associations
WorkingGlobalMRNQuery =  """
                                SELECT DISTINCT pad.GlobalMRNIFK, pad.AddressListFK, pad.UpdateDate,
                                ROW_NUMBER() OVER(PARTITION BY pad.GlobalMRNIFK ORDER BY pad.UpdateDate DESC, pad.AddressListFK DESC) AS Row_Num
                                FROM {PatientAcctsAddress_df} pad  
                                WHERE cast(pad.UpdateDate as date) >= current_date-7
                                AND NOT EXISTS (SELECT  1 FROM {PatientMatchingBlockAllowGMRN_df} pmbg WHERE pad.GlobalMRNIFK = pmbg.GMRNIFK limit 1) 
                            """

WorkingGlobalMRN_df = spark.sql(WorkingGlobalMRNQuery, PatientAcctsAddress_df = PatientAcctsAddress_df, PatientMatchingBlockAllowGMRN_df = PatientMatchingBlockAllowGMRN_df)

GlobalMRNAddressesQuery =  """
                                SELECT GlobalMRNIFK,AddressListFK,UpdateDate FROM {WorkingGlobalMRN_df} wpa
                                where  wpa.Row_Num = 1
                            """

GlobalMRNAddresses_df = spark.sql(GlobalMRNAddressesQuery, WorkingGlobalMRN_df = WorkingGlobalMRN_df)

DISTINCTAddressListFKQuery = """
                             SELECT DISTINCT AddressListFK FROM {GlobalMRNAddresses_df}
                             """

DISTINCTAddressListFK_df =  spark.sql(DISTINCTAddressListFKQuery, GlobalMRNAddresses_df = GlobalMRNAddresses_df)

AddressCountQuery = """
                        SELECT paa.AddressListFK, COUNT(DISTINCT z.GlobalMRNIFK) GMRNCount   
                        FROM {DISTINCTAddressListFK_df} paa    
                        JOIN {PatientAcctsAddress_df} z    
                        ON z.AddressListFK = paa.AddressListFK    
                        GROUP BY paa.AddressListFK 
                    """
AddressCount_df = spark.sql(AddressCountQuery, DISTINCTAddressListFK_df = DISTINCTAddressListFK_df, PatientAcctsAddress_df = PatientAcctsAddress_df)

AddressCountfinalQuery = """
                        	SELECT ad.AddressListFK, ad.GMRNCount
                        	FROM {AddressCount_df} ad
                        	JOIN {AddressList_df} al
                            ON ad.AddressListFK = al.AddressListPK
                        	WHERE NOT (upper(al.StreetNameNormalized) IN ('NA', 'U', 'UK', 'UNK', '*U', 'NOTCOLLECTED', 'UNKNOWN', 'AVENUE', 'BADADDR', 'NANA', '*', '*000', 'X')
                            OR upper(al.StreetNameNormalized) LIKE '%BADADDRESS%'
                            OR upper(al.StreetNameNormalized) LIKE '%HOMELES%'
                            OR upper(al.StreetNameNormalized) LIKE '%HOMLES%'
                            OR upper(al.StreetNameNormalized) LIKE '%HMLSS%'
                            OR upper(al.StreetNameNormalized) LIKE '%OPENDOORMISSION%'
                            OR upper(al.StreetNameNormalized) LIKE '%UPDATE%'
                            OR upper(al.StreetNameNormalized) LIKE '%NONEAVAILABLE%'
                            OR upper(al.StreetNameNormalized) LIKE '%RETURNMAIL%'
                            OR upper(al.StreetNameNormalized) LIKE '%VERIFY%ADR%'
                            OR upper(al.StreetNameNormalized) LIKE '%VERIFY%ADD%'
                            OR upper(al.StreetNameNormalized) LIKE '%RECVDRETURNMAIL%'
                            OR upper(al.StreetNameNormalized) LIKE '%RCVDRETMAIL%'
                            OR upper(al.StreetNameNormalized) LIKE '%REC%RET%MAIL%'
                            OR upper(al.StreetNameNormalized) LIKE '%BAD%ADDRESS%'
                            OR upper(al.StreetNameNormalized) LIKE '%BADADDRES%'
                            OR upper(al.StreetNameNormalized) LIKE '%GENERALDELIVERY%'
                            OR upper(al.StreetNameNormalized) LIKE '%MAIL%RET%'
                            OR upper(al.StreetNameNormalized) LIKE '%RET%MAIL%'
                            OR upper(al.StreetNameNormalized) LIKE '%GOODADD%'
                            OR upper(al.StreetNameNormalized) LIKE '%REHAB%'
                            OR upper(al.StreetNameNormalized) LIKE '%HOSPITAL%'
                            OR upper(al.StreetNameNormalized) LIKE '%NURSING%'
                            OR upper(al.StreetNameNormalized) LIKE '%NONE%'
                            OR upper(al.StreetNameNormalized) LIKE '%CORRECTIONAL%'
                            OR upper(al.StreetNameNormalized) LIKE '%FACILI%'
                            OR upper(al.StreetNameNormalized) LIKE '%UNKNOWN%')
                        """

AddressCountfinal_df = spark.sql(AddressCountfinalQuery, AddressCount_df = AddressCount_df, AddressList_df = AddressList_df)

FamMembersListQuery =   """
                            SELECT pad.GlobalMRNIFK, pad.AddressListFK, pad.UpdateDate, ROW_NUMBER() OVER(PARTITION BY pad.GlobalMRNIFK ORDER BY pad.UpdateDate DESC, pad.AddressListFK DESC) RowNum
                            FROM {GlobalMRNAddresses_df} gma
                            JOIN {PatientAcctsAddress_df} pad 
                            ON pad.AddressListFK = gma.AddressListFK AND pad.GlobalMRNIFK <> gma.GlobalMRNIFK
                            WHERE 1=1
                            AND NOT EXISTS (SELECT 1 FROM {PatientMatchingBlockAllowGMRN_df} pmbg WHERE gma.GlobalMRNIFK = pmbg.GMRNIFK limit 1) 
                        """

FamMembersList_df = spark.sql(FamMembersListQuery, GlobalMRNAddresses_df = GlobalMRNAddresses_df, PatientAcctsAddress_df = PatientAcctsAddress_df, PatientMatchingBlockAllowGMRN_df = PatientMatchingBlockAllowGMRN_df)

FamMembersQuery =   """
                    SELECT DISTINCT    
                    (CASE WHEN cast(gma.GlobalMRNIFK as long) < cast(fam.GlobalMRNIFK as long) THEN gma.GlobalMRNIFK ELSE fam.GlobalMRNIFK END) GlobalMRNIFK,    
                    (CASE WHEN cast(gma.GlobalMRNIFK as long) < cast(fam.GlobalMRNIFK as long) THEN fam.GlobalMRNIFK ELSE gma.GlobalMRNIFK END) MemberGlobalMRNIFK,    
                    gma.AddressListFK      
                    FROM {GlobalMRNAddresses_df} gma    
                    JOIN {FamMembersList_df} fam   
                    ON gma.AddressListFK = fam.AddressListFK AND fam.GlobalMRNIFK <> gma.GlobalMRNIFK
                    WHERE fam.RowNum = 1 AND ABS(DATEDIFF(MONTH, fam.UpdateDate, gma.UpdateDate)) <= 12 
                    AND NOT EXISTS (SELECT 1 FROM {PatientMatchingBlockAllowGMRN_df} pmbg WHERE fam.GlobalMRNIFK = pmbg.GMRNIFK limit 1) 
                    """

FamMembers_df = spark.sql(FamMembersQuery, GlobalMRNAddresses_df = GlobalMRNAddresses_df, FamMembersList_df = FamMembersList_df, PatientMatchingBlockAllowGMRN_df = PatientMatchingBlockAllowGMRN_df)

FamAddressesQuery =  """
                    SELECT fm.GlobalMRNIFK, fm.MemberGlobalMRNIFK, fm.AddressListFK,  
                    ROW_NUMBER() OVER (PARTITION BY fm.GlobalMRNIFK, fm.MemberGlobalMRNIFK ORDER BY a.GMRNCount) RowNum    
                    FROM {FamMembers_df} fm    
                    JOIN {AddressCountfinal_df} a    
                    ON fm.AddressListFK = a.AddressListFK    
                    WHERE a.GMRNCount <= 8
                """
FamAddresses_df = spark.sql(FamAddressesQuery, FamMembers_df = FamMembers_df, AddressCountfinal_df = AddressCountfinal_df)

FamilyMembersQuery = """
                SELECT f.GlobalMRNIFK,f.MemberGlobalMRNIFK, f.AddressListFK, CAST(0 AS INTEGER) UsingPermID 
                FROM {FamAddresses_df} f    
                WHERE RowNum = 1 
                """
FamilyMembers_df = spark.sql(FamilyMembersQuery, FamAddresses_df = FamAddresses_df)

AddressGMRNFamilyAssociationsInsertsQuery = """
                                                    SELECT  f.GlobalMRNIFK, f.MemberGlobalMRNIFK, f.UsingPermID, f.AddressListFK    
                                                    FROM {FamilyMembers_df} f
                                                    LEFT JOIN {globalmrnfamilyassociations_df} gmrn     
                                                    ON f.GlobalMRNIFK = CAST(gmrn.GlobalMRNIFK1 AS STRING)
                                                    AND f.MemberGlobalMRNIFK = CAST(gmrn.GlobalMRNIFK2 AS STRING)
                                                    LEFT JOIN {TUGlobalMRNFamilyAssociationsInserts_df} tugmrn
                                                    ON f.GlobalMRNIFK = tugmrn.GlobalMRNIFK 
                                                    AND f.MemberGlobalMRNIFK = tugmrn.MemberGlobalMRNIFK    
                                                    WHERE gmrn.GlobalMRNIFK1 IS NULL 
                                                    AND tugmrn.GlobalMRNIFK IS NULL 
                                                """

AddressGMRNFamilyAssociationsInserts_df = spark.sql(AddressGMRNFamilyAssociationsInsertsQuery, FamilyMembers_df = FamilyMembers_df, globalmrnfamilyassociations_df = globalmrnfamilyassociations_df,TUGlobalMRNFamilyAssociationsInserts_df = TUGlobalMRNFamilyAssociationsInserts_df)
AddressGMRNFamilyAssociationsInserts_df = AddressGMRNFamilyAssociationsInserts_df.dropDuplicates()

# COMMAND ----------

# DBTITLE 1,GlobalMRNFamilyAssociations Inserts
GlobalMRNFamilyAssociationsInserts_df = TUGlobalMRNFamilyAssociationsInserts_df.union(AddressGMRNFamilyAssociationsInserts_df)
GlobalMRNFamilyAssociationsInserts_df = GlobalMRNFamilyAssociationsInserts_df.dropDuplicates()
GlobalMRNFamilyAssociationsInserts_df = GlobalMRNFamilyAssociationsInserts_df.withColumn('GlobalMRNIFK1', GlobalMRNFamilyAssociationsInserts_df['GlobalMRNIFK'].cast('bigint')).withColumn('GlobalMRNIFK2', GlobalMRNFamilyAssociationsInserts_df['MemberGlobalMRNIFK'].cast('bigint'))
GlobalMRNFamilyAssociationsInserts_df = GlobalMRNFamilyAssociationsInserts_df.drop('GlobalMRNIFK', 'MemberGlobalMRNIFK')
GlobalMRNFamilyAssociationsInserts_df = GlobalMRNFamilyAssociationsInserts_df.withColumn('bc', lit(bc)).withColumn('createdate', lit(current_timestamp())).withColumn('updatedate', lit(current_timestamp())).withColumn('bcupdated', lit(bc))

# COMMAND ----------

# DBTITLE 1,add pk column to incoming associations and append to UC publish table
globalmrnfamilyassociations_df = globalmrnfamilyassociations_df.withColumn("globalmrnfamilyassociationpk", col("globalmrnfamilyassociationpk").cast(LongType()))
max_pk_val = globalmrnfamilyassociations_df.select(max('globalmrnfamilyassociationpk')).collect()[0][0]

new_associations_df1 = GlobalMRNFamilyAssociationsInserts_df.withColumn("row_number", row_number().over(Window.orderBy("GlobalMRNIFK1", "GlobalMRNIFK2", "UsingPermID", "addresslistfk")))
new_associations_df2 = new_associations_df1.withColumn("globalmrnfamilyassociationpk", (col("row_number") + lit(max_pk_val))).drop("row_number")

final_associations_df = new_associations_df2.select(
    col("globalmrnfamilyassociationpk").cast('long'),
    col("GlobalMRNIFK1").cast('long'),
    col("GlobalMRNIFK2").cast('long'),
    col("UsingPermID").cast('short'),
    col("addresslistfk"),
    col("createdate"),
    col("updatedate"),
    col("bc"),
    col("bcupdated")
)

final_associations_df.write.mode("overwrite").format("delta").option("mergeSchema", "true").option("replaceWhere", f"bc = '{bc}'").saveAsTable(globalMRNFamilyAssociationsTable)
