# Databricks notebook source
dbutils.widgets.text("catalog_name","")
dbutils.widgets.getArgument("catalog_name")
catalog_name= getArgument("catalog_name")

dbutils.widgets.text("target_table","")
dbutils.widgets.getArgument("target_table")
target_table= getArgument("target_table")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

publish_schema = 'dataingestion'
staging_schema = "cdd_staging"

# COMMAND ----------

staging_table = catalog_name + "." + staging_schema + "." + 'GlobalMRNFamilyAssociationsInserts'
print("staging_table: ", staging_table)

# COMMAND ----------

# DBTITLE 1,to be sqooped data
sqoop_df = spark.read.table(staging_table).where(f"bc = '{bc}'")
sqoop_df = sqoop_df.drop("bc")

# COMMAND ----------

# DBTITLE 1,sqoop step to sql server
path_conn_file = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-dataingestion-sql-insleads-cs")
sqoop_df.write.format('jdbc').mode('append').option('driver', 'com.microsoft.sqlserver.jdbc.SQLServerDriver').option('url', path_conn_file).option('dbtable',target_table).save()
