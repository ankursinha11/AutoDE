# Databricks notebook source
dbutils.widgets.text("catalog_name","")
catalog_name=dbutils.widgets.get("catalog_name")

# COMMAND ----------

# DBTITLE 1,PatientMatchingBlockAllowGMRN
spark.sql(f"""CREATE TABLE IF NOT EXISTS {catalog_name}.dataingestion.PatientMatchingBlockAllowGMRN
(patientmatchingblockallowgmrnpk int,
gmrnifk bigint,
edipartnerfk short,
applypayergroup int,
blockallow string,
note string,
backfillstatus string,
createuserid int,
updateuserid int,
createdate timestamp,
createdby string,
updatedate timestamp,
updatedby string, 
bc string,
bcupdated string)
TBLPROPERTIES('vacuum'='72 hours')
""")

# COMMAND ----------

# DBTITLE 1,AddressList
spark.sql(f"""CREATE TABLE IF NOT EXISTS {catalog_name}.cdd.AddressList
(addresslistpk int,
zip string,
streetnum string,
streetname string,
streetnamenormalized string,
streettype string,
directionindicator string,
unitinfo string,
unitnum string,
createdate timestamp,
createdby string,
updatedate timestamp,
updatedby string,
bc string,
bcupdated string)
TBLPROPERTIES('vacuum'='72 hours')
""")

# COMMAND ----------

# DBTITLE 1,GlobalMRNFamilyAssociations
spark.sql(f"""CREATE TABLE IF NOT EXISTS {catalog_name}.cdd.GlobalMRNFamilyAssociations
(globalmrnfamilyassociationpk bigint,
globalmrnifk1 bigint,
globalmrnifk2 bigint,
usingpermid short,
addresslistfk int,
createdate timestamp,
updatedate timestamp,
bc string,
bcupdated string)
TBLPROPERTIES('vacuum'='72 hours')
""")

# COMMAND ----------

# DBTITLE 1,PatientAcctsAddress
spark.sql(f"""CREATE TABLE IF NOT EXISTS {catalog_name}.cdd.PatientAcctsAddress
(patientacctsaddresspk bigint,
hospitalfk short,
patientacctifk bigint,
globalmrnifk bigint,
zip string,
addresslistfk int,
createdate timestamp,
createdby string,
updatedate timestamp,
updatedby string,
 bc string,
bcupdated string)
TBLPROPERTIES('vacuum'='72 hours')
""")

# COMMAND ----------

spark.sql(f"""CREATE TABLE IF NOT EXISTS {catalog_name}.dataingestion_staging.AddressList
(addresslistpk int,
zip string,
streetnum string,
streetname string,
streetnamenormalized string,
streettype string,
directionindicator string,
unitinfo string,
unitnum string,
createdate timestamp,
createdby string,
updatedate timestamp,
updatedby string,
 bc string)
TBLPROPERTIES('vacuum'='72 hours')
""")

# COMMAND ----------

spark.sql(f"""CREATE TABLE IF NOT EXISTS {catalog_name}.dataingestion_staging.GlobalMRNFamilyAssociations
(globalmrnfamilyassociationpk bigint,
globalmrnifk1 bigint,
globalmrnifk2 bigint,
usingpermid int,
addresslistfk int,
createdate timestamp,
updatedate timestamp,
 bc string)
TBLPROPERTIES('vacuum'='72 hours')
""")

# COMMAND ----------

spark.sql(f"""CREATE TABLE IF NOT EXISTS {catalog_name}.dataingestion_staging.PatientAcctsAddress
(patientacctsaddresspk bigint,
hospitalfk short,
patientacctifk bigint,
globalmrnifk bigint,
zip string,
addresslistfk int,
createdate timestamp,
createdby string,
updatedate timestamp,
updatedby string,
 bc string)
TBLPROPERTIES('vacuum'='72 hours')
""")

# COMMAND ----------

spark.sql(f"""CREATE TABLE IF NOT EXISTS {catalog_name}.cdd_staging.GlobalMRNFamilyAssociationsInserts
(GlobalMRNIFK1 bigint,
GlobalMRNIFK2 bigint,
UsingPermID short,
addresslistfk int,
createdate timestamp,
updatedate timestamp,
IsProcessed string,
bc string)
TBLPROPERTIES('vacuum'='72 hours')
""")
