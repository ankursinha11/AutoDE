# Databricks notebook source
# hh_permidmap.py

# COMMAND ----------

# DBTITLE 1,Input Variables
# Set variables
dbutils.widgets.text("bcdate","")
dbutils.widgets.getArgument("bcdate")
bcdate= getArgument("bcdate")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("input_cdd_dir","")
dbutils.widgets.getArgument("input_cdd_dir")
input_cdd_dir= getArgument("input_cdd_dir")

dbutils.widgets.text("output_cdd_dir","")
dbutils.widgets.getArgument("output_cdd_dir")
output_cdd_dir= getArgument("output_cdd_dir")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")


if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'

# esInputDir = f"{baseurl}/publish/es/allDistinctRecs/{bcdate}"
# inputPostBDFMerged = f"{baseurl}/{input_post_bdf_merged}"
# outputBaseDir = f"{baseurl}/transform/escanoutput"

# # esInputDir = f"{input_cdd_dir}/publish/es/allDistinctRecs/{bcdate}"
# # outputBaseDir = f"{output_cdd_dir}/publish/escanoutput"
# # inputPostBDFMerged = f"{input_cdd_dir}/publish/es"

# COMMAND ----------

# DBTITLE 1,Run common_util
# MAGIC %run "/Insleads-code/Common-Util/common_util"

# COMMAND ----------

# DBTITLE 1,adls access
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

permid_patientacctid_schema = StructType([
    StructField("permid", StringType(), nullable=True),
	StructField("patientacctifk", StringType(), nullable=True),
    StructField("matchind", StringType(), nullable=True),
    StructField("magnetpermid", StringType(), nullable=True),
    StructField("hospitalfk", ShortType(), nullable=False)
])

# COMMAND ----------

# DBTITLE 1,distinctPatientAcctIdPermId
# Load and store distinctPatientAcctIdPermId
#distinctPatientAcctIdPermId = spark.read.load(f"{baseurl}/{input_cdd_dir}/permIdPatientAcctId/{bcdate}", format='csv', sep='|')
distinctPatientAcctIdPermId = readcsv_permissive(spark,f"{baseurl}/{input_cdd_dir}/permIdPatientAcctId/{bcdate}", permid_patientacctid_schema, "|", "0", "na")
writecsv(spark, distinctPatientAcctIdPermId, baseurl+output_cdd_dir+"/permIdPatientAcctId/"+bcdate, 1, 'overwrite', "|")

# COMMAND ----------

# DBTITLE 1,distinctPatientAcctIdPermId for M1
# Load and store distinctPatientAcctIdPermId for M1
#distinctPatientAcctIdPermIdM1 = spark.read.load(f"{baseurl}/{input_cdd_dir}/permIdPatientAcctId/{bcdate}-M1", format='csv', sep='|')
distinctPatientAcctIdPermIdM1 = readcsv_permissive(spark,f"{baseurl}/{input_cdd_dir}/permIdPatientAcctId/{bcdate}-M1", permid_patientacctid_schema, "|", "0", "na")
writecsv(spark, distinctPatientAcctIdPermIdM1, baseurl+output_cdd_dir+"/permIdPatientAcctId/"+bcdate+"-M1", 1, 'overwrite', "|")

# COMMAND ----------

# DBTITLE 1,postBDFNoHits
# Load and store postBDFNoHits
postBDFNoHits = spark.read.load(f"{baseurl}/{input_cdd_dir}/es_nohits/{bcdate}", format='csv', sep='|')
writecsv(spark, postBDFNoHits, baseurl+output_cdd_dir+"/es_nohits/"+bcdate, 1, 'overwrite', "|")
