# Databricks notebook source
# hh_policyinfo.py

# COMMAND ----------

# DBTITLE 1,Input Variables
# Set variables
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("bcdate","")
dbutils.widgets.getArgument("bcdate")
bcdate= getArgument("bcdate")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("input_cdd_dir","")
dbutils.widgets.getArgument("input_cdd_dir")
input_cdd_dir= getArgument("input_cdd_dir")

dbutils.widgets.text("output_cdd_dir","")
dbutils.widgets.getArgument("output_cdd_dir")
output_cdd_dir= getArgument("output_cdd_dir")

dbutils.widgets.text("scratch_path","")
dbutils.widgets.getArgument("scratch_path")
scratch_path= getArgument("scratch_path")

dbutils.widgets.text("clientidtoblock_dir","")
dbutils.widgets.getArgument("clientidtoblock_dir")
clientidtoblock_dir= getArgument("clientidtoblock_dir")



if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user  


# Derived Params
esincinputdir = baseurl+input_cdd_dir+"/es/allDistinctRecs/"+bcdate   
ieallinputdir =  baseurl+input_cdd_dir+"/ie/imRecs/*"
clientidtoblock_dir = baseurl+clientidtoblock_dir
esincpeople_stg_parquet =  baseurl+scratch_path+bcdate+"/esincpeople_stg"
iepostbdf_fill_stg_parquet = baseurl+scratch_path+bcdate+"/iepostbdf_fill_stg"
gen1_dir = baseurl+output_cdd_dir+"/correlatedfinalPolicyInfo/"+bcdate
f1_dir = baseurl+output_cdd_dir+"/finalPolicyInfo/"+bcdate
f2_dir = baseurl+output_cdd_dir+"/finalPolicyInfo/"+bcdate+"-M1"

# COMMAND ----------

# DBTITLE 1,Run common_util
# MAGIC %run "/Insleads-code/Common-Util/common_util"

# COMMAND ----------

# DBTITLE 1,adls access
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# DBTITLE 1,Imports
import sys
import subprocess
import os
import pyspark
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.types import StringType
from pyspark.sql import Window
from pyspark import SparkContext, SparkConf

# COMMAND ----------

# DBTITLE 1, Load & cleanse esincpostbdf

def load_esincpostbdfallfields(spark, esincinputdir):
    esincpostbdfallfields_schema = StructType([ \
        StructField("col_0", StringType()), \
        StructField("esPermId", StringType()), \
        StructField("esMatchInd", StringType()), \
        StructField("col_03", StringType()) \
    ])
    print("DEBUG: esincpostbdfallfields_schema ")

    df = readcsv(spark, esincinputdir, esincpostbdfallfields_schema, '|', '0', 'na')
    print("DEBUG: Source file-1 load completed for esincpostbdfallfields - " + str(esincinputdir) + "\n")
    return df

def filter_esincpeople(src_load1):
    esincpostbdfallfields=src_load1.na.fill("")
    esincpostbdf = esincpostbdfallfields.select("espermid","esmatchind")
    esincfiltered = esincpostbdf.where(col("espermid").isNotNull() & (col("esPermId") != ''))
    esincdistinct = esincfiltered.distinct()    
    w = Window.partitionBy("espermid")
    esincpeoplegroup = esincdistinct.select("espermid","esmatchind",count("espermid").over(w).alias("counts"))
    esincimpeople = esincpeoplegroup.select("espermid").withColumn("esmatchind",lit("IM").cast(StringType())).filter(col("counts")==2).distinct()
    esincotherpeople = esincpeoplegroup.filter(col("counts")==1).drop("counts")
    esincpeople = esincimpeople.union(esincotherpeople)
    print("DEBUG: Source file-1 filter completed for esincpeople" + "\n")
    return esincpeople    

# COMMAND ----------

# DBTITLE 1,Load iepostbdf
def load_iepostbdf(spark, ieallinputdir):
    iepostbdf_schema = StructType([ \
        StructField("tracenumber", StringType(), nullable=True), \
        StructField("received", StringType(), nullable=True), \
        StructField("providerid", StringType(), nullable=True), 
        StructField("providerlastnameorgname", StringType(), nullable=True), \
        StructField("subscriberlastname", StringType(), nullable=True), \
        StructField("subscriberfirstname", StringType(), nullable=True), \
        StructField("subscribermiddlename", StringType(), nullable=True), \
        StructField("subscribergender", StringType(), nullable=True), \
        StructField("subscriberdOb", StringType(), nullable=True), \
        StructField("subscriberssn", StringType(), nullable=True), \
        StructField("subscribergroupnumber", StringType(), nullable=True), \
        StructField("subscribersuffixcode", StringType(), nullable=True), \
        StructField("subscriberidcode", StringType(), nullable=True), \
        StructField("subscriberid", StringType(), nullable=True), \
        StructField("subscriberaddress", StringType(), nullable=True), \
        StructField("subscriberstate", StringType(), nullable=True), \
        StructField("subscribercity", StringType(), nullable=True), \
        StructField("subscriberZip", StringType(), nullable=True), \
        StructField("dependentlastname", StringType(), nullable=True), \
        StructField("dependentfirstname", StringType(), nullable=True), \
        StructField("dependentgender", StringType(), nullable=True), \
        StructField("dependentdob", StringType(), nullable=True), \
        StructField("dependentssn", StringType(), nullable=True), \
        StructField("dateofservice", StringType(), nullable=True), \
        StructField("responseresultext", StringType(), nullable=True), \
        StructField("responseresultstd", StringType(), nullable=True), \
        StructField("payerid", StringType(), nullable=True), \
        StructField("payerproviderid", StringType(), nullable=True), \
        StructField("payerlastnameorgname", StringType(), nullable=True), \
        StructField("clientid", StringType(), nullable=True), \
        StructField("breadcrumbs", StringType(), nullable=True), \
        StructField("custom1", StringType(), nullable=True), \
        StructField("custom2", StringType(), nullable=True), \
        StructField("filenum", StringType(), nullable=True), \
        StructField("recordnum", StringType(), nullable=True), \
        StructField("magnetpermid", StringType(), nullable=True), \
        StructField("iepermid", StringType(), nullable=False), \
        StructField("matchind", StringType(), nullable=True), \
        StructField("linkid", StringType(), nullable=True) \
        ])
        
    df = readcsv_permissive(spark, ieallinputdir, iepostbdf_schema, '|', '0', 'na')
    print("DEBUG: Source file-2 load completed for iepostbdf - " + str(ieallinputdir) + "\n")
    return df

# COMMAND ----------

# DBTITLE 1,Staging as parquet (esincpeople  & iepostbdf )

def extract_pqt_stg_esincpeople(filter_src_load1, esincpeople_stg_parquet):
    # filter_src_load1.coalesce(10).write.mode('overwrite').parquet(esincpeople_stg_parquet)
    writeparquet(spark, filter_src_load1, esincpeople_stg_parquet, 10, 'overwrite')
    print("DEBUG: Staging source file-1 extraction completed extract_pqt_stg_esincpeople " + str(esincpeople_stg_parquet) + "\n")
    
def extract_pqt_stg_iepostbdf(src_load2, iepostbdf_fill_stg_parquet):
    iepostbdf_fill=src_load2.na.fill("")
    # iepostbdf_fill.coalesce(500).write.mode('overwrite').parquet(iepostbdf_fill_stg_parquet)
    writeparquet(spark, iepostbdf_fill, iepostbdf_fill_stg_parquet, 500, 'overwrite')
    print("DEBUG: Staging source file-2 extraction completed iepostbdf_fill " + str(iepostbdf_fill_stg_parquet) + "\n")                                   


# COMMAND ----------

# DBTITLE 1,Read from Staging (esincpeople & iepostbdf)
def load_stg_esincpeople(spark, esincpeople_stg_parquet):
    # esincpeople_pqt = spark.read.parquet(esincpeople_stg_parquet)
    esincpeople_pqt = readparquet(spark, esincpeople_stg_parquet,"0","na")
    print("DEBUG: Loaded parquet from staging location esincpeople_stg_parquet " + str(esincpeople_stg_parquet) + "\n")
    return esincpeople_pqt
    
def load_stg_iepostbdf(spark, iepostbdf_fill_stg_parquet):    
    # iepostbdf_fill_pqt=spark.read.parquet(iepostbdf_fill_stg_parquet)
    iepostbdf_fill_pqt = readparquet(spark, iepostbdf_fill_stg_parquet,"0","na")
    print("DEBUG: Loaded parquet from staging location iepostbdf_fill_stg_parquet " + str(iepostbdf_fill_stg_parquet) + "\n")
    return iepostbdf_fill_pqt

# COMMAND ----------

# DBTITLE 1,Join escincpeople & iepostbdf
def joined_escincpeople_iepostbdf(stg_load1, stg_load2):
    filteredie1 = stg_load2.where(col("iepermid").isNotNull() & (col("iepermid") != ''))
    ieespeoplerecords = filteredie1.join(stg_load1, stg_load1.espermid == filteredie1.iepermid, "inner")
    print("DEBUG: Joining staging parquet files stg_load1 and stg_load2 " + "\n")
    return ieespeoplerecords

def subs_joined_filter(join_stgload1_stgload2):  
    subs_df = join_stgload1_stgload2.where((~col("custom1").like('%00DEP00%')) | col("custom1").isNull() & (col("iepermid") == ''))
    print("DEBUG: subs filtered from joined pqt join_stgload1_stgload2 " + "\n")
    return subs_df

def deps_joined_filter(join_stgload1_stgload2): 
    deps_df = join_stgload1_stgload2.where(col("custom1").like('%00DEP00%'))
    print("DEBUG: deps filtered from joined pqt join_stgload1_stgload2 " + "\n")
    return deps_df

# COMMAND ----------

# DBTITLE 1,Filter & Union of policy info

def subs_filter(subs):
    policyinfo1_df = subs.select( \
        col("iepermid"), \
        col("tracenumber"), \
        col("received"), \
        col("providerid"), \
        col("providerlastnameorgname"), \
        col("subscribergroupnumber"), \
        col("subscribersuffixcode"), \
        col("subscriberidcode"), \
        col("subscriberid"), \
        col("dateofservice"), \
        col("payerid"), \
        col("payerproviderid"), \
        col("payerlastnameorgname"), \
        lit("F").alias("dependentflag"), \
        col("subscriberfirstname"), \
        col("subscribermiddlename"), \
        col("subscriberlastname"), \
        col("subscribergender"), \
        col("subscriberdob"), \
        col("subscriberssn"), \
        col("subscriberaddress"), \
        col("subscriberstate"), \
        col("subscribercity"), \
        col("subscriberzip"), \
        col("esmatchind"), \
        col("clientid"), \
        col("responseresultext"), \
        col("responseresultstd"), \
        col("custom1"), \
        col("custom2") \
        )
    print("DEBUG: policyinfo1" + "\n")
    return policyinfo1_df

def deps_filter(deps):   
    policyinfo2_df = deps.select(
        col("iepermid"), \
        col("tracenumber"), \
        col("received"), \
        col("providerid"), \
        col("providerlastnameorgname"), \
        col("subscribergroupnumber"), \
        col("subscribersuffixcode"), \
        col("subscriberidcode"), \
        col("subscriberid"), \
        col("dateofservice"), \
        col("payerid"), \
        col("payerproviderid"), \
        col("payerlastnameorgname"), \
        lit("T").alias("dependentflag"), \
        col("dependentFirstName").alias("subscriberfirstname"), \
        lit("").alias("subscribermiddlename"), \
        col("dependentlastname").alias("subscriberlastname"), \
        col("dependentgender").alias("subscribergender"), \
        col("dependentdob").alias("subscriberdob"), \
        col("dependentssn").alias("subscriberssn"), \
        col("subscriberaddress"), col("subscriberstate"), \
        col("subscribercity"), \
        col("subscriberzip"), \
        col("esmatchind"), \
        col("clientid"), \
        col("responseresultext"), \
        col("responseresultstd"), \
        col("custom1"), \
        col("custom2") \
        )
    print("DEBUG: policyinfo2" + "\n")
    return policyinfo2_df

def unioned_pinfo1_pinfo2(policyinfo1, policyinfo2):
    policyinfo_df = policyinfo1.union(policyinfo2)
    print("DEBUG: policyinfo_df unioned from policyinfo1 and policyinfo2 " + "\n")
    return policyinfo_df

# COMMAND ----------

# DBTITLE 1,Good, Corrupted & Marked from policy info

def goodrows_filter(spark, policyinfo):
    policyinfo.registerTempTable("policyinfotable")
    print("DEBUG: Registered temp table policyinfo- policyinfotable " + "\n")
    
    goodrows_df = spark.sql("SELECT * FROM policyinfotable where \
        (iepermid is null or length(iepermid)<=12) and \
        (tracenumber is null or length(tracenumber)<=15 ) and \
        (received is null or length(received)<=50 ) and \
        (providerid is null or length(providerid)<=30 ) and \
        (providerlastnameorgname is null or length(providerlastnameorgname)<=100 ) and \
        (subscribergroupnumber is null or length(subscribergroupnumber)<=70 ) and \
        (subscribersuffixcode is null or length(subscribersuffixcode)<=30 ) and \
        (subscriberidcode is null or length(subscriberidcode)<=20 ) and \
        (subscriberid is null or length(subscriberid)<=100 ) and \
        (dateofservice is null or length(dateofservice)<=30 ) and \
        (payerid is null or length(payerid)<=50 ) and \
        (payerproviderid is null or length(payerproviderid)<=30 ) \
        and (payerlastnameorgname is null or length(payerlastnameorgname)<=100 ) and \
        (dependentflag is null or length(dependentflag)<=1 ) and \
        (subscriberfirstname is null or length(subscriberfirstname)<=100 ) and \
        (subscribermiddlename is null or length(subscribermiddlename)<=100 ) and \
        (subscriberlastname is null or length(subscriberlastname)<=100 ) and \
        (subscribergender is null or length(subscribergender)<=10 ) and \
        (subscriberdob is null or length(subscriberdob)<=20 ) and \
        (subscriberssn is null or length(subscriberssn)<=30 ) and \
        (subscriberaddress is null or length(subscriberaddress)<=150 ) and \
        (subscriberstate is null or length(subscriberstate)<=15 ) and \
        (subscribercity is null or length(subscribercity)<=50 ) and \
        (subscriberzip is null or length(subscriberzip)<=20 ) and \
        (clientid is null or length(clientid)<=10 ) and \
        (responseresultext is null or length(responseresultext)<=1 ) and \
        (responseresultstd is null or length(responseresultstd)<=1 ) and \
        (custom1 is null or length(custom1)<=32 ) and \
        (custom2 is null or length(custom2)<=64) \
    ")
    print("DEBUG: goodrows_df" + "\n")
    return goodrows_df

def markedgoodrows_add_col(goodrows):
    markedgoodrows_df = goodrows.select('*', lit("N"))
    print("DEBUG: markedgoodrows_df" + "\n")
    return markedgoodrows_df

def corruptrows_filter(spark, policyinfo):
    policyinfo.registerTempTable("policyinfotable")
    print("DEBUG: Registered temp table policyinfo- policyinfotable" + "\n")
    
    corruptrows_df = spark.sql("SELECT * FROM policyinfotable where \
        (iepermid is not null and length(iepermid)>12) or \
        (tracenumber is not null and length(tracenumber)>15) or \
        (received is not null and length(received)>50) or \
        (providerid is not null and length(providerid)>30) or \
        (providerlastnameorgname is not null and length(providerlastnameorgname)>100) or \
        (subscribergroupnumber is not null and length(subscribergroupnumber)>70) or \
        (subscribersuffixcode is not null and length(subscribersuffixcode)>30) or \
        (subscriberidcode is not null and length(subscriberidcode)>20) or \
        (subscriberid is not null and length(subscriberid)>100) or \
        (dateofservice is not null and length(dateofservice)>30) or \
        (payerid is not null and length(payerid)>50) or \
        (payerid is not null and length(payerid)<5) or \
        (payerproviderid is not null and length(payerproviderid)>30) or \
        (payerlastnameorgname is not null and length(payerlastnameorgname)>100) or \
        (dependentflag is not null and length(dependentflag)>1) or \
        (subscriberfirstname is not null and length(subscriberfirstname)>100) or \
        (subscribermiddlename is not null and length(subscribermiddlename)>100) or \
        (subscriberlastname is not null and length(subscriberlastname)>100) or \
        (subscribergender is not null and length(subscribergender)>10) or \
        (subscriberdob is not null and length(subscriberdob)>20) or \
        (subscriberssn is not null and length(subscriberssn)>30) or \
        (subscriberaddress is not null and length(subscriberaddress)>150) or \
        (subscriberstate is not null and length(subscriberstate)>15) or \
        (subscribercity is not null and length(subscribercity)>50) or \
        (subscriberzip is not null and length(subscriberzip)>20) or \
        (clientid is not null and length(clientid)>10) or \
        (responseresultext is not null and length(responseresultext)>1) or \
        (responseresultstd is not null and length(responseresultstd)>1) or \
        (custom1 is not null and length(custom1)>32) or \
        (custom2 is not null and length(custom2)>64) \
    ")   
    print("DEBUG: corruptrows_df" + "\n")
    return corruptrows_df

def markedcorruptrows_add_col(spark, corruptrows):
    corruptrows.registerTempTable("corruptrowstable")
    print("DEBUG: Registered temp table corruptrows- corruptrowstable" + "\n")

    markedcorruptrows_df = spark.sql("SELECT \
        CASE WHEN length(iepermid)>12 THEN '' ELSE iepermid end as iepermid, \
        CASE WHEN length(tracenumber)>15 THEN '' ELSE tracenumber end as tracenumber, \
        CASE WHEN length(received)>50 THEN '' ELSE received end as received, \
        CASE WHEN length(providerid)>30 THEN '' ELSE providerid end as providerid, \
        CASE WHEN length(providerlastnameorgname)>100 THEN '' ELSE providerlastnameorgname end as providerlastnameorgname, \
        CASE WHEN length(subscribergroupnumber)>70 THEN '' ELSE subscribergroupnumber end as subscribergroupnumber, \
        CASE WHEN length(subscribersuffixcode)>30 THEN '' ELSE subscribersuffixcode end as subscribersuffixcode, \
        CASE WHEN length(subscriberidcode)>20 THEN '' ELSE subscriberidcode end as subscriberidcode, \
        CASE WHEN length(subscriberid)>100 THEN '' ELSE subscriberid end as subscriberid, \
        CASE WHEN length(dateofservice)>30 THEN '' ELSE dateofservice end as dateofservice, \
        CASE WHEN length(payerid)>50 THEN '' ELSE payerid end as payerid, \
        CASE WHEN length(payerproviderid)>30 THEN '' ELSE payerproviderid end as payerproviderid, \
        CASE WHEN length(payerlastnameorgname)>100 THEN '' ELSE payerlastnameorgname end as payerlastnameorgname, \
        CASE WHEN length(dependentflag)>1 THEN '' ELSE dependentflag end as dependentflag, \
        CASE WHEN length(subscriberfirstname)>100 THEN '' ELSE subscriberfirstname end as subscriberfirstname, \
        CASE WHEN length(subscribermiddlename)>100 THEN '' ELSE subscribermiddlename end as subscribermiddlename, \
        CASE WHEN length(subscriberlastname)>100 THEN '' ELSE subscriberlastname end as subscriberlastname, \
        CASE WHEN length(subscribergender)>10 THEN '' ELSE subscribergender end as subscribergender, \
        CASE WHEN length(subscriberdob)>20 THEN '' ELSE subscriberdob end as subscriberdob, \
        CASE WHEN length(subscriberssn)>30 THEN '' ELSE subscriberssn end as subscriberssn, \
        CASE WHEN length(subscriberaddress)>150 THEN '' ELSE subscriberaddress end as subscriberaddress, \
        CASE WHEN length(subscriberstate)>15 THEN '' ELSE subscriberstate end as subscriberstate, \
        CASE WHEN length(subscribercity)>50 THEN '' ELSE subscribercity end as subscribercity, \
        CASE WHEN length(subscriberzip)>20 THEN '' ELSE subscriberzip end as subscriberzip, \
        esmatchind, \
        CASE WHEN length(clientid)>10 THEN '' ELSE clientid end as clientid, \
        CASE WHEN length(responseresultext)>1 THEN '' ELSE responseresultext end as responseresultext, \
        CASE WHEN length(responseresultstd)>1 THEN '' ELSE responseresultstd end as responseresultstd, \
        CASE WHEN length(custom1)>32 THEN SUBSTRING(custom1,0,32) ELSE custom1 end as custom1,  \
        CASE WHEN length(custom2)>64 THEN SUBSTRING(custom2,0,64) ELSE custom2 end as custom2, \
        'Y' \
        FROM corruptrowstable \
    ")    
    
    print("DEBUG: markedcorruptrows_df" + "\n")
    return markedcorruptrows_df

def unioned_allmarkedrows(markedgoodrows, markedcorruptrows):
    allmarkedrows_df = markedgoodrows.union(markedcorruptrows)
    withoutblankclientids = allmarkedrows_df.filter(col("clientid").isNotNull() & (col("clientid") != ''))
    print("DEBUG: allmarkedrows_df unioned from markedgoodrows and markedcorruptrows" + "\n")
    return withoutblankclientids

# COMMAND ----------

# DBTITLE 1,Client ID to Block
def clientidtoblock(spark, clientidtoblock_dir):
    clientidtoblock_schema = StructType([StructField("cidtoblock", StringType())])

    # clientidtoblock_df = spark.read.format("csv").schema(clientidtoblock_schema).options(quote="").load(clientidtoblock_dir)
    clientidtoblock_df = readcsv(spark, clientidtoblock_dir, clientidtoblock_schema, '|', '0', 'na')
    print("DEBUG: Loaded source file clientidtoblock" + str(clientidtoblock_dir) + "\n")
    return clientidtoblock_df

# COMMAND ----------

# DBTITLE 1,Right Join distinct_src_load3(cidtoblock) & allmarkedrows (clientid)
def rightouterjoin_filter(distinct_src_load3, allmarkedrows):
    rightouterjoin_df = distinct_src_load3.join(allmarkedrows, distinct_src_load3.cidtoblock == allmarkedrows.clientid, "right_outer")
    print("DEBUG: distinct_src_load3 rightoutter joined to allmarkedrows on distinct_src_load3.cidtoblock == allmarkedrows.clientid" + "\n")
    rightouterjoinrecs_df = rightouterjoin_df.filter(col("cidtoblock").isNull())
    print("DEBUG: rightouterjoinrecs_df filtered for nulls" + "\n")
    return rightouterjoinrecs_df    

def generate_gen1(rightouterjoinrecs):
    gen1_df = rightouterjoinrecs.select(col("iePermId"), \
        col("TraceNumber"), \
        col("Received"), \
        col("providerId"), \
        col("providerLastNameOrgName"), \
        col("subscriberGroupNumber"), \
        col("subscriberSuffixCode"), \
        col("subscriberIdCode"), \
        col("subscriberId"), \
        col("dateOfService"), \
        col("payerId"), \
        col("payerProviderId"), \
        col("payerLastNameOrgName"), \
        col("dependentFlag"), \
        col("subscriberFirstName"), \
        col("subscriberMiddleName"), \
        col("subscriberLastName"), \
        col("subscriberGender"), \
        col("subscriberDOB"), \
        col("subscriberSSN"), \
        col("subscriberAddress"), \
        col("subscriberState"), \
        col("subscriberCity"), \
        col("subscriberZip"), \
        col("esMatchInd"), \
        col("clientId"), \
        col("ResponseResultExt"), \
        col("ResponseResultStd"), \
        col("Custom1"), \
        col("Custom2"), \
        col("N").alias("corrupt flag") \
    )
    print("DEBUG: Generated gen1_df" + "\n")
    return gen1_df


# COMMAND ----------

# DBTITLE 1,Generate extracts
def extract_gen1(gen1, gen1_dir):
    gen1.repartition(10).write.format('csv').mode('overwrite').options(delimiter="|").option("emptyValue", None).option("nullValue", None).save(gen1_dir)
    print("DEBUG: Extracted gen1 successfully gen1_dir - " + str(gen1_dir) + "\n")

def tgt_gen1_load(spark, gen1_dir):
    fp_load = spark.read.format("csv").options(quote="", delimiter="|").load(gen1_dir)
    fp_df = fp_load.na.fill("")
    return fp_df

def extract_f1(f1, f1_dir):
    f1.repartition(5).write.format('csv').mode('overwrite').options(delimiter="|").option("emptyValue", None).option("nullValue", None).save(f1_dir)
    print("DEBUG: Extracted f1 successfully f1_dir - " + str(f1_dir) + "\n")
 
def extract_f2(f2, f2_dir): 
    f2.repartition(5).write.format('csv').mode('overwrite').options(delimiter="|").option("emptyValue", None).option("nullValue", None).save(f2_dir)
    print("DEBUG: Extracted f2 successfully f2_dir - " + str(f2_dir) + "\n")
    

# COMMAND ----------

# DBTITLE 1,Execution
print("DEBUG: Incremental ES Processing BEGIN" + "\n")
src_load1 = load_esincpostbdfallfields(spark,esincinputdir)    
filter_src_load1 = filter_esincpeople(src_load1)    
extract_filter_src_load1 = extract_pqt_stg_esincpeople(filter_src_load1, esincpeople_stg_parquet)

src_load2 = load_iepostbdf(spark, ieallinputdir)
extract_src_load2 = extract_pqt_stg_iepostbdf(src_load2, iepostbdf_fill_stg_parquet)

stg_load1 = load_stg_esincpeople(spark, esincpeople_stg_parquet)
stg_load2 = load_stg_iepostbdf(spark, iepostbdf_fill_stg_parquet)

join_stgload1_stgload2 = joined_escincpeople_iepostbdf(stg_load1, stg_load2)

subs = subs_joined_filter(join_stgload1_stgload2)
deps = deps_joined_filter(join_stgload1_stgload2)

policyinfo1 = subs_filter(subs)
policyinfo2 = deps_filter(deps)
policyinfo = unioned_pinfo1_pinfo2(policyinfo1, policyinfo2)

goodrows = goodrows_filter(spark, policyinfo)
markedgoodrows = markedgoodrows_add_col(goodrows)

corruptrows = corruptrows_filter(spark, policyinfo)
markedcorruptrows = markedcorruptrows_add_col(spark, corruptrows)
allmarkedrows = unioned_allmarkedrows(markedgoodrows, markedcorruptrows)

src_load3 = clientidtoblock(spark, clientidtoblock_dir)
distinct_src_load3 = src_load3.distinct()
print("DEBUG: Duplicates removed from source file clientidtoblock_dir" + str(clientidtoblock_dir)) 

rightouterjoinrecs = rightouterjoin_filter(distinct_src_load3, allmarkedrows)
gen1 = generate_gen1(rightouterjoinrecs)
    
dump_gen1 = extract_gen1(gen1, gen1_dir)

# fp = tgt_gen1_load(spark, dump_gen1, gen1_dir)    
fp = tgt_gen1_load(spark, gen1_dir)    
f1 = fp.filter(trim(col("_c24")) != 'M1') 
f2 = fp.filter(trim(col("_c24")) == 'M1')

dump_f1 = extract_f1(f1, f1_dir)
dump_f2 = extract_f2(f2, f2_dir)

print("DEBUG: Policy Info Script Execution Completed")
# spark.stop()