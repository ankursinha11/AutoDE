# Databricks notebook source
# hh_phone.py

# COMMAND ----------

# DBTITLE 1,Input Variables
# Set variables
dbutils.widgets.text("bcdate","")
dbutils.widgets.getArgument("bcdate")
bcdate= getArgument("bcdate")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("input_cdd_dir","")
dbutils.widgets.getArgument("input_cdd_dir")
input_cdd_dir= getArgument("input_cdd_dir")

dbutils.widgets.text("output_cdd_dir","")
dbutils.widgets.getArgument("output_cdd_dir")
output_cdd_dir= getArgument("output_cdd_dir")

dbutils.widgets.text("tu_input_dir","")
dbutils.widgets.getArgument("tu_input_dir")
tu_input_dir= getArgument("tu_input_dir")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")


if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 


# COMMAND ----------

# DBTITLE 1,Run common_util
# MAGIC %run "/Insleads-code/Common-Util/common_util"

# COMMAND ----------

# DBTITLE 1,adls access
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# DBTITLE 1,eScan data
# Load ESBDF relation. eScan data post BDF
esBDFschema = StructType([
    StructField("MagnetPermId", StringType(), True),
	StructField("PermId", StringType(), True),
    StructField("MatchInd", StringType(), True),
    StructField("LinkId", StringType(), True)
])

ESBDF = readcsv(spark, baseurl+input_cdd_dir+"/allDistinctRecs/"+bcdate, esBDFschema, '|', '0', 'na')

# COMMAND ----------

# DBTITLE 1,Read  TU phone data and Join
TUPHONE = spark.read.parquet(baseurl+tu_input_dir+"/phone/current/*")
PHJOINED = ESBDF.join(TUPHONE, ESBDF.PermId == TUPHONE.TUKEY)

PHOUT = PHJOINED.select(
    PHJOINED.MagnetPermId,
    PHJOINED.TUKEY,
    PHJOINED.MatchInd,
    PHJOINED.PHONE_SEQ_NUM,
    PHJOINED.PHONE_NUM,
    PHJOINED.PHONE_FRST_RPTD_DTE
)

# COMMAND ----------

# DBTITLE 1,PHOUT
# Store ADOUT to output directory
writecsv(spark, PHOUT, baseurl+output_cdd_dir+"/tuphone/"+bcdate, 1, 'overwrite', "|")
