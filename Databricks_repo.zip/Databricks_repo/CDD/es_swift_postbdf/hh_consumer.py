# Databricks notebook source
# hh_consumer.py

# COMMAND ----------

# DBTITLE 1,Input Variables
# Set variables
dbutils.widgets.text("bcdate","")
dbutils.widgets.getArgument("bcdate")
bcdate= getArgument("bcdate")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("input_cdd_dir","")
dbutils.widgets.getArgument("input_cdd_dir")
input_cdd_dir= getArgument("input_cdd_dir")

dbutils.widgets.text("output_cdd_dir","")
dbutils.widgets.getArgument("output_cdd_dir")
output_cdd_dir= getArgument("output_cdd_dir")

dbutils.widgets.text("tu_input_dir","")
dbutils.widgets.getArgument("tu_input_dir")
tu_input_dir= getArgument("tu_input_dir")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")


if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user  

print(baseurl+input_cdd_dir+"/allDistinctRecs/"+bcdate)    

# COMMAND ----------

# DBTITLE 1,Run common_util
# MAGIC %run "/Insleads-code/Common-Util/common_util"

# COMMAND ----------

# DBTITLE 1,adls access
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# DBTITLE 1,eScan data
# Load ESBDF relation. eScan data post BDF
esBDFschema = StructType([
    StructField("MagnetPermId", StringType(), True),
	StructField("PermId", StringType(), True),
    StructField("MatchInd", StringType(), True),
    StructField("LinkId", StringType(), True)
])

ESBDF = readcsv(spark, baseurl+input_cdd_dir+"/allDistinctRecs/"+bcdate, esBDFschema, '|', '0', 'na')

# ESBDFALL = spark.read.format("csv").option("delimiter", "|").load(esInputDir)
# ESBDF = ESBDFALL.select(
#     ESBDFALL._c0.alias("MagnetPermId"),
#     ESBDFALL._c1.alias("PermId"),
#     ESBDFALL._c2.alias("MatchInd"),
#     ESBDFALL._c3.alias("LinkId")
# )

# COMMAND ----------

# DBTITLE 1,Read TU consumer data and Join
TUCONSUMER=spark.read.parquet(baseurl+tu_input_dir+"/consumer/current/*")
# Join escan and TU consumer by permid
CSJOINED = ESBDF.join(TUCONSUMER, ESBDF.PermId == TUCONSUMER.TUKEY)

CSOUT = CSJOINED.select(
    ESBDF.MagnetPermId,
    TUCONSUMER.TUKEY,
    ESBDF.MatchInd,
    TUCONSUMER.SSN,
    TUCONSUMER.FRST_NME,
    TUCONSUMER.MIDL_NME,
    TUCONSUMER.LAST_NME,
    TUCONSUMER.GENERATIONAL_NME_SFX,
    TUCONSUMER.NME_PFX_CDE,
    TUCONSUMER.NME_SFX_CDE,
    TUCONSUMER.DOB
)

# COMMAND ----------

# DBTITLE 1,CSOUT
# Store CSOUT into the specified directory
print("CSOUT Path:" + str(baseurl+output_cdd_dir+"/tuconsumer/"+bcdate))
writecsv(spark, CSOUT, baseurl+output_cdd_dir+"/tuconsumer/"+bcdate, 1, 'overwrite', "|")
