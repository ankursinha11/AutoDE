# Databricks notebook source
# es_package.py

# COMMAND ----------

# DBTITLE 1,Input Variables
# Set variables
dbutils.widgets.text("inDate","")
dbutils.widgets.getArgument("inDate")
inDate= getArgument("inDate")

outDate= inDate

dbutils.widgets.text("ieInDate","")
dbutils.widgets.getArgument("ieInDate")
ieInDate= getArgument("ieInDate")

dbutils.widgets.text("withesinc","")
dbutils.widgets.getArgument("withesinc")
withesinc= getArgument("withesinc")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("input_cdd_dir","")
dbutils.widgets.getArgument("input_cdd_dir")
input_cdd_dir= getArgument("input_cdd_dir")

dbutils.widgets.text("output_cdd_dir","")
dbutils.widgets.getArgument("output_cdd_dir")
output_cdd_dir= getArgument("output_cdd_dir")

dbutils.widgets.text("datasource","")
dbutils.widgets.getArgument("datasource")
datasource= getArgument("datasource")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user  

output_file_path = baseurl + "/" + output_cdd_dir + "/package_for_es/"


# COMMAND ----------

# DBTITLE 1,adls access
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# DBTITLE 1,Clean up - Previous run
# for i in dbutils.fs.ls(output_file_path):
#     if i.path == output_file_path + "/" + outDate +'/':
#         dbutils.fs.rm(output_file_path + "/" + outDate,True)

# dbutils.fs.mkdirs(output_file_path + "/" + outDate)

# COMMAND ----------

# DBTITLE 1,Size Calculation
def merge_split(input_folder, output_file_path, output_file_name, maxfilesize, custom_param = None):
    if custom_param == 'M1':
        input_file_path = [folder for folder in dbutils.fs.ls(input_folder) if folder.path.endswith(outDate+"-M1/")][0].path
    else:
        input_file_path = [folder for folder in dbutils.fs.ls(input_folder) if folder.path.endswith(outDate+"/")][0].path

    inputfilesize = 0
    for i in dbutils.fs.ls(input_file_path):
        inputfilesize = inputfilesize+i.size

    totalnooffiles = int(inputfilesize/maxfilesize)+1 # to write to multiple 300MB files
    print(str(input_file_path) + " total no of files : " + str(totalnooffiles))

    df = spark.read.text(input_file_path)
    df.repartition(totalnooffiles).write.mode("overwrite").option("maxPartitionBytes",maxfilesize).option("compression","deflate").csv(output_file_path  + "/" + outDate + "/temp")

    for i in dbutils.fs.ls(output_file_path  + "/" + outDate + "/temp"):
        if '.csv' in i.path and totalnooffiles >0:
            dbutils.fs.mv(i.path, output_file_path + "/" + outDate + "/" + output_file_name + '-' + str(totalnooffiles))
            totalnooffiles=totalnooffiles-1
    
    dbutils.fs.rm(output_file_path + "/" + outDate + "/temp", True)

# COMMAND ----------

# subprocess.run(["ls", f"{nfs_mount}/{cdd_dir}/input/es/{inDate}"], capture_output=True, text=True).stdout.split("\n")[0].split("_")[-1].split(".")[0]
# dbutils.fs.ls("abfss://prod-icd-dev-adls@divyaprodstorageact1.dfs.core.windows.net/ravee/data/cdd/publish/escanoutput/tuconsumer/20230427T20/").stdout.split("\n")[0].split("_")[-1].split(".")[0]

# COMMAND ----------

# escanTag = 

if withesinc == "T":
    merge_split(f"{baseurl}/{input_cdd_dir}/publish/escanoutput/permIdPatientAcctId/", output_file_path + "es/", f"TU_{outDate}_PermId_PatientAcctId-map.merged", 314572800)

    merge_split(f"{baseurl}/{input_cdd_dir}/publish/escanoutput/permIdPatientAcctId/", output_file_path + "es/" , f"TU_{outDate}_PermId_PatientAcctId-CustomMatch1.merged", 314572800, "M1")

    merge_split(f"{baseurl}/{input_cdd_dir}/publish/escanoutput/es_nohits/", output_file_path + "es/", f"TU_{outDate}_PatientAcctId-NoHits.merged", 314572800)

    merge_split(f"{baseurl}/{input_cdd_dir}/publish/escanoutput/tuconsumer/", output_file_path + "es/", f"TU_{outDate}_TUConsumerInfo.merged", 314572800)

    merge_split(f"{baseurl}/{input_cdd_dir}/publish/escanoutput/tuaddress/", output_file_path + "es/", f"TU_{outDate}_TUAddressInfo.merged", 314572800)

    merge_split(f"{baseurl}/{input_cdd_dir}/publish/escanoutput/tuphone/", output_file_path + "es/", f"TU_{outDate}_TUPhoneInfo.merged", 314572800)

    merge_split(f"{baseurl}/{input_cdd_dir}/publish/escanoutput/finalPolicyInfo/", output_file_path + "es/", f"TU_{outDate}_PolicyInfo.merged", 314572800)

    merge_split(f"{baseurl}/{input_cdd_dir}/publish/escanoutput/finalPolicyInfo/", output_file_path + "es/", f"TU_{outDate}_CustomMatch1.merged", 314572800, "M1")

    merge_split(f"{baseurl}/{input_cdd_dir}/publish/es_cm2/finalPolicyInfo/", output_file_path + "es/", f"TU_{outDate}_CustomMatch2.merged", 314572800)

elif withesinc == "G":
    merge_split(f"{baseurl}/{input_cdd_dir}/publish/esgmrn_cm2/finalPolicyInfo/", output_file_path+ "esgmrn/", f"TU_{outDate}_gmrn{ieInDate}_CustomMatch2.merged", 314572800)

elif withesinc == "S":
    escanTag="esswift"

    merge_split(f"{baseurl}/{input_cdd_dir}/publish/escanoutput/permIdPatientAcctId/", output_file_path + "es/", f"TU_${outDate}_${escanTag}_PermId_PatientAcctId-map.merged", 314572800)

    merge_split(f"{baseurl}/{input_cdd_dir}/publish/escanoutput/permIdPatientAcctId/", output_file_path + "es/" , f"TU_${outDate}_${escanTag}_ie${outDate}only_PermId_PatientAcctId-CustomMatch1.merged", 314572800, "M1")

    merge_split(f"{baseurl}/{input_cdd_dir}/publish/escanoutput/es_nohits/", output_file_path + "es/", f"TU_${outDate}_${escanTag}_ie${outDate}only_PatientAcctId-NoHits.merged", 314572800)

    merge_split(f"{baseurl}/{input_cdd_dir}/publish/escanoutput/tuconsumer/", output_file_path + "es/", f"TU_${outDate}_${escanTag}_ie${outDate}only_TUConsumerInfo.merged", 314572800)

    merge_split(f"{baseurl}/{input_cdd_dir}/publish/escanoutput/tuaddress/", output_file_path + "es/", f"TU_${outDate}_${escanTag}_ie${outDate}only_TUAddressInfo.merged", 314572800)

    merge_split(f"{baseurl}/{input_cdd_dir}/publish/escanoutput/tuphone/", output_file_path + "es/", f"TU_${outDate}_${escanTag}_ie${outDate}only_TUPhoneInfo.merged", 314572800)

    merge_split(f"{baseurl}/{input_cdd_dir}/publish/escanoutput/finalPolicyInfo/", output_file_path + "es/", f"TU_${outDate}_${escanTag}_ie${outDate}only_PolicyInfo.merged", 314572800)

    merge_split(f"{baseurl}/{input_cdd_dir}/publish/escanoutput/finalPolicyInfo/", output_file_path + "es/", f"TU_${outDate}_${escanTag}_ie${outDate}only_CustomMatch1.merged", 314572800, "M1")

    merge_split(f"{baseurl}/{input_cdd_dir}/publish/es_cm2/finalPolicyInfo/", output_file_path + "es/", f"TU_${outDate}_${escanTag}_ie${outDate}only_CustomMatch2.merged", 314572800)

else:
    merge_split(f"{baseurl}/{input_cdd_dir}/publish/escanoutput/noesinc/finalPolicyInfo/", output_file_path + "ie/", f"TU_${outDate}_ie${ieInDate}only_PolicyInfo.merged", 314572800)

    merge_split(f"{baseurl}/{input_cdd_dir}/publish/escanoutput/noesinc/finalPolicyInfo/", output_file_path + "ie/" , f"TU_${outDate}_ie${ieInDate}only_CustomMatch1.merged", 314572800, "M1")

    merge_split(f"{baseurl}/{input_cdd_dir}/publish/ie_cm2/finalPolicyInfo/", output_file_path + "ie/", f"TU_${outDate}_ie${ieInDate}_CustomMatch2.merged", 314572800)