# Databricks notebook source
# hh_address.py

# COMMAND ----------

# DBTITLE 1,Input Variables
# Set variables
dbutils.widgets.text("bcdate","")
dbutils.widgets.getArgument("bcdate")
bcdate= getArgument("bcdate")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("input_cdd_dir","")
dbutils.widgets.getArgument("input_cdd_dir")
input_cdd_dir= getArgument("input_cdd_dir")

dbutils.widgets.text("output_cdd_dir","")
dbutils.widgets.getArgument("output_cdd_dir")
output_cdd_dir= getArgument("output_cdd_dir")

dbutils.widgets.text("tu_input_dir","")
dbutils.widgets.getArgument("tu_input_dir")
tu_input_dir= getArgument("tu_input_dir")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")


if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 


# COMMAND ----------

# DBTITLE 1,Run common_util
# MAGIC %run "/Insleads-code/Common-Util/common_util"

# COMMAND ----------

# DBTITLE 1,adls access
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# DBTITLE 1,eScan data
# Load ESBDF relation. eScan data post BDF
esBDFschema = StructType([
    StructField("MagnetPermId", StringType(), True),
	StructField("PermId", StringType(), True),
    StructField("MatchInd", StringType(), True),
    StructField("LinkId", StringType(), True)
])

ESBDF = readcsv(spark, baseurl+input_cdd_dir+"/allDistinctRecs/"+bcdate, esBDFschema, '|', '0', 'na')
# display(ESBDF)

# COMMAND ----------

# DBTITLE 1,Read  TU address data and Join
TUADDRESS = spark.read.parquet(baseurl+tu_input_dir+"/address/current/*")
# Join escan and TU address by PermId
ADJOINED = ESBDF.join(TUADDRESS, ESBDF.PermId == TUADDRESS.TUKEY)
ADOUT = ADJOINED.select(
    ADJOINED.MagnetPermId,
    ADJOINED.TUKEY,
    ADJOINED.MatchInd,
    ADJOINED.ADDR_SEQ_NUM,
    ADJOINED.ADDR_NUM,
    ADJOINED.PREDIR_CDE,
    ADJOINED.STR_NME,
    ADJOINED.STR_TYP_CDE,
    ADJOINED.POSTDIR_CDE,
    ADJOINED.UNIT_TYPE,
    ADJOINED.UNIT_NUM,
    ADJOINED.CITY_NME,
    ADJOINED.STATE_CDE,
    ADJOINED.ZIP_CDE,
    ADJOINED.ZIP_EXTND_CDE,
    ADJOINED.ADDR_FRST_RPTD_DTE,
    ADJOINED.STD_FLG
)
# display(ADJOINED)
# display(ADOUT)

# COMMAND ----------

# DBTITLE 1,ADOUT
# Store ADOUT to output directory
writecsv(spark, ADOUT, baseurl+output_cdd_dir+"/tuaddress/"+bcdate, 500, 'overwrite', "|")
