# Databricks notebook source
# es_uploaddeg.py

# COMMAND ----------

# DBTITLE 1,Input Variables
# Set variables
dbutils.widgets.text("bcdate","")
dbutils.widgets.getArgument("bcdate")
bcdate= getArgument("bcdate")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("input_cdd_dir","")
dbutils.widgets.getArgument("input_cdd_dir")
input_cdd_dir= getArgument("input_cdd_dir")

dbutils.widgets.text("output_cdd_dir","")
dbutils.widgets.getArgument("output_cdd_dir")
output_cdd_dir= getArgument("output_cdd_dir")

dbutils.widgets.text("datasource","")
dbutils.widgets.getArgument("datasource")
datasource= getArgument("datasource")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user  

# COMMAND ----------

# DBTITLE 1,adls access
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

from datetime import datetime
import subprocess
import os

nfs_mount = "/shared/hdfs"

if datasource == 'ie':
    DS = 'IE'
elif datasource == 'es':
    DS = 'ES'
elif datasource == 'esgmrn':
    DS = 'ESGMRN'

os.chdir(os.path.join(nfs_mount, input_cdd_dir, "publish", "package_for_es", datasource, bcdate))

log_entry = f"{DS}|{bcdate}|OUT|{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
with open(os.path.join(nfs_mount, input_cdd_dir, "input", "sla", "data"), "a") as log_file:
    log_file.write(log_entry + "\n")

subprocess.call(["scp", "*.zip", "datagateway-internal.transunion.com:/MKT/TransUnion_Healthcare/dgmtuhcr/ToTU/Chicago_To_eScan"])

os.chdir(os.path.join(nfs_mount, input_cdd_dir, "publish", "package_for_es", datasource, bcdate))

for file in os.listdir("."):
    if file.endswith(".zip"):
        log_entry = f"TU|Sent|{file}|{datetime.now().strftime('%m%d%Y')}"
        with open(os.path.join(nfs_mount, input_cdd_dir, "input", "es_ack", "tu_data"), "a") as log_file:
            log_file.write(log_entry + "\n")
