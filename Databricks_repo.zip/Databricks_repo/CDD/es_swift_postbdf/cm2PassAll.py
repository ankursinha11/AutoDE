# Databricks notebook source
#cm2PassAll.py used by ie_postbdf and es_swift_postbdf

# COMMAND ----------

# DBTITLE 1,input parameters
#define input variables
dbutils.widgets.text("bcdate","") # bc date from ie_postbdf or es_swift_postbdf
dbutils.widgets.getArgument("bcdate")
bcdate= getArgument("bcdate")

dbutils.widgets.text("esdate","") # specific to es_swift_postbdf
dbutils.widgets.getArgument("esdate")
esdate = getArgument("esdate")

dbutils.widgets.text("iedate", "") #specific to ie_postbdf
dbutils.widgets.getArgument("iedate")
iedate= getArgument("iedate")

dbutils.widgets.text("gmrndate","") # not used in script so blank
dbutils.widgets.getArgument("gmrndate")
gmrndate= getArgument("gmrndate")

dbutils.widgets.text("outFolder","") # ie_cm2 or es_cm2
dbutils.widgets.getArgument("outFolder")
outFolder= getArgument("outFolder")

dbutils.widgets.text("cm2_user_folder","") # /hcecdd/user/${user.name}/CDD
dbutils.widgets.getArgument("cm2_user_folder")
cm2_user_folder = getArgument("cm2_user_folder")

dbutils.widgets.text("cm2_hcedata_user_folder","") #hcedata/user/${user.name}/CDD
dbutils.widgets.getArgument("cm2_hcedata_user_folder")
cm2_hcedata_user_folder = getArgument("cm2_hcedata_user_folder")

dbutils.widgets.text("path_stg_parquet","") # same as cm2_user_folder
dbutils.widgets.getArgument("path_stg_parquet")
path_stg_parquet = getArgument("path_stg_parquet")

dbutils.widgets.text("cm2_action_flag","") # cm2_read_src_files orcm2_match1 etc
dbutils.widgets.getArgument("cm2_action_flag")
cm2_action_flag = getArgument("cm2_action_flag")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

trange = 5
p_factor = (trange)

# COMMAND ----------

# DBTITLE 1,set base path
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

# DBTITLE 1,adls access
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# DBTITLE 1,import common util
# MAGIC %run "/Insleads-code/Common-Util/common_util" 

# COMMAND ----------

import os
import sys
from pyspark.sql import SparkSession,DataFrame
from pyspark.sql.functions import *
import datetime
import math
from pyspark.sql.types import *
from pyspark import SparkContext
from pyspark.conf import SparkConf
from functools import reduce

# COMMAND ----------

def extract_pqt_stg_ieAllParsed(ieAllParsed_src_load, ieAllParsed_path_stg_pqt,ieAllParsed_partition_cnt,p_factor):
    ieAllParsed_fill=ieAllParsed_src_load.withColumn("transactionrange", (ieAllParsed_src_load.TraceNumber.cast("bigint") % p_factor).cast("bigint"))
    writepartitionByParquet(ieAllParsed_fill, ieAllParsed_path_stg_pqt,ieAllParsed_partition_cnt)
    print("DEBUG: Staging source ieAllParsed extraction completed " + str(ieAllParsed_path_stg_pqt) + "\n")

    return ieAllParsed_fill

# COMMAND ----------

def writepartitionByParquet(df, filepath, repartition_cnt):
    df = df.coalesce(repartition_cnt)
    df.write.partitionBy("transactionrange").mode("overwrite").parquet(filepath)
    return None

# COMMAND ----------

def extract_ieAllOnlyDemoSubset(ieAllOnlyDemoSubset_tmp, ieAllOnlyDemoSubset_tmp_path, ieAllParsed_partition_cnt):
    ieAllParsed_fill=ieAllOnlyDemoSubset_tmp.na.fill("")
    ieAllParsed_fill.repartition(ieAllParsed_partition_cnt).write.mode('overwrite'). \
                                    parquet(ieAllOnlyDemoSubset_tmp_path)
    print("DEBUG: Staging source ieAllOnlyDemoSubset extraction completed " + str(ieAllOnlyDemoSubset_tmp_path) + "\n")

# COMMAND ----------

def extract_pqt_stg_esInput1_load(esInput1_load, esScrubbedPath_stg_pqt, esInput1_load_partition_cnt):
    esInput1_load_fill=esInput1_load.na.fill("")
    esInput1_load_fill.repartition(esInput1_load_partition_cnt).write.mode('overwrite'). \
                                    parquet(esScrubbedPath_stg_pqt)
    print("DEBUG: Staging source extract_pqt_stg_esInput1_load extraction completed " + str(esScrubbedPath_stg_pqt) + "\n")

# COMMAND ----------

def ieAllParsed_part_cnt(iedate):
    if iedate == '/':
        ieAllParsed_partition_cnt=600
        return ieAllParsed_partition_cnt
    else: 
        ieAllParsed_partition_cnt=10
        return ieAllParsed_partition_cnt 

# COMMAND ----------

def esInput1_load_part_cnt(esdate):
    if esdate == '/':
        esInput1_load_partition_cnt=100
        return esInput1_load_partition_cnt
    else: 
        esInput1_load_partition_cnt=10
        return esInput1_load_partition_cnt

# COMMAND ----------

def saveFinalResults(allMarkedRows, allMarkedRows_path):
    df = allMarkedRows.withColumn('esMatchInd',col("matchInd")) \
    .select("GMRNId","TraceNumber","Received","providerId","providerLastNameOrgName", \
    "subscriberGroupNumber","subscriberSuffixCode","subscriberIdCode","subscriberId","dateOfService", \
    "payerId","payerProviderId", "payerLastNameOrgName","dependentFlag", \
    "subscriberFirstName","subscriberMiddleName","subscriberLastName","subscriberGender", \
    "subscriberDOB","subscriberSSN","subscriberAddress","subscriberState","subscriberCity", \
    "subscriberZip", "esMatchInd","clientId","ResponseResultExt","ResponseResultStd", \
    "Custom1","Custom2","corruptFlag")
    save_delimited_file(df, allMarkedRows_path)

# COMMAND ----------

def addValidation(policyInfo, colName, maxSize):
    errorCondition = (col(colName).isNotNull() & (length(col(colName)) > maxSize))
    df = policyInfo.withColumn(colName+'_orig',col(colName))
    df = df.withColumn(colName+'_error', when(errorCondition,'Y').otherwise('N')) \
    .withColumn(colName, when(errorCondition,'').otherwise(col(colName)))
    return df

# COMMAND ----------

def addValidationForAllColumns(policyInfo):
    df = policyInfo
    df = addValidation(df, 'TraceNumber', 15)
    df = addValidation(df, 'Received', 50)
    df = addValidation(df, 'providerId', 30)
    df = addValidation(df, 'providerLastNameOrgName', 100)
    df = addValidation(df, 'subscriberGroupNumber', 70)
    df = addValidation(df, 'GMRNId', 12)
    df = addValidation(df, 'subscriberSuffixCode', 30)
    df = addValidation(df, 'subscriberIdCode', 20)
    df = addValidation(df, 'subscriberId', 100)
    df = addValidation(df, 'dateOfService', 30)
    df = addValidation(df, 'payerId', 50)
    df = addValidation(df, 'payerProviderId', 30)
    df = addValidation(df, 'payerLastNameOrgName', 100)
    df = addValidation(df, 'dependentFlag', 1)
    df = addValidation(df, 'subscriberFirstName', 100)
    df = addValidation(df, 'subscriberMiddleName', 100)
    df = addValidation(df, 'subscriberLastName', 100)
    df = addValidation(df, 'subscriberGender', 10)
    df = addValidation(df, 'subscriberDOB', 20)
    df = addValidation(df, 'subscriberSSN', 30)
    df = addValidation(df, 'subscriberAddress', 150)
    df = addValidation(df, 'subscriberState', 15)
    df = addValidation(df, 'subscriberCity', 50)
    df = addValidation(df, 'subscriberZip', 20)
    df = addValidation(df, 'clientId', 10)
    df = addValidation(df, 'ResponseResultExt', 1)
    df = addValidation(df, 'ResponseResultStd', 1)
    df = addValidation(df, 'Custom1', 32)
    df = addValidation(df, 'Custom2', 64)
    return df

# COMMAND ----------

def addOverallValidation(policyInfo):
    valCondition = ((col("GMRNId_error") == 'Y') |  \
    (col("TraceNumber_error") == 'Y') |  \
    (col("Received_error") == 'Y') |  \
    (col("providerId_error") == 'Y') |  \
    (col("providerLastNameOrgName_error") == 'Y') |  \
    (col("subscriberGroupNumber_error") == 'Y') |  \
    (col("subscriberSuffixCode_error") == 'Y') |  \
    (col("subscriberIdCode_error") == 'Y') |  \
    (col("subscriberId_error") == 'Y') |  \
    (col("dateOfService_error") == 'Y') |  \
    (col("payerId_error") == 'Y') |  \
    (col("payerProviderId_error") == 'Y') | \
    (col("payerLastNameOrgName_error") == 'Y') |  \
    (col("dependentFlag_error") == 'Y') |  \
    (col("subscriberFirstName_error") == 'Y') |  \
    (col("subscriberMiddleName_error") == 'Y') |  \
    (col("subscriberLastName_error") == 'Y') |  \
    (col("subscriberGender_error") == 'Y') |  \
    (col("subscriberDOB_error") == 'Y') |  \
    (col("subscriberSSN_error") == 'Y') |  \
    (col("subscriberAddress_error") == 'Y') |  \
    (col("subscriberState_error") == 'Y') |  \
    (col("subscriberCity_error") == 'Y') |  \
    (col("subscriberZip_error") == 'Y') |  \
    (col("clientId_error") == 'Y') |  \
    (col("ResponseResultExt_error") == 'Y') |  \
    (col("ResponseResultStd_error") == 'Y') |  \
    (col("Custom1_error") == 'Y') |  \
    (col("Custom2_error") == 'Y'))
    df = policyInfo.withColumn('corruptFlag',when(valCondition,'Y').otherwise('N'))
    return df

# COMMAND ----------

def readFile(spark, filepath, schema):
    df = spark.read.format("csv") \
        .options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", delimiter="|") \
        .schema(schema) \
        .load(filepath)
    return df

# COMMAND ----------

#special method for reading nested files

def readFileNested(spark,filepath,schema):
    filepath_nested = filepath + "/*/"
    try:
      df=readFile(spark, filepath_nested, schema)
      return df
    except:
      df=readFile(spark, filepath, schema)
      return df

# COMMAND ----------

def saveTextFile(df, filepath):
    df.repartition(10).write \
        .format("csv") \
        .option("header", "false") \
        .option("sep", "|") \
        .mode("overwrite") \
        .save(filepath)

# COMMAND ----------

def writeParquet(df, filepath):
    df.write.mode("overwrite").parquet(filepath)

# COMMAND ----------

def readFromParquet(spark,filepath):
    df = spark.read.parquet(filepath)
    return df

# COMMAND ----------

def save_delimited_file(df, filepath, delimiter='|'):
    df.coalesce(100).write \
        .format("csv") \
        .options(header="false", timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", delimiter=delimiter,emptyValue='') \
        .mode("overwrite") \
        .save(filepath)

# COMMAND ----------

def extract_parquet_data(spark, hdfs_path, cols=None):
    if cols == '' or cols is None:
        df = spark.read.parquet(hdfs_path)
    else:
        df = spark.read.parquet(hdfs_path).select(cols)
    return df

# COMMAND ----------

def load_esInputMissingPAIds(spark, esInputMissingPAIdsPath):
    missingschema = StructType([
        StructField("paifkint", IntegerType()),
        StructField("hospitalfk", StringType())
    ])
    df = readFile(spark, esInputMissingPAIdsPath, missingschema) \
        .filter(col("paifkint").isNotNull()) \
        .selectExpr("cast(paifkint as string) PAId", "hospitalfk")
    return df

# COMMAND ----------

def load_esInput1(spark, esScrubbedPath):
    esschema = StructType([
        StructField("leadingpipe", StringType()),
        StructField("hospitalfk", StringType()),
        StructField("PAId", StringType())
    ])
    df = readFileNested(spark, esScrubbedPath, esschema) \
        .select("PAId","hospitalfk")
    df2 = df.withColumn("PAId", trim(col("PAId"))).withColumn("hospitalfk", trim(col("hospitalfk")))
    return df2

# COMMAND ----------

def load_gmrnPAIdMap(spark, gmrn_path):
    df = extract_parquet_data(spark, gmrn_path)
    df2 = df.withColumn("GMRNId", trim(df.globalmrnifk)) \
        .withColumn("PAId", trim(df.patientacctifk)) \
        .withColumn("hospitalfk", trim(df.hospitalfk)) \
        .select("GMRNId", "PAId", "hospitalfk")
    return df2

# COMMAND ----------

def create_esM2CandidatesDistinctOnlyGMRN(gmrnPAIdMap, esInputDistinct):
    df = gmrnPAIdMap.join(
            esInputDistinct,
            (gmrnPAIdMap.PAId == esInputDistinct.PAId) & 
            (gmrnPAIdMap.hospitalfk == esInputDistinct.hospitalfk)
        ) \
        .select(gmrnPAIdMap.GMRNId).distinct()
    return df

# COMMAND ----------

def create_missingPAIds(esInputDistinct, gmrnPAIdMap):
    df = esInputDistinct.join(
            gmrnPAIdMap,
            (esInputDistinct.PAId == gmrnPAIdMap.PAId) &
            (esInputDistinct.hospitalfk == gmrnPAIdMap.hospitalfk),
            how='left_anti'
        ) \
        .select(esInputDistinct.PAId, esInputDistinct.hospitalfk).distinct()
    return df

# COMMAND ----------

def load_hospIdsToPurge(spark, hospIdsToPurge_path):
    hospIdToPurgeSchema = StructType([
        StructField("hid", IntegerType())
    ])
    df = readFile(spark, hospIdsToPurge_path, hospIdToPurgeSchema) \
        .filter(col("hid").isNotNull()) \
        .selectExpr("cast(hid as string) hospid")
    return df

# COMMAND ----------

def remove_purged_hospital_gmrnDemos(gmrnDemos, hospIdsToPurge):
    df = gmrnDemos.join(hospIdsToPurge, gmrnDemos.hospid == hospIdsToPurge.hospid, how='left_anti').distinct()
    return df

# COMMAND ----------

@udf(returnType=StringType())
def getDigits(text):
    if text is None:
      return ''
    else:
      return ''.join([i if (ord(i) > 47 and ord(i) < 58) else '' for i in text])

# COMMAND ----------

def load_gmrnDemos(spark, gmrnDemos_path):
    gmrnDemosColList = ["globalmrnifk", "hospitalfk", "firstname", "lastname", "dob", "ssn", "addr1", \
                        "city", "state", "zip"]
    df = extract_parquet_data(spark, gmrnDemos_path, gmrnDemosColList)
    df2 = df.withColumn("GMRNId", trim(col("globalmrnifk"))) \
        .withColumn("hospid", trim(col("hospitalfk"))) \
        .withColumn("FN", upper(trim(col("firstname")))) \
        .withColumn("LN", upper(trim(col("lastname")))) \
        .withColumn("City", upper(trim(col("city")))) \
        .withColumn("SSN", upper(trim(col("ssn")))) \
        .withColumn("zip", upper(trim(col("zip")))) \
        .withColumn("State", upper(trim(col("state")))) \
        .withColumn("AddressNumbers", when(col("addr1").isNull(), "").otherwise(getDigits(col("addr1"))))
    df3 = df2.withColumn("LNF4", when(col("LN").isNull(), "").otherwise(substring(col("LN"), 0, 4))) \
        .withColumn("FNF4", when(col("FN").isNull(), "").otherwise(substring(col("FN"), 0, 4))) \
        .withColumn("Zip", when(col("zip").isNull(), "").otherwise(substring(col("zip"), 0, 5))) \
        .withColumn("DOB", when(col("dob").isNull(), "") \
                    .otherwise(regexp_replace(substring(col("dob"), 0, 10), "-", ""))) \
        .select("GMRNId", "hospid", "FN", "LN", "City", "SSN", "State", "DOB", "AddressNumbers", \
                "Zip", "LNF4", "FNF4")
    return df3

# COMMAND ----------

def create_esM2CandidatesWithDemo(spark, esM2CandidatesDistinctOnlyGMRN, gmrnDemos):
    df = esM2CandidatesDistinctOnlyGMRN.select(col("GMRNId").alias("esGMRNId"))
    df2 = df.join(gmrnDemos, df.esGMRNId == gmrnDemos.GMRNId) \
        .select("GMRNId", "hospid", "FN", "LN", "City", "SSN", "State", "DOB", "AddressNumbers", \
                "Zip", "LNF4", "FNF4")
    return df2

# COMMAND ----------

def create_ieAllOnlyDemoSubset(ieAllParsed,p_factor):
    df = ieAllParsed.filter(col("subscriberId") != '') \
        .withColumn("subscriberFirstNameFNF4", substring(col("subscriberFirstName"), 0, 4)) \
        .withColumn("subscriberLastNameLNF4", substring(col("subscriberLastName"), 0, 4)) \
        .select("TraceNumber","subscriberLastName","subscriberFirstName","subscriberFirstNameFNF4", \
                "subscriberLastNameLNF4","subscriberDOB","subscriberSSN","subscriberId","subscriberAddress",\
                "subscriberState","subscriberCity","subscriberZip","subscriberAddressNumbers","depFlag")
    return df.withColumn("transactionrange", (df.TraceNumber.cast("bigint") % p_factor).cast("bigint"))

# COMMAND ----------

def load_ieAllParsed(spark,ieAllParsed_path):
    ieAllParsedSchema = StructType([
        StructField("TraceNumber", StringType()),
        StructField("Received", StringType()),
        StructField("providerId", StringType()),
        StructField("providerLastNameOrgName", StringType()),
        StructField("subscriberLastName", StringType()),
        StructField("subscriberFirstName", StringType()),
        StructField("subscriberMiddleName", StringType()),
        StructField("subscriberGender", StringType()),
        StructField("subscriberDOB", StringType()),
        StructField("subscriberSSN", StringType()),
        StructField("subscriberGroupNumber", StringType()),
        StructField("subscriberSuffixCode", StringType()),
        StructField("subscriberIdCode", StringType()),
        StructField("subscriberId", StringType()),
        StructField("subscriberAddress", StringType()),
        StructField("subscriberState", StringType()),
        StructField("subscriberCity", StringType()),
        StructField("subscriberZip", StringType()),
        StructField("subscriberAddressNumbers", StringType()),
        StructField("dateOfService", StringType()),
        StructField("ResponseResultExt", StringType()),
        StructField("ResponseResultStd", StringType()),
        StructField("payerId", StringType()),
        StructField("payerProviderId", StringType()),
        StructField("payerLastNameOrgName", StringType()),
        StructField("clientId", StringType()),
        StructField("breadCrumbs", StringType()),
        StructField("depFlag", StringType())
    ])
    return readFile(spark,ieAllParsed_path,ieAllParsedSchema)

# COMMAND ----------

# FIRST PASS - FN, LN, DOB, City, State
def Match1(esM2CandidatesWithDemo,ieAllOnlyDemoSubset):
    esUnmatched = esM2CandidatesWithDemo.select("GMRNId","FN","LN","DOB","City","State").distinct()
    esUnmatched = esUnmatched.filter((col("FN") != '') & (col("LN") != '') & (col("DOB") != '') & (col("City") != '') & (col("State") != ''))
    cond = [ \
    ieAllOnlyDemoSubset.subscriberFirstName == esM2CandidatesWithDemo.FN, \
    ieAllOnlyDemoSubset.subscriberLastName == esM2CandidatesWithDemo.LN,  \
    ieAllOnlyDemoSubset.subscriberDOB == esM2CandidatesWithDemo.DOB,  \
    ieAllOnlyDemoSubset.subscriberCity == esM2CandidatesWithDemo.City,  \
    ieAllOnlyDemoSubset.subscriberState == esM2CandidatesWithDemo.State \
    ]
    matched_iees1J = ieAllOnlyDemoSubset.join(esUnmatched, cond) \
    .select("GMRNId","TraceNumber","depFlag") \
    .distinct()
    return matched_iees1J

# COMMAND ----------

# SECOND PASS - FN, LN, DOB, Zip, AddressNumbers
def Match2(esM2CandidatesWithDemo,ieAllOnlyDemoSubset):
    esUnmatched = esM2CandidatesWithDemo.select("GMRNId","FN","LN","DOB","Zip","AddressNumbers").distinct()
    esUnmatched = esUnmatched.filter((col("FN") != '') & (col("LN") != '') & (col("DOB") != '') & (col("Zip") != '') & (col("AddressNumbers") != ''))
    cond = [ \
    ieAllOnlyDemoSubset.subscriberFirstName == esM2CandidatesWithDemo.FN, \
    ieAllOnlyDemoSubset.subscriberLastName == esM2CandidatesWithDemo.LN,  \
    ieAllOnlyDemoSubset.subscriberDOB == esM2CandidatesWithDemo.DOB,  \
    ieAllOnlyDemoSubset.subscriberZip == esM2CandidatesWithDemo.Zip,  \
    ieAllOnlyDemoSubset.subscriberAddressNumbers == esM2CandidatesWithDemo.AddressNumbers \
    ]
    matched_iees1J = ieAllOnlyDemoSubset.join(esUnmatched, cond) \
    .select("GMRNId","TraceNumber","depFlag") \
    .distinct()
    return matched_iees1J

# COMMAND ----------

# THIRD PASS - FN, LN, DOB, SSN
def Match3(esM2CandidatesWithDemo,ieAllOnlyDemoSubset):
    esUnmatched = esM2CandidatesWithDemo.select("GMRNId","FN","LN","DOB","SSN").distinct()
    esUnmatched = esUnmatched.filter((col("FN") != '') & (col("LN") != '') & (col("DOB") != '') & (col("SSN") != ''))
    cond = [ \
    ieAllOnlyDemoSubset.subscriberFirstName == esM2CandidatesWithDemo.FN, \
    ieAllOnlyDemoSubset.subscriberLastName == esM2CandidatesWithDemo.LN,  \
    ieAllOnlyDemoSubset.subscriberDOB == esM2CandidatesWithDemo.DOB,  \
    ieAllOnlyDemoSubset.subscriberSSN == esM2CandidatesWithDemo.SSN  \
    ]
    matched_iees1J = ieAllOnlyDemoSubset.join(esUnmatched, cond) \
    .select("GMRNId","TraceNumber","depFlag") \
    .distinct()
    return matched_iees1J

# COMMAND ----------

# FOURTH PASS - FNF4, LN, SSN, City, State
def Match4(esM2CandidatesWithDemo,ieAllOnlyDemoSubset):
    esUnmatched = esM2CandidatesWithDemo.select("GMRNId","FNF4","LN","SSN","City","State").distinct()
    esUnmatched = esUnmatched.filter((col("FNF4") != '') & (col("LN") != '') & (col("SSN") != '') & (col("City") != '') & (col("State") != ''))
    cond = [ \
    ieAllOnlyDemoSubset.subscriberFirstNameFNF4 == esM2CandidatesWithDemo.FNF4, \
    ieAllOnlyDemoSubset.subscriberLastName == esM2CandidatesWithDemo.LN,  \
    ieAllOnlyDemoSubset.subscriberSSN == esM2CandidatesWithDemo.SSN,  \
    ieAllOnlyDemoSubset.subscriberCity == esM2CandidatesWithDemo.City,  \
    ieAllOnlyDemoSubset.subscriberState == esM2CandidatesWithDemo.State  \
    ]
    matched_iees1J = ieAllOnlyDemoSubset.join(esUnmatched, cond) \
    .select("GMRNId","TraceNumber","depFlag") \
    .distinct()
    return matched_iees1J

# COMMAND ----------

# FIFTH PASS - FNF4, LN, SSN, Zip, AddressNumbers
def Match5(esM2CandidatesWithDemo,ieAllOnlyDemoSubset):
    esUnmatched = esM2CandidatesWithDemo.select("GMRNId","FNF4","LN","SSN","Zip","AddressNumbers").distinct()
    esUnmatched = esUnmatched.filter((col("FNF4") != '') & (col("LN") != '') & (col("SSN") != '') & (col("Zip") != '') & (col("AddressNumbers") != ''))
    cond = [ \
    ieAllOnlyDemoSubset.subscriberFirstNameFNF4 == esM2CandidatesWithDemo.FNF4, \
    ieAllOnlyDemoSubset.subscriberLastName == esM2CandidatesWithDemo.LN,  \
    ieAllOnlyDemoSubset.subscriberSSN == esM2CandidatesWithDemo.SSN,  \
    ieAllOnlyDemoSubset.subscriberZip == esM2CandidatesWithDemo.Zip,  \
    ieAllOnlyDemoSubset.subscriberAddressNumbers == esM2CandidatesWithDemo.AddressNumbers  \
    ]
    matched_iees1J = ieAllOnlyDemoSubset.join(esUnmatched, cond) \
    .select("GMRNId","TraceNumber","depFlag") \
    .distinct()
    return matched_iees1J

# COMMAND ----------

# SIXTH PASS - FNF4, LNF4, SSN, Zip
def Match6(esM2CandidatesWithDemo,ieAllOnlyDemoSubset):
    esUnmatched = esM2CandidatesWithDemo.select("GMRNId","FNF4","LNF4","SSN","Zip").distinct()
    esUnmatched = esUnmatched.filter((col("FNF4") != '') & (col("LNF4") != '') & (col("SSN") != '') & (col("Zip") != ''))
    cond = [ \
    ieAllOnlyDemoSubset.subscriberFirstNameFNF4 == esM2CandidatesWithDemo.FNF4, \
    ieAllOnlyDemoSubset.subscriberLastNameLNF4 == esM2CandidatesWithDemo.LNF4,  \
    ieAllOnlyDemoSubset.subscriberSSN == esM2CandidatesWithDemo.SSN,  \
    ieAllOnlyDemoSubset.subscriberZip == esM2CandidatesWithDemo.Zip  \
    ]
    matched_iees1J = ieAllOnlyDemoSubset.join(esUnmatched, cond) \
    .select("GMRNId","TraceNumber","depFlag") \
    .distinct()
    return matched_iees1J

# COMMAND ----------

def create_policyInfo(allMatchedTmp,ieAllParsed,bcdate):
    amt = allMatchedTmp.select("GMRNId", "matchInd", col("TraceNumber").alias("amtTraceNumber"), \
        col("depFlag").alias("amtdepFlag"))
    joinConditions = [amt.amtTraceNumber == ieAllParsed.TraceNumber, amt.amtdepFlag == ieAllParsed.depFlag]
    df = amt.join(ieAllParsed, joinConditions) \
    .withColumn("Custom1",col("breadCrumbs")) \
    .withColumn('Custom2',lit(bcdate)) \
    .withColumn("dependentFlag", when(col("depFlag") == 'Y','T').otherwise('F')) \
    .select("GMRNId","TraceNumber","Received","providerId","providerLastNameOrgName","subscriberGroupNumber", \
    "subscriberSuffixCode","subscriberIdCode","subscriberId","dateOfService","payerId","payerProviderId", \
    "payerLastNameOrgName","dependentFlag","subscriberFirstName","subscriberMiddleName","subscriberLastName", \
    "subscriberGender","subscriberDOB","subscriberSSN","subscriberAddress","subscriberState","subscriberCity", \
    "subscriberZip", "matchInd","clientId","ResponseResultExt","ResponseResultStd","Custom1","Custom2")
    return df

# COMMAND ----------

# DBTITLE 1,common folders/variables
userFolder = baseurl+cm2_user_folder
cm2_user_folder_for_data = baseurl+cm2_user_folder
userFolderForData = cm2_user_folder_for_data

outputBaseDir = userFolder + '/transform/output/' + outFolder 
publishBaseDir = userFolder + '/publish/' + outFolder

hcedatauserFolder = baseurl+cm2_hcedata_user_folder
cm2_hcedata_user_folder_for_data = baseurl+cm2_hcedata_user_folder
hcedatauserFolderForData = cm2_hcedata_user_folder_for_data

# input data paths
# scrubbed path can have sub-directories and if we dont do /*/*, we could be missing out data 
esScrubbedPath = userFolderForData + '/publish/es/scrubbed/' + esdate + '/*' #confirm this
esInputMissingPAIdsPath = userFolderForData + '/publish/ie_cm2/missingPAIds/current/*'
#gmrn_path = hcedatauserFolderForData + '/publish/escan/globalmrnxpacct/current/*'
gmrn_path =  baseurl+'/data/gmrn/publish/globalmrnxpacct/current/*' #updated folder
#gmrnDemos_path = hcedatauserFolderForData + '/publish/escan/globalmrndemographics/current/*'
gmrnDemos_path =  baseurl+'/data/gmrn/publish/globalmrndemographics/current/*' #updated folder
hospIdsToPurge_path = userFolderForData + '/staging/input/hospIdsToPurge/hospIdsToPurge.txt' # folder update
ieAllParsed_path = userFolderForData + '/publish/ie/parsed_all/' + iedate + '/*'

####Remove
print ("DEBUG: esScrubbedPath " + esScrubbedPath + "\n")
print ("DEBUG: esInputMissingPAIdsPath " + esInputMissingPAIdsPath + "\n")
print ("DEBUG: gmrn_path " + gmrn_path + "\n")
print ("DEBUG: gmrnDemos_path " + gmrnDemos_path + "\n")
print ("DEBUG: hospIdsToPurge_path " + hospIdsToPurge_path + "\n")
print ("DEBUG: ieAllParsed_path " + ieAllParsed_path + "\n")

###partition_count_check_based_on_ie_or_es
ieAllParsed_partition_cnt = ieAllParsed_part_cnt(iedate)
esInput1_load_partition_cnt = esInput1_load_part_cnt(esdate)

print("DEBUG: ieAllParsed_partition_cnt " + str(ieAllParsed_partition_cnt))
print("DEBUG: esInput1_load_partition_cnt " + str(esInput1_load_partition_cnt))

# Staging Parquet data path
ieallparsed_path_stg_pqt = baseurl+path_stg_parquet + '/staging/scratch/' + outFolder + '_ieallparsed/' + bcdate
print ("DEBUG: ieallparsed_path_stg_pqt " + ieallparsed_path_stg_pqt + "\n")
esm2candidateswithdemo_stg_pqt =  baseurl+path_stg_parquet + '/staging/scratch/' + outFolder + '_esm2candidateswithdemo/' + bcdate
print ("DEBUG: esm2candidateswithdemo_stg_pqt " + esm2candidateswithdemo_stg_pqt + "\n")
esScrubbedPath_stg_pqt = baseurl+path_stg_parquet + '/staging/scratch/' + outFolder + '_esScrubbedPath/' + bcdate
print ("DEBUG: esScrubbedPath_stg_pqt " + esScrubbedPath_stg_pqt + "\n")

# output data paths
missingPAIds_output_path = userFolder + '/transform/output/' + outFolder + '/missingPAIds/' + bcdate
MatchFolder = outputBaseDir + '/matched_*/' + bcdate
Match1Folder = outputBaseDir + '/matched_1/' + bcdate
Match2Folder = outputBaseDir + '/matched_2/' + bcdate
Match3Folder = outputBaseDir + '/matched_3/' + bcdate
Match4Folder = outputBaseDir + '/matched_4/' + bcdate
Match5Folder = outputBaseDir + '/matched_5/' + bcdate
Match6Folder = outputBaseDir + '/matched_6/' + bcdate
allMarkedRows_path = publishBaseDir + '/finalPolicyInfo/' + bcdate
ieAllOnlyDemoSubset_tmp_path = outputBaseDir + '/ieAllOnlyDemoSubset/' + bcdate

print("DEBUG: missingPAIds_output_path " + missingPAIds_output_path + "\n")
print("DEBUG: MatchFolder " + MatchFolder + "\n")
print("DEBUG: Match1Folder " + Match1Folder + "\n")
print("DEBUG: Match2Folder " + Match2Folder + "\n")
print("DEBUG: Match3Folder " + Match3Folder + "\n")
print("DEBUG: Match4Folder " + Match4Folder + "\n")
print("DEBUG: Match5Folder " + Match5Folder + "\n")
print("DEBUG: Match6Folder " + Match6Folder + "\n")
print("DEBUG: allMarkedRows_path " + allMarkedRows_path + "\n")
print("DEBUG: ieAllOnlyDemoSubset_tmp_path " + ieAllOnlyDemoSubset_tmp_path + "\n")

# COMMAND ----------

# DBTITLE 1,Match code
if  cm2_action_flag == 'cm2_read_src_files':
    current_dt = datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]

    #spark = SparkSession.builder.appName(cm2_action_flag).getOrCreate()
    #spark.sparkContext.setLogLevel("ERROR")
    spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)

    # process
    ieAllParsed_src_load = load_ieAllParsed(spark,ieAllParsed_path)
    extract_ieAllParsed_src_load = extract_pqt_stg_ieAllParsed(ieAllParsed_src_load, ieallparsed_path_stg_pqt,ieAllParsed_partition_cnt,p_factor)

    ieAllParsed = readFromParquet(spark, ieallparsed_path_stg_pqt)
    ieAllOnlyDemoSubset_tmp = create_ieAllOnlyDemoSubset(ieAllParsed,p_factor)
    #print("DEBUG: get partition counts from ieAllOnlyDemoSubset_tmp" + str(ieAllOnlyDemoSubset_tmp.rdd.getNumPartitions()))
    ieAllOnlyDemoSubset_extract = extract_ieAllOnlyDemoSubset(ieAllOnlyDemoSubset_tmp, ieAllOnlyDemoSubset_tmp_path, ieAllParsed_partition_cnt)
    print("DEBUG: ieAllOnlyDemoSubset_extract extraction staging completed " + ieAllOnlyDemoSubset_tmp_path)

    esInputMissingPAIds = load_esInputMissingPAIds(spark, esInputMissingPAIdsPath)
    esInput1_load = load_esInput1(spark, esScrubbedPath)
    extract_esInput1_load = extract_pqt_stg_esInput1_load(esInput1_load, esScrubbedPath_stg_pqt, esInput1_load_partition_cnt)
    esInput1 = readFromParquet(spark, esScrubbedPath_stg_pqt)
    print("DEBUG: esInput1 extraction staging completed " + esScrubbedPath_stg_pqt)
   
    esInputDistinct = esInputMissingPAIds.union(esInput1).distinct()
    gmrnPAIdMap = load_gmrnPAIdMap(spark, gmrn_path)
    esM2CandidatesDistinctOnlyGMRN = create_esM2CandidatesDistinctOnlyGMRN(gmrnPAIdMap, esInputDistinct)
    missingPAIds = create_missingPAIds(esInputDistinct, gmrnPAIdMap)
    saveTextFile(missingPAIds, missingPAIds_output_path)

    hospIdsToPurge = load_hospIdsToPurge(spark, hospIdsToPurge_path)
    gmrnDemos = load_gmrnDemos(spark, gmrnDemos_path)
    gmrnDemos = remove_purged_hospital_gmrnDemos(gmrnDemos, hospIdsToPurge)
    esm2candidateswithdemo_stg = create_esM2CandidatesWithDemo(spark, esM2CandidatesDistinctOnlyGMRN, gmrnDemos)
    writeParquet(esm2candidateswithdemo_stg, esm2candidateswithdemo_stg_pqt)
    print("DEBUG: esm2candidateswithdemo_stg_pqt extraction staging completed " + esm2candidateswithdemo_stg_pqt)
    #
    #spark.stop()
    #return None
elif cm2_action_flag == 'cm2_match1':
    current_dt = datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    #spark = SparkSession.builder.appName(cm2_action_flag).getOrCreate()
    #spark.sparkContext.setLogLevel("ERROR")
    spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)
    #Process

    esM2CandidatesWithDemo = readFromParquet(spark, esm2candidateswithdemo_stg_pqt)
    ieAllOnlyDemoSubset = readFromParquet(spark,ieAllOnlyDemoSubset_tmp_path)

    MatchResult_Intermediate1 = Match1(esM2CandidatesWithDemo, ieAllOnlyDemoSubset)
    writeParquet(MatchResult_Intermediate1, Match1Folder)
    print("DEBUG: MatchResult_Intermediate1 Completed")
    #spark.stop()
    #return None
elif cm2_action_flag == 'cm2_match2':
    current_dt = datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    #spark = SparkSession.builder.appName(cm2_action_flag).getOrCreate()
    #spark.sparkContext.setLogLevel("ERROR")
    spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)

    ##Process
    esM2CandidatesWithDemo = readFromParquet(spark, esm2candidateswithdemo_stg_pqt)
    ieAllOnlyDemoSubset = readFromParquet(spark,ieAllOnlyDemoSubset_tmp_path)

    MatchResult_Intermediate2 = Match2(esM2CandidatesWithDemo, ieAllOnlyDemoSubset)
    writeParquet(MatchResult_Intermediate2, Match2Folder)
    print("DEBUG: MatchResult_Intermediate2 Completed")
    #spark.stop()
    #return None
elif cm2_action_flag == 'cm2_match3':
    current_dt = datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    #spark = SparkSession.builder.appName(cm2_action_flag).getOrCreate()
    #spark.sparkContext.setLogLevel("ERROR")
    spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)

    ##Process
    esM2CandidatesWithDemo = readFromParquet(spark, esm2candidateswithdemo_stg_pqt)
    ieAllOnlyDemoSubset = readFromParquet(spark,ieAllOnlyDemoSubset_tmp_path)

    MatchResult_Intermediate3 = Match3(esM2CandidatesWithDemo, ieAllOnlyDemoSubset)
    writeParquet(MatchResult_Intermediate3, Match3Folder)
    print("DEBUG: MatchResult_Intermediate3 Completed")
    #spark.stop()
    #return None
elif cm2_action_flag == 'cm2_match4':
    current_dt = datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    #spark = SparkSession.builder.appName(cm2_action_flag).getOrCreate()
    #spark.sparkContext.setLogLevel("ERROR")
    spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)

    ##Process
    esM2CandidatesWithDemo = readFromParquet(spark, esm2candidateswithdemo_stg_pqt)
    ieAllOnlyDemoSubset = readFromParquet(spark,ieAllOnlyDemoSubset_tmp_path)

    MatchResult_Intermediate4 = Match4(esM2CandidatesWithDemo, ieAllOnlyDemoSubset)
    writeParquet(MatchResult_Intermediate4, Match4Folder)
    print("DEBUG: MatchResult_Intermediate4 Completed")
    #spark.stop()
    #return None
elif cm2_action_flag == 'cm2_match5':
    current_dt = datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    #spark = SparkSession.builder.appName(cm2_action_flag).getOrCreate()
    #spark.sparkContext.setLogLevel("ERROR")
    spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)

    ##Process
    esM2CandidatesWithDemo = readFromParquet(spark, esm2candidateswithdemo_stg_pqt)
    ieAllOnlyDemoSubset = readFromParquet(spark,ieAllOnlyDemoSubset_tmp_path)

    MatchResult_Intermediate5 = Match5(esM2CandidatesWithDemo, ieAllOnlyDemoSubset)
    writeParquet(MatchResult_Intermediate5, Match5Folder)
    print("DEBUG: MatchResult_Intermediate5 Completed") 
    #spark.stop()
    #return None
elif cm2_action_flag == 'cm2_match6':
    current_dt = datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    #spark = SparkSession.builder.appName(cm2_action_flag).getOrCreate()
    #spark.sparkContext.setLogLevel("ERROR")
    spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)

    ##Process
    esM2CandidatesWithDemo = readFromParquet(spark, esm2candidateswithdemo_stg_pqt)
    ieAllOnlyDemoSubset = readFromParquet(spark,ieAllOnlyDemoSubset_tmp_path)

    MatchResult_Intermediate6 = Match6(esM2CandidatesWithDemo, ieAllOnlyDemoSubset)
    writeParquet(MatchResult_Intermediate6, Match6Folder)
    print("DEBUG: MatchResult_Intermediate6 Completed") 
    #spark.stop()
    #return None
elif cm2_action_flag == 'cm2_allmatches':
    current_dt = datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    #spark = SparkSession.builder.appName(cm2_action_flag).getOrCreate()
    #spark.sparkContext.setLogLevel("ERROR")
    spark.conf.set("spark.sql.autoBroadcastJoinThreshold", -1)

    ##Process
    MatchResult = readFromParquet(spark,MatchFolder)

    #allMatchDataFrames = [MatchResult1,MatchResult2,MatchResult3,MatchResult4,MatchResult5,MatchResult6]
    #allMatchedTmp = reduce(DataFrame.unionAll, allMatchDataFrames) \
    allMatchedTmp = MatchResult \
    .withColumn("matchInd",lit('M2')) \
    .select("GMRNId", "TraceNumber", "depFlag","matchInd") \
    .distinct()

    print("DEBUG: ieallparsed_path_stg_pqt --" + ieallparsed_path_stg_pqt)

    ieAllParsed = readFromParquet(spark, ieallparsed_path_stg_pqt)
    policyInfo = create_policyInfo(allMatchedTmp,ieAllParsed,bcdate)
    policyInfo = addValidationForAllColumns(policyInfo)
    allMarkedRows = addOverallValidation(policyInfo)

    saveFinalResults(allMarkedRows,allMarkedRows_path)
    print("DEBUG: MatchResult All Matches save completed") 
    #spark.stop()
    #return None
else:
    print("DEBUG: Missing argument for action_flag")
    #exit(1)
