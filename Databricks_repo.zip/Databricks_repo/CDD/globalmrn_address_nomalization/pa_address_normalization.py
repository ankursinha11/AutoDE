# Databricks notebook source
# DBTITLE 1,Data Sources
# 1. Patientaccts
# 2. globalmrnxpacct
# 3. PatientMatchingBlockAllowGMRN
# 4. AddressList
# 5. PatientAcctsAddress

# COMMAND ----------

# DBTITLE 1,Imports
from pyspark.sql.functions import *
from pyspark.sql.types import *
import re
import datetime

# COMMAND ----------

# DBTITLE 1,Widgets
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("catalog_name","")
dbutils.widgets.getArgument("catalog_name")
catalog_name= getArgument("catalog_name")

publish_schema1 = 'dataingestion'
publish_schema2 = 'cdd'
staging_schema = 'cdd_staging'

# COMMAND ----------

# DBTITLE 1,Basepath
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user
print(baseurl)    

# COMMAND ----------

# DBTITLE 1,Input Paths and data
pa_path = f"{baseurl}/data/dataingestion/publish/patientaccts/current/20991231/"
gmrnxpacct_path = f"{baseurl}/data/gmrn/publish/globalmrnxpacct/current/*/*"
PatientMatchingBlockAllowGMRNTable = f"{catalog_name}.{publish_schema1}.PatientMatchingBlockAllowGMRN"
AddressListTable = f"{catalog_name}.{publish_schema2}.addresslist"
PatientAcctsAddressTable = f"{catalog_name}.{publish_schema2}.patientacctsaddress"
StagingTable1 = f"{catalog_name}.{staging_schema}.PatientacctAddressesRaw"
StagingTable2 = f"{catalog_name}.{staging_schema}.PatientacctAddressesNormlized"
patientaccts_df = spark.read.format("delta").load(pa_path)
gmrnxpacct_df = spark.read.format("parquet").load(gmrnxpacct_path)
PatientMatchingBlockAllowGMRN_df = spark.read.table(PatientMatchingBlockAllowGMRNTable)
AddressList_df = spark.read.table(AddressListTable)
PatientAcctsAddress_df = spark.read.table(PatientAcctsAddressTable)

# COMMAND ----------

# DBTITLE 1,Delta Patientaccts with GMRN id
FetchingGMRNAddressesQuery = """
            SELECT gpac.GlobalMRNIFK, pa.HospitalFK, pa.PatientAcctIPK, LEFT(TRIM(pa.Zip), 5) Zip, 
                   RTRIM(LTRIM(CONCAT(COALESCE(UPPER(pa.Addr1), ''), ' ', COALESCE(UPPER(pa.Addr2), '')))) Addr
            FROM {patientaccts_df} pa
            INNER JOIN (
                SELECT g.GlobalMRNIFK, g.HospitalFK, g.PatientAcctIFK
                FROM {gmrnxpacct_df} g
                LEFT JOIN {PatientMatchingBlockAllowGMRN_df} bad
                ON g.GlobalMRNIFK = CAST(bad.gmrnifk AS STRING)
                WHERE bad.gmrnifk IS NULL
            ) gpac
            ON pa.HospitalFK = gpac.HospitalFK AND pa.PatientAcctIPK = gpac.PatientAcctIFK
            WHERE LEN(LEFT(TRIM(pa.Zip), 5)) = 5 and pa.trgupdatedate >= current_timestamp() - INTERVAL 3 DAY
        """

FetchingGMRNAddresses_df = spark.sql(FetchingGMRNAddressesQuery, patientaccts_df=patientaccts_df, gmrnxpacct_df=gmrnxpacct_df,PatientMatchingBlockAllowGMRN_df=PatientMatchingBlockAllowGMRN_df)

FetchingGMRNAddresses_df = FetchingGMRNAddresses_df.withColumn("bc",lit(bc))

FetchingGMRNAddresses_df.write.mode("overwrite").format("delta").option("replaceWhere", f"bc = '{bc}'").saveAsTable(StagingTable1)

FetchingGMRNAddresses_df = spark.read.table(StagingTable1).where(f"bc = '{bc}'")

# COMMAND ----------

# DBTITLE 1,AddressData UDF
def trim_internal_whitespace(s):
    if s is None:
        return ""
    # Replace multiple spaces with a single space
    return re.sub(r"\s{2,}", " ", s).strip()

def AddressData(address):
    if address is None:
        return ""
    address = address.replace("#", "# ")
    address = address.replace(",", "")
    address = address.replace(".", "")
    address = address.replace("-", " ")
    # address = address.replace(":", " ") not needed for now
    address = address.replace("ST PAUL", "SAINT PAUL")
    # Trim internal whitespace
    address = trim_internal_whitespace(address)
    return address
AddressData_udf = udf(AddressData, StringType())
AddressData_df = FetchingGMRNAddresses_df.withColumn("StreetName", AddressData_udf(FetchingGMRNAddresses_df["Addr"]))

# COMMAND ----------

# DBTITLE 1,CareOfParser UDF
def CareOfParser(street_name):
    pattern = r"(?i)C/O (?P<CareOfName>[A-Z]+ [A-Z]+)$"  # Updated to match only first and last name
    match = re.search(pattern, street_name or "")
    
    if match:
        care_of = match.group("CareOfName").strip()
        unit_info = f"[CareOf:{care_of}]"
        cleaned_street = re.sub(pattern, "", street_name, flags=re.IGNORECASE).strip()
    else:
        cleaned_street = street_name
        unit_info = None
    
    return (cleaned_street, unit_info)

schema = StructType([
    StructField("StreetName", StringType(), True),
    StructField("UnitInfo", StringType(), True)])

CareOfParser_udf = udf(CareOfParser, schema)

CareOfParser_df = AddressData_df.withColumn("careofparsed", CareOfParser_udf(AddressData_df["StreetName"]))

CareOfParser_df = CareOfParser_df.select('GlobalMRNIFK','HospitalFK','PatientAcctIPK','Zip','Addr','careofparsed.StreetName', 'careofparsed.UnitInfo')

# COMMAND ----------

# DBTITLE 1,NumberAddrParser UDF
def NumberAddrParser(street_name):
    pattern = r"^(?P<Number>[0-9]+[0-9A-Z-]*( [A-Z0-9]+/[A-Z0-9]+)?)"
    match = re.match(pattern, street_name, re.IGNORECASE)
    if match:
        number = match.group("Number")
        new_street_name = street_name[len(number):].lstrip()
        return (number, new_street_name)
    else:
        return (None, street_name)
		
schema = StructType([
         StructField("Number", StringType(), True),
         StructField("StreetName", StringType(), True)])

NumberAddrParser_udf = udf(NumberAddrParser, schema)

NumberAddrParser_df = CareOfParser_df.withColumn("NumberAddrParser", NumberAddrParser_udf(CareOfParser_df["StreetName"]))

NumberAddrParser_df = NumberAddrParser_df.select('GlobalMRNIFK','HospitalFK','PatientAcctIPK','Zip','Addr','NumberAddrParser.StreetName','UnitInfo','NumberAddrParser.Number')

# COMMAND ----------

# DBTITLE 1,UnitTypeParser UDF
unit_types = {
    "APARTMENT": "APT",
    "APT": "APT",
    "POB": "BOX",
    "POBOX": "BOX",
    "BOX": "BOX",
    "FLOOR": "FLOOR",
    "CONDO": "CONDO",
    "NO": "NUMBER",
    "NUM": "NUMBER",
    "STE": "SUITE",
    "STUDIO": "STUDIO",
    "SUITE": "SUITE",
    "BLD": "BUILDING",
    "BLDG": "BUILDING",
    "BUILDING": "BUILDING",
    "DEPARTMENT": "DEPARTMENT",
    "DEPT": "DEPARTMENT",
    "UNIT": "UNIT",
    "UNT": "UNIT",
    "LOT": "LOT",
    "FL": "FLOOR",
    "ROOM": "ROOM",
    "RM": "ROOM",
    "TRLR": "TRAILER",
    "TRAILER": "TRAILER"
}

def UnitTypeParser(street_name, unit_info):
    if not street_name:
        return (street_name, unit_info)

    updated_unit_info = unit_info if unit_info else ""
    unit_info_set = set()
    skip_box = False

    # Normalize PO BOX patterns
    po_box_patterns = [r"(?i)\bP\.?\s*O\.?\s*BOX\s*([0-9A-Z\-\/]+)\b", r"(?i)\bPOST\s*OFFICE\s*BOX\s*([0-9A-Z\-\/]+)\b",r"(?i)\b(PO|P\.O\.|P O|POST OFFICE)\b\s*([0-9A-Z\-\/]+)\b"]
    for pattern in po_box_patterns:
        po_box_match = re.search(pattern, street_name)
        if po_box_match:
            box_number = po_box_match.group(1)
            street_name = re.sub(pattern, f"PO BOX {box_number}", street_name)
            unit_str = f"[BOX: {box_number}]"
            if unit_str not in unit_info_set:
                updated_unit_info += unit_str if not updated_unit_info else unit_str
                unit_info_set.add(unit_str)
            skip_box = True
            break

    unit_matches = []
    for unit_type, normalized_type in unit_types.items():
        if normalized_type == "BOX" and skip_box:
            continue
        pattern = rf"(?i)\b({unit_type})\b\s*(#?\s*[0-9A-Z\-\/]+)"
        matches = list(re.finditer(pattern, street_name, flags=re.IGNORECASE))
        for match in matches:
            unit_number = match.group(2).strip()
            unit_str = f"[{normalized_type}: {unit_number}]"
            if unit_str not in unit_info_set:
                updated_unit_info += unit_str if not updated_unit_info else unit_str
                unit_info_set.add(unit_str)
            unit_matches.append(match.group(0))

    # Handle hash sign unit pattern
    hash_pattern = r"(?:\s|^)\#\s*([0-9A-Z\-]+)\b"
    hash_match = re.search(hash_pattern, street_name, flags=re.IGNORECASE)
    if hash_match:
        number = hash_match.group(1)
        unit_str = f"[#:{number}]"
        if unit_str not in unit_info_set:
            updated_unit_info += unit_str if not updated_unit_info else unit_str
            unit_info_set.add(unit_str)
        street_name = re.sub(hash_pattern, "", street_name, flags=re.IGNORECASE).strip()

    for match_str in unit_matches:
        street_name = street_name.replace(match_str, "").strip()

    street_name = re.sub(r"\s+[A-Z]{1,2}\d{1,3}$", "", street_name).strip()

    if street_name and street_name.upper().endswith("BSMT"):
        basement_str = "[BASEMENT]"
        if basement_str not in unit_info_set:
            updated_unit_info += basement_str
            unit_info_set.add(basement_str)
        street_name = re.sub(r"(?i)BSMT$", "", street_name, flags=re.IGNORECASE).strip()

    return (street_name, updated_unit_info if updated_unit_info else None)

schema = StructType([
    StructField("StreetName", StringType(), True),
    StructField("UnitInfo", StringType(), True)])

UnitTypeParser_udf = udf(UnitTypeParser, schema)

UnitTypeParser_df = NumberAddrParser_df.withColumn("UnitTypeParser",UnitTypeParser_udf(NumberAddrParser_df["StreetName"], NumberAddrParser_df["UnitInfo"]))

UnitTypeParser_df = UnitTypeParser_df.select('GlobalMRNIFK','HospitalFK','PatientAcctIPK','Zip','Addr','UnitTypeParser.StreetName','UnitTypeParser.UnitInfo','Number')

# COMMAND ----------

# DBTITLE 1,UnitTypeDeepParser UDF
def UnitTypeDeepParser(street_name, unit_info):
    if not street_name:
        return (street_name, unit_info)

    updated_unit_info = unit_info or ""
    original_street = street_name

    # Track already present unit info for deduplication
    unit_info_set = set()
    if updated_unit_info:
        # Extract all [TYPE: value] or [#: value] patterns
        unit_info_set.update(re.findall(r"\[[^\[\]:]+:[^\[\]]+\]", updated_unit_info))

    street_name_upper = street_name.upper()
    for unit_type, normalized_type in unit_types.items():
        if unit_type.upper() in street_name_upper:
            pattern = rf"(?i){unit_type}\s*(?P<UnitNumber>#?\s*[A-Z\-]*[0-9\-]+[A-Z\-]*[0-9A-Z]*)$"
            match = re.search(pattern, street_name)
            if match:
                unit_number = match.group("UnitNumber").replace("-", "").strip()
                unit_str = f"[{normalized_type}: {unit_number}]"
                if unit_str not in unit_info_set:
                    updated_unit_info += unit_str if not updated_unit_info else unit_str
                    unit_info_set.add(unit_str)
                street_name = re.sub(pattern, "", street_name, flags=re.IGNORECASE).strip()

    # Special handling for hash sign unit at end (e.g., "# 110")
    hash_unit_pattern = r"\s+#\s*([0-9A-Z\-]+)$"
    hash_match = re.search(hash_unit_pattern, street_name)
    if hash_match:
        unit_number = hash_match.group(1)
        unit_str = f"[#: {unit_number}]"
        if unit_str not in unit_info_set:
            updated_unit_info += unit_str if not updated_unit_info else unit_str
            unit_info_set.add(unit_str)
        street_name = re.sub(hash_unit_pattern, "", street_name).strip()

    # Special handling for PO BOX patterns – keep the PO BOX text in the street name
    po_box_pattern = r"(?i)\bPO\s*BOX\s*([0-9A-Z\-\/]+)\b"
    po_box_match = re.search(po_box_pattern, original_street)
    if po_box_match:
        street_name = original_street  # Retain the original PO BOX text

    return (street_name, updated_unit_info if updated_unit_info else None)

schema = StructType([
    StructField("StreetName", StringType(), True),
    StructField("UnitInfo", StringType(), True)])

UnitTypeDeepParser_udf = udf(UnitTypeDeepParser, schema)

UnitTypeDeepParser_df = UnitTypeParser_df.withColumn("UnitTypeDeepParser", UnitTypeDeepParser_udf(UnitTypeParser_df["StreetName"], UnitTypeParser_df["UnitInfo"]))

UnitTypeDeepParser_df = UnitTypeDeepParser_df.select('GlobalMRNIFK','HospitalFK','PatientAcctIPK','Zip','Addr','UnitTypeDeepParser.StreetName','UnitTypeDeepParser.UnitInfo','Number')

# COMMAND ----------

# DBTITLE 1,HashSignParser UDF
def HashSignParser(street_name, unit_info):
    if street_name is None:
        return ("", None)

    # Match hash sign followed by optional spaces and unit number (case-insensitive not needed for #, but for consistency)
    match = re.search(r"(?:\s|^)\#\s*([0-9A-Z\-]+)\b", street_name, flags=re.IGNORECASE)
    updated_unit_info = unit_info or ""

    if match:
        number = match.group(1)
        unit_str = f"[#:{number}]"
        if unit_str not in (updated_unit_info or ""):
            updated_unit_info += unit_str
        # Remove the matched hash unit, including optional spaces (case-insensitive)
        street_name = re.sub(r"(?:\s|^)\#\s*" + re.escape(number) + r"\b", "", street_name, flags=re.IGNORECASE).strip()

    return (street_name, updated_unit_info if updated_unit_info else None)

schema = StructType([
    StructField("StreetName", StringType(), True),
    StructField("UnitInfo", StringType(), True)])

HashSignParser_udf = udf(HashSignParser, schema)

HashSignParser_df = UnitTypeDeepParser_df.withColumn("HashSignParser", HashSignParser_udf(UnitTypeDeepParser_df["StreetName"], UnitTypeDeepParser_df["UnitInfo"]))

HashSignParser_df = HashSignParser_df.select('GlobalMRNIFK','HospitalFK','PatientAcctIPK','Zip','Addr','HashSignParser.StreetName','HashSignParser.UnitInfo','Number')

# COMMAND ----------

# DBTITLE 1,UnnamedUnitTypeParser UDF
def UnnamedUnitTypeParser(street_name, unit_info):
    if street_name is None:
        return (None, unit_info)

    pattern = r"^(.*\b(?:ST|AVE|DR|RD|NE|NW|SE|SW|N|S|E|W|PLAZA|PLZ|STREET|BLVD|AVENUE|DRIVE|CR|CIRCLE|RT|ROUTE|ROAD|LN|LANE)\b)\s*([#]?\s*[A-Z-]*\d+[A-Z-]*\d*[A-Z]*)$"
    
    #(ST|AVE|DR|RD|NE|NW|SE|SW|N|S|E|W|PLAZA|PLZ|STREET|BLVD|AVENUE|DRIVE)\s{0,1}(?<UnitNumber>#{0,1}\s{0,1}[A-Z0-9-]+$)# 
    #alternative to pick QQ from C/O WVH N 2665 County Rd QQ#
    match = re.match(pattern, street_name.strip(), re.IGNORECASE)
    
    updated_unit_info = unit_info or ""
    if match:
        new_street_name = match.group(1).strip()
        unit_number = match.group(2).replace(" ", "")
        unit_str = f"[NUM:{unit_number}]"
        if unit_str not in updated_unit_info:
            updated_unit_info += unit_str
        return (new_street_name, updated_unit_info if updated_unit_info else None)
    else:
        return (street_name, updated_unit_info if updated_unit_info else None)

schema = StructType([
    StructField("StreetName", StringType(), True),
    StructField("UnitInfo", StringType(), True)])
        
UnnamedUnitTypeParser_udf = udf(UnnamedUnitTypeParser, schema)

UnnamedUnitTypeParser_df = HashSignParser_df.withColumn("UnnamedUnitTypeParser",UnnamedUnitTypeParser_udf(HashSignParser_df["StreetName"], HashSignParser_df["UnitInfo"]))

UnnamedUnitTypeParser_df = UnnamedUnitTypeParser_df.select('GlobalMRNIFK','HospitalFK','PatientAcctIPK','Zip','Addr','UnnamedUnitTypeParser.StreetName','UnnamedUnitTypeParser.UnitInfo','Number')

# COMMAND ----------

# DBTITLE 1,DirectionalAtEndParser UDF
def DirectionalAtEndParser(street_name):
    if not street_name:
        return (street_name, None)
    pattern = r"(?i)(?P<Direction>\b(N|S|E|W|NE|NW|SE|SW|NORTH|SOUTH|EAST|WEST|NORTHEAST|NORTHWEST|SOUTHEAST|SOUTHWEST)\b\s*$)"
    match = re.search(pattern, street_name)
    if match:
        direction = match.group("Direction").strip()
        index_direction = len(street_name) - len(match.group("Direction"))
        street_name = street_name[:index_direction].rstrip()
        return (street_name, direction)
    return (street_name, None)

schema = StructType([
    StructField("StreetName", StringType(), True),
    StructField("DirectionIndicator", StringType(), True)])

DirectionalAtEndParser_udf = udf(DirectionalAtEndParser, schema)

DirectionalAtEndParser_df = UnnamedUnitTypeParser_df.withColumn("DirectionalAtEndParser",DirectionalAtEndParser_udf(UnnamedUnitTypeParser_df["StreetName"]))

DirectionalAtEndParser_df = DirectionalAtEndParser_df.select('GlobalMRNIFK','HospitalFK','PatientAcctIPK','Zip','Addr','DirectionalAtEndParser.StreetName','UnitInfo','DirectionalAtEndParser.DirectionIndicator','Number')

# COMMAND ----------

# DBTITLE 1,SpecialStreetTypeParser UDF
street_types = {
    "ALLEY": "ALLEY",
    "AVE": "AVENUE",
    "AV": "AVENUE",
    "AVENUE": "AVENUE",
    "CIR": "CIRCLE",
    "BEND": "BEND",
    "BYPASS": "BYPASS",
    "BND": "BEND",
    "BLVD": "BOULEVARD",
    "BLUFF": "BLUFF",
    "BOULEVAR": "BOULEVARD",
    "BOULEVARD": "BOULEVARD",
    "CHASE": "CHASE",
    "CR": "CIRCLE",
    "CMNS": "COMMONS",
    "COMMONS": "COMMONS",
    "CIRCLE": "CIRCLE",
    "COURT": "COURT",
    "CROSSING": "CROSSING",
    "CREEK": "CREEK",
    "CRK": "CREEK",
    "CRV": "CURVE",
    "CV": "COVE",
    "COVE": "COVE",
    "CRT": "COURT",
    "CT": "COURT",
    "CURVE": "CURVE",
    "DR": "DRIVE",
    "DRIVE": "DRIVE",
    "DRIV": "DRIVE",
    "EXPY": "EXPRESSWAY",
    "EXT": "EXTENSION",
    "EXTENSION": "EXTENSION",
    "FLD": "FIELD",
    "GLEN": "GLEN",
    "GLN": "GLEN",
    "HILLS": "HILLS",
    "HILL": "HILL",
    "HIGHWAY": "HIGHWAY",
    "HWY": "HIGHWAY",
    "HEIGHTS": "HEIGHTS",
    "HOLLOW": "HOLLOW",
    "HOLW": "HOLLOW",
    "HTS": "HEIGHTS",
    "KNOLL": "KNOLL",
    "LANDING": "LANDING",
    "LANE": "LANE",
    "LN": "LANE",
    "LOOP": "LOOP",
    "MANOR": "MANOR",
    "MNR": "MANOR",
    "OVERLOOK": "OVERLOOK",
    "PARKWAY": "PARKWAY",
    "PATH": "PATH",
    "PASS": "PASS",
    "PKWY": "PARKWAY",
    "PL": "PLACE",
    "PLACE": "PLACE",
    "PLAZA": "PLAZA",
    "PLZ": "PLAZA",
    "POINT": "POINT",
    "POINTE": "POINT",
    "PT": "POINT",
    "RO": "ROAD",
    "RD": "ROAD",
    "RUN": "RUN",
    "ROAD": "ROAD",
    "RDG": "RIDGE",
    "ROW": "ROW",
    "RIDGE": "RIDGE",
    "RIDG": "RIDGE",
    "ST": "STREET",
    "SQUARE": "SQUARE",
    "SQ": "SQUARE",
    "STATE HIGHWAY": "STATE HIGHWAY",
    "STATE HWY": "STATE HIGHWAY",
    "STREET": "STREET",
    "SPUR": "SPUR",
    "TERRACE": "TERRACE",
    "TER": "TERRACE",
    "TERR": "TERRACE",
    "TRACE": "TRACE",
    "TRCE": "TRACE",
    "TR": "TRAIL",
    "TRAIL": "TRAIL",
    "TRC": "TRACE",
    "TRL": "TRAIL",
    "TURNPIKE": "TURNPIKE",
    "TPKE": "TURNPIKE",
    "VILLAGE": "VILLAGE",
    "VLG": "VILLAGE",
    "VIEW": "VIEW",
    "VW": "VIEW",
    "WY": "WAY",
    "WAY": "WAY",
    "WALK": "WALK",
    "WLK": "WALK",
    "XING": "CROSSING"
}

def SpecialStreetTypeParser(street_name):
    if not street_name:
        return (None, None)

    street_type = None
    updated_name = street_name
    address = street_name.upper()

    # Special handling for "CO RD"
    if re.search(r"(?i)\bco rd\b", address):
        updated_name = re.sub(r"(?i)\bco rd\b", "COUNTY ROAD", updated_name)
        street_type = "COUNTY ROAD"
    elif re.search(r"(?i)\bcr\b", address):
        updated_name = re.sub(r"(?i)\bcr\b", "COUNTY ROAD", updated_name)
        street_type = "COUNTY ROAD"
    elif re.search(r"(?i)\bcounty road\b", address):
        updated_name = re.sub(r"(?i)\bcounty road\b", "COUNTY ROAD", updated_name)
        street_type = "COUNTY ROAD"
    elif re.search(r"(?i)\brt\b", address):
        updated_name = re.sub(r"(?i)\brt\b", "ROUTE", updated_name)
        street_type = "ROUTE"

    # Standard street type handling (ignore case) if not already set
    if not street_type:
        # Match street type at end, allowing for abbreviations like "LN", "DR", etc.
        pattern = r"\b([A-Z\.]+)\b\s*$"
        match = re.search(pattern, updated_name, re.IGNORECASE)
        if match:
            road_type = match.group(1).strip().replace(".", "").upper()
            for key in street_types.keys():
                if road_type == key.upper():
                    street_type = street_types[key]
                    updated_name = updated_name[:match.start(1)].rstrip()
                    break

    # Capitalize street_type for output consistency (e.g., "Lane" instead of "LANE")
    if street_type:
        street_type = street_type.capitalize()

    return (updated_name if updated_name else None, street_type)

schema = StructType([
    StructField("StreetName", StringType(), True),
    StructField("StreetType", StringType(), True)])

SpecialStreetTypeParser_udf = udf(SpecialStreetTypeParser, schema)

SpecialStreetTypeParser_df = DirectionalAtEndParser_df.withColumn("SpecialStreetTypeParser",SpecialStreetTypeParser_udf(DirectionalAtEndParser_df["StreetName"]))

SpecialStreetTypeParser_df = SpecialStreetTypeParser_df.select('GlobalMRNIFK','HospitalFK','PatientAcctIPK','Zip','Addr','SpecialStreetTypeParser.StreetName','UnitInfo','DirectionIndicator','SpecialStreetTypeParser.StreetType','Number')

# COMMAND ----------

# DBTITLE 1,StreetTypeAtEndParser UDF
def StreetTypeAtEndParser(street_name):
    if not street_name:
        return {"streetname": street_name, "streettype": None}

    street_type = None
    updated_name = street_name
    address = street_name.upper()

    # Match street type only at the end, ignore case
    pattern = r" ([A-Z\.]+)$"
    match = re.search(pattern, street_name, flags=re.IGNORECASE)
    if match:
        road_type = match.group(1)
        road_type_no_period = road_type.strip(". ").upper()
        if road_type_no_period in (k.upper() for k in street_types):
            for key in street_types:
                if road_type_no_period == key.upper():
                    street_type = street_types[key]
                    updated_name = updated_name[:match.start(1)].strip()
                    break

    return {"streetname": updated_name, "streettype": street_type}

schema = StructType([
    StructField("streetname", StringType(), True),
    StructField("streettype", StringType(), True)])

StreetTypeAtEndParser_udf = udf(StreetTypeAtEndParser, schema)

StreetTypeAtEndParser_df = DirectionalAtEndParser_df.withColumn("StreetTypeAtEndParser",SpecialStreetTypeParser_udf(DirectionalAtEndParser_df["StreetName"]))

StreetTypeAtEndParser_df = StreetTypeAtEndParser_df.select('GlobalMRNIFK','HospitalFK','PatientAcctIPK','Zip','Addr','StreetTypeAtEndParser.StreetName','UnitInfo','DirectionIndicator','StreetTypeAtEndParser.StreetType','Number')

# COMMAND ----------

# DBTITLE 1,DirectionalAtBeginParser UDF
def DirectionalAtBeginParser(street_name, direction_indicator):
    if not street_name or street_name.strip() == "":
        return (None, direction_indicator)
 
    pattern = r"^(NORTH|SOUTH|EAST|WEST|NORTHEAST|NORTHWEST|SOUTHEAST|SOUTHWEST|N|S|E|W|NE|NW|SE|SW)\.?\s+"
    match = re.match(pattern, street_name.strip(), re.IGNORECASE)
 
    if match and not direction_indicator:
        direction = match.group(1).upper()
        cleaned_name = street_name[match.end():].strip()
        return (cleaned_name if cleaned_name else None, direction)
   
    return (street_name if street_name else None, direction_indicator)
 
schema = StructType([
    StructField("StreetName", StringType(), True),
    StructField("DirectionIndicator", StringType(), True)])
 
DirectionalAtBeginParser_udf = udf(DirectionalAtBeginParser, schema)
 
DirectionalAtBeginParser_df = StreetTypeAtEndParser_df.withColumn("DirectionalAtBeginParser",DirectionalAtBeginParser_udf(StreetTypeAtEndParser_df["StreetName"],StreetTypeAtEndParser_df["DirectionIndicator"]))
 
DirectionalAtBeginParser_df = DirectionalAtBeginParser_df.select('GlobalMRNIFK','HospitalFK','PatientAcctIPK','Zip','Addr','DirectionalAtBeginParser.StreetName','UnitInfo','DirectionalAtBeginParser.DirectionIndicator','StreetType','Number')

# COMMAND ----------

# DBTITLE 1,TextReplacementParser UDF
# Define the text replacement dictionary
text_swap = {
    "AVE": "AVENUE", "APTS": "APARTMENTS", "BR": "BRANCH", "CNTR": "CENTER", "CIR": "CIRCLE",
    "BND": "BEND", "BLVD": "BOULEVARD", "CRV": "CURVE", "CV": "COVE", "CT": "COURT",
    "DR": "DRIVE", "DRV": "DRIVE", "EXPY": "EXPRESSWAY", "FLD": "FIELD", "GA": "GEORGIA",
    "GLN": "GLEN", "HWY": "HIGHWAY", "HTS": "HEIGHTS", "LN": "LANE", "PKWY": "PARKWAY",
    "MEW": "MEADOW", "MTN": "MOUNTAIN", "MT": "MOUNT", "PL": "PLACE", "PLZ": "PLAZA",
    "RD": "ROAD", "RDG": "RIDGE", "RIDG": "RIDGE", "RT": "ROUTE", "ST": "STREET",
    "STATE HWY": "STATE HIGHWAY", "TER": "TERRACE", "TRCE": "TRACE", "TRC": "TRACE",
    "TRL": "TRAIL", "TPKE": "TURNPIKE", "VLG": "VILLAGE", "WLK": "WALK", "XING": "CROSSING",
    "APT": "APARTMENT", "NUM": "NUMBER", "STE": "SUITE", "BLD": "BUILDING", "BLDG": "BUILDING",
    "DEPT": "DEPARTMENT", "FL": "FLOOR", "RM": "ROOM", "TRLR": "TRAILER",
    "US HIGHWAY": "HIGHWAY", "GA HIGHWAY": "HIGHWAY", "STATE ROUTE": "ROUTE", "SR": "ROUTE",
    "GEORGIA HIGHWAY": "HIGHWAY", "1ST": "FIRST", "2ND": "SECOND", "3RD": "THIRD",
    "4TH": "FOURTH", "5TH": "FIFTH", "6TH": "SIXTH", "7TH": "SEVENTH", "8TH": "EIGHTH",
    "9TH": "NINTH"
}

def TextReplacementParser(street_name):
    if not street_name:
        return ""
    for key, value in text_swap.items():
        # Use regex to match whole words only
        street_name = re.sub(rf'\b{key}\b', value, street_name, flags=re.IGNORECASE)
    return street_name

TextReplacementParser_udf = udf(TextReplacementParser, StringType())

TextReplacementParser_df = DirectionalAtBeginParser_df.withColumn("StreetName", TextReplacementParser_udf(DirectionalAtBeginParser_df["StreetName"]))

TextReplacementParser_df = TextReplacementParser_df.select('GlobalMRNIFK','HospitalFK','PatientAcctIPK','Zip','Addr','StreetName','UnitInfo','DirectionIndicator','StreetType','Number')

# COMMAND ----------

# DBTITLE 1,NormalizedStreetParser UDF
def NormalizedStreetParser(street_name):
    if street_name is None:
        return ""
    words = street_name.split()
    normalized = []
    for word in words:
        if word.endswith("S"):
            normalized.append(word[:-1])  # Remove trailing 'S'
        else:
            normalized.append(word)
    return ''.join(normalized)

NormalizedStreetParser_udf = udf(NormalizedStreetParser, StringType())

NormalizedStreetParser_df = TextReplacementParser_df.withColumn("StreetNameNormalized", NormalizedStreetParser_udf(TextReplacementParser_df["StreetName"]))

NormalizedStreetParser_df = NormalizedStreetParser_df.select('GlobalMRNIFK','HospitalFK','PatientAcctIPK','Zip','Addr','StreetName','StreetNameNormalized','UnitInfo','DirectionIndicator','StreetType','Number')

# COMMAND ----------

# DBTITLE 1,Filters and Write to Normalized staging table
NormalizedAdresses_df = NormalizedStreetParser_df.withColumn("StreetName", when(length(col("StreetName")) <= 100, col("StreetName")).otherwise(""))
NormalizedAdresses_df = NormalizedAdresses_df.withColumn("StreetNum", when(length(col("Number")) <= 50, col("Number")).otherwise("")).drop("Number")
NormalizedAdresses_df = NormalizedAdresses_df.withColumn("StreetNameNormalized", when(length(col("StreetNameNormalized")) <= 100, col("StreetNameNormalized")).otherwise(""))
NormalizedAdresses_df = NormalizedAdresses_df.withColumn("StreetType", when(length(col("StreetType")) <= 50, col("StreetType")).otherwise(""))
NormalizedAdresses_df = NormalizedAdresses_df.withColumn("DirectionIndicator", when(length(col("DirectionIndicator")) <= 50, col("DirectionIndicator")).otherwise(""))
NormalizedAdresses_df = NormalizedAdresses_df.withColumn("UnitInfo", when(length(col("UnitInfo")) <= 50, col("UnitInfo")).otherwise(""))
NormalizedAdresses_df = NormalizedAdresses_df.withColumn("UnitNum",when((length(col("UnitInfo")) <= 50) & col("UnitInfo").contains(":") & col("UnitInfo").contains("]"),trim(regexp_extract(col("UnitInfo"), r":([^\]]+)\]", 1))).otherwise(""))
NormalizedAdresses_df = NormalizedAdresses_df.withColumn("bc",lit(bc))
NormalizedAdresses_df.write.mode("overwrite").format("delta").option("replaceWhere", f"bc = '{bc}'").saveAsTable(StagingTable2)

# COMMAND ----------

# DBTITLE 1,Max IPK
max_addresslistpk = spark.sql(f"SELECT MAX(addresslistpk) FROM {AddressListTable}").collect()[0][0]
max_patientacctsaddresspk = spark.sql(f"SELECT MAX(patientacctsaddresspk) FROM {PatientAcctsAddressTable}").collect()[0][0]

# COMMAND ----------

# DBTITLE 1,Addresslist Inserts
AddresslistInertQuery = f"""
MERGE INTO {AddressListTable} AS target
USING (
    SELECT ({max_addresslistpk}) + ROW_NUMBER() OVER (ORDER BY sub.Zip, sub.StreetNum) AS AddressListPK,SUB.* from (SELECT DISTINCT st.Zip, st.StreetNum, MAX(st.StreetName) AS StreetName, st.StreetNameNormalized, MAX(st.StreetType) AS StreetType, MAX(st.DirectionIndicator) AS DirectionIndicator, MAX(st.UnitInfo) AS UnitInfo, st.UnitNum,current_timestamp as createdate,'app_databricks' as createdby,current_timestamp as updatedate,'app_databricks' as updatedby,'{bc}' as bc,'{bc}' as bcupdated
    FROM (SELECT * FROM {StagingTable2} WHERE bc = '{bc}') AS st
    left JOIN {AddressListTable}  al
        ON st.Zip = al.Zip
        AND (coalesce(st.StreetNameNormalized,'') = coalesce(al.StreetNameNormalized,'') AND coalesce(st.StreetNum,'') = coalesce(al.StreetNum,'') AND coalesce(st.UnitNum,'') = coalesce(al.UnitNum,''))
    WHERE al.Zip IS NULL
    GROUP BY st.Zip, st.StreetNum, st.StreetNameNormalized, st.UnitNum) AS SUB
) AS source
ON target.Zip = source.Zip AND target.StreetNum = source.StreetNum AND target.StreetNameNormalized = source.StreetNameNormalized AND target.UnitNum = source.UnitNum
WHEN NOT MATCHED THEN 
INSERT (AddressListPK, Zip, StreetNum, StreetName, StreetNameNormalized, StreetType, DirectionIndicator, UnitInfo, UnitNum, createdate, createdby, updatedate, updatedby, bc, bcupdated) 
VALUES (source.AddressListPK, source.Zip, source.StreetNum, source.StreetName, source.StreetNameNormalized, source.StreetType, source.DirectionIndicator, source.UnitInfo, source.UnitNum, source.createdate, source.createdby, source.updatedate, source.updatedby, source.bc, source.bcupdated)"""

AddresslistInert_df = spark.sql(AddresslistInertQuery,AddressListTable =AddressListTable,bc=bc,max_addresslistpk=max_addresslistpk,StagingTable2 = StagingTable2)

# COMMAND ----------

# DBTITLE 1,PatientAcctsAddress Updates
PatientAcctsAddressUpdateQuery = f""" MERGE INTO {PatientAcctsAddressTable} AS target
     USING (
      SELECT al.AddressListPK,st.HospitalFK,st.PatientAcctIPK from 
      (SELECT HospitalFK,PatientAcctIPK,Zip,StreetNameNormalized,StreetNum,UnitNum FROM {StagingTable2} WHERE bc = '{bc}') as st
      JOIN {AddressListTable} al 
      ON st.Zip = al.Zip AND st.StreetNameNormalized = al.StreetNameNormalized AND st.StreetNum = al.StreetNum AND st.UnitNum = al.UnitNum
      ) AS source
       ON target.HospitalFK = source.HospitalFK AND target.PatientAcctIFK = source.PatientAcctIPK AND target.AddressListFK <> source.AddressListPK
WHEN MATCHED THEN UPDATE SET AddressListFK = source.AddressListPK, bcupdated = '{bc}',updatedate=current_timestamp """

PatientAcctsAddressUpdate_df = spark.sql(PatientAcctsAddressUpdateQuery,AddressListTable=AddressListTable,PatientAcctsAddressTable=PatientAcctsAddressTable,bc=bc,StagingTable2 = StagingTable2)

# COMMAND ----------

# DBTITLE 1,PatientAcctsAddress Inserts
PatientAcctsAddressInsertQuery = f"""MERGE INTO {PatientAcctsAddressTable} AS target
     USING (
      SELECT ({max_patientacctsaddresspk}) + ROW_NUMBER() OVER (ORDER BY st.HospitalFK, st.PatientAcctIPK) as patientacctsaddresspk,st.HospitalFK, st.PatientAcctIPK, st.GlobalMRNIFK, st.Zip, al.AddressListPK,ROW_NUMBER() OVER (PARTITION BY st.HospitalFK, st.PatientAcctIPK ORDER BY st.HospitalFK, st.PatientAcctIPK) AS Row_Num,current_timestamp as createdate,'app_databricks' as createdby,current_timestamp as updatedate,'app_databricks' as updatedby,'{bc}' as bc,'{bc}' as bcupdated
      FROM (SELECT * FROM {StagingTable2} WHERE bc = '{bc}') as st
      JOIN {AddressListTable} al 
      ON st.Zip = al.Zip AND st.StreetNameNormalized = al.StreetNameNormalized AND st.StreetNum = al.StreetNum AND st.UnitNum = al.UnitNum
      ) AS source
       ON target.HospitalFK = source.HospitalFK AND target.PatientAcctIFK = source.PatientAcctIPK
WHEN NOT MATCHED AND source.Row_Num = 1 THEN
INSERT (patientacctsaddresspk,HospitalFK, PatientAcctIFK, GlobalMRNIFK, Zip, AddressListFK, createdate, createdby, updatedate, updatedby, bc, bcupdated)
VALUES (source.patientacctsaddresspk,source.HospitalFK, source.PatientAcctIPK, source.GlobalMRNIFK, source.Zip, source.AddressListPK, source.createdate, source.createdby, source.updatedate, source.updatedby, source.bc, source.bcupdated)"""

PatientAcctsAddressInsert_df = spark.sql(PatientAcctsAddressInsertQuery,AddressListTable=AddressListTable,PatientAcctsAddressTable=PatientAcctsAddressTable,bc=bc,StagingTable2=StagingTable2,max_patientacctsaddresspk=max_patientacctsaddresspk)
