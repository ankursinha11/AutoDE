# Databricks notebook source
## DDL for UC Tables ##

# COMMAND ----------

dbutils.widgets.text("catalog_name","")
catalog_name=dbutils.widgets.get("catalog_name")

# COMMAND ----------

spark.sql(f"""CREATE TABLE IF NOT EXISTS {catalog_name}.cdd_staging.patientacctaddressesraw
(GlobalMRNIFK string,
HospitalFK smallint,
PatientAcctIPK string,
Zip string,
Addr string,
bc string)
TBLPROPERTIES('vacuum'='72 hours')
""")

# COMMAND ----------

spark.sql(f"""CREATE TABLE IF NOT EXISTS {catalog_name}.cdd_staging.patientacctaddressesnormlized
(GlobalMRNIFK string,
HospitalFK smallint,
PatientAcctIPK string,
Zip string,
Addr string,
StreetName string,
StreetNameNormalized string,
UnitInfo string,
DirectionIndicator string,
StreetType string,
StreetNum string,
UnitNum string,
bc string)
TBLPROPERTIES('vacuum'='72 hours')
""")
