# Databricks notebook source
# permid_publish_parquet.py
# This script is to 
#           - Read permid data written in csv.
#           - Combine all match ind (bc, bc-M1) 
#           - write bc to parque

# COMMAND ----------

#define input variables
dbutils.widgets.text("hdfs_permid_input","")
dbutils.widgets.getArgument("hdfs_permid_input")
hdfs_permid_input= getArgument("hdfs_permid_input")

dbutils.widgets.text("hdfs_permid_publish","")
dbutils.widgets.getArgument("hdfs_permid_publish")
hdfs_permid_publish= getArgument("hdfs_permid_publish")

dbutils.widgets.text("bc", "")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

import sys
import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql import SparkSession
from pyspark import SparkContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import *

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/common_util"

# COMMAND ----------

# DBTITLE 1,adls access
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

permid_patientacctid_schema = StructType([
    StructField("permid", StringType(), nullable=True),
	StructField("patientacctifk", StringType(), nullable=True),
    StructField("matchind", StringType(), nullable=True),
    StructField("magnetpermid", StringType(), nullable=True),
    StructField("hospitalfk", ShortType(), nullable=False)
])

# COMMAND ----------

df_pa = readcsv_permissive(spark,baseurl+hdfs_permid_input + "/" + bc, permid_patientacctid_schema, "|", "0", "na")

# COMMAND ----------

df_pam = readcsv_permissive(spark,baseurl+hdfs_permid_input + "/" + bc +"-M1", permid_patientacctid_schema, "|", "0", "na")

# COMMAND ----------

df = df_pa.union(df_pam)

# COMMAND ----------

writeparquet(spark, df,baseurl+hdfs_permid_publish + "/" + bc, 1, "overwrite")
