# Databricks notebook source
# 1. first time new bc datasource is same
# 2. any entry in bc change datasource to NA 

# COMMAND ----------

dbutils.widgets.text("maprdbtable", "")
maprdbtable = dbutils.widgets.getArgument("maprdbtable")
print(maprdbtable)

dbutils.widgets.text("cosmosendpoint", "")
dbutils.widgets.getArgument("cosmosendpoint")
cosmosendpoint = getArgument("cosmosendpoint")
print(cosmosendpoint)

dbutils.widgets.text("cosmosdb", "")
dbutils.widgets.getArgument("cosmosdb")
cosmosdb= getArgument("cosmosdb")
print(cosmosdb)

dbutils.widgets.text("bc", "")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")
print(bc)

dbutils.widgets.text("datasource", "")
dbutils.widgets.getArgument("datasource")
datasource= getArgument("datasource")
print(datasource)

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/cosmos_util"

# COMMAND ----------

if datasource == "es_swift":
        notificationtype = "bdf_download"
elif datasource == "ie":
        notificationtype = "bdf_download_ie"
elif datasource == "chc":
        notificationtype = "chc_xref"
print(notificationtype)

# COMMAND ----------

# if datasource == "es":
#     notificationtype = "bdf_download"
# elif datasource == "ie":
#     notificationtype = "bdf_download_ie"
# elif datasource == "chc":
#     notificationtype = "bdf_download_chc"
# else:
#     notificationtype = "bdf_download"

# COMMAND ----------

filterExp = f"notificationtype == '{notificationtype}' and bc == '{bc}'"
filterExp

# COMMAND ----------

spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
config = cosmosconfig(cosmosendpoint, cosmosdb, maprdbtable)
df = readfromcosmosdb(config)
df = df.filter(filterExp)

if df.count() != 0:
    datasource = "NA"
print(datasource)

# COMMAND ----------

dbutils.notebook.exit({'datasource':datasource})

# COMMAND ----------

# 1. first time new bc datasource is same
# 2. any entry in bc change datasource to NA 

# COMMAND ----------

# 1. first time new bc datasource is same
# 2. for unprocessed and running with bc need datasource to return NA
# 3. for processed with bc need datasource to return NA when time window is less than 5 hrs