# Databricks notebook source
#merge_swift.pig

# COMMAND ----------

# DBTITLE 1,input variables
#define input variables
dbutils.widgets.text("inputPostBDFDir","")
dbutils.widgets.getArgument("inputPostBDFDir")
inputPostBDFDir= getArgument("inputPostBDFDir")

dbutils.widgets.text("outputBaseDir","")
dbutils.widgets.getArgument("outputBaseDir")
outputBaseDir= getArgument("outputBaseDir")

dbutils.widgets.text("bc", "")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/common_util"

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# DBTITLE 1,adls access
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

postBDF = spark.read.text(baseurl+inputPostBDFDir+bc+'/*_cbeMatchAppend.dat')

# COMMAND ----------

postBDF = postBDF.select(
		col("value").substr(1,64).alias("ID"),
		col("value").substr(65,50).alias("FN"),
		col("value").substr(115,50).alias("MN"),
		col("value").substr(165,50).alias("LN"),
		col("value").substr(215,1).alias("Gender"),
		col("value").substr(216,9).alias("SSN"),
		col("value").substr(225,10).alias("DOB"),
		col("value").substr(235,75).alias("Address1"),
		col("value").substr(310,75).alias("Address2"),
		col("value").substr(385,30).alias("City"),
		col("value").substr(415,2).alias("State"),
		col("value").substr(417,5).alias("Zip"),
		col("value").substr(422,5).alias("Zip4"),
		col("value").substr(427,20).alias("Phone"),
		col("value").substr(447,32).alias("Custom1"),
		col("value").substr(479,64).alias("Custom2"),
		col("value").substr(543,3).alias("FileNum"),
		col("value").substr(546,12).alias("RecordNum"),
		col("value").substr(558,12).alias("MagnetPermId"),
		col("value").substr(570,12).alias("PermId"),
		col("value").substr(582,2).alias("MatchInd"),
		col("value").substr(584,12).alias("LinkId")
		)

# COMMAND ----------

allRecs = postBDF.select(
		trim(col("ID")).alias("ID"),
		trim(col("FN")).alias("FN"),
		trim(col("MN")).alias("MN"),
		trim(col("LN")).alias("LN"),
		trim(col("Gender")).alias("Gender"),
		trim(col("SSN")).alias("SSN"),
		trim(col("DOB")).alias("DOB"),
		trim(col("Address1")).alias("Address1"),
		trim(col("Address2")).alias("Address2"),
		trim(col("City")).alias("City"),
		trim(col("State")).alias("State"),
		trim(col("Zip")).alias("Zip"),
		trim(col("Zip4")).alias("Zip4"),
		trim(col("Phone")).alias("Phone"),
        trim(col("Custom1")).alias("Custom1"),
		trim(col("Custom2")).alias("Custom2"),
		trim(col("Custom2")).alias("BreadCrumbs"),
		trim(col("FileNum")).alias("FileNum"),
		trim(col("RecordNum")).alias("RecordNum"),
		trim(col("MagnetPermId")).alias("MagnetPermId"),
		trim(col("PermId")).alias("PermId"),
		trim(col("MatchInd")).alias("MatchInd"),
		trim(col("LinkId")).alias("LinkId")
		)

# COMMAND ----------

allRecs = allRecs \
    .withColumn("HospitalFk", split(col("ID"), "_").getItem(0)) \
    .withColumn("PatientAcctId", split(col("ID"), "_").getItem(1)).drop("ID")
    
cols = ["HospitalFk", "PatientAcctId"] + [c for c in allRecs.columns if c not in ("HospitalFk", "PatientAcctId")]
allRecs = allRecs.select(cols)

# COMMAND ----------

visitIdPermId = allRecs.select("PermId","PatientAcctId","MatchInd","MagnetPermId","HospitalFk")

# COMMAND ----------

distinctVisitIdPermId = visitIdPermId.dropDuplicates()

# COMMAND ----------

# DBTITLE 1,permIdPatientAcctId
writecsv(spark,distinctVisitIdPermId,baseurl+outputBaseDir+'permIdPatientAcctId/'+bc,1,'overwrite',"|")

# COMMAND ----------

distinctRecs = allRecs.groupBy("MagnetPermId","PermId","MatchInd","LinkId").agg(count("PermId")).alias("counts")

# COMMAND ----------

distinctRecsSelectedFields = distinctRecs.select("MagnetPermId","PermId","MatchInd","LinkId")

# COMMAND ----------

# DBTITLE 1,allDistinctRecs
writecsv(spark,distinctRecsSelectedFields,baseurl+outputBaseDir+'allDistinctRecs/'+bc,1,'overwrite',"|")

# COMMAND ----------

postBDFRejects = spark.read.text(baseurl+inputPostBDFDir+bc+'/*_cbeEditRejects.dat')

# COMMAND ----------

postBDFRejects = postBDFRejects.select(
		col("value").substr(1,64).alias("ID"),
		col("value").substr(65,50).alias("FN"),
		col("value").substr(115,50).alias("MN"),
		col("value").substr(165,50).alias("LN"),
		col("value").substr(215,1).alias("Gender"),
		col("value").substr(216,9).alias("SSN"),
		col("value").substr(225,10).alias("DOB"),
		col("value").substr(235,75).alias("Address1"),
		col("value").substr(310,75).alias("Address2"),
		col("value").substr(385,30).alias("City"),
		col("value").substr(415,2).alias("State"),
		col("value").substr(417,5).alias("Zip"),
		col("value").substr(422,5).alias("Zip4"),
		col("value").substr(427,20).alias("Phone"),
		col("value").substr(447,32).alias("Custom1"),
		col("value").substr(479,64).alias("Custom2")
		)

# COMMAND ----------

postBDFRejects = postBDFRejects.select(*[trim(col(c)).alias(c) for c in postBDFRejects.columns])

# COMMAND ----------

postBDFRejects = postBDFRejects \
    .withColumn("HospitalFk", split(col("ID"), "_").getItem(0)) \
    .withColumn("PatientAcctId", split(col("ID"), "_").getItem(1)).drop("ID")
cols = ["HospitalFk", "PatientAcctId"] + [c for c in postBDFRejects.columns if c not in ("HospitalFk", "PatientAcctId")]
postBDFRejects = postBDFRejects.select(cols)

# COMMAND ----------

postBDFRejects = postBDFRejects.select(*[when(col(c) == "", None).otherwise(col(c)).alias(c) for c in postBDFRejects.columns])

# COMMAND ----------

postBDFNoHits = spark.read.text(baseurl+inputPostBDFDir+bc+'/*_cbeNoHits.dat')

# COMMAND ----------

postBDFNoHits = postBDFNoHits.select(
		col("value").substr(1,64).alias("ID"),
		col("value").substr(65,50).alias("FN"),
		col("value").substr(115,50).alias("MN"),
		col("value").substr(165,50).alias("LN"),
		col("value").substr(215,1).alias("Gender"),
		col("value").substr(216,9).alias("SSN"),
		col("value").substr(225,10).alias("DOB"),
		col("value").substr(235,75).alias("Address1"),
		col("value").substr(310,75).alias("Address2"),
		col("value").substr(385,30).alias("City"),
		col("value").substr(415,2).alias("State"),
		col("value").substr(417,5).alias("Zip"),
		col("value").substr(422,5).alias("Zip4"),
		col("value").substr(427,20).alias("Phone"),
		col("value").substr(447,32).alias("Custom1"),
		col("value").substr(479,64).alias("Custom2")
		)

# COMMAND ----------

postBDFNoHits = postBDFNoHits.select(*[trim(col(c)).alias(c) for c in postBDFNoHits.columns])

# COMMAND ----------

postBDFNoHits = postBDFNoHits \
    .withColumn("HospitalFk", split(col("ID"), "_").getItem(0)) \
    .withColumn("PatientAcctId", split(col("ID"), "_").getItem(1)).drop("ID")

cols = ["HospitalFk", "PatientAcctId"] + [c for c in postBDFNoHits.columns if c not in ("HospitalFk", "PatientAcctId")]
postBDFNoHits = postBDFNoHits.select(cols)

# COMMAND ----------

postBDFNoHits = postBDFNoHits.select(*[when(col(c) == "", None).otherwise(col(c)).alias(c) for c in postBDFNoHits.columns])

# COMMAND ----------

NOPERM = postBDFNoHits.union(postBDFRejects)

# COMMAND ----------

# DBTITLE 1,nopermid
writecsv(spark,NOPERM,baseurl+outputBaseDir+'nopermid/'+bc,1,'overwrite',"|")

# COMMAND ----------

NH = postBDFNoHits.select("PatientAcctId","HospitalFk")

# COMMAND ----------

# DBTITLE 1,nohits
writecsv(spark,NH,baseurl+outputBaseDir+'es_nohits/'+bc,1,'overwrite',"|")

# COMMAND ----------

RJ = postBDFRejects.select("PatientAcctId","HospitalFk")

# COMMAND ----------

# DBTITLE 1,norejects
writecsv(spark,RJ,baseurl+outputBaseDir+'es_rejects/'+bc,1,'overwrite',"|")
