# Databricks notebook source
#audit_bdf_swift.sh

# COMMAND ----------

# DBTITLE 1,input variables
#define input variables
dbutils.widgets.text("datasource","")
dbutils.widgets.getArgument("datasource")
datasource= getArgument("datasource")

dbutils.widgets.text("bc", "")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("bdf_input","")
dbutils.widgets.getArgument("bdf_input")
bdf_input= getArgument("bdf_input")


dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

error = 0

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

# DBTITLE 1,adls access
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

import re
import datetime

# COMMAND ----------

# DBTITLE 1,bc check
# Checking the breadcrumb passed in from the bdf download process to be a valid breadcrumb
if not bc: #proceeds when bc value empty
  error = 1
else:
  if not (re.match(r"^\d{2}[A-Z]{3}\d{4}(-)\d{2}$", bc) or re.match(r"^\d{8}T\d{2}$", bc)): #checks if bc value matches to yyyymmddThh or ddMMMyyyy-hh format
    error = 1
  else:
    if re.match(r"^\d{2}[A-Z]{3}\d{4}(-)\d{2}$", bc): #ddMMMyyyy-hh
      month = bc[2:5]
      day = bc[0:2]
      year = bc[5:9]
      hh = bc[10:12]
      months = ["INVALID", "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"]
      imonth = months.index(month)
      try:
        datetime.datetime(int(year), int(imonth), int(day), int(hh))
      except ValueError:
        error = 1
    elif re.match(r"^\d{8}T\d{2}$", bc): #yyyymmddThh
      imonth = bc[4:6]
      day = bc[6:8]
      year = bc[0:4]
      hh = bc[9:11]
      try:
        datetime.datetime(int(year), int(imonth), int(day), int(hh))
      except ValueError:
        error = 1

# COMMAND ----------

print(error)

# COMMAND ----------

filelist = dbutils.fs.ls(baseurl+bdf_input+datasource+'_bdf/'+bc)
MatchAppendfile = []
if not error: #proceeds with error=0
  if datasource: #proceeds with datasource not empty
      for f in filelist:
          if f.name.endswith("_cbeMatchAppend.dat"):
              MatchAppendfile.append(f.name) 
      if MatchAppendfile:   # proceeds with not empty
        error = 0
      else:
        error = 1
      if not any(f.name.endswith("_cbeNoHits.dat") for f in filelist):
          dbutils.fs.put(baseurl+bdf_input+datasource+'_bdf/'+bc+'/empty_cbeNoHits.dat','')

      if not any(f.name.endswith("_cbeEditRejects.dat") for f in filelist):
          dbutils.fs.put(baseurl+bdf_input+datasource+'_bdf/'+bc+'/empty_cbeEditRejects.dat','')
      #if not any(f.name.endswith("_test.dat") for f in filelist): #test
      #  dbutils.fs.put(baseurl+bdf_input+datasource+'_bdf/'+bc+'/empty_test.dat','')

# COMMAND ----------

print(error)

# COMMAND ----------

# Checking file data Match Indicator to be IM or HM
for f in MatchAppendfile:
    first_line = dbutils.fs.head(baseurl+bdf_input+datasource+'_bdf/'+bc+'/'+f,1000) #reads first 1000 characters
    matchind = first_line[581:583].strip().upper()
    print(matchind)
    if not (matchind == "IM" or matchind == "HM"):
        error = 1

# COMMAND ----------

if error:
  print("error=true")
  raise Exception ("error returned as 1")
else:
  print("error=false")

# COMMAND ----------

audit_bdf_swift_output = {'error': error}

# COMMAND ----------

dbutils.notebook.exit(audit_bdf_swift_output)