# Databricks notebook source
#process_bdf.sh

# COMMAND ----------

# DBTITLE 1,input variables
dbutils.widgets.text("bdf_input","")
dbutils.widgets.getArgument("bdf_input")
bdf_input= getArgument("bdf_input")

dbutils.widgets.text("dbfsziptemppath","")
dbutils.widgets.getArgument("dbfsziptemppath")
dbfsziptemppath= getArgument("dbfsziptemppath")

dbutils.widgets.text("dbfsextracttemppath","")
dbutils.widgets.getArgument("dbfsextracttemppath")
dbfsextracttemppath= getArgument("dbfsextracttemppath")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

# DBTITLE 1,adls access
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# DBTITLE 1,to get file pattern for processing one bc at a time
firstfilevalue = 1
for i in dbutils.fs.ls(baseurl+bdf_input+'bdf'):
    if '.ZIP' in i.name and firstfilevalue >0:
        filepart = i.name.split('.')[4]
        firstfilevalue = firstfilevalue-1

# COMMAND ----------

# DBTITLE 1,copy adls zip folder to dbfs
dbutils.fs.cp(baseurl+bdf_input+'bdf',dbfsziptemppath,True)

# COMMAND ----------

# DBTITLE 1,extracts zip files and gets bc, datasource values from bdf files
import zipfile
for i in dbutils.fs.ls(dbfsziptemppath):
    if filepart in i.name:
        #print(i.path)
        with zipfile.ZipFile('/'+i.path.replace(':',''), "r") as zip_ref:
            zip_ref.extractall('/'+dbfsextracttemppath.replace(':',''))
            extractedfile = zip_ref.namelist()[0]
            #print(extractedfiles)
        with open('/'+dbfsextracttemppath.replace(':','')+extractedfile, "r") as file:
            first_line = file.readline()
        # Extract the breadcrumb and datasource
        breadcrumb = first_line[530:542].strip()
        datasource = first_line[446:478].strip()
        if 'chc' in datasource:
            datasource = 'chc'
        elif 'ie' in datasource:
            datasource = 'ie'
        dbutils.fs.mkdirs(baseurl+bdf_input+datasource+'_bdf/'+breadcrumb+'/')
        #dbutils.fs.mkdirs(baseurl+bdf_input+'/bdf/'+'bdf_empty')
        
        if len(breadcrumb) > 0 and len(datasource) > 0 :
            dbutils.fs.mv(dbfsextracttemppath+extractedfile,baseurl+bdf_input+datasource+'_bdf/'+breadcrumb)
        #else:
        #    dbutils.fs.mv(dbfsextracttemppath+extractedfile,baseurl+bdf_input+'/bdf/'+'bdf_empty')


# COMMAND ----------

# DBTITLE 1,remove zip files copied to dbfs from adls
dbutils.fs.rm(dbfsziptemppath,True) #need to reverify if this required or not

# COMMAND ----------

# DBTITLE 1,move source files after extract
dbutils.fs.mkdirs(baseurl+bdf_input+'bdf_archive/'+datasource+'/'+breadcrumb+'/')
dbutils.fs.mkdirs(baseurl+bdf_input+'bdf_empty'+'/')
if len(breadcrumb) > 0 and len(datasource) > 0 :
    for i in dbutils.fs.ls(baseurl+bdf_input+'bdf'):
        if filepart in i.name:
            dbutils.fs.mv(i.path,baseurl+bdf_input+'bdf_archive/'+datasource+'/'+breadcrumb)
else:
    for i in dbutils.fs.ls(baseurl+bdf_input+'bdf'):
        if filepart in i.name:
            dbutils.fs.mv(i.path,baseurl+bdf_input+'bdf_empty'+'/')

# COMMAND ----------

#if 'ie' in datasource:
#   datasource = 'ie'

# COMMAND ----------

process_bdf_output = {'bc':breadcrumb,'datasource':datasource}

# COMMAND ----------

dbutils.notebook.exit(process_bdf_output)