# Databricks notebook source
#match1.pig

# COMMAND ----------

#define input variables
dbutils.widgets.text("TUpath","")
dbutils.widgets.getArgument("TUpath")
TUpath= getArgument("TUpath")

dbutils.widgets.text("outputBaseDir","")
dbutils.widgets.getArgument("outputBaseDir")
outputBaseDir= getArgument("outputBaseDir")

dbutils.widgets.text("bc", "")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/common_util"

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/dateValidation" 

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# DBTITLE 1,adls access
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

nopermidschema = StructType([
    StructField("hospitalfk", ShortType(), False),
    StructField("PatientAcctId", StringType(), True),
    StructField("FN", StringType(), True),
    StructField("MN", StringType(), True),
	StructField("LN", StringType(), True),
    StructField("Gender", StringType(), True),
    StructField("SSN", StringType(), True),
    StructField("DOB", StringType(), True),
    StructField("Address1", StringType(), True),
    StructField("Address2", StringType(), True),
	StructField("City", StringType(), True),
    StructField("State", StringType(), True),
    StructField("Zip", StringType(), True),
	StructField("Zip4", StringType(), True),
    StructField("Phone", StringType(), True),
    StructField("Custom1", StringType(), True),
    StructField("Custom2", StringType(), True)
])

# COMMAND ----------

ES1 = readcsv(spark,baseurl+outputBaseDir+'nopermid/'+bc+'/*.csv',nopermidschema,'|','0','na')

# COMMAND ----------

ESSUB1 = ES1.select("PatientAcctId", "FN","LN","DOB","hospitalfk")

# COMMAND ----------

transformDate_udf = udf(transformDate,StringType())

# COMMAND ----------

ESSUB1 = ESSUB1.withColumn("DOB",transformDate_udf(ESSUB1["DOB"]))

# COMMAND ----------

for i in dbutils.fs.ls(baseurl+TUpath):
    TUpath = i.path

# COMMAND ----------

# TUCONSUMER = readcsv(spark,TUpath,tuconsumerschema,'|','0','na')
TUCONSUMER = spark.read.parquet(TUpath)

# COMMAND ----------

TUSUBSET = TUCONSUMER.select("TUKEY","FRST_NME","LAST_NME","DOB")

# COMMAND ----------

TUSUBSET = TUSUBSET.withColumn("DOB",transformDate_udf(TUSUBSET["DOB"]))

# COMMAND ----------

F1 = ESSUB1.filter("DOB is not null and DOB !=''")

# COMMAND ----------

joincondition = [F1["FN"] == TUSUBSET["FRST_NME"],F1["LN"] == TUSUBSET["LAST_NME"],F1["DOB"] == TUSUBSET["DOB"]]

# COMMAND ----------

J1 = F1.join(TUSUBSET,on=joincondition,how='inner')

# COMMAND ----------

G1 = J1.select("TUKEY","PatientAcctId",lit('M1').alias('cust1'),lit("").alias('cust2'),"hospitalfk")

# COMMAND ----------

G2 = G1.groupBy("PatientAcctId","hospitalfk").agg(count("PatientAcctId").alias("tncount"))

# COMMAND ----------

G3 = G2.filter("tncount == 1")

# COMMAND ----------

G4 = G3.join(G1,["PatientAcctId","hospitalfk"],"inner")

# COMMAND ----------

G5 = G4.select("TUKEY","PatientAcctId","cust1",when(col("cust2") == "", None).otherwise(col("cust2")).alias("cust2"),"hospitalfk")

# COMMAND ----------

writecsv(spark,G5,baseurl+outputBaseDir+'permIdPatientAcctId/'+bc+'-M1',1,'overwrite',"|")

# COMMAND ----------

G6 = G4.select(when(col("cust2") == "", None).otherwise(col("cust2")).alias("c1"),"TUKEY",lit("M1").alias("c2"),when(col("cust2") == "", None).otherwise(col("cust2")).alias("c3"))

# COMMAND ----------

writecsv(spark,G6,baseurl+outputBaseDir+'allDistinctRecs/'+bc+'-M1',1,'overwrite','|')
