# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window

# COMMAND ----------

dbutils.widgets.text("tablename","")
dbutils.widgets.getArgument("tablename")
tablename= getArgument("tablename")

dbutils.widgets.text("path_conn_file", "")
dbutils.widgets.getArgument("path_conn_file")
path_conn_file= getArgument("path_conn_file")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("sqoop_output_path","")
dbutils.widgets.getArgument("sqoop_output_path")
sqoop_output_path= getArgument("sqoop_output_path")

dbutils.widgets.text("tudb","")
dbutils.widgets.getArgument("tudb")
tudb= getArgument("tudb")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("loopcount","")
dbutils.widgets.getArgument("loopcount")
loopcount= getArgument("loopcount")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user
print(baseurl)

# COMMAND ----------

tu_sqoop=spark.read.parquet(baseurl+sqoop_output_path+bc)
total_count=tu_sqoop.count()

if total_count > int(loopcount):
    w = Window().orderBy("patientacctifk1")
    tu_sqoop=tu_sqoop.withColumn("row_num", row_number().over(w))
    tu_sqoop=tu_sqoop.cache()
    step=int(loopcount)
    for i in range(1,total_count,step):
        tu_sqoop_part = tu_sqoop.filter((col('row_num')>=i) & (col('row_num')<=i+step-1))
        print(i,i+step-1)
        tu_sqoop_part=tu_sqoop_part.drop('row_num')
        tu_sqoop_part.write.format('jdbc').mode('append').option('driver', 'com.microsoft.sqlserver.jdbc.SQLServerDriver').option \
        ('url', path_conn_file).option('dbtable', tudb+tablename).save()
else:
   tu_sqoop.write.format('jdbc').mode('append').option('driver', 'com.microsoft.sqlserver.jdbc.SQLServerDriver').option \
        ('url', path_conn_file).option('dbtable', tudb+tablename).save() 
