# Databricks notebook source
## This notebook reads all unique permid relations from famc to create relations between patientaccts 
## This will cross verify against existing patientacct relations (TuSourcedFamilyMemberLink) to send only new relations to sql table
## Code can be updated in future to read only daily delta relations from famc
## TuSourcedFamilyMemberLink can have sync issues that may generate some duplicates 

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

# COMMAND ----------

# container = "prod-icd-stg-adls"
# storageaccount = "prodicdstgdls"
# user = "vishnup"
# bc = "20250908T15"

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))
spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "auto")

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

# DBTITLE 1,Setting up paths
tusourcedfamilymemberlink_path = f"{baseurl}/data/cdd/publish/tu/tusourcedfamilymemberlink/current/20991231/"
permidrelations_path = f"{baseurl}/data/leadrepo/publish/famc/permid_relations/current/"
permidpatientacctid_path = f"{baseurl}/data/cdd/publish/permidpatientacctid/*"
pa_path = f"{baseurl}/data/dataingestion/publish/patientaccts/current/20991231/"
tusourcedfamilymemberlink_transform_path = f"{baseurl}/data/cdd/transform/tusourcedfamilymemberlink/{bc}"

print("tusourcedfamilymemberlink_path -", tusourcedfamilymemberlink_path)
print("permidpatientacctid_path - ", permidpatientacctid_path)
print("permidrelations_path - ", permidrelations_path)
print("pa_path - ", pa_path)
print("tusourcedfamilymemberlink_transform_path - ", tusourcedfamilymemberlink_transform_path)

# COMMAND ----------

# DBTITLE 1,Read patientacct data and filter last 1 year data
patientaccts = spark.read.format("delta").load(pa_path)
patientaccts.createOrReplaceTempView("patientaccts")
patientaccts = spark.sql("""SELECT patientacctipk,hospitalfk FROM patientaccts WHERE createdate > CURRENT_DATE - 366""")
patientaccts.createOrReplaceTempView("patientaccts")

# COMMAND ----------

# DBTITLE 1,permidpatientacctid from cdd with dupes removal
permidpatientacctid  = spark.read.format("parquet").load(permidpatientacctid_path).filter("matchind IN ('IM', 'M1')")
permidpatientacctid = permidpatientacctid.dropDuplicates()
permidpatientacctid.createOrReplaceTempView("permidpatientacctid")
permidpatientacctid_dupes = spark.sql("""
                                        SELECT patientacctifk, hospitalfk 
                                        FROM permidpatientacctid
                                        GROUP BY patientacctifk, hospitalfk
                                        HAVING COUNT(DISTINCT permid) > 1
                                    """)
permidpatientacctid_dupes.createOrReplaceTempView("permidpatientacctid_dupes")

permidpatientacctid = spark.sql("""
                                    SELECT pp.permid, pp.patientacctifk, pp.hospitalfk, pp.matchind 
                                    FROM permidpatientacctid  pp
                                    LEFT ANTI JOIN permidpatientacctid_dupes ppd
                                        ON pp.patientacctifk = ppd.patientacctifk
                                        AND pp.hospitalfk = ppd.hospitalfk
                                """)
permidpatientacctid.createOrReplaceTempView("permidpatientacctid")

# COMMAND ----------

# DBTITLE 1,Join Patientaccts and permidpatientacctid to get associated permid for each patientacctipk
pa_permid_join = spark.sql("""
                            SELECT pa.patientacctipk, pa.hospitalfk, perm.permid,
                                ROW_NUMBER() OVER(PARTITION BY pa.patientacctipk, pa.hospitalfk ORDER BY matchind ASC) AS rn
                            FROM patientaccts AS pa
                            INNER JOIN permidpatientacctid AS perm
                                ON pa.patientacctipk = perm.patientacctifk
                                AND pa.hospitalfk = perm.hospitalfk
                           """)
pa_permid_join = pa_permid_join.filter('rn = 1').drop('rn')
pa_permid_join = pa_permid_join.drop_duplicates()
pa_permid_join.createOrReplaceTempView("pa_permid_join")

# COMMAND ----------

# DBTITLE 1,permid relations fom famc
permidrelations = spark.read.format("delta").load(permidrelations_path)
permidrelations.createOrReplaceTempView("permidrelations")

# COMMAND ----------

# DBTITLE 1,join1 on permid
join1 = spark.sql("""SELECT a.patientacctipk AS patientacctipk1,
                           a.hospitalfk AS hospitalfk1,
                           b.permid AS permid,
                           b.magnetpermid AS magnetpermid
                           FROM pa_permid_join AS a
                           INNER JOIN permidrelations AS b
                           ON a.permid = b.permid
                           """)
join1 = join1.drop_duplicates()
join1.createOrReplaceTempView("join1")

# COMMAND ----------

# DBTITLE 1,join2 on magnetpermid
join2 = spark.sql("""SELECT b.patientacctipk1,
                           b.hospitalfk1,
                           a.patientacctipk AS patientacctipk2,
                           a.hospitalfk AS hospitalfk2,
                           current_timestamp() AS createdate
                           FROM pa_permid_join AS a
                           INNER JOIN join1 AS b
                           ON a.permid = b.magnetpermid
                           """)
join2 = join2.drop_duplicates()
join2.createOrReplaceTempView("join2")

# COMMAND ----------

# DBTITLE 1,read tusourcedfamilymemberlink data
tusourcedfamilymemberlink = spark.read.format("delta").load(tusourcedfamilymemberlink_path)
tusourcedfamilymemberlink = tusourcedfamilymemberlink.withColumn("tusourcedfamilymemberlinkpk", col("tusourcedfamilymemberlinkpk").cast(LongType()))
tusourcedfamilymemberlink.createOrReplaceTempView("tusourcedfamilymemberlink")

# COMMAND ----------

# DBTITLE 1,get max of tusourcedfamilymemberlinkpk
max_tusourcedfamilymemberlinkpk = spark.sql(f"""SELECT max(tusourcedfamilymemberlinkpk) FROM tusourcedfamilymemberlink""").collect()[0][0]

# COMMAND ----------

# DBTITLE 1,lookup to filter out already sent records
lookup_tusourcedfamilymemberlink = spark.sql(f"""
                        SELECT
                            ROW_NUMBER() OVER (ORDER BY a.patientacctipk1, a.hospitalfk1, a.patientacctipk2, a.hospitalfk2) AS increasing_id,
                            a.patientacctipk1 AS patientacctifk1,
                            a.hospitalfk1,
                            a.patientacctipk2 AS patientacctifk2,
                            a.hospitalfk2,
                            a.createdate
                        FROM join2 AS a
                        LEFT JOIN tusourcedfamilymemberlink AS b
                        ON a.patientacctipk1 = b.patientacctifk1
                        AND a.hospitalfk1 = b.hospitalfk1
                        AND a.patientacctipk2 = b.patientacctifk2
                        AND a.hospitalfk2 = b.hospitalfk2
                        WHERE b.tusourcedfamilymemberlinkpk IS NULL
                    """)
lookup_tusourcedfamilymemberlink = lookup_tusourcedfamilymemberlink.drop_duplicates()
lookup_tusourcedfamilymemberlink = lookup_tusourcedfamilymemberlink.withColumn("tusourcedfamilymemberlinkpk", (col("increasing_id") + lit(max_tusourcedfamilymemberlinkpk))).drop("increasing_id")
for column in lookup_tusourcedfamilymemberlink.columns:
    lookup_tusourcedfamilymemberlink = lookup_tusourcedfamilymemberlink.withColumn(column, col(column).cast(StringType()))

# COMMAND ----------

# DBTITLE 1,write out to transform path
lookup_tusourcedfamilymemberlink.write.mode("overwrite").parquet(tusourcedfamilymemberlink_transform_path)

# COMMAND ----------

# DBTITLE 1,appending tusourcedfamilymemberlink data to cdd publish path
tusourcedfamilymemberlink_transform_df = spark.read.parquet(tusourcedfamilymemberlink_transform_path)
tusourcedfamilymemberlink_transform_df.write.mode("append").format("delta").save(tusourcedfamilymemberlink_path)
