# Databricks notebook source
# DBTITLE 1,Initialize Python Libraries
import sys
import math
from datetime import datetime
from pyspark.storagelevel import StorageLevel
from pyspark.sql.types import *
from datetime import datetime
from pyspark.sql.functions import *
import re
from collections import deque

spark.conf.set("spark.databricks.io.cache.enabled", "true")

# COMMAND ----------

# DBTITLE 1,Sample Input-QA
#RUNNING AS LOCAL USER maxc
#input_lr_transaction=abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/maxc//data/leadrepo/publish/cooked/hfc_lr_transaction/
#input_lr_xref_gmrnid_transaction=abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/maxc//data/leadrepo/publish/cooked/hfc_lr_xref_gmrnid_transaction/
#input_hfc_delta=abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/maxc//data/leadrepo/staging/input/raw/helperfoundcoverages//20231115T09
#input_bc=20231115T09
#input_hfc_toserve=abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/maxc//data/leadrepo/publish/toserve/hfc_import/20231115T09
#input_globalmrnxpacct=abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/maxc//data/gmrn/publish/globalmrnxpacct/current/*
#input_temp=abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/maxc//data/leadrepo/transform/scratch/hfc/20231115T09
#input_helperfoundcoverages=abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/maxc//data/dataingestion/publish//helperfoundcoverages/current/20991231/
#input_hospitals=abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/maxc//data/dataingestion/publish//hospitals/current/20991231/
#input_edipartners=abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/maxc//data/dataingestion/publish//edipartners/current/20991231/

# COMMAND ----------

# DBTITLE 1,Initialize the input-output parameters.
dbutils.widgets.text('input_bc','')
input_bc = dbutils.widgets.get("input_bc")

dbutils.widgets.text('input_hfc_delta','')
input_hfc_delta = dbutils.widgets.get("input_hfc_delta")

dbutils.widgets.text('input_hfc_toserve','')
input_hfc_toserve = dbutils.widgets.get("input_hfc_toserve")

dbutils.widgets.text('input_base_tables','')
input_base_tables = dbutils.widgets.get("input_base_tables")

dbutils.widgets.text('input_lr_transaction','')
input_lr_transaction = dbutils.widgets.get("input_lr_transaction")

dbutils.widgets.text('storageaccount','')
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text('container','')
container = dbutils.widgets.get("container")

dbutils.widgets.text('loadtype','')
loadtype = dbutils.widgets.get("loadtype")

dbutils.widgets.text('user','')
user = dbutils.widgets.get("user")

# COMMAND ----------

# DBTITLE 1,Initialize Access Keys
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# DBTITLE 1,Determining User Type 'na' or 'local' [na=prod_user] [local=maxc]
if user=='na':
    username=""
else :
    username=user

print("user= "+ user+" username= "+username)

# COMMAND ----------

# DBTITLE 1,Setting Fully Qualified Base Parameters
baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'

if username=='':
    print("RUNNING AS PROD USER")
    input_lr_transaction=baseurl+input_lr_transaction
    input_hfc_delta=baseurl+input_hfc_delta+"/"+input_bc
    input_hfc_toserve=baseurl+input_hfc_toserve+"/"+input_bc
    input_temp=baseurl+"/data/leadrepo/transform/scratch/hfc/"+input_bc
    input_helperfoundcoverages=baseurl+input_base_tables+"/helperfoundcoverages/current/20991231/"
    input_hospitals=baseurl+input_base_tables+"/hospitals/current/20991231/"
    input_edipartners=baseurl+input_base_tables+"/edipartners/current/20991231/"
else :
    print("RUNNING AS LOCAL USER "+username)
    input_lr_transaction=baseurl+"/"+username+"/"+input_lr_transaction
    input_hfc_delta=baseurl+"/"+username+"/"+input_hfc_delta+"/"+input_bc
    input_hfc_toserve=baseurl+"/"+username+"/"+input_hfc_toserve+"/"+input_bc
    input_temp=baseurl+"/"+username+"/"+"/data/leadrepo/transform/scratch/hfc/"+input_bc
    input_helperfoundcoverages=baseurl+"/"+username+"/"+input_base_tables+"/helperfoundcoverages/current/20991231/"
    input_hospitals=baseurl+"/"+username+"/"+input_base_tables+"/hospitals/current/20991231/"
    input_edipartners=baseurl+"/"+username+"/"+input_base_tables+"/edipartners/current/20991231/"

print("input_lr_transaction="+ input_lr_transaction)
print("input_hfc_delta="+ input_hfc_delta)
print("input_bc="+ input_bc)
print("input_hfc_toserve="+ input_hfc_toserve)
print("input_temp="+ input_temp)
print("input_helperfoundcoverages="+ input_helperfoundcoverages)
print("input_hospitals="+ input_hospitals)
print("input_edipartners="+ input_edipartners)

# COMMAND ----------

# loadtype="base"
# print("loadtype : "+loadtype)

# COMMAND ----------

# DBTITLE 1,Determining Load Type Base or Delta
if loadtype=="base":
    print("LOAD_TYPE : "+loadtype)
    df_hfc_delta=spark.read.format("delta").load(input_helperfoundcoverages).filter("EDIDataSourceFK IN ('13','14')").filter("InferredSourceMethodCode  = 'FM'")
    # df_hfc_delta=df_hfc_delta.filter(df_hfc_delta.createdate>='2023-09-26')
elif loadtype=="delta":
    print("LOAD_TYPE : "+loadtype)
    df_hfc_delta=spark.read.parquet(input_hfc_delta).filter("EDIDataSourceFK IN ('13','14')").filter("InferredSourceMethodCode  = 'FM'")
else:
    print("WRONG LOADTYE : "+loadtype)
    exit(1)

# COMMAND ----------

# print("COUNT : df_hfc_delta : "+str(df_hfc_delta.count()))

# COMMAND ----------

# DBTITLE 1,Reading Base Hospital and Edipartners Data
df_hospitals=spark.read.format("parquet").load(input_hospitals).selectExpr("hospitalpk as hospitalfk","hcsystemfk").dropDuplicates()
df_hospitals.createOrReplaceTempView("df_hospitals")

df_edipartners=spark.read.format("parquet").load(input_edipartners).filter("isenabledflag=='1'")
df_edipartners=df_edipartners.selectExpr("edipayerfk","edipartnerpk as payerid").dropDuplicates()
df_edipartners.createOrReplaceTempView("df_edipartners")

# COMMAND ----------

# DBTITLE 1,Reading HFC Input Join HOSPITAL Join EDIPARTNES to fetch demographics with hcsystem and payerid
df_hfc_delta.createOrReplaceTempView("df_hfc_delta")
df_hfc_delta=spark.sql("""
                          SELECT 
			     df_hfc_delta.helperfoundcoverageipk   AS transactionkey,
                          df_hfc_delta.patientacctifk           AS sourcepatientacctifk,
                          df_hfc_delta.coverageid,
                          df_hfc_delta.inferredsourcemethodcode AS verifiedsource,
                          df_hfc_delta.createdate,
                          df_hfc_delta.updatedate,
                          df_hfc_delta.hospitalfk               AS clientid,
                   SUBSTR(df_hfc_delta.dob,1,10)                AS dob,
                          df_hfc_delta.firstname,
                          df_hfc_delta.gender,
                          df_hfc_delta.lastname,
                          df_hfc_delta.middlename,
                          df_hfc_delta.ssn,
                          df_hfc_delta.addr,
                          df_hfc_delta.city,
                          df_hfc_delta.state,
                          df_hfc_delta.edipayerfk,
                   SUBSTR(df_hfc_delta.zip,1,5)    AS zip,
                          CURRENT_DATE()           AS lr_createdate,
                          '5'                      AS sourcekey,
                          ''                       AS responsestatus,
                          ''                       AS groupnumber,
                          df_hospitals.hcsystemfk
                          FROM df_hfc_delta 
                          INNER JOIN df_hospitals ON df_hfc_delta.hospitalfk=df_hospitals.hospitalfk
                          """).withColumn("lr_creatingmodule",lit(input_bc)).withColumn("dependentflag", lit('0')).dropDuplicates()

df_hfc_delta.createOrReplaceTempView("df_hfc_delta")

df_hfc_delta=spark.sql(""" SELECT df_hfc_delta.*,df_edipartners.payerid FROM df_hfc_delta INNER JOIN df_edipartners ON df_hfc_delta.edipayerfk=df_edipartners.edipayerfk """).dropDuplicates()

for column in df_hfc_delta.columns:
    df_hfc_delta = df_hfc_delta.withColumn(column, trim(col(column)))
    df_hfc_delta = df_hfc_delta.withColumn(column, upper(col(column)))
    df_hfc_delta = df_hfc_delta.withColumn(column, when(col(column).isNull(), '').otherwise(col(column)))
    df_hfc_delta = df_hfc_delta.withColumn(column, when(col(column) == 'null', '').otherwise(col(column)))


# COMMAND ----------

# DBTITLE 1,Append HFC data to LR_TRANSACTION
trange=int(5)
df_hfc_delta = df_hfc_delta.withColumn("transactionrange",((df_hfc_delta.transactionkey).cast("bigint") % trange).cast("bigint"))
df_hfc_delta.dropDuplicates().repartition(120).write.mode("append").partitionBy("transactionrange").parquet(input_lr_transaction)
df_hfc_delta.unpersist()

# COMMAND ----------

# DBTITLE 1,Append HFC data to SERVED
filterExpr="lr_creatingmodule=='"+input_bc+"'"
print(filterExpr)
df_hfc_delta=spark.read.parquet(input_lr_transaction).filter(filterExpr)
df_hfc_delta=df_hfc_delta.selectExpr("transactionkey","clientid as hospitalfk","sourcepatientacctifk as patientacctifk","payerid","coverageid","lr_creatingmodule as bc").dropDuplicates()
df_hfc_delta.repartition(10).write.mode("overwrite").parquet(input_hfc_toserve)
df_hfc_delta.unpersist()