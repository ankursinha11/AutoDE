# Databricks notebook source
import sys
import math
from datetime import datetime
from pyspark.storagelevel import StorageLevel
from pyspark.sql.types import *
from datetime import datetime
from pyspark.sql.functions import *
import re
from collections import deque
from delta.tables import *

# COMMAND ----------

dbutils.widgets.text('input_bc','')
input_bc = dbutils.widgets.get("input_bc")

dbutils.widgets.text('input_hfc_toserve','')
input_hfc_toserve = dbutils.widgets.get("input_hfc_toserve")

dbutils.widgets.text('input_base_tables','')
input_base_tables = dbutils.widgets.get("input_base_tables")

dbutils.widgets.text('input_lr_xref_gmrnid_transaction','')
input_lr_xref_gmrnid_transaction = dbutils.widgets.get("input_lr_xref_gmrnid_transaction")

dbutils.widgets.text('storageaccount','')
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text('container','')
container = dbutils.widgets.get("container")

dbutils.widgets.text('loadtype','')
loadtype = dbutils.widgets.get("loadtype")

dbutils.widgets.text('user','')
user = dbutils.widgets.get("user")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))
spark.sql("""SET spark.sql.shuffle.partitions=auto""")
spark.conf.set("spark.databricks.io.cache.enabled", "true")

# COMMAND ----------

if user=='na':
    username=""
else :
    username=user

print("user= "+ user+" username= "+username)

# COMMAND ----------

baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'

if username=='':
    print("RUNNING AS PROD USER")
    input_lr_xref_gmrnid_transaction=baseurl+input_lr_xref_gmrnid_transaction
    input_hfc_toserve=baseurl+input_hfc_toserve+"/"+input_bc
    input_globalmrnxpacct=baseurl+"/data/gmrn/publish/globalmrnxpacct/current/*"
    input_temp=baseurl+"/data/leadrepo/transform/scratch/hfc/"+input_bc
    input_helperfoundcoverages=baseurl+input_base_tables+"/helperfoundcoverages/current/20991231/"
    input_hospitals=baseurl+input_base_tables+"/hospitals/current/20991231/"
    input_edipartners=baseurl+input_base_tables+"/edipartners/current/20991231/"
else :
    print("RUNNING AS LOCAL USER "+username)
    input_lr_xref_gmrnid_transaction=baseurl+"/"+username+"/"+input_lr_xref_gmrnid_transaction
    input_hfc_toserve=baseurl+"/"+username+"/"+input_hfc_toserve+"/"+input_bc
    input_globalmrnxpacct=baseurl+"/"+username+"/"+"/data/gmrn/publish/globalmrnxpacct/current/*"
    input_temp=baseurl+"/"+username+"/"+"/data/leadrepo/transform/scratch/hfc/"+input_bc
    input_helperfoundcoverages=baseurl+"/"+username+"/"+input_base_tables+"/helperfoundcoverages/current/20991231/"
    input_hospitals=baseurl+"/"+username+"/"+input_base_tables+"/hospitals/current/20991231/"
    input_edipartners=baseurl+"/"+username+"/"+input_base_tables+"/edipartners/current/20991231/"

print("input_lr_xref_gmrnid_transaction="+ input_lr_xref_gmrnid_transaction)
print("input_bc="+ input_bc)
print("input_hfc_toserve="+ input_hfc_toserve)
print("input_globalmrnxpacct="+ input_globalmrnxpacct)
print("input_temp="+ input_temp)
print("input_helperfoundcoverages="+ input_helperfoundcoverages)
print("input_hospitals="+ input_hospitals)
print("input_edipartners="+ input_edipartners)

# COMMAND ----------

# DBTITLE 1,Determining Participating Hospitals 
df_hfc_delta=spark.read.parquet(input_hfc_toserve)
df_hfc_delta.createOrReplaceTempView("df_hfc_delta")
df_hfc_hospital_in_play=df_hfc_delta.selectExpr("hospitalfk").dropDuplicates()
df_hfc_hospital_in_play.createOrReplaceTempView("df_hfc_hospital_in_play")

# COMMAND ----------

# DBTITLE 1,Reading base globalmrnxpacct and deduping
df_globalmrnxpacct=spark.read.parquet(input_globalmrnxpacct).selectExpr("globalmrnifk as gmrnid","hospitalfk","patientacctifk","createdate")
df_globalmrnxpacct.createOrReplaceTempView("df_globalmrnxpacct")

df_globalmrnxpacct=spark.sql("""SELECT * FROM df_globalmrnxpacct WHERE hospitalfk IN (SELECT hospitalfk FROM df_hfc_hospital_in_play)""")
df_globalmrnxpacct.createOrReplaceTempView("df_globalmrnxpacct")

df_globalmrnxpacct=spark.sql("""SELECT patientacctifk,hospitalfk,gmrnid,ROW_NUMBER() OVER (PARTITION BY patientacctifk,hospitalfk ORDER BY createdate DESC) AS rnk FROM df_globalmrnxpacct""")
df_globalmrnxpacct=df_globalmrnxpacct.filter("rnk=='1'").drop("rnk").dropDuplicates()

df_globalmrnxpacct.repartition(250).write.mode("overwrite").parquet(input_temp+"/gmrn_dedeuped/")
df_globalmrnxpacct.unpersist()

# COMMAND ----------

# DBTITLE 1,Reading deduped globalmrnxpacct  data
df_globalmrnxpacct=spark.read.parquet(input_temp+"/gmrn_dedeuped/")
df_globalmrnxpacct.createOrReplaceTempView("df_globalmrnxpacct")

# COMMAND ----------

# DBTITLE 1,Generating GMRN_XREF data
df_gmrn_delta=spark.sql("""
        SELECT 
        df_hfc_delta.transactionkey,
       '5' AS sourcekey,
       df_hfc_delta.bc AS lr_creatingmodule,
       CURRENT_DATE()  AS lr_createdate,
       df_globalmrnxpacct.gmrnid AS gmrnid,
       df_hfc_delta.hospitalfk as hospitalfk
FROM df_hfc_delta
  INNER JOIN df_globalmrnxpacct
          ON df_hfc_delta.hospitalfk = df_globalmrnxpacct.hospitalfk
         AND df_hfc_delta.patientacctifk = df_globalmrnxpacct.patientacctifk
         """)
df_gmrn_delta.createOrReplaceTempView("df_gmrn_delta")
df_gmrn_delta=spark.sql("""
       SELECT transactionkey,
       sourcekey,
       lr_creatingmodule,
       lr_createdate,
       gmrnid,
       'gh' AS xrefsource,
       CONCAT(df_gmrn_delta.gmrnid,'~',df_gmrn_delta.lr_creatingmodule) AS audittrail,
       CONCAT(df_gmrn_delta.gmrnid,'_',df_gmrn_delta.transactionkey,'_',df_gmrn_delta.hospitalfk,'_',df_gmrn_delta.sourcekey) AS _id,
       hospitalfk
FROM df_gmrn_delta """).dropDuplicates()

# COMMAND ----------

# DBTITLE 1,Loading GMRN_XREF data to hfc_lr_xref_gmrnid_transaction table
if loadtype=="base":
    print("XREF LOAD_TYPE : "+loadtype)
    df_gmrn_delta.write.format("delta").save(input_lr_xref_gmrnid_transaction)
elif loadtype=="delta":
    print("XREF LOAD_TYPE : "+loadtype)
    df_raw = DeltaTable.forPath(spark, input_lr_xref_gmrnid_transaction)
    df_raw.alias("raw").merge(df_gmrn_delta.alias("delta"), "raw._id=delta._id").whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()
    print("NON_BASE : RECONCILE : INSERT-UPDATE : DONE")
else:
    print("XREF WRONG LOADTYE : "+loadtype)
    exit(1)

# COMMAND ----------



# COMMAND ----------


