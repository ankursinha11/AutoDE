# Databricks notebook source
# MAGIC %pip install phonetics

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.functions import *
from pyspark.sql.types import IntegerType, BooleanType
from pyspark.sql.types import StringType

# COMMAND ----------

dbutils.widgets.text("hdfs_match_output", "")
hdfs_match_output = dbutils.widgets.get("hdfs_match_output")

dbutils.widgets.text("hdfs_temp_path", "")
hdfs_temp_path = dbutils.widgets.get("hdfs_temp_path")

dbutils.widgets.text("swift_mode", "")
swift_mode = dbutils.widgets.get("swift_mode")

dbutils.widgets.text("storageaccount", "")
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text("stagedPatientacctsTableName", "")
stagedPatientacctsTableName = dbutils.widgets.get("stagedPatientacctsTableName")

dbutils.widgets.text("stagedGlobalmrndemographicsTableName", "")
stagedGlobalmrndemographicsTableName = dbutils.widgets.get("stagedGlobalmrndemographicsTableName")

# COMMAND ----------

# DBTITLE 1,SAMPLE INPUTS
# stagedPatientacctsTableName="chc_staged_patientaccts_20250410T02"
# stagedGlobalmrndemographicsTableName="chc_staged_globalmrndemographics_20250410T02"
# hdfs_match_output="abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/maxc/data/chc/staging/matches/merge/20250410T02"
# hdfs_temp_path="abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/maxc/data/chc/staging/phonetics/20250410T02/"
# swift_mode="1"
# storageaccount="prodicdstgdls"

# COMMAND ----------

g_demo = hdfs_temp_path + "/g_demo/"
p_acct = hdfs_temp_path + "/p_acct/"
g_demo_x_p_acct = hdfs_temp_path + "/g_demo_x_p_acct/"

# COMMAND ----------

# DBTITLE 1,INPUT STATS
print("stagedPatientacctsTableName          "+str(stagedPatientacctsTableName))
print("stagedGlobalmrndemographicsTableName "+str(stagedGlobalmrndemographicsTableName))
print("hdfs_match_output                    "+str(hdfs_match_output))
print("hdfs_temp_path                       "+str(hdfs_temp_path))
print("g_demo                               "+str(g_demo))
print("p_acct                               "+str(p_acct))
print("g_demo_x_p_acct                      "+str(g_demo_x_p_acct))
print("swift_mode                           "+str(swift_mode))
print("storageaccount                       "+str(storageaccount))

# COMMAND ----------

spark.conf.set("spark.databricks.io.cache.enabled", "true")
spark.conf.set("spark.sql.adaptive.skewJoin.enabled", "true")
spark.conf.set("spark.sql.shuffle.partitions", "auto")
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/tu_data_quality"

# COMMAND ----------

# MAGIC %run "/Insleads-code/GMRN/gmrn_merge/match_util"

# COMMAND ----------

if swift_mode == "1":
    print("CHC Swift Mode Enabled")
else :
    print("CHC Swift Mode Disabled")
    dbutils.notebook.exit(0)

# COMMAND ----------

selectedCols = ["globalmrnifk", "firstname", "dob", "lastname", "gender", "phone", "city", "state", "zip", "addrnum", "medicalrecnum", "ssn", "hhpermid", "fn_valid", "dob_valid", "ln_valid", "gender_valid", "phone_valid", "city_valid", "state_valid", "zip_valid", "addrnum_valid", "mrn_valid", "ssn_valid", "hhpermid_valid",]

# COMMAND ----------

# dbutils.fs.rm("abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/maxc/data/chc/staging/matches/merge/20250410T02/",True)

# COMMAND ----------

# DBTITLE 1,whole_PA
df_pa = spark.read.table(stagedPatientacctsTableName).select(selectedCols)
whole_PA = df_pa.selectExpr("globalmrnifk").dropDuplicates()
# print("COUNT DISTINCT WHOLE PA       : "+str(whole_PA.count()))

# COMMAND ----------

# DBTITLE 1,already_assigned_PA
schema = StructType(
    [
        StructField("pid", StringType()),
        StructField("cid", StringType()),
        StructField("mt", IntegerType()),
    ]
)
already_assigned = spark.read.format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", delimiter="|").schema(schema).load(hdfs_match_output + "/*")
already_assigned_PA = already_assigned.selectExpr("pid as globalmrnifk").dropDuplicates()
# print("COUNT DISTINCT ASSIGNED PA    : "+str(already_assigned_PA.count()))

# COMMAND ----------

# DBTITLE 1,unassigned_PA
unassigned_PA = whole_PA.subtract(already_assigned_PA).dropDuplicates()
# print("COUNT DISTINCT UN-ASSIGNED PA : "+str(unassigned_PA.count()))

# COMMAND ----------

# DBTITLE 1,unassigned_PA
df_pa = df_pa.join(unassigned_PA, ["globalmrnifk"], "inner").select(*df_pa.columns)
df_pa_2 = df_pa.where((df_pa.dob_valid == 1) & (df_pa.city_valid == 1) & (df_pa.state_valid == 1) & (df_pa.gender_valid == 1) & (df_pa.fn_valid == 1) & (df_pa.ln_valid == 1))
df_pa_2 = df_pa_2.withColumn("state", upper(trim(col("state")))).withColumn("city", upper(trim(col("city")))).withColumn("gender", upper(trim(col("gender"))))
df_pa_2 = df_pa_2.withColumn("firstname", upper(trim(col("firstname")))).withColumn("lastname", upper(trim(col("lastname"))))
df_pa_2 = df_pa_2.selectExpr("globalmrnifk", "firstname", "dob", "lastname", "gender", "phone", "city", "state", "zip", "medicalrecnum", "ssn").dropDuplicates()
# print("COUNT DISTINCT QUALIFIED UN-ASSIGNED PA : "+str(df_pa_2.selectExpr("globalmrnifk").dropDuplicates().count()))
df_pa_2.write.mode("overwrite").parquet(p_acct)
df_pa_2.unpersist()

# COMMAND ----------

# DBTITLE 1,GDEMO
df_gd = spark.read.table(stagedGlobalmrndemographicsTableName).select(selectedCols)
df_gd_2 = df_gd.where((df_gd.dob_valid == 1) & (df_gd.city_valid == 1) & (df_gd.state_valid == 1) & (df_gd.gender_valid == 1) & (df_gd.fn_valid == 1) & (df_gd.ln_valid == 1))
df_gd_2 = df_gd_2.withColumn("state", upper(trim(col("state")))).withColumn("city", upper(trim(col("city")))).withColumn("gender", upper(trim(col("gender"))))
df_gd_2 = df_gd_2.withColumn("firstname", upper(trim(col("firstname")))).withColumn("lastname", upper(trim(col("lastname"))))
df_gd_2 = df_gd_2.selectExpr("globalmrnifk", "firstname", "dob", "lastname", "gender", "phone", "city", "state", "zip", "medicalrecnum", "ssn").dropDuplicates()
df_gd_2.write.mode("overwrite").parquet(g_demo)
df_gd_2.unpersist()

# COMMAND ----------

# DBTITLE 1,Check if Phonetics Needed
df_pa_2 = spark.read.parquet(p_acct)
df_gd_2 = spark.read.parquet(g_demo)

if df_pa_2.count() == 0:
    print("No Phonetics Needed")
    dbutils.notebook.exit(0)
else :
    print("Phonetics Needed")

# COMMAND ----------

# DBTITLE 1,SALTING
from pyspark.sql.functions import hash
from pyspark.sql.functions import col

N = 50
left  = df_pa_2.withColumn("salt", hash("state", "city", "gender", "dob") % N)
right = df_gd_2.withColumn("salt", hash("state", "city", "gender", "dob") % N)
left  = left.repartition("salt", "state", "city", "gender", "dob")
right = right.repartition("salt", "state", "city", "gender", "dob")

# COMMAND ----------

# DBTITLE 1,JOIN
data = (
    left.alias("left_side")
    .hint("SKEW", "state")
    .hint("SKEW", "city")
    .hint("SKEW", "gender")
    .hint("SKEW", "dob")
    .join(
        right.alias("right_side"),
        (left.state == right.state)
        & (left.city == right.city)
        & (left.gender == right.gender)
        & (left.dob == right.dob)
        & (left.globalmrnifk != right.globalmrnifk),
    )
    .select(
        left.globalmrnifk.alias("left_globalmrnifk"),
        left.firstname.alias("left_firstname"),
        left.dob.alias("left_dob"),
        left.lastname.alias("left_lastname"),
        left.gender.alias("left_gender"),
        left.phone.alias("left_phone"),
        left.city.alias("left_city"),
        left.state.alias("left_state"),
        left.zip.alias("left_zip"),
        left.medicalrecnum.alias("left_medicalrecnum"),
        left.ssn.alias("left_ssn"),
        right.globalmrnifk.alias("right_globalmrnifk"),
        right.firstname.alias("right_firstname"),
        right.dob.alias("right_dob"),
        right.lastname.alias("right_lastname"),
        right.gender.alias("right_gender"),
        right.phone.alias("right_phone"),
        right.city.alias("right_city"),
        right.state.alias("right_state"),
        right.zip.alias("right_zip"),
        right.medicalrecnum.alias("right_medicalrecnum"),
        right.ssn.alias("right_ssn"),
    )
)

data.write.mode("overwrite").format("parquet").save(g_demo_x_p_acct)
print("DONE writing to g_demo_x_p_acct " + g_demo_x_p_acct)
data.unpersist()

# COMMAND ----------

# DBTITLE 1,matchExprs
whereExprs = {
    "phnxfn"    : " left_firstname <> right_firstname AND phonetic_match_udf(left_firstname,right_firstname)= '1' ",
    "phnxln"    : " left_lastname <> right_lastname   AND phonetic_match_udf(left_lastname,right_lastname) = '1' ",
    "phnfn"     : " phonetic_match_udf(left_firstname,right_firstname)= '1' ",
    "phnln"     : " phonetic_match_udf(left_lastname,right_lastname) = '1' ",
    "gender"    : " left_gender = right_gender ",
    "ssn"       : " left_ssn = right_ssn ",
    "mrn"       : " left_medicalrecnum = right_medicalrecnum ",
    "dob"       : " to_date(left_dob) = to_date(right_dob) ",
    "state"     : " left_state = right_state ",
    "zip"       : " left_zip = right_zip ",
    "lastname"  : " left_lastname = right_lastname ",
    "firstname" : " left_firstname = right_firstname ",
    "dob1"      : " abs(datediff(to_date(left_dob),to_date(right_dob))) = 1 ",
    "nofnln"    : " left_firstname <> right_firstname AND left_lastname <> right_lastname ",
    "phnxfnln"  : " phonetic_match_udf(left_firstname,right_lastname)= '1'",
    "phnxlnfn"  : " phonetic_match_udf(left_lastname,right_firstname)= '1'"
}

matchExprs = {
    "70" : " AND ".join([whereExprs.get("phnxfn"), whereExprs.get("lastname"), whereExprs.get("dob"),     whereExprs.get("gender"), whereExprs.get("state"), whereExprs.get("zip"), whereExprs.get("mrn")]),
    "71" : " AND ".join([whereExprs.get("phnxfn"), whereExprs.get("lastname"), whereExprs.get("dob"),     whereExprs.get("gender"), whereExprs.get("state"), whereExprs.get("zip")]),
    "72" : " AND ".join([whereExprs.get("phnxfn"), whereExprs.get("lastname"), whereExprs.get("dob"),     whereExprs.get("gender"), whereExprs.get("mrn")]),
    "73" : " AND ".join([whereExprs.get("phnxfn"), whereExprs.get("lastname"), whereExprs.get("dob"),     whereExprs.get("gender"), whereExprs.get("state")]),
    "74" : " AND ".join([whereExprs.get("phnxfn"), whereExprs.get("lastname"), whereExprs.get("dob"),     whereExprs.get("gender")]),
    "75" : " AND ".join([whereExprs.get("phnxfn"), whereExprs.get("phnxln"),   whereExprs.get("dob"),     whereExprs.get("gender"), whereExprs.get("state")]),
    "76" : " AND ".join([whereExprs.get("nofnln"), whereExprs.get("phnxfnln"), whereExprs.get("phnxlnfn"),whereExprs.get("dob"), whereExprs.get("gender"), whereExprs.get("state"),whereExprs.get("zip")]),
    "77" : " AND ".join([whereExprs.get("nofnln"), whereExprs.get("phnxfn"),   whereExprs.get("phnxln"),  whereExprs.get("dob"), whereExprs.get("gender"), whereExprs.get("state"),whereExprs.get("zip")]),
    "78" : " AND ".join([whereExprs.get("phnfn"),  whereExprs.get("phnln"),    whereExprs.get("dob"),     whereExprs.get("gender"), whereExprs.get("state"),whereExprs.get("zip")]),
    # DISABLED "79" : " AND ".join([whereExprs.get("phnxfn"), whereExprs.get("phnxln"), whereExprs.get("dob1"), whereExprs.get("gender"), whereExprs.get("state")]),
}

selectExprGMRNs = ['left_globalmrnifk', 'right_globalmrnifk']

debugCols = ["left_globalmrnifk","right_globalmrnifk","left_firstname","right_firstname","left_lastname","right_lastname","left_dob","right_dob","left_gender","right_gender","left_state","right_state","left_zip","right_zip","left_ssn","right_ssn","left_city","right_city"]

# COMMAND ----------

# DBTITLE 1,phonetic_match_udf
from pyspark.sql.functions import udf
from pyspark.sql.types import StringType
import phonetics

def phonetic_match(left_firstname, right_firstname):
    try:
        name1 = left_firstname
        name2 = right_firstname
        if not name1 or not name2:
            return "0"
        name1_parts = name1.split()
        name2_parts = name2.split()
        for part1 in name1_parts:
            for part2 in name2_parts:
                if phonetics.dmetaphone(part1)[0] == phonetics.dmetaphone(part2)[0]:
                    return "1"
        return "0"
    except Exception as e:
        return "0"

phonetic_match_udf = udf(phonetic_match, StringType())
spark.udf.register("phonetic_match_udf", phonetic_match_udf)  

# COMMAND ----------

phonetics=spark.read.parquet(g_demo_x_p_acct).dropDuplicates()
phonetics.createOrReplaceTempView("phonetics")

# COMMAND ----------

for matchType in matchExprs:
    matchTypeWritePath = hdfs_match_output + "/" + matchType
    matchTypeExpression = str(matchExprs[matchType])
    matchTypeExpression = "SELECT * FROM phonetics WHERE " + matchTypeExpression
    print("matchType           : "+str(matchType))
    print("matchTypeWritePath  : "+str(matchTypeWritePath))
    print("matchTypeExpression : "+str(matchTypeExpression))
    result = spark.sql(matchTypeExpression)
    #if matchType == '78' : result.selectExpr(debugCols).display()
    result = result.selectExpr(selectExprGMRNs).withColumn("matchtype", lit(matchType)).dropDuplicates()
    # resultCount = result.count()
    # print("matchTypeCount      : "+str(resultCount))
    result.write.option("header", True).mode("overwrite").format("csv").options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", delimiter="|").save(hdfs_match_output + "/" + matchType)
    print("matchType Writing Complete\n")
    result.unpersist()

# COMMAND ----------


