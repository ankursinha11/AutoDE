# Databricks notebook source
import sys
import os
import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
from pyspark import SparkContext
from pyspark.conf import SparkConf
import subprocess
from  pyspark.sql.functions import input_file_name

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window

# COMMAND ----------

dbutils.widgets.text('input_bc','')
input_bc = dbutils.widgets.get("input_bc")

dbutils.widgets.text('input_publish','')
input_publish = dbutils.widgets.get("input_publish")

dbutils.widgets.text('input_transaction','')
input_transaction = dbutils.widgets.get("input_transaction")

dbutils.widgets.text('input_serve','')
input_serve = dbutils.widgets.get("input_serve")

dbutils.widgets.text('storageaccount','')
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text('container','')
container = dbutils.widgets.get("container")

dbutils.widgets.text('user','')
user = dbutils.widgets.get("user")

# COMMAND ----------

# container="prod-icd-stg-adls"
# storageaccount="prodicdstgdls"
# input_publish="/data/chc/publish/current/20991231/"
# input_serve="/data/leadrepo/publish/toserve/chc_import/"
# input_transaction="/data/leadrepo/publish/cooked/chc_lr_transaction/"
# input_bc="20250410T02"
# user="maxc"

# COMMAND ----------

if user=='na':
    username=""
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'+"/"+username+"/"
else :
    username=user
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'+"/"+username+"/"


# print("user= "+ user+" username= "+username)
print("baseurl= "+ baseurl)

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

input_transaction=baseurl+input_transaction
input_publish=baseurl+input_publish
input_serve=baseurl+"/"+input_serve+"/"+input_bc


print("input_transaction="+ input_transaction)
print("input_publish="+ input_publish)
print("input_serve="+ input_serve)

# COMMAND ----------

# filterExpr = "bc==" + "'" + input_bc + "'"
# data = spark.read.parquet(input_publish).filter(filterExpr)
# data.createOrReplaceTempView("data")
# data=spark.sql("""
# SELECT t.*,
#        CASE
#          WHEN CAST(t.coveragestartdate AS DATE) IS NULL THEN NULL
#          ELSE CAST(t.coveragestartdate AS DATE)
#        END AS coveragestartdate_mod,
#        CASE
#          WHEN CAST(t.coverageenddate AS DATE) IS NULL THEN NULL
#          ELSE CAST(t.coverageenddate AS DATE)
#        END AS coverageenddate_mod
# FROM data t
# """)
# data.createOrReplaceTempView("data")
# data=spark.sql("""
# SELECT t.*,
# CASE 
#  WHEN CAST(t.coveragestartdate_mod AS DATE) <=CURRENT_DATE() AND CAST(t.coverageenddate_mod AS DATE) >= CURRENT_DATE() THEN 'ACTIVE'
#  WHEN CAST(t.coveragestartdate_mod AS DATE) > CURRENT_DATE() AND CAST(t.coverageenddate_mod AS DATE) >  CURRENT_DATE()  THEN 'FUTURE'
#  WHEN CAST(t.coveragestartdate_mod AS DATE) < CURRENT_DATE() AND CAST(t.coverageenddate_mod AS DATE) <  CURRENT_DATE()  THEN 'EXPIRED'
#  ELSE 'UNKNOWN' 
# END AS coveragestatus
# FROM data t
# """)
# data.createOrReplaceTempView("data")
# data.selectExpr("coveragestartdate_mod","coverageenddate_mod","coveragestatus").show(10,False)
# spark.sql(""" SELECT coveragestatus,count(*) from data GROUP BY coveragestatus """).show(10,False)

# COMMAND ----------

filterExpr = "bc==" + "'" + input_bc + "'"
data = spark.read.parquet(input_publish).filter(filterExpr)
data.createOrReplaceTempView("data")
# dep_demo_check_sql="""
# SELECT *,
#        CASE
#          WHEN (
#          dependentfirstname IS NULL AND 
#          dependentlastname IS NULL AND 
#          dependentgender IS NULL AND 
#          dependentdob IS NULL AND 
#          dependentssn IS NULL AND 
#          dependentaddress1 IS NULL
#                ) THEN '0'
#          ELSE '1'
#        END AS is_valid_dep_demo,
#        CASE
#          WHEN (
#          subfirstname IS NULL AND 
#          sublastname IS NULL AND 
#          subgender IS NULL AND 
#          subdob IS NULL AND 
#          subssn IS NULL AND 
#          subaddress1 IS NULL
#                ) THEN '0'
#          ELSE '1'
#        END AS is_valid_sub_demo
# FROM data
# """
dep_demo_check_sql ="""
SELECT *,
       CASE WHEN (dependentfirstname IS NULL AND dependentlastname IS NULL AND dependentdob IS NULL AND dependentssn IS NULL) THEN '0' ELSE '1' END AS is_valid_dep_demo,
       CASE WHEN (subfirstname       IS NULL AND sublastname       IS NULL AND subdob       IS NULL AND subssn       IS NULL) THEN '0' ELSE '1' END AS is_valid_sub_demo
FROM data
"""
data=spark.sql(dep_demo_check_sql).dropDuplicates()

data.createOrReplaceTempView("data")
p_factor = 5
dt = datetime.datetime.today().strftime('%Y-%m-%dT%H:%M:%S.%f0-05:00')
dt = str(dt)

lr_sql = """
SELECT CAST(regexp_replace((reverse (split (basefilename,'_'))[0]),".dat","") AS BIGINT) AS basefilename_ts,
       typeofcoverage,
       CAST(transactionkey_row AS BIGINT)                                    AS transactionkey_row,
       CAST(transactionkey_sub AS BIGINT)                                    AS transactionkey,
       "chc"                                                                 AS verifiedsource,
       policyidnumber                                                        AS coverageid,
       responsestatus                                                        AS responsestatus,
       groupnumber                                                           AS groupnumber,
       '3'                                                                   AS sourcekey,
       edipartnerfk                                                          AS payerid,
       hospitalfk                                                            AS hospitalfk,
       ""                                                                    AS sourcepatientacctifk,
       hospitalfk                                                            AS clientid,
       hcsystemfk                                                            AS hcsystemfk,
       subfirstname                                                          AS firstname,
       submiddleinitial                                                      AS middlename,
       sublastname                                                           AS lastname,
       subgender                                                             AS gender,
       subssn                                                                AS ssn,
       subdob                                                                AS dob,
       CONCAT(subaddress1," ",subaddress2)                                   AS addr,
       subcity                                                               AS city,
       substate                                                              AS state,
       substr(subzip,1,5)                                                    AS zip,
       '0'                                                                   AS dependentflag,
       """ + "'" + dt + "'" + """                                            AS createdate,
       """ + "'" + dt + "'" + """                                            AS updatedate,
       '0'                                                                   AS isdeletedflag,
       """ + "'" + dt + "'" + """                                            AS lr_createdate,
       bc                                                                    AS lr_creatingmodule
FROM data WHERE is_valid_sub_demo ='1'
UNION ALL
SELECT CAST(regexp_replace((reverse (split (basefilename,'_'))[0]),".dat","") AS BIGINT) AS basefilename_ts,
       typeofcoverage,
       CAST(transactionkey_row AS BIGINT)                                    AS transactionkey_row,
       CAST(transactionkey_dep AS BIGINT)                                    AS transactionkey,
       "chc"                                                                 AS verifiedsource,
       policyidnumber                                                        AS coverageid,
       responsestatus                                                        AS responsestatus,
       groupnumber                                                           AS groupnumber,
       '3'                                                                   AS sourcekey,
       edipartnerfk                                                          AS payerid,
       hospitalfk                                                            AS hospitalfk,
       ""                                                                    AS sourcepatientacctifk,
       hospitalfk                                                            AS clientid,
       hcsystemfk                                                            AS hcsystemfk,
       dependentfirstname                                                    AS firstname,
       dependentmiddleinitial                                                AS middlename,
       dependentlastname                                                     AS lastname,
       dependentgender                                                       AS gender,
       dependentssn                                                          AS ssn,
       dependentdob                                                          AS dob,
       CONCAT(dependentaddress1," ",dependentaddress2)                       AS addr,
       dependentcity                                                         AS city,
       dependentstate                                                        AS state,
       substr(dependentzip,1,5)                                              AS zip,
       '1'                                                                   AS dependentflag,
       """ + "'" + dt + "'" + """                                            AS createdate,
       """ + "'" + dt + "'" + """                                            AS updatedate,
       '0'                                                                   AS isdeletedflag,
       """ + "'" + dt + "'" + """                                            AS lr_createdate,
       bc                                                                    AS lr_creatingmodule
FROM data WHERE is_valid_dep_demo ='1'
"""

output = spark.sql(lr_sql).drop("is_valid_dep_demo").drop("is_valid_sub_demo").drop("hospitalfk").dropDuplicates()

output.createOrReplaceTempView("output")

output = spark.sql("""
                   SELECT *, RANK() OVER (PARTITION BY 
lr_creatingmodule,
coverageid,
typeofcoverage,
firstname,middlename,lastname,
gender,
ssn,
CAST(dob AS DATE),
addr,city,state,zip 
ORDER BY CAST(basefilename_ts AS BIGINT) DESC, CAST(dependentflag AS BIGINT) DESC) AS rnk FROM output""").filter("rnk=='1'").drop("rnk").drop("basefilename_ts").drop("typeofcoverage").dropDuplicates()

output = output.withColumn("transactionrange", (col("transactionkey") % p_factor).cast("integer")).dropDuplicates()
output = output.repartition(25)

output.write.partitionBy("transactionrange").mode("append").parquet(input_transaction)
output.unpersist()

filterExpr2 = "lr_creatingmodule==" + "'" + input_bc+ "'"
output = spark.read.parquet(input_transaction).filter(filterExpr2)
output = output.selectExpr("transactionkey AS transactionkey", "clientid as hospitalfk", "payerid", "coverageid", "lr_creatingmodule as bc").dropDuplicates()
output.repartition(5).write.mode('overwrite').parquet(input_serve)
output.unpersist()

# COMMAND ----------


