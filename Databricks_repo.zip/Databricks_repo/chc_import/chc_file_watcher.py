# Databricks notebook source
# Sample PROD INPUTS 
# container = "prod-icd-adls"
# storageaccount = "prodicddls"
# landing_path = "/data/chc/staging/landing/"
# output_path = "/data/chc/staging/input/"
# user = "na"
# container_chc = "prod-chc-data-adls"

from pyspark.sql.functions import col, lit, concat, when, collect_set, expr
from datetime import datetime
from pyspark.sql.functions import expr, concat, lit, col

# COMMAND ----------

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("container_chc","")
dbutils.widgets.getArgument("container_chc")
container_chc= getArgument("container_chc")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("landing_path","")
dbutils.widgets.getArgument("landing_path")
landing_path= getArgument("landing_path")

dbutils.widgets.text("output_path","")
dbutils.widgets.getArgument("output_path")
output_path= getArgument("output_path")

# COMMAND ----------

spark.conf.set(
    f"fs.azure.account.key.{storageaccount}.dfs.core.windows.net",
    dbutils.secrets.get(scope="icd-insleads-dbwscope", key="icd-adls-insleads-kvsecret")
)

if user == 'na':  # default value
    baseurl = f"abfss://{container}@{storageaccount}.dfs.core.windows.net"
    baseurl_chc = f"abfss://{container_chc}@{storageaccount}.dfs.core.windows.net"
else:
    baseurl = f"abfss://{container}@{storageaccount}.dfs.core.windows.net/{user}"
    baseurl_chc = f"abfss://{container_chc}@{storageaccount}.dfs.core.windows.net/{user}"


ret_val = 0
now_time = datetime.now()
bc = now_time.strftime('%Y%m%dT%H')

landing_path = baseurl_chc + landing_path
reject_path = baseurl_chc + "/data/chc/staging/rejects/"
output_path = baseurl + output_path + bc + '/'
chc_eid_mapping = baseurl + "/data/chc/staging/mapping/chc_eid_mapping/"
chc_hosp_mapping = baseurl + "/data/chc/staging/mapping/chc_hosp_mapping/"

if not any(f.path == reject_path for f in dbutils.fs.ls(landing_path.rstrip("/")) if f.isDir()):
    dbutils.fs.mkdirs(reject_path)

print(f"bc   : {bc}")
print(f"landing_path: {landing_path}")
print(f"reject_path: {reject_path}")
print(f"output_path: {output_path}")
print(f"chc_eid_mapping: {chc_eid_mapping}")
print(f"chc_hosp_mapping: {chc_hosp_mapping}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Fetching Valid Configation for FileWatcher

# COMMAND ----------


eid_hosp = (
    spark.read.format("parquet")
    .load(chc_hosp_mapping)
    .select(
        "eid",
        expr("lower(state)").alias("state"),
        "bpe",
        when(
            col("carrier") == "uhc", "united_healthcare"
        ).otherwise(col("carrier")).alias("carrier")
    )
)

eid_table = (
    spark.read.format("parquet")
    .load(chc_eid_mapping)
    .selectExpr(
        "eid",
        "bpe",
        "CASE WHEN carrier='uhc' THEN 'united_healthcare' ELSE carrier END AS carrier"
    )
)

eid_table = eid_table.join(eid_hosp, ["eid", "bpe", "carrier"], "inner").selectExpr("eid", "bpe", "carrier", "state")
eid_table = eid_table.withColumn("filename", concat(col("eid"), lit("_"), col("bpe"), lit("_"), col("carrier")))
eid_table = eid_table.withColumn(
    "filepattern",
    concat(
        col("eid"),
        lit("_med_carrier_"),
        col("bpe"),
        lit("_"),
        col("carrier"),
        lit("_"),
        col("state")
    )
).drop("eid", "bpe", "carrier", "state")

display(eid_table)

eid_rows = eid_table.selectExpr("replace(filename, 'united_healthcare', 'united') as filename").dropDuplicates().collect()
carrier_codes = {f"carrier_type_{str(i+1).zfill(2)}": row.filename for i, row in enumerate(eid_rows)}
print("Unique & Valid : EID : BPE : CARRIER")
for key, value in carrier_codes.items():
    print(f"{key} : {value}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Reject Check in LANDING Dir

# COMMAND ----------

eid_filepattern = eid_table.selectExpr("filepattern").dropDuplicates()
if dbutils.fs.ls(landing_path):
    landing_df = (
        spark.createDataFrame(dbutils.fs.ls(landing_path))
        .selectExpr("name")
        .dropDuplicates()
    )
else:
    print("No files landed yet")
    ret_val = 0
    dbutils.notebook.exit({"ret_val": ret_val, "bc": bc})

nonconfig_files = landing_df.join(
    eid_filepattern, expr("name LIKE filepattern || '%'"), "left_anti"
)

if nonconfig_files.count() > 0:
    print("Invalid or unconfigured Carrier file found:")
    nonconfig_files = nonconfig_files.selectExpr("name").dropDuplicates()
    for row in nonconfig_files.collect():
        print("Moving file :" + row.name + " to reject directory : " + reject_path)
        dbutils.fs.mv(landing_path + row.name, reject_path + row.name, True)
else:
    print("No reject files found")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Valid Check in LANDING Dir

# COMMAND ----------

files = dbutils.fs.ls(landing_path)
stats = {key: 0 for key in carrier_codes}

for file in files:
    if "dat" in file.name:
        # print(f"Valid or Configured Carrier file found: {file.name}")
        parts = file.name.split("_")
        if len(parts) >= 5:
            carrier_code = parts[0]
            carrier_bpe = parts[3]
            carrier_partner = parts[4]
            carrier_type = f"{carrier_code}_{carrier_bpe}_{carrier_partner}"
            for key, value in carrier_codes.items():
                if carrier_type == value:
                    stats[key] += 1
    else:
        print(f"No Valid or Configured Carrier files found: {file.name}")
        ret_val = 0

print("Listing all Valid or Configured carrier types and count in landing directory:")

for key, count in stats.items():
    print(f"{key} : {carrier_codes[key]:<30} : {count}")

# COMMAND ----------

max_file_type = max(stats, key=stats.get)
max_file_type_count = stats[max_file_type]
print(f"max_file_type : {max_file_type}   file count : {max_file_type_count}")

if "tufts" in carrier_codes[max_file_type].lower():
    if max_file_type_count < 10:
        print(f"file type is tufts expecting atleast 10 small files but found {max_file_type_count} file(s) ")
        stats.pop(max_file_type)
        print("checking for next available carrier types")
        if stats:
            max_file_type = max(stats, key=stats.get)
            max_file_type_count = stats.get(max_file_type)
            print(f"max_file_type       : {max_file_type}")
            print(f"max_file_type_count : {max_file_type_count}")
        else:
            print("No other carrier types available.")
    else:
        print(f"file type is tufts count : {max_file_type_count}")
else:
    print("non tufts file type")

# COMMAND ----------

if max_file_type_count > 0:
    print("valid EID found")
    filepattern = carrier_codes[max_file_type]
    filecode = filepattern.split("_")[0]
    filebpe = filepattern.split("_")[1]
    filecarrier = filepattern.split("_")[2]
    pattern = f"{filecode}_med_carrier_{filebpe}_{filecarrier}"
    print("pattern : " + str(pattern))
    files = dbutils.fs.ls(landing_path)
    for file in files:
        print(file.name)
        if pattern in file.name:
            #print("FILENAME PATTERN : " + pattern + " : " + file.name)
            #print("SOURCE : " + file.path)
            #print("TARGET : " + output_path + file.name)
            print("dbutils.fs.mv('" + file.path + "', '" + output_path + file.name + "')")
            dbutils.fs.mv(file.path, output_path + file.name)
else:
    print("NO VALID CARRIER FOUND TO BE INGESTED Exiting with ret_val 0")
    ret_val = 0
    dbutils.notebook.exit({"ret_val": ret_val, "bc": bc})

# COMMAND ----------

ret_val = 1
dbutils.notebook.exit({"ret_val": ret_val, "bc": bc})
