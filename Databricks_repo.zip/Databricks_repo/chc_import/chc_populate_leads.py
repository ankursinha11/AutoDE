# Databricks notebook source
import os
import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
from pyspark import SparkContext
from pyspark.conf import SparkConf
import subprocess
from  pyspark.sql.functions import input_file_name
from pyspark.sql.window import Window
from pyspark.sql.functions import row_number

# COMMAND ----------

dbutils.widgets.text('path_chc_to_serve','')
path_chc_to_serve = dbutils.widgets.get("path_chc_to_serve")

dbutils.widgets.text('path_chc_lr_transaction','')
path_chc_lr_transaction = dbutils.widgets.get("path_chc_lr_transaction")

dbutils.widgets.text('path_chc_scratch','')
path_chc_scratch = dbutils.widgets.get("path_chc_scratch")

dbutils.widgets.text('path_chc_json_demographics','')
path_chc_json_demographics = dbutils.widgets.get("path_chc_json_demographics")


dbutils.widgets.text('path_basetables','')
path_basetables = dbutils.widgets.get("path_basetables")



dbutils.widgets.text('chc_bc','')
chc_bc = dbutils.widgets.get("chc_bc")



dbutils.widgets.text('storageaccount','')
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text('container','')
container = dbutils.widgets.get("container")


dbutils.widgets.text('user','')
user = dbutils.widgets.get("user")

# COMMAND ----------

if user=='na':
    username=""
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'+"/"+username+"/"
else :
    username=user
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'+"/"+username+"/"


print("user= "+ user+" username= "+username)
print("baseurl= "+ baseurl)

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

path_basetables=baseurl+path_basetables
path_chc_lr_transaction=baseurl+path_chc_lr_transaction
path_chc_scratch=baseurl+path_chc_scratch+"/"+chc_bc
path_chc_to_serve=baseurl+path_chc_to_serve+"/"+chc_bc
path_chc_json_demographics=baseurl+path_chc_json_demographics+"/chc/"+chc_bc
path_edipayers_tupayeridmapping=path_basetables+"/edipayers_tupayeridmapping/current/20991231/"
path_edipartners=path_basetables+"/edipartners/current/20991231/"

# print("path_basetables="+ path_basetables)
# print("path_chc_lr_transaction="+ path_chc_lr_transaction)
# print("path_chc_scratch="+ path_chc_scratch)
# print("path_chc_to_serve="+ path_chc_to_serve)
# print("path_chc_json_demographics="+ path_chc_json_demographics)
# print("path_edipayers_tupayeridmapping="+ path_edipayers_tupayeridmapping)
# print("path_edipartners="+ path_edipartners)

# COMMAND ----------

p_factor = 5

data_to_serve = spark.read.parquet(path_chc_to_serve).select("transactionkey").withColumn("transactionrange", (col("transactionkey").cast("bigint") % p_factor).cast("bigint")).dropDuplicates()

filterExpr = "lr_creatingmodule==" + "'" + chc_bc + "'"

data_transaction = spark.read.parquet(path_chc_lr_transaction).filter(filterExpr)

data_to_serve.createOrReplaceTempView("data_to_serve")
data_transaction.createOrReplaceTempView("data_transaction")

joinsql = """
             SELECT data_transaction.transactionkey,
                    data_transaction.verifiedsource as leadsource,
                    data_transaction.coverageid,
                    data_transaction.sourcekey,
                    data_transaction.payerid,
                    data_transaction.clientid             AS hospitalfk,
                    data_transaction.sourcepatientacctifk AS patientacctipk,
                    data_transaction.clientid,
                    data_transaction.hcsystemfk,
                    data_transaction.firstname,
                    data_transaction.middlename,
                    data_transaction.lastname,
                    data_transaction.gender,
                    data_transaction.ssn,
                    data_transaction.dob,
                    data_transaction.addr,
                    data_transaction.city,
                    data_transaction.state,
                    data_transaction.zip,
                    data_transaction.dependentflag,
                    data_transaction.createdate,
                    data_transaction.updatedate,
                    data_transaction.isdeletedflag,
                    data_transaction.lr_createdate,
                    data_transaction.lr_creatingmodule
             FROM data_transaction
               INNER JOIN data_to_serve
                       ON data_transaction.transactionrange = data_to_serve.transactionrange
                      AND data_transaction.transactionkey = data_to_serve.transactionkey
"""
data_transaction = spark.sql(joinsql).withColumn("bc", lit(chc_bc)).dropDuplicates()
data_transaction.repartition(150).write.mode("overwrite").parquet(path_chc_scratch + "/chc_joinedf/")
data_transaction.unpersist()

# COMMAND ----------

data_transaction = spark.read.parquet(path_chc_scratch + "/chc_joinedf/")
data_transaction.createOrReplaceTempView("JOINED")
sparkSql01 = """
            SELECT A.*,
                   CONCAT(A.payerid,"_",A.coverageid) AS leadid,
                   CASE
                     WHEN (A.firstname IS NULL AND A.lastname IS NULL AND A.dob IS NULL AND A.ssn IS NULL AND A.gender IS NULL) THEN '0'
                     ELSE '1'
                   END AS isdemovalid,
                   CASE WHEN LENGTH(TRIM(A.dob)) > 9
                        THEN CAST(
                           concat(
                                  date_format(A.dob,'yyyy'),"-",
                                  date_format(A.dob,'MM'),"-",
                                  date_format(A.dob,'dd')
                                  ) AS STRING)
                        ELSE
                            CAST(
                                  concat(
                                         SUBSTR(A.dob,1,4),"-",
                                         SUBSTR(A.dob,5,2),"-",
                                         SUBSTR(A.dob,7,2)
                                         ) AS STRING)
                        END AS formated_dob,
                   CAST(regexp_replace (regexp_replace (regexp_replace (regexp_replace ((SPLIT (A.createdate,"\\\.")[0]),"T",""),":",""),"-","")," ","") AS BIGINT) AS createdate_as_bigint,
                   CAST(regexp_replace (regexp_replace (regexp_replace (regexp_replace ((SPLIT (A.updatedate,"\\\.")[0]),"T",""),":",""),"-","")," ","") AS BIGINT) AS updatedate_as_bigint
            FROM JOINED A
"""
data_transaction = spark.sql(sparkSql01).filter("isdemovalid = 1").dropDuplicates()
data_transaction.repartition(150).write.mode("overwrite").parquet(path_chc_scratch + "/chc_joinedf_stage2_temp/")
data_transaction.unpersist()

# COMMAND ----------

data_transaction = spark.read.parquet(path_chc_scratch + "/chc_joinedf_stage2_temp/")

data_transaction.createOrReplaceTempView("CLEANSED")
sparkSql02 = """
                SELECT A.transactionkey,
                       A.leadid,
                       A.coverageid,
                       A.payerid,
                       A.dependentflag,
                       A.firstname,
                       A.middlename,
                       A.lastname,
                       A.formated_dob   AS dob,
                       A.ssn,
                       A.gender,
                       CASE WHEN (A.state IS NULL OR TRIM(A.state) ='') THEN 'XX' ELSE A.state END AS state,
                       A.clientid,
                       A.hospitalfk,
                       A.hcsystemfk,
                       A.bc,
                       A.patientacctipk,
                       A.leadsource,
                       A.createdate_as_bigint,
                       A.updatedate_as_bigint,
                       CASE
                         WHEN LENGTH(A.createdate_as_bigint) >= 14 THEN '1'
                         ELSE '0'
                       END AS isDateValid,
                       CAST(CONCAT (SUBSTR (A.createdate_as_bigint,1,4),"-",SUBSTR (A.createdate_as_bigint,5,2),"-",SUBSTR (A.createdate_as_bigint,7,2)," ",SUBSTR (A.createdate_as_bigint,9,2),":",SUBSTR (A.createdate_as_bigint,11,2),":",SUBSTR (A.createdate_as_bigint,13,2)) AS STRING) AS createdate,
                       CAST(CONCAT (SUBSTR (A.updatedate_as_bigint,1,4),"-",SUBSTR (A.updatedate_as_bigint,5,2),"-",SUBSTR (A.updatedate_as_bigint,7,2)," ",SUBSTR (A.updatedate_as_bigint,9,2),":",SUBSTR (A.updatedate_as_bigint,11,2),":",SUBSTR (A.updatedate_as_bigint,13,2)) AS STRING) AS updatedate,
                       A.isdemovalid
                FROM CLEANSED A
"""
data_transaction = spark.sql(sparkSql02).filter("isDateValid = 1").drop("isDateValid").filter("coverageid != ''").filter("payerid != ''").dropDuplicates()
data_transaction.createOrReplaceTempView("data_transaction")

tupayer_data = spark.read.format("parquet").load(path_edipayers_tupayeridmapping).select("tupayerid", "edipayerfk").dropDuplicates()
edipartner_data = spark.read.format("parquet").load(path_edipartners).filter("isenabledflag=='1'").filter("edipartnerpk > 0").select("edipayerfk", "edipartnerpk").dropDuplicates()
tupayer_data = tupayer_data.join(edipartner_data, 'edipayerfk').selectExpr("CAST(tupayerid AS int) AS tupayerid", "edipartnerpk AS edipartnerfk")
cond1 = when(col("tupayerid") == 10102, lit(30)).otherwise(col("edipartnerfk"))
cond2 = when(col("tupayerid") == 10001, lit(82)).otherwise(col("edipartnerfk"))
cond3 = when(col("tupayerid") == 10055, lit(8)).otherwise(col("edipartnerfk"))
cond4 = when(col("tupayerid") == 10285, lit(71)).otherwise(col("edipartnerfk"))
cond5 = when(col("tupayerid") == 11174, lit(479)).otherwise(col("edipartnerfk"))
cond6 = when(col("tupayerid") == 11196, lit(547)).otherwise(col("edipartnerfk"))
tupayer_data = tupayer_data.withColumn("edipartnerfk", cond1)
tupayer_data = tupayer_data.withColumn("edipartnerfk", cond2)
tupayer_data = tupayer_data.withColumn("edipartnerfk", cond3)
tupayer_data = tupayer_data.withColumn("edipartnerfk", cond4)
tupayer_data = tupayer_data.withColumn("edipartnerfk", cond5)
tupayer_data = tupayer_data.withColumn("edipartnerfk", cond6).dropDuplicates()
tupayer_data = tupayer_data.selectExpr("edipartnerfk").dropDuplicates()
tupayer_data.createOrReplaceTempView("tupayer_data")

data_transaction = spark.sql("""select * from data_transaction where payerid in (select distinct edipartnerfk from tupayer_data)""")

for column in data_transaction.columns:
    data_transaction = data_transaction.withColumn(column, trim(col(column)))
    data_transaction = data_transaction.withColumn(column, when(col(column) == '', '').otherwise(col(column)))
    data_transaction = data_transaction.withColumn(column, when(col(column) == 'XX', '').otherwise(col(column)))
    data_transaction = data_transaction.withColumn(column, when(col(column).isNull(), '').otherwise(col(column)))

data_transaction.createOrReplaceTempView("data_transaction")

sql_demog = """
SELECT transactionkey,
       leadid,
       isdemovalid,
       dependentflag,
       createdate_as_bigint,
       hcsystemfk,
       hospitalfk,
       'chc' as source,
       leadsource,
       bc,
       STRUCT(firstname,state,middlename,lastname,dob,ssn,gender,dependentflag,createdate,CASE WHEN updatedate IS NULL THEN createdate ELSE updatedate END AS updatedate,hospitalfk,hcsystemfk,bc,'chc' as source,leadsource) AS demographics
FROM data_transaction
"""

final = spark.sql(sql_demog).dropDuplicates()

final.repartition(150).write.mode("overwrite").parquet(path_chc_json_demographics)
final.unpersist()