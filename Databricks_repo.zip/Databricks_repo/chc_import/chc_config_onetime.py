# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window

# COMMAND ----------

user = "divya"

if user == "na":
    print("PROD USER : ")
    container = "prod-icd-adls"
    storageaccount = "prodicddls"
    input_mapping = "/data/chc/staging/mapping/"
    container_str = str(container)
    storageaccount_str = str(storageaccount)
    baseurl = (f"abfss://{container_str}@{storageaccount_str}.dfs.core.windows.net/")
else:
    print("DEV or STG USER : " + str(user))
    container = "prod-icd-stg-adls"
    storageaccount = "prodicdstgdls"
    input_mapping = "/data/chc/staging/mapping/"
    container_str = str(container)
    storageaccount_str = str(storageaccount)
    baseurl = (f"abfss://{container_str}@{storageaccount_str}.dfs.core.windows.net/{user}/")

print("baseurl: "+baseurl)
print("container: "+container)
print("storageaccount: "+storageaccount)
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

chc_eid_mapping  = baseurl+"/data/chc/staging/mapping/chc_eid_mapping/"
chc_hosp_mapping = baseurl+"/data/chc/staging/mapping/chc_hosp_mapping/"

print("chc_eid_mapping  : "+chc_eid_mapping)
print("chc_hosp_mapping : "+chc_hosp_mapping)

# COMMAND ----------

# DBTITLE 1,eid_data
eid_data = [
    ("193262","bcbs","101","accenture","chc","chc_193262_bdf"),
    ("540532","bcbs","101","accenture","chc","chc_540532_bdf"),
    ("544960","deltadental","764","accenture","chc","chc_544960_bdf"),
    ("546114","allways","461","accenture","chc","chc_546114_bdf"),
    ("372100", "humana", "68", "accenture", "chc", "chc_372100_bdf"),
    ("468596", "cigna", "67", "accenture", "chc", "chc_468596_bdf"),
    ("095430", "aetna", "65", "accenture", "chc", "chc_095430_bdf"),
    ("447697", "uhc", "80", "accenture", "chc", "chc_447697_bdf"),
    ("093634", "harvardpilgrim", "290", "accenture", "chc", "chc_093634_bdf"),
    ("277596", "tufts", "308", "accenture", "chc", "chc_277596_bdf"),
    ("372100", "humana", "68", "centene", "chc", "chc_372100_bdf"),
    ("468596", "cigna", "67", "centene", "chc", "chc_468596_bdf"),
    ("095430", "aetna", "65", "centene", "chc", "chc_095430_bdf"),
    ("447697", "uhc", "80", "centene", "chc", "chc_447697_bdf"),
    ("093634", "harvardpilgrim", "290", "centene", "chc", "chc_093634_bdf"),
    ("277596", "tufts", "308", "centene", "chc", "chc_277596_bdf"),
    ("193177", "ameritas", "704", "accenture", "chc", "chc_193177_bdf"),
    ("223059", "healthpartners", "251", "centene", "chc", "chc_223059_bdf"),
]
eid_columns = ["eid", "carrier", "edipartnerfk", "bpe", "channel", "chc_bdf_folder"]
eid_mapping = spark.createDataFrame(eid_data).toDF(*eid_columns).dropDuplicates()
# eid_mapping.display()
eid_mapping.repartition(1).write.mode("overwrite").format("parquet").save(chc_eid_mapping)
# eid_mapping.unpersist()

# COMMAND ----------

hospitals = (
    spark.read.format("parquet")
    .load(baseurl + "/data/dataingestion/publish/hospitals/current/20991231/")
    .selectExpr("hospitalpk", "hospitalpk as hospitalfk", "hcsystemfk")
    .dropDuplicates()
)
hospitals.createOrReplaceTempView("hospitals")

hosp_data = [
    ("193262", "MA", "5020", "accenture", "bcbs"),
    ("540532", "TX", "4892", "accenture", "bcbs"),
    ("193177", "TX", "4892", "accenture", "ameritas"),
    ("544960", "MA", "5020", "accenture", "deltadental"),
    ("546114", "MA", "5020", "accenture", "allways"),
    ("372100", "TX", "4892", "accenture", "humana"),
    ("372100", "MA", "5020", "accenture", "humana"),
    ("468596", "TX", "4892", "accenture", "cigna"),
    ("468596", "MA", "5020", "accenture", "cigna"),
    ("095430", "TX", "4892", "accenture", "aetna"),
    ("095430", "MA", "5020", "accenture", "aetna"),
    ("447697", "TX", "4892", "accenture", "uhc"),
    ("447697", "MA", "5020", "accenture", "uhc"),
    ("093634", "TX", "4892", "accenture", "harvardpilgrim"),
    ("093634", "MA", "5020", "accenture", "harvardpilgrim"),
    ("277596", "TX", "4892", "accenture", "tufts"),
    ("277596", "MA", "5020", "accenture", "tufts"),
    ("095430", "MA", "5020", "centene", "aetna"),
    ("095430", "MO", "5197", "centene", "aetna"),
    ("095430", "IA", "5196", "centene", "aetna"),
    ("095430", "OH", "5287", "centene", "aetna"),
    ("095430", "IL", "5406", "centene", "aetna"),
    ("095430", "MI", "5407", "centene", "aetna"),
    ("095430", "NH", "5408", "centene", "aetna"),
    ("095430", "PA", "5409", "centene", "aetna"),
    ("095430", "WI", "5410", "centene", "aetna"),
    ("095430", "GA", "5488", "centene", "aetna"),
    ("095430", "SC", "5489", "centene", "aetna"),
    ("095430", "OK", "5490", "centene", "aetna"),
    ("095430", "TX", "5491", "centene", "aetna"),
    ("095430", "LA", "5512", "centene", "aetna"),
    ("095430", "MS", "5513", "centene", "aetna"),
    ("095430", "OR", "5515", "centene", "aetna"),
    ("095430", "WA", "5516", "centene", "aetna"),
    ("095430", "AZ", "5517", "centene", "aetna"),
    ("095430", "IN", "5546", "centene", "aetna"),
    ("095430", "NE", "5547", "centene", "aetna"),
    ("095430", "NV", "5548", "centene", "aetna"),
    ("095430", "DE", "5549", "centene", "aetna"),
    ("095430", "FL", "5528", "centene", "aetna"),
    ("095430", "NC", "5569", "centene", "aetna"),
    ("095430", "AR", "5570", "centene", "aetna"),
    ("095430", "KS", "5571", "centene", "aetna"),
    ("468596", "MA", "5020", "centene", "cigna"),
    ("468596", "MO", "5197", "centene", "cigna"),
    ("468596", "IA", "5196", "centene", "cigna"),
    ("468596", "OH", "5287", "centene", "cigna"),
    ("468596", "IL", "5406", "centene", "cigna"),
    ("468596", "MI", "5407", "centene", "cigna"),
    ("468596", "NH", "5408", "centene", "cigna"),
    ("468596", "PA", "5409", "centene", "cigna"),
    ("468596", "WI", "5410", "centene", "cigna"),
    ("468596", "GA", "5488", "centene", "cigna"),
    ("468596", "SC", "5489", "centene", "cigna"),
    ("468596", "OK", "5490", "centene", "cigna"),
    ("468596", "TX", "5491", "centene", "cigna"),
    ("468596", "LA", "5512", "centene", "cigna"),
    ("468596", "MS", "5513", "centene", "cigna"),
    ("468596", "OR", "5515", "centene", "cigna"),
    ("468596", "WA", "5516", "centene", "cigna"),
    ("468596", "AZ", "5517", "centene", "cigna"),
    ("468596", "IN", "5546", "centene", "cigna"),
    ("468596", "NE", "5547", "centene", "cigna"),
    ("468596", "NV", "5548", "centene", "cigna"),
    ("468596", "DE", "5549", "centene", "cigna"),
    ("468596", "FL", "5528", "centene", "cigna"),
    ("468596", "NC", "5569", "centene", "cigna"),
    ("468596", "AR", "5570", "centene", "cigna"),
    ("468596", "KS", "5571", "centene", "cigna"),
    ("372100", "AR", "5570", "centene", "humana"),
    ("372100", "AZ", "5517", "centene", "humana"),
    ("372100", "DE", "5549", "centene", "humana"),
    ("372100", "FL", "5528", "centene", "humana"),
    ("372100", "GA", "5488", "centene", "humana"),
    ("372100", "IL", "5406", "centene", "humana"),
    ("372100", "IN", "5546", "centene", "humana"),
    ("372100", "IA", "5196", "centene", "humana"),
    ("372100", "KS", "5571", "centene", "humana"),
    ("372100", "LA", "5512", "centene", "humana"),
    ("372100", "MI", "5407", "centene", "humana"),
    ("372100", "MS", "5513", "centene", "humana"),
    ("372100", "MO", "5197", "centene", "humana"),
    ("372100", "NE", "5547", "centene", "humana"),
    ("372100", "NV", "5548", "centene", "humana"),
    ("372100", "NH", "5408", "centene", "humana"),
    ("372100", "NC", "5569", "centene", "humana"),
    ("372100", "OH", "5287", "centene", "humana"),
    ("372100", "OK", "5490", "centene", "humana"),
    ("372100", "OR", "5515", "centene", "humana"),
    ("372100", "PA", "5409", "centene", "humana"),
    ("372100", "SC", "5489", "centene", "humana"),
    ("372100", "TX", "5491", "centene", "humana"),
    ("372100", "WA", "5516", "centene", "humana"),
    ("372100", "WI", "5410", "centene", "humana"),
    ("223059", "AZ", "5517", "centene", "healthpartners"),
    ("223059", "AR", "5570", "centene", "healthpartners"),
    ("223059", "DE", "5549", "centene", "healthpartners"),
    ("223059", "FL", "5528", "centene", "healthpartners"),
    ("223059", "GA", "5488", "centene", "healthpartners"),
    ("223059", "IL", "5406", "centene", "healthpartners"),
    ("223059", "IN", "5546", "centene", "healthpartners"),
    ("223059", "IA", "5196", "centene", "healthpartners"),
    ("223059", "KS", "5571", "centene", "healthpartners"),
    ("223059", "LA", "5512", "centene", "healthpartners"),
    ("223059", "MI", "5407", "centene", "healthpartners"),
    ("223059", "MS", "5513", "centene", "healthpartners"),
    ("223059", "MO", "5197", "centene", "healthpartners"),
    ("223059", "NE", "5547", "centene", "healthpartners"),
    ("223059", "NV", "5548", "centene", "healthpartners"),
    ("223059", "NH", "5408", "centene", "healthpartners"),
    ("223059", "NC", "5569", "centene", "healthpartners"),
    ("223059", "OH", "5287", "centene", "healthpartners"),
    ("223059", "OK", "5490", "centene", "healthpartners"),
    ("223059", "OR", "5515", "centene", "healthpartners"),
    ("223059", "PA", "5409", "centene", "healthpartners"),
    ("223059", "SC", "5489", "centene", "healthpartners"),
    ("223059", "TX", "5491", "centene", "healthpartners"),
    ("223059", "WA", "5516", "centene", "healthpartners"),
    ("223059", "WI", "5410", "centene", "healthpartners"),
    ("447697", "AZ", "5517", "centene", "uhc"),
    ("447697", "AR", "5570", "centene", "uhc"),
    ("447697", "DE", "5549", "centene", "uhc"),
    ("447697", "FL", "5528", "centene", "uhc"),
    ("447697", "GA", "5488", "centene", "uhc"),
    ("447697", "IL", "5406", "centene", "uhc"),
    ("447697", "IN", "5546", "centene", "uhc"),
    ("447697", "IA", "5196", "centene", "uhc"),
    ("447697", "KS", "5571", "centene", "uhc"),
    ("447697", "LA", "5512", "centene", "uhc"),
    ("447697", "MI", "5407", "centene", "uhc"),
    ("447697", "MS", "5513", "centene", "uhc"),
    ("447697", "MO", "5197", "centene", "uhc"),
    ("447697", "NE", "5547", "centene", "uhc"),
    ("447697", "NV", "5548", "centene", "uhc"),
    ("447697", "NH", "5408", "centene", "uhc"),
    ("447697", "NC", "5569", "centene", "uhc"),
    ("447697", "OH", "5287", "centene", "uhc"),
    ("447697", "OK", "5490", "centene", "uhc"),
    ("447697", "OR", "5515", "centene", "uhc"),
    ("447697", "PA", "5409", "centene", "uhc"),
    ("447697", "SC", "5489", "centene", "uhc"),
    ("447697", "TX", "5491", "centene", "uhc"),
    ("447697", "WA", "5516", "centene", "uhc"),
    ("447697", "WI", "5410", "centene", "uhc")
]

hosp_columns = ["eid", "state", "hospitalfk", "bpe", "carrier"]
hosp_mapping = spark.createDataFrame(hosp_data).toDF(*hosp_columns).dropDuplicates()
hosp_mapping.createOrReplaceTempView("hosp_mapping")
hosp_mapping = spark.sql("""SELECT hosp_mapping.*,hospitals.hcsystemfk FROM hosp_mapping INNER JOIN hospitals ON hosp_mapping.hospitalfk = hospitals.hospitalfk""").dropDuplicates()
# hosp_mapping.display()
hosp_mapping.repartition(1).write.mode("overwrite").format("parquet").save(chc_hosp_mapping)
# hosp_mapping.unpersist()

# COMMAND ----------


