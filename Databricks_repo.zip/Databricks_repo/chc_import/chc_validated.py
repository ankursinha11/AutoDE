# Databricks notebook source
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import *
import datetime
from pyspark.sql.functions import substring,coalesce
from pyspark.sql.window import Window
from delta import *

# COMMAND ----------

# bcdata="20250410T02"
# container="prod-icd-stg-adls"
# storageaccount="prodicdstgdls"
# chc_accenture_aetna_path_publish="/data/chc/publish/current/20991231/"
# chc_accenture_aetna_path_transaction="/data/leadrepo/publish/cooked/chc_lr_transaction/"
# chc_accenture_aetna_path_temp="/data/chc/staging/temp/chc_validated/"
# user="maxc"
# hdfs_output="/data/chc/staging/staged_all/staged_patientaccts/20250410T02/"
# hdfs_permid_input="/data/chc/publish/idxpermid/medical_carrier/20250410T02/"

# COMMAND ----------

dbutils.widgets.text("bcdata","")
bcdata= dbutils.widgets.get("bcdata")

dbutils.widgets.text("hdfs_permid_input", "")
hdfs_permid_input= dbutils.widgets.get("hdfs_permid_input")

dbutils.widgets.text("hdfs_output", "")
hdfs_output= dbutils.widgets.get("hdfs_output")

dbutils.widgets.text("chc_accenture_aetna_path_publish", "")
chc_accenture_aetna_path_publish= dbutils.widgets.get("chc_accenture_aetna_path_publish")

dbutils.widgets.text("chc_accenture_aetna_path_transaction", "")
chc_accenture_aetna_path_transaction= dbutils.widgets.get("chc_accenture_aetna_path_transaction")

dbutils.widgets.text("chc_accenture_aetna_path_temp", "")
chc_accenture_aetna_path_temp= dbutils.widgets.get("chc_accenture_aetna_path_temp")

dbutils.widgets.text("storageaccount","")
storageaccount=dbutils.widgets.get("storageaccount")

dbutils.widgets.text('container','')
container = dbutils.widgets.get("container")

dbutils.widgets.text('user','')
user = dbutils.widgets.get("user")

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

chc_accenture_aetna_path_publish = baseurl+ chc_accenture_aetna_path_publish
chc_accenture_aetna_path_transaction = baseurl+ chc_accenture_aetna_path_transaction
chc_accenture_aetna_path_temp = baseurl+ chc_accenture_aetna_path_temp
hdfs_output = baseurl+ hdfs_output
hdfs_permid_input = baseurl+ hdfs_permid_input

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/tu_data_quality"

# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions","auto")
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

path_temp = chc_accenture_aetna_path_temp + "/chc_validated/"
path_temp_01 = path_temp + "/01/"
path_temp_02 = path_temp + "/02/"
path_temp_03 = path_temp + "/03/"
path_temp_04 = path_temp + "/04/"

chc_bc = bcdata
filterExpr01 = "lr_creatingmodule=='" + chc_bc + "'"
filterExpr02 = "bc=='" + chc_bc + "'"

# COMMAND ----------

df_transaction = spark.read.parquet(chc_accenture_aetna_path_transaction).filter(filterExpr01).selectExpr("transactionkey","firstname","lastname","gender","addr","ssn","dob","city","state","zip","coverageid","dependentflag","lr_creatingmodule").dropDuplicates()
df_transaction.createOrReplaceTempView("df_transaction")

# COMMAND ----------

df_publish = spark.read.parquet(chc_accenture_aetna_path_publish).filter(filterExpr02).selectExpr("transactionkey_row", "bc", "uniq_sub_hash256_pefld","uniq_dep_hash256_pefld").dropDuplicates()
df_publish.createOrReplaceTempView("df_publish")

# COMMAND ----------

sql_trans_x_publish_sub = """
SELECT p.uniq_sub_hash256_pefld AS patientacctifk,
       d.firstname,
       d.lastname,
       d.gender,
       d.ssn,
       d.dob,
       d.addr       AS addr1,
       d.city,
       d.state,
       d.zip,
       d.coverageid AS policyid,
       ''           AS phone,
       d.dependentflag
FROM (SELECT * FROM df_transaction WHERE dependentflag = '0') d
  LEFT JOIN df_publish p
        ON  TRIM (d.lr_creatingmodule) = TRIM (p.bc)
        AND CAST (d.transactionkey AS BIGINT) = CAST(CONCAT(p.transactionkey_row,'0') AS BIGINT)
"""
data = spark.sql(sql_trans_x_publish_sub).dropDuplicates()
data.write.mode('overwrite').parquet(path_temp_01)

# COMMAND ----------

sql_trans_x_publish_dep = """
SELECT p.uniq_dep_hash256_pefld AS patientacctifk,
       d.firstname,
       d.lastname,
       d.gender,
       d.ssn,
       d.dob,
       d.addr        AS addr1,
       d.city,
       d.state,
       d.zip,
       d.coverageid AS policyid,
       ''           AS phone,
       d.dependentflag
FROM (SELECT * FROM df_transaction WHERE dependentflag = '1') d
  LEFT JOIN df_publish p
         ON TRIM (d.lr_creatingmodule) = TRIM (p.bc) 
         AND CAST (d.transactionkey AS BIGINT) = CAST(CONCAT(p.transactionkey_row,'1') AS BIGINT)
"""
data = spark.sql(sql_trans_x_publish_dep).dropDuplicates()
# data = data.withColumn("dob",concat_ws('-',substring(data.dob,1,4),substring(data.dob,5,2),substring(paccts.dob,5,2)))
data.write.mode('append').parquet(path_temp_01)

# COMMAND ----------

paccts = spark.read.parquet(path_temp_01).dropDuplicates()

for column in paccts.columns:
    paccts = paccts.withColumn(column, regexp_replace(col(column), r'[^\x00-\x7f]', r''))
    paccts = paccts.withColumn(column, trim(col(column)))

paccts = paccts.withColumn('policyid', regexp_replace(paccts.policyid, '[^A-Za-z0-9]', ''))
paccts.createOrReplaceTempView("patientaccts")

# COMMAND ----------

patientacctxpolicyid = paccts.select("patientacctifk", "policyid").dropDuplicates()

isValidPolicy_udf = udf(isValidPolicy, IntegerType())

patientacctxpolicyid = patientacctxpolicyid.withColumn('policyid_valid', isValidPolicy_udf(patientacctxpolicyid.policyid))
patientacctxpolicyid = patientacctxpolicyid.filter(~patientacctxpolicyid.policyid.like("%000000"))
patientacctxpolicyid = patientacctxpolicyid.dropDuplicates().filter(patientacctxpolicyid.policyid_valid == 1)
patientacctxpolicyid_grp = patientacctxpolicyid.groupBy("patientacctifk").agg(collect_set("policyid").alias("policyid"))

patientacctxpolicyid_grp.createOrReplaceTempView("patientacctxpolicyid_grp")

# COMMAND ----------

permid = spark.read.option("recursiveFileLookup","true").parquet(hdfs_permid_input)
permid = permid.withColumnRenamed("uniq_hash256_pefld", "patientacctifk")
permid.createOrReplaceTempView("patientacctxpermid")

im_permid = permid.filter(permid.matchind == 'IM').select('patientacctifk', 'permid').dropDuplicates()
im_permid.createOrReplaceTempView("im_patientacctxpermid")

hm_permid = permid.filter((permid.matchind == 'HM') | (permid.matchind == 'IM')).select('permid', 'magnetpermid').dropDuplicates()
hm_permid = hm_permid.groupBy("permid").agg(collect_set("magnetpermid").alias("hhpermid"))
hm_permid.createOrReplaceTempView("hm_permid")

# COMMAND ----------

patientacctxpermid_base_sql = """
SELECT DISTINCT 
       g.patientacctifk,
       pp.permid,
       hv.hhpermid,
       pi.policyid
FROM patientaccts g
  LEFT JOIN im_patientacctxpermid pp ON g.patientacctifk = pp.patientacctifk
  LEFT JOIN hm_permid hv ON hv.permid = pp.permid
  LEFT JOIN patientacctxpolicyid_grp pi ON g.patientacctifk = pi.patientacctifk
"""
patientacctxpermid_base = spark.sql(patientacctxpermid_base_sql)

patientacctxpermid_base.write.mode('overwrite').parquet(path_temp_02)

# COMMAND ----------

patientacctxpermid_base = spark.read.parquet(path_temp_02)
patientacctxpermid_base.createOrReplaceTempView("patientacctxpermid_base")

# COMMAND ----------

### Final Join to get all the required Data ###

joinSQL = """
SELECT concat("T",g.patientacctifk) AS globalmrnifk,
       g.firstname                  AS firstname,
       g.lastname                   AS lastname,
       g.dob                        AS dob,
       g.ssn                        AS ssn,
       g.gender                     AS gender,
       g.addr1                      AS addrnum,
       g.city                       AS city,
       g.state                      AS state,
       g.zip                        AS zip,
       g.phone                      AS phone,
       ''                           AS medicaidnum,
       ''                           AS medicarehic,
       SPLIT('',",")                AS medicalrecnum,
       pp.hhpermid,
       pp.policyid,
       pp.permid
FROM patientaccts g
  LEFT JOIN patientacctxpermid_base pp ON g.patientacctifk = pp.patientacctifk
"""

pd = spark.sql(joinSQL)
pd.dropDuplicates().write.mode('overwrite').parquet(path_temp_03)

# COMMAND ----------

pd = spark.read.parquet(path_temp_03)

# COMMAND ----------

# Create validation UDF functions

isValidName_udf = udf(isValidName, IntegerType())
isValidDOB_udf = udf(isValidDOB, IntegerType())
isValidSSN_udf = udf(isValidSSN, IntegerType())
isValidGender_udf = udf(isValidGender, IntegerType())
isValidCity_udf = udf(isValidCity, IntegerType())
isValidState_udf = udf(isValidState, IntegerType())
isValidZip_udf = udf(isValidZip, IntegerType())
isValidPhone_udf = udf(isValidPhone, IntegerType())
isValidString_udf = udf(isValidString, IntegerType())
isValidPID_udf = udf(isValidPID, IntegerType())
isValidNumber_udf = udf(isNumber, IntegerType())
isValidPolicy_udf = udf(isValidPolicy, IntegerType())

# COMMAND ----------

# cleanse and trim

pd = pd.withColumn('firstname', upper(pd.firstname))
pd = pd.withColumn('lastname', upper(pd.lastname))
pd = pd.withColumn('gender', upper(pd.gender))
pd = pd.withColumn('city', upper(pd.city))
pd = pd.withColumn('state', upper(pd.state))

pd = pd.withColumn('addrnum', regexp_extract(pd.addrnum, '\d+', 0))
pd = pd.withColumn('zip', regexp_extract(pd.zip, '\d\d\d\d\d', 0))
pd = pd.withColumn('phone', regexp_replace(pd.phone, '[^0-9]', ''))
pd = pd.withColumn('dob', regexp_extract(pd.dob, '\d+-\d+-\d+', 0))
pd = pd.withColumn('city', regexp_replace(pd.city, '[^A-Za-z\s]', ''))
pd = pd.withColumn('city', regexp_replace(pd.city, 'XX', ''))
pd = pd.withColumn('city', regexp_replace(pd.city, 'YY', ''))
pd = pd.withColumn('city', trim(pd.city))
pd = pd.withColumn('state', regexp_replace(pd.state, 'XX', ''))
pd = pd.withColumn('state', regexp_replace(pd.state, 'YY', ''))
pd = pd.withColumn('state', regexp_replace(pd.state, '[^A-Za-z\s]', ''))
pd = pd.withColumn('state', trim(pd.state))

# COMMAND ----------

# add validation columns

pd = pd.withColumn('fn_valid', isValidName_udf(pd.firstname))
pd = pd.withColumn('ln_valid', isValidName_udf(pd.lastname))
pd = pd.withColumn('dob_valid', isValidDOB_udf(pd.dob))
pd = pd.withColumn('gender_valid', isValidGender_udf(pd.gender))
pd = pd.withColumn('ssn_valid', isValidSSN_udf(pd.ssn))
pd = pd.withColumn('city_valid', isValidCity_udf(pd.city))
pd = pd.withColumn('state_valid', isValidState_udf(pd.state))
pd = pd.withColumn('zip_valid', isValidZip_udf(pd.zip))
pd = pd.withColumn('phone_valid', isValidPhone_udf(pd.phone))

new_hh_valid = when(col("hhpermid").isNull(), 0).otherwise(1)
pd = pd.withColumn('hhpermid_valid', new_hh_valid)

new_policy_valid = when(col("policyid").isNull(), 0).otherwise(1)
pd = pd.withColumn('policyid_valid', new_policy_valid)

pd = pd.withColumn('pid_valid', isValidPID_udf(pd.permid))
pd = pd.withColumn('addrnum_valid', isValidNumber_udf(pd.addrnum))

pd = pd.withColumn('mrn_valid', lit(0))
pd = pd.withColumn('mcd_valid', lit(0))
pd = pd.withColumn('mcr_valid', lit(0))

# COMMAND ----------

workflowtype="chc"
tableName = f"{workflowtype}_staged_patientaccts_{bcdata}"
print(tableName)
dropSql = f"DROP TABLE IF EXISTS {tableName}"
spark.sql(dropSql)

# COMMAND ----------

pd.dropDuplicates().write.mode("overwrite").format("delta").option("path", hdfs_output + bcdata).saveAsTable(tableName)

# COMMAND ----------

# optimizeSql = f"OPTIMIZE {tableName}"
# spark.sql(optimizeSql)

# COMMAND ----------


cluterBySql = f"ALTER TABLE {tableName} CLUSTER BY (state, city, dob, firstname)"
optimizeSql = f"OPTIMIZE {tableName}"
spark.sql(cluterBySql)
spark.sql(optimizeSql)

dbutils.notebook.exit({"stagedPatientacctsTableName": tableName})

# COMMAND ----------


