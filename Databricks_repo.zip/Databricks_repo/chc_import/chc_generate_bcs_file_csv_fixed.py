# Databricks notebook source
import sys
import os
import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
from pyspark import SparkContext
from pyspark.conf import SparkConf
import subprocess
from  pyspark.sql.functions import input_file_name

# COMMAND ----------

dbutils.widgets.text('input_bc','')
input_bc = dbutils.widgets.get("input_bc")

dbutils.widgets.text('input_publish','')
input_publish = dbutils.widgets.get("input_publish")

dbutils.widgets.text('input_transaction','')
input_transaction = dbutils.widgets.get("input_transaction")

dbutils.widgets.text('input_tobcs_csv','')
input_tobcs_csv = dbutils.widgets.get("input_tobcs_csv")

dbutils.widgets.text('input_tobcs_fixed','')
input_tobcs_fixed = dbutils.widgets.get("input_tobcs_fixed")

dbutils.widgets.text('storageaccount','')
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text('container','')
container = dbutils.widgets.get("container")



dbutils.widgets.text('user','')
user = dbutils.widgets.get("user")

# COMMAND ----------

# container="prod-icd-stadls"
# storageaccount="prodicdstgdls"
# input_publish="/data/chc/publish/current/20991231/"
# input_serve="/data/leadrepo/publish/toserve/chc_import/"
# input_transaction="/data/leadrepo/publish/cooked/chc_lr_transaction/"
# input_bc="20250408T05"
# user="maxc"
# input_tobcs_csv="/data/chc/transform/tobcs_csv/"
# input_tobcs_fixed="/data/chc/transform/tobcs_fixed/"

# COMMAND ----------

if user=='na':
    username=""
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'+"/"+username+"/"
else :
    username=user
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'+"/"+username+"/"


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

input_transaction=baseurl+input_transaction
input_publish=baseurl+input_publish
input_tobcs_csv=baseurl+"/"+input_tobcs_csv+"/"+input_bc
input_tobcs_fixed=baseurl+"/"+input_tobcs_fixed+"/"+input_bc

# print("input_transaction="+ input_transaction)
# print("input_publish="+ input_publish)
# print("input_tobcs_csv="+ input_tobcs_csv)
# print("input_tobcs_fixed="+ input_tobcs_fixed)

# COMMAND ----------

filterExpr = "bc=='" + input_bc + "'"
filterExpr1 = "lr_creatingmodule==" + "'" + input_bc + "'"

trans=spark.read.parquet(input_transaction).filter(filterExpr1).selectExpr("transactionkey").dropDuplicates()
trans.createOrReplaceTempView("trans")


data = spark.read.parquet(input_publish).filter(filterExpr)

for column in data.columns:
    data = data.withColumn(column, when(col(column).isNull(), None).otherwise(col(column)))
    data = data.withColumn(column, when(col(column) == '', None).otherwise(col(column)))
    data = data.withColumn(column, when(col(column) == 'null', None).otherwise(col(column)))

data.createOrReplaceTempView("data")


# COMMAND ----------

dep_demo_check_sql="""
SELECT *,
       CASE
         WHEN (
         dependentfirstname IS NULL AND 
         dependentmiddleinitial IS NULL AND 
         dependentlastname IS NULL AND 
         dependentgender IS NULL AND 
         dependentdob IS NULL AND 
         dependentssn IS NULL AND 
         dependentaddress1 IS NULL
               ) THEN '0'
         ELSE '1'
       END AS is_valid_dep_demo,
       CASE
         WHEN (
         subfirstname IS NULL AND 
         submiddleinitial IS NULL AND 
         sublastname IS NULL AND 
         subgender IS NULL AND 
         subdob IS NULL AND 
         subssn IS NULL AND 
         subaddress1 IS NULL
               ) THEN '0'
         ELSE '1'
       END AS is_valid_sub_demo
FROM data
"""
data=spark.sql(dep_demo_check_sql).dropDuplicates()

data.createOrReplaceTempView("data")

# COMMAND ----------

sql0003 = """
SELECT transactionkey_sub                    AS ID,
       UPPER(subfirstname)                   AS FN,
       UPPER(submiddleinitial)               AS MN,
       UPPER(sublastname)                    AS LN,
       UPPER(subgender)                      AS Gender,
       subssn                                AS SSN,
       REGEXP_REPLACE(subdob,"-","")         AS DOB,
       UPPER(subaddress1)                    AS Address,
       UPPER(subaddress2)                    AS Address2,
       UPPER(subcity)                        AS City,
       UPPER(substate)                       AS State,
       substr(subzip,1,5)                    AS Zip,
       substr(subzip,6,4)                    AS Zip4,
       ''                                    AS Phone,
       bcs_file_type                         AS Custom1,
       bc                                    AS Custom2
FROM data WHERE is_valid_sub_demo ='1'
UNION ALL
SELECT transactionkey_dep                    AS ID,
       UPPER(dependentfirstname)             AS FN,
       UPPER(dependentmiddleinitial)         AS MN,
       UPPER(dependentlastname)              AS LN,
       UPPER(dependentgender)                AS Gender,
       dependentssn                          AS SSN,
       REGEXP_REPLACE(dependentdob,"-","")   AS DOB,
       UPPER(dependentaddress1)              AS Address,
       UPPER(dependentaddress2)              AS Address2,
       UPPER(dependentcity)                  AS City,
       UPPER(dependentstate)                 AS State,
       substr(dependentzip,1,5)              AS Zip,
       substr(dependentzip,6,4)              AS Zip4,
       ''                                    AS Phone,
       bcs_file_type                         AS Custom1,
       bc                                    AS Custom2
FROM data WHERE is_valid_dep_demo ='1'
"""

data = spark.sql(sql0003).drop("is_valid_sub_demo").drop("is_valid_dep_demo").dropDuplicates()

data.createOrReplaceTempView("data")

# COMMAND ----------

data = spark.sql(""" SELECT data.* FROM data INNER JOIN trans where CAST(data.ID AS BIGINT)=CAST(trans.transactionkey AS BIGINT) """).dropDuplicates()

for column in data.columns:
    data = data.withColumn(column, when(col(column).isNull(), '').otherwise(col(column)))
    data = data.withColumn(column, when(col(column) == '', '').otherwise(col(column)))
    data = data.withColumn(column, when(col(column) == 'null', '').otherwise(col(column)))

data.repartition(15).write.format("csv").mode("overwrite").options(header="false", delimiter='|', timestampFormat="yyyy-MM-dd", emptyValue='',charset="iso-8859-1").save(input_tobcs_csv)

# COMMAND ----------

from pyspark.sql.functions import concat, format_string

forBDF= spark.read.csv(input_tobcs_csv,sep="|")
forBDF = forBDF.na.fill("")
schema = [
    "ID", "FN", "MN", "LN", "Gender", "SSN", "DOB", "Address", "Address2",
    "City", "State", "Zip", "Zip4", "Phone", "Custom1", "Custom2"
]

forBDF = forBDF.toDF(*schema)

# TEMP CODE BEGINS
# print("COUNT BEFORE FILTER", forBDF.count())
forBDF = forBDF.filter("length(ID) <= 64")
forBDF = forBDF.filter("length(FN) <= 50")
forBDF = forBDF.filter("length(MN) <= 50")
forBDF = forBDF.filter("length(LN) <= 50")
forBDF = forBDF.filter("length(Gender) <= 1")
forBDF = forBDF.filter("length(SSN) <= 9")
forBDF = forBDF.filter("length(DOB) <= 10")
forBDF = forBDF.filter("length(Address) <= 75")
forBDF = forBDF.filter("length(Address2) <= 75")
forBDF = forBDF.filter("length(City) <= 30")
forBDF = forBDF.filter("length(State) <= 2")
forBDF = forBDF.filter("length(Zip) <= 5")
forBDF = forBDF.filter("length(Zip4) <= 5")
forBDF = forBDF.filter("length(Phone) <= 20")
# print("COUNT AFTER FILTER", forBDF.count())
# TEMP CODE ENDS

FixedwidthColumnlengths = {'ID':64,'FN':50,'MN':50,'LN':50,'Gender':1,'SSN':9,'DOB':10,'Address':75,'Address2':75,'City':30,'State':2,'Zip':5,'Zip4':5,'Phone':20,'Custom1':32,'Custom2':64}
#just = r"%-{width}s".format(width=20)
#rjust = r"%{width}s".format(width=20)

outdf1 = forBDF.select(
    concat(*[format_string(r"%{width}s".format(width = i),c) for (c,i) in zip(forBDF.columns,FixedwidthColumnlengths.values())]).alias("fixedWidth")
)

# COMMAND ----------

outdf1.coalesce(1).write.format("text").options(charset="iso-8859-1").mode('overwrite').save(input_tobcs_fixed)
