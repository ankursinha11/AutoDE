# Databricks notebook source
import os
import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
from pyspark import SparkContext
from pyspark.conf import SparkConf
import subprocess
from  pyspark.sql.functions import input_file_name
from pyspark.sql.window import Window
from pyspark.sql.functions import row_number
import subprocess

# COMMAND ----------

# SAMPLE PROD INPUTS
# container = "prod-icd-adls"
# storageaccount = "prodicddls"
# input_bc = "20250410T02"
# input_data = "/data/chc/staging/input/"
# input_mapping = "/data/chc/staging/mapping/"
# input_publish = "/data/chc/publish/current/20991231/"
# input_temp = "/data/chc/transform/temp/"
# user = "na"

# COMMAND ----------

dbutils.widgets.text('input_bc','')
input_bc = dbutils.widgets.get("input_bc")

dbutils.widgets.text('input_data','')
input_data = dbutils.widgets.get("input_data")

dbutils.widgets.text('input_publish','')
input_publish = dbutils.widgets.get("input_publish")

dbutils.widgets.text('input_mapping','')
input_mapping = dbutils.widgets.get("input_mapping")

dbutils.widgets.text('input_temp','')
input_temp = dbutils.widgets.get("input_temp")

dbutils.widgets.text('storageaccount','')
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text('container','')
container = dbutils.widgets.get("container")

dbutils.widgets.text('user','')
user = dbutils.widgets.get("user")

# COMMAND ----------

if user=='na':
    username=""
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'+"/"+username+"/"
else :
    username=user
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'+"/"+username+"/"

print(baseurl)

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

input_data = baseurl + input_data + "/" + input_bc
input_publish = baseurl + input_publish
input_temp = baseurl + input_temp + "/" + input_bc
path_temp = input_temp
path_temp_01 = path_temp + "/01/"
path_temp_02 = path_temp + "/02/"
path_temp_03 = path_temp + "/03/"
path_temp_04 = path_temp + "/04/"

# COMMAND ----------

# DBTITLE 1,eid_mapping
eid_mapping = spark.read.format("parquet").load(baseurl+input_mapping+"/chc_eid_mapping")
eid_mapping.createOrReplaceTempView("eid_mapping")

# COMMAND ----------

hosp_mapping = spark.read.format("parquet").load(baseurl+input_mapping+"/chc_hosp_mapping")
hosp_mapping.createOrReplaceTempView("hosp_mapping")

# COMMAND ----------

field = [
    StructField("policy_id", StringType(), True),
    StructField("group_number", StringType(), True),
    StructField("group_name", StringType(), True),
    StructField("coverage_type", StringType(), True),
    StructField("subscriber_last_name", StringType(), True),
    StructField("subscriber_first_name", StringType(), True),
    StructField("subscriber_middle_initial", StringType(), True),
    StructField("subscriber_address1", StringType(), True),
    StructField("subscriber_address2", StringType(), True),
    StructField("subscriber_city", StringType(), True),
    StructField("subscriber_state", StringType(), True),
    StructField("subscriber_zip", StringType(), True),
    StructField("subscriber_dob", StringType(), True),
    StructField("subscriber_ssn", StringType(), True),
    StructField("subscriber_gender", StringType(), True),
    StructField("subscriber_phone", StringType(), True),
    StructField("relationship_code", StringType(), True),
    StructField("dependent_code", StringType(), True),
    StructField("dependent_last_name", StringType(), True),
    StructField("dependent_first_name", StringType(), True),
    StructField("dependent_middle_initial", StringType(), True),
    StructField("dependent_address1", StringType(), True),
    StructField("dependent_address2", StringType(), True),
    StructField("dependent_city", StringType(), True),
    StructField("dependent_state", StringType(), True),
    StructField("dependent_zip", StringType(), True),
    StructField("dependent_dob", StringType(), True),
    StructField("dependent_ssn", StringType(), True),
    StructField("dependent_gender", StringType(), True),
    StructField("dependent_phone", StringType(), True),
    StructField("begin_coverage_date", StringType(), True),
    StructField("end_coverage_date", StringType(), True),
    StructField("pharmacy_benefits", StringType(), True),
    StructField("alternate_id1", StringType(), True),
    StructField("alternate_id2", StringType(), True),
    StructField("employer_name", StringType(), True),
    StructField("employer_address1", StringType(), True),
    StructField("employer_address2", StringType(), True),
    StructField("employer_city", StringType(), True),
    StructField("employer_state", StringType(), True),
    StructField("employer_zip", StringType(), True),
    StructField("employer_status", StringType(), True),
    StructField("source", StringType(), True),
    StructField("system", StringType(), True)
]

table_schema = StructType(field)


data = spark.read.format("csv").options(header="true", inferSchema="false", timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", delimiter="\x01").schema(table_schema).load(input_data).withColumn("filename", input_file_name()).dropDuplicates()
data = data.filter("policy_id <> 'policy_id'")

for column in data.columns:
    data = data.withColumn(column, trim(col(column)))
    data = data.withColumn(column, upper(col(column)))
    data = data.withColumn(column, when(col(column) == '', None).otherwise(col(column)))
    data = data.withColumn(column, when(col(column).isNull(), None).otherwise(col(column)))
    data = data.withColumn(column, when(upper(col(column)) == 'NULL',None).otherwise(col(column)))

# data.display()
data.repartition(200).write.mode('overwrite').parquet(path_temp_01)
data.unpersist()

# COMMAND ----------

data = spark.read.parquet(path_temp_01).dropDuplicates()
data.createOrReplaceTempView("data")
data = spark.sql("""SELECT data.*,reverse(split(data.filename, '/'))[0] as basefilename from data""")
data.createOrReplaceTempView("data")
data = spark.sql("""SELECT data.*,split(basefilename,"_")[0] as basefilename_eid,reverse(split(basefilename, "_"))[1] as basefilename_state from data""")
data = data.withColumn("bpe", split(col("basefilename"), "_")[3])
data = data.withColumn("carrier", split(col("basefilename"), "_")[4])
data.createOrReplaceTempView("data")
data=spark.sql("""SELECT data.*,CASE WHEN lower(carrier) LIKE '%united%' THEN 'uhc' ELSE lower(carrier) END AS carrier_2 FROM data""")
data=data.withColumn("carrier", col("carrier_2")).drop("carrier_2")
data.createOrReplaceTempView("data")

from pyspark.sql.functions import when, upper, trim, col, coalesce
data = data.withColumn(
    "policyidnumber",
    when(
        (upper(trim(col("carrier"))).like("%UHC%")) | (upper(trim(col("carrier"))).like("%HEALTHPARTNERS%")),
        coalesce(col("alternate_id1"), col("alternate_id2"), col("policy_id"))
    ).otherwise(col("policy_id"))
)
data.createOrReplaceTempView("data")
sql = """
SELECT data.policyidnumber,
       LOWER(data.basefilename)                                       AS basefilename,
       UPPER(data.basefilename_state)                                 AS basefilename_state,
       basefilename_eid                                               AS basefilename_eid,
       eid_mapping.channel                                            AS channel,
       data.group_number                                              AS groupnumber,
       ""                                                             AS responsestatus,
       data.group_name                                                AS groupname,
       data.coverage_type                                             AS typeofcoverage,
       data.subscriber_last_name                                      AS sublastname,
       data.subscriber_first_name                                     AS subfirstname,
       data.subscriber_middle_initial                                 AS submiddleinitial,
       data.subscriber_address1                                       AS subaddress1,
       data.subscriber_address2                                       AS subaddress2,
       data.subscriber_city                                           AS subcity,
       data.subscriber_state                                          AS substate,
       data.subscriber_zip                                            AS subzip,
       CAST(from_unixtime(unix_timestamp(regexp_replace(data.subscriber_dob,"-",""),'yyyyMMdd'), 'yyyy-MM-dd') AS STRING)                                           AS subdob,
       data.subscriber_ssn                                            AS subssn,
       data.subscriber_gender                                         AS subgender,
       data.subscriber_phone                                          AS subphone,
       data.relationship_code                                         AS relationcode,
       data.dependent_code                                            AS dependentindicator,
       data.dependent_last_name                                       AS dependentlastname,
       data.dependent_first_name                                      AS dependentfirstname,
       data.dependent_middle_initial                                  AS dependentmiddleinitial,
       data.dependent_address1                                        AS dependentaddress1,
       data.dependent_address2                                        AS dependentaddress2,
       data.dependent_city                                            AS dependentcity,
       data.dependent_state                                           AS dependentstate,
       data.dependent_zip                                             AS dependentzip,
       CAST(from_unixtime(unix_timestamp(regexp_replace(data.dependent_dob,"-",""),'yyyyMMdd'), 'yyyy-MM-dd') AS STRING)                                             AS dependentdob,
       data.dependent_ssn                                             AS dependentssn,
       data.dependent_gender                                          AS dependentgender,
       data.dependent_phone                                           AS dependentphone,
       CAST(from_unixtime(unix_timestamp(regexp_replace(data.begin_coverage_date,"-",""),'yyyyMMdd'), 'yyyy-MM-dd') AS STRING)                                       AS coveragestartdate,
       CASE WHEN TRIM (data.end_coverage_date) IS NOT NULL THEN CAST(from_unixtime(unix_timestamp(regexp_replace(data.end_coverage_date,"-",""),'yyyyMMdd'), 'yyyy-MM-dd') AS STRING)  ELSE CAST('2099-12-31' AS STRING) END AS coverageenddate,
       data.pharmacy_benefits                                         AS pharmacybenefitoutsourced,
       data.alternate_id1,    
       data.alternate_id2,  
       data.employer_name                                             AS employername,
       data.employer_address1                                         AS employeraddress1,
       data.employer_address2                                         AS employeraddress2,
       data.employer_city                                             AS employercity,
       data.employer_state                                            AS employerstate,
       data.employer_zip                                              AS employer_zip,
       data.employer_status                                           AS employerstatus,
       data.source,
       data.system,
       data.basefilename_eid                                          AS eid,
       CAST(current_timestamp() AS STRING)                            AS createdate,
       hosp_mapping.hospitalfk                                        AS hospitalfk,
       hosp_mapping.hcsystemfk                                        AS hcsystemfk,
       lower(data.carrier)                                            AS carrier,
       eid_mapping.edipartnerfk                                       AS edipartnerfk,
       lower(data.bpe)                                                AS bpe
FROM   data
LEFT JOIN eid_mapping
         ON (
            TRIM(data.basefilename_eid) = TRIM(eid_mapping.eid)
        AND UPPER (TRIM (data.bpe)) = UPPER (TRIM (eid_mapping.bpe))
        AND UPPER (TRIM (data.carrier)) = UPPER (TRIM (eid_mapping.carrier))
            )
  LEFT JOIN hosp_mapping
         ON (TRIM (data.basefilename_eid) = TRIM (hosp_mapping.eid)
        AND UPPER (TRIM (data.basefilename_state)) = UPPER (TRIM (hosp_mapping.state))
        AND UPPER (TRIM (data.bpe)) = UPPER (TRIM (hosp_mapping.bpe)))
"""

data = spark.sql(sql).dropDuplicates()

data.createOrReplaceTempView("data")
data = spark.sql("""
                  SELECT *,
                         concat(channel,"_",eid)                                                                                          AS bcs_file_type,
                         sha2(concat_ws (':',policyidnumber,edipartnerfk,subfirstname,sublastname,subdob),256)                            AS uniq_sub_hash256_pefld,
                         sha2(concat_ws (':',policyidnumber,edipartnerfk,dependentfirstname,dependentlastname,dependentdob),256)          AS uniq_dep_hash256_pefld
                  FROM data
               """).dropDuplicates()
# data.display()
data.repartition(200).write.mode('overwrite').parquet(path_temp_02)
data.unpersist()

# COMMAND ----------

data = spark.read.parquet(path_temp_02)
data.createOrReplaceTempView("data")
data = spark.sql("""SELECT * FROM data ORDER BY uniq_sub_hash256_pefld,uniq_dep_hash256_pefld,relationcode""")
static_data = "20991231"
data = data.withColumn("static_column", lit(static_data))
data = data.withColumn("rowid", row_number().over(Window.partitionBy("static_column").orderBy("static_column","uniq_sub_hash256_pefld","uniq_dep_hash256_pefld","relationcode")))
data.repartition(200).write.mode('overwrite').parquet(path_temp_03)
data.unpersist()

# COMMAND ----------

bc=input_bc

data = spark.read.parquet(path_temp_03)
bc_new = bc[2:11]

data = data.withColumn("bc", lit(bc)).withColumn("bc_new", lit(bc_new))
data.createOrReplaceTempView("data")
data = spark.sql("""SELECT CAST(CAST(concat(rowid,regexp_replace (bc_new,'T','')) AS STRING) AS BIGINT) AS transactionkey_row,* FROM data""").drop("bc_new")
data.createOrReplaceTempView("data")
data=spark.sql("""
SELECT CAST(transactionkey_row AS BIGINT)              AS transactionkey_row,
       CAST(CONCAT (transactionkey_row,'0') AS BIGINT) AS transactionkey_sub,
       CAST(CONCAT (transactionkey_row,'1') AS BIGINT) AS transactionkey_dep,       
       basefilename,
       basefilename_state,
       basefilename_eid,
       channel,
       groupnumber,
       responsestatus,
       groupname,
       policyidnumber,
       typeofcoverage,
       uniq_sub_hash256_pefld,
       sublastname,
       subfirstname,
       submiddleinitial,
       subaddress1,
       subaddress2,
       subcity,
       substate,
       subzip,
       subdob,
       subssn,
       subgender,
       subphone,
       relationcode,
       dependentindicator,
       uniq_dep_hash256_pefld,
       dependentlastname,
       dependentfirstname,
       dependentmiddleinitial,
       dependentaddress1,
       dependentaddress2,
       dependentcity,
       dependentstate,
       dependentzip,
       dependentdob,
       dependentssn,
       dependentgender,
       dependentphone,
       coveragestartdate,
       coverageenddate,
       pharmacybenefitoutsourced,
       alternate_id1,
       alternate_id2,
       employername,
       employeraddress1,
       employeraddress2,
       employercity,
       employerstate,
       employer_zip,
       employerstatus,
       source,
       system,
       eid,
       createdate,
       hospitalfk,
       hcsystemfk,
       carrier,
       edipartnerfk,
       bpe,
       bcs_file_type,
       static_column,
       rowid,
       bc,
       bc AS lr_creatingmodule
FROM data
""")

data.repartition(25).write.mode('append').parquet(input_publish)
data.unpersist()

# COMMAND ----------


