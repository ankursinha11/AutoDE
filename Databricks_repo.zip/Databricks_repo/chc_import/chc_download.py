# Databricks notebook source
dbutils.widgets.text("bcs_upload_zip_path", "")
dbutils.widgets.getArgument("bcs_upload_zip_path")
bcs_upload_zip_path= getArgument("bcs_upload_zip_path")

dbutils.widgets.text("bcs_download_cdd_path", "")
dbutils.widgets.getArgument("bcs_download_cdd_path")
bcs_download_cdd_path= getArgument("bcs_download_cdd_path")

dbutils.widgets.text("bcs_download_chc_path", "")
dbutils.widgets.getArgument("bcs_download_chc_path")
bcs_download_chc_path= getArgument("bcs_download_chc_path")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text('cosmosEndpoint','')
cosmosEndpoint = dbutils.widgets.get("cosmosEndpoint")

dbutils.widgets.text('cosmosDatabaseName','')
cosmosDatabaseName = dbutils.widgets.get("cosmosDatabaseName")

dbutils.widgets.text('cosmosContainerName','')
cosmosContainerName = dbutils.widgets.get("cosmosContainerName")


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------


def readFromCosmos(Endpoint,MasterKey,DatabaseName,ContainerName):
    readConf = {
    "spark.cosmos.accountEndpoint" : Endpoint,
    "spark.cosmos.accountKey" : MasterKey,
    "spark.cosmos.database" : DatabaseName,
    "spark.cosmos.container" : ContainerName
}
    df_read = spark.read.format("cosmos.oltp").options(**readConf).option("spark.cosmos.read.inferSchema.enabled", "true").load()
    return df_read


def writeToCosmos(dfWrite,Endpoint,MasterKey,DatabaseName,ContainerName):
    writeConf = {
    "spark.cosmos.accountEndpoint" : Endpoint,
    "spark.cosmos.accountKey" : MasterKey,
    "spark.cosmos.database" : DatabaseName,
    "spark.cosmos.container" : ContainerName,
    "spark.cosmos.write.strategy" : "ItemOverwrite"
}
    dfWrite.write.format('cosmos.oltp').options(**writeConf).mode('append').save()

cosmosMasterKey = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-cosmos-insleads-kvsecret")

print("cosmosEndpoint" + str(cosmosEndpoint))
print("cosmosMasterKey" + str(cosmosMasterKey))
print("cosmosDatabaseName" + str(cosmosDatabaseName))
print("cosmosContainerName" + str(cosmosContainerName))

data = readFromCosmos(cosmosEndpoint,cosmosMasterKey,cosmosDatabaseName,cosmosContainerName)
data.createOrReplaceTempView("data")
data=spark.sql(""" SELECT bc from data where cast(bcsdownload as INT) ='0' ORDER BY bc ASC """).selectExpr("bc").dropDuplicates().limit(1)
if data.count() > 0 :
    bc = [str(row.bc) for row in data.collect()][0]
    print("bc : "+bc)
else :
     ret_val=0
     dbutils.notebook.exit(ret_val)

# COMMAND ----------

#filterExp="lr_creatingmodule=='"+bc+"'"
#data=spark.read.parquet(baseurl+"/data/chc/publish/current/20991231/").filter(filterExp).selectExpr("eid").dropDuplicates().limit(1)
#eid = [str(row.eid) for row in data.collect()][0]
#print("EID to look: " +eid)
#folder_eid="chc_"+eid+"_bdf"
#print("folder_eid: " +folder_eid)

# COMMAND ----------

bcs_upload_zip_path = baseurl+bcs_upload_zip_path+bc+'/merge'
bcs_download_cdd_path = baseurl+bcs_download_cdd_path+"/"+bc
bcs_download_chc_path = baseurl+bcs_download_chc_path+"/"+bc
print("bcs_upload_zip_path : "+ bcs_upload_zip_path)
print("bcs_download_cdd_path : " + bcs_download_cdd_path)
print("bcs_download_chc_path : " + bcs_download_chc_path)

# COMMAND ----------

# # abfss_url = "abfss://prod-icd-stg-adls@prodicdstgdls.dfs.core.windows.net/"
# match_path = abfss_url+"karthik/data/chc/transform/download/chc/20230602T08/"
# zip_path = abfss_url+"karthik/data/chc/transform/new/20230602T08/merge/"
# print(match_path,'\n',zip_path)


zip_path = bcs_upload_zip_path
match_path = bcs_download_cdd_path
print(match_path, '\n', zip_path)

# COMMAND ----------

def file_exists(path):
  try:
    dbutils.fs.ls(path)
    return 1
  except Exception as e:
    if 'java.io.FileNotFoundException' in str(e):
      return 0
    else:
      raise

# COMMAND ----------

isfile_exists=file_exists(match_path)
if isfile_exists == 1:
    print("folder  present :"+str(match_path))
    files = dbutils.fs.ls(match_path)
    match_path_count = 0
    for file in files: 
        if file[1].endswith("MatchAppend.dat"):
            match_path_count = match_path_count + 1
else :
    print("folder doesnt exists :"+str(match_path))
    ret_val=0
    dbutils.notebook.exit({'bc':bc,'ret_val':ret_val})

# print("match_path_count: " +str(match_path_count))

# COMMAND ----------

files = dbutils.fs.ls(zip_path)
zip_path_count = 0
for file in files: 
    if file[1].endswith(".zip"):
        zip_path_count = zip_path_count + 1

# print("zip_path_count: ",zip_path_count)

# COMMAND ----------

if (zip_path_count == match_path_count):
    ret_val = 1
    print("bc"+str(bc))
    print("ret_val :"+str(ret_val))
    #COPY THE DATA from cp -r bcs_download_cdd_path/*MATCH* bcs_download_chc_path
    dbutils.notebook.exit({'bc':bc,'ret_val':ret_val})
else:
    ret_val = 0
    dbutils.notebook.exit({'bc':'0','ret_val':ret_val})