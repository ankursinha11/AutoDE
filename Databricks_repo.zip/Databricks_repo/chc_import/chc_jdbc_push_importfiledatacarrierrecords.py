# Databricks notebook source
import sys
import os
import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
from pyspark import SparkContext
from pyspark.conf import SparkConf
import subprocess
from  pyspark.sql.functions import input_file_name

# COMMAND ----------

dbutils.widgets.text('input_bc','')
input_bc = dbutils.widgets.get("input_bc")

dbutils.widgets.text('input_publish','')
input_publish = dbutils.widgets.get("input_publish")

dbutils.widgets.text('input_transaction','')
input_transaction = dbutils.widgets.get("input_transaction")

dbutils.widgets.text('input_xref_gmrn','')
input_xref_gmrn = dbutils.widgets.get("input_xref_gmrn")

dbutils.widgets.text('input_xref_perm','')
input_xref_perm = dbutils.widgets.get("input_xref_perm")

dbutils.widgets.text('input_temp','')
input_temp = dbutils.widgets.get("input_temp")

dbutils.widgets.text('input_jdbc_conn','')
input_jdbc_conn = dbutils.widgets.get("input_jdbc_conn")

dbutils.widgets.text('input_tablename','')
input_tablename = dbutils.widgets.get("input_tablename")

dbutils.widgets.text('input_base_table','')
input_base_table = dbutils.widgets.get("input_base_table")

dbutils.widgets.text('storageaccount','')
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text('container','')
container = dbutils.widgets.get("container")

dbutils.widgets.text('user','')
user = dbutils.widgets.get("user")

# COMMAND ----------

# DBTITLE 1,PROD
# input_base_table = "/data/dataingestion/publish/"
# input_jdbc_conn = "jdbc:sqlserver://jude1.nthrive.nthcrp.com;user=app_databricks;password=XXXXXXXXXXXXXXXX;encrypt=true;trustServerCertificate=true"
# input_publish = "/data/chc/publish/current/20991231/"
# input_tablename = "abinitio.dbo.importfiledatacarrierrecords"
# input_bc = "20250410T02"
# storageaccount = "prodicddls"
# user = "na"
# container = "prod-icd-adls"
# input_temp = "/data/chc/transform/temp/"
# input_transaction = "/data/leadrepo/publish/cooked/chc_lr_transaction/"
# input_xref_gmrn = "/data/leadrepo/publish/cooked/chc_lr_xref_gmrnid_transaction/"
# input_xref_perm = "/data/chc/publish/idxpermid/medical_carrier/"

# COMMAND ----------

# DBTITLE 1,STAGE
# input_base_table = "/data/dataingestion/publish/"
# input_jdbc_conn = "jdbc:sqlserver://jude1.nthrive.nthcrp.com;user=app_databricks;password=XXXXXXXXXXXXXXXXXXXXXXXXXX;encrypt=true;trustServerCertificate=true"
# input_publish = "/data/chc/publish/current/20991231/"
# input_tablename = "abinitio.dbo.importfiledatacarrierrecords"
# input_bc = "20250614T05"
# storageaccount = "prodicdstgdls"
# user = "maxc"
# container = "prod-icd-stg-adls"
# input_temp = "/data/chc/transform/temp/"
# input_transaction = "/data/leadrepo/publish/cooked/chc_lr_transaction/"
# input_xref_gmrn = "/data/leadrepo/publish/cooked/chc_lr_xref_gmrnid_transaction/"
# input_xref_perm = "/data/chc/publish/idxpermid/medical_carrier/"

# COMMAND ----------

if user=='na':
    username=""
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'+"/"+username+"/"
else :
    username=user
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'+"/"+username+"/"


print("baseurl= "+ baseurl)

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))


input_base_table = baseurl + input_base_table

chc_path_publish = baseurl + input_publish
chc_path_transaction = baseurl + input_transaction
chc_path_xref_gmrnid = baseurl + input_xref_gmrn
chc_path_xref_permid = baseurl + input_xref_perm + input_bc
chc_bc = input_bc
chc_prod_jdbc_conn_file = input_jdbc_conn
chc_prod_jdbc_tablename = input_tablename

chc_path_temp = baseurl + input_temp + "/importfiledatacarrierrecords/" + input_bc +"/"
print("chc_path_temp : " + chc_path_temp)

path_temp_PD = chc_path_temp + "/tmp/PD/"
path_temp_GD = chc_path_temp + "/tmp/GD/"
path_temp_UP = chc_path_temp + "/tmp/UP/"
path_temp_UG = chc_path_temp + "/tmp/UG/"
path_temp_FC = chc_path_temp + "/tmp/FC/"

path_temp_01 = chc_path_temp + "/tmp/01/"
path_temp_02 = chc_path_temp + "/tmp/02/"
path_temp_03 = chc_path_temp + "/tmp/03/"
path_temp_04 = chc_path_temp + "/tmp/04/"
path_temp_05 = chc_path_temp + "/tmp/05/"
path_temp_06 = chc_path_temp + "/tmp/06/"
path_temp_07 = chc_path_temp + "/tmp/07/"
path_temp_08 = chc_path_temp + "/tmp/08/"

chc_path_output = chc_path_temp + "/output/"
print("chc_path_output : " + chc_path_output)

filterExpr1 = "lr_creatingmodule==" + "'" + chc_bc + "'"
filterExpr2 = "bc==" + "'" + chc_bc + "'"

# COMMAND ----------

chc_publish_sub = spark.read.parquet(chc_path_publish).selectExpr("lr_creatingmodule","eid","bpe","carrier").dropDuplicates()

# COMMAND ----------

# DBTITLE 1,gmrn
gmrn = spark.read.format("delta").load(chc_path_xref_gmrnid).filter(filterExpr1).selectExpr("transactionkey", "gmrnid", "gmrnmatchind", "xrefsource").dropDuplicates()
gmrn.write.mode("overwrite").format("parquet").save(path_temp_GD)
gmrn.unpersist()

# COMMAND ----------

# DBTITLE 1,perm
perm = spark.read.format("parquet").load(chc_path_xref_permid).filter("MatchInd=='IM'")
perm = perm.selectExpr("transactionkey","bc as lr_creatingmodule","eid","MagnetPermId","MatchInd","PermId").dropDuplicates()
perm.write.mode("overwrite").format("parquet").save(path_temp_PD)
perm.unpersist()

# COMMAND ----------

gmrn=spark.read.format("parquet").load(path_temp_GD)
gmrn.createOrReplaceTempView("gmrn")

perm=spark.read.format("parquet").load(path_temp_PD)
perm.createOrReplaceTempView("perm")

# COMMAND ----------

# publish = (
#     spark.read.parquet(chc_path_publish)
#     .filter(filterExpr2)
#     .selectExpr(
#         "basefilename",
#         "bc as lr_creatingmodule",
#         "eid",
#         "bpe",
#         "hospitalfk",
#         "hcsystemfk",
#         "carrier",
#         "coveragestartdate",
#         "coverageenddate",
#         "typeofcoverage",
#         "transactionkey_row",
#         "policyidnumber",
#     )
#     .dropDuplicates()
# )
# publish = publish.filter("bpe=='accenture'").filter("carrier=='aetna'").dropDuplicates()
# publish.display()

# COMMAND ----------

# DBTITLE 1,PUBLISH
publish = (
    spark.read.parquet(chc_path_publish)
    .filter(filterExpr2)
    .selectExpr(
        "basefilename",
        "bc as lr_creatingmodule",
        "eid",
        "bpe",
        "hospitalfk",
        "hcsystemfk",
        "carrier",
        "coveragestartdate",
        "coverageenddate",
        "typeofcoverage",
        "transactionkey_row",
        "policyidnumber",
    )
    .dropDuplicates()
)
# publish = publish.filter("bpe=='accenture'").filter("carrier=='aetna'").dropDuplicates()

publish.createOrReplaceTempView("publish")

carrier_type = publish.selectExpr("carrier").dropDuplicates().collect()[0]
carrier_type = str(carrier_type["carrier"])

if carrier_type == 'uhc':
    trans = spark.read.parquet(chc_path_transaction).filter(filterExpr1).filter("dependentflag=='1'").drop("transactionrange")
else:
    trans = spark.read.parquet(chc_path_transaction).filter(filterExpr1).drop("transactionrange")

trans.createOrReplaceTempView("trans")

# COMMAND ----------

trans_x_publish = spark.sql("""
       SELECT 
       trans.*,
       publish.eid,
       publish.bpe,
       publish.carrier,
       publish.coveragestartdate,
       publish.coverageenddate,
       publish.typeofcoverage,
       CAST(regexp_replace((reverse (split (publish.basefilename,'_'))[0]),".dat","") AS BIGINT) AS basefilename_ts
       FROM trans
  INNER JOIN publish
          ON trans.lr_creatingmodule = publish.lr_creatingmodule
         AND CAST (trans.transactionkey_row AS BIGINT) = CAST (publish.transactionkey_row AS BIGINT)
         AND trans.coverageid = publish.policyidnumber
""").dropDuplicates()

trans_x_publish.createOrReplaceTempView("trans_x_publish")

trans_x_publish = spark.sql("""
SELECT a.*,
       CASE
         WHEN carrier = 'aetna' THEN aetna_typeofcoverage ELSE typeofcoverage END AS typeofcoverage_rev
FROM (SELECT a.*,
             concat_ws(',',a.aetna_typeofcoverage_1,a.aetna_typeofcoverage_2,a.aetna_typeofcoverage_3,a.aetna_typeofcoverage_4,a.aetna_typeofcoverage_5) AS aetna_typeofcoverage
      FROM (SELECT *,
       CASE WHEN (carrier='aetna' AND SUBSTR(typeofcoverage,1,1)='Y') THEN 'M'  ELSE 'X'  END AS aetna_typeofcoverage_1,
       CASE WHEN (carrier='aetna' AND SUBSTR(typeofcoverage,2,1)='Y') THEN 'D'  ELSE 'X'  END AS aetna_typeofcoverage_2,
       CASE WHEN (carrier='aetna' AND SUBSTR(typeofcoverage,3,1)='Y') THEN 'V'  ELSE 'X'  END AS aetna_typeofcoverage_3,
       CASE WHEN (carrier='aetna' AND SUBSTR(typeofcoverage,4,1)='Y') THEN 'RX' ELSE 'X'  END AS aetna_typeofcoverage_4,
       CASE WHEN (carrier='aetna' AND SUBSTR(typeofcoverage,5,1)='Y') THEN 'B'  ELSE 'X'  END AS aetna_typeofcoverage_5
       FROM trans_x_publish) a) a
""").drop("aetna_typeofcoverage_1").drop("aetna_typeofcoverage_2").drop("aetna_typeofcoverage_3").drop("aetna_typeofcoverage_4").drop("aetna_typeofcoverage_5").drop("aetna_typeofcoverage").drop("typeofcoverage").withColumnRenamed("typeofcoverage_rev", "typeofcoverage").dropDuplicates()

trans_x_publish.createOrReplaceTempView("trans_x_publish")

# COMMAND ----------

trans_x_publish = spark.sql(""" SELECT * FROM trans_x_publish LATERAL VIEW explode(SPLIT(typeofcoverage,",")) itemTable AS exp_typeofcoverage """).drop("typeofcoverage")
trans_x_publish=trans_x_publish.withColumnRenamed("exp_typeofcoverage", "typeofcoverage").filter("typeofcoverage <> 'X'").dropDuplicates()
trans_x_publish.createOrReplaceTempView("trans_x_publish")
trans_x_publish = spark.sql("""
SELECT t.basefilename_ts,
       t.eid,
       t.bpe,
       t.carrier,
       t.payerid,
       t.clientid   AS hospitalfk,
       t.hcsystemfk,
       t.lr_creatingmodule,
       t.transactionkey_row,
       t.transactionkey,
       CASE WHEN CAST(t.dependentflag AS SMALLINT) IS NULL THEN NULL ELSE CAST(t.dependentflag AS SMALLINT) END AS dependentflag,
       t.groupnumber,
       t.coverageid,
       CASE WHEN CAST(t.coveragestartdate AS DATE) IS NULL THEN NULL ELSE CAST(t.coveragestartdate AS DATE) END AS coveragestartdate,
       CASE WHEN CAST(t.coverageenddate AS DATE)   IS NULL THEN NULL ELSE CAST(t.coverageenddate AS DATE)   END AS coverageenddate,
       t.typeofcoverage,
       CASE 
             WHEN CAST(t.coveragestartdate AS DATE) <=CURRENT_DATE() AND CAST(t.coverageenddate AS DATE) >= CURRENT_DATE() THEN 'ACTIVE'
             WHEN CAST(t.coveragestartdate AS DATE) > CURRENT_DATE() AND CAST(t.coverageenddate AS DATE) > CURRENT_DATE()  THEN 'FUTURE'
             WHEN CAST(t.coveragestartdate AS DATE) < CURRENT_DATE() AND CAST(t.coverageenddate AS DATE) < CURRENT_DATE()  THEN 'EXPIRED'
             ELSE 'UNKNOWN' 
       END            AS coveragestatus,
       CURRENT_DATE() AS reportdate,    
       t.firstname,
       t.middlename,
       t.lastname,
       t.gender,
       t.ssn,
       CASE WHEN CAST(t.dob AS DATE) IS NULL THEN NULL ELSE CAST(t.dob AS DATE) END AS dob,
       t.addr,
       t.city,
       t.state,
       t.zip,
       RANK() OVER (PARTITION BY eid,carrier,coverageid,groupnumber,typeofcoverage,CAST(coveragestartdate AS DATE),CAST(coverageenddate AS DATE),CAST(dob AS DATE),ssn ORDER BY CAST(basefilename_ts AS BIGINT) DESC) AS rnk
FROM trans_x_publish t
""").dropDuplicates()

trans_x_publish.write.mode('overwrite').parquet(path_temp_01)
trans_x_publish.unpersist()

# COMMAND ----------

# DBTITLE 1,trans_x_publish_x_perm
trans_x_publish = spark.read.parquet(path_temp_01).filter("rnk=='1'").drop("rnk").dropDuplicates()
trans_x_publish.createOrReplaceTempView("trans_x_publish")

trans_x_publish_x_perm = spark.sql("""
SELECT t.basefilename_ts,
       t.eid,
       t.bpe,
       t.carrier,
       t.payerid,
       t.hospitalfk   AS hospitalfk,
       t.hcsystemfk,
       t.lr_creatingmodule,
       t.transactionkey_row,
       t.transactionkey,
       CASE WHEN CAST(t.dependentflag AS SMALLINT) IS NULL THEN NULL ELSE CAST(t.dependentflag AS SMALLINT) END AS dependentflag,
       t.groupnumber,
       t.coverageid,
       CASE WHEN CAST(t.coveragestartdate AS DATE) IS NULL THEN NULL ELSE CAST(t.coveragestartdate AS DATE) END AS coveragestartdate,
       CASE WHEN CAST(t.coverageenddate AS DATE)   IS NULL THEN NULL ELSE CAST(t.coverageenddate AS DATE)   END AS coverageenddate,
       t.typeofcoverage,
       CASE 
             WHEN CAST(t.coveragestartdate AS DATE) <=CURRENT_DATE() AND CAST(t.coverageenddate AS DATE) >= CURRENT_DATE() THEN 'ACTIVE'
             WHEN CAST(t.coveragestartdate AS DATE) > CURRENT_DATE() AND CAST(t.coverageenddate AS DATE) > CURRENT_DATE()  THEN 'FUTURE'
             WHEN CAST(t.coveragestartdate AS DATE) < CURRENT_DATE() AND CAST(t.coverageenddate AS DATE) < CURRENT_DATE()  THEN 'EXPIRED'
             ELSE 'UNKNOWN' 
       END            AS coveragestatus,
       CURRENT_DATE() AS reportdate,    
       t.firstname,
       t.middlename,
       t.lastname,
       t.gender,
       t.ssn,
       CASE WHEN CAST(t.dob AS DATE) IS NULL THEN NULL ELSE CAST(t.dob AS DATE) END AS dob,
       t.addr,
       t.city,
       t.state,
       t.zip,       
       perm.permid,
       perm.matchind,
       perm.magnetpermid
FROM trans_x_publish t
  LEFT JOIN perm
         ON TRIM (t.lr_creatingmodule) = TRIM (perm.lr_creatingmodule)
        AND TRIM (t.eid) = TRIM (perm.eid)
        AND CAST (t.transactionkey AS BIGINT) = CAST (perm.transactionkey AS BIGINT)
""").dropDuplicates()

trans_x_publish_x_perm.write.mode('overwrite').parquet(path_temp_02)
trans_x_publish_x_perm.unpersist()

# COMMAND ----------

# DBTITLE 1,trans_x_publish_x_perm_x_gmrn
trans_x_publish_x_perm = spark.read.parquet(path_temp_02)
trans_x_publish_x_perm.createOrReplaceTempView("trans_x_publish_x_perm")

trans_x_publish_x_perm_x_gmrn = spark.sql(""" 
SELECT trans_x_publish_x_perm.*,
       gmrn.gmrnid
FROM trans_x_publish_x_perm
  LEFT JOIN gmrn ON trans_x_publish_x_perm.transactionkey = gmrn.transactionkey
""").dropDuplicates()

trans_x_publish_x_perm_x_gmrn.write.mode('overwrite').parquet(path_temp_03)
trans_x_publish_x_perm_x_gmrn.unpersist()

# COMMAND ----------

trans_x_publish_x_perm_x_gmrn = spark.read.parquet(path_temp_03)
trans_x_publish_x_perm_x_gmrn.createOrReplaceTempView("trans_x_publish_x_perm_x_gmrn")


dup_permid = spark.sql("""SELECT permid, COUNT(DISTINCT CAST(dob AS DATE)) AS pd_count FROM trans_x_publish_x_perm_x_gmrn GROUP BY permid HAVING COUNT(DISTINCT CAST(dob AS DATE)) > 1""")
dup_permid.write.mode('overwrite').parquet(path_temp_UP)
dup_permid.unpersist()

dup_gmrnid = spark.sql("""SELECT gmrnid, COUNT(DISTINCT CAST(dob AS DATE)) AS gd_count FROM trans_x_publish_x_perm_x_gmrn GROUP BY gmrnid HAVING COUNT(DISTINCT CAST(dob AS DATE)) > 1""")
dup_gmrnid.write.mode('overwrite').parquet(path_temp_UG)
dup_gmrnid.unpersist()

dup_permid = spark.read.parquet(path_temp_UP).selectExpr("permid").dropDuplicates()
dup_permid.createOrReplaceTempView("dup_permid")
dup_gmrnid = spark.read.parquet(path_temp_UG).selectExpr("gmrnid").dropDuplicates()
dup_gmrnid.createOrReplaceTempView("dup_gmrnid")

# COMMAND ----------

trans_x_publish_x_perm_x_gmrn = spark.sql("""
SELECT trans_x_publish_x_perm_x_gmrn.*,
       CASE WHEN trans_x_publish_x_perm_x_gmrn.permid = dup_permid.permid THEN '0' ELSE '1' END AS is_valid_permid,
       CASE WHEN trans_x_publish_x_perm_x_gmrn.gmrnid = dup_gmrnid.gmrnid THEN '0' ELSE '1' END AS is_valid_gmrnid
FROM trans_x_publish_x_perm_x_gmrn
  LEFT JOIN dup_permid ON trans_x_publish_x_perm_x_gmrn.permid = dup_permid.permid
  LEFT JOIN dup_gmrnid ON trans_x_publish_x_perm_x_gmrn.gmrnid = dup_gmrnid.gmrnid
""").dropDuplicates()

trans_x_publish_x_perm_x_gmrn.createOrReplaceTempView("trans_x_publish_x_perm_x_gmrn")

trans_x_publish_x_perm_x_gmrn = spark.sql("""
SELECT 
       basefilename_ts,
       eid,
       bpe,
       carrier,
       payerid,
       hospitalfk,
       hcsystemfk,
       lr_creatingmodule,
       transactionkey_row,
       transactionkey,
       dependentflag,
       groupnumber,
       coverageid,
       coveragestartdate,
       coverageenddate,
       typeofcoverage,
       coveragestatus,
       reportdate,
       firstname,
       middlename,
       lastname,
       gender,
       ssn,
       dob,
       addr,
       city,
       state,
       zip,
       CASE WHEN is_valid_permid='1' THEN permid       ELSE NULL END AS permid,
       CASE WHEN is_valid_permid='1' THEN matchind     ELSE NULL END AS matchind,
       CASE WHEN is_valid_permid='1' THEN magnetpermid ELSE NULL END AS magnetpermid,
       CASE WHEN is_valid_gmrnid='1' THEN gmrnid       ELSE NULL END AS gmrnid
FROM trans_x_publish_x_perm_x_gmrn
""").dropDuplicates()

trans_x_publish_x_perm_x_gmrn.createOrReplaceTempView("trans_x_publish_x_perm_x_gmrn")

final_output = spark.sql("""
         SELECT 
         CASE WHEN SSN    IS NOT NULL THEN CAST('1' AS SMALLINT) ELSE CAST('0' AS SMALLINT) END    AS ssn_flag,
         CASE WHEN PERMID IS NOT NULL THEN CAST('1' AS SMALLINT) ELSE CAST('0' AS SMALLINT) END    AS permid_flag,
         CASE WHEN GMRNID IS NOT NULL THEN CAST('1' AS SMALLINT) ELSE CAST('0' AS SMALLINT) END    AS gmrnid_flag,
       *
FROM trans_x_publish_x_perm_x_gmrn
""").dropDuplicates()

final_output.write.mode('overwrite').parquet(path_temp_04)
final_output.unpersist()

# COMMAND ----------

final_output = spark.read.parquet(path_temp_04)
# print("Number of records in final_output: " + str(final_output.count()))

final_output.createOrReplaceTempView("final_output")
final_output=spark.sql("""
SELECT *,
       CASE
         WHEN (firstname IS NULL AND lastname IS NULL AND dob IS NULL AND ssn IS NULL) THEN '0'
         ELSE '1'
       END AS demo_valid
FROM final_output
WHERE (coverageid IS NOT NULL OR TRIM(coverageid) <> '')
""")
final_output = final_output.filter("demo_valid='1'").drop("demo_valid").filter("hospitalfk IS NOT NULL").dropDuplicates()
# print("Number of records in final_output: " + str(final_output.count()))


final_output.createOrReplaceTempView("final_output")

participating_hospitals = final_output.selectExpr("hospitalfk").dropDuplicates()

participating_permid=final_output.filter("permid IS NOT NULL").selectExpr("permid","matchind","hospitalfk").dropDuplicates()
participating_gmrnid=final_output.filter("gmrnid IS NOT NULL").selectExpr("gmrnid","hospitalfk").dropDuplicates()

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import rank

# COMMAND ----------

# DBTITLE 1,patientaccts
patientaccts = spark.read.format("delta").load(baseurl + "/data/dataingestion/publish/patientaccts/current/20991231/")
patientaccts = patientaccts.selectExpr("patientacctipk as patientacctifk","hospitalfk","ssn","createdate","acctnum","admitdate","dischargedate","totalcharges")
patientaccts = patientaccts.join(participating_hospitals,(patientaccts.hospitalfk == participating_hospitals.hospitalfk),"inner").select(patientaccts["*"])
patientaccts = patientaccts.withColumn('totalcharges', patientaccts.totalcharges.cast("decimal(32,2)"))
patientaccts = patientaccts.filter("totalcharges >= 0.01")

# COMMAND ----------

patientaccts_w_ssn = patientaccts.filter("ssn IS NOT NULL")
patientaccts_w_ssn.createOrReplaceTempView("patientaccts_w_ssn")
patientaccts_w_ssn = spark.sql(
"""
SELECT patientacctifk,
       ssn,
       hospitalfk,
       acctnum,
       createdate,
       admitdate,
       dischargedate,
       totalcharges,
       RANK() OVER (PARTITION BY hospitalfk,ssn ORDER BY admitdate DESC,acctnum DESC) AS rnk
FROM patientaccts_w_ssn
"""
).filter("rnk=='1'").drop("rnk").dropDuplicates()
patientaccts_w_ssn = patientaccts_w_ssn.selectExpr("patientacctifk","ssn","hospitalfk").dropDuplicates()
patientaccts_w_ssn.createOrReplaceTempView("patientaccts_w_ssn")

# COMMAND ----------

# DBTITLE 1,permidpatientacctid
permidpatientacctid = (
    spark.read.format("parquet")
    .load(baseurl + "/data/cdd/publish/permidpatientacctid/*/")
    .filter("matchind=='IM'")
    .selectExpr("patientacctifk", "permid", "matchind","hospitalfk")
)

permidpatientacctid = permidpatientacctid.join(
    participating_permid,
    (permidpatientacctid.matchind == participating_permid.matchind)
    & (permidpatientacctid.permid == participating_permid.permid)
    & (permidpatientacctid.hospitalfk == participating_permid.hospitalfk),
    "inner",
).select(permidpatientacctid["*"]).dropDuplicates()

permidpatientacctid = (
    permidpatientacctid.join(
        patientaccts,
        (permidpatientacctid.patientacctifk == patientaccts.patientacctifk) & (permidpatientacctid.hospitalfk == patientaccts.hospitalfk),
        "inner",
    )
    .select(
        permidpatientacctid["*"],
        # patientaccts["hospitalfk"], hospitalfk comes from dataframe permidpatientacctid so commenting out this expression
        patientaccts["acctnum"],
        patientaccts["createdate"],
        patientaccts["admitdate"],
        patientaccts["dischargedate"],
        patientaccts["totalcharges"],
    )
    .dropDuplicates()
)

permidpatientacctid = permidpatientacctid.withColumn(
    "dd_priority", when(col("dischargedate").isNull(), lit(1)).otherwise(0)
)
permidpatientacctid.createOrReplaceTempView("permidpatientacctid")

permidpatientacctid = spark.sql(
    """
SELECT patientacctifk,
       permid,
       matchind,
       hospitalfk,
       acctnum,
       createdate,
       admitdate,
       dischargedate,
       totalcharges,
       dd_priority,
       RANK() OVER (PARTITION BY permid,matchind,hospitalfk ORDER BY dd_priority DESC,admitdate DESC,acctnum DESC) AS rnk
FROM permidpatientacctid                              
"""
)
#permidpatientacctid.display()
permidpatientacctid = (
    permidpatientacctid.filter("rnk=='1'").drop("rnk", "dd_priority").dropDuplicates()
)
permidpatientacctid.repartition(100).write.mode("overwrite").parquet(path_temp_05)
permidpatientacctid.unpersist()

# COMMAND ----------

# permidpatientacctid=spark.read.parquet(path_temp_05)
# permidpatientacctid.createOrReplaceTempView("permidpatientacctid")
# spark.sql(""" SELECT hospitalfk,matchind,permid,count(*) FROM permidpatientacctid GROUP BY hospitalfk,matchind,permid HAVING COUNT(*) > 1 """).display()

# COMMAND ----------

globalmrnxpacct = (
    spark.read.format("parquet")
    .load(baseurl + "/data/gmrn/publish/globalmrnxpacct/current/*")
    .selectExpr("patientacctifk", "globalmrnifk", "hospitalfk")
)
globalmrnxpacct = (
    globalmrnxpacct.join(
        participating_gmrnid,
        (globalmrnxpacct.hospitalfk == participating_gmrnid.hospitalfk)
        & (globalmrnxpacct.globalmrnifk == participating_gmrnid.gmrnid),
        "inner",
    )
    .select(globalmrnxpacct["*"])
    .dropDuplicates()
)

globalmrnxpacct = (
    globalmrnxpacct.join(
        patientaccts,
        (globalmrnxpacct.hospitalfk == patientaccts.hospitalfk)
        & (globalmrnxpacct.patientacctifk == patientaccts.patientacctifk),
        "inner",
    )
    .select(
        globalmrnxpacct["*"],
        patientaccts["acctnum"],
        patientaccts["createdate"],
        patientaccts["admitdate"],
        patientaccts["dischargedate"],
        patientaccts["totalcharges"],
    )
    .dropDuplicates()
)
globalmrnxpacct = globalmrnxpacct.withColumn(
    "dd_priority", when(col("dischargedate").isNull(), lit(1)).otherwise(0)
)
globalmrnxpacct.createOrReplaceTempView("globalmrnxpacct")

globalmrnxpacct = spark.sql(
    """
SELECT patientacctifk,
       globalmrnifk,
       hospitalfk,
       acctnum,
       createdate,
       admitdate,
       dischargedate,
       totalcharges,
       dd_priority,
       RANK() OVER (PARTITION BY hospitalfk,globalmrnifk ORDER BY dd_priority DESC,admitdate DESC,acctnum DESC) AS rnk
FROM globalmrnxpacct                         
"""
)

globalmrnxpacct = (
    globalmrnxpacct.filter("rnk=='1'").drop("rnk", "dd_priority").dropDuplicates()
)
globalmrnxpacct.repartition(100).write.mode("overwrite").parquet(path_temp_06)
globalmrnxpacct.unpersist()

# COMMAND ----------

permidpatientacctid=spark.read.parquet(path_temp_05)
permidpatientacctid.createOrReplaceTempView("permidpatientacctid")

globalmrnxpacct = spark.read.parquet(path_temp_06)
globalmrnxpacct.createOrReplaceTempView("globalmrnxpacct")

# COMMAND ----------

final_output = spark.sql(
    """
SELECT 
  final_output.*,
  CASE WHEN final_output.gmrnid_flag='1' AND globalmrnxpacct.patientacctifk     IS NOT NULL THEN globalmrnxpacct.patientacctifk     ELSE NULL END AS g_patientacctifk,
  CASE WHEN final_output.permid_flag='1' AND permidpatientacctid.patientacctifk IS NOT NULL THEN permidpatientacctid.patientacctifk ELSE NULL END AS p_patientacctifk,
  CASE WHEN final_output.ssn_flag='1'    AND patientaccts_w_ssn.patientacctifk  IS NOT NULL THEN patientaccts_w_ssn.patientacctifk  ELSE NULL END AS s_patientacctifk
FROM final_output
  LEFT JOIN globalmrnxpacct
         ON final_output.hospitalfk = globalmrnxpacct.hospitalfk
        AND final_output.gmrnid = globalmrnxpacct.globalmrnifk
  LEFT JOIN permidpatientacctid
         ON final_output.hospitalfk = permidpatientacctid.hospitalfk
        AND final_output.matchind = permidpatientacctid.matchind
        AND final_output.permid = permidpatientacctid.permid
  LEFT JOIN patientaccts_w_ssn
         ON final_output.hospitalfk = patientaccts_w_ssn.hospitalfk
        AND CAST(final_output.ssn AS BIGINT) = CAST(patientaccts_w_ssn.ssn AS BIGINT)
"""
)
# final_output.display()

final_output.createOrReplaceTempView("final_output")
final_output = spark.sql(
    """
SELECT final_output.*,
       CASE
         WHEN g_patientacctifk IS NOT NULL                                                           THEN g_patientacctifk
         WHEN g_patientacctifk IS NULL AND s_patientacctifk IS NOT NULL                              THEN s_patientacctifk
         WHEN g_patientacctifk IS NULL AND s_patientacctifk IS NULL AND p_patientacctifk IS NOT NULL THEN p_patientacctifk
         WHEN g_patientacctifk IS NULL AND p_patientacctifk IS NULL AND s_patientacctifk IS NULL     THEN NULL
         ELSE NULL
       END AS patientacctifk
FROM final_output     
"""
)

final_output = (
    final_output.drop("g_patientacctifk")
    .drop("p_patientacctifk")
    .drop("permid_flag")
    .drop("gmrnid_flag")
    .drop("s_patientacctifk")
    .drop("ssn_flag")
    .dropDuplicates()
)

# final_output.display()
final_output.write.mode("overwrite").parquet(path_temp_07)
final_output.unpersist()

# COMMAND ----------

data=spark.read.parquet(path_temp_07).dropDuplicates()
# print("Count : data : " + "{:,}".format(data.count()))
data.createOrReplaceTempView("data")

# COMMAND ----------

# DBTITLE 1,DRAC COLUMNS
filterExpr1 = "lr_creatingmodule==" + "'" + chc_bc + "'"
chc_publish = spark.read.parquet(chc_path_publish).filter(filterExpr1)
chc_publish = chc_publish.selectExpr(
    "lr_creatingmodule",
    "transactionkey_row",
    "transactionkey_sub",
    "transactionkey_dep",
    "relationcode",
    "source",
    "system",
    "alternate_id1",
    "alternate_id2",
    "employername",
    "employeraddress1",
    "employeraddress2",
    "employercity",
    "employerstate",
    "employer_zip",
    "employerstatus",
)
chc_publish_sub = chc_publish.selectExpr(
    "lr_creatingmodule",
    "transactionkey_row",
    "transactionkey_sub as transactionkey",
    "0  AS dependentflag",
    "'' AS relationcode",
    "source",
    "system",
    "alternate_id1",
    "alternate_id2",
    "employername",
    "employeraddress1",
    "employeraddress2",
    "employercity",
    "employerstate",
    "employer_zip",
    "employerstatus",
).dropDuplicates()
chc_publish_dep = chc_publish.selectExpr(
    "lr_creatingmodule",
    "transactionkey_row",
    "transactionkey_dep as transactionkey",
    "1 AS dependentflag",
    "relationcode",
    "source",
    "system",
    "alternate_id1",
    "alternate_id2",
    "employername",
    "employeraddress1",
    "employeraddress2",
    "employercity",
    "employerstate",
    "employer_zip",
    "employerstatus",
).dropDuplicates()
chc_publish_combined = chc_publish_sub.union(chc_publish_dep)
chc_publish_combined.createOrReplaceTempView("chc_publish_combined")

data = spark.sql("""
SELECT data.*,
       chc_publish_combined.relationcode,
       chc_publish_combined.source,
       chc_publish_combined.system,
       chc_publish_combined.alternate_id1,
       chc_publish_combined.alternate_id2,
       chc_publish_combined.employername,
       chc_publish_combined.employeraddress1,
       chc_publish_combined.employeraddress2,
       chc_publish_combined.employercity,
       chc_publish_combined.employerstate,
       chc_publish_combined.employer_zip as employerzip,
       chc_publish_combined.employerstatus
FROM data
  LEFT JOIN chc_publish_combined
         ON data.lr_creatingmodule = chc_publish_combined.lr_creatingmodule
        AND data.transactionkey_row = chc_publish_combined.transactionkey_row
        AND data.transactionkey = chc_publish_combined.transactionkey
        AND data.dependentflag = chc_publish_combined.dependentflag
""")
data = data.dropDuplicates()

# COMMAND ----------

uniq_transactionkey=data.selectExpr("transactionkey").dropDuplicates()
# print("Count : data : uniq transactionkey :" + "{:,}".format(uniq_transactionkey.count()))

uniq_transactionkey_notnull_pa=uniq_transactionkey.filter("patientacctifk IS NOT NULL").selectExpr("transactionkey").dropDuplicates()
# print("Count : data : uniq transactionkey : with PA" + "{:,}".format(uniq_transactionkey_notnull_pa.count()))

# COMMAND ----------

input_tablename = "insights.dbo.importfiledatacarrierrecords"
data.write.format("jdbc").mode("append").option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver").option("url", input_jdbc_conn).option("dbtable", input_tablename).save()
data.unpersist()

# COMMAND ----------


