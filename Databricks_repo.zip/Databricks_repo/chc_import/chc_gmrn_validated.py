# Databricks notebook source
import sys
from pyspark.sql.functions import *
from pyspark.sql.types import *
import datetime
from pyspark.sql.functions import substring,coalesce
from pyspark.sql.window import Window
from delta import *

# COMMAND ----------

#SAMPLE INPUT 
# bc="20250410T02"
# hdfs_dataingestion_input="/data/dataingestion/publish/"
# hdfs_output="/data/chc/staging/staged_all/staged_globalmrndemographics/20250410T02/"
# hdfs_permid_input="/data/cdd/publish/permidpatientacctid/*"
# storageaccount="prodicdstgdls"
# hdfs_gmrn_publish="/data/gmrn/publish/"
# container="prod-icd-stg-adls"
# user="maxc"

# COMMAND ----------

datetime.datetime.today().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]

# COMMAND ----------

dbutils.widgets.text("bc", "")
bc= dbutils.widgets.get("bc")

dbutils.widgets.text('storageaccount','')
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text('container','')
container = dbutils.widgets.get("container")

dbutils.widgets.text('user','')
user = dbutils.widgets.get("user")

dbutils.widgets.text("hdfs_dataingestion_input","")
hdfs_dataingestion_input= dbutils.widgets.get("hdfs_dataingestion_input")

dbutils.widgets.text("hdfs_gmrn_publish","")
hdfs_gmrn_publish= dbutils.widgets.get("hdfs_gmrn_publish")

dbutils.widgets.text("hdfs_output", "")
hdfs_output= dbutils.widgets.get("hdfs_output")

dbutils.widgets.text("hdfs_permid_input", "")
hdfs_permid_input= dbutils.widgets.get("hdfs_permid_input")


# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user

# COMMAND ----------

hdfs_dataingestion_input = baseurl+ hdfs_dataingestion_input
hdfs_gmrn_publish = baseurl+ hdfs_gmrn_publish
hdfs_output = baseurl+ hdfs_output
hdfs_permid_input = baseurl+ hdfs_permid_input

# COMMAND ----------

spark.conf.set("spark.sql.shuffle.partitions","auto")
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/tu_data_quality"

# COMMAND ----------

isValidPolicy_udf = udf(isValidPolicy, IntegerType())
isValidMRN_udf = udf(isValidMRN, IntegerType())

# COMMAND ----------

policyid = spark.read.parquet(hdfs_gmrn_publish + "/globalmrnxhospinsurancecodes/current/*").select("globalmrnifk", "inspolicyid").dropDuplicates()
for column in policyid.columns:
    policyid = policyid.withColumn(column, regexp_replace(col(column), r'[^\x00-\x7f]', r''))
    policyid = policyid.withColumn(column, trim(col(column)))

policyid = policyid.withColumn('inspolicyid', regexp_replace(policyid.inspolicyid, '[^A-Za-z0-9]', ''))
policyid = policyid.withColumn('policyid_valid', isValidPolicy_udf(policyid.inspolicyid))
policyid = policyid.filter(~policyid.inspolicyid.like("%000000"))
policyid = policyid.dropDuplicates().filter(policyid.policyid_valid == 1)
policyidlist = policyid.groupBy("globalmrnifk").agg(collect_set("inspolicyid").alias("policyid"))
policyidlist.createOrReplaceTempView("policyidlist")

# COMMAND ----------

gdemo = spark.read.parquet(hdfs_gmrn_publish + "/globalmrndemographics/current/*")
gdemo = gdemo.filter(gdemo.ignoreflag != '1')

for column in gdemo.columns:
    gdemo = gdemo.withColumn(column, regexp_replace(col(column), r'[^\x00-\x7f]', r''))
    gdemo = gdemo.withColumn(column, trim(col(column)))

gdemo.createOrReplaceTempView("globalmrndemographics")

# COMMAND ----------

pa = DeltaTable.forPath(spark,hdfs_dataingestion_input + "/patientaccts/current/20991231/").toDF().select('patientacctipk', 'hospitalfk', 'medicalrecnum').dropDuplicates()
pa.createOrReplaceTempView("patientaccts")

# COMMAND ----------

gmrnxpa = spark.read.parquet(hdfs_gmrn_publish + "/globalmrnxpacct/current/*").select('globalmrnifk','hospitalfk','patientacctifk').dropDuplicates()
gmrnxpa.createOrReplaceTempView("globalmrnxpacct")

# COMMAND ----------

permid = spark.read.option("recursiveFileLookup","true").parquet(hdfs_permid_input).dropDuplicates()
hh = permid.filter((permid.matchind == 'HM') | (permid.matchind == 'IM')) \
    .select('permid', 'magnetpermid').dropDuplicates()

hh = hh.groupBy("permid").agg(collect_set("magnetpermid").alias("hhlist"))
hh.createOrReplaceTempView("hhview")

permid = permid.filter(permid.matchind == 'IM').select('patientacctifk', 'hospitalfk', 'permid')
permid.createOrReplaceTempView("patientacctxpermid")


# COMMAND ----------

# Create MRN list
mrnlist = (pa.join(gmrnxpa, (pa.patientacctipk == gmrnxpa.patientacctifk) & (pa.hospitalfk == gmrnxpa.hospitalfk ), "inner")
           .select(gmrnxpa.globalmrnifk, pa.patientacctipk, pa.hospitalfk, pa.medicalrecnum)
        )
        
mrnlist = mrnlist.withColumn('mrn_valid', isValidMRN_udf(mrnlist.medicalrecnum))
mrnlist = mrnlist.dropDuplicates().filter(mrnlist.mrn_valid == 1)
mrnlist = (mrnlist 
    .select("globalmrnifk", concat_ws('~', mrnlist.hospitalfk, mrnlist.medicalrecnum)
            .alias("mrn_ids"))
)
mrnlist = mrnlist.groupBy("globalmrnifk").agg(collect_set("mrn_ids").alias("mrnlist"))
mrnlist.createOrReplaceTempView("gmrnxmrnlist")


# COMMAND ----------

globalSQL = """
SELECT  DISTINCT g.globalmrnifk,  pp.permid
FROM globalmrnxpacct g
LEFT JOIN patientacctxpermid pp ON g.patientacctifk=pp.patientacctifk AND g.hospitalfk = pp.hospitalfk
"""

df1 = spark.sql(globalSQL)

df1.createOrReplaceTempView("permid")

# COMMAND ----------

SQL2 = """
SELECT p.globalmrnifk,  p.permid, hv.hhlist
FROM permid p
LEFT JOIN hhview hv ON hv.permid=p.permid
"""

df2 = spark.sql(SQL2)
df2.createOrReplaceTempView("permid2")


# COMMAND ----------

joinSQL = """
SELECT
  g.globalmrnifk,
  g.firstname as firstname,
  g.lastname as lastname,
  g.dob as dob,
  g.ssn as ssn,
  g.gender as gender,
  g.addr1 as addrnum,
  g.city as city,
  g.state as state,
  g.zip as zip,
  g.phone1 as phone,
  g.medicaidnum as medicaidnum,
  g.medicarehic as medicarehic,
  mlist.mrnlist as medicalrecnum,
  gpa.hhlist as hhpermid,
  policyidlist.policyid as policyid,
  gpa.permid
FROM permid2 gpa
INNER JOIN globalmrndemographics g ON g.globalmrnifk=gpa.globalmrnifk
LEFT JOIN gmrnxmrnlist mlist ON mlist.globalmrnifk=gpa.globalmrnifk
LEFT JOIN policyidlist ON policyidlist.globalmrnifk=gpa.globalmrnifk
"""

pd = spark.sql(joinSQL)

# COMMAND ----------

# Trim and remove non printable characters
for column in pd.columns:
    if (column != "medicalrecnum" and column != "policyid" and column != "hhpermid"):
        pd = pd.withColumn(column, regexp_replace(col(column), r'[^\x00-\x7f]', r''))
        pd = pd.withColumn(column, trim(col(column)))

# COMMAND ----------

# Create validation UDF functions
isValidName_udf = udf(isValidName, IntegerType())
isValidDOB_udf = udf(isValidDOB, IntegerType())
isValidSSN_udf = udf(isValidSSN, IntegerType())
isValidGender_udf = udf(isValidGender, IntegerType())
isValidCity_udf = udf(isValidCity, IntegerType())
isValidState_udf = udf(isValidState, IntegerType())
isValidZip_udf = udf(isValidZip, IntegerType())
isValidPhone_udf = udf(isValidPhone, IntegerType())
isValidString_udf = udf(isValidString, IntegerType())
isValidMCD_udf = udf(isValidMCD, IntegerType())
isValidMCR_udf = udf(isValidMCR, IntegerType())
isValidPID_udf = udf(isValidPID, IntegerType())
isValidNumber_udf = udf(isNumber, IntegerType())


# COMMAND ----------

# cleanse and trim

pd = pd.withColumn('firstname', upper(pd.firstname))
pd = pd.withColumn('lastname', upper(pd.lastname))
pd = pd.withColumn('gender', upper(pd.gender))
pd = pd.withColumn('city', upper(pd.city))
pd = pd.withColumn('state', upper(pd.state))

pd = pd.withColumn('addrnum', regexp_extract(pd.addrnum, '\d+', 0))
pd = pd.withColumn('zip', regexp_extract(pd.zip, '\d\d\d\d\d', 0))
pd = pd.withColumn('phone', regexp_replace(pd.phone, '[^0-9]', ''))
pd = pd.withColumn('dob', regexp_extract(pd.dob, '\d+-\d+-\d+', 0))
pd = pd.withColumn('city', regexp_replace(pd.city, '[^A-Za-z\s]', ''))
pd = pd.withColumn('city', regexp_replace(pd.city, 'XX', ''))
pd = pd.withColumn('city', regexp_replace(pd.city, 'YY', ''))
pd = pd.withColumn('city', trim(pd.city))
pd = pd.withColumn('state', regexp_replace(pd.state, 'XX', ''))
pd = pd.withColumn('state', regexp_replace(pd.state, 'YY', ''))
pd = pd.withColumn('state', regexp_replace(pd.state, '[^A-Za-z\s]', ''))
pd = pd.withColumn('state', trim(pd.state))

# COMMAND ----------

# add validation columns
pd = pd.withColumn('fn_valid', isValidName_udf(pd.firstname))
pd = pd.withColumn('ln_valid', isValidName_udf(pd.lastname))
pd = pd.withColumn('dob_valid', isValidDOB_udf(pd.dob))
pd = pd.withColumn('gender_valid', isValidGender_udf(pd.gender))
pd = pd.withColumn('ssn_valid', isValidSSN_udf(pd.ssn))
pd = pd.withColumn('city_valid', isValidCity_udf(pd.city))
pd = pd.withColumn('state_valid', isValidState_udf(pd.state))
pd = pd.withColumn('zip_valid', isValidZip_udf(pd.zip))
pd = pd.withColumn('phone_valid', isValidPhone_udf(pd.phone))

new_mrn_valid = when(col("medicalrecnum").isNull(), 0).otherwise(1)
pd = pd.withColumn('mrn_valid', new_mrn_valid)

new_policy_valid = when(col("policyid").isNull(), 0).otherwise(1)
pd = pd.withColumn('policyid_valid', new_policy_valid)

new_hh_valid = when(col("hhpermid").isNull(), 0).otherwise(1)
pd = pd.withColumn('hhpermid_valid', new_hh_valid)

pd = pd.withColumn('mcr_valid', isValidMCR_udf(pd.medicarehic))
pd = pd.withColumn('mcd_valid', isValidMCD_udf(pd.medicaidnum))
pd = pd.withColumn('pid_valid', isValidPID_udf(pd.permid))
pd = pd.withColumn('addrnum_valid', isValidNumber_udf(pd.addrnum))

# COMMAND ----------

# save to folder
# display(pd)

# pd.dropDuplicates().write.mode("overwrite").parquet(hdfs_output)

# COMMAND ----------
workflowtype="chc"
tableName = f"{workflowtype}_staged_globalmrndemographics_{bc}"
dropSql = f"DROP TABLE IF EXISTS {tableName}"
cluterBySql = f"ALTER TABLE {tableName} CLUSTER BY (state, city, dob, firstname)"
optimizeSql = f"OPTIMIZE {tableName}"
spark.sql(dropSql)
pd.dropDuplicates().write.mode("overwrite").format("delta").option("path", hdfs_output + bc).saveAsTable(tableName)
spark.sql(cluterBySql)
spark.sql(optimizeSql)

dbutils.notebook.exit({"stagedGlobalmrndemographicsTableName": tableName})

# COMMAND ----------


