# Databricks notebook source
import sys
import os
import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
from pyspark import SparkContext
from pyspark.conf import SparkConf
import subprocess
from  pyspark.sql.functions import input_file_name

# COMMAND ----------

dbutils.widgets.text('input_bc','')
input_bc = dbutils.widgets.get("input_bc")

dbutils.widgets.text('input_frombcs_parquet','')
input_frombcs_parquet = dbutils.widgets.get("input_frombcs_parquet")



dbutils.widgets.text('input_frombcs_fixed','')
input_frombcs_fixed = dbutils.widgets.get("input_frombcs_fixed")

dbutils.widgets.text('storageaccount','')
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text('container','')
container = dbutils.widgets.get("container")



dbutils.widgets.text('user','')
user = dbutils.widgets.get("user")

# COMMAND ----------

if user=='na':
    username=""
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'+"/"+username+"/"
else :
    username=user
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'+"/"+username+"/"


print("user= "+ user+" username= "+username)
print("baseurl= "+ baseurl)

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------


input_frombcs_parquet=baseurl+"/"+input_frombcs_parquet+"/"+input_bc
input_frombcs_fixed=baseurl+"/"+input_frombcs_fixed+"/"+input_bc

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
postBDF = spark.read.text(input_frombcs_fixed+'/*_cbeMatchAppend.dat')
postBDF = postBDF.select(
		col("value").substr(1,64).alias("PatientAcctId"),
		col("value").substr(65,50).alias("FN"),
		col("value").substr(115,50).alias("MN"),
		col("value").substr(165,50).alias("LN"),
		col("value").substr(215,1).alias("Gender"),
		col("value").substr(216,9).alias("SSN"),
		col("value").substr(225,10).alias("DOB"),
		col("value").substr(235,75).alias("Address1"),
		col("value").substr(310,75).alias("Address2"),
		col("value").substr(385,30).alias("City"),
		col("value").substr(415,2).alias("State"),
		col("value").substr(417,5).alias("Zip"),
		col("value").substr(422,5).alias("Zip4"),
		col("value").substr(427,20).alias("Phone"),
		col("value").substr(447,32).alias("Custom1"),
		col("value").substr(479,64).alias("Custom2"),
		col("value").substr(543,3).alias("FileNum"),
		col("value").substr(546,12).alias("RecordNum"),
		col("value").substr(558,12).alias("MagnetPermId"),
		col("value").substr(570,12).alias("PermId"),
		col("value").substr(582,2).alias("MatchInd"),
		col("value").substr(584,12).alias("LinkId")
		)

postBDF = postBDF.select(
		trim(col("PatientAcctId")).alias("PatientAcctId"),
		trim(col("FN")).alias("FN"),
		trim(col("MN")).alias("MN"),
		trim(col("LN")).alias("LN"),
		trim(col("Gender")).alias("Gender"),
		trim(col("SSN")).alias("SSN"),
		trim(col("DOB")).alias("DOB"),
		trim(col("Address1")).alias("Address1"),
		trim(col("Address2")).alias("Address2"),
		trim(col("City")).alias("City"),
		trim(col("State")).alias("State"),
		trim(col("Zip")).alias("Zip"),
		trim(col("Zip4")).alias("Zip4"),
		trim(col("Phone")).alias("Phone"),
        trim(col("Custom1")).alias("Custom1"),
		trim(col("Custom2")).alias("Custom2"),
		trim(col("Custom2")).alias("BreadCrumbs"),
		trim(col("FileNum")).alias("FileNum"),
		trim(col("RecordNum")).alias("RecordNum"),
		trim(col("MagnetPermId")).alias("MagnetPermId"),
		trim(col("PermId")).alias("PermId"),
		trim(col("MatchInd")).alias("MatchInd"),
		trim(col("LinkId")).alias("LinkId")
		)

distinctVisitIdPermId = postBDF.select("PermId","PatientAcctId","MatchInd","MagnetPermId","Custom1","Custom2").dropDuplicates()

distinctVisitIdPermId.repartition(10).write.mode("append").parquet(input_frombcs_parquet)