# Databricks notebook source
import sys
import os
import math
from datetime import datetime
from pyspark.storagelevel import StorageLevel
from datetime import datetime
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import re
from collections import deque
from delta.tables import *

# COMMAND ----------

dbutils.widgets.text('storageaccount','')
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text('container','')
container = dbutils.widgets.get("container")

dbutils.widgets.text('user','')
user = dbutils.widgets.get("user")

dbutils.widgets.text('chc_bc','')
chc_bc = dbutils.widgets.get("chc_bc")

dbutils.widgets.text('input_publish','')
input_publish = dbutils.widgets.get("input_publish")

dbutils.widgets.text('input_transaction','')
input_transaction = dbutils.widgets.get("input_transaction")

dbutils.widgets.text('input_gmrn_mergedecisions','')
input_gmrn_mergedecisions = dbutils.widgets.get("input_gmrn_mergedecisions")

dbutils.widgets.text('op_chc_lr_xref_gmrnid_transaction','')
op_chc_lr_xref_gmrnid_transaction = dbutils.widgets.get("op_chc_lr_xref_gmrnid_transaction")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user=='na':
    username=""
else :
    username=user

print("user= "+ user+" username= "+username)

# COMMAND ----------

if username=='':
    print("RUNNING AS PROD USER")
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else :
    print("RUNNING AS LOCAL USER "+username)
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+username

input_publish=baseurl+input_publish
input_transaction=baseurl+input_transaction
input_gmrn_mergedecisions=baseurl+input_gmrn_mergedecisions
input_gmrn_mergedecisions_assign = input_gmrn_mergedecisions + "/assign/"
op_chc_lr_xref_gmrnid_transaction=baseurl+op_chc_lr_xref_gmrnid_transaction

print("input_publish="+ input_publish)
print("input_transaction="+ input_transaction)
print("input_gmrn_mergedecisions_assign="+ input_gmrn_mergedecisions_assign)
print("op_chc_lr_xref_gmrnid_transaction="+ op_chc_lr_xref_gmrnid_transaction)
print("chc_bc="+ chc_bc)

# COMMAND ----------

# DBTITLE 1,Reading input_gmrn_mergedecisions_assign 
dedup_schema = StructType([
    StructField("uniq_hash256_pefld", StringType(), True),
    StructField("gmrnid", StringType(), True),
    StructField("gmrnmatchind", StringType(), True)   
    ])
gmrnid = spark.read.format("csv").schema(dedup_schema).options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", delimiter="|").load(input_gmrn_mergedecisions_assign).dropDuplicates()

# gmrnid = gmrnid.withColumnRenamed('_c0', 'uniq_hash256_pefld') \
#                .withColumnRenamed('_c1', 'gmrnid') \
#                .withColumnRenamed('_c2', 'gmrnmatchind') \
#                .selectExpr("uniq_hash256_pefld", "gmrnid", "gmrnmatchind").dropDuplicates()

gmrnid.createOrReplaceTempView("gmrnid")

# COMMAND ----------

# DBTITLE 1,Reading input_transaction and input_publish
filterExpr = "lr_creatingmodule==" + "'" + chc_bc + "'"
filterExpr_p = "bc==" + "'" + chc_bc + "'"

trans = spark.read.parquet(input_transaction).filter(filterExpr).selectExpr("transactionkey_row","transactionkey","dependentflag","lr_createdate", "lr_creatingmodule").dropDuplicates()
publish = spark.read.parquet(input_publish).filter(filterExpr_p).selectExpr("transactionkey_row","uniq_sub_hash256_pefld","uniq_dep_hash256_pefld","bc").dropDuplicates()

trans.createOrReplaceTempView("trans")
publish.createOrReplaceTempView("publish")

# COMMAND ----------

# DBTITLE 1,Generating GMRNID_XREF data
sql_trans_x_publish="""
SELECT trans.transactionkey_row,
       trans.transactionkey,
       trans.lr_createdate,
       trans.lr_creatingmodule,
       publish.uniq_sub_hash256_pefld AS uniq_hash256_pefld
FROM (SELECT * FROM trans WHERE dependentflag = '0') trans
  INNER JOIN publish
          ON CAST (trans.transactionkey AS BIGINT) = CAST(CONCAT(publish.transactionkey_row,'0') AS BIGINT)
         AND trans.lr_creatingmodule = publish.bc
UNION ALL
SELECT trans.transactionkey_row,
       trans.transactionkey,
       trans.lr_createdate,
       trans.lr_creatingmodule,
       publish.uniq_dep_hash256_pefld AS uniq_hash256_pefld
FROM (SELECT * FROM trans WHERE dependentflag = '1') trans
  INNER JOIN publish
          ON CAST (trans.transactionkey AS BIGINT) = CAST(CONCAT(publish.transactionkey_row,'1') AS BIGINT)
         AND trans.lr_creatingmodule = publish.bc
"""

trans=spark.sql(sql_trans_x_publish).dropDuplicates()
trans.createOrReplaceTempView("trans")

gmrlsql = """
SELECT trans.transactionkey_row                                           AS transactionkey_row,
       trans.transactionkey                                               AS transactionkey,
       trans.lr_creatingmodule                                            AS lr_creatingmodule,
       CONCAT(trans.transactionkey,"~",lr_creatingmodule)                 AS audittrail,
       gmrnid.gmrnid                                                      AS gmrnid ,
       '3'                                                                AS sourcekey,
       'm2'                                                               AS xrefsource,
       trans.lr_createdate                                                AS lr_createdate,
       concat(gmrnid.gmrnid,"-",trans.transactionkey,"-","3")             AS `_id`,
       gmrnid.gmrnmatchind     
FROM trans
  INNER JOIN gmrnid 
  ON TRIM (trans.uniq_hash256_pefld) = TRIM (gmrnid.uniq_hash256_pefld)
"""
output = spark.sql(gmrlsql).dropDuplicates()

#logic to keep _id unique within the batch 
output.createOrReplaceTempView("output")
output = spark.sql("""SELECT output.*, CASE WHEN UPPER(output.xrefsource) = 'IM' THEN '1' ELSE '2' END AS p_xrefsource FROM output""")#this can be removed later, if gmrnid match xrefsource always 'm2'
output.createOrReplaceTempView("output")
output = spark.sql("""SELECT output.*, 
                        ROW_NUMBER() OVER (PARTITION BY _id ORDER BY p_xrefsource ASC, gmrnmatchind ASC) AS RN
                        FROM output
                    """).filter("RN=='1'").drop("RN").drop("p_xrefsource")
#Merge to delta xref table
deltaTable = DeltaTable.forPath(spark, op_chc_lr_xref_gmrnid_transaction)
(
    deltaTable.alias("target")
    .merge(
        output.alias("source"),
        "target._id = source._id"
    )
    .whenMatchedUpdateAll()
    .whenNotMatchedInsertAll()
    .execute()
)
