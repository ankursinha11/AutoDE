# Databricks notebook source
# DBTITLE 1,define input variables
dbutils.widgets.text("datasource","")
dbutils.widgets.getArgument("datasource")
datasource= getArgument("datasource")

dbutils.widgets.text("input_tobcs_fixed", "")
dbutils.widgets.getArgument("input_tobcs_fixed")
input_tobcs_fixed= getArgument("input_tobcs_fixed")

dbutils.widgets.text("bc", "")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("output_path","")
dbutils.widgets.getArgument("output_path")
output_path= getArgument("output_path")


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

input_tobcs_fixed = baseurl+input_tobcs_fixed
output_path = baseurl+output_path

# COMMAND ----------

#nfs_dir=/shared/hdfs$cdd_dir 
# nfs_dir = cdd_dir+"/transform/"+datasource+"/package_bdf/"

nfs_dir = input_tobcs_fixed
# print(nfs_dir)

# COMMAND ----------

df_bdf = spark.read.text(input_tobcs_fixed+bc)

# COMMAND ----------

source_path = dbutils.fs.ls(input_tobcs_fixed+bc)

# COMMAND ----------

for file_name in source_path:
    if 'part' in file_name.path:
        print(file_name)
        dbutils.fs.cp(file_name.path, output_path+bc+'/merge/merge.txt' )

# COMMAND ----------

inputfilesize = 0
for i in dbutils.fs.ls(input_tobcs_fixed+bc):
    inputfilesize = inputfilesize+i.size

# COMMAND ----------

maxfilesize = 15000000000 #for 15GB
totalnooffiles = int(inputfilesize/maxfilesize)+1 # to write to multiple 15 GB files
# print(totalnooffiles)

# COMMAND ----------

df_bdf.repartition(totalnooffiles).write.mode("overwrite").option("maxPartitionBytes",maxfilesize).text(output_path+bc+'/merge_temp/')

# COMMAND ----------

for i in dbutils.fs.ls(output_path+bc+'/merge_temp/'):
    if 'part' in i.path and totalnooffiles >0:
        dbutils.fs.mv(i.path,output_path+bc+'/merge/'+"/"+"md_carri"+"-"+bc+'-'+str(totalnooffiles))
        totalnooffiles=totalnooffiles-1 