# Databricks notebook source
import sys
import os
import math
from datetime import datetime
from pyspark.storagelevel import StorageLevel
from datetime import datetime
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import re
from collections import deque
from delta.tables import *

# COMMAND ----------

# DBTITLE 1,STAGE
# chc_bc="20250410T02"
# input_frombcs_parquet="/data/chc/transform/frombcs_parquet/permIdPatientAcctId/"
# input_publish="/data/chc/publish/current/20991231/"
# input_transaction="/data/leadrepo/publish/cooked/chc_lr_transaction/"
# storageaccount="prodicdstgdls"
# op_chc_lr_xref_permid_transaction="/data/leadrepo/publish/cooked/chc_lr_xref_permid_transaction/"
# user="maxc"
# container="prod-icd-stg-adls"
# op_chc_publish_idxpermid="/data/chc/publish/idxpermid/medical_carrier/"

# COMMAND ----------

dbutils.widgets.text('storageaccount','')
storageaccount = dbutils.widgets.get("storageaccount")

dbutils.widgets.text('container','')
container = dbutils.widgets.get("container")

dbutils.widgets.text('user','')
user = dbutils.widgets.get("user")

dbutils.widgets.text('chc_bc','')
chc_bc = dbutils.widgets.get("chc_bc")

dbutils.widgets.text('input_frombcs_parquet','')
input_frombcs_parquet = dbutils.widgets.get("input_frombcs_parquet")

dbutils.widgets.text('input_publish','')
input_publish = dbutils.widgets.get("input_publish")

dbutils.widgets.text('input_transaction','')
input_transaction = dbutils.widgets.get("input_transaction")

dbutils.widgets.text('op_chc_lr_xref_permid_transaction','')
op_chc_lr_xref_permid_transaction = dbutils.widgets.get("op_chc_lr_xref_permid_transaction")

dbutils.widgets.text('op_chc_publish_idxpermid','')
op_chc_publish_idxpermid = dbutils.widgets.get("op_chc_publish_idxpermid")


# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user=='na':
    username=""
else :
    username=user

print("user= "+ user+" username= "+username)

# COMMAND ----------

if username=='':
    print("RUNNING AS PROD USER")
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else :
    print("RUNNING AS LOCAL USER "+username)
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+username

input_frombcs_parquet=baseurl+input_frombcs_parquet+chc_bc
input_publish=baseurl+input_publish
op_chc_publish_idxpermid=baseurl+op_chc_publish_idxpermid+chc_bc
op_chc_lr_xref_permid_transaction=baseurl+op_chc_lr_xref_permid_transaction


print("input_frombcs_parquet="+ input_frombcs_parquet)
print("input_publish="+ input_publish)
print("op_chc_publish_idxpermid="+ op_chc_publish_idxpermid)
print("op_chc_lr_xref_permid_transaction="+ op_chc_lr_xref_permid_transaction)
print("chc_bc="+ chc_bc)

# COMMAND ----------

# DBTITLE 1,df_chc_raw
filterExpr = "bc==" + "'" + chc_bc + "'"
df_chc_raw = spark.read.parquet(input_publish).filter(filterExpr)
df_chc_raw.createOrReplaceTempView("df_chc_raw")

# COMMAND ----------

# DBTITLE 1,chc_bcs
from pyspark.sql.functions import split
chc_bcs = spark.read.parquet(input_frombcs_parquet).filter("UPPER(TRIM(MatchInd))=='IM'").selectExpr("PatientAcctId", "Custom1", "Custom2", "MagnetPermId", "MatchInd", "PermId").dropDuplicates()
chc_bcs = chc_bcs.withColumn("eid", split(chc_bcs.Custom1, '\\_')[1])
chc_bcs.createOrReplaceTempView("chc_bcs")

# COMMAND ----------

# DBTITLE 1,Reading input_publish and input_frombcs_parquet
# DISABLED

# chc_bcs = spark.sql("""
# SELECT chc_bcs.*,
#        SPLIT(chc_bcs.Custom1,'\\_')[1] AS eid,
#        RANK() OVER (PARTITION BY chc_bcs.PatientAcctId,chc_bcs.Custom1,chc_bcs.Custom2 ORDER BY chc_bcs.MatchInd_rank ASC) AS rnk
# FROM (SELECT PatientAcctId,
#              Custom1,
#              Custom2,
#              MagnetPermId,
#              MatchInd,
#              PermId,
#              CASE
#                WHEN MatchInd = 'IM' THEN '1'
#                WHEN MatchInd = 'HM' THEN '2'
#              END AS MatchInd_rank
#       FROM chc_bcs) chc_bcs
# """).filter("rnk=='1'").drop("rnk").dropDuplicates()

# chc_bcs.createOrReplaceTempView("ch_bcs")

# COMMAND ----------

sql0001 = """
SELECT 
       df_chc_raw.rowid,
       df_chc_raw.transactionkey_row         AS transactionkey_row,
       chc_bcs.PatientAcctId                 AS transactionkey,
       df_chc_raw.uniq_sub_hash256_pefld     AS uniq_hash256_pefld,
       df_chc_raw.bc,
       df_chc_raw.eid,
       df_chc_raw.carrier,
       df_chc_raw.edipartnerfk,
       df_chc_raw.hospitalfk,
       df_chc_raw.hcsystemfk,
       chc_bcs.PermId                    AS permid,
       chc_bcs.MatchInd                  AS matchind,
       chc_bcs.MagnetPermId              AS magnetpermid
FROM df_chc_raw
  INNER JOIN chc_bcs
          ON TRIM (df_chc_raw.bc) = TRIM (chc_bcs.Custom2)
         AND TRIM (df_chc_raw.eid) = TRIM (chc_bcs.eid)
         AND CAST (CONCAT (df_chc_raw.transactionkey_row,'0') AS BIGINT) = CAST (chc_bcs.PatientAcctId AS BIGINT)
UNION ALL
SELECT df_chc_raw.rowid,
       df_chc_raw.transactionkey_row       AS transactionkey_row,
       chc_bcs.PatientAcctId               AS transactionkey,
       df_chc_raw.uniq_dep_hash256_pefld   AS uniq_hash256_pefld,
       df_chc_raw.bc,
       df_chc_raw.eid,  
       df_chc_raw.carrier,  
       df_chc_raw.edipartnerfk,  
       df_chc_raw.hospitalfk,  
       df_chc_raw.hcsystemfk,  
       chc_bcs.PermId                   AS permid,
       chc_bcs.MatchInd                 AS matchind,
       chc_bcs.MagnetPermId             AS magnetpermid
FROM df_chc_raw 
  INNER JOIN chc_bcs
          ON TRIM (df_chc_raw.bc) = TRIM (chc_bcs.Custom2)
         AND TRIM (df_chc_raw.eid) = TRIM (chc_bcs.eid)
         AND CAST (CONCAT (df_chc_raw.transactionkey_row,'1') AS BIGINT) = CAST (chc_bcs.PatientAcctId AS BIGINT)
"""
out = spark.sql(sql0001).dropDuplicates()
out.repartition(100).write.mode('overwrite').parquet(op_chc_publish_idxpermid)
out.unpersist()

# COMMAND ----------

# DBTITLE 1,Generating PERMID_XREF data
dt = datetime.today().strftime('%Y-%m-%dT%H:%M:%S.%f0-05:00')
dt = str(dt)

permid = spark.read.parquet(op_chc_publish_idxpermid)
permid.createOrReplaceTempView("permid")
permsql = """
SELECT 
       """ + "'" + dt + "'" + """          AS lr_createdate,       
       bc                                  AS lr_creatingmodule,
       permid                              AS permid,
       '3'                                 AS sourcekey,
       transactionkey                      AS transactionkey,
       transactionkey_row                  AS transactionkey_row,
       concat(permid,"-",transactionkey,"-","3") AS _id,
       CONCAT(permid,"~",bc)               AS audittrail,
       matchind                            AS xrefsource
FROM permid
"""
output = spark.sql(permsql).dropDuplicates()

#logic to keep _id unique within the batch 
output.createOrReplaceTempView("output")
output = spark.sql("""SELECT output.*, CASE WHEN UPPER(output.xrefsource) = 'IM' THEN '1' ELSE '2' END AS p_xrefsource FROM output""")
output.createOrReplaceTempView("output")
output = spark.sql("""SELECT output.*, 
                        ROW_NUMBER() OVER (PARTITION BY _id ORDER BY p_xrefsource ASC) AS RN
                        FROM output
                    """).filter("RN=='1'").drop("RN").drop("p_xrefsource")
                    
#Merge to delta xref table
deltaTable = DeltaTable.forPath(spark, op_chc_lr_xref_permid_transaction)
(
    deltaTable.alias("target")
    .merge(
        output.alias("source"),
        "target._id = source._id"
    )
    .whenMatchedUpdateAll()
    .whenNotMatchedInsertAll()
    .execute()
)
