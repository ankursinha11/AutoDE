# Databricks notebook source
import os
import sys
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
import datetime
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
from pyspark import SparkContext
from pyspark.conf import SparkConf
import subprocess
from  pyspark.sql.functions import input_file_name
from pyspark.sql.window import Window
from pyspark.sql.functions import row_number
import subprocess

# COMMAND ----------

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("columnname","")
dbutils.widgets.getArgument("columnname")
columnname= getArgument("columnname")

dbutils.widgets.text('cosmosEndpoint','')
cosmosEndpoint = dbutils.widgets.get("cosmosEndpoint")

dbutils.widgets.text('cosmosDatabaseName','')
cosmosDatabaseName = dbutils.widgets.get("cosmosDatabaseName")

dbutils.widgets.text('cosmosContainerName','')
cosmosContainerName = dbutils.widgets.get("cosmosContainerName")

# COMMAND ----------

spark.conf.set(
    "fs.azure.account.key." + storageaccount + ".dfs.core.windows.net",
    dbutils.secrets.get(
        scope="icd-insleads-dbwscope", key="icd-adls-insleads-kvsecret"
    ),
)

# COMMAND ----------

def writeToCosmos(dfWrite,Endpoint,MasterKey,DatabaseName,ContainerName):
    writeConf = {
    "spark.cosmos.accountEndpoint" : Endpoint,
    "spark.cosmos.accountKey" : MasterKey,
    "spark.cosmos.database" : DatabaseName,
    "spark.cosmos.container" : ContainerName,
    "spark.cosmos.write.strategy" : "ItemOverwrite"
}
    dfWrite.write.format('cosmos.oltp').options(**writeConf).mode('append').save()


def readFromCosmos(Endpoint,MasterKey,DatabaseName,ContainerName):
    readConf = {
    "spark.cosmos.accountEndpoint" : Endpoint,
    "spark.cosmos.accountKey" : MasterKey,
    "spark.cosmos.database" : DatabaseName,
    "spark.cosmos.container" : ContainerName
}
    df_read = spark.read.format("cosmos.oltp").options(**readConf).option("spark.cosmos.read.inferSchema.enabled", "true").load()
    return df_read


schema = StructType(
    [
        StructField("id", StringType(), True),
        StructField("bc", StringType(), True),
        StructField("published", StringType(), True),
        StructField("bcsupload", StringType(), True),
        StructField("bcsdownload", StringType(), True),
        StructField("permid", StringType(), True),
        StructField("gmrnid", StringType(), True),
    ]
)

if user == "na":
    username = ""
    baseurl = (
        "abfss://"
        + container
        + "@"
        + storageaccount
        + ".dfs.core.windows.net"
        + "/"
        + username
        + "/"
    )
else:
    username = user
    baseurl = (
        "abfss://"
        + container
        + "@"
        + storageaccount
        + ".dfs.core.windows.net"
        + "/"
        + username
        + "/"
    )


# print("user= "+ user+" username= "+username)
# print("baseurl= "+ baseurl)

cosmosMasterKey = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-cosmos-insleads-kvsecret")


print("cosmosEndpoint" + str(cosmosEndpoint))
print("cosmosMasterKey" + str(cosmosMasterKey))
print("cosmosDatabaseName" + str(cosmosDatabaseName))
print("cosmosContainerName" + str(cosmosContainerName))

# COMMAND ----------

if columnname == 'published':
    l = [(bc, bc, '1','0','0','0','0')]
    data = spark.createDataFrame(l, schema)
    data.show(10,False)
    writeToCosmos(data,cosmosEndpoint,cosmosMasterKey,cosmosDatabaseName,cosmosContainerName)
else :
    filterExpr="id=="+"'"+bc+"'"
    data = readFromCosmos(cosmosEndpoint,cosmosMasterKey,cosmosDatabaseName,cosmosContainerName).filter(filterExpr).withColumn(columnname,lit('1'))
    writeToCosmos(data,cosmosEndpoint,cosmosMasterKey,cosmosDatabaseName,cosmosContainerName)

# COMMAND ----------

#readFromCosmos(cosmosEndpoint,cosmosMasterKey,cosmosDatabaseName,cosmosContainerName).show(10,False)