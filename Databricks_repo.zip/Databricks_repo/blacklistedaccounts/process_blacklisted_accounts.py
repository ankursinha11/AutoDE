# Databricks notebook source
from pyspark.sql.functions import *
# container="prod-icd-adls"
# storageaccount="prodicddls"
# user="na"
# address_table="parsedaddress"
# data_ingestion_path="/data/dataingestion/publish/"
# gmrn_publish_path="/data/gmrn/publish/"
# email_table="privacyemails"
# icddb="zescantemp.dbo."
# legal_table="dontreportdatafromlegalteam"
# output_db="zescantemp.dbo."
# output_table="patientmatchingblockallowgmrn"
# phone_table="parsedphone"
# prod_confirm_table="productconfirmation"

# COMMAND ----------

# DBTITLE 1,Parameters
dbutils.widgets.text("phone_table", "")
dbutils.widgets.getArgument("phone_table")
phone_table = getArgument("phone_table")

dbutils.widgets.text("address_table", "")
dbutils.widgets.getArgument("address_table")
address_table = getArgument("address_table")

dbutils.widgets.text("email_table", "")
dbutils.widgets.getArgument("email_table")
email_table = getArgument("email_table")

dbutils.widgets.text("prod_confirm_table", "")
dbutils.widgets.getArgument("prod_confirm_table")
prod_confirm_table = getArgument("prod_confirm_table")

dbutils.widgets.text("legal_table", "")
dbutils.widgets.getArgument("legal_table")
legal_table = getArgument("legal_table")


dbutils.widgets.text("container", "")
dbutils.widgets.getArgument("container")
container = getArgument("container")

dbutils.widgets.text("storageaccount", "")
dbutils.widgets.getArgument("storageaccount")
storageaccount = getArgument("storageaccount")

dbutils.widgets.text("user", "")
dbutils.widgets.getArgument("user")
user = getArgument("user")

dbutils.widgets.text("icddb", "")
dbutils.widgets.getArgument("icddb")
icddb = getArgument("icddb")

dbutils.widgets.text("output_table", "")
dbutils.widgets.getArgument("output_table")
output_table = getArgument("output_table")

dbutils.widgets.text("output_db", "")
dbutils.widgets.getArgument("output_db")
output_db = getArgument("output_db")

dbutils.widgets.text("data_ingestion_path", "")
dbutils.widgets.getArgument("data_ingestion_path")
data_ingestion_path = getArgument("data_ingestion_path")

dbutils.widgets.text("gmrn_publish_path", "")
dbutils.widgets.getArgument("gmrn_publish_path")
gmrn_publish_path = getArgument("gmrn_publish_path")

# COMMAND ----------

# DBTITLE 1,Set config
spark.conf.set(
    "fs.azure.account.key." + storageaccount + ".dfs.core.windows.net",
    dbutils.secrets.get(
        scope="icd-insleads-dbwscope", key="icd-adls-insleads-kvsecret"
    ),
)

# COMMAND ----------

path_conn_file = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-compliance-db-sql-insleads-cs")
path_conn_file_out = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-dataingestion-sql-insleads-cs")

# COMMAND ----------

# DBTITLE 1,set basepath
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user



data_ingestion_path = baseurl + data_ingestion_path
gmrn_publish_path = baseurl + gmrn_publish_path
temp_rw = baseurl + "/data/blacklisted/temp_rw/"


print("baseurl             : "+str(baseurl))
print("data_ingestion_path : "+str(data_ingestion_path))
print("gmrn_publish_path   : "+str(gmrn_publish_path))
print("temp_rw             : "+str(temp_rw))

# COMMAND ----------

# DBTITLE 1,EXTRACTION AS IS
# phonequery       = f"""SELECT * FROM {icddb}{phone_table}"""
# addressquery     = f"""SELECT * from {icddb}{address_table}"""
# emailsquery      = f"""SELECT * from {icddb}{email_table}"""
# legalquery       = f"""SELECT * from {output_db}{legal_table}"""

phonequery  ="select * from compliance.dlpr_parse.parsedphone"
addressquery="select * from compliance.dlpr_parse.parsedaddress"
emailsquery ="select * from compliance.dlpr_read.privacyemails"
legalquery  ="select * from escan.dbo.dontreportdatafromlegalteam"
blockquery = "select * from escan.dbo.patientmatchingblockallowgmrn"

print("phonequery       : "+str(phonequery))
print("addressquery     : "+str(addressquery))
print("emailsquery      : "+str(emailsquery))
print("legalquery       : "+str(legalquery))
print("blockquery       : "+str(blockquery))


df_phone   = spark.read.format("jdbc").option("url", path_conn_file).option("query", phonequery).load()
df_phone.write.mode("overwrite").format("parquet").save(temp_rw+"/df_phone/")

df_address = spark.read.format("jdbc").option("url", path_conn_file).option("query", addressquery).load()
df_address.write.mode("overwrite").format("parquet").save(temp_rw+"/df_address/")

df_email   = spark.read.format("jdbc").option("url", path_conn_file).option("query", emailsquery).load()
df_email.write.mode("overwrite").format("parquet").save(temp_rw+"/df_email/")

df_legal   = spark.read.format("jdbc").option("url", path_conn_file_out).option("query", legalquery).load()
df_legal.write.mode("overwrite").format("parquet").save(temp_rw+"/df_legal/")

df_iblock  = spark.read.format("jdbc").option("url", path_conn_file_out).option("query", blockquery).load()
df_iblock.write.mode("overwrite").format("parquet").save(temp_rw+"/df_iblock/")


# COMMAND ----------

# DBTITLE 1,CLENSE
df_phone=spark.read.parquet(temp_rw+"/df_phone/")
df_phone.createOrReplaceTempView("df_phone")
df_phone=spark.sql(""" SELECT * FROM df_phone WHERE GUID IS NOT NULL AND BATCHID IS NOT NULL""").dropDuplicates()
df_phone.createOrReplaceTempView("df_phone")



df_address=spark.read.parquet(temp_rw+"/df_address/")
df_address.createOrReplaceTempView("df_address")
df_address=spark.sql(""" SELECT * FROM df_address WHERE GUID IS NOT NULL AND BATCHID IS NOT NULL""").dropDuplicates()
df_address.createOrReplaceTempView("df_address")


df_email=spark.read.parquet(temp_rw+"/df_email/").dropDuplicates()
df_email.createOrReplaceTempView("df_email")
df_email=spark.sql(""" SELECT * FROM df_email WHERE GUID IS NOT NULL AND BATCHID IS NOT NULL""").dropDuplicates()
df_email.createOrReplaceTempView("df_email")


df_legal=spark.read.parquet(temp_rw+"/df_legal/").dropDuplicates()
df_legal.createOrReplaceTempView("df_legal")
df_legal=spark.sql(""" SELECT * FROM df_legal WHERE GUID IS NOT NULL AND BATCHID IS NOT NULL""").dropDuplicates()
df_legal.createOrReplaceTempView("df_legal")


df_iblock=spark.read.parquet(temp_rw+"/df_iblock/").dropDuplicates()
df_iblock.createOrReplaceTempView("df_iblock")

# COMMAND ----------

# DBTITLE 1,CHECK PREVIOUS BATCHES
conn_compliance = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-compliance-db-sql-insleads-cs")
productconfirmation = (
    spark.read.format("jdbc")
    .option("url", conn_compliance)
    .option("query", "SELECT * FROM compliance.dlpr_confirm.productconfirmation")
    .load()
)
processed_batches=productconfirmation.selectExpr("BatchId").dropDuplicates()
processed_batches.createOrReplaceTempView("processed_batches")


df_legal_yesterday=df_legal.selectExpr("BatchID","GUID").dropDuplicates()
df_legal_yesterday.createOrReplaceTempView("df_legal_yesterday")


processed_guids=spark.sql(""" SELECT df_legal_yesterday.GUID FROM df_legal_yesterday INNER JOIN processed_batches ON df_legal_yesterday.BatchId=processed_batches.BatchId""").dropDuplicates()
processed_guids.createOrReplaceTempView("processed_guids")

# COMMAND ----------

df_phone   = spark.sql(""" SELECT df_phone.*   FROM df_phone   WHERE df_phone.GUID   NOT IN (SELECT GUID FROM processed_guids) """)
df_address = spark.sql(""" SELECT df_address.* FROM df_address WHERE df_address.GUID NOT IN (SELECT GUID FROM processed_guids) """)
df_email   = spark.sql(""" SELECT df_email.*   FROM df_email   WHERE df_email.GUID   NOT IN (SELECT GUID FROM processed_guids) """)

# COMMAND ----------

df_GUID = df_email.selectExpr("GUID").dropDuplicates()
df_GUID.write.mode("overwrite").format("parquet").save(temp_rw + "/df_GUID/")
df_GUID.unpersist()

df_GUID = spark.read.parquet(temp_rw + "/df_GUID/")

if df_GUID.count() == 0:
    print("NO PENDING GUID to search")
    dbutils.notebook.exit(0)
else:
    print("PENDING GUID to search")

# COMMAND ----------

# DBTITLE 1,select tables data and join the tables
df_em_pp = df_email.join(df_phone, (df_email.GUID == df_phone.GUID), "left").select(
    df_email["*"], df_phone["PhoneNumeric"]
)
df_em_pp_ad = (
    df_em_pp.join(df_address, df_em_pp.GUID == df_address.GUID, "left")
    .withColumn("Name1", trim(regexp_replace(df_em_pp["Name"], "&#39;", "")))
    .withColumn("namelower", trim(lower("Name1")))
    .withColumn("num_words", size(split(col("Name1"), " ")))
    .withColumn(
        "suffix",
        when(
            lower(split(col("Name1"), " ").getItem(col("num_words") - 1)).isin(
                "jr", "jr.", "sr", "sr.", "i", "ii", "iii", "iv"
            ),
            split(col("Name1"), " ").getItem(col("num_words") - 1),
        ).otherwise(lit(None)),
    )
    .withColumn(
        "first_name", when(col("num_words") >= 1, split(col("Name1"), " ").getItem(0))
    )
    .withColumn(
        "middle_name", when(col("num_words") >= 3, split(col("Name1"), " ").getItem(1))
    )
    .withColumn(
        "last_name",
        when(col("num_words") >= 3, split(col("Name1"), " ").getItem(2))
        .when(col("num_words") == 2, split(col("Name1"), " ").getItem(1))
        .when(col("num_words") == 1, lit(None)),
    )
    .select(
        df_em_pp["BatchId"],
        df_em_pp["GUID"],
        col("Name1").alias("Name"),
        df_em_pp["AlternateName"],
        df_em_pp["Email"],
        df_em_pp["Phone"],
        df_em_pp["Date"],
        df_em_pp["PhoneNumeric"],
        df_address["Id"],
        df_address["CreatedDateUtc"],
        trim(lower((df_em_pp["HomeAddress"]))).alias("addresslower"),
        trim((df_em_pp["HomeAddress"])).alias("FullAddress"),
        trim(
            concat(df_address["StreetNumber"], lit(" "), df_address["StreetName"])
        ).alias("streetnumber_name"),
        trim(
            concat(
                df_address["StreetNumber"],
                lit(" "),
                df_address["StreetName"],
                lit(" "),
                df_address["StreetType"],
                lit(" "),
                df_address["UnitType"],
                lit(" "),
                df_address["UnitNumber"],
            )
        ).alias("streetaddress"),
        df_address["City"],
        df_address["State"],
        df_address["Zip"],
        trim(col("first_name")).alias("FirstName"),
        trim(col("middle_name")).alias("MiddleName"),
        trim(col("last_name")).alias("LastName"),
        trim(col("suffix")).alias("Suffix"),
        "namelower",
    )
)
df_em_pp_ad = df_em_pp_ad.dropDuplicates()
df_em_pp_ad.repartition(50).write.mode("overwrite").format("parquet").save(
    temp_rw + "/df_em_pp_ad/"
)
df_em_pp_ad.unpersist()

# COMMAND ----------

# DBTITLE 1,explode alternate name add rows by generating new GUID for each alternate name
df_em_pp_ad=spark.read.format("parquet").load(temp_rw+"/df_em_pp_ad/")

df_with_alt_name = df_em_pp_ad.filter( col("AlternateName").isNotNull() )
df_exploded = df_with_alt_name.select("*",posexplode(split(col("AlternateName"), ",")).alias("pos", "alternateName_split"))
df_exploded = df_exploded.withColumn("GUID", concat_ws("-AN", col("GUID"), col("pos")))
df_exploded = df_exploded.withColumn("Name", col("alternateName_split"))
df_exploded = df_exploded.drop("pos").drop("alternateName_split")

df_em_pp_ad_all = df_em_pp_ad.unionAll(df_exploded)
df_em_pp_ad_all.createOrReplaceTempView("email")

# COMMAND ----------

df_temp_legal = df_em_pp_ad_all.select(
    col("BatchId").alias("BatchID"),
    "GUID",
    "FirstName",
    "MiddleName",
    "LastName",
    "Suffix",
    "Email",
    col("Phone").alias("Phone"),
    col("FullAddress").alias("HomeAddress"),
    "Date",
    col("PhoneNumeric").alias("PhoneNumber"),
    col("streetaddress").alias("Address"),
    "City",
    "State",
    "Zip",
).dropDuplicates()
df_temp_legal.createOrReplaceTempView("df_temp_legal")

df_temp_legal=spark.sql("""
SELECT BatchID,
       CASE WHEN SPLIT(GUID,"-")[1] IS NULL THEN 'P' ELSE 'S' END AS nm_matchtype,
       SPLIT(GUID,"-")[0]                                         AS GUID,
       FirstName,
       MiddleName,
       LastName,
       Suffix,
       Email,
       Phone,
       HomeAddress,
       DATE,
       PhoneNumber,
       Address,
       City,
       State,
       Zip
FROM df_temp_legal
""")
df_temp_legal.createOrReplaceTempView("df_temp_legal")

df_temp_legal=spark.sql("""
SELECT BatchID,
       GUID,
       FirstName,
       MiddleName,
       LastName,
       Suffix,
       Email,
       Phone,
       HomeAddress,
       DATE,
       PhoneNumber,
       Address,
       City,
       State,
       Zip,
       RANK() OVER (PARTITION BY BatchID,GUID ORDER BY nm_matchtype ASC) AS RNK
FROM df_temp_legal
""")
df_temp_legal=df_temp_legal.filter("RNK=='1'").drop("RNK").dropDuplicates()
df_temp_legal.createOrReplaceTempView("df_temp_legal")

# COMMAND ----------

delta_data=spark.sql("""
SELECT df_temp_legal.*,
       CASE
         WHEN df_legal_yesterday.BatchID IS NULL AND df_legal_yesterday.GUID IS NULL THEN '1'
         ELSE '0'
       END AS isNewData
FROM df_temp_legal
  LEFT JOIN df_legal_yesterday
         ON TRIM (df_temp_legal.BatchID) = TRIM (df_legal_yesterday.BatchID)
        AND TRIM (df_temp_legal.GUID) = TRIM (df_legal_yesterday.GUID)
""")
delta_data = delta_data.filter("isNewData=='1'").drop("isNewData").dropDuplicates()
delta_data = delta_data.withColumn("RecdListDate",lit(current_timestamp()))

# COMMAND ----------

df_batch = delta_data.selectExpr("BatchID").dropDuplicates()
df_batch.write.mode("overwrite").format("parquet").save(temp_rw+"/batch/")
df_batch.unpersist()

# COMMAND ----------

df_batch = spark.read.parquet(temp_rw + "/batch/")

if df_batch.count() == 0:
    print("NO DATA TO PUSH")
    dbutils.notebook.exit(0)
else:
    print("DATA TO BE PUSHED")
    delta_data.write.format("jdbc").mode("append").option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver").option("url", path_conn_file_out).option("dbtable", "escan.dbo.dontreportdatafromlegalteam").save()

# COMMAND ----------

# delta_data.write.format("jdbc").mode("append").option(
#     "driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver"
# ).option("url", path_conn_file_out).option(
#     "dbtable", "escan.dbo.dontreportdatafromlegalteam"
# ).save()

# COMMAND ----------

# diff_legal = df_temp_legal.select("GUID").dropDuplicates().exceptAll(df_legal.select("GUID").dropDuplicates()).dropDuplicates()
# diff_legal.createOrReplaceTempView("diff_legal")
# diff_legal.display()

# COMMAND ----------



# legal_insert=spark.sql("""
# SELECT df_temp_legal.*,
#        diff_legal.GUID AS diff_legal_GUID
# FROM df_temp_legal
#   LEFT JOIN diff_legal ON TRIM (df_temp_legal.GUID) = TRIM (diff_legal.GUID)
# """
# )
# legal_insert = legal_insert.filter(col("diff_legal_GUID").isNull()).drop("diff_legal_GUID").dropDuplicates()
# legal_insert= legal_insert.withColumn("RecdListDate",lit(current_timestamp()))
# print("legal_insert : "+str(legal_insert.count()))

# COMMAND ----------

# DBTITLE 1,BAD CODE
# diff_legal = df_temp_legal.select("GUID").exceptAll(df_legal.select("GUID"))
# legal_insert=df_temp_legal.join(diff_legal, df_temp_legal.GUID==diff_legal.GUID, "left").drop(diff_legal.GUID).dropDuplicates()
# legal_insert= legal_insert.withColumn("RecdListDate",lit(current_timestamp()))

# COMMAND ----------

# legal_insert.display()

# COMMAND ----------



# COMMAND ----------

# legal_insert.write.format('jdbc').mode('append').option('driver', 'com.microsoft.sqlserver.jdbc.SQLServerDriver').option('url', path_conn_file_out).option('dbtable', icddb+legal_table).save()
# legal_insert.write.format('jdbc').mode('append').option('driver', 'com.microsoft.sqlserver.jdbc.SQLServerDriver').option('url', path_conn_file_out).option('dbtable', 'zescantemp.dbo.dontreportdatafromlegalteam').save()

# COMMAND ----------

# DBTITLE 1,DISABLED
# READ globalmrnxpacct
# READ foundcoverage
# READ edipartners
# READ edipayers

# globalmrnxpacct=spark.read.parquet(gmrn_publish_path+"/globalmrnxpacct/current/*/").selectExpr("globalmrnifk","hospitalfk","patientacctifk")
# globalmrnxpacct.createOrReplaceTempView("globalmrnxpacct")

# foundcoverage = spark.read.format("delta").load(data_ingestion_path+"/foundcoverage/current/20991231/").selectExpr("hospitalfk","patientacctifk","edipartnerfk")
# foundcoverage.createOrReplaceTempView("foundcoverage")

# edipartners=spark.read.parquet(data_ingestion_path+"/edipartners/current/20991231/").selectExpr("edipartnerpk","edipayerfk","partnername","isenabledflag as isedipartnersEnabled").dropDuplicates()
# edipartners.createOrReplaceTempView("edipartners")

# edipayers=spark.read.parquet(data_ingestion_path+"/edipayers/current/20991231/").selectExpr("EDIPayerGroupFK","edipayerpk").dropDuplicates()
# edipayers.createOrReplaceTempView("edipayers")

# COMMAND ----------

# DBTITLE 1,DISABLED
# # READ patientaccts
# patientaccts = spark.read.format("delta").load(data_ingestion_path + "/patientaccts/current/20991231/")
# patientaccts = patientaccts.selectExpr(
#     "firstname",
#     "lastname",
#     "middlename",
#     "suffix",
#     "phone1",
#     "phone2",
#     "addr1",
#     "addr2",
#     "city",
#     "state",
#     "hospitalfk",
#     "patientacctipk",
#     "medicalrecnum"
# )


# patientaccts=patientaccts.withColumn("addr1lower", trim(regexp_replace(lower(patientaccts.addr1),"\\\\", "")))
# patientaccts=patientaccts.withColumn("phone1", regexp_replace(lower(patientaccts.phone1),"\\\\", ""))
# patientaccts=patientaccts.withColumn("phone1", regexp_replace(lower(patientaccts.phone1),"-", ""))
# patientaccts=patientaccts.withColumn("phone1", regexp_replace(lower(patientaccts.phone1),"\\(", ""))
# patientaccts=patientaccts.withColumn("phone1", regexp_replace(lower(patientaccts.phone1),"\\)", ""))
# patientaccts=patientaccts.withColumn("phone2", regexp_replace(lower(patientaccts.phone2),"\\\\", ""))
# patientaccts=patientaccts.withColumn("phone2", regexp_replace(lower(patientaccts.phone2),"-", ""))
# patientaccts=patientaccts.withColumn("phone2", regexp_replace(lower(patientaccts.phone2),"\\(", ""))
# patientaccts=patientaccts.withColumn("phone2", regexp_replace(lower(patientaccts.phone2),"\\)", ""))
# patientaccts=patientaccts.withColumn("citylower", trim(lower(patientaccts.city)))
# patientaccts=patientaccts.withColumn("statelower", trim(lower(patientaccts.state)))
# patientaccts=patientaccts.withColumn("phone1", (patientaccts.phone1).cast("long"))
# patientaccts=patientaccts.withColumn("phone2", (patientaccts.phone2).cast("long"))

# patientaccts=patientaccts.withColumn("firstname", trim(regexp_replace(lower(patientaccts.firstname),"\\\\", "")))
# patientaccts=patientaccts.withColumn("lastname", trim(regexp_replace(lower(patientaccts.lastname),"\\\\", "")))
# patientaccts=patientaccts.withColumn("citylower", regexp_replace(lower(patientaccts.citylower),"\\\\", ""))
# patientaccts=patientaccts.withColumn("statelower", regexp_replace(lower(patientaccts.statelower),"\\\\", ""))
# patientaccts=patientaccts.withColumn("addr1lower", regexp_replace(lower(patientaccts.addr1lower),"\\\\", ""))

# patientaccts.createOrReplaceTempView("patientaccts")

# COMMAND ----------

# DBTITLE 1,DISABLED
# df_pc_mailname = spark.sql(
#     """
# SELECT e.GUID,
#        e.Name AS Name,
#        e.FullAddress,
#        e.PhoneNumeric,
#        e.Email,
#        p.firstname,
#        p.lastname,
#        p.middlename,
#        p.phone1,
#        p.phone2,
#        p.addr1,
#        p.addr2,
#        p.city,
#        p.state,
#        p.hospitalfk,
#        p.patientacctipk,
#        p.medicalrecnum,
#       --  p.referraldate,
#       --  p.admitdate,
#       --  p.dischargedate,
#        CURRENT_DATE() AS adddate,
#        'Name and HomeAddrLike' AS searchcombo
# FROM email e
# JOIN patientaccts p
#   ON e.FirstName = p.firstname
#  AND LOWER(TRIM(e.LastName)) = LOWER(TRIM(p.lastname))
#  AND LOWER(TRIM(e.addresslower)) LIKE '%' || LOWER(TRIM(p.citylower)) || '%'
#  AND LOWER(TRIM(e.addresslower)) LIKE '%' || LOWER(TRIM(p.statelower)) || '%'
#  AND LOWER(TRIM(e.addresslower)) LIKE '%' || LOWER(TRIM(p.addr1lower)) || '%'
# """
# )

# COMMAND ----------

# DBTITLE 1,DISABLED
# df_pc_mailstreet = spark.sql(
#     """
# SELECT e.GUID,
#        e.Name AS Name,
#        e.FullAddress,
#        e.PhoneNumeric,
#        e.Email,
#        p.firstname,
#        p.lastname,
#        p.middlename,
#        p.phone1,
#        p.phone2,
#        p.addr1,
#        p.addr2,
#        p.city,
#        p.state,
#        p.hospitalfk,
#        p.patientacctipk,
#        p.medicalrecnum,
#       --  p.referraldate,
#       --  p.admitdate,
#       --  p.dischargedate,
#        CURRENT_DATE() AS adddate,
#        'Name and HomeAddrLike' AS searchcombo
# FROM email e
#   JOIN patientaccts p
#     ON LOWER(TRIM(e.FirstName)) = LOWER(TRIM(p.firstname))
#    AND LOWER(TRIM(e.LastName)) = LOWER(TRIM(p.lastname))
#    AND LOWER(TRIM(p.addr1lower)) LIKE '%' || LOWER(TRIM(e.streetnumber_name)) || '%'
#    AND LOWER(TRIM(e.addresslower)) LIKE '%' || LOWER(TRIM(p.citylower)) || '%'
#    AND LOWER(TRIM(e.addresslower)) LIKE '%' || LOWER(TRIM(p.statelower)) || '%'
# """
# )

# COMMAND ----------

# DBTITLE 1,DISABLED
# df_pcphone_mail = spark.sql(
#     """
# SELECT e.GUID,
#        e.Name AS Name,
#        e.FullAddress,
#        e.PhoneNumeric,
#        e.Email,
#        p.firstname,
#        p.lastname,
#        p.middlename,
#        p.phone1,
#        p.phone2,
#        p.addr1,
#        p.addr2,
#        p.city,
#        p.state,
#        p.hospitalfk,
#        p.patientacctipk,
#        p.medicalrecnum,
#       --  p.referraldate,
#       --  p.admitdate,
#       --  p.dischargedate,
#        CURRENT_DATE()   AS adddate,
#        'Name and Phone' AS searchcombo
# FROM email e
#   JOIN patientaccts p
#     ON LOWER(TRIM(e.FirstName)) = LOWER(TRIM(p.firstname))
#    AND LOWER(TRIM(e.LastName)) = LOWER(TRIM(p.lastname))
#    AND (e.phonenumeric = p.phone1
#     OR e.phonenumeric = p.phone2)                   
# """
# )

# COMMAND ----------

# DBTITLE 1,DISABLED
# df_pc_mail = df_pc_mailname.unionAll(df_pcphone_mail).unionAll(df_pc_mailstreet)
# df_pc_mail.write.mode("overwrite").format("parquet").save(temp_rw+"/df_pc_mail/")
# df_pc_mail.unpersist()

# COMMAND ----------

# DBTITLE 1,DISABLED
# df_pc_mail = spark.read.format("parquet").load(temp_rw + "/df_pc_mail/").dropDuplicates()

# for column in df_pc_mail.columns:
#     df_pc_mail = df_pc_mail.withColumn(column, trim(col(column)))
#     df_pc_mail = df_pc_mail.withColumn(column, when(col(column) == '', None).otherwise(col(column)))
#     df_pc_mail = df_pc_mail.withColumn(column, when(col(column).isNull(), None).otherwise(col(column)))
#     df_pc_mail = df_pc_mail.withColumn(column, when(upper(col(column)) == 'NULL',None).otherwise(col(column)))

# df_pc_mail.createOrReplaceTempView("blockallowacctsreview")

# df_pc_mail = spark.sql("""
# SELECT GUID,
#        CASE WHEN SPLIT(GUID,"-")[1] IS NULL THEN 'P' ELSE 'S' END AS nm_matchtype,
#        Name,
#        FullAddress,
#        PhoneNumeric,
#        Email,
#        firstname,
#        lastname,
#        middlename,
#        addr1,
#        addr2,
#        city,
#        state,
#        hospitalfk,
#        patientacctipk,
#        medicalrecnum,
#        adddate,
#        searchcombo
# FROM blockallowacctsreview
# """).dropDuplicates()

# print("BEFORE DEDUPE COUNT : df_pc_mail : "+str(df_pc_mail.count()))

# df_pc_mail.createOrReplaceTempView("blockallowacctsreview")
# df_pc_mail=spark.sql("""
# SELECT 
#        CASE WHEN nm_matchtype='P' THEN GUID ELSE SPLIT(GUID,"-")[1] END AS GUID,
#        nm_matchtype,
#        Name,
#        FullAddress,
#        PhoneNumeric,
#        Email,
#        firstname,
#        lastname,
#        middlename,
#        addr1,
#        addr2,
#        city,
#        state,
#        hospitalfk,
#        patientacctipk,
#        medicalrecnum,
#        adddate,
#        searchcombo,
#        RANK() OVER (PARTITION BY patientacctipk,hospitalfk,medicalrecnum,firstname,middlename,lastname,addr1,addr2,city,state ORDER BY nm_matchtype ASC) AS RNK
# FROM blockallowacctsreview
# """)


# df_pc_mail=df_pc_mail.filter("RNK=='1'").drop("RNK").selectExpr("GUID","nm_matchtype","hospitalfk","patientacctipk","medicalrecnum").dropDuplicates()
# df_pc_mail.write.mode("overwrite").format("parquet").save(temp_rw+"/df_pc_mail_deduped/")
# df_pc_mail.unpersist()

# COMMAND ----------

# DBTITLE 1,DISABLED
# df_pc_mail=spark.read.format("parquet").load(temp_rw + "/df_pc_mail_deduped/")
# df_pc_mail.createOrReplaceTempView("blockallowacctsreview")
# print("AFTER DEDUPE COUNT : df_pc_mail : "+str(df_pc_mail.count()))

# COMMAND ----------

# DBTITLE 1,join of found overage, patient accounts joins, patient accts, globalmrnxpacct
# df_combined = spark.sql("""
# SELECT blockallowacctsreview.GUID,
#        blockallowacctsreview.nm_matchtype,
#        blockallowacctsreview.hospitalfk,
#        blockallowacctsreview.patientacctipk,
#        blockallowacctsreview.medicalrecnum,
#        globalmrnxpacct.globalmrnifk,
#        foundcoverage.edipartnerfk
# FROM blockallowacctsreview
#   INNER JOIN globalmrnxpacct
#           ON blockallowacctsreview.hospitalfk = globalmrnxpacct.hospitalfk
#          AND blockallowacctsreview.patientacctipk = globalmrnxpacct.patientacctifk
#   INNER JOIN patientaccts
#           ON blockallowacctsreview.hospitalfk = patientaccts.hospitalfk
#          AND blockallowacctsreview.patientacctipk = patientaccts.patientacctipk
#          AND blockallowacctsreview.medicalrecnum = patientaccts.medicalrecnum
#   INNER JOIN foundcoverage
#           ON blockallowacctsreview.hospitalfk = foundcoverage.hospitalfk
#          AND blockallowacctsreview.patientacctipk = foundcoverage.patientacctifk
# """).dropDuplicates()
# df_combined.write.mode("overwrite").format("parquet").save(temp_rw+"/df_combined/")
# df_combined.unpersist()

# COMMAND ----------

# DBTITLE 1,DISABLED
# df_combined=spark.read.format("parquet").load(temp_rw+"/df_combined/")
# df_combined = df_combined.selectExpr("hospitalfk", "patientacctipk", "globalmrnifk", "edipartnerfk").dropDuplicates()
# df_combined.createOrReplaceTempView("combined")
# df_combined.display()

# COMMAND ----------

# DBTITLE 1,DISABLED
# edipartners_x_edipayers = spark.sql("""
# SELECT edipartners.edipartnerpk,
#        edipartners.edipayerfk,
#        edipartners.partnername,
#        edipartners.isedipartnersEnabled,
#        edipayers.EDIPayerGroupFK
# FROM edipartners
#   INNER JOIN edipayers ON edipartners.edipayerfk = edipayers.edipayerpk
# """).dropDuplicates()
# edipartners_x_edipayers=edipartners_x_edipayers.filter("isedipartnersEnabled=='1'").drop("isedipartnersEnabled").drop("partnername").dropDuplicates()
# edipartners_x_edipayers.createOrReplaceTempView("edipartners_x_edipayers")

# COMMAND ----------

# DBTITLE 1,DISABLED


# df_input_block = df_iblock.select("GMRNIFK","EDIPartnerFK","ApplyPayerGroup").dropDuplicates()
# print("COUNT : df_input_block : "+str(df_input_block.count()))
# # df_input_block.display()

# df_block = spark.sql("""
# SELECT combined.globalmrnifk AS GMRNIFK,
#        combined.edipartnerfk AS EDIPartnerFK,
#        CAST(CASE WHEN edipartners_x_edipayers.EDIPayerGroupFK IS NULL THEN 0 WHEN edipartners_x_edipayers.EDIPayerGroupFK  IS NOT NULL THEN 1  END AS boolean) AS ApplyPayerGroup,
#        'B'                            AS BlockAllow,
#        'Flagged per SF Case 06009005' AS Note,
#        'Ready'                        AS BackfillStatus,
#        246                            AS CreateUserId,
#        CAST(NULL AS VARCHAR(1))       AS UpdateUserId,
#        GETDATE()                      AS CreateDate,
#        'app_databricks'               AS CreatedBy,
#        GETDATE()                      AS UpdateDate,
#        'app_databricks'               AS UpdatedBy
# FROM combined
#   INNER JOIN edipartners_x_edipayers ON combined.edipartnerfk = edipartners_x_edipayers.edipartnerpk
# """)

# df_block=df_block.withColumn("ApplyPayerGroup",df_block["ApplyPayerGroup"].cast("boolean"))
# df_out_block=df_block.select("GMRNIFK","EDIPartnerFK","ApplyPayerGroup").dropDuplicates()
# diff_block=df_out_block.subtract(df_input_block)


# COMMAND ----------

# DBTITLE 1,DISABLED
# patientmatchingblockallowgmrn= diff_block.join(df_block, ["GMRNIFK", "EDIPartnerFK","ApplyPayerGroup"], "inner")
# patientmatchingblockallowgmrn.write.mode("overwrite").format("parquet").save(temp_rw+"/patientmatchingblockallowgmrn/")

# COMMAND ----------

# DBTITLE 1,DISABLED
# df_bl.write.format("jdbc").mode("append").option(
#     "driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver"
# ).option("url", path_conn_file_out).option(
#     "dbtable", "escan.dbo.patientmatchingblockallowgmrn"
# ).save()
