# Databricks notebook source
from pyspark.sql.functions import *

# container="prod-icd-adls"
# storageaccount="prodicddls"
# user="na"
# output_db="zescantemp"
# output_table="dbo.ProductConfirmation"
# prod_confirm_table="ProductConfirmation"
# server="lewvsiddb01.nthrive.nthcrp.com"
# temp_path="/data/temp_rw/"
# db_user="app_databricks"

# COMMAND ----------

# DBTITLE 1,Parameters
dbutils.widgets.text("temp_path", "")
dbutils.widgets.getArgument("temp_path")
temp_path = getArgument("temp_path")

dbutils.widgets.text("db_user", "")
dbutils.widgets.getArgument("db_user")
db_user = getArgument("db_user")

dbutils.widgets.text("server", "")
dbutils.widgets.getArgument("server")
server = getArgument("server")

dbutils.widgets.text("prod_confirm_table", "")
dbutils.widgets.getArgument("prod_confirm_table")
prod_confirm_table = getArgument("prod_confirm_table")

dbutils.widgets.text("container", "")
dbutils.widgets.getArgument("container")
container = getArgument("container")

dbutils.widgets.text("storageaccount", "")
dbutils.widgets.getArgument("storageaccount")
storageaccount = getArgument("storageaccount")

dbutils.widgets.text("user", "")
dbutils.widgets.getArgument("user")
user = getArgument("user")

dbutils.widgets.text("output_table", "")
dbutils.widgets.getArgument("output_table")
output_table = getArgument("output_table")

dbutils.widgets.text("output_db", "")
dbutils.widgets.getArgument("output_db")
output_db = getArgument("output_db")

# COMMAND ----------

# DBTITLE 1,Set config
spark.conf.set(
    "fs.azure.account.key." + storageaccount + ".dfs.core.windows.net",
    dbutils.secrets.get(
        scope="icd-insleads-dbwscope", key="icd-adls-insleads-kvsecret"
    ),
)

if user == "na":  # defualt value
    baseurl = "abfss://" + container + "@" + storageaccount + ".dfs.core.windows.net"
else:
    baseurl = (
        "abfss://" + container + "@" + storageaccount + ".dfs.core.windows.net/" + user
    )

conn_compliance = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-compliance-db-sql-insleads-cs")

# COMMAND ----------

df_GUID  = spark.read.parquet(baseurl + "/data/blacklisted/temp_rw/df_GUID/")
df_batch = spark.read.parquet(baseurl + "/data/blacklisted/temp_rw/batch/")

# COMMAND ----------

if df_GUID.count() == 0:
    print("NO PENDING GUID to search")
    dbutils.notebook.exit(0)
else:
    print("PENDING GUID to search")

# COMMAND ----------

if df_batch.count() == 0:
    print("No new batches to process")
    dbutils.notebook.exit(0)
else :
    print("New batches to process")

# COMMAND ----------

batchid_list = df_batch.select("BatchId").distinct().collect()
# Convert to the desired format
batchid_list = ",".join([f"({row['BatchId']})" for row in batchid_list])

# COMMAND ----------

productconfirmation = (
    spark.read.format("jdbc")
    .option("url", conn_compliance)
    .option("query", "SELECT * FROM compliance.dlpr_confirm.productconfirmation")
    .load()
)

# COMMAND ----------

# Install pymssql package
%pip install "pymssql<3.0"

# COMMAND ----------

import re
import pymssql

# COMMAND ----------

def parse_jdbc_connection_string(jdbc_string):
    jdbc_string = jdbc_string.replace("jdbc:sqlserver://", "")
    server_info, params = jdbc_string.split(";", 1)
    server = server_info
    param_dict = dict(param.split("=") for param in params.split(";") if "=" in param)
    return {
        "server": server,
        "user": param_dict.get("user"),
        "password": param_dict.get("password"),
    }


# Parse the connection string
connection_params = parse_jdbc_connection_string(conn_compliance)

# Log the connection parameters
print(f"Connecting to server: {connection_params['server']}")
print(f"Using user: {connection_params['user']}")

# Connect using pymssql
try:
    conn = pymssql.connect(
        server=connection_params["server"],
        user=connection_params["user"],
        password=connection_params["password"],
        database="compliance",
        as_dict=True,
    )
    print("Connection successful")
except pymssql.OperationalError as e:
    print(f"OperationalError: {e}")
except Exception as e:
    print(f"An error occurred: {e}")

# COMMAND ----------

query_update = f"declare @listOfIDs table (id int);insert @listOfIDs(id) values{batchid_list}; update compliance.dlpr_confirm.productconfirmation set InsuranceDiscovery_Response='Confirmed', InsuranceDiscovery_ResponseDate=GETDATE() where (InsuranceDiscovery_Response is null or LEN(InsuranceDiscovery_Response)=0) and (InsuranceDiscovery_ResponseDate is null or LEN(InsuranceDiscovery_ResponseDate)=0) and batchid in (select id from @listOfIDs)"

# query_update = f"declare @listOfIDs table (id int);insert @listOfIDs(id) values{batchid_list}; update zescantemp.dbo.productconfirmation set InsuranceDiscovery_Response='Confirmed', InsuranceDiscovery_ResponseDate=GETDATE() where (InsuranceDiscovery_Response is null or LEN(InsuranceDiscovery_Response)=0) and (InsuranceDiscovery_ResponseDate is null or LEN(InsuranceDiscovery_ResponseDate)=0) and batchid in (select id from @listOfIDs)"

print(query_update)

# COMMAND ----------

cursor = conn.cursor()
cursor.execute(query_update)
conn.commit()
cursor.close()
conn.close()
