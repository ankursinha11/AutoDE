# Databricks notebook source
dbutils.widgets.text("dataingestion_publish_path","")
dbutils.widgets.getArgument("dataingestion_publish_path")
dataingestion_publish_path= getArgument("dataingestion_publish_path")

dbutils.widgets.text("scratch_path","")
dbutils.widgets.getArgument("scratch_path")
scratch_path= getArgument("scratch_path")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

dataingestion_publish_path = baseurl+dataingestion_publish_path
scratch_path=baseurl+scratch_path+bc
print("dataingestion_publish_path:",dataingestion_publish_path)
print("scratch_path:",scratch_path)

# COMMAND ----------

# MAGIC %run /Insleads-code/LeadDiscovery/common/process_leads

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from delta.tables import *
from pyspark.sql.functions import concat

# COMMAND ----------

# DBTITLE 1,Read Foundcoverage with hitstatus= 0
all_fc=spark.read.format('delta').load(dataingestion_publish_path+"/foundcoverage/current/20991231/")
fc=all_fc.filter("hitstatus=0")
fc = fc.withColumn("coverageid",when((fc.coverageid.contains(fc.groupnumber))& (fc.groupnumber != '') \
                      ,substring_index(fc.coverageid,'-',1)).otherwise(fc.coverageid))
fc.count()#358998325

# COMMAND ----------

# DBTITLE 1,Read Foundcoverage with hitstatus=1,2
fc1=all_fc.filter("hitstatus in (1,2)")
fc1 = fc1.withColumn("coverageid",when((fc1.coverageid.contains(fc1.groupnumber))& (fc1.groupnumber != '') \
                      ,substring_index(fc1.coverageid,'-',1)).otherwise(fc1.coverageid))
fc1.count()#4738740233

# COMMAND ----------

# DBTITLE 1,Joining fc hitstatus 0 with hospitals to get the hcsystemfk
hospitals=spark.read.format('parquet').load(dataingestion_publish_path+"/hospitals/current/20991231/")
fcxhosp=fc.join(hospitals,fc.hospitalfk==hospitals.hospitalpk,how="left").select(fc.patientacctifk,fc.edipartnerfk,fc.coverageid,fc.hospitalfk,"firstname","middlename","lastname","gender","addr",fc.state,fc.city,fc.zip,"dob","ssn","foundcoverageipk","hitstatus",hospitals.hcsystemfk)

# COMMAND ----------

# DBTITLE 1,Joining fc hitstatus 1,2 with hospitals to get the hcsystemfk
fcxhosp1=fc1.join(hospitals,fc1.hospitalfk==hospitals.hospitalpk,how="left").select(fc1.patientacctifk,fc1.edipartnerfk,fc1.coverageid,fc1.hospitalfk,"firstname","middlename","lastname","gender","addr",fc1.state,fc1.city,fc1.zip,"dob","ssn","foundcoverageipk","hitstatus",hospitals.hcsystemfk)

# COMMAND ----------

# DBTITLE 1,read xref_permid with source=1(FC)
lr_xref_gmrnid=spark.read.format("delta").load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/leadrepo/publish/cooked/lr_xref_gmrnid_transaction/").filter("sourcekey=1").select("transactionkey","gmrnid")

# COMMAND ----------

# DBTITLE 1,join fc temp with xref_gmrnid
fcxgmrn_xref=lr_xref_gmrnid.join(fcxhosp, fcxhosp.foundcoverageipk==lr_xref_gmrnid.transactionkey)
fcxgmrn_xref.write.mode('overwrite').parquet(scratch_path+"/fc_matching_hitstatus0/")

# COMMAND ----------

# DBTITLE 1,join fc temp hitstatus 1,2 with xref
fcxgmrn_xref1=lr_xref_gmrnid.join(fcxhosp1, fcxhosp1.foundcoverageipk==lr_xref_gmrnid.transactionkey)
fcxgmrn_xref1.write.mode('overwrite').parquet(scratch_path+"/fc_matching_hitstatus1_2/")

# COMMAND ----------

matching=spark.read.parquet(scratch_path+"/fc_matching_hitstatus0/").dropDuplicates()
matching.count()#261684726

# COMMAND ----------

# DBTITLE 1,creating a new column to match with _id col in lsb
mat1=matching.withColumn("new_id", concat(lit("G_"), matching.gmrnid,lit("_"),matching.edipartnerfk,lit("_"),matching.coverageid)).select("new_id","hcsystemfk","hospitalfk").dropDuplicates()#total: 
mat1=mat1.withColumn("hcsystemfk",concat(mat1.hcsystemfk,lit("_fc")))
mat1.count()#88369514

# COMMAND ----------

matching12=spark.read.parquet(scratch_path+"/fc_matching_hitstatus1_2/").dropDuplicates()
#print("matching12 count:",matching12.count())#
mat12=matching12.withColumn("new_id", concat(lit("G_"), matching12.gmrnid,lit("_"),matching12.edipartnerfk,lit("_"),matching12.coverageid)).select("new_id","hcsystemfk","hospitalfk").dropDuplicates()#total: 
mat12=mat12.withColumn("hcsystemfk",concat(mat12.hcsystemfk,lit("_fc")))
print("mat12:",mat12.count())#722783189

# COMMAND ----------

# DBTITLE 1,diff of hitstatus1,2 and hitstatus 0
difff=mat1.subtract(mat12)#72653184
difff.write.mode('overwrite').parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/lsb_cleanup/gmrnid/20250113T22/gmrnid_diff_tobeupdated/")

# COMMAND ----------

# DBTITLE 1,read lsb and filter gmrn_id recs
lsb = spark.read.format("delta").load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/leadservicebase/publish/served/lsbv1/leadservicebase/")#4533120961
lsb_fc = lsb.filter(col("_id").startswith('G')).filter(col("hcsystemfk_source").contains('fc'))#911657366
lsb_ex = lsb_fc.select("*",explode_outer("demographics")).drop("demographics")
lsb_ex.count()#1606016541

# COMMAND ----------

# DBTITLE 1,Explode hospitalfk
import pyspark.sql.functions as f
lsb_exp2=lsb_ex.select(f.split("value.hospitalfk",'[|]').alias('tmp'),"*").withColumn("tmp",f.explode("tmp"))

# COMMAND ----------

lsb_exp2=lsb_exp2.withColumn("value",lsb_exp2["value"].withField("hospitalfk", lsb_exp2.tmp)).drop("tmp")#1843165275

# COMMAND ----------

# DBTITLE 1,joining exploded lsb with the need to be updated
jn=lsb_exp2.join(difff, (lsb_exp2._id == difff.new_id) & (lsb_exp2.key == difff.hcsystemfk) & (difff.hospitalfk==lsb_exp2.value.hospitalfk),"left")#
jn.count()# 1843165275

# COMMAND ----------

latest=jn.filter("new_id is null") 

# COMMAND ----------

# DBTITLE 1,prepare for rollback
new1=latest.select('*').groupBy("_id","key").agg(concat_ws("|",collect_list("value.hospitalfk")).alias("merged_value"))
new1=new1.select("_id","key","merged_value")

# COMMAND ----------

# test_jn1=latest.join(new1,"_id")
test_jn1=latest.join(new1,(latest._id==new1._id) & (latest.key==new1.key)).select(latest["*"],new1["merged_value"])

# COMMAND ----------

test_jn1=test_jn1.withColumn("value",test_jn1["value"].withField("hospitalfk", test_jn1.merged_value)).drop("merged_value")
# test_jn2=test_jn1.select("_id","identity","leadcreatedate","leadid","leadupdatedate","lsbcreatedate","lsbupdatedate","key").dropDuplicates()
test_jn2=test_jn1.dropDuplicates()

# COMMAND ----------

test_jn3=test_jn2.groupBy("_id").agg(concat_ws("|",collect_list("key")).alias("hcsystemfk_source1")).drop("identity","leadcreatedate","leadid","leadupdatedate","lsbcreatedate","lsbupdatedate")

# COMMAND ----------

test_jn4=test_jn2.join(test_jn3,"_id")

# COMMAND ----------

# DBTITLE 1,rollback
test_jn4.createOrReplaceTempView("lsb_demo2")
lsb3_sql = """ 
            SELECT
                _id,
                hcsystemfk_source1 as hcsystemfk_source,
                identity,
                leadcreatedate,
                leadid,
                leadupdatedate,
                lsbcreatedate,
                date_format(current_timestamp(), "yyyy-MM-dd HH:mm:ss") as lsbupdatedate,
                sort_array(collect_list(struct(key, value)) over (PARTITION BY _id)) as demographics_list,
                ROW_NUMBER() OVER (PARTITION BY _id ORDER BY leadupdatedate DESC) AS RNK
            FROM lsb_demo2 
            """
lsb3 = spark.sql(lsb3_sql).filter("RNK == 1").drop("RNK")
print(lsb3.count())#878911634


# COMMAND ----------

spark.conf.set("spark.sql.mapKeyDedupPolicy", "LAST_WIN")

lsb5 = lsb3.withColumn("demographics", map_from_entries("demographics_list")).drop("demographics_list")

# COMMAND ----------

lsb5.write.mode("overwrite").parquet(scratch_path+"/fc_lsb_final/")

# COMMAND ----------

fc_lsbrd=spark.read.parquet(scratch_path+"/fc_lsb_final/")
fc_lsbrd.count()

# COMMAND ----------

diff=lsb_fc.select("_id").subtract(fc_lsbrd.select("_id"))
#diff.count()#32745732

# COMMAND ----------

diff.write.mode('overwrite').parquet(scratch_path+"/gmrnid_diff_tobedeleted/")

# COMMAND ----------

gmrnid_diff_tobedeleted=spark.read.parquet(scratch_path+"/gmrnid_diff_tobedeleted/")
gmrnid_diff_tobedeleted.count()#32745732

# COMMAND ----------

lsb_path_source="abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/leadservicebase/publish/served/latest2/leadservicebase/"

# COMMAND ----------

lsb_source = DeltaTable.forPath(spark, lsb_path_source)
lsb_source.alias("curr").merge(fc_lsbrd.alias("new_data"), 'curr._id == new_data._id').whenMatchedUpdateAll().execute()

# COMMAND ----------

lsb_source = DeltaTable.forPath(spark, lsb_path_source)
lsb_source.alias("curr").merge(gmrnid_diff_tobedeleted.alias("new_data"), 'curr._id == new_data._id').whenMatchedDelete().execute()