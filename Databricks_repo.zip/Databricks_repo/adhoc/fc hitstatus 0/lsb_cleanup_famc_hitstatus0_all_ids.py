# Databricks notebook source
dbutils.widgets.text("dataingestion_publish_path","")
dbutils.widgets.getArgument("dataingestion_publish_path")
dataingestion_publish_path= getArgument("dataingestion_publish_path")

dbutils.widgets.text("scratch_path","")
dbutils.widgets.getArgument("scratch_path")
scratch_path= getArgument("scratch_path")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

dataingestion_publish_path = baseurl+dataingestion_publish_path
scratch_path=baseurl+scratch_path+bc
print("dataingestion_publish_path:",dataingestion_publish_path)
print("scratch_path:",scratch_path)

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from delta.tables import *
from pyspark.sql.functions import concat
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
import datetime
import getpass
import os
import sys
import subprocess
from delta.tables import *

# COMMAND ----------

# DBTITLE 1,Read FoundCoverage and filter hitstatus 0 records
all_fc=spark.read.format('delta').load(dataingestion_publish_path+"/foundcoverage/current/20991231/")
fc=all_fc.filter("hitstatus=0")
print("fc hitstatus 0 :",fc.count())#360120335
fc.createOrReplaceTempView("fc")

# COMMAND ----------

# DBTITLE 1,Get permids for the above FC hitstatus0 records (PA+demogs+permid) using paxpermid
pp=spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/cdd/publish/permidpatientacctid/*")
pp = pp.filter("matchind in ('IM','M1')")
pp.createOrReplaceTempView("permidpatientacctid")

fc_pa_permid = spark.sql(""" Select fc.*, pp.permid FROM fc 
        INNER JOIN permidpatientacctid pp ON 
        fc.patientacctifk = pp.PatientAcctIFK""")
print("fc_pa_permid:",fc_pa_permid.count())#334,114,057
# fc_pa_permid.filter("permid = 'E0C54CA954F4'").display()

# COMMAND ----------

# DBTITLE 1,Read FoundCoverage and filter hitstatus 1,2 records
fc12=all_fc.filter("hitstatus in (1,2)")
print("fc hitstatus 1,2 :",fc12.count())#4746394840
fc12.createOrReplaceTempView("fc12")

# COMMAND ----------

# DBTITLE 1,Get permids for the above FC hitstatus12 records (PA+demogs+permid+cov info) using paxpermid
pp=spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/cdd/publish/permidpatientacctid/*")
pp = pp.filter("matchind in ('IM','M1')")
pp.createOrReplaceTempView("permidpatientacctid")

fc12_pa_permid = spark.sql(""" Select fc12.*, pp.permid FROM fc12
        INNER JOIN permidpatientacctid pp ON 
        fc12.patientacctifk = pp.PatientAcctIFK""")
print("fc12_pa_permid:",fc12_pa_permid.count())#3,986,070,842
# fc12_pa_permid.filter("permid = '00E74D002A26'").display()

# COMMAND ----------

# DBTITLE 1,Final set of permids with hitstatus0
fc_pa_permid = fc_pa_permid.withColumn("ssn", when(col("ssn").isNull(), lit("000000000")).otherwise(col("ssn")))
fc12_pa_permid = fc12_pa_permid.withColumn("ssn", when(col("ssn").isNull(), lit("000000000")).otherwise(col("ssn")))
fc_pa_permid = fc_pa_permid.withColumn("ssn", when(col("ssn") == '', lit("000000000")).otherwise(col("ssn")))
fc12_pa_permid = fc12_pa_permid.withColumn("ssn", when(col("ssn") == '', lit("000000000")).otherwise(col("ssn")))

fc_pa_permid_final = fc_pa_permid.join(fc12_pa_permid, ["permid", "firstname", "lastname", "dob", "ssn"], "leftanti")
fc_pa_permid_final.write.mode("overwrite").parquet(scratch_path+"/final_famc_permids_hitstatus0_demogs")

# COMMAND ----------

# DBTITLE 1,Read final hitstatus0 permid level demogs
fc_pa_permid_final_demogs = spark.read.parquet(scratch_path+"/final_famc_permids_hitstatus0_demogs")
print("fc_pa_permid_final_demogs:",fc_pa_permid_final_demogs.count())#162,027,774
fc_pa_permid_final_demogs_hcs = fc_pa_permid_final_demogs
fc_pa_permid_final_demogs_hcs = fc_pa_permid_final_demogs_hcs.withColumn("dob" , substring("dob",1,10))
fc_pa_permid_final_demogs_hcs = fc_pa_permid_final_demogs_hcs.select( "permid", "firstname", "lastname", "dob", "ssn", "edipartnerfk", "coverageid" ).dropDuplicates()
print("fc_pa_permid_final_demogs_hcs:",fc_pa_permid_final_demogs_hcs.count())# 38376066


# COMMAND ----------

# MAGIC %md
# MAGIC ## STEP2

# COMMAND ----------

# DBTITLE 1,create id
fc_pa_permid_final_demogs_hcs=fc_pa_permid_final_demogs_hcs.withColumn("new_id", concat(lit("P_"),fc_pa_permid_final_demogs_hcs.permid,lit("_"),fc_pa_permid_final_demogs_hcs.edipartnerfk,lit("_"),fc_pa_permid_final_demogs_hcs.coverageid))

# COMMAND ----------

# MAGIC %md
# MAGIC # LSB

# COMMAND ----------

# DBTITLE 1,Read LSB with fm source records
lsb = spark.read.format("delta").load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/leadservicebase/publish/mh_hitstatus_cleanup/served/updated_leadservicebase_after_mh_cleanup/")#4302680420
lsb_fm = lsb.filter(col("hcsystemfk_source").contains('fm'))#38744154
lsb_ex = lsb_fm.select("*",explode_outer("demographics")).drop("demographics")
print("lsb:",lsb.count())#4302680420
print("lsb_fm:",lsb_fm.count())#508904672
print("lsb_ex:",lsb_ex.count())#951816908

# COMMAND ----------

# DBTITLE 1,joining hitstatus 0 records with lsb level 1
lsb_ex = lsb_ex.withColumn("value",when((lsb_ex.value.ssn == '') | (lsb_ex.value.ssn.isNull()) ,  lsb_ex["value"].withField("ssn", lit("000000000"))).otherwise(col("value")))# this will update many ssn values to 000000000 
jn=lsb_ex.join(fc_pa_permid_final_demogs_hcs, (lsb_ex._id == fc_pa_permid_final_demogs_hcs.new_id) & (lsb_ex.value.firstname == fc_pa_permid_final_demogs_hcs.firstname) & (lsb_ex.value.lastname == fc_pa_permid_final_demogs_hcs.lastname) & (lsb_ex.value.dob == fc_pa_permid_final_demogs_hcs.dob)  & (lsb_ex.value.ssn == fc_pa_permid_final_demogs_hcs.ssn) ,"left")
# print("jn:",jn.count())#952633632
latest=jn.filter("new_id is null").drop("permid","new_id", "firstname", "lastname", "dob", "ssn", "edipartnerfk", "coverageid")
print("latest:",latest.count())


# COMMAND ----------

# DBTITLE 1,Bad records which are being removed
latest1=jn.filter("new_id is not null")
# latest1.select(split("key",'_')[1]).distinct().display()#ich 351947 fm = 1456766
# latest1.filter("key like '%fc'").display()#ich 351947 fm = 1456766 fc 1240798 chc 49219
latest1.count()#3,096,961


# COMMAND ----------

# DBTITLE 1,Roll back on ID level
latest.createOrReplaceTempView("lsb_demo2")
lsb3_sql = """ 
            SELECT
                _id,
                sort_array(collect_list(key) over (PARTITION BY _id)) as hcsystemfk_source_concat,
                identity,
                leadcreatedate,
                leadid,
                leadupdatedate,
                lsbcreatedate,
                date_format(current_timestamp(), "yyyy-MM-dd HH:mm:ss") as lsbupdatedate,
                sort_array(collect_list(struct(key, value)) over (PARTITION BY _id)) as demographics_list,
                ROW_NUMBER() OVER (PARTITION BY _id ORDER BY leadupdatedate DESC) AS RNK
            FROM lsb_demo2 
            """
lsb3 = spark.sql(lsb3_sql).filter("RNK == 1").drop("RNK")
print(lsb3.count())#508,909,209


# COMMAND ----------

lsb4 = lsb3.withColumn('hcsystemfk_source', array_join('hcsystemfk_source_concat' , '|')).drop("hcsystemfk_source_concat")

# COMMAND ----------

latest.select("_id").distinct().count()

# COMMAND ----------

# DBTITLE 1,Covert to LSB format
lsb5 = lsb4.withColumn("demographics", map_from_entries("demographics_list")).drop("demographics_list")
lsb6 = lsb5.select('_id', 'hcsystemfk_source', 'identity', 'leadcreatedate', 'leadid', 'leadupdatedate', 'lsbcreatedate', 'lsbupdatedate', 'demographics')
lsb6.write.mode("overwrite").parquet(scratch_path+"/fc_lsb_final7/")

# COMMAND ----------

# DBTITLE 1,Difference records to be deleted
difference_tobedel=lsb_fm.select('_id').subtract(lsb6.select('_id'))#389758
difference_tobedel.write.parquet(scratch_path+"/difference_tobedeleted7/")
difference_tobedel.count()

# COMMAND ----------

# DBTITLE 1,updated ids count
print("Number of ids updates:",latest1.select("_id").distinct().subtract(difference_tobedel).count())#1533953

# COMMAND ----------

# DBTITLE 1,Read paths
fm_lsbrd=spark.read.parquet(scratch_path+"/fc_lsb_final7/")
diff_tobedeletedrd=spark.read.parquet(scratch_path+"/difference_tobedeleted7/")
lsb_path_source="abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/leadservicebase/publish/mh_hitstatus_cleanup/served/updated_leadservicebase_after_mh_cleanup/"

# COMMAND ----------

fm_lsbrd.display()

# COMMAND ----------

lsb2 = fm_lsbrd.select("*",explode_outer("demographics")).drop("demographics")
lsb2.count()

# COMMAND ----------

# DBTITLE 1,Update lsb
lsb_source = DeltaTable.forPath(spark, lsb_path_source)
lsb_source.alias("curr").merge(fm_lsbrd.alias("new_data"), 'curr._id == new_data._id').whenMatchedUpdateAll().execute()

# COMMAND ----------

# DBTITLE 1,delete bad ids from lsb
lsb_source = DeltaTable.forPath(spark, lsb_path_source)
lsb_source.alias("curr").merge(diff_tobedeletedrd.alias("new_data"), 'curr._id == new_data._id').whenMatchedDelete().execute()