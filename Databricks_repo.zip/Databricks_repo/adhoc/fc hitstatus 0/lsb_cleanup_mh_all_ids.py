# Databricks notebook source
dbutils.widgets.text("dataingestion_publish_path","")
dbutils.widgets.getArgument("dataingestion_publish_path")
dataingestion_publish_path= getArgument("dataingestion_publish_path")

dbutils.widgets.text("scratch_path","")
dbutils.widgets.getArgument("scratch_path")
scratch_path= getArgument("scratch_path")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

dataingestion_publish_path = baseurl+dataingestion_publish_path
scratch_path=baseurl+scratch_path+bc
print("dataingestion_publish_path:",dataingestion_publish_path)
print("scratch_path:",scratch_path)

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from delta.tables import *
from pyspark.sql.functions import concat

# COMMAND ----------

# DBTITLE 1,Read FoundCoverage and filter hitstatus 0 records
all_fc=spark.read.format('delta').load(dataingestion_publish_path+"/foundcoverage/current/20991231/")
fc=all_fc.filter("hitstatus=0")
print("fc hitstatus 0 :",fc.count())#360120335
fc.createOrReplaceTempView("fc")

# COMMAND ----------

# DBTITLE 1,Read Medicarecoverage and hopitals and join with Foundcoverage
medicarecoverage=spark.read.format('delta').load(dataingestion_publish_path+"/medicarecoverage/current/20991231/")
hospitals=spark.read.format('parquet').load(dataingestion_publish_path+"/hospitals/current/20991231/")
medicarecoverage.createOrReplaceTempView("medicarecoverage")
hospitals.createOrReplaceTempView("hospitals")

fc_hosp_medcov=spark.sql(""" Select hospitals.hcsystemfk,fc.hospitalfk,medicarecoverage.MedicareHIC as coverageid,'82' as edipartnerfk,medicarecoverage.MedicareCoverageIPK FROM fc 
        INNER JOIN hospitals ON fc.hospitalfk=hospitals.hospitalpk 
        INNER JOIN medicarecoverage ON 
        fc.hospitalfk=medicarecoverage.hospitalfk AND 
        fc.foundcoverageipk=medicarecoverage.FoundCoverageIFK AND 
        fc.patientacctifk=medicarecoverage.PatientAcctIFK""")
fc_hosp_medcov.count()#27735931

# COMMAND ----------

# DBTITLE 1,Repeate above steps for hitstatus 1,2 records
fc1=all_fc.filter("hitstatus in (1,2)")
print("fc 1,2 :",fc1.count())#4746394840
fc1.createOrReplaceTempView("fc1")

# COMMAND ----------

# DBTITLE 1,Read Medicarecoverage and hopitals and join with Foundcoverage hitstatus 1,2
medicarecoverage=spark.read.format('delta').load(dataingestion_publish_path+"/medicarecoverage/current/20991231/")
hospitals=spark.read.format('parquet').load(dataingestion_publish_path+"/hospitals/current/20991231/")
medicarecoverage.createOrReplaceTempView("medicarecoverage")
hospitals.createOrReplaceTempView("hospitals")

fc_hosp_medcov_1=spark.sql(""" Select hospitals.hcsystemfk,fc1.hospitalfk,medicarecoverage.MedicareHIC as coverageid,'82' as edipartnerfk,medicarecoverage.MedicareCoverageIPK FROM fc1 
        INNER JOIN hospitals ON fc1.hospitalfk=hospitals.hospitalpk 
        INNER JOIN medicarecoverage ON 
        fc1.hospitalfk=medicarecoverage.hospitalfk AND 
        fc1.foundcoverageipk=medicarecoverage.FoundCoverageIFK AND 
        fc1.patientacctifk=medicarecoverage.PatientAcctIFK""")
fc_hosp_medcov_1.count()#1228326203

# COMMAND ----------

# MAGIC %md
# MAGIC # GMRNID

# COMMAND ----------

# DBTITLE 1,Read mh_lr_xref_gmrnid and join with medicarecoverage(hitstatus 0 records)
#Read mh_lr_xref_gmrnid and join with medicarecoverage(hitstatus 0 records) & creating a new column to match _id col in lsb
mh_lr_xref_gmrnid_transaction=spark.read.format("delta").load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/leadrepo/publish/cooked/mh_lr_xref_gmrnid_transaction/").select("transactionkey","gmrnid") #
fcxmh_gmrnid=fc_hosp_medcov.join(mh_lr_xref_gmrnid_transaction, fc_hosp_medcov.MedicareCoverageIPK==mh_lr_xref_gmrnid_transaction.transactionkey)
print("fcxmh_gmrnid:",fcxmh_gmrnid.count())#3654169
fcxmh_gmrnid_id=fcxmh_gmrnid.withColumn("new_id", concat(lit("G_"),fcxmh_gmrnid.gmrnid,lit("_82_"),fcxmh_gmrnid.coverageid)).select("new_id","hcsystemfk","hospitalfk")
fcxmh_gmrnid_id=fcxmh_gmrnid_id.withColumn("hcsystemfk",concat(fcxmh_gmrnid_id.hcsystemfk,lit("_mh")))
print("fcxmh_gmrnid_id:",fcxmh_gmrnid_id.count())

# COMMAND ----------

# DBTITLE 1,join with medicarecoverage(hitstatus 1,2 records) & creating _id col
fcxmh_gmrnid_1=fc_hosp_medcov_1.join(mh_lr_xref_gmrnid_transaction, fc_hosp_medcov_1.MedicareCoverageIPK==mh_lr_xref_gmrnid_transaction.transactionkey)
print("fcxmh_gmrnid_1:",fcxmh_gmrnid_1.count())#432274499
fcxmh_gmrnid_id_1=fcxmh_gmrnid_1.withColumn("new_id", concat(lit("G_"),fcxmh_gmrnid_1.gmrnid,lit("_82_"),fcxmh_gmrnid_1.coverageid)).select("new_id","hcsystemfk","hospitalfk")
fcxmh_gmrnid_id_1=fcxmh_gmrnid_id_1.withColumn("hcsystemfk",concat(fcxmh_gmrnid_id_1.hcsystemfk,lit("_mh")))
print("fcxmh_gmrnid_id_1",fcxmh_gmrnid_id_1.count())#

# COMMAND ----------

# DBTITLE 1,Difference of hitstatus 0 records with 1,2
difff_gmrnid=fcxmh_gmrnid_id.subtract(fcxmh_gmrnid_id_1)#139839
difff_gmrnid.write.parquet(scratch_path+"/gmrnid_diff_tobeupdated/")

# COMMAND ----------

# MAGIC %md
# MAGIC # PERMID

# COMMAND ----------

# DBTITLE 1,Read mh_lr_xref_permid and join with medicarecoverage(hitstatus 0 records)
#Read mh_lr_xref_permid and join with medicarecoverage(hitstatus 0 records) & creating a new column to match _id col in lsb
mh_lr_xref_permid_transaction=spark.read.format("delta").load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/leadrepo/publish/cooked/mh_lr_xref_permid_transaction/").select("transactionkey","permid") #
fcxmh_permid=fc_hosp_medcov.join(mh_lr_xref_permid_transaction, fc_hosp_medcov.MedicareCoverageIPK==mh_lr_xref_permid_transaction.transactionkey)
print("fcxmh_permid:",fcxmh_permid.count())
fcxmh_permid_id=fcxmh_permid.withColumn("new_id", concat(lit("P_"),fcxmh_permid.permid,lit("_82_"),fcxmh_permid.coverageid)).select("new_id","hcsystemfk","hospitalfk")
fcxmh_permid_id=fcxmh_permid_id.withColumn("hcsystemfk",concat(fcxmh_permid_id.hcsystemfk,lit("_mh")))
print("fcxmh_permid_id:",fcxmh_permid_id.count())#

# COMMAND ----------

# DBTITLE 1,join with medicarecoverage(hitstatus 1,2 records) & creating _id col
fcxmh_permid_1=fc_hosp_medcov_1.join(mh_lr_xref_permid_transaction, fc_hosp_medcov_1.MedicareCoverageIPK==mh_lr_xref_permid_transaction.transactionkey)
print("fcxmh_permid_1:",fcxmh_permid_1.count())
fcxmh_permid_id_1=fcxmh_permid_1.withColumn("new_id", concat(lit("P_"),fcxmh_permid_1.permid,lit("_82_"),fcxmh_permid_1.coverageid)).select("new_id","hcsystemfk","hospitalfk")
fcxmh_permid_id_1=fcxmh_permid_id_1.withColumn("hcsystemfk",concat(fcxmh_permid_id_1.hcsystemfk,lit("_mh")))
print("fcxmh_permid_id_1:",fcxmh_permid_id_1.count())

# COMMAND ----------

# DBTITLE 1,Difference of hitstatus 0 records with 1,2
difff_permid=fcxmh_permid_id.subtract(fcxmh_permid_id_1)#128345
difff_permid.write.parquet(scratch_path+"/permid_diff_tobeupdated/")

# COMMAND ----------

# MAGIC %md
# MAGIC # SSN

# COMMAND ----------

#Read mh_lr_xref_ssn_mrn_ and join with medicarecoverage(hitstatus 0 records) & creating a new column to match _id col in lsb
mh_lr_xref_ssn_transaction=spark.read.format("delta").load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/leadrepo/publish/cooked/mh_lr_xref_ssn_mrn_clusterid_transaction/").select("transactionkey","ssn") #
fcxmh_ssn=fc_hosp_medcov.join(mh_lr_xref_ssn_transaction, fc_hosp_medcov.MedicareCoverageIPK==mh_lr_xref_ssn_transaction.transactionkey)
print("fcxmh_ssn:",fcxmh_ssn.count())#
fcxmh_ssn_id=fcxmh_ssn.withColumn("new_id", concat(lit("S_"),fcxmh_ssn.ssn,lit("_82_"),fcxmh_ssn.coverageid)).select("new_id","hcsystemfk","hospitalfk")
fcxmh_ssn_id=fcxmh_ssn_id.withColumn("hcsystemfk",concat(fcxmh_ssn_id.hcsystemfk,lit("_mh")))
print("fcxmh_ssn_id:",fcxmh_ssn_id.count())#

# COMMAND ----------

# DBTITLE 1,join with medicarecoverage(hitstatus 1,2 records) & creating _id col
fcxmh_ssn_1=fc_hosp_medcov_1.join(mh_lr_xref_ssn_transaction, fc_hosp_medcov_1.MedicareCoverageIPK==mh_lr_xref_ssn_transaction.transactionkey)
print("fcxmh_ssn_1:",fcxmh_ssn_1.count())
fcxmh_ssn_id_1=fcxmh_ssn_1.withColumn("new_id", concat(lit("S_"),fcxmh_ssn_1.ssn,lit("_82_"),fcxmh_ssn_1.coverageid)).select("new_id","hcsystemfk","hospitalfk")
fcxmh_ssn_id_1=fcxmh_ssn_id_1.withColumn("hcsystemfk",concat(fcxmh_ssn_id_1.hcsystemfk,lit("_mh")))
print("fcxmh_ssn_id_1:",fcxmh_ssn_id_1.count())

# COMMAND ----------

# DBTITLE 1,Difference of hitstatus 0 records with 1,2
difff_ssn=fcxmh_ssn_id.subtract(fcxmh_ssn_id_1)#118154
difff_ssn.write.parquet(scratch_path+"/ssn_diff_tobeupdated/")

# COMMAND ----------

# MAGIC %md
# MAGIC # MRN

# COMMAND ----------

#Read mh_lr_xref_ssn_mrn_ and join with medicarecoverage(hitstatus 0 records) & creating a new column to match _id col in lsb
mh_lr_xref_mrn_transaction=spark.read.format("delta").load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/leadrepo/publish/cooked/mh_lr_xref_ssn_mrn_clusterid_transaction/").select("transactionkey","medicalrecnum") #
fcxmh_mrn=fc_hosp_medcov.join(mh_lr_xref_mrn_transaction, fc_hosp_medcov.MedicareCoverageIPK==mh_lr_xref_mrn_transaction.transactionkey)
print("fcxmh_mrn:",fcxmh_mrn.count())
fcxmh_mrn_id=fcxmh_mrn.withColumn("new_id", concat(lit("MH_"),fcxmh_mrn.hospitalfk,lit("_"),fcxmh_mrn.medicalrecnum,lit("_82_"),fcxmh_mrn.coverageid)).select("new_id","hcsystemfk","hospitalfk")
fcxmh_mrn_id=fcxmh_mrn_id.withColumn("hcsystemfk",concat(fcxmh_mrn_id.hcsystemfk,lit("_mh")))
print("fcxmh_mrn_id:",fcxmh_mrn_id.count())#

# COMMAND ----------

# DBTITLE 1,join with medicarecoverage(hitstatus 1,2 records) & creating _id col
fcxmh_mrn_1=fc_hosp_medcov_1.join(mh_lr_xref_mrn_transaction, fc_hosp_medcov_1.MedicareCoverageIPK==mh_lr_xref_mrn_transaction.transactionkey)
print("fcxmh_mrn_1:",fcxmh_mrn_1.count())
fcxmh_mrn_id_1=fcxmh_mrn_1.withColumn("new_id", concat(lit("MH_"),fcxmh_mrn.hospitalfk,lit("_"),fcxmh_mrn.medicalrecnum,lit("_82_"),fcxmh_mrn_1.coverageid)).select("new_id","hcsystemfk","hospitalfk")
fcxmh_mrn_id_1=fcxmh_mrn_id_1.withColumn("hcsystemfk",concat(fcxmh_mrn_id_1.hcsystemfk,lit("_mh")))
print("fcxmh_mrn_id_1:",fcxmh_mrn_id_1.count())

# COMMAND ----------

# DBTITLE 1,Difference of hitstatus 0 records with 1,2
difff_mrn=fcxmh_mrn_id.subtract(fcxmh_mrn_id_1)#136544
difff_mrn.write.parquet(scratch_path+"/mrn_diff_tobeupdated/")

# COMMAND ----------

# MAGIC %md
# MAGIC # Clusteredacct

# COMMAND ----------

#Read mh_lr_xref_ssn_mrn_ and join with medicarecoverage(hitstatus 0 records) & creating a new column to match _id col in lsb
mh_lr_xref_cluster_transaction=spark.read.format("delta").load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/leadrepo/publish/cooked/mh_lr_xref_ssn_mrn_clusterid_transaction/").select("transactionkey","clusteredacctfk") #
fcxmh_cluster=fc_hosp_medcov.join(mh_lr_xref_cluster_transaction, fc_hosp_medcov.MedicareCoverageIPK==mh_lr_xref_cluster_transaction.transactionkey)
print("fcxmh_cluster:",fcxmh_cluster.count())
fcxmh_cluster_id=fcxmh_cluster.withColumn("new_id", concat(lit("CH_"),fcxmh_cluster.hospitalfk,lit("_"),fcxmh_cluster.clusteredacctfk,lit("_82_"),fcxmh_cluster.coverageid)).select("new_id","hcsystemfk","hospitalfk")
fcxmh_cluster_id=fcxmh_cluster_id.withColumn("hcsystemfk",concat(fcxmh_cluster_id.hcsystemfk,lit("_mh")))
print("fcxmh_cluster_id:",fcxmh_cluster_id.count())#

# COMMAND ----------

# DBTITLE 1,join with medicarecoverage(hitstatus 1,2 records) & creating _id col
fcxmh_cluster_1=fc_hosp_medcov_1.join(mh_lr_xref_cluster_transaction, fc_hosp_medcov_1.MedicareCoverageIPK==mh_lr_xref_cluster_transaction.transactionkey)
print("fcxmh_cluster_1:",fcxmh_cluster_1.count())
fcxmh_cluster_id_1=fcxmh_cluster_1.withColumn("new_id", concat(lit("CH_"),fcxmh_cluster_1.hospitalfk,lit("_"),fcxmh_cluster_1.clusteredacctfk,lit("_82_"),fcxmh_cluster_1.coverageid)).select("new_id","hcsystemfk","hospitalfk")
fcxmh_cluster_id_1=fcxmh_cluster_id_1.withColumn("hcsystemfk",concat(fcxmh_cluster_id_1.hcsystemfk,lit("_mh")))
print("fcxmh_cluster_id_1:",fcxmh_cluster_id_1.count())

# COMMAND ----------

# DBTITLE 1,Difference of hitstatus 0 records with 1,2
difff_cluster=fcxmh_cluster_id.subtract(fcxmh_cluster_id_1)#162384
difff_cluster.write.parquet(scratch_path+"/cluster_diff_tobeupdated/")

# COMMAND ----------

# DBTITLE 1,Read all hitstatus 0 ids
difff=spark.read.parquet(scratch_path+"/*_diff_tobeupdated")
difff.count()#685266

# COMMAND ----------

# MAGIC %md
# MAGIC # LSB

# COMMAND ----------

# DBTITLE 1,Read LSB  with mh records
lsb = spark.read.format("delta").load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/leadservicebase/publish/mh_hitstatus_cleanup/served/leadservicebase/")#4305573163
lsb_mh = lsb.filter(col("hcsystemfk_source").contains('mh'))#38762769
lsb_ex = lsb_mh.select("*",explode_outer("demographics")).drop("demographics")
print("lsb:",lsb.count())
print("lsb_mh:",lsb_mh.count())
print("lsb_ex:",lsb_ex.count())#66715749

# COMMAND ----------

# DBTITLE 1,Level 2 explode on hospitalfk
import pyspark.sql.functions as f
lsb_exp2=lsb_ex.select(f.split("value.hospitalfk",'[|]').alias('tmp'),"*").withColumn("tmp",f.explode("tmp"))
lsb_exp2=lsb_exp2.withColumn("value",lsb_exp2["value"].withField("hospitalfk", lsb_exp2.tmp)).drop("tmp")
lsb_exp2.count()#79741774

# COMMAND ----------

# DBTITLE 1,joining hitstatus 0 records with lsb level 2 explode on id, hcsystem& hospital
#joining hitstatus 0 records with lsb level 2 explode on id, hcsystem& hospital & Filtering all the good records
jn=lsb_exp2.join(difff, (lsb_exp2._id == difff.new_id) & (lsb_exp2.key == difff.hcsystemfk) & (difff.hospitalfk==lsb_exp2.value.hospitalfk),"left")
print("jn:",jn.count())#79693982
latest=jn.filter("new_id is null").drop("new_id","hcsystemfk","hospitalfk")
print("latest:",latest.count())

# COMMAND ----------

latest.select("_id").distinct().count()

# COMMAND ----------

# DBTITLE 1,Bad records which are removed
latest1=jn.filter("new_id is not null").drop("new_id","hcsystemfk","hospitalfk")
latest1.count()#

# COMMAND ----------

# DBTITLE 1,prepare for rollup, creating a hospitalfk value for the good records
new1=latest.select('*').groupBy("_id","key").agg(concat_ws("|",collect_list("value.hospitalfk")).alias("merged_value"))
new1=new1.select("_id","key","merged_value")
new1.count()#66438600

# COMMAND ----------

# DBTITLE 1,joining back to good records to update the hospitalfk value
test_jn1=latest.join(new1,(latest._id==new1._id) & (latest.key==new1.key)).select(latest["*"],new1["merged_value"])
print("test_jn1:",test_jn1.count())#
test_jn1=test_jn1.withColumn("value",test_jn1["value"].withField("hospitalfk", test_jn1.merged_value)).drop("merged_value")
print("test_jn1_hosp_updated:",test_jn1.count())#
test_jn2=test_jn1.dropDuplicates()# 
print("test_jn2:",test_jn2.count())

# COMMAND ----------

# DBTITLE 1,Rollback on hcsystemfk_source
test_jn3=test_jn2.groupBy("_id").agg(concat_ws("|",collect_list("key")).alias("hcsystemfk_source1")).drop("identity","leadcreatedate","leadid","leadupdatedate","lsbcreatedate","lsbupdatedate")
print("test_jn3:",test_jn3.count())#38537924
test_jn4=test_jn2.join(test_jn3,"_id")#66438600
print("test_jn4:",test_jn4.count())

# COMMAND ----------

# DBTITLE 1,Roll back on ID level
test_jn4.createOrReplaceTempView("lsb_demo2")
lsb3_sql = """ 
            SELECT
                _id,
                hcsystemfk_source1 as hcsystemfk_source,
                identity,
                leadcreatedate,
                leadid,
                leadupdatedate,
                lsbcreatedate,
                date_format(current_timestamp(), "yyyy-MM-dd HH:mm:ss") as lsbupdatedate,
                sort_array(collect_list(struct(key, value)) over (PARTITION BY _id)) as demographics_list,
                ROW_NUMBER() OVER (PARTITION BY _id ORDER BY leadupdatedate DESC) AS RNK
            FROM lsb_demo2 
            """
lsb3 = spark.sql(lsb3_sql).filter("RNK == 1").drop("RNK")
print(lsb3.count())#38537924


# COMMAND ----------

# DBTITLE 1,Covert to LSB format
lsb5 = lsb3.withColumn("demographics", map_from_entries("demographics_list")).drop("demographics_list")
lsb5.write.parquet(scratch_path+"/fc_lsb_final/")

# COMMAND ----------

# DBTITLE 1,Difference records to be deleted
difference_tobedel=lsb_mh.select('_id').subtract(lsb5.select('_id'))#224845
difference_tobedel.write.parquet(scratch_path+"/difference_tobedel/")
difference_tobedel.count()

# COMMAND ----------

print("Number of ids updates:",latest1.select("_id").distinct().subtract(difference_tobedel).count())#

# COMMAND ----------

# DBTITLE 1,Read paths
mh_lsbrd=spark.read.parquet(scratch_path+"/fc_lsb_final/")
diff_tobedeletedrd=spark.read.parquet(scratch_path+"/difference_tobedel/")
lsb_path_source="abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/leadservicebase/publish/mh_hitstatus_cleanup/served/leadservicebase/"

# COMMAND ----------

# DBTITLE 1,Update lsb
lsb_source = DeltaTable.forPath(spark, lsb_path_source)
lsb_source.alias("curr").merge(mh_lsbrd.alias("new_data"), 'curr._id == new_data._id').whenMatchedUpdateAll().execute()

# COMMAND ----------

# DBTITLE 1,delete bad ids from lsb
lsb_source = DeltaTable.forPath(spark, lsb_path_source)
lsb_source.alias("curr").merge(diff_tobedeletedrd.alias("new_data"), 'curr._id == new_data._id').whenMatchedDelete().execute()