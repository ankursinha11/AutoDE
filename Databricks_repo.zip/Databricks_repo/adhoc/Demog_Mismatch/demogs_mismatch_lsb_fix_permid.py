# Databricks notebook source
dbutils.widgets.text("cdd_publish_path","")
dbutils.widgets.getArgument("cdd_publish_path")
cdd_publish_path= getArgument("cdd_publish_path")

dbutils.widgets.text("dataingestion_publish_path","")
dbutils.widgets.getArgument("dataingestion_publish_path")
dataingestion_publish_path= getArgument("dataingestion_publish_path")

dbutils.widgets.text("gmrn_publish_path","")
dbutils.widgets.getArgument("gmrn_publish_path")
gmrn_publish_path= getArgument("gmrn_publish_path")

dbutils.widgets.text("leaddiscovery_transform_path","")
dbutils.widgets.getArgument("leaddiscovery_transform_path")
leaddiscovery_transform_path= getArgument("leaddiscovery_transform_path")

dbutils.widgets.text("notificationtype","")
dbutils.widgets.getArgument("notificationtype")
notificationtype= getArgument("notificationtype")

dbutils.widgets.text("lead_mode_flag","")
dbutils.widgets.getArgument("lead_mode_flag")
lead_mode_flag= getArgument("lead_mode_flag")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

cdd_publish_path = baseurl+cdd_publish_path
dataingestion_publish_path = baseurl+dataingestion_publish_path
gmrn_publish_path = baseurl+gmrn_publish_path
leaddiscovery_transform_path = baseurl+leaddiscovery_transform_path
candidatepa_path = leaddiscovery_transform_path + notificationtype + '/candidatepa/'+bc+'/'
hdfs_admitdatelookup=leaddiscovery_transform_path+notificationtype+'/minmaxbyhospital/'+bc+'/*'
hdfs_scratch=leaddiscovery_transform_path+notificationtype+'/leadstatus/'+bc+'/test_mc/'
pa_path=dataingestion_publish_path+'/patientaccts/current/20991231/'
pac_path=dataingestion_publish_path+'/patientacctscodes/current/20991231/'

print("--------------------------------------------------------------------------------")
print("bc="+str(bc))
print("cdd_publish_path="+str(cdd_publish_path))
print("dataingestion_publish_path="+str(dataingestion_publish_path))
print("gmrn_publish_path="+str(gmrn_publish_path))
print("lead_mode_flag="+str(lead_mode_flag))
print("leaddiscovery_transform_path="+str(leaddiscovery_transform_path))
print("notificationtype="+str(notificationtype))
print("--------------------------------------------------------------------------------")
print("candidatepa_path="+str(candidatepa_path))
print("hdfs_admitdatelookup="+str(hdfs_admitdatelookup))
print("hdfs_scratch="+str(hdfs_scratch))
print("pa_path="+str(pa_path))
print("pac_path="+str(pac_path))

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
import sys
import datetime
import getpass
import os
import sys
import subprocess
from delta.tables import *

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/schema_util"

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/tu_data_quality"

# COMMAND ----------

fs_common="abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/leadrepo/config/xref"
schema = createSchemaLine(fs_common + "/lr_xref_parse.schema")
imrecs_schema = createSchemaLine(fs_common + "/lr_xref_parse_imrecs.schema")

# COMMAND ----------

# DBTITLE 1,Read ie data
path_input = "abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/cdd/publish/ie/imRecs/*/*"
raw = spark.read.format("csv") \
                  .options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", mode="FAILFAST", quote="", delimiter="|") \
                  .schema(imrecs_schema).load(path_input) \
                  .selectExpr("iepermid","subscriberfirstname","subscribermiddlename","subscriberlastname","subscriberdob","subscriberssn","subscribergender","subscriberstate","received","clientid").dropDuplicates()
raw.createOrReplaceTempView('ie')
ie_imRecs_unique = spark.sql("""
                    SELECT ie.*,  
                    ROW_NUMBER() OVER (PARTITION BY iepermid,clientid ORDER BY CAST(received AS TIMESTAMP) DESC) AS rn
                    FROM ie
                    """)
ie_imRecs_unique = ie_imRecs_unique.filter("rn = 1").drop("rn")
ie_imRecs_unique.write.mode("overwrite").format("parquet").save("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/demog_mismatch_permid/ie_imRecs_unique/ie/")

# COMMAND ----------

# DBTITLE 1,Read es data
path_input = "abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/cdd/publish/escanoutput/finalPolicyInfo/*/*"
raw_cleaned = spark.read.format("csv") \
                   .options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", mode="FAILFAST", quote="", delimiter="|") \
                   .schema(schema).load(path_input) \
                   .selectExpr("iepermid","subscriberfirstname","subscribermiddlename","subscriberlastname","subscriberdob","subscriberssn","subscribergender","subscriberstate","received","clientid").dropDuplicates()
raw_cleaned.createOrReplaceTempView('es')
es_escanoutput_unique = spark.sql("""
                    SELECT es.*,  
                    ROW_NUMBER() OVER (PARTITION BY iepermid,clientid ORDER BY CAST(received AS TIMESTAMP) DESC) AS rn
                    FROM es
                    """)
es_escanoutput_unique = es_escanoutput_unique.filter("rn = 1").drop("rn")
es_escanoutput_unique.write.mode("overwrite").format("parquet").save("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/demog_mismatch_permid/ie_imRecs_unique/es/")

# COMMAND ----------

# DBTITLE 1,Union of ie&es
ie_es_union=spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/demog_mismatch_permid/ie_imRecs_unique/*/")
ie_es_union.createOrReplaceTempView("ie_es_union")
ie_es_unique_union = spark.sql("""Select * from (Select *, row_number() over (partition by iepermid, clientid order by received desc) as rn from ie_es_union)x where x.rn =1""").drop("rn")
ie_es_unique_union = ie_es_unique_union.withColumn("subscriberssn", when(col("subscriberssn").isNull(), '000000000').otherwise(col("subscriberssn")))
ie_es_unique_union = ie_es_unique_union.withColumn("subscriberssn",(trim(regexp_replace(col("subscriberssn"), '-', ''))))
ie_es_unique_union.write.mode("overwrite").format("parquet").save("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/demog_mismatch_permid/ie_es_union_step1/")

# COMMAND ----------

# DBTITLE 1,lsb data
ie_es_unique_union=spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/demog_mismatch_permid/ie_es_union_step1/")
print("Get all unique permid+client_id records with latest demographics: ",ie_es_unique_union.count())#791,676,181
lsb = spark.read.format("delta").load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/leadservicebase/publish/served/latest_lsb/leadservicebase/")
lsb_g =lsb.filter(col("_id").startswith('G'))
lsb_p =lsb.filter(col("_id").startswith('P'))
lsb_s =lsb.filter(col("_id").startswith('S'))
lsb_m =lsb.filter(col("_id").startswith('MH'))
lsb_c =lsb.filter(col("_id").startswith('CH'))

print("LSB Total count:" + str(lsb.count()))#4074864542
print("LSB gmrnid count:" + str(lsb_g.count()))#1076850464
print("LSB permid count:" + str(lsb_p.count()))#1151862206
print("LSB ssn count:" + str(lsb_s.count()))#401101966
print("LSB mrn count:" + str(lsb_m.count()))#680613599
print("LSB clusteredacct count:" + str(lsb_c.count()))#764436306


# COMMAND ----------

lsb_ex = lsb_p.select("*",explode_outer("demographics")).drop("demographics")
lsb_ex = lsb_ex.filter(col("key").contains('ich')).drop("hcsystemfk_source")      
lsb_ex.write.mode("overwrite").format("parquet").save("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/demog_mismatch_permid/lsb_ich_step2/")

# COMMAND ----------

lsb_ex=spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/demog_mismatch_permid/lsb_ich_step2/")
print("Get all lsb PERMID leads only ICH leads: ", lsb_ex.count())#811,583,278

# COMMAND ----------

InvalidStartsWithSSN = ['9','666','000']
InvalidSSNListAdvertisements = ['002281852','128036045','165207999','212099999','042103580','135016629',
                                '165227999','306302348','062360749','141186941','165247999','308125070',
                                '078051120','165167999','189092294','468288779','095073645','165187999',
                                '212097694','549241889']
InvalidSSNContainsList = ['12345678','111111','2222222','3333333','4444444','5555555','6666666','7777777',
                          '8888888','999999','0000000']
InvalidSSNList = ['987654321','100101000','111223333','010101010','121212121','777889999','100101000','111999999',
                  '012345678','111223333','010101010','009111111','121212121','888999999','777889999','123123123',
                  '123999999','123121234','090909090','111121212','001010001','111223344','049999904','101010101',
                  '111551114','121121212','123456780','111221111','111223456','449989555','059700970','060507537',
                  '499888888','123456788','000000000']

# COMMAND ----------

def isValidSSN(ssn):
    # empty or white space
    if not ssn:
        return 0
    newssn  = ssn.strip().replace("-","")
    if not newssn:
        return 0
    # contains exactly 9 numbers
    _ssn_re = re.compile(r"^[0-9]{9}$")
    match = _ssn_re.match(newssn)
    if not match:
        return 0
    # invalid ssn -- used in ads
    if newssn in InvalidSSNListAdvertisements:
        return 0
    # invalid ssn -- magic numbers used by hospitals
    if newssn in InvalidSSNList:
        return 0
    # invalid starts with
    for ssn_start in InvalidStartsWithSSN:
        if newssn.startswith(ssn_start):
            return 0
    # ends with 0000
    if newssn.endswith('0000'):
        return 0
    # can't have 00 in middle set xxx-00-xxxx
    _ssn_re = re.compile(r"^[0-9]{3}00[0-9]{4}$")
    match = _ssn_re.match(newssn)
    if match:
        return 0
    # invalid contains
    for ssn in InvalidSSNContainsList:
        if ssn in newssn:
            return 0
    return 1

# COMMAND ----------

isValidSSN_udf = udf(isValidSSN, IntegerType())

# COMMAND ----------

# DBTITLE 1,Join LSB and final policy info
# Set the legacy time parser policy
spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")
ca = ie_es_unique_union.join(
    lsb_ex,
    (concat(lit('P_'), ie_es_unique_union.iepermid) == lsb_ex.identity) &
    (split(lsb_ex.key, '_')[0] == ie_es_unique_union.clientid)
)
print("Join step 1 and 2 on permid & clientid: ",ca.count())#809,544,108
#ca.write.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/demog_mismatch/ca_ie_es_joinop/")

#DOB
ca_dob = ca.filter((col("subscriberdob").isNotNull() ) & (col("subscriberdob") != '00000000'))
ca_dob = ca_dob.filter(upper(trim(col("subscriberdob"))) != upper(trim(regexp_replace(col("value.dob"), '-', ''))))
ca_dob.write.mode("overwrite").format("parquet").save("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/demog_mismatch_permid/ca_dob_notmatching/")

#SSN
ca_ssn = ca.withColumn("subscriberssn",(trim(regexp_replace(col("subscriberssn"), '-', ''))))
ca_ssn_udf = ca_ssn.withColumn('SSN', when(isValidSSN_udf(ca_ssn.subscriberssn) == 1, lit('1')).otherwise(lit('0')))
ca_ssn_udf=ca_ssn_udf.filter("SSN='1'").drop("SSN")
ca_ssn_final=ca_ssn_udf.filter(col("subscriberssn")!=col("value.ssn"))
ca_ssn_final.write.mode("overwrite").format("parquet").save("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/demog_mismatch_permid/ca_ssn_notmatching/")



# COMMAND ----------

ca_dob_rd=spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/demog_mismatch_permid/ca_dob_notmatching/")
ca_ssn_rd=spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/demog_mismatch_permid/ca_ssn_notmatching/")
print("demorgraphic records which doesnt match on  DOB:",ca_dob_rd.count())#40,203,912
print("demorgraphic records which doesnt match on  SSN:",ca_ssn_rd.count())#68,481,137

ca_union = ca_dob_rd.union(ca_ssn_rd)
ca_union = ca_union.withColumn("subscriberdob", date_format(to_date("subscriberdob", "yyyyMMdd"),"yyyy-MM-dd")) #changing the format for lsb

ca_final = ca_union.select("_id","key", "subscriberfirstname", "subscribermiddlename","subscriberlastname", "subscriberdob", "subscribergender","subscriberssn","subscriberstate").dropDuplicates()

ca_final.write.mode("overwrite").format("parquet").save("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/demog_mismatch_permid/ca_final_step3/")#79857110 104678640 after change

# COMMAND ----------

# DBTITLE 1,STEP4:Join LSB and CA
lsb = spark.read.format("delta").load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/leadservicebase/publish/served/latest_lsb/leadservicebase")
lsb_ich = lsb.filter(col("_id").startswith('P')).filter(col("hcsystemfk_source").contains('ich'))
ca_final = spark.read.format("parquet").load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/demog_mismatch_permid/ca_final_step3/")
print("ca_final records:",ca_final.count())

ca_final=ca_final.withColumnRenamed("key","c_key").withColumnRenamed("_id","c_id").select("c_id").dropDuplicates()
ca_lsb_jn=ca_final.join(lsb_ich,(ca_final.c_id == lsb_ich._id)).drop("c_id")
print("ca_final records joined with lsb_ich: ",ca_lsb_jn.count())#72663532 after cjhange 94,426,901

ca_lsb_jn_ex=ca_lsb_jn.select("*",explode_outer("demographics")).drop("demographics")
ca_lsb_jn_ex.write.mode("overwrite").format("parquet").save("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/demog_mismatch_permid/lsb_demogs_need_to_updated_latest_parquet/")#205,688,899 after change 262,606,525

# COMMAND ----------

from pyspark.sql.functions import col
ca_lsb_jn=spark.read.format("parquet").load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/demog_mismatch_permid/lsb_demogs_need_to_updated_latest_parquet/")
print("After Explode lsb_ready_to_be_loaded:", ca_lsb_jn.count())
ca_final = spark.read.format("parquet").load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/demog_mismatch_permid/ca_final_step3/")
ca_final=ca_final.withColumnRenamed("key","c_key")
ca_final=ca_final.withColumnRenamed("_id","c_id")
ca_lsb_jn_rd = ca_lsb_jn.join(ca_final,(ca_final.c_id == ca_lsb_jn._id) & (ca_final.c_key == ca_lsb_jn.key), 'left')

# COMMAND ----------

ca_lsb_jn_rd_filtered = ca_lsb_jn_rd.filter((upper(trim(col("subscriberfirstname")))==upper(trim(col("value.firstname")))) & (upper(trim(col("subscriberlastname"))) == upper(trim(col("value.lastname"))))) # 45796495 after change 61772733

# COMMAND ----------

ca_lsb_jn_rd_filtered_t = ca_lsb_jn_rd_filtered.withColumn("value",when((col("c_key") == col("key"))  & (col("subscriberdob").isNotNull()) & (col("subscriberdob") != '00000000') &  ((col("value.dob").isNull()) | (col("value.dob") == '') ), ca_lsb_jn_rd_filtered["value"].withField("dob", col("subscriberdob"))).otherwise(col("value")))\
    .withColumn("value",when((col("c_key") == col("key"))  & (col("subscriberssn").isNotNull()) & (col("subscriberssn") != '000000000') &  ((col("value.ssn").isNull()) | (col("value.ssn") == '') | (col("value.ssn") == '000000000') ), ca_lsb_jn_rd_filtered["value"].withField("ssn", col("subscriberssn"))).otherwise(col("value")))\
    .withColumn("value",when((col("c_key") == col("key")) & (((col("value.middlename") == '')) | ((col("value.middlename").isNull()))) , ca_lsb_jn_rd_filtered["value"].withField("middlename", col("subscribermiddlename"))).otherwise(col("value")))\
    .withColumn("value",when((col("c_key") == col("key")) & (((col("value.gender") == '')) | ((col("value.gender").isNull()))) , ca_lsb_jn_rd_filtered["value"].withField("gender", col("subscribergender"))).otherwise(col("value")))\
    .withColumn("value",when((col("c_key") == col("key")) & (((col("value.state") == '')) | ((col("value.state").isNull())) | ((col("value.state") == 'XX'))  ), ca_lsb_jn_rd_filtered["value"].withField("state", col("subscriberstate"))).otherwise(col("value")))\
    .drop("subscriberdob", "subscriberfirstname", "subscribermiddlename", "subscriberlastname","subscribergender", "subscriberssn", "subscriberstate", "c_key","c_id")

ca_lsb_jn_rd_filtered_t.write.mode("overwrite").format("parquet").save("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/demog_mismatch_permid/lsb_ready_to_be_loaded_fn_ln_matching/")


# COMMAND ----------

ca_lsb_jn_rd_not_filtered = ca_lsb_jn_rd.exceptAll(ca_lsb_jn_rd_filtered) # 159892404 after cahnge 200833792

# COMMAND ----------

ca_lsb_jn_rd_not_filtered_t = ca_lsb_jn_rd_not_filtered.withColumn("value",when((col("c_key") == col("key"))  & (col("subscriberdob").isNotNull()) & (col("subscriberdob") != '00000000'), ca_lsb_jn_rd_not_filtered["value"].withField("dob", col("subscriberdob"))).otherwise(col("value")))\
    .withColumn("value",when((col("c_key") == col("key"))  & (col("subscriberssn").isNotNull()) & (col("subscriberssn") != '000000000') , ca_lsb_jn_rd_not_filtered["value"].withField("ssn", col("subscriberssn"))).otherwise(col("value")))\
    .withColumn("value",when((col("c_key") == col("key")) & (((col("subscriberfirstname") != '')) | ((col("subscriberfirstname").isNotNull()))) , ca_lsb_jn_rd_not_filtered["value"].withField("firstname", col("subscriberfirstname"))).otherwise(col("value")))\
    .withColumn("value",when((col("c_key") == col("key")) & (((col("subscribermiddlename") != '')) | ((col("subscribermiddlename").isNotNull()))) , ca_lsb_jn_rd_not_filtered["value"].withField("middlename", col("subscribermiddlename"))).otherwise(col("value")))\
    .withColumn("value",when((col("c_key") == col("key")) & (((col("subscriberlastname") != '')) | ((col("subscriberlastname").isNotNull()))) , ca_lsb_jn_rd_not_filtered["value"].withField("lastname", col("subscriberlastname"))).otherwise(col("value")))\
    .withColumn("value",when((col("c_key") == col("key")) & (((col("subscribergender") != '')) | ((col("subscribergender").isNotNull())) ), ca_lsb_jn_rd_not_filtered["value"].withField("gender", col("subscribergender"))).otherwise(col("value")))\
    .withColumn("value",when((col("c_key") == col("key")) & (((col("subscriberstate") != '')) | ((col("subscriberstate").isNotNull())) | ((col("subscriberstate") != 'XX'))), ca_lsb_jn_rd_not_filtered["value"].withField("state", col("subscriberstate"))).otherwise(col("value")))\
    .drop("subscriberdob", "subscriberfirstname", "subscribermiddlename", "subscriberlastname","subscribergender", "subscriberssn", "subscriberstate", "c_key","c_id")

ca_lsb_jn_rd_not_filtered_t.write.mode("overwrite").format("parquet").save("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/demog_mismatch_permid/lsb_ready_to_be_loaded_fn_ln_not_matching/")


# COMMAND ----------

final_leads=ca_lsb_jn_rd_filtered_t.union(ca_lsb_jn_rd_not_filtered_t)
final_leads.write.mode("overwrite").format("parquet").save("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/demog_mismatch_permid/lsb_ready_to_be_loaded_parquet/")#205688899

# COMMAND ----------

lsb_ready_to_be_loaded = spark.read.format('parquet').load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/demog_mismatch_permid/lsb_ready_to_be_loaded_parquet/")
print("lsb_ready_to_be_loaded:", lsb_ready_to_be_loaded.count())
lsb_ready_to_be_loaded.createOrReplaceTempView("lsb_demo2")
lsb3_sql = """ 
            SELECT
                _id,
                hcsystemfk_source,
                identity,
                leadcreatedate,
                leadid,
                leadupdatedate,
                lsbcreatedate,
                date_format(current_timestamp(), "yyyy-MM-dd HH:mm:ss") as lsbupdatedate,
                sort_array(collect_list(struct(key, value)) over (PARTITION BY _id)) as demographics_list,
                ROW_NUMBER() OVER (PARTITION BY _id ORDER BY leadupdatedate DESC) AS RNK
            FROM lsb_demo2 
            """
lsb3 = spark.sql(lsb3_sql).filter("RNK == 1").drop("RNK")
print(lsb3.count())#72663532


# COMMAND ----------

lsb5 = lsb3.withColumn("demographics", map_from_entries("demographics_list")).drop("demographics_list")
lsb6 = lsb5.select('_id', 'hcsystemfk_source', 'identity', 'leadcreatedate', 'leadid', 'leadupdatedate', 'lsbcreatedate', 'lsbupdatedate', 'demographics')
lsb6.repartition(100).write.mode("overwrite").parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/demog_mismatch_permid/lsb_demo_final_latest/")#94426901

# COMMAND ----------

lsb_path_source="abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/ramcharan/data/leadservicebase/publish/served/latest_lsb/leadservicebase/"

# COMMAND ----------

lsb_source = DeltaTable.forPath(spark, lsb_path_source)
lsb_source.alias("curr").merge(lsb6.alias("new_data"), 'curr._id == new_data._id').whenMatchedUpdateAll().execute()

# COMMAND ----------

lastOperationDF_src = lsb_source.history(3).filter("operation = 'MERGE'")
inserts = lastOperationDF_src.select(collect_list("operationMetrics.numTargetRowsInserted"))
updates = lastOperationDF_src.select(collect_list("operationMetrics.numTargetRowsUpdated"))

print("Number of rows inserted into the target table: " + str(inserts.first()[0]) )
print("Number of rows updated in the target table: " +  str(updates.first()[0]) )
