# Databricks notebook source
#use below parameters

#container - "prod-icd-adls" or "prod-icd-stg-adls"
#storageaccount - "prodicddls" or "prodicdstgdls"
#source_publish_path - "/data/cdd/publish/ie_cm2/missingPAIds/current_old/" (rename the existing current to current_old)
#patientaccts_path - "/data/dataingestion/publish/patientaccts/current/20991231/"
#dest_publish_path - "/data/cdd/publish/ie_cm2/missingPAIds/current/"
#user - "na" or "<youruser>"

# COMMAND ----------

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user", "")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container", "")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("source_publish_path", "")
dbutils.widgets.getArgument("source_publish_path")
source_publish_path= getArgument("source_publish_path")

dbutils.widgets.text("patientaccts_path", "")
dbutils.widgets.getArgument("patientaccts_path")
patientaccts_path= getArgument("patientaccts_path")

dbutils.widgets.text("dest_publish_path","")
dbutils.widgets.getArgument("dest_publish_path")
dest_publish_path= getArgument("dest_publish_path")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

# COMMAND ----------

# MAGIC %run "/Insleads-code/Common-Util/common_util"

# COMMAND ----------

from pyspark.sql.types import StructField, StructType, IntegerType, ShortType
from pyspark.sql.functions import col

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 
print(baseurl)

# COMMAND ----------

source_publish_path = baseurl+source_publish_path +'*'
patientaccts_path = baseurl+patientaccts_path 
dest_publish_path = baseurl+dest_publish_path + bc

print(source_publish_path)
print(patientaccts_path)
print(dest_publish_path)

# COMMAND ----------

patientacct_df = spark.read.format("delta").load(patientaccts_path)

# COMMAND ----------

def readFile(spark, filepath, schema):
    df = spark.read.format("csv") \
        .options(timestampFormat="yyyy/MM/dd HH:mm:ss ZZ", delimiter="|") \
        .schema(schema) \
        .load(filepath)
    return df

# COMMAND ----------

existing_schema_missingPAIds = StructType([
    StructField("PAId", StringType())
])

# COMMAND ----------

existing_missingPAIds_df = readFile(spark, source_publish_path, existing_schema_missingPAIds)    

# COMMAND ----------

joined_df = existing_missingPAIds_df.join(patientacct_df, existing_missingPAIds_df.PAId == patientacct_df.patientacctipk, "inner").select(existing_missingPAIds_df.PAId, col("hospitalfk").cast("string").alias("hospitalfk"))

# COMMAND ----------

joined_df.write \
    .option("sep", "|") \
    .mode("overwrite") \
    .csv(dest_publish_path)

