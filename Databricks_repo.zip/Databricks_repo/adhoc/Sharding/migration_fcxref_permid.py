# Databricks notebook source
# fc_xref_input = '/data/leadrepo/publish/cooked/lr_xref_permid_transaction_old/' (rename existing one to _old before migration)
# fc_xref_output = '/data/leadrepo/publish/cooked/lr_xref_permid_transaction/'
# fc_publish_path = '/data/dataingestion/publish/foundcoverage/current/20991231/'
# storageaccount = 'prodicddls'
# container = 'prod-icd-adls'
# user = 'na'

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("fc_xref_input","")
dbutils.widgets.getArgument("fc_xref_input")
fc_xref_input= getArgument("fc_xref_input")

dbutils.widgets.text("fc_xref_output","")
dbutils.widgets.getArgument("fc_xref_output")
fc_xref_output= getArgument("fc_xref_output")

dbutils.widgets.text("fc_publish_path","")
dbutils.widgets.getArgument("fc_publish_path")
fc_publish_path= getArgument("fc_publish_path")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user
print(baseurl)

# COMMAND ----------

fc_xref_input = baseurl+fc_xref_input
fc_xref_output = baseurl+fc_xref_output
fc_publish_path = baseurl+fc_publish_path

print(f'fc_xref_input: {fc_xref_input}')
print(f'fc_xref_output: {fc_xref_output}')
print(f'fc_publish_path: {fc_publish_path}')

# COMMAND ----------

fc_publish_df = spark.read.format("delta").load(fc_publish_path)

# COMMAND ----------

existing_xref_df = spark.read.format('delta').load(fc_xref_input)
fc_xref_df = existing_xref_df.filter(col('sourcekey') == "1")
ich_xref_df = existing_xref_df.filter(col('sourcekey') == "2").withColumn('hospitalfk', lit(''))

# COMMAND ----------

xref_fc_joined_df = fc_xref_df.join(fc_publish_df, fc_xref_df["transactionkey"] == fc_publish_df["foundcoverageipk"], "inner") \
               .select(fc_xref_df["*"], fc_publish_df["hospitalfk"])

# COMMAND ----------

xref_fc_joined_df = xref_fc_joined_df.withColumn(
        "_id1",
        concat_ws("_", xref_fc_joined_df.permid, xref_fc_joined_df.transactionkey,xref_fc_joined_df.hospitalfk,xref_fc_joined_df.sourcekey),
    )

# COMMAND ----------

xref_fc_joined_df = xref_fc_joined_df.drop("_id")
xref_fc_joined_df = xref_fc_joined_df.withColumnRenamed("_id1", "_id")

# COMMAND ----------

cols = [
    "audittrail", "lr_createdate", "lr_creatingmodule", "permid",
    "sourcekey","transactionkey", "xrefsource", "hospitalfk", "_id"
]

new_order = ["_id"] + [col for col in cols if col != "_id"]

xref_fc_joined_df = xref_fc_joined_df[new_order]

# COMMAND ----------

migrated_xref_df = xref_fc_joined_df.union(ich_xref_df)

# COMMAND ----------

migrated_xref_df.write.format("delta").mode("overwrite").save(fc_xref_output)
