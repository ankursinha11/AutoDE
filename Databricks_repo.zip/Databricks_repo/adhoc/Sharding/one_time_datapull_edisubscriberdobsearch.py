# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("scratch_path","")
dbutils.widgets.getArgument("scratch_path")
scratch_path= getArgument("scratch_path")

dbutils.widgets.text("dataingestion_publish_path","")
dbutils.widgets.getArgument("dataingestion_publish_path")
dataingestion_publish_path= getArgument("dataingestion_publish_path")

# bc='20251005T13'
# container='prod-icd-stg-adls'
# dataingestion_publish_path='/data/dataingestion/publish/'
# scratch_path='/data/adhoc/'
# storageaccount='prodicdstgdls'
# user='na'

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

db='escan.dbo.'
tablename = 'EDISubscriberDOBSearch'
scratch_path = baseurl + scratch_path + bc +'/'+ tablename+'_temp/'
dataingestion_publish_path = baseurl + dataingestion_publish_path
print("scratch_path: "+scratch_path)
print("dataingestion_publish_path: "+dataingestion_publish_path)

# COMMAND ----------

string_connection = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-dataingestion-sql-insleads-cs")
table_query_primary = "(SELECT edisubscriberdobsearchpk, hospitalfk,processflag,coverageid FROM " + db + tablename + " (NOLOCK) ) as a "
print("table_query_primary : "+table_query_primary)

# COMMAND ----------

data_primary = spark.read.format("jdbc").option("url", string_connection) \
.option("dbtable", table_query_primary) \
.option("numPartitions", 20) \
.option("fetchsize", 1000) \
.load()
data_primary.write.mode('overwrite').parquet(scratch_path)

# COMMAND ----------

prod_edisubscriberdobsearch_df=spark.read.format('delta').load(dataingestion_publish_path +'edisubscriberdobsearch/current/20991231/')
temp_df=spark.read.parquet(scratch_path)
prod_edisubscriberdobsearch_df.createOrReplaceTempView("input_df_tbl")
temp_df.createOrReplaceTempView("sql_table_tbl")
print("input:",prod_edisubscriberdobsearch_df.count())
print("sql_df:",temp_df.count())
op_df=spark.sql("""select ip.*, sq.processflag, sq.coverageid from input_df_tbl ip left join sql_table_tbl sq on ip.edisubscriberdobsearchpk = sq.edisubscriberdobsearchpk and ip.hospitalfk= sq.hospitalfk""")
# op_df.count()

# COMMAND ----------

op_df.write.mode('overwrite').format('delta').save(dataingestion_publish_path +'edisubscriberdobsearch_new/current/20991231/')
