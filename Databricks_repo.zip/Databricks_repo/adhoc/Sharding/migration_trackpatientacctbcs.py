# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user", "")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container", "")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("source_publish_path", "")
dbutils.widgets.getArgument("source_publish_path")
source_publish_path= getArgument("source_publish_path")

dbutils.widgets.text("patientaccts_path", "")
dbutils.widgets.getArgument("patientaccts_path")
patientaccts_path= getArgument("patientaccts_path")

dbutils.widgets.text("dest_publish_path","")
dbutils.widgets.getArgument("dest_publish_path")
dest_publish_path= getArgument("dest_publish_path")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 



# COMMAND ----------

source_publish_path = baseurl+source_publish_path
patientaccts_path = baseurl+patientaccts_path
dest_publish_path = baseurl+dest_publish_path

# COMMAND ----------

track_df = spark.read.format("delta").load(source_publish_path)

# COMMAND ----------

patient_df = spark.read.format("delta").load(patientaccts_path)

# COMMAND ----------

joined_df = track_df.join(patient_df, track_df.patientacctipk == patient_df.patientacctipk, "inner").select(track_df.patientacctipk, patient_df.hospitalfk, track_df.demographicsupdatedate)

# COMMAND ----------

joined_df.count()

# COMMAND ----------

joined_df.write.format("delta").mode("overwrite").save(dest_publish_path)
