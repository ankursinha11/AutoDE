# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window
from pyspark.sql.functions import row_number

# COMMAND ----------

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("hfc_xref_input","")
dbutils.widgets.getArgument("hfc_xref_input")
hfc_xref_input= getArgument("hfc_xref_input")

dbutils.widgets.text("hfc_xref_output","")
dbutils.widgets.getArgument("hfc_xref_output")
hfc_xref_output= getArgument("hfc_xref_output")

dbutils.widgets.text("hfc_publish_path","")
dbutils.widgets.getArgument("hfc_publish_path")
hfc_publish_path= getArgument("hfc_publish_path")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user
print(baseurl)

# COMMAND ----------

hfc_xref_input = baseurl+hfc_xref_input
hfc_xref_output = baseurl+hfc_xref_output
hfc_publish_path = baseurl+hfc_publish_path

print(f'hfc_xref_input: {hfc_xref_input}')
print(f'hfc_xref_output: {hfc_xref_output}')
print(f'hfc_publish_path: {hfc_publish_path}')

# COMMAND ----------

hfc_publish_df = spark.read.format("delta").load(hfc_publish_path)

# COMMAND ----------

hfc_xref_df = spark.read.format('delta').load(hfc_xref_input)
print("input count:"+ str(hfc_xref_df.count()))

# COMMAND ----------

xref_hfc_joined_df = hfc_xref_df.join(hfc_publish_df, hfc_xref_df["transactionkey"] == hfc_publish_df["helperfoundcoverageipk"], "inner") \
               .select(hfc_xref_df["*"], hfc_publish_df["hospitalfk"].alias("hospitalfk"))
print("joined count:"+ str(xref_hfc_joined_df.count()))

# COMMAND ----------

1181519072-1005351020 #176168052 records are dropped

# COMMAND ----------

xref_hfc_joined_df = xref_hfc_joined_df.withColumn(
        "_id1",
        concat_ws("_", xref_hfc_joined_df.gmrnid, xref_hfc_joined_df.transactionkey,xref_hfc_joined_df.hospitalfk,xref_hfc_joined_df.sourcekey),
    )

# COMMAND ----------

window_spec = Window.partitionBy(
    xref_hfc_joined_df.gmrnid,
    xref_hfc_joined_df.transactionkey,
    xref_hfc_joined_df.hospitalfk,
    xref_hfc_joined_df.sourcekey
).orderBy(col("lr_createdate").cast("timestamp").desc())

xref_hfc_joined_df = xref_hfc_joined_df.withColumn("row_num", row_number().over(window_spec))
xref_hfc_joined_df = xref_hfc_joined_df.filter(col("row_num") == 1).drop("row_num")

# COMMAND ----------

xref_hfc_joined_df = xref_hfc_joined_df.drop("_id")
xref_hfc_joined_df=xref_hfc_joined_df.withColumnRenamed("_id1","_id")

# COMMAND ----------

cols = [
    "transactionkey", "sourcekey", "lr_creatingmodule", "lr_createdate", "gmrnid", 
    "xrefsource", "audittrail", "_id","hospitalfk"
]

xref_hfc_joined_df = xref_hfc_joined_df.select([col(c) for c in cols])

# COMMAND ----------

xref_hfc_joined_df.write.format("delta").mode("overwrite").save(hfc_xref_output)

# COMMAND ----------


