# Databricks notebook source
# ich_xref_input = '/data/leadrepo/publish/cooked/lr_xref_gmrnid_transaction_old2/' #(rename the existing one to old2 before migration)
# ich_xref_output = '/data/leadrepo/publish/cooked/lr_xref_gmrnid_transaction/'
# lr_transaction_path = '/data/leadrepo/publish/cooked/lr_transaction/'
# storageaccount = 'prodicddls'
# container = 'prod-icd-adls'
# user = 'na'

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("ich_xref_input","")
dbutils.widgets.getArgument("ich_xref_input")
ich_xref_input= getArgument("ich_xref_input")

dbutils.widgets.text("ich_xref_output","")
dbutils.widgets.getArgument("ich_xref_output")
ich_xref_output= getArgument("ich_xref_output")

dbutils.widgets.text("lr_transaction_path","")
dbutils.widgets.getArgument("lr_transaction_path")
lr_transaction_path= getArgument("lr_transaction_path")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user
print(baseurl)

# COMMAND ----------

ich_xref_input = baseurl+ich_xref_input
ich_xref_output = baseurl+ich_xref_output
lr_transaction_path = baseurl+lr_transaction_path

print(f'ich_xref_input: {ich_xref_input}')
print(f'ich_xref_output: {ich_xref_output}')
print(f'lr_transaction_path: {lr_transaction_path}')

# COMMAND ----------

lr_transaction_df = spark.read.parquet(lr_transaction_path).filter(col("sourcekey") == "2")

# COMMAND ----------

existing_xref_df = spark.read.format('delta').load(ich_xref_input)
fc_xref_df = existing_xref_df.filter(col('sourcekey') == "1")
ich_xref_df = existing_xref_df.filter(col('sourcekey') == "2").drop('hospitalfk')

# COMMAND ----------

xref_lr_joined_df = ich_xref_df.join(lr_transaction_df, ich_xref_df["transactionkey"] == lr_transaction_df["transactionkey"], "inner") \
               .select(ich_xref_df["*"], lr_transaction_df["clientid"])

xref_lr_joined_df = xref_lr_joined_df.withColumnRenamed("clientid", "hospitalfk")

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import row_number

window_spec = Window.partitionBy(
    xref_lr_joined_df.gmrnid,
    xref_lr_joined_df.transactionkey,
    xref_lr_joined_df.hospitalfk,
    xref_lr_joined_df.sourcekey
).orderBy(col("lr_createdate").cast("timestamp").desc())

xref_lr_joined_df = xref_lr_joined_df.withColumn("row_num", row_number().over(window_spec))
xref_lr_joined_df = xref_lr_joined_df.filter(col("row_num") == 1)

# COMMAND ----------

xref_lr_joined_df = xref_lr_joined_df.withColumn(
        "_id1",
        concat_ws("_", xref_lr_joined_df.gmrnid, xref_lr_joined_df.transactionkey,xref_lr_joined_df.hospitalfk,xref_lr_joined_df.sourcekey),
    )

# COMMAND ----------

xref_lr_joined_df = xref_lr_joined_df.drop("_id")
xref_lr_joined_df = xref_lr_joined_df.withColumnRenamed("_id1", "_id")

# COMMAND ----------

cols = [
    "audittrail", "lr_createdate", "lr_creatingmodule", "sourcekey",
    "transactionkey", "xrefsource", "gmrnid", "hospitalfk", "_id"
]

new_cols = cols[:-2] + ["_id", "hospitalfk"]

xref_lr_joined_df = xref_lr_joined_df.select([col(c) for c in new_cols])

# COMMAND ----------

migrated_xref_df = xref_lr_joined_df.union(fc_xref_df)

# COMMAND ----------

migrated_xref_df.write.format("delta").mode("overwrite").save(ich_xref_output)
