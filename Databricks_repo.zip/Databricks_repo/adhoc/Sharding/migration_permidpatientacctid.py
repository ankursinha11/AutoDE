# Databricks notebook source
#use below parameters

#container = "prod-icd-adls" or "prod-icd-stg-adls"
#storage account = "prodicddls" or "prodicdstgdls"
#hdfs_permid_publish = "/data/cdd/publish/permidpatientacctid_old/" (rename the existing one to permidpatientacctid_old before running it)
#publish_output = "/data/cdd/publish/permidpatientacctid/"
#pa_publish_path = "/data/dataingestion/publish/patientaccts/current/20991231/"
#user = "na" or "<youruser>"

# COMMAND ----------

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("hdfs_permid_publish","")
dbutils.widgets.getArgument("hdfs_permid_publish")
hdfs_permid_publish= getArgument("hdfs_permid_publish")

dbutils.widgets.text("publish_output","")
dbutils.widgets.getArgument("publish_output")
publish_output= getArgument("publish_output")

dbutils.widgets.text("pa_publish_path","")
dbutils.widgets.getArgument("pa_publish_path")
dataingestion_publish_path= getArgument("pa_publish_path")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

# COMMAND ----------

from pyspark.sql.functions import col
import os

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user
print(baseurl)

# COMMAND ----------

hdfs_permid_publish = baseurl + hdfs_permid_publish
publish_output = baseurl + publish_output
pa_publish_path = baseurl + dataingestion_publish_path

print(f'hdfs_permid_publish : {hdfs_permid_publish}')
print(f'publish_output: {publish_output}')
print(f'pa_publish_path : {pa_publish_path}')

# COMMAND ----------

patientacct_df = spark.read.format("delta").load(pa_publish_path)

# COMMAND ----------

existing_bc_paths = [f.path for f in dbutils.fs.ls(hdfs_permid_publish) if f.isDir()]

# COMMAND ----------

for bc_path in existing_bc_paths:
    df = spark.read.parquet(bc_path)
    df_with_hospitalfk = df.join(patientacct_df, df["patientacctifk"] == patientacct_df["patientacctipk"], "inner") \
               .select(df["*"], patientacct_df["hospitalfk"])
    bc = bc_path.replace(hdfs_permid_publish, "")
    target_path = os.path.join(publish_output, bc)
    print(f"Writing to: {target_path}")
    df_with_hospitalfk.write.mode("overwrite").parquet(target_path)   
