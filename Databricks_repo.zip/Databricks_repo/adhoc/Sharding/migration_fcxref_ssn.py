# Databricks notebook source
# fc_xref_input = '/data/leadrepo/publish/cooked/lr_xref_ssn_mrn_cluster_transaction_old/' (rename the existing one to _old before migration)
# fc_xref_output = '/data/leadrepo/publish/cooked/lr_xref_ssn_mrn_cluster_transaction/'
# storageaccount = 'prodicddls'
# container = 'prod-icd-adls'
# user = 'na'

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("fc_xref_input","")
dbutils.widgets.getArgument("fc_xref_input")
fc_xref_input= getArgument("fc_xref_input")

dbutils.widgets.text("fc_xref_output","")
dbutils.widgets.getArgument("fc_xref_output")
fc_xref_output= getArgument("fc_xref_output")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user
print(baseurl)

# COMMAND ----------

fc_xref_input = baseurl+fc_xref_input
fc_xref_output = baseurl+fc_xref_output

print(f'fc_xref_input: {fc_xref_input}')
print(f'fc_xref_output: {fc_xref_output}')

# COMMAND ----------

existing_xref_df = spark.read.format('delta').load(fc_xref_input)

# COMMAND ----------

migrated_xref_df = existing_xref_df.withColumn("_id1", concat_ws("_", existing_xref_df.transactionkey,existing_xref_df.hospitalfk,existing_xref_df.sourcekey))

# COMMAND ----------

migrated_xref_df = migrated_xref_df.drop("_id")
migrated_xref_df = migrated_xref_df.withColumnRenamed("_id1", "_id")

# COMMAND ----------

new_col_order = ['_id'] + [col for col in migrated_xref_df.columns if col != '_id']
migrated_xref_df = migrated_xref_df.select(new_col_order)

# COMMAND ----------

migrated_xref_df.write.format("delta").mode("overwrite").save(fc_xref_output)
