# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("mh_xref_input","")
dbutils.widgets.getArgument("mh_xref_input")
mh_xref_input= getArgument("mh_xref_input")

dbutils.widgets.text("mh_xref_output","")
dbutils.widgets.getArgument("mh_xref_output")
mh_xref_output= getArgument("mh_xref_output")

dbutils.widgets.text("mh_publish_path","")
dbutils.widgets.getArgument("mh_publish_path")
mh_publish_path= getArgument("mh_publish_path")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user
print(baseurl)

# COMMAND ----------

mh_xref_input = baseurl+mh_xref_input
mh_xref_output = baseurl+mh_xref_output
mh_publish_path = baseurl+mh_publish_path

print(f'mh_xref_input: {mh_xref_input}')
print(f'mh_xref_output: {mh_xref_output}')
print(f'mh_publish_path: {mh_publish_path}')


# COMMAND ----------

mh_publish_df = spark.read.format("delta").load(mh_publish_path)

# COMMAND ----------

mh_xref_df = spark.read.format('delta').load(mh_xref_input)

# COMMAND ----------

xref_mh_joined_df = mh_xref_df.join(mh_publish_df, mh_xref_df["transactionkey"] == mh_publish_df["MedicareCoverageIPK"], "inner") \
               .select(mh_xref_df["*"], mh_publish_df["HospitalFK"].alias("hospitalfk"))

# COMMAND ----------

xref_mh_joined_df.count() 

# COMMAND ----------

xref_mh_joined_df = xref_mh_joined_df.withColumn(
        "_id1",
        concat_ws("_", xref_mh_joined_df.transactionkey,xref_mh_joined_df.hospitalfk,xref_mh_joined_df.sourcekey),
    )

# COMMAND ----------

xref_mh_joined_df = xref_mh_joined_df.drop("_id")
xref_mh_joined_df=xref_mh_joined_df.withColumnRenamed("_id1","_id")

# COMMAND ----------

cols = [
    "transactionkey", "sourcekey", "lr_creatingmodule", "lr_createdate", "ssn", 
    "clusteredacctfk", "medicalrecnum","xrefsource", "audittrail", "_id","hospitalfk"
]

xref_mh_joined_df = xref_mh_joined_df.select([col(c) for c in cols])

# COMMAND ----------

xref_mh_joined_df.write.format("delta").mode("overwrite").save(mh_xref_output)

# COMMAND ----------


