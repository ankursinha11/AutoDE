# Databricks notebook source
# famc_xref_input = '/data/leadrepo/publish/cooked/famc_lr_xref_permid_transaction_old/' #(rename existing one to _old before migration)
# famc_xref_output = '/data/leadrepo/publish/cooked/famc_lr_xref_permid_transaction/'
# lr_transaction_input = '/data/leadrepo/publish/cooked/lr_transaction/'
# storageaccount = 'prodicddls'
# container = 'prod-icd-adls'
# user = 'na'

# COMMAND ----------

# Databricks notebook source
famc_xref_input = '/data/leadrepo/publish/cooked/famc_lr_xref_permid_transaction/' #(rename existing one to _old before migration)
famc_xref_output = '/data/leadrepo/publish/cooked/famc_lr_xref_permid_transaction_migrated/'
lr_transaction_input = '/data/leadrepo/publish/cooked/lr_transaction/'
storageaccount = 'prodicdstgdls'
container = 'prod-icd-stg-adls'
user = 'suhas'

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("famc_xref_input","")
dbutils.widgets.getArgument("famc_xref_input")
famc_xref_input= getArgument("famc_xref_input")

dbutils.widgets.text("famc_xref_output","")
dbutils.widgets.getArgument("famc_xref_output")
famc_xref_output= getArgument("famc_xref_output")

dbutils.widgets.text("lr_transaction_input","")
dbutils.widgets.getArgument("lr_transaction_input")
lr_transaction_input= getArgument("lr_transaction_input")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user
print(baseurl)

# COMMAND ----------

famc_xref_input = baseurl+famc_xref_input
famc_xref_output = baseurl+famc_xref_output
lr_transaction_input = baseurl+lr_transaction_input

print(f"famc_xref_input: {famc_xref_input}")
print(f"famc_xref_output: {famc_xref_output}")
print(f"lr_transaction_input : {lr_transaction_input}")

# COMMAND ----------

lr_transaction_df = spark.read.parquet(lr_transaction_input).filter(col("sourcekey") == "2")

# COMMAND ----------

existing_famc_xref_df = spark.read.format('delta').load(famc_xref_input)
famc_fc_xref_df = existing_famc_xref_df.filter(col('sourcekey') == "1")
famc_ich_xref_df = existing_famc_xref_df.filter(col('sourcekey') == "2").drop('hospitalfk')

# COMMAND ----------

famc_ich_xref_hospital_df = famc_ich_xref_df.join(lr_transaction_df, famc_ich_xref_df["transactionkey"] == lr_transaction_df["transactionkey"], "inner") \
               .select(famc_ich_xref_df["*"], lr_transaction_df["clientid"])

famc_ich_xref_hospital_df = famc_ich_xref_hospital_df.withColumnRenamed("clientid", "hospitalfk")

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import row_number

window_spec = Window.partitionBy(
    xref_lr_joined_df.permid,
    xref_lr_joined_df.transactionkey,
    xref_lr_joined_df.hospitalfk,
    xref_lr_joined_df.sourcekey
).orderBy(col("lr_createdate").cast("timestamp").desc())

famc_ich_xref_hospital_df = famc_ich_xref_hospital_df.withColumn("row_num", row_number().over(window_spec))
famc_ich_xref_hospital_df = famc_ich_xref_hospital_df.filter(col("row_num") == 1)

# COMMAND ----------

famc_ich_xref_hospital_df = famc_ich_xref_hospital_df.withColumn(
        "_id1",
        concat_ws("_", famc_ich_xref_hospital_df.permid, famc_ich_xref_hospital_df.transactionkey,famc_ich_xref_hospital_df.hospitalfk,famc_ich_xref_hospital_df.sourcekey),
    )

# COMMAND ----------

famc_ich_xref_hospital_df = famc_ich_xref_hospital_df.drop("_id")
famc_ich_xref_hospital_df = famc_ich_xref_hospital_df.withColumnRenamed("_id1", "_id")

# COMMAND ----------

new_order = [ "transactionkey", "sourcekey", "permid", "lr_createdate", "lr_creatingmodule", "_id", "xrefsource", "audittrail", "hospitalfk" ]

# COMMAND ----------

famc_ich_xref_hospital_df = famc_ich_xref_hospital_df[new_order]

# COMMAND ----------

migrated_famc_ich_xref_df = famc_ich_xref_hospital_df.union(famc_fc_xref_df)

# COMMAND ----------

migrated_famc_ich_xref_df.write.format("delta").mode("overwrite").save(famc_xref_output)
