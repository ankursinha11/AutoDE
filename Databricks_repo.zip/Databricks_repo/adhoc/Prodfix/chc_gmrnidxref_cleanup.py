# Databricks notebook source
storageaccount = 'prodicddls'
container = 'prod-icd-adls'
user = 'na' 

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

baseurl

# COMMAND ----------

chc_xref = spark.read.format("delta").load(baseurl+"/satya/data/leadrepo/publish/cooked/chc_lr_xref_gmrnid_transaction/")
# print(chc_xref.count())
# print(chc_xref.dropDuplicates().count())

# COMMAND ----------

from pyspark.sql.window import Window
import pyspark.sql.functions as F

cols = [c for c in chc_xref.columns if c != 'gmrnmatchind']
w = Window.partitionBy(*cols).orderBy(F.col('gmrnmatchind').asc(), F.col('gmrnid').cast('long').asc())
chc_xref = chc_xref.withColumn("rn", F.row_number().over(w)).filter("rn = 1").drop("rn")
chc_xref.write.mode("overwrite").format("delta").save(baseurl+"/satya/data/leadrepo/publish/cooked/chc_lr_xref_gmrnid_transaction_0918")
