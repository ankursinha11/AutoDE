# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window


# COMMAND ----------

dbutils.widgets.text("user", "")
dbutils.widgets.getArgument("user")
user = getArgument("user")

dbutils.widgets.text("container", "")
dbutils.widgets.getArgument("container")
container = getArgument("container")

dbutils.widgets.text("storageaccount", "")
dbutils.widgets.getArgument("storageaccount")
storageaccount = getArgument("storageaccount")

dbutils.widgets.text("source_path", "")
dbutils.widgets.getArgument("source_path")
source_path = getArgument("source_path")

dbutils.widgets.text("target_path", "")
dbutils.widgets.getArgument("target_path")
target_path = getArgument("target_path")

# COMMAND ----------

spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

source_path = baseurl+source_path
target_path = baseurl+target_path
print(source_path)
print(target_path)

# COMMAND ----------

patx = spark.read.format("delta").load(source_path)
patx_fil = patx.filter("breadcrumb='-IX' or breadcrumb='-FC' or breadcrumb like '%JAN%' or breadcrumb like '%OCT%' or breadcrumb='null'  or breadcrumb is null or trim(breadcrumb) = '' ")
patx_tot = patx.subtract(patx_fil)
patx_fil = patx_fil.withColumn("createdate", date_format(to_timestamp(to_timestamp(lit("2020-01-01"), "yyyy-MM-dd")), "yyyy-MM-dd HH:mm:ss"))   
patx_tot = patx_tot.withColumn("createdate", date_format(to_timestamp(col("breadcrumb").substr(1,8),"yyyyMMdd"), "yyyy-MM-dd HH:mm:ss"))
patx_up = patx_fil.union(patx_tot)

# COMMAND ----------

patx_up.write.mode("overwrite").format("delta").save(target_path)
