# Databricks notebook source
# MAGIC %md
# MAGIC # #RUN hipaa_issue_fc_bcbs_leads_cleanup_impact_final to Read hit impact leads 

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window


# COMMAND ----------

dbutils.widgets.text("user", "")
dbutils.widgets.getArgument("user")
user = getArgument("user")

dbutils.widgets.text("container", "")
dbutils.widgets.getArgument("container")
container = getArgument("container")

dbutils.widgets.text("storageaccount", "")
dbutils.widgets.getArgument("storageaccount")
storageaccount = getArgument("storageaccount")



# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

print(baseurl)


# COMMAND ----------

# DBTITLE 1,NBCBS Invalid-valid lrlr_xref counts
df_g = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lr_lr_xref_valid_invalid_filtered_nbcbs_g/")
df_g.createOrReplaceTempView('df_g')
print("lr_invalid_filtered_g count:", df_g.count())
df_p = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lr_lr_xref_valid_invalid_filtered_nbcbs_p/")
df_p.createOrReplaceTempView('df_p')
print("lr_invalid_filtered_p count:", df_p.count())
df_s = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lr_lr_xref_valid_invalid_filtered_nbcbs_s/")
df_s.createOrReplaceTempView('df_s')
print("lr_invalid_filtered_s count:", df_s.count())
df_m = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lr_lr_xref_valid_invalid_filtered_nbcbs_m/")
df_m.createOrReplaceTempView('df_m')
print("lr_invalid_filtered_m count:", df_m.count())
df_c = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lr_lr_xref_valid_invalid_filtered_nbcbs_c/")
df_c.createOrReplaceTempView('df_c')
print("lr_invalid_filtered_c count:", df_c.count())


# COMMAND ----------

# DBTITLE 1,Remove Hit impact leads
hit_ids = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lsb_coverageid_policyid_match_nbcbs/").dropDuplicates()

# Filter hit_ids for each id type
hit_ids_g = hit_ids.filter(col("lsb_id_type") == "G")
hit_ids_p = hit_ids.filter(col("lsb_id_type") == "P")
hit_ids_s = hit_ids.filter(col("lsb_id_type") == "S")
hit_ids_m = hit_ids.filter(col("lsb_id_type") == "MH")
hit_ids_c = hit_ids.filter(col("lsb_id_type") == "CH")

df_g_filtered = df_g.join(
    hit_ids_g, 
    (df_g.gmrnid == hit_ids_g.lsb_identity) & 
    (df_g.payerid == hit_ids_g.lsb_edipartner) & 
    (df_g.coverageid == hit_ids_g.lsb_coverageid), 
    "left_anti"
)
df_p_filtered = df_p.join(
    hit_ids_p, 
    (df_p.permid == hit_ids_p.lsb_identity) & 
    (df_p.payerid == hit_ids_p.lsb_edipartner) & 
    (df_p.coverageid == hit_ids_p.lsb_coverageid), 
    "left_anti"
)
df_s_filtered = df_s.join(
    hit_ids_s, 
    (df_s.ssn == hit_ids_s.lsb_identity) & 
    (df_s.payerid == hit_ids_s.lsb_edipartner) & 
    (df_s.coverageid == hit_ids_s.lsb_coverageid), 
    "left_anti"
)
df_m_filtered = df_m.join(
    hit_ids_m, 
    (df_m.medicalrecnum == hit_ids_m.lsb_identity) & 
    (df_m.payerid == hit_ids_m.lsb_edipartner) & 
    (df_m.coverageid == hit_ids_m.lsb_coverageid), 
    "left_anti"
)
df_c_filtered = df_c.join(
    hit_ids_c, 
    (df_c.clusteredacctfk == hit_ids_c.lsb_identity) & 
    (df_c.payerid == hit_ids_c.lsb_edipartner) & 
    (df_c.coverageid == hit_ids_c.lsb_coverageid), 
    "left_anti"
)

df_g_filtered.createOrReplaceTempView('df_g_filtered')
df_p_filtered.createOrReplaceTempView('df_p_filtered')
df_s_filtered.createOrReplaceTempView('df_s_filtered')
df_m_filtered.createOrReplaceTempView('df_m_filtered')
df_c_filtered.createOrReplaceTempView('df_c_filtered')

print("df_g_filtered count:", df_g_filtered.count())
print("df_p_filtered count:", df_p_filtered.count())
print("df_s_filtered count:", df_s_filtered.count())
print("df_m_filtered count:", df_m_filtered.count())
print("df_c_filtered count:", df_c_filtered.count())

# COMMAND ----------

# DBTITLE 1,Rewrite lr_xref
lr_xref_g_all = spark.read.format('delta').load(baseurl + "/data/leadrepo/publish/cooked/lr_xref_gmrnid_transaction/")
lr_xref_p_all = spark.read.format('delta').load(baseurl + "/data/leadrepo/publish/cooked/lr_xref_permid_transaction/")
lr_xref_smc_all = spark.read.format('delta').load(baseurl + "/data/leadrepo/publish/cooked/lr_xref_ssn_mrn_cluster_transaction/")

lr_xref_g_1 = lr_xref_g_all.filter("sourcekey = 1")
lr_xref_p_1 = lr_xref_p_all.filter("sourcekey = 1")
lr_xref_smc_1 = lr_xref_smc_all.filter("sourcekey = 1")

lr_xref_g_2 = lr_xref_g_all.filter("sourcekey != 1")
lr_xref_p_2 = lr_xref_p_all.filter("sourcekey != 1")

lr_xref_g_new = lr_xref_g_all.join(df_g_filtered.select("gmrnid", "transactionkey", "sourcekey"), on=["gmrnid", "transactionkey", "sourcekey"], how="left_anti")
lr_xref_p_new = lr_xref_p_all.join(df_p_filtered.select("permid", "transactionkey", "sourcekey"), on=["permid", "transactionkey", "sourcekey"], how="left_anti")
lr_xref_smc_new = lr_xref_smc_all.join(df_s_filtered.select("ssn", "transactionkey", "sourcekey"), on=["ssn", "transactionkey", "sourcekey"], how="left_anti") \
    .join(df_m_filtered.select("medicalrecnum", "transactionkey", "sourcekey"), on=["medicalrecnum", "transactionkey", "sourcekey"], how="left_anti") \
    .join(df_c_filtered.select("clusteredacctfk", "transactionkey", "sourcekey"), on=["clusteredacctfk", "transactionkey", "sourcekey"], how="left_anti")

# Order columns as source
lr_xref_g_new = lr_xref_g_new.select(lr_xref_g_all.columns)
lr_xref_p_new = lr_xref_p_new.select(lr_xref_p_all.columns)
lr_xref_smc_new = lr_xref_smc_new.select(lr_xref_smc_all.columns)

print("lr_xref_g_all fc count:" + str(lr_xref_g_all.count()))
print("lr_xref_p_all fc count:" + str(lr_xref_p_all.count()))
print("lr_xref_smc_all fc count:" + str(lr_xref_smc_all.count()))

print("lr_xref_g_1 fc count:" + str(lr_xref_g_1.count()))
print("lr_xref_p_1 fc count:" + str(lr_xref_p_1.count()))
print("lr_xref_smc_1 fc count:" + str(lr_xref_smc_1.count()))

print("lr_xref_g_2 non fc count:" + str(lr_xref_g_2.count()))
print("lr_xref_p_2 non fc count:" + str(lr_xref_p_2.count()))

print("lr_xref_g_new fc count:" + str(lr_xref_g_new.count()))
print("lr_xref_p_new fc count:" + str(lr_xref_p_new.count()))
print("lr_xref_smc_new fc count:" + str(lr_xref_smc_new.count()))

lr_xref_g_new.write.mode("overwrite").format("delta").save(baseurl + "/abdul/data/leadrepo/publish/cooked/lr_xref_gmrnid_transaction_nbcbs_new/")
lr_xref_p_new.write.mode("overwrite").format("delta").save(baseurl + "/abdul/data/leadrepo/publish/cooked/lr_xref_permid_transaction_nbcbs_new/")
lr_xref_smc_new.write.mode("overwrite").format("delta").save(baseurl + "/abdul/data/leadrepo/publish/cooked/lr_xref_ssn_mrn_cluster_transaction_nbcbs_new/")

# COMMAND ----------

# DBTITLE 1,Read LSB
lsb = spark.read.format("delta").load(baseurl + "/data/leadservicebase/publish/served/leadservicebase/")

lsb_fc = lsb.filter(col("hcsystemfk_source").contains('_fc'))#3,136,461,976
lsb_fc_bcbs = lsb_fc.filter(split(col('leadid'), '_')[0] == '101')#567,158,050
lsb_fc_nbcbs = lsb_fc.filter(split(col('leadid'), '_')[0] != '101')

lsb_fc_nbcbs_ex = lsb_fc_nbcbs.select("*",explode_outer("demographics")).drop("demographics").drop("hcsystemfk_source")
lsb_fc_nbcbs_ex_1 = lsb_fc_nbcbs_ex.withColumnRenamed("key", "hcsystemfk_source")
lsb_fc_nbcbs_ex_1 = lsb_fc_nbcbs_ex_1.filter(split(col("hcsystemfk_source"), '_')[1] =='fc')

lsb_fc_nbcbs_ex_1 = lsb_fc_nbcbs_ex_1.withColumn("lsb_hospitalfk", col("value").hospitalfk)
lsb_hospital_split_df = lsb_fc_nbcbs_ex_1.withColumn("lsb_hospitalfk", split("lsb_hospitalfk", "\\|"))
lsb_hospital_ex_df = lsb_hospital_split_df.withColumn("lsb_hospitalfk", explode("lsb_hospitalfk"))

lsb_g =lsb_hospital_ex_df.filter(col("_id").startswith('G'))
lsb_g.createOrReplaceTempView("lsb_g")
lsb_p =lsb_hospital_ex_df.filter(col("_id").startswith('P'))
lsb_p.createOrReplaceTempView("lsb_p")
lsb_s =lsb_hospital_ex_df.filter(col("_id").startswith('S'))
lsb_s.createOrReplaceTempView("lsb_s")
lsb_m =lsb_hospital_ex_df.filter(col("_id").startswith('MH'))
lsb_m.createOrReplaceTempView("lsb_m")
lsb_c =lsb_hospital_ex_df.filter(col("_id").startswith('CH'))
lsb_c.createOrReplaceTempView("lsb_c")

print("LSB Total count:" + str(lsb.count()))
print("LSB FC count:" + str(lsb_fc.count()))
print("LSB FC BCBS count:" + str(lsb_fc_bcbs.count()))
print("LSB FC NON BCBS count:" + str(lsb_fc_nbcbs.count()))
print("LSB FC NON BCBS hosp explode count:" + str(lsb_hospital_ex_df.count()))

print("LSB FC gmrnid count:" + str(lsb_g.count()))
print("LSB FC permid count:" + str(lsb_p.count()))
print("LSB FC ssn count:" + str(lsb_s.count()))
print("LSB FC mrn count:" + str(lsb_m.count()))
print("LSB FC clusteredacct count:" + str(lsb_c.count()))


# COMMAND ----------

# DBTITLE 1,LSB prior uniq lead count
from pyspark.sql.functions import col

leadid_g = lsb_g.select("leadid")
leadid_p = lsb_p.select("leadid")
leadid_s = lsb_s.select("leadid")
leadid_m = lsb_m.select("leadid")
leadid_c = lsb_c.select("leadid")

all_leadids = leadid_g.unionByName(leadid_p).unionByName(leadid_s).unionByName(leadid_m).unionByName(leadid_c).dropDuplicates()
print(all_leadids.count())

# COMMAND ----------

# DBTITLE 1,JOIN LR LR_XREF LSB
#gmrn_xref
p1=spark.sql("""select g.*
             from lsb_g g
             LEFT ANTI JOIN df_g_filtered dg ON g.identity = concat('G_',dg.gmrnid) and g.leadid = concat(dg.payerid,'_',dg.coverageid) and g.lsb_hospitalfk = dg.clientid
             """)
p1.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/hipaa_issue/lsb_nbcbs_gmrn_xref_invalid_filtered2/")

# #permid_xref
p2 = spark.sql("""select p.*
             from lsb_p p
             LEFT ANTI JOIN df_p_filtered dp ON p.identity = concat('P_',dp.permid) and p.leadid = concat(dp.payerid,'_',dp.coverageid) and p.lsb_hospitalfk = dp.clientid
             """)
p2.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/hipaa_issue/lsb_nbcbs_perm_xref_invalid_filtered2/")

# ssn_xref
p3 = spark.sql("""select s.*
             from lsb_s s
             LEFT ANTI JOIN df_s_filtered ds ON s.identity = concat('S_',ds.ssn) and s.leadid = concat(ds.payerid,'_',ds.coverageid) and s.lsb_hospitalfk = ds.clientid
             """)
p3.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/hipaa_issue/lsb_nbcbs_ssn_xref_invalid_filtered2/")

# #_mrn_xref
p4 = spark.sql("""select m.*
             from lsb_m m
             LEFT ANTI JOIN df_m_filtered dm ON m.identity = concat('MH_',dm.clientid,'_',dm.medicalrecnum) and m.leadid = concat(dm.payerid,'_',dm.coverageid) and m.lsb_hospitalfk = dm.clientid
             """)
p4.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/hipaa_issue/lsb_nbcbs_mrn_xref_invalid_filtered2/")

p5 = spark.sql("""select c.*
             from lsb_c c
             LEFT ANTI JOIN df_c_filtered dc ON c.identity = concat('CH_',dc.clientid,'_',dc.clusteredacctfk) and c.leadid = concat(dc.payerid,'_',dc.coverageid) and c.lsb_hospitalfk = dc.clientid
             """)
p5.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/hipaa_issue/lsb_nbcbs_cls_xref_invalid_filtered2/")

# COMMAND ----------

# DBTITLE 1,valid NBCBS LSB data
lb1 = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lsb_nbcbs_gmrn_xref_invalid_filtered2/").dropDuplicates()
lb1.createOrReplaceTempView('lb1')
print("lb1 count:", lb1.count())

lb2 = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lsb_nbcbs_perm_xref_invalid_filtered2/").dropDuplicates()
lb2.createOrReplaceTempView('lb2')
print("lb2 count:", lb2.count())

lb3 = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lsb_nbcbs_ssn_xref_invalid_filtered2/").dropDuplicates()
lb3.createOrReplaceTempView('lb3')
print("lb3 count:", lb3.count())

lb4 = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lsb_nbcbs_mrn_xref_invalid_filtered2/").dropDuplicates()
lb4.createOrReplaceTempView('lb4')
print("lb4 count:", lb4.count())

lb5 = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lsb_nbcbs_cls_xref_invalid_filtered2/").dropDuplicates()
lb5.createOrReplaceTempView('lb5')
print("lb5 count:", lb5.count())

# COMMAND ----------

# DBTITLE 1,lead uniq count to keep
from pyspark.sql.functions import col

leadqq_g = lb1.select("leadid")
leadqq_p = lb2.select("leadid")
leadqq_s = lb3.select("leadid")
leadqq_m = lb4.select("leadid")
leadqq_c = lb5.select("leadid")

all_leadqqs = leadqq_g.unionByName(leadqq_p).unionByName(leadqq_s).unionByName(leadqq_m).unionByName(leadqq_c).dropDuplicates()
print(all_leadqqs.count())

# COMMAND ----------

# DBTITLE 1,all valid FC NBCBS leads & update hospitalfk
from pyspark.sql.window import Window
from pyspark.sql.functions import concat_ws, collect_list, row_number

#Read all NBCBS FC valid data
all_id_valid_leads = spark.read.parquet(baseurl + "/abdul/hipaa_issue/*_xref_invalid_filtered2/").dropDuplicates()#.count()#175,522,919 223,429,7872

window_spec = Window.partitionBy("_id", "hcsystemfk_source").orderBy("lsbupdatedate")
all_id_valid_leads = all_id_valid_leads.withColumn("hospitalfk_conc", concat_ws("|", collect_list("lsb_hospitalfk").over(window_spec))).drop("lsb_hospitalfk")
all_id_valid_leads = all_id_valid_leads.withColumn("rn", row_number().over(window_spec)).filter("rn = 1").drop("rn")

all_id_valid_leads_updated = all_id_valid_leads.withColumn("value", col("value").withField("hospitalfk", col("hospitalfk_conc"))).drop("hospitalfk_conc")

all_id_valid_leads_updated.count()

# COMMAND ----------

#  LOGIC TO ROLLUP AND LOAD TO LSB

# COMMAND ----------

# DBTITLE 1,Read Leadservicebase
lsb = spark.read.format("delta").load(baseurl + "/data/leadservicebase/publish/served/leadservicebase/")

lsb_fc = lsb.filter(col("hcsystemfk_source").contains('_fc'))#3,136,461,976
lsb_nfc = lsb.filter(~col("hcsystemfk_source").contains('_fc'))

lsb_fc_bcbs = lsb_fc.filter(split(col('leadid'), '_')[0] == '101')#567,158,050
lsb_fc_nbcbs = lsb_fc.filter(split(col('leadid'), '_')[0] != '101')
lsb_fc_nbcbs_ex = lsb_fc_nbcbs.select("*",explode_outer("demographics")).drop("demographics").drop("hcsystemfk_source")
lsb_fc_nbcbs_ex_1 = lsb_fc_nbcbs_ex.withColumnRenamed("key", "hcsystemfk_source")

lsb_fc_nbcbs_ex_nfc = lsb_fc_nbcbs_ex_1.filter(split(col("hcsystemfk_source"), '_')[1] !='fc')
lsb_fc_nbcbs_ex_fc = lsb_fc_nbcbs_ex_1.filter(split(col("hcsystemfk_source"), '_')[1] =='fc')

print("lsb count:", lsb.count())
print("lsb_fc count:", lsb_fc.count())
print("lsb_nfc count:", lsb_nfc.count())
print("lsb_fc_bcbs count:", lsb_fc_bcbs.count())
print("lsb_fc_nbcbs count:", lsb_fc_nbcbs.count())
print("lsb_fc_nbcbs_ex count:", lsb_fc_nbcbs_ex.count())
print("lsb_fc_nbcbs_ex_fc count:", lsb_fc_nbcbs_ex_fc.count())
print("lsb_fc_nbcbs_ex_nfc count:", lsb_fc_nbcbs_ex_nfc.count())


# COMMAND ----------

# DBTITLE 1,replace fresh exploded FC NBCBS leads
new_lsb_fc_nbcbs_ex = lsb_fc_nbcbs_ex_nfc.union(all_id_valid_leads_updated) 

print("new_lsb LSB FC NBCBS explode count: " + str(new_lsb_fc_nbcbs_ex.count()))

# COMMAND ----------

# DBTITLE 1,Remove duplicate demographics per _id+hcsystem_source
new_lsb_fc_nbcbs_ex.createOrReplaceTempView("new_lsb_fc_nbcbs_ex")
query_stmt = """ SELECT
                _id,
                sort_array(collect_list(hcsystemfk_source) over (PARTITION BY _id)) as hcsystemfk_source_concat,
                identity,
                min(leadcreatedate) over (PARTITION BY _id) as leadcreatedate,
                leadid,
                max(leadupdatedate) over (PARTITION BY _id) as leadupdatedate,
                min(lsbcreatedate) over (PARTITION BY _id) as lsbcreatedate,
                max(lsbupdatedate) over (PARTITION BY _id) as lsbupdatedate,
                sort_array(collect_list(struct(hcsystemfk_source, value)) over (PARTITION BY _id)) as demographics_list, 
                ROW_NUMBER() OVER (PARTITION BY _id ORDER BY leadupdatedate DESC) AS RNK
            FROM new_lsb_fc_nbcbs_ex
            """
new_lsb_fc_nbcbs = spark.sql(query_stmt).filter("RNK == 1").drop("RNK")

print("new_lsb LSB FC NBCBS count: " + str(new_lsb_fc_nbcbs.count()))


# COMMAND ----------

# DBTITLE 1,Transform to LSB format
new_lsb_fc_nbcbs1 = new_lsb_fc_nbcbs.withColumn('hcsystemfk_source', array_join('hcsystemfk_source_concat' , '|')).drop("hcsystemfk_source_concat")
new_lsb_fc_nbcbs2 = new_lsb_fc_nbcbs1.withColumn("demographics", map_from_entries("demographics_list")).drop("demographics_list")
new_lsb_fc_nbcbs2 = new_lsb_fc_nbcbs2.select('_id', 'hcsystemfk_source', 'identity', 'leadcreatedate', 'leadid', 'leadupdatedate', 'lsbcreatedate', 'lsbupdatedate', 'demographics')

new_lsb_fc = new_lsb_fc_nbcbs2.union(lsb_fc_bcbs)
new_lsb = new_lsb_fc.union(lsb_nfc)#2,930,152,454

print("new_lsb LSB FC count: " + str(new_lsb_fc.count()))
print("new_lsb LSB count: " + str(new_lsb.count()))

new_lsb.write.mode("overwrite").format("delta").save(baseurl + "/abdul/data/leadservicebase/staging/leadservicebase_new/")
