# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window


# COMMAND ----------

dbutils.widgets.text("user", "")
dbutils.widgets.getArgument("user")
user = getArgument("user")

dbutils.widgets.text("container", "")
dbutils.widgets.getArgument("container")
container = getArgument("container")

dbutils.widgets.text("storageaccount", "")
dbutils.widgets.getArgument("storageaccount")
storageaccount = getArgument("storageaccount")



# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

print(baseurl)


# COMMAND ----------

# DBTITLE 1,Read FAMC LR JOIN HFC FC
lr_cols = ['transactionkey','sourcepatientacctifk' ,'clientid', 'lr_createdate', 'verifiedsource', 'responsestatus','payerid','coverageid']
lr = spark.read.format("parquet").load(baseurl + "/data/leadrepo/publish/cooked/lr_transaction/").select(lr_cols)
lr.createOrReplaceTempView("lr")
lr_fc = lr.filter("sourcekey == '1'")

print("lr count:" + str(lr.count()))
print("lr fc count:" + str(lr_fc.count()))



# COMMAND ----------

lr_valid = lr_fc.where(
                    lr_fc.responsestatus.like('%EB:1%') | 
                    lr_fc.responsestatus.like('%EB:2%') | 
                    lr_fc.responsestatus.like('%EB:3%') | 
                    lr_fc.responsestatus.like('%EB:4%') | 
                    lr_fc.responsestatus.like('%EB:5%') |
                    lr_fc.responsestatus.like('%EB:6%') 
                    )
lr_valid = lr_valid.filter(~((col("payerid") == '101') & (lr_valid.responsestatus.like('%EB:6%'))))
lr_valid.createOrReplaceTempView('lr_valid')
lr_invalid = lr_fc.exceptAll(lr_valid)
lr_invalid.createOrReplaceTempView('lr_invalid')

famc_lr_xref_p = spark.read.format('delta').load(baseurl + "/data/leadrepo/publish/cooked/famc_lr_xref_permid_transaction/")
famc_lr_xref_p.createOrReplaceTempView('famc_lr_xref_p')

print("lr fc valid count:" + str(lr_valid.count()))
print("lr fc invalid count:" + str(lr_invalid.count()))
print("famc_lr_xref_p count:" + str(famc_lr_xref_p.count()))

# COMMAND ----------

# DBTITLE 1,Valid LR X LR_XREF
lr1 = spark.sql("""select r.*, lp.permid
             from famc_lr_xref_p lp
             JOIN lr_valid r ON r.transactionkey = lp.transactionkey
             """)
lr1.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/famc_hipaa_issue/famc_perm_lr_lrxref_valid_famc/")

# COMMAND ----------

# DBTITLE 1,valid lr lr_xref counts
lr_v1 = spark.read.parquet(baseurl + "/abdul/famc_hipaa_issue/famc_perm_lr_lrxref_valid_famc/")#
lr_v1.createOrReplaceTempView('lrv1')

print(lr_v1.count())


# COMMAND ----------

# DBTITLE 1,INVALID LR x LR_XREF
lr1 = spark.sql("""select r.*, lp.permid
             from famc_lr_xref_p lp
             JOIN lr_invalid r ON r.transactionkey = lp.transactionkey
             """)
lr1.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/famc_hipaa_issue/famc_perm_lr_lrxref_invalid_famc")


# COMMAND ----------

# DBTITLE 1,invalid lr X lr_xref counts
lr_in1 = spark.read.parquet(baseurl + "/abdul/famc_hipaa_issue/famc_perm_lr_lrxref_invalid_famc")#
lr_in1.createOrReplaceTempView('lri1')

print(lr_in1.count())

# COMMAND ----------

# DBTITLE 1,Invalid - valid ones
# Remove valid matching records lr_v1 from lr_in1 on ["gmrnid", "payerid", "coverageid", "clientid"]
df_p = lr_in1.join(lr_v1, on=["permid", "payerid", "coverageid", "clientid"], how="left_anti")
df_p.write.mode("overwrite").parquet(baseurl + "/abdul/famc_hipaa_issue/famc_lr_invalid_filtered_p_famc/")



# COMMAND ----------

# DBTITLE 1,Invalid-valid counts
df_p = spark.read.parquet(baseurl + "/abdul/famc_hipaa_issue/famc_lr_invalid_filtered_p_famc/")
df_p.createOrReplaceTempView('df_p')

print("lr_invalid_filtered_p count:", df_p.count())

# df_p.select("permid", "transactionkey", "sourcekey", "payerid", "coverageid", "clientid").dropDuplicates().count()#347035878

# COMMAND ----------

# DBTITLE 1,Read LSB
lsb = spark.read.format("delta").load(baseurl + "/data/leadservicebase/publish/served/leadservicebase/")
lsb_famc = lsb.filter(col("hcsystemfk_source").contains('_fm'))  # 303,552,807

lsb_famc_ex = lsb_famc.select("*", explode_outer("demographics")).drop("demographics").drop("hcsystemfk_source")
lsb_famc_ex_1 = lsb_famc_ex.withColumnRenamed("key", "hcsystemfk_source")
lsb_famc_ex_2 = lsb_famc_ex_1.filter(split(col("hcsystemfk_source"), '_')[1] == 'fm')

lsb_famc_ex_3 = lsb_famc_ex_2.withColumn("lsb_hospitalfk", col("value").hospitalfk)
lsb_hospital_split_df = lsb_famc_ex_3.withColumn("lsb_hospitalfk", split("lsb_hospitalfk", "\\|"))
lsb_hospital_ex_df = lsb_hospital_split_df.withColumn("lsb_hospitalfk", explode("lsb_hospitalfk"))
lsb_hospital_ex_df.createOrReplaceTempView('lsb_hospital_ex_df')

print("LSB Total count:" + str(lsb.count()))
print("LSB FAMC count:" + str(lsb_famc.count()))

print("LSB FAMC demo explode count:" + str(lsb_famc_ex.count()))
print("LSB ONLY FAMC demo explode count:" + str(lsb_famc_ex_2.count()))
print("LSB ONLY FAMC hosp explode count:" + str(lsb_hospital_ex_df.count()))

# COMMAND ----------

# DBTITLE 1,LEFT ANTI JOIN on InValid LR LR_XREF to get VALID LSB
#gmrn_xref
p1=spark.sql("""select p.*
             from lsb_hospital_ex_df p
             LEFT ANTI JOIN df_p dp ON p.identity = concat('P_',dp.permid) and p.leadid = concat(dp.payerid,'_',dp.coverageid) and p.lsb_hospitalfk = dp.clientid
             """)
p1.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/famc_hipaa_issue/lsb_covid_recs_source_perm_xref_invalid_filtered_famc/")


# COMMAND ----------

# DBTITLE 1,valid FAMC LSB data
lb1 = spark.read.parquet(baseurl + "/abdul/famc_hipaa_issue/lsb_covid_recs_source_perm_xref_invalid_filtered_famc/").dropDuplicates()
lb1.createOrReplaceTempView('lb1')
print("lb1 count:", lb1.count())

# COMMAND ----------

# MAGIC %md
# MAGIC # ## ###################IMPACT ANALYSIS HITS############################
# MAGIC # 

# COMMAND ----------

# DBTITLE 1,JOIN LR LR_XREF LSB DELETED
#perm_xref
p1=spark.sql("""select p.*
             from lsb_hospital_ex_df p
             JOIN df_p dp ON p.identity = concat('P_',permid) and p.leadid = concat(dp.payerid,'_',dp.coverageid) and p.lsb_hospitalfk = dp.clientid
             """)
p1.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/famc_hipaa_issue/lsb_covid_recs_source_perm_deleted_famc/")

# COMMAND ----------

# DBTITLE 1,Going to be deleted
d1 = spark.read.parquet(baseurl + "/abdul/famc_hipaa_issue/lsb_covid_recs_source_perm_deleted_famc/").dropDuplicates()
d1.createOrReplaceTempView('d1')
print("d1 count:", d1.count())
print("Uniq covids to be deleted :", d1.select("leadid").dropDuplicates().count())



# COMMAND ----------

# DBTITLE 1,Remove any ids match with non deleted leads
dl1 = d1.join(lb1, ['_id'], 'leftanti').select("_id")

dl1.write.mode("overwrite").parquet(baseurl + "/abdul/famc_hipaa_issue/lsb_covid_recs_source_perm_impact_famc/")

print("dl1 count:", dl1.count())

# COMMAND ----------

# DBTITLE 1,deletes impact
hosp = spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/dataingestion/publish/hospitals/current/20991231/").filter("active = 1")
eq = spark.read.format('delta').load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/dataingestion/publish/ediqueries/current/20991231/").select("hospitalfk", "edipartnerfk","EDIQueryPK","patientacctifk","trn","EDI270QueryComboIFK","createdate" )
eqhm = spark.read.format('delta').load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/dataingestion/publish/ediqueryhitsandmisses/current/20991231/").select("EDIQueryFK","EDI270QueryComboIFK","createdate","policyid").filter("result in ('EB:1','EB:2','EB:3','EB:4','EB:5')")
egsd = spark.read.format('delta').load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/dataingestion/publish/ediglobalsourceddata/current/20991231/").select("hospitalfk", "edidatasourcefk","trn","EDIPartnerFK","patientacctifk","EDISourceTableKey" )

hosp.createOrReplaceTempView('hosp')
eq.createOrReplaceTempView('eq')
eqhm.createOrReplaceTempView('eqhm')
egsd.createOrReplaceTempView('egsd')

deletes = spark.read.parquet(baseurl + "/abdul/famc_hipaa_issue/*_impact_famc/")
deletes.createOrReplaceTempView('deletes')#

res = spark.sql("""
        SELECT lb.*,hm.createdate as hm_createdate,eq.createdate as eq_createdate,hm.policyid
        FROM deletes lb
        JOIN egsd eg ON lb._id = eg.EDISourceTableKey
        JOIN eq eq ON eg.hospitalfk=eq.hospitalfk AND eg.trn = eq.trn and eq.EDIPartnerFK = eg.EDIPartnerFK and eq.patientacctifk = eg.patientacctifk
        JOIN eqhm hm ON eq.EDIQueryPK = hm.EDIQueryFK and eq.EDI270QueryComboIFK = hm.EDI270QueryComboIFK 
        JOIN hosp h ON h.HospitalPK = eq.HospitalFK
""").dropDuplicates()
res.write.mode("overwrite").parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/abdul/famc_hipaa_issue/hitstatus_leads20251021_activeH_famc/")

# COMMAND ----------

from pyspark.sql.functions import when, split, col
hs = spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/abdul/famc_hipaa_issue/hitstatus_leads20251021_activeH_famc/")

hs1 = hs.withColumn(
    "lsb_edipartner", when(col("_id").startswith("P"), split(col("_id"), "_")[2])
).withColumn(
    "lsb_coverageid", when(col("_id").startswith("P"), split(col("_id"), "_")[3])
).withColumn(
    "lsb_identity", when(col("_id").startswith("P"), split(col("_id"), "_")[1])
).withColumn(
    "lsb_id_type", when(col("_id").startswith("P"), split(col("_id"), "_")[0])
)

print("EB hits: " +str(hs.count()))
hs1.select("lsb_edipartner","lsb_coverageid").dropDuplicates().count()#

# COMMAND ----------

hs1.filter("policyid = lsb_coverageid").count()

# COMMAND ----------

# DBTITLE 1,write hits to file
hs2 = hs1.filter("policyid = lsb_coverageid").select(
    "lsb_edipartner",
    "lsb_coverageid",
    "lsb_identity",
    "lsb_id_type"
).dropDuplicates()
hs2.write.mode("overwrite").parquet(baseurl + "/abdul/famc_hipaa_issue/lsb_coverageid_policyid_match_famc/")

# COMMAND ----------

hh = spark.read.parquet(baseurl + "/abdul/famc_hipaa_issue/lsb_coverageid_policyid_match_famc/")
hh.count()


# COMMAND ----------

# MAGIC %md
# MAGIC ###################END of IMPACT ANALYSIS
# MAGIC
