# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window


# COMMAND ----------

dbutils.widgets.text("user", "")
dbutils.widgets.getArgument("user")
user = getArgument("user")

dbutils.widgets.text("container", "")
dbutils.widgets.getArgument("container")
container = getArgument("container")

dbutils.widgets.text("storageaccount", "")
dbutils.widgets.getArgument("storageaccount")
storageaccount = getArgument("storageaccount")



# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

print(baseurl)


# COMMAND ----------

# DBTITLE 1,Read LSB
lsb = spark.read.format("delta").load(baseurl + "/data/leadservicebase/publish/served/leadservicebase/")
lsb_chc = lsb.filter(col("hcsystemfk_source").contains('_chc'))
lsb_nchc = lsb.filter(~col("hcsystemfk_source").contains('_chc'))

lsb_chc_ex = lsb_chc.select("*",explode_outer("demographics")).drop("demographics").drop("hcsystemfk_source")
lsb_chc_ex_1 = lsb_chc_ex.withColumnRenamed("key", "hcsystemfk_source")
lsb_chc_ex_bad = lsb_chc_ex_1.filter(col("hcsystemfk_source") =='_chc')
lsb_chc_ex_good = lsb_chc_ex_1.filter(col("hcsystemfk_source") !='_chc')

print("LSB Total count:" + str(lsb.count()))
print("LSB CHC count:" + str(lsb_chc.count()))
print("LSB NON CHC count:" + str(lsb_nchc.count()))

print("LSB CHC demo explode count:" + str(lsb_chc_ex.count()))
print("LSB chc_ex_bad demo explode count:" + str(lsb_chc_ex_bad.count()))
print("LSB chc_ex_good  explode count:" + str(lsb_chc_ex_good.count()))


# COMMAND ----------

# DBTITLE 1,chc leads having mismatch demo issue due to ich  sub dep issue
chcLsbIdTobeDeleted = spark.read.format("parquet").load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/maxc/data/chcLsbIdTobeDeleted/")#6862
chcLsbIdTobeDeleted_ids = chcLsbIdTobeDeleted.select("_id").distinct()

lsb_chc_ex_good_chc = lsb_chc_ex_good.filter(col("hcsystemfk_source").like("%_chc"))
lsb_chc_ex_good_nchc = lsb_chc_ex_good.filter(~col("hcsystemfk_source").like("%_chc"))

lsb_chc_ex_good_chc_final = lsb_chc_ex_good_chc.join(chcLsbIdTobeDeleted_ids, (lsb_chc_ex_good["_id"] == chcLsbIdTobeDeleted_ids["_id"]), how="left_anti")
lsb_chc_ex_good_final = lsb_chc_ex_good_chc_final.union(lsb_chc_ex_good_nchc)

print("lsb_chc_ex_good_chc count: " + str(lsb_chc_ex_good_chc.count()))
print("lsb_chc_ex_good_nchc count: " + str(lsb_chc_ex_good_nchc.count()))
print("lsb_chc_ex_good_chc_final count: " + str(lsb_chc_ex_good_chc_final.count()))
print("lsb_chc_ex_good_final count: " + str(lsb_chc_ex_good_final.count()))


# COMMAND ----------

# DBTITLE 1,Remove duplicate demographics per _id+hcsystem_source
lsb_chc_ex_good_final.createOrReplaceTempView("lsb_chc_ex_good_final")
query_stmt = """ SELECT
                _id,
                sort_array(collect_list(hcsystemfk_source) over (PARTITION BY _id)) as hcsystemfk_source_concat,
                identity,
                min(leadcreatedate) over (PARTITION BY _id) as leadcreatedate,
                leadid,
                max(leadupdatedate) over (PARTITION BY _id) as leadupdatedate,
                min(lsbcreatedate) over (PARTITION BY _id) as lsbcreatedate,
                max(lsbupdatedate) over (PARTITION BY _id) as lsbupdatedate,
                sort_array(collect_list(struct(hcsystemfk_source, value)) over (PARTITION BY _id)) as demographics_list, 
                ROW_NUMBER() OVER (PARTITION BY _id ORDER BY leadupdatedate DESC) AS RNK
            FROM lsb_chc_ex_good_final
            """
new_lsb_chc = spark.sql(query_stmt).filter("RNK == 1").drop("RNK")

print("new_lsb LSB CHC count: " + str(new_lsb_chc.count()))


# COMMAND ----------

# DBTITLE 1,Transform to LSB format
new_lsb_chc1 = new_lsb_chc.withColumn('hcsystemfk_source', array_join('hcsystemfk_source_concat' , '|')).drop("hcsystemfk_source_concat")
new_lsb_chc2 = new_lsb_chc1.withColumn("demographics", map_from_entries("demographics_list")).drop("demographics_list")
new_lsb_chc2 = new_lsb_chc2.select('_id', 'hcsystemfk_source', 'identity', 'leadcreatedate', 'leadid', 'leadupdatedate', 'lsbcreatedate', 'lsbupdatedate', 'demographics')

new_lsb = lsb_nchc.union(new_lsb_chc2)#

print("new_lsb LSB count: " + str(new_lsb.count()))

new_lsb.write.mode("overwrite").format("delta").save(baseurl + "/abdul/data/leadservicebase/staging/leadservicebase_new_chc/")
