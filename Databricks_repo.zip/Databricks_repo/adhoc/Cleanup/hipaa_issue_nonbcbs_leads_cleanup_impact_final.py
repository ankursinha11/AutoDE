# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window


# COMMAND ----------

dbutils.widgets.text("user", "")
dbutils.widgets.getArgument("user")
user = getArgument("user")

dbutils.widgets.text("container", "")
dbutils.widgets.getArgument("container")
container = getArgument("container")

dbutils.widgets.text("storageaccount", "")
dbutils.widgets.getArgument("storageaccount")
storageaccount = getArgument("storageaccount")


# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

print(baseurl)


# COMMAND ----------

# DBTITLE 1,Read LR LR_XREF
lr_xref_g = spark.read.format('delta').load(baseurl + "/data/leadrepo/publish/cooked/lr_xref_gmrnid_transaction/")
lr_xref_g = lr_xref_g.filter("sourcekey = 1")
lr_xref_g.createOrReplaceTempView('lr_xref_g')
lr_xref_p = spark.read.format('delta').load(baseurl + "/data/leadrepo/publish/cooked/lr_xref_permid_transaction/")
lr_xref_p = lr_xref_p.filter("sourcekey = 1")
lr_xref_p.createOrReplaceTempView('lr_xref_p')
lr_xref_smc = spark.read.format('delta').load(baseurl + "/data/leadrepo/publish/cooked/lr_xref_ssn_mrn_cluster_transaction/")
lr_xref_smc = lr_xref_smc.filter("sourcekey = 1")
lr_xref_smc.createOrReplaceTempView('lr_xref_smc')

lr = spark.read.format("parquet").load(baseurl + "/data/leadrepo/publish/cooked/lr_transaction/") 
lr_cols = ['transactionkey','clientid', 'lr_createdate', 'verifiedsource', 'responsestatus','payerid','coverageid', 'sourcekey']
lr = lr.select(lr_cols)
print("lr total count:" + str(lr.count()))#

lr = lr.filter("payerid != '101'and sourcekey == '1'")#
# lr = lr.withColumn("respst", split(col("responsestatus"),'\\|'))
# lr = lr.withColumn("respst_exp", explode(col("respst")))
# lr_valid = lr.filter("respst_exp in ('EB:1','EB:2','EB:3','EB:4','EB:5','EB:6')")#
# lr_invalid = lr.filter("respst_exp = '' or respst_exp not in ('EB:1','EB:2','EB:3','EB:4','EB:5','EB:6')")#
lr_valid = lr.where(
                    lr.responsestatus.like('%EB:1%') | 
                    lr.responsestatus.like('%EB:2%') | 
                    lr.responsestatus.like('%EB:3%') | 
                    lr.responsestatus.like('%EB:4%') | 
                    lr.responsestatus.like('%EB:5%') | 
                    lr.responsestatus.like('%EB:6%')
                    )
lr_valid.createOrReplaceTempView('lr_valid')
lr_invalid = lr.exceptAll(lr_valid)
lr_invalid.createOrReplaceTempView('lr_invalid')

print("lr nbcbs fc count:" + str(lr.count()))#
print("lr nbcbs fc valid count:" + str(lr_valid.count()))#451,557,840
print("lr nbcbs fc invalid count:" + str(lr_invalid.count()))#451,557,840

print("lr_xref_g fc count:" + str(lr_xref_g.count()))#2,997,221,554
print("lr_xref_p fc count:" + str(lr_xref_p.count()))#2,395,025,351
print("lr_xref_smc fc count:" + str(lr_xref_smc.count()))#71258186


# COMMAND ----------

# DBTITLE 1,Valid LR X LR_XREF
lr1 = spark.sql("""select r.*, lg.gmrnid
             from lr_xref_g lg
             JOIN lr_valid r ON r.transactionkey = lg.transactionkey
             """)
lr1.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/hipaa_issue/lsb_gmrn_lr_lrxref_nonbcbs_valid/")

lr2 = spark.sql("""select r.*, lp.permid
             from lr_xref_p lp
             JOIN lr_valid r ON r.transactionkey = lp.transactionkey
             """)
lr2.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/hipaa_issue/lsb_perm_lr_lrxref_nonbcbs_valid/")

lr3 = spark.sql("""select r.*, ls.ssn
             from lr_xref_smc ls
             JOIN lr_valid r ON r.transactionkey = ls.transactionkey
             """)
lr3.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/hipaa_issue/lsb_ssn_lr_lrxref_nonbcbs_valid/")

lr4 = spark.sql("""select r.*, lm.medicalrecnum
             from lr_xref_smc lm
             JOIN lr_valid r ON r.transactionkey = lm.transactionkey
             """)
lr4.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/hipaa_issue/lsb_mrn_lr_lrxref_nonbcbs_valid/")

lr5 = spark.sql("""select r.*, lc.clusteredacctfk
             from lr_xref_smc lc
             JOIN lr_valid r ON r.transactionkey = lc.transactionkey
             """)
lr5.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/hipaa_issue/lsb_cls_lr_lrxref_nonbcbs_valid/")

# COMMAND ----------

# DBTITLE 1,valid lr lr_xref counts
lr_v1 = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lsb_gmrn_lr_lrxref_nonbcbs_valid/")#
lr_v1.createOrReplaceTempView('lrv1')
lr_v2 = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lsb_perm_lr_lrxref_nonbcbs_valid/")#
lr_v2.createOrReplaceTempView('lrv2')
lr_v3 = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lsb_ssn_lr_lrxref_nonbcbs_valid/")#
lr_v3.createOrReplaceTempView('lrv3')
lr_v4 = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lsb_mrn_lr_lrxref_nonbcbs_valid/")#
lr_v4.createOrReplaceTempView('lrv4')
lr_v5 = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lsb_cls_lr_lrxref_nonbcbs_valid/")#
lr_v5.createOrReplaceTempView('lrv5')


print(lr_v1.count())
print(lr_v2.count())
print(lr_v3.count())
print(lr_v4.count())
print(lr_v5.count())

# COMMAND ----------

# DBTITLE 1,INVALID LR x LR_XREF
lr1 = spark.sql("""select r.*, lg.gmrnid
             from lr_xref_g lg
             JOIN lr_invalid r ON r.transactionkey = lg.transactionkey
             """)
lr1.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/hipaa_issue/lsb_gmrn_lr_lrxref_nonbcbs_invalid_filtered1/")

lr2 = spark.sql("""select r.*, lp.permid
             from lr_xref_p lp
             JOIN lr_invalid r ON r.transactionkey = lp.transactionkey
             """)
lr2.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/hipaa_issue/lsb_perm_lr_lrxref_nonbcbs_invalid_filtered1/")

lr3 = spark.sql("""select r.*, ls.ssn
             from lr_xref_smc ls
             JOIN lr_invalid r ON r.transactionkey = ls.transactionkey
             """)
lr3.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/hipaa_issue/lsb_ssn_lr_lrxref_nonbcbs_invalid_filtered1/")

lr4 = spark.sql("""select r.*, lm.medicalrecnum
             from lr_xref_smc lm
             JOIN lr_invalid r ON r.transactionkey = lm.transactionkey
             """)
lr4.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/hipaa_issue/lsb_mrn_lr_lrxref_nonbcbs_invalid_filtered1/")

lr5 = spark.sql("""select r.*, lc.clusteredacctfk
             from lr_xref_smc lc
             JOIN lr_invalid r ON r.transactionkey = lc.transactionkey
             """)
lr5.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/hipaa_issue/lsb_cls_lr_lrxref_nonbcbs_invalid_filtered1/")

# COMMAND ----------

lr_in1 = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lsb_gmrn_lr_lrxref_nonbcbs_invalid_filtered1/")#
lr_in1.createOrReplaceTempView('lri1')
lr_in2 = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lsb_perm_lr_lrxref_nonbcbs_invalid_filtered1/")#
lr_in2.createOrReplaceTempView('lri2')
lr_in3 = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lsb_ssn_lr_lrxref_nonbcbs_invalid_filtered1/")#
lr_in3.createOrReplaceTempView('lri3')
lr_in4 = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lsb_mrn_lr_lrxref_nonbcbs_invalid_filtered1/")#
lr_in4.createOrReplaceTempView('lri4')
lr_in5 = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lsb_cls_lr_lrxref_nonbcbs_invalid_filtered1/")#
lr_in5.createOrReplaceTempView('lri5')

print(lr_in1.count())
print(lr_in2.count())
print(lr_in3.count())
print(lr_in4.count())
print(lr_in5.count())

# COMMAND ----------

# DBTITLE 1,Invalid - valid ones
# Remove valid matching records lr_v1 from lr_in1 on ["gmrnid", "payerid", "coverageid", "clientid"]
df_g = lr_in1.join(lr_v1, on=["gmrnid", "payerid", "coverageid", "clientid"], how="left_anti")
df_g.createOrReplaceTempView('lr_invalid_filtered_g')
df_g.write.mode("overwrite").parquet(baseurl + "/abdul/hipaa_issue/lr_lr_xref_valid_invalid_filtered_nbcbs_g/")

# Remove valid matching records lr_v2 from lr_in2 on ["permid", "payerid", "coverageid", "clientid"]
df_p = lr_in2.join(lr_v2, on=["permid", "payerid", "coverageid", "clientid"], how="left_anti")
df_p.createOrReplaceTempView('lr_invalid_filtered_p')
df_p.write.mode("overwrite").parquet(baseurl + "/abdul/hipaa_issue/lr_lr_xref_valid_invalid_filtered_nbcbs_p/")

# Remove valid matching records lr_v3 from lr_in3 on ["ssn", "payerid", "coverageid", "clientid"]
df_s = lr_in3.join(lr_v3, on=["ssn", "payerid", "coverageid", "clientid"], how="left_anti")
df_s.createOrReplaceTempView('lr_invalid_filtered_s')
df_s.write.mode("overwrite").parquet(baseurl + "/abdul/hipaa_issue/lr_lr_xref_valid_invalid_filtered_nbcbs_s/")

# Remove valid matching records lr_v4 from lr_in4 on ["medicalrecnum", "payerid", "coverageid", "clientid"]
df_m = lr_in4.join(lr_v4, on=["medicalrecnum", "payerid", "coverageid", "clientid"], how="left_anti")
df_m.createOrReplaceTempView('lr_invalid_filtered_m')
df_m.write.mode("overwrite").parquet(baseurl + "/abdul/hipaa_issue/lr_lr_xref_valid_invalid_filtered_nbcbs_m/")

# Remove valid matching records lr_v5 from lr_in5 on ["clusteredacctfk", "payerid", "coverageid", "clientid"]
df_c = lr_in5.join(lr_v5, on=["clusteredacctfk", "payerid", "coverageid", "clientid"], how="left_anti")
df_c.createOrReplaceTempView('lr_invalid_filtered_c')
df_c.write.mode("overwrite").parquet(baseurl + "/abdul/hipaa_issue/lr_lr_xref_valid_invalid_filtered_nbcbs_c/")

# COMMAND ----------

# DBTITLE 1,invalid-valid lr lr_xref counts
df_g = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lr_lr_xref_valid_invalid_filtered_nbcbs_g/")
df_g.createOrReplaceTempView('df_g')
print("lr_invalid_filtered_g count:", df_g.count())
df_p = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lr_lr_xref_valid_invalid_filtered_nbcbs_p/")
df_p.createOrReplaceTempView('df_p')
print("lr_invalid_filtered_p count:", df_p.count())
df_s = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lr_lr_xref_valid_invalid_filtered_nbcbs_s/")
df_s.createOrReplaceTempView('df_s')
print("lr_invalid_filtered_s count:", df_s.count())
df_m = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lr_lr_xref_valid_invalid_filtered_nbcbs_m/")
df_m.createOrReplaceTempView('df_m')
print("lr_invalid_filtered_m count:", df_m.count())
df_c = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lr_lr_xref_valid_invalid_filtered_nbcbs_c/")
df_c.createOrReplaceTempView('df_c')
print("lr_invalid_filtered_c count:", df_c.count())


# COMMAND ----------

# DBTITLE 1,Read LSB
lsb = spark.read.format("delta").load(baseurl + "/data/leadservicebase/publish/served/leadservicebase/")

lsb_fc = lsb.filter(col("hcsystemfk_source").contains('_fc'))#3,136,461,976
lsb_fc_bcbs = lsb_fc.filter(split(col('leadid'), '_')[0] == '101')#567,158,050
lsb_fc_nbcbs = lsb_fc.filter(split(col('leadid'), '_')[0] != '101')

lsb_fc_nbcbs_ex = lsb_fc_nbcbs.select("*",explode_outer("demographics")).drop("demographics").drop("hcsystemfk_source")
lsb_fc_nbcbs_ex_1 = lsb_fc_nbcbs_ex.withColumnRenamed("key", "hcsystemfk_source")
lsb_fc_nbcbs_ex_1 = lsb_fc_nbcbs_ex_1.filter(split(col("hcsystemfk_source"), '_')[1] =='fc')

lsb_fc_nbcbs_ex_1 = lsb_fc_nbcbs_ex_1.withColumn("lsb_hospitalfk", col("value").hospitalfk)
lsb_hospital_split_df = lsb_fc_nbcbs_ex_1.withColumn("lsb_hospitalfk", split("lsb_hospitalfk", "\\|"))
lsb_hospital_ex_df = lsb_hospital_split_df.withColumn("lsb_hospitalfk", explode("lsb_hospitalfk"))

lsb_g =lsb_hospital_ex_df.filter(col("_id").startswith('G'))
lsb_g.createOrReplaceTempView("lsb_g")
lsb_p =lsb_hospital_ex_df.filter(col("_id").startswith('P'))
lsb_p.createOrReplaceTempView("lsb_p")
lsb_s =lsb_hospital_ex_df.filter(col("_id").startswith('S'))
lsb_s.createOrReplaceTempView("lsb_s")
lsb_m =lsb_hospital_ex_df.filter(col("_id").startswith('MH'))
lsb_m.createOrReplaceTempView("lsb_m")
lsb_c =lsb_hospital_ex_df.filter(col("_id").startswith('CH'))
lsb_c.createOrReplaceTempView("lsb_c")

print("LSB Total count:" + str(lsb.count()))
print("LSB FC count:" + str(lsb_fc.count()))
print("LSB FC BCBS count:" + str(lsb_fc_bcbs.count()))
print("LSB FC NON BCBS count:" + str(lsb_fc_nbcbs.count()))
print("LSB FC NON BCBS hosp explode count:" + str(lsb_hospital_ex_df.count()))
print("LSB FC gmrnid count:" + str(lsb_g.count()))
print("LSB FC permid count:" + str(lsb_p.count()))
print("LSB FC ssn count:" + str(lsb_s.count()))
print("LSB FC mrn count:" + str(lsb_m.count()))
print("LSB FC clusteredacct count:" + str(lsb_c.count()))


# COMMAND ----------

# DBTITLE 1,LSB prior uniq lead count
from pyspark.sql.functions import col

leadid_g = lsb_g.select("leadid")
leadid_p = lsb_p.select("leadid")
leadid_s = lsb_s.select("leadid")
leadid_m = lsb_m.select("leadid")
leadid_c = lsb_c.select("leadid")

all_leadids = leadid_g.unionByName(leadid_p).unionByName(leadid_s).unionByName(leadid_m).unionByName(leadid_c).dropDuplicates()
print(all_leadids.count())

# COMMAND ----------

# DBTITLE 1,JOIN valid LR LR_XREF LSB
#gmrn_xref
p1=spark.sql("""select g.*
             from lsb_g g
             LEFT ANTI JOIN df_g dg ON g.identity = concat('G_',dg.gmrnid) and g.leadid = concat(dg.payerid,'_',dg.coverageid) and g.lsb_hospitalfk = dg.clientid
             """)
p1.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/hipaa_issue/lsb_nbcbs_gmrn_xref_invalid_filtered2/")

# #permid_xref
p2 = spark.sql("""select p.*
             from lsb_p p
             LEFT ANTI JOIN df_p dp ON p.identity = concat('P_',dp.permid) and p.leadid = concat(dp.payerid,'_',dp.coverageid) and p.lsb_hospitalfk = dp.clientid
             """)
p2.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/hipaa_issue/lsb_nbcbs_perm_xref_invalid_filtered2/")

# ssn_xref
p3 = spark.sql("""select s.*
             from lsb_s s
             LEFT ANTI JOIN df_s ds ON s.identity = concat('S_',ds.ssn) and s.leadid = concat(ds.payerid,'_',ds.coverageid) and s.lsb_hospitalfk = ds.clientid
             """)
p3.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/hipaa_issue/lsb_nbcbs_ssn_xref_invalid_filtered2/")

# #_mrn_xref
p4 = spark.sql("""select m.*
             from lsb_m m
             LEFT ANTI JOIN df_m dm ON m.identity = concat('MH_',dm.clientid,'_',dm.medicalrecnum) and m.leadid = concat(dm.payerid,'_',dm.coverageid) and m.lsb_hospitalfk = dm.clientid
             """)
p4.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/hipaa_issue/lsb_nbcbs_mrn_xref_invalid_filtered2/")

p5 = spark.sql("""select c.*
             from lsb_c c
             LEFT ANTI JOIN df_c dc ON c.identity = concat('CH_',dc.clientid,'_',dc.clusteredacctfk) and c.leadid = concat(dc.payerid,'_',dc.coverageid) and c.lsb_hospitalfk = dc.clientid
             """)
p5.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/hipaa_issue/lsb_nbcbs_cls_xref_invalid_filtered2/")

# COMMAND ----------

# DBTITLE 1,valid BCBS LSB data
lb1 = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lsb_nbcbs_gmrn_xref_invalid_filtered2/").dropDuplicates()
lb1.createOrReplaceTempView('lb1')
print("lb1 count:", lb1.count())

lb2 = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lsb_nbcbs_perm_xref_invalid_filtered2/").dropDuplicates()
lb2.createOrReplaceTempView('lb2')
print("lb2 count:", lb2.count())

lb3 = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lsb_nbcbs_ssn_xref_invalid_filtered2/").dropDuplicates()
lb3.createOrReplaceTempView('lb3')
print("lb3 count:", lb3.count())

lb4 = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lsb_nbcbs_mrn_xref_invalid_filtered2/").dropDuplicates()
lb4.createOrReplaceTempView('lb4')
print("lb4 count:", lb4.count())

lb5 = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lsb_nbcbs_cls_xref_invalid_filtered2/").dropDuplicates()
lb5.createOrReplaceTempView('lb5')
print("lb5 count:", lb5.count())

# COMMAND ----------

# DBTITLE 1,lead uniq count to keep
from pyspark.sql.functions import col

leadqq_g = lb1.select("leadid")
leadqq_p = lb2.select("leadid")
leadqq_s = lb3.select("leadid")
leadqq_m = lb4.select("leadid")
leadqq_c = lb5.select("leadid")

all_leadqqs = leadqq_g.unionByName(leadqq_p).unionByName(leadqq_s).unionByName(leadqq_m).unionByName(leadqq_c).dropDuplicates()
print(all_leadqqs.count())

# COMMAND ----------

# MAGIC %md
# MAGIC # ## ###################IMPACT ANALYSIS HITS############################

# COMMAND ----------

# DBTITLE 1,JOIN LR LR_XREF LSB DELETED
#gmrn_xref
p1=spark.sql("""select g.*
             from lsb_g g
             JOIN df_g dg ON g.identity = concat('G_',dg.gmrnid) and g.leadid = concat(dg.payerid,'_',dg.coverageid) and g.lsb_hospitalfk = dg.clientid
             """)
p1.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/hipaa_issue/lsb_covid_recs_source_gmrn_deleted_nbcbs/")

# #permid_xref
p2 = spark.sql("""select p.*
             from lsb_p p
             JOIN df_p dp ON p.identity = concat('P_',dp.permid) and p.leadid = concat(dp.payerid,'_',dp.coverageid) and p.lsb_hospitalfk = dp.clientid
             """)
p2.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/hipaa_issue/lsb_covid_recs_source_perm_deleted_nbcbs/")

# ssn_xref
p3 = spark.sql("""select s.*
             from lsb_s s
             JOIN df_s ds ON s.identity = concat('S_',ds.ssn) and s.leadid = concat(ds.payerid,'_',ds.coverageid) and s.lsb_hospitalfk = ds.clientid
             """)
p3.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/hipaa_issue/lsb_covid_recs_source_ssn_deleted_nbcbs/")

# #_mrn_xref
p4 = spark.sql("""select m.*
             from lsb_m m
             JOIN df_m dm ON m.identity = concat('MH_',dm.clientid,'_',dm.medicalrecnum) and m.leadid = concat(dm.payerid,'_',dm.coverageid) and m.lsb_hospitalfk = dm.clientid
             """)
p4.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/hipaa_issue/lsb_covid_recs_source_mrn_deleted_nbcbs/")

p5 = spark.sql("""select c.*
             from lsb_c c
             JOIN df_c dc ON c.identity = concat('CH_',dc.clientid,'_',dc.clusteredacctfk) and c.leadid = concat(dc.payerid,'_',dc.coverageid) and c.lsb_hospitalfk = dc.clientid
             """)
p5.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/hipaa_issue/lsb_covid_recs_source_cls_deleted_nbcbs/")

# COMMAND ----------

# DBTITLE 1,Going to be deleted
d1 = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lsb_covid_recs_source_gmrn_deleted_nbcbs/").dropDuplicates()
d1.createOrReplaceTempView('d1')
print("d1 count:", d1.count())

d2 = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lsb_covid_recs_source_perm_deleted_nbcbs/").dropDuplicates()
d2.createOrReplaceTempView('d2')
print("d2 count:", d2.count())

d3 = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lsb_covid_recs_source_ssn_deleted_nbcbs/").dropDuplicates()
d3.createOrReplaceTempView('d3')
print("d3 count:", d3.count())

d4 = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lsb_covid_recs_source_mrn_deleted_nbcbs/").dropDuplicates()
d4.createOrReplaceTempView('d4')
print("d4 count:", d4.count())

d5 = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lsb_covid_recs_source_cls_deleted_nbcbs/").dropDuplicates()
d5.createOrReplaceTempView('d5')
print("d5 count:", d5.count())

# COMMAND ----------

# DBTITLE 1,uniq leads to be deleted
from pyspark.sql.functions import col

ldq_g = d1.select("leadid")
ldq_p = d2.select("leadid")
ldq_s = d3.select("leadid")
ldq_m = d4.select("leadid")
ldq_c = d5.select("leadid")

all_ds = ldq_g.unionByName(ldq_p).unionByName(ldq_s).unionByName(ldq_m).unionByName(ldq_c).dropDuplicates()
print(all_ds.subtract(all_leadqqs).count())#

# COMMAND ----------

# DBTITLE 1,Remove any ids match with non deleted leads
dl1 = d1.join(lb1, ['_id'], 'leftanti').select("_id")
dl2 = d2.join(lb2, ['_id'], 'leftanti').select("_id")
dl3 = d3.join(lb3, ['_id'], 'leftanti').select("_id")
dl4 = d4.join(lb4, ['_id'], 'leftanti').select("_id")
dl5 = d5.join(lb5, ['_id'], 'leftanti').select("_id")

dl1.write.mode("overwrite").parquet(baseurl + "/abdul/hipaa_issue/lsb_covid_recs_source_gmrn_impact_nbcbs/")
dl2.write.mode("overwrite").parquet(baseurl + "/abdul/hipaa_issue/lsb_covid_recs_source_perm_impact_nbcbs/")
dl3.write.mode("overwrite").parquet(baseurl + "/abdul/hipaa_issue/lsb_covid_recs_source_ssn_impact_nbcbs/")
dl4.write.mode("overwrite").parquet(baseurl + "/abdul/hipaa_issue/lsb_covid_recs_source_mrn_impact_nbcbs/")
dl5.write.mode("overwrite").parquet(baseurl + "/abdul/hipaa_issue/lsb_covid_recs_source_cls_impact_nbcbs/")

print("dl1 count:", dl1.count())
print("dl2 count:", dl2.count())
print("dl3 count:", dl3.count())
print("dl4 count:", dl4.count())
print("dl5 count:", dl5.count())

# COMMAND ----------

# DBTITLE 1,deletes impact
hosp = spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/dataingestion/publish/hospitals/current/20991231/").filter("active = 1")
eq = spark.read.format('delta').load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/dataingestion/publish/ediqueries/current/20991231/").select("hospitalfk", "edipartnerfk","EDIQueryPK","patientacctifk","trn","EDI270QueryComboIFK","createdate" )
eqhm = spark.read.format('delta').load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/dataingestion/publish/ediqueryhitsandmisses/current/20991231/").select("EDIQueryFK","EDI270QueryComboIFK","createdate","policyid").filter("result in ('EB:1','EB:2','EB:3','EB:4','EB:5')")
egsd = spark.read.format('delta').load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/dataingestion/publish/ediglobalsourceddata/current/20991231/").select("hospitalfk", "edidatasourcefk","trn","EDIPartnerFK","patientacctifk","EDISourceTableKey" )

hosp.createOrReplaceTempView('hosp')
eq.createOrReplaceTempView('eq')
eqhm.createOrReplaceTempView('eqhm')
egsd.createOrReplaceTempView('egsd')

deletes = spark.read.parquet(baseurl + "/abdul/hipaa_issue/*_impact_nbcbs/")
deletes.createOrReplaceTempView('deletes')#712739376
# deletes.count()

res = spark.sql("""
        SELECT lb.*,hm.createdate as hm_createdate,eq.createdate as eq_createdate,hm.policyid
        FROM deletes lb
        JOIN egsd eg ON lb._id = eg.EDISourceTableKey
        JOIN eq eq ON eg.hospitalfk=eq.hospitalfk AND eg.trn = eq.trn and eq.EDIPartnerFK = eg.EDIPartnerFK and eq.patientacctifk = eg.patientacctifk
        JOIN eqhm hm ON eq.EDIQueryPK = hm.EDIQueryFK and eq.EDI270QueryComboIFK = hm.EDI270QueryComboIFK 
        JOIN hosp h ON h.HospitalPK = eq.HospitalFK
""").dropDuplicates()
res.write.mode("overwrite").parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/abdul/hipaa_issue/hitstatus_leads20251001_activeH_nonbcbs/")

# COMMAND ----------

hs = spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/abdul/hipaa_issue/hitstatus_leads20251001_activeH_nonbcbs/")
# hs.filter("_id like '%MKY3HZN30219650%'").display()#6,034,291
# hs.select(max("hm_createdate")).display()
# hs.filter("hm_createdate = '2025-09-11'").display()
# hs.select(max("eq_createdate")).display()

hs.count()

# COMMAND ----------

from pyspark.sql.functions import when, split, col

hs1 = hs.withColumn(
    "lsb_edipartner",
    when(col("_id").startswith("G"), split(col("_id"), "_")[2])
    .when(col("_id").startswith("P"), split(col("_id"), "_")[2])
    .when(col("_id").startswith("S"), split(col("_id"), "_")[2])
    .when(col("_id").startswith("MH"), split(col("_id"), "_")[3])
    .when(col("_id").startswith("CH"), split(col("_id"), "_")[3])
).withColumn(
    "lsb_coverageid",
    when(col("_id").startswith("G"), split(col("_id"), "_")[3])
    .when(col("_id").startswith("P"), split(col("_id"), "_")[3])
    .when(col("_id").startswith("S"), split(col("_id"), "_")[3])
    .when(col("_id").startswith("MH"), split(col("_id"), "_")[4])
    .when(col("_id").startswith("CH"), split(col("_id"), "_")[4])
).withColumn(
    "lsb_identity",
    when(col("_id").startswith("G"), split(col("_id"), "_")[1])
    .when(col("_id").startswith("P"), split(col("_id"), "_")[1])
    .when(col("_id").startswith("S"), split(col("_id"), "_")[1])
    .when(col("_id").startswith("MH"), split(col("_id"), "_")[2])
    .when(col("_id").startswith("CH"), split(col("_id"), "_")[2])
).withColumn(
    "lsb_id_type",
    when(col("_id").startswith("G"), split(col("_id"), "_")[0])
    .when(col("_id").startswith("P"), split(col("_id"), "_")[0])
    .when(col("_id").startswith("S"), split(col("_id"), "_")[0])
    .when(col("_id").startswith("MH"), split(col("_id"), "_")[0])
    .when(col("_id").startswith("CH"), split(col("_id"), "_")[0])
)

hs1.select("lsb_edipartner","lsb_coverageid").dropDuplicates().count()#2,003,673 1,820,842

# COMMAND ----------

# DBTITLE 1,write hits to file
hs1.filter("policyid = lsb_coverageid").count()#847893
# hs1.filter("policyid = lsb_coverageid").select("lsb_edipartner","lsb_coverageid").dropDuplicates().count()

hs2 = hs1.filter("policyid = lsb_coverageid").select(
    "lsb_edipartner",
    "lsb_coverageid",
    "lsb_identity",
    "lsb_id_type"
).dropDuplicates()
hs2.write.mode("overwrite").parquet(baseurl + "/abdul/hipaa_issue/lsb_coverageid_policyid_match_nbcbs/")

# COMMAND ----------

hh = spark.read.parquet(baseurl + "/abdul/hipaa_issue/lsb_coverageid_policyid_match_nbcbs/")
hh.count()


# COMMAND ----------


