# Databricks notebook source
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

# COMMAND ----------

# user='ramcharan'
# bc='20250922T11'
# container='prod-icd-stg-adls'
# storageaccount='prodicdstgdls'
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# DBTITLE 1,Read Paths
lr_transaction_df=spark.read.parquet(baseurl+"/data/leadrepo/publish/cooked/lr_transaction/*/*")
lr_transaction_ich_df=lr_transaction_df.filter("sourcekey=2")
lr_invalid=lr_transaction_ich_df.filter("responsestatus in ('0','3','4','5','7','8','10','15','16','17','312','313','314')")
lr_invalid.createOrReplaceTempView('lr_invalid')



lr_valid= lr_transaction_ich_df.filter("responsestatus not in ('0','3','4','5','7','8','10','15','16','17','312','313','314')")#
lr_valid.createOrReplaceTempView('lr_valid')

print("lr_valid:",lr_valid.count())
print("lr_invalid:",lr_invalid.count())
# print("lr_transaction:",lr_transaction_df.count())
# print("lr_transaction_ich:",lr_transaction_ich_df.count())

lr_xref_permid_transaction_df=spark.read.format('delta').load(baseurl+"/data/leadrepo/publish/cooked/lr_xref_permid_transaction/")
lr_xref_permid_transaction_ich_df=lr_xref_permid_transaction_df.filter("sourcekey=2")
lr_xref_gmrnid_transaction_df=spark.read.format('delta').load(baseurl+"/data/leadrepo/publish/cooked/lr_xref_gmrnid_transaction/")
lr_xref_gmrnid_transaction_ich_df=lr_xref_gmrnid_transaction_df.filter("sourcekey=2")
famc_lr_xref_permid_transaction_df=spark.read.format('delta').load(baseurl+"/data/leadrepo/publish/cooked/famc_lr_xref_permid_transaction/")
famc_lr_xref_permid_transaction_ich_df=famc_lr_xref_permid_transaction_df.filter("sourcekey=2")

print("famc_lr_xref_permid_transaction:",famc_lr_xref_permid_transaction_df.count())
print("famc_lr_xref_permid_transaction_ich:",famc_lr_xref_permid_transaction_ich_df.count())
print("lr_xref_permid_transaction:",lr_xref_permid_transaction_df.count())
print("lr_xref_permid_transaction_ich:",lr_xref_permid_transaction_ich_df.count())
print("lr_xref_gmrnid_transaction:",lr_xref_gmrnid_transaction_df.count())
print("lr_xref_gmrnid_transaction_ich:",lr_xref_gmrnid_transaction_ich_df.count())

# COMMAND ----------

# DBTITLE 1,Create Views
# lr_transaction_ich_df.createOrReplaceTempView("lr_transaction_ich_tbl")
lr_xref_permid_transaction_ich_df.createOrReplaceTempView("lr_xref_p")
lr_xref_gmrnid_transaction_ich_df.createOrReplaceTempView("lr_xref_g")
famc_lr_xref_permid_transaction_ich_df.createOrReplaceTempView("famc_lr_xref_p")

# COMMAND ----------

# DBTITLE 1,Valid LR X LR_XREF
lr1 = spark.sql("""select r.*, lg.gmrnid
             from lr_xref_g lg
             JOIN lr_valid r ON r.transactionkey = lg.transactionkey
             """)
lr1.write.mode("overwrite").format("parquet").save(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/scratch/lr_xref_gmrnid_valid_filtered/")

lr2 = spark.sql("""select r.*, lp.permid
             from lr_xref_p lp
             JOIN lr_valid r ON r.transactionkey = lp.transactionkey
             """)
lr2.write.mode("overwrite").format("parquet").save(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/scratch/lr_xref_permid_valid_filtered/")

lr3 = spark.sql("""select r.*, lp.permid
             from famc_lr_xref_p lp
             JOIN lr_valid r ON r.transactionkey = lp.transactionkey
             """)
lr3.write.mode("overwrite").format("parquet").save(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/scratch/lr_xref_famc_permid_valid_filtered/")

# COMMAND ----------

# DBTITLE 1,Invalid LR X LR_XREF
lr1 = spark.sql("""select r.*, lg.gmrnid
             from lr_xref_g lg
             JOIN lr_invalid r ON r.transactionkey = lg.transactionkey
             """)
lr1.write.mode("overwrite").format("parquet").save(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/scratch/lr_xref_gmrnid_invalid_filtered/")

lr2 = spark.sql("""select r.*, lp.permid
             from lr_xref_p lp
             JOIN lr_invalid r ON r.transactionkey = lp.transactionkey
             """)
lr2.write.mode("overwrite").format("parquet").save(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/scratch/lr_xref_permid_invalid_filtered/")

lr3 = spark.sql("""select r.*, lp.permid
             from famc_lr_xref_p lp
             JOIN lr_invalid r ON r.transactionkey = lp.transactionkey
             """)
lr3.write.mode("overwrite").format("parquet").save(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/scratch/lr_famc_xref_permid_invalid_filtered/")

# COMMAND ----------

lr_v1 = spark.read.parquet(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/scratch/lr_xref_gmrnid_valid_filtered/")#
lr_v1.createOrReplaceTempView('lrv1')
lr_v2 = spark.read.parquet(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/scratch/lr_xref_permid_valid_filtered/")#
lr_v2.createOrReplaceTempView('lrv2')
lr_v3 = spark.read.parquet(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/scratch/lr_xref_famc_permid_valid_filtered/")#
lr_v3.createOrReplaceTempView('lrv3')

print(lr_v1.count())
print(lr_v2.count())
print(lr_v3.count())

# COMMAND ----------

lr_in1 = spark.read.parquet(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/scratch/lr_xref_gmrnid_invalid_filtered/")#
lr_in1.createOrReplaceTempView('lri1')
lr_in2 = spark.read.parquet(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/scratch/lr_xref_permid_invalid_filtered/")#
lr_in2.createOrReplaceTempView('lri2')
lr_in3 = spark.read.parquet(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/scratch/lr_famc_xref_permid_invalid_filtered/")#
lr_in3.createOrReplaceTempView('lri3')

print(lr_in1.count())
print(lr_in2.count())
print(lr_in3.count())

# COMMAND ----------

# DBTITLE 1,Invalid - valid ones
# Remove valid matching records lr_v1 from lr_in1 on ["gmrnid", "payerid", "coverageid", "clientid"]
df_g = lr_in1.join(lr_v1, on=["gmrnid", "payerid", "coverageid", "clientid"], how="left_anti")
df_g.createOrReplaceTempView('lr_invalid_filtered_g')
print("lr_invalid_filtered_g count:", df_g.count())
df_g.write.mode("overwrite").parquet(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/scratch/lr_invalid_filtered_g/")

# Remove valid matching records lr_v2 from lr_in2 on ["permid", "payerid", "coverageid", "clientid"]
df_p = lr_in2.join(lr_v2, on=["permid", "payerid", "coverageid", "clientid"], how="left_anti")
df_p.createOrReplaceTempView('lr_invalid_filtered_p')
print("lr_invalid_filtered_p count:", df_p.count())
df_p.write.mode("overwrite").parquet(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/scratch/lr_invalid_filtered_p/")

# Remove valid matching records lr_v3 from lr_in3 on ["permid", "payerid", "coverageid", "clientid"]
df_famc_p = lr_in3.join(lr_v3, on=["permid", "payerid", "coverageid", "clientid"], how="left_anti")
df_famc_p.createOrReplaceTempView('lr_invalid_filtered_famc_p')
print("lr_invalid_filtered_famc count:", df_famc_p.count())
df_famc_p.write.mode("overwrite").parquet(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/scratch/lr_famc_invalid_filtered_p/")

# COMMAND ----------

df_g = spark.read.parquet(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/scratch/lr_invalid_filtered_g/")
gmrnid_del=df_g.withColumn("person_id", concat(lit("G_"),col("gmrnid")))
gmrnid_del=gmrnid_del.drop("gmrnid")
gmrnid_del.write.mode('overwrite').parquet(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/deleted_records/lr_xref_gmrnid_transaction/")
#df_g.createOrReplaceTempView('df_g')
df_p = spark.read.parquet(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/scratch/lr_invalid_filtered_p/")
permid_del=df_p.withColumn("person_id", concat(lit("P_"),col("permid")))
permid_del=permid_del.drop("permid")
permid_del.write.mode('overwrite').parquet(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/deleted_records/lr_xref_permid_transaction/")
#df_p.createOrReplaceTempView('df_p')

df_famc_p = spark.read.parquet(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/scratch/lr_famc_invalid_filtered_p/")
famc_permid_del=df_famc_p.withColumn("person_id", concat(lit("P_"),col("permid")))
famc_permid_del=famc_permid_del.drop("permid")
famc_permid_del.write.mode('overwrite').parquet(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/deleted_records/lr_famc_xref_permid_transaction/")

# COMMAND ----------

# MAGIC %md
# MAGIC PERMID XREF

# COMMAND ----------

# DBTITLE 1,cleaned_ lr_ich_xref_permid
# to_be_del_tran_permid_rd=spark.read.parquet(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/deleted_records/lr_xref_permid_transaction/")
to_be_del_tran_permid_rd = spark.read.parquet(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/scratch/lr_invalid_filtered_p/")
cleaned_df=lr_xref_permid_transaction_df.join(to_be_del_tran_permid_rd,(lr_xref_permid_transaction_df.transactionkey==to_be_del_tran_permid_rd.transactionkey) & (lr_xref_permid_transaction_df.sourcekey==2), how='leftanti')#.count()
# cleaned_df.count()
cleaned_df.write.mode('overwrite').format('delta').save(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/cleaned_tables/lr_xref_permid_transaction/")

# COMMAND ----------

# MAGIC %md
# MAGIC GMRNID XREF

# COMMAND ----------

# DBTITLE 1,cleaned_ lr_ich_xref_gmrnid
# to_be_del_tran_gmrnid_rd=spark.read.parquet(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/deleted_records/lr_xref_gmrnid_transaction/")
to_be_del_tran_gmrnid_rd = spark.read.parquet(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/scratch/lr_invalid_filtered_g/")
cleaned_gmrn_df=lr_xref_gmrnid_transaction_df.join(to_be_del_tran_gmrnid_rd,(lr_xref_gmrnid_transaction_df.transactionkey==to_be_del_tran_gmrnid_rd.transactionkey) & (lr_xref_gmrnid_transaction_df.sourcekey==2), how='leftanti')#.count()
cleaned_gmrn_df.write.mode('overwrite').format('delta').save(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/cleaned_tables/lr_xref_gmrnid_transaction/")

# COMMAND ----------

# MAGIC %md
# MAGIC FAMC XREF

# COMMAND ----------

# to_be_del_tran_permid_rd=spark.read.parquet(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/deleted_records/famc_lr_xref_permid_transaction/")
to_be_del_tran_famc_permid_rd = spark.read.parquet(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/scratch/lr_famc_invalid_filtered_p/")
cleaned_famc_df=famc_lr_xref_permid_transaction_df.join(to_be_del_tran_famc_permid_rd,(famc_lr_xref_permid_transaction_df.transactionkey==to_be_del_tran_famc_permid_rd.transactionkey) & (famc_lr_xref_permid_transaction_df.sourcekey==2), how='leftanti')#.count()
# cleaned_df.count()
cleaned_famc_df.write.mode('overwrite').format('delta').save(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/cleaned_tables/famc_lr_xref_permid_transaction/")

# COMMAND ----------

# DBTITLE 1,Read all del records from gmrnid and permid
all_del=spark.read.parquet(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/deleted_records/*/*")
#all_del.dropDuplicates().count()#140802595
# all_del.select("transactionkey").distinct().count()
#creating a new column to match with _id in lsb
all_del1=all_del.withColumn("all_del_id",concat(col('person_id'),lit('_'),col("payerid"),lit('_'),col("coverageid")))#556920016

# COMMAND ----------

# DBTITLE 1,Read Leadservicebase
lsb = spark.read.format("delta").load(f"{baseurl}/data/leadservicebase/publish/served/leadservicebase/")
lsb_ex = lsb.select("*",explode("demographics")).drop("demographics")
lsb_ex = lsb_ex.filter("_id not like '%dummy%'").drop("hcsystemfk_source") #.filter(col("key").contains('ich'))

# COMMAND ----------

# DBTITLE 1,Delete all bad records from lsb
jn_del_lsb = lsb_ex.join(
    all_del1,
    (all_del1.clientid == split(lsb_ex.key,'_')[0]) & 
    (all_del1.all_del_id == lsb_ex._id),
    "leftanti"
)
jn_del_lsb.count()#

# COMMAND ----------

# DBTITLE 1,Get all the unique ID's which got deleted
removed_ids = lsb_ex.join(
    all_del1,
    (all_del1.clientid == split(lsb_ex.key,'_')[0]) & 
    (all_del1.all_del_id == lsb_ex._id),
    "inner"
)
jn_del_lsb.createOrReplaceTempView("jn_del_lsb_tbl")
#removed_ids.select('_id').distinct().count()#155542531
removed_ids=removed_ids.select('_id').distinct()
removed_ids.createOrReplaceTempView("removed_ids_tbl")

# COMMAND ----------

# DBTITLE 1,GET MAX leadupdate date for all records
max_leadupdatedate_df = spark.sql("""
  SELECT
    _id,
    MAX(value.updatedate) AS max_leadupdatedate
  FROM
    jn_del_lsb_tbl
  GROUP BY
    _id
""")
max_leadupdatedate_df.createOrReplaceTempView("max_leadupdatedate_tbl")
# max_leadupdatedate_df.filter("_id='P_00A8C10185E9_101_XYU992410735'").display()

# COMMAND ----------

# DBTITLE 1,Update the lsbupdatedate for the ID's which were modified
updated_df=spark.sql(""" Select d._id,
                                d.identity,
                                d.leadcreatedate,
                                d.leadid,
                                m.max_leadupdatedate AS leadupdatedate,
                                d.lsbcreatedate,
                                CASE WHEN r._id is not null then current_timestamp() ELSE d.lsbupdatedate END as lsbupdatedate,
                                d.key,
                                d.value 
                        From jn_del_lsb_tbl d
                        LEFT JOIN removed_ids_tbl r
                              ON d._id= r._id
                        LEFT JOIN max_leadupdatedate_tbl m
                              ON d._id = m._id
                                """)

updated_df.count()                                

# COMMAND ----------

# DBTITLE 1,Rollback lsb
updated_df.createOrReplaceTempView("lsb_demo2")
lsb3_sql = """ 
            SELECT
                _id,
                concat_ws("|", collect_list(key)) as hcsystemfk_source,
                identity,
                leadcreatedate,
                leadid,
                leadupdatedate,
                lsbcreatedate,
                lsbupdatedate,
                sort_array(collect_list(struct(key, value))) as demographics_list,
                ROW_NUMBER() OVER (PARTITION BY _id ORDER BY leadupdatedate DESC) AS RNK
            FROM lsb_demo2 
            GROUP BY _id, identity, leadcreatedate, leadid, leadupdatedate, lsbcreatedate, lsbupdatedate
            """
lsb3 = spark.sql(lsb3_sql).filter("RNK == 1").drop("RNK")

# COMMAND ----------

# DBTITLE 1,convert to mapped format for demographics column
lsb4 = lsb3.withColumn("demographics", map_from_entries("demographics_list")).drop("demographics_list")
# lsb4.count()#

# COMMAND ----------

# DBTITLE 1,write the final cleaned lsb
lsb4.write.format("delta").mode("overwrite").save(f"{baseurl}/data/ich_response_codes/adhoc/{bc}/cleaned_tables/leadservicebase/")
