# Databricks notebook source
# MAGIC %md
# MAGIC # #RUN hipaa_issue_fc_bcbs_leads_cleanup_impact_final to Read hit impact leads 

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window


# COMMAND ----------

dbutils.widgets.text("user", "")
dbutils.widgets.getArgument("user")
user = getArgument("user")

dbutils.widgets.text("container", "")
dbutils.widgets.getArgument("container")
container = getArgument("container")

dbutils.widgets.text("storageaccount", "")
dbutils.widgets.getArgument("storageaccount")
storageaccount = getArgument("storageaccount")



# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

print(baseurl)


# COMMAND ----------

# DBTITLE 1,Invalid-valid lrlr_xref counts
df_g = spark.read.parquet(baseurl + "/abdul/hfc_hipaa_issue/hfc_lr_invalid_filtered_g_hfc/")
df_g.createOrReplaceTempView('df_g')

print("lr_invalid_filtered_g count:", df_g.count())

# COMMAND ----------

# DBTITLE 1,Remove Hit impact leads
#RUN hipaa_issue_fc_bcbs_leads_cleanup_impact_final to Read hit impact leads 
hit_ids = spark.read.parquet(baseurl + "/abdul/hfc_hipaa_issue/lsb_coverageid_policyid_match_hfc/").dropDuplicates()

# Filter hit_ids for each id type
hit_ids_g = hit_ids.filter(col("lsb_id_type") == "G")

df_g_filtered = df_g.join(
    hit_ids_g, 
    (df_g.gmrnid == hit_ids_g.lsb_identity) & 
    (df_g.payerid == hit_ids_g.lsb_edipartner) & 
    (df_g.coverageid == hit_ids_g.lsb_coverageid), 
    "left_anti"
)
df_g_filtered.createOrReplaceTempView('df_g_filtered')
print("df_g_filtered count:", df_g_filtered.count())


# COMMAND ----------

# DBTITLE 1,Rewrite lr_xref
hfc_lr_xref_g = spark.read.format('delta').load(baseurl + "/data/leadrepo/publish/cooked/hfc_lr_xref_gmrnid_transaction/")
hfc_lr_xref_g.createOrReplaceTempView('hfc_lr_xref_g')

hfc_lr_xref_g_new = hfc_lr_xref_g.join(df_g_filtered.select("gmrnid", "transactionkey"), on=["gmrnid", "transactionkey"], how="left_anti")

# Order columns as source
hfc_lr_xref_g_new = hfc_lr_xref_g_new.select(hfc_lr_xref_g.columns)

print("hfc_lr_xref_g fc count:" + str(hfc_lr_xref_g.count()))
print("hfc_lr_xref_g_new fc count:" + str(hfc_lr_xref_g_new.count()))

hfc_lr_xref_g_new.write.mode("overwrite").format("delta").save(baseurl + "/abdul/data/leadrepo/publish/cooked/hfc_lr_xref_gmrnid_transaction_new/")


# COMMAND ----------

# DBTITLE 1,Read LSB
lsb = spark.read.format("delta").load(baseurl + "/data/leadservicebase/publish/served/leadservicebase/")
lsb_hfc = lsb.filter(col("hcsystemfk_source").contains('_hfc'))#303,552,807

lsb_hfc_ex = lsb_hfc.select("*",explode_outer("demographics")).drop("demographics").drop("hcsystemfk_source")
lsb_hfc_ex_1 = lsb_hfc_ex.withColumnRenamed("key", "hcsystemfk_source")
lsb_hfc_ex_2 = lsb_hfc_ex_1.filter(split(col("hcsystemfk_source"), '_')[1] =='hfc')

lsb_hfc_ex_3 = lsb_hfc_ex_2.withColumn("lsb_hospitalfk", col("value").hospitalfk)
lsb_hospital_split_df = lsb_hfc_ex_3.withColumn("lsb_hospitalfk", split("lsb_hospitalfk", "\\|"))
lsb_hospital_ex_df = lsb_hospital_split_df.withColumn("lsb_hospitalfk", explode("lsb_hospitalfk"))
lsb_hospital_ex_df.createOrReplaceTempView('lsb_hospital_ex_df')

print("LSB Total count:" + str(lsb.count()))
print("LSB HFC count:" + str(lsb_hfc.count()))

print("LSB HFC demo explode count:" + str(lsb_hfc_ex.count()))
print("LSB ONLY HFC demo explode count:" + str(lsb_hfc_ex_2.count()))
print("LSB ONLY HFC hosp explode count:" + str(lsb_hospital_ex_df.count()))


# COMMAND ----------

# DBTITLE 1,JOIN LR LR_XREF LSB
#gmrn_xref
p1=spark.sql("""select g.*
             from lsb_hospital_ex_df g
             LEFT ANTI JOIN df_g_filtered dg ON g.identity = concat('G_',dg.gmrnid) and g.leadid = concat(dg.payerid,'_',dg.coverageid) and g.lsb_hospitalfk = dg.clientid
             """)
p1.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/hfc_hipaa_issue/lsb_covid_recs_source_gmrn_xref_invalid_filtered_hfc1")


# COMMAND ----------

# DBTITLE 1,valid BCBS LSB data
lb1 = spark.read.parquet(baseurl + "/abdul/hfc_hipaa_issue/lsb_covid_recs_source_gmrn_xref_invalid_filtered_hfc1").dropDuplicates()
lb1.createOrReplaceTempView('lb1')
print("lb1 count:", lb1.count())


# COMMAND ----------

# DBTITLE 1,all valid FC leads & update hospitalfk
from pyspark.sql.window import Window
from pyspark.sql.functions import concat_ws, collect_list, row_number

#Read all BCBS FC valid data
all_id_valid_leads = spark.read.parquet(baseurl + "/abdul/hfc_hipaa_issue/lsb_covid_recs_source_gmrn_xref_invalid_filtered_hfc1/").dropDuplicates()#

window_spec = Window.partitionBy("_id", "hcsystemfk_source").orderBy("lsbupdatedate")
all_id_valid_leads = all_id_valid_leads.withColumn("hospitalfk_conc", concat_ws("|", collect_list("lsb_hospitalfk").over(window_spec))).drop("lsb_hospitalfk")
all_id_valid_leads = all_id_valid_leads.withColumn("rn", row_number().over(window_spec)).filter("rn = 1").drop("rn")

all_id_valid_leads_updated = all_id_valid_leads.withColumn("value", col("value").withField("hospitalfk", col("hospitalfk_conc"))).drop("hospitalfk_conc")
all_id_valid_leads_updated.count()

# COMMAND ----------

#  LOGIC TO ROLLUP AND LOAD TO LSB

# COMMAND ----------

# DBTITLE 1,Read Leadservicebase
lsb = spark.read.format("delta").load(baseurl + "/data/leadservicebase/publish/served/leadservicebase/")
lsb_hfc = lsb.filter(col("hcsystemfk_source").contains('_hfc'))#303,552,807
lsb_nhfc = lsb.filter(~col("hcsystemfk_source").contains('_hfc'))

lsb_hfc_ex = lsb_hfc.select("*",explode_outer("demographics")).drop("demographics").drop("hcsystemfk_source")
lsb_hfc_ex_1 = lsb_hfc_ex.withColumnRenamed("key", "hcsystemfk_source")
lsb_hfc_ex_2 = lsb_hfc_ex_1.filter(split(col("hcsystemfk_source"), '_')[1] =='hfc')
lsb_nhfc_ex_2 = lsb_hfc_ex_1.filter(split(col("hcsystemfk_source"), '_')[1] !='hfc')

lsb_hfc_ex_3 = lsb_hfc_ex_2.withColumn("lsb_hospitalfk", col("value").hospitalfk)
lsb_hospital_split_df = lsb_hfc_ex_3.withColumn("lsb_hospitalfk", split("lsb_hospitalfk", "\\|"))
lsb_hospital_ex_df = lsb_hospital_split_df.withColumn("lsb_hospitalfk", explode("lsb_hospitalfk"))
lsb_hospital_ex_df.createOrReplaceTempView('lsb_hospital_ex_df')

print("LSB Total count:" + str(lsb.count()))
print("LSB HFC count:" + str(lsb_hfc.count()))
print("LSB NON HFC count:" + str(lsb_nhfc.count()))

print("LSB HFC demo explode count:" + str(lsb_hfc_ex.count()))
print("LSB ONLY HFC demo explode count:" + str(lsb_hfc_ex_2.count()))
print("LSB ONLY NON HFC demo explode count:" + str(lsb_nhfc_ex_2.count()))
print("LSB ONLY HFC hosp explode count:" + str(lsb_hospital_ex_df.count()))



# COMMAND ----------

# DBTITLE 1,replace fresh exploded HFC leads
new_lsb_hfc_ex = lsb_nhfc_ex_2.union(all_id_valid_leads_updated) 

print("new_lsb LSB HFC explode count: " + str(new_lsb_hfc_ex.count()))

# COMMAND ----------

# DBTITLE 1,Remove duplicate demographics per _id+hcsystem_source
new_lsb_hfc_ex.createOrReplaceTempView("new_lsb_hfc_ex")
query_stmt = """ SELECT
                _id,
                sort_array(collect_list(hcsystemfk_source) over (PARTITION BY _id)) as hcsystemfk_source_concat,
                identity,
                min(leadcreatedate) over (PARTITION BY _id) as leadcreatedate,
                leadid,
                max(leadupdatedate) over (PARTITION BY _id) as leadupdatedate,
                min(lsbcreatedate) over (PARTITION BY _id) as lsbcreatedate,
                max(lsbupdatedate) over (PARTITION BY _id) as lsbupdatedate,
                sort_array(collect_list(struct(hcsystemfk_source, value)) over (PARTITION BY _id)) as demographics_list, 
                ROW_NUMBER() OVER (PARTITION BY _id ORDER BY leadupdatedate DESC) AS RNK
            FROM new_lsb_hfc_ex
            """
new_lsb_hfc = spark.sql(query_stmt).filter("RNK == 1").drop("RNK")

print("new_lsb LSB HFC count: " + str(new_lsb_hfc.count()))


# COMMAND ----------

# DBTITLE 1,Transform to LSB format
new_lsb_hfc1 = new_lsb_hfc.withColumn('hcsystemfk_source', array_join('hcsystemfk_source_concat' , '|')).drop("hcsystemfk_source_concat")
new_lsb_hfc2 = new_lsb_hfc1.withColumn("demographics", map_from_entries("demographics_list")).drop("demographics_list")
new_lsb_hfc2 = new_lsb_hfc2.select('_id', 'hcsystemfk_source', 'identity', 'leadcreatedate', 'leadid', 'leadupdatedate', 'lsbcreatedate', 'lsbupdatedate', 'demographics')

new_lsb = lsb_nhfc.union(new_lsb_hfc2)#

print("new_lsb LSB count: " + str(new_lsb.count()))

new_lsb.write.mode("overwrite").format("delta").save(baseurl + "/abdul/data/leadservicebase/staging/leadservicebase_new/")
