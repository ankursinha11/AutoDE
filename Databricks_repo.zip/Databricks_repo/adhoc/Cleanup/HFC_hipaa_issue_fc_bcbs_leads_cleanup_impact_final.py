# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window


# COMMAND ----------

dbutils.widgets.text("user", "")
dbutils.widgets.getArgument("user")
user = getArgument("user")

dbutils.widgets.text("container", "")
dbutils.widgets.getArgument("container")
container = getArgument("container")

dbutils.widgets.text("storageaccount", "")
dbutils.widgets.getArgument("storageaccount")
storageaccount = getArgument("storageaccount")



# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

print(baseurl)


# COMMAND ----------

# DBTITLE 1,Read HFC LR JOIN HFC FC
hfc_lr_cols = ['transactionkey','sourcepatientacctifk' ,'clientid', 'lr_createdate', 'verifiedsource', 'responsestatus','payerid','coverageid']
hfc_lr = spark.read.format("parquet").load(baseurl + "/data/leadrepo/publish/cooked/hfc_lr_transaction/").select(hfc_lr_cols)
helperfoundcoverages = spark.read.format("delta").load(baseurl + "/data/dataingestion/publish/helperfoundcoverages/current/20991231/")
foundcoverage = spark.read.format("delta").load(baseurl + "/data/dataingestion/publish/foundcoverage/current/20991231/")

hfc_lr.createOrReplaceTempView("hfc_lr")
helperfoundcoverages.createOrReplaceTempView("helperfoundcoverages")
foundcoverage.createOrReplaceTempView("foundcoverage")

hfc_lr_joined = spark.sql("""
    SELECT lr.*, fc.patientacctifk, fc.hospitalfk, fc.edipartnerfk, fc.coverageid as fc_coverageid
    FROM hfc_lr lr
    INNER JOIN helperfoundcoverages hfc ON lr.transactionkey = hfc.helperfoundcoverageipk
    INNER JOIN foundcoverage fc ON hfc.sourcefoundcoverageifk = fc.foundcoverageipk
""")
# hfc_lr_joined.limit(1000).display()#1761614963 1,056,279,868
print("HFC lr total count:" + str(hfc_lr.count()))#
print("HFC lr FC total count:" + str(hfc_lr_joined.count()))#
hfc_lr_joined.write.mode("overwrite").parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/abdul/hfc_hipaa_issue/hfc_leads_fc_source/")

# COMMAND ----------

hfc_fc_source = spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/abdul/hfc_hipaa_issue/hfc_leads_fc_source/")
hfc_fc_source.createOrReplaceTempView("hfc_fc_source")
hfc_non_fc_source = spark.sql("""
    SELECT *
    FROM hfc_lr lr
    LEFT ANTI JOIN hfc_fc_source hfc ON lr.transactionkey = hfc.transactionkey
""")    
hfc_non_fc_source.write.mode("overwrite").parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/abdul/hfc_hipaa_issue/hfc_leads_non_fc_source/")

# COMMAND ----------

# DBTITLE 1,Bring responsestatus
hosp = spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/dataingestion/publish/hospitals/current/20991231/")
eq = spark.read.format('delta').load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/dataingestion/publish/ediqueries/current/20991231/").select("hospitalfk", "edipartnerfk","EDIQueryPK","patientacctifk","trn","EDI270QueryComboIFK","createdate" )
eqhm = spark.read.format('delta').load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/dataingestion/publish/ediqueryhitsandmisses/current/20991231/").select("EDIQueryFK","EDI270QueryComboIFK","createdate","policyid", "result")

hosp.createOrReplaceTempView('hosp')
eq.createOrReplaceTempView('eq')
eqhm.createOrReplaceTempView('eqhm')

hfc_fc_source.createOrReplaceTempView('hfc_fc')#
res = spark.sql("""
        SELECT h.*, hm.result
        FROM hfc_fc h
        JOIN eq eq ON h.hospitalfk= eq.hospitalfk AND h.EDIPartnerFK = eq.EDIPartnerFK and h.patientacctifk = eq.patientacctifk
        JOIN eqhm hm ON eq.EDIQueryPK = hm.EDIQueryFK and eq.EDI270QueryComboIFK = hm.EDI270QueryComboIFK and h.coverageid = hm.policyid
        JOIN hosp hp ON hp.HospitalPK = eq.HospitalFK
""").dropDuplicates()
res.write.mode("overwrite").parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/abdul/hfc_hipaa_issue/hfc_leads_responsestatus/")

# COMMAND ----------

r_cols = ['transactionkey','result']
hfc_lr_rs = spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/abdul/hfc_hipaa_issue/hfc_leads_responsestatus/").select(r_cols).dropDuplicates()#1194588408

hfc_lr_rs_joined = hfc_lr.join(hfc_lr_rs, on="transactionkey", how="left").withColumn("responsestatus", hfc_lr_rs.result).drop("result")

hfc_lr_rs_joined.count()#2401565836

# COMMAND ----------

lr_valid = hfc_lr_rs_joined.where(
                    hfc_lr_rs_joined.responsestatus.like('%EB:1%') | 
                    hfc_lr_rs_joined.responsestatus.like('%EB:2%') | 
                    hfc_lr_rs_joined.responsestatus.like('%EB:3%') | 
                    hfc_lr_rs_joined.responsestatus.like('%EB:4%') | 
                    hfc_lr_rs_joined.responsestatus.like('%EB:5%') |
                    hfc_lr_rs_joined.responsestatus.like('%EB:6%') 
                    )
lr_valid = lr_valid.filter(~((col("payerid") == '101') & (lr_valid.responsestatus.like('%EB:6%'))))
print("hfc lr fc valid count:" + str(lr_valid.count()))
lr_non_fc = spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/abdul/hfc_hipaa_issue/hfc_leads_non_fc_source/")
lr_valid = lr_valid.union(lr_non_fc)
lr_valid.createOrReplaceTempView('lr_valid')
lr_invalid = hfc_lr_rs_joined.exceptAll(lr_valid)
lr_invalid = lr_invalid.join(hfc_fc_source.select("transactionkey").dropDuplicates(), on="transactionkey", how="inner")
lr_invalid.createOrReplaceTempView('lr_invalid')

hfc_lr_xref_g = spark.read.format('delta').load(baseurl + "/data/leadrepo/publish/cooked/hfc_lr_xref_gmrnid_transaction/")
hfc_lr_xref_g.createOrReplaceTempView('hfc_lr_xref_g')

print("hfc lr valid count:" + str(lr_valid.count()))
print("hfc lr non fc count:" + str(lr_non_fc.count()))
print("hfc lr fc invalid count:" + str(lr_invalid.count()))
print("hfc_lr_xref_g count:" + str(hfc_lr_xref_g.count()))

# COMMAND ----------

# DBTITLE 1,Valid LR X LR_XREF
lr1 = spark.sql("""select r.*, lg.gmrnid
             from hfc_lr_xref_g lg
             JOIN lr_valid r ON r.transactionkey = lg.transactionkey
             """)
lr1.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/hfc_hipaa_issue/hfc_gmrn_lr_lrxref_valid_hfc/")

# COMMAND ----------

# DBTITLE 1,valid lr lr_xref counts
lr_v1 = spark.read.parquet(baseurl + "/abdul/hfc_hipaa_issue/hfc_gmrn_lr_lrxref_valid_hfc")#
lr_v1.createOrReplaceTempView('lrv1')

print(lr_v1.count())


# COMMAND ----------

# DBTITLE 1,INVALID LR x LR_XREF
lr1 = spark.sql("""select r.*, lg.gmrnid
             from hfc_lr_xref_g lg
             JOIN lr_invalid r ON r.transactionkey = lg.transactionkey
             """)
lr1.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/hfc_hipaa_issue/hfc_gmrn_lr_lrxref_invalid_hfc")


# COMMAND ----------

# DBTITLE 1,invalid lr X lr_xref counts
lr_in1 = spark.read.parquet(baseurl + "/abdul/hfc_hipaa_issue/hfc_gmrn_lr_lrxref_invalid_hfc")#
lr_in1.createOrReplaceTempView('lri1')

print(lr_in1.count())

# COMMAND ----------

# DBTITLE 1,Invalid - valid ones
# Remove valid matching records lr_v1 from lr_in1 on ["gmrnid", "payerid", "coverageid", "clientid"]
df_g = lr_in1.join(lr_v1, on=["gmrnid", "payerid", "coverageid", "clientid"], how="left_anti")
df_g.write.mode("overwrite").parquet(baseurl + "/abdul/hfc_hipaa_issue/hfc_lr_invalid_filtered_g_hfc/")



# COMMAND ----------

# DBTITLE 1,Invalid-valid counts
df_g = spark.read.parquet(baseurl + "/abdul/hfc_hipaa_issue/hfc_lr_invalid_filtered_g_hfc/")
df_g.createOrReplaceTempView('df_g')

print("lr_invalid_filtered_g count:", df_g.count())

# df_g.select("gmrnid", "transactionkey", "sourcekey", "payerid", "coverageid", "clientid").dropDuplicates().count()#347035878

# COMMAND ----------

# DBTITLE 1,Read LSB
lsb = spark.read.format("delta").load(baseurl + "/data/leadservicebase/publish/served/leadservicebase/")
lsb_hfc = lsb.filter(col("hcsystemfk_source").contains('_hfc'))#303,552,807

lsb_hfc_ex = lsb_hfc.select("*",explode_outer("demographics")).drop("demographics").drop("hcsystemfk_source")
lsb_hfc_ex_1 = lsb_hfc_ex.withColumnRenamed("key", "hcsystemfk_source")
lsb_hfc_ex_2 = lsb_hfc_ex_1.filter(split(col("hcsystemfk_source"), '_')[1] =='hfc')

lsb_hfc_ex_3 = lsb_hfc_ex_2.withColumn("lsb_hospitalfk", col("value").hospitalfk)
lsb_hospital_split_df = lsb_hfc_ex_3.withColumn("lsb_hospitalfk", split("lsb_hospitalfk", "\\|"))
lsb_hospital_ex_df = lsb_hospital_split_df.withColumn("lsb_hospitalfk", explode("lsb_hospitalfk"))
lsb_hospital_ex_df.createOrReplaceTempView('lsb_hospital_ex_df')

print("LSB Total count:" + str(lsb.count()))
print("LSB HFC count:" + str(lsb_hfc.count()))

print("LSB HFC demo explode count:" + str(lsb_hfc_ex.count()))
print("LSB ONLY HFC demo explode count:" + str(lsb_hfc_ex_2.count()))
print("LSB ONLY HFC hosp explode count:" + str(lsb_hospital_ex_df.count()))


# COMMAND ----------

# DBTITLE 1,LEFT ANTI JOIN on InValid LR LR_XREF to get VALID LSB
#gmrn_xref
p1=spark.sql("""select g.*
             from lsb_hospital_ex_df g
             LEFT ANTI JOIN df_g dg ON g.identity = concat('G_',dg.gmrnid) and g.leadid = concat(dg.payerid,'_',dg.coverageid) and g.lsb_hospitalfk = dg.clientid
             """)
p1.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/hfc_hipaa_issue/lsb_covid_recs_source_gmrn_xref_invalid_filtered_hfc/")


# COMMAND ----------

# DBTITLE 1,valid HFC LSB data
lb1 = spark.read.parquet(baseurl + "/abdul/hfc_hipaa_issue/lsb_covid_recs_source_gmrn_xref_invalid_filtered_hfc").dropDuplicates()
lb1.createOrReplaceTempView('lb1')
print("lb1 count:", lb1.count())

# COMMAND ----------

# MAGIC %md
# MAGIC # ## ###################IMPACT ANALYSIS HITS############################
# MAGIC # 

# COMMAND ----------

# DBTITLE 1,JOIN LR LR_XREF LSB DELETED
#gmrn_xref
p1=spark.sql("""select g.*
             from lsb_hospital_ex_df g
             JOIN df_g dg ON g.identity = concat('G_',dg.gmrnid) and g.leadid = concat(dg.payerid,'_',dg.coverageid) and g.lsb_hospitalfk = dg.clientid
             """)
p1.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/hfc_hipaa_issue/lsb_covid_recs_source_gmrn_deleted_hfc/")

# COMMAND ----------

# DBTITLE 1,Going to be deleted
d1 = spark.read.parquet(baseurl + "/abdul/hfc_hipaa_issue/lsb_covid_recs_source_gmrn_deleted_hfc/").dropDuplicates()
d1.createOrReplaceTempView('d1')
print("d1 count:", d1.count())
print("Uniq covids to be deleted :", d1.select("leadid").dropDuplicates().count())



# COMMAND ----------

# DBTITLE 1,Remove any ids match with non deleted leads
dl1 = d1.join(lb1, ['_id'], 'leftanti').select("_id")

dl1.write.mode("overwrite").parquet(baseurl + "/abdul/hfc_hipaa_issue/lsb_covid_recs_source_gmrn_impact_hfc/")

print("dl1 count:", dl1.count())

# COMMAND ----------

# DBTITLE 1,deletes impact
hosp = spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/dataingestion/publish/hospitals/current/20991231/").filter("active = 1")
eq = spark.read.format('delta').load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/dataingestion/publish/ediqueries/current/20991231/").select("hospitalfk", "edipartnerfk","EDIQueryPK","patientacctifk","trn","EDI270QueryComboIFK","createdate" )
eqhm = spark.read.format('delta').load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/dataingestion/publish/ediqueryhitsandmisses/current/20991231/").select("EDIQueryFK","EDI270QueryComboIFK","createdate","policyid").filter("result in ('EB:1','EB:2','EB:3','EB:4','EB:5')")
egsd = spark.read.format('delta').load("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/data/dataingestion/publish/ediglobalsourceddata/current/20991231/").select("hospitalfk", "edidatasourcefk","trn","EDIPartnerFK","patientacctifk","EDISourceTableKey" )

hosp.createOrReplaceTempView('hosp')
eq.createOrReplaceTempView('eq')
eqhm.createOrReplaceTempView('eqhm')
egsd.createOrReplaceTempView('egsd')

deletes = spark.read.parquet(baseurl + "/abdul/hfc_hipaa_issue/*_impact_hfc/")
deletes.createOrReplaceTempView('deletes')#399,504,693

res = spark.sql("""
        SELECT lb.*,hm.createdate as hm_createdate,eq.createdate as eq_createdate,hm.policyid
        FROM deletes lb
        JOIN egsd eg ON lb._id = eg.EDISourceTableKey
        JOIN eq eq ON eg.hospitalfk=eq.hospitalfk AND eg.trn = eq.trn and eq.EDIPartnerFK = eg.EDIPartnerFK and eq.patientacctifk = eg.patientacctifk
        JOIN eqhm hm ON eq.EDIQueryPK = hm.EDIQueryFK and eq.EDI270QueryComboIFK = hm.EDI270QueryComboIFK 
        JOIN hosp h ON h.HospitalPK = eq.HospitalFK
""").dropDuplicates()
res.write.mode("overwrite").parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/abdul/hfc_hipaa_issue/hitstatus_leads20251021_activeH_hfc/")

# COMMAND ----------

from pyspark.sql.functions import when, split, col
hs = spark.read.parquet("abfss://prod-icd-adls@prodicddls.dfs.core.windows.net/abdul/hfc_hipaa_issue/hitstatus_leads20251021_activeH_hfc/")

hs1 = hs.withColumn(
    "lsb_edipartner", when(col("_id").startswith("G"), split(col("_id"), "_")[2])
).withColumn(
    "lsb_coverageid", when(col("_id").startswith("G"), split(col("_id"), "_")[3])
).withColumn(
    "lsb_identity", when(col("_id").startswith("G"), split(col("_id"), "_")[1])
).withColumn(
    "lsb_id_type", when(col("_id").startswith("G"), split(col("_id"), "_")[0])
)

print("EB hits: " +str(hs.count()))
hs1.select("lsb_edipartner","lsb_coverageid").dropDuplicates().count()#

# COMMAND ----------

hs1.filter("policyid = lsb_coverageid").count()

# COMMAND ----------

# DBTITLE 1,write hits to file
hs2 = hs1.filter("policyid = lsb_coverageid").select(
    "lsb_edipartner",
    "lsb_coverageid",
    "lsb_identity",
    "lsb_id_type"
).dropDuplicates()
hs2.write.mode("overwrite").parquet(baseurl + "/abdul/hfc_hipaa_issue/lsb_coverageid_policyid_match_hfc/")

# COMMAND ----------

hh = spark.read.parquet(baseurl + "/abdul/hfc_hipaa_issue/lsb_coverageid_policyid_match_hfc/")
# hh.count()


# COMMAND ----------

# MAGIC %md
# MAGIC ###################END of IMPACT ANALYSIS
# MAGIC
