# Databricks notebook source
# MAGIC %md
# MAGIC # #RUN famc_hipaa_issue_fc_bcbs_leads_cleanup_impact_final to Read hit impact leads 

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window


# COMMAND ----------

dbutils.widgets.text("user", "")
dbutils.widgets.getArgument("user")
user = getArgument("user")

dbutils.widgets.text("container", "")
dbutils.widgets.getArgument("container")
container = getArgument("container")

dbutils.widgets.text("storageaccount", "")
dbutils.widgets.getArgument("storageaccount")
storageaccount = getArgument("storageaccount")

# COMMAND ----------

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

print(baseurl)


# COMMAND ----------

# DBTITLE 1,Invalid-valid lrlr_xref counts
df_p = spark.read.parquet(baseurl + "/abdul/famc_hipaa_issue/famc_lr_invalid_filtered_p_famc/")
df_p.createOrReplaceTempView('df_p')

print("lr_invalid_filtered_p count:", df_p.count())

# COMMAND ----------

# DBTITLE 1,Remove Hit impact leads
#RUN hipaa_issue_fc_bcbs_leads_cleanup_impact_final to Read hit impact leads 
hit_ids = spark.read.parquet(baseurl + "/abdul/famc_hipaa_issue/lsb_coverageid_policyid_match_famc/").dropDuplicates()

# Filter hit_ids for each id type
hit_ids_p = hit_ids.filter(col("lsb_id_type") == "P")

df_p_filtered = df_p.join(
    hit_ids_p, 
    (df_p.permid == hit_ids_p.lsb_identity) & 
    (df_p.payerid == hit_ids_p.lsb_edipartner) & 
    (df_p.coverageid == hit_ids_p.lsb_coverageid), 
    "left_anti"
)
df_p_filtered.createOrReplaceTempView('df_p_filtered')
print("df_p_filtered count:", df_p_filtered.count())


# COMMAND ----------

# DBTITLE 1,Rewrite lr_xref
famc_lr_xref_p = spark.read.format('delta').load(baseurl + "/data/leadrepo/publish/cooked/famc_lr_xref_permid_transaction/")
famc_lr_xref_p.createOrReplaceTempView('famc_lr_xref_p')

famc_lr_xref_p_new = famc_lr_xref_p.join(df_p_filtered.select("permid", "transactionkey"), on=["permid", "transactionkey"], how="left_anti")

# Order columns as source
famc_lr_xref_p_new = famc_lr_xref_p_new.select(famc_lr_xref_p.columns)

print("famc_lr_xref_p fc count:" + str(famc_lr_xref_p.count()))
print("famc_lr_xref_p_new fc count:" + str(famc_lr_xref_p_new.count()))

famc_lr_xref_p_new.write.mode("overwrite").format("delta").save(baseurl + "/abdul/data/leadrepo/publish/cooked/famc_lr_xref_permid_transaction_new/")

# COMMAND ----------

# DBTITLE 1,Read LSB
lsb = spark.read.format("delta").load(baseurl + "/data/leadservicebase/publish/served/leadservicebase/")
lsb_famc = lsb.filter(col("hcsystemfk_source").contains('_fm'))#303,552,807

lsb_famc_ex = lsb_famc.select("*",explode_outer("demographics")).drop("demographics").drop("hcsystemfk_source")
lsb_famc_ex_1 = lsb_famc_ex.withColumnRenamed("key", "hcsystemfk_source")
lsb_famc_ex_2 = lsb_famc_ex_1.filter(split(col("hcsystemfk_source"), '_')[1] =='fm')

lsb_famc_ex_3 = lsb_famc_ex_2.withColumn("lsb_hospitalfk", col("value").hospitalfk)
lsb_hospital_split_df = lsb_famc_ex_3.withColumn("lsb_hospitalfk", split("lsb_hospitalfk", "\\|"))
lsb_hospital_ex_df = lsb_hospital_split_df.withColumn("lsb_hospitalfk", explode("lsb_hospitalfk"))
lsb_hospital_ex_df.createOrReplaceTempView('lsb_hospital_ex_df')

print("LSB Total count:" + str(lsb.count()))
print("LSB FAMC count:" + str(lsb_famc.count()))
print("LSB NON FAMC count:" + str(lsb_nfamc.count()))

print("LSB FAMC demo explode count:" + str(lsb_famc_ex.count()))
print("LSB ONLY FAMC demo explode count:" + str(lsb_famc_ex_2.count()))
print("LSB ONLY NON FAMC demo explode count:" + str(lsb_nfamc_ex_2.count()))
print("LSB ONLY FAMC hosp explode count:" + str(lsb_hospital_ex_df.count()))

# COMMAND ----------

# DBTITLE 1,JOIN LR LR_XREF LSB
#gmrn_xref
p1=spark.sql("""select p.*
             from lsb_hospital_ex_df p
             LEFT ANTI JOIN df_p_filtered dp ON p.identity = concat('P_',dp.permid) and p.leadid = concat(dp.payerid,'_',dp.coverageid) and p.lsb_hospitalfk = dp.clientid
             """)
p1.write.mode("overwrite").format("parquet").save(baseurl + "/abdul/famc_hipaa_issue/lsb_covid_recs_source_perm_xref_invalid_filtered_famc1")


# COMMAND ----------

# DBTITLE 1,valid BCBS LSB data
lb1 = spark.read.parquet(baseurl + "/abdul/famc_hipaa_issue/lsb_covid_recs_source_perm_xref_invalid_filtered_famc1").dropDuplicates()
lb1.createOrReplaceTempView('lb1')
print("lb1 count:", lb1.count())


# COMMAND ----------

# DBTITLE 1,all valid FC leads & update hospitalfk
from pyspark.sql.window import Window
from pyspark.sql.functions import concat_ws, collect_list, row_number

#Read all BCBS FC valid data
all_id_valid_leads = spark.read.parquet(baseurl + "/abdul/famc_hipaa_issue/lsb_covid_recs_source_perm_xref_invalid_filtered_famc1/").dropDuplicates()#

window_spec = Window.partitionBy("_id", "hcsystemfk_source").orderBy("lsbupdatedate")
all_id_valid_leads = all_id_valid_leads.withColumn("hospitalfk_conc", concat_ws("|", collect_list("lsb_hospitalfk").over(window_spec))).drop("lsb_hospitalfk")
all_id_valid_leads = all_id_valid_leads.withColumn("rn", row_number().over(window_spec)).filter("rn = 1").drop("rn")

all_id_valid_leads_updated = all_id_valid_leads.withColumn("value", col("value").withField("hospitalfk", col("hospitalfk_conc"))).drop("hospitalfk_conc")
all_id_valid_leads_updated.count()

# COMMAND ----------

#  LOGIC TO ROLLUP AND LOAD TO LSB

# COMMAND ----------

# DBTITLE 1,Read Leadservicebase
lsb = spark.read.format("delta").load(baseurl + "/data/leadservicebase/publish/served/leadservicebase/")
lsb_famc = lsb.filter(col("hcsystemfk_source").contains('_fm'))#303,552,807
lsb_nfamc = lsb.filter(~col("hcsystemfk_source").contains('_fm'))

lsb_famc_ex = lsb_famc.select("*",explode_outer("demographics")).drop("demographics").drop("hcsystemfk_source")
lsb_famc_ex_1 = lsb_famc_ex.withColumnRenamed("key", "hcsystemfk_source")
lsb_famc_ex_2 = lsb_famc_ex_1.filter(split(col("hcsystemfk_source"), '_')[1] =='fm')
lsb_nfamc_ex_2 = lsb_famc_ex_1.filter(split(col("hcsystemfk_source"), '_')[1] !='fm')

lsb_famc_ex_3 = lsb_famc_ex_2.withColumn("lsb_hospitalfk", col("value").hospitalfk)
lsb_hospital_split_df = lsb_famc_ex_3.withColumn("lsb_hospitalfk", split("lsb_hospitalfk", "\\|"))
lsb_hospital_ex_df = lsb_hospital_split_df.withColumn("lsb_hospitalfk", explode("lsb_hospitalfk"))
lsb_hospital_ex_df.createOrReplaceTempView('lsb_hospital_ex_df')

print("LSB Total count:" + str(lsb.count()))
print("LSB FAMC count:" + str(lsb_famc.count()))
print("LSB NON FAMC count:" + str(lsb_nfamc.count()))

print("LSB FAMC demo explode count:" + str(lsb_famc_ex.count()))
print("LSB ONLY FAMC demo explode count:" + str(lsb_famc_ex_2.count()))
print("LSB ONLY NON FAMC demo explode count:" + str(lsb_nfamc_ex_2.count()))
print("LSB ONLY FAMC hosp explode count:" + str(lsb_hospital_ex_df.count()))



# COMMAND ----------

# DBTITLE 1,replace fresh exploded HFC leads
new_lsb_famc_ex = lsb_nfamc_ex_2.union(all_id_valid_leads_updated) 

print("new_lsb LSB FAMC explode count: " + str(new_lsb_famc_ex.count()))

# COMMAND ----------

# DBTITLE 1,Remove duplicate demographics per _id+hcsystem_source
new_lsb_famc_ex.createOrReplaceTempView("new_lsb_famc_ex")
query_stmt = """ SELECT
                _id,
                sort_array(collect_list(hcsystemfk_source) over (PARTITION BY _id)) as hcsystemfk_source_concat,
                identity,
                min(leadcreatedate) over (PARTITION BY _id) as leadcreatedate,
                leadid,
                max(leadupdatedate) over (PARTITION BY _id) as leadupdatedate,
                min(lsbcreatedate) over (PARTITION BY _id) as lsbcreatedate,
                max(lsbupdatedate) over (PARTITION BY _id) as lsbupdatedate,
                sort_array(collect_list(struct(hcsystemfk_source, value)) over (PARTITION BY _id)) as demographics_list, 
                ROW_NUMBER() OVER (PARTITION BY _id ORDER BY leadupdatedate DESC) AS RNK
            FROM new_lsb_famc_ex
            """
new_lsb_famc = spark.sql(query_stmt).filter("RNK == 1").drop("RNK")

print("new_lsb LSB FAMC count: " + str(new_lsb_famc.count()))


# COMMAND ----------

# DBTITLE 1,Transform to LSB format
new_lsb_famc1 = new_lsb_famc.withColumn('hcsystemfk_source', array_join('hcsystemfk_source_concat' , '|')).drop("hcsystemfk_source_concat")
new_lsb_famc2 = new_lsb_famc1.withColumn("demographics", map_from_entries("demographics_list")).drop("demographics_list")
new_lsb_famc2 = new_lsb_famc2.select('_id', 'hcsystemfk_source', 'identity', 'leadcreatedate', 'leadid', 'leadupdatedate', 'lsbcreatedate', 'lsbupdatedate', 'demographics')

new_lsb = lsb_nfamc.union(new_lsb_famc2)#

print("new_lsb LSB count: " + str(new_lsb.count()))

new_lsb.write.mode("overwrite").format("delta").save(baseurl + "/abdul/data/leadservicebase/staging/leadservicebase_new_famc/")
