# Databricks notebook source
# DBTITLE 1,Input Parameters
dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("hdfs_mcaidhelper_sqoop_out","")
dbutils.widgets.getArgument("hdfs_mcaidhelper_sqoop_out")
hdfs_mcaidhelper_sqoop_out= getArgument("hdfs_mcaidhelper_sqoop_out")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("maxRecordsPerFile", "")
dbutils.widgets.getArgument("maxRecordsPerFile")
maxRecordsPerFile = getArgument("maxRecordsPerFile")

dbutils.widgets.text("workflow_name", "")
dbutils.widgets.getArgument("workflow_name")
workflow_name = getArgument("workflow_name")

dbutils.widgets.text("dataingestion_publish_path", "")
dbutils.widgets.getArgument("dataingestion_publish_path")
dataingestion_publish_path = getArgument("dataingestion_publish_path")


# COMMAND ----------

# DBTITLE 1,Storage Account access
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))
# setting the baseurl
if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user
print("baseurl: ", baseurl)


#setting the edi_payer_baseurl
edi_payer_baseurl ='abfss://edi-payer-leads@'+storageaccount+'.dfs.core.windows.net'

print("edi_payer_baseurl:", edi_payer_baseurl)

# COMMAND ----------

# DBTITLE 1,Imports
from pyspark.sql.functions import *
from pyspark.sql.types import *
import uuid

# COMMAND ----------

# DBTITLE 1,Common Util Functions
# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

# DBTITLE 1,Shard Config Data
# Read the config file to get the shards
config_path = baseurl + dataingestion_publish_path + "partnerxrefconfig/current/20991231/"
configcols = ["edipartnerfk", "databaseshardname"]

df_shard_config = extract_deltalake_data(spark,config_path, configcols)

#Output shards path
shard_dir = edi_payer_baseurl + "/shards_inprogress/"

# COMMAND ----------

# DBTITLE 1,Final Leads
mcaidhelper = spark.read.parquet(baseurl+hdfs_mcaidhelper_sqoop_out+bc +'/pa_final')
mcaidhelper = mcaidhelper.withColumn("uniqueid", concat_ws("_", mcaidhelper.hospitalfk, mcaidhelper.patientacctifk, expr("uuid()")))
mcaidhelper.createOrReplaceTempView('mcaidhelper')

# COMMAND ----------

# DBTITLE 1,Final Leads with output format
bc_value = bc

mcaidhelper = spark.sql(f'''
select 
uniqueid,
'{bc_value}' as bc,
patientacctifk,
hospitalfk, 
CAST(NULL AS VARCHAR(1)) AS hospitalname,
firstname, 
lastname,
middlename, 
dob,
ssn, 
gender, 
state,
admitdate, 
dischargedate, 
clusteredacctfk, 
CAST(NULL AS VARCHAR(1)) AS totalcharges,
CAST(NULL AS VARCHAR(1)) AS npi,
edipartnerfk as lsb_edipartnerfk,
CoverageID as lsb_coverageid,
CAST(NULL AS VARCHAR(1)) AS  lsb_leadsource,
CAST(NULL AS VARCHAR(1)) AS  lsb_xrefsource,
CAST(NULL AS VARCHAR(1)) AS  lsb_firstname,
CAST(NULL AS VARCHAR(1)) AS  lsb_middlename,
CAST(NULL AS VARCHAR(1)) AS  lsb_lastname,
CAST(NULL AS VARCHAR(1)) AS  lsb_gender,
CAST(NULL AS VARCHAR(1)) AS  lsb_dob,
CAST(NULL AS VARCHAR(1)) AS  lsb_ssn,
CAST(NULL AS VARCHAR(1)) AS  lsb_state,
CAST(NULL AS VARCHAR(1)) AS usefamilydataflag,
'54' as edidatasourcefk,
CAST(NULL AS VARCHAR(1)) AS edidatasourcetablekey, 
CAST(NULL AS VARCHAR(1)) AS associationsource,
medicarehic, 
CoverageID as medicaidnum
from mcaidhelper
''')

# COMMAND ----------

# DBTITLE 1,Final Leads join to Shard
join_df = mcaidhelper.join(df_shard_config, mcaidhelper.lsb_edipartnerfk == df_shard_config.edipartnerfk, "left").select(mcaidhelper["*"], df_shard_config["databaseshardname"])

join_df2 = join_df.withColumn("databaseshardname", coalesce(col("databaseshardname"), lit("default_shard")))\
                   .withColumn("workflow_name", lit(workflow_name))\
                  .withColumn("bc", lit(bc +"-MAH"))

# COMMAND ----------

join_df3 = join_df2.withColumn("patientacctifk", F.col("patientacctifk").cast(LongType()))\
	.withColumn("hospitalfk", F.col("hospitalfk").cast(IntegerType()))\
  .withColumn("dob", F.to_timestamp(F.col("dob")))\
	.withColumn("admitdate", F.col("admitdate").cast(TimestampType()))\
	.withColumn("dischargedate", F.col("dischargedate").cast(TimestampType()))\
	.withColumn("clusteredacctfk", F.col("clusteredacctfk").cast(IntegerType()))\
	.withColumn("totalcharges", F.col("totalcharges").cast(DecimalType(38,2)))\
	.withColumn("lsb_edipartnerfk", F.col("lsb_edipartnerfk").cast(IntegerType()))\
	.withColumn("lsb_dob", F.col("lsb_dob").cast(TimestampType()))\
	.withColumn("edidatasourcefk", F.col("edidatasourcefk").cast(IntegerType()))

# COMMAND ----------

# DBTITLE 1,Write to Shard Path
join_df3.coalesce(1)\
        .write.option("maxRecordsPerFile", maxRecordsPerFile)\
        .mode("overwrite")\
        .partitionBy("databaseshardname","workflow_name","bc")\
        .parquet(shard_dir)
