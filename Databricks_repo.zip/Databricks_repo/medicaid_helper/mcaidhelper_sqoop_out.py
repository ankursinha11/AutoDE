# Databricks notebook source
# DBTITLE 1,Input Parameters
dbutils.widgets.text("tablename","")
dbutils.widgets.getArgument("tablename")
tablename= getArgument("tablename")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("mcaidhelper_sqoop_out","")
dbutils.widgets.getArgument("mcaidhelper_sqoop_out")
mcaidhelper_sqoop_out= getArgument("mcaidhelper_sqoop_out")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

# COMMAND ----------

# DBTITLE 1,Storage account access
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

# DBTITLE 1,Imports
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# DBTITLE 1,Read Final leads
pa_sqoop = spark.read.parquet(baseurl+mcaidhelper_sqoop_out+bc +'/pa_final').drop("medicarehic")

# COMMAND ----------

# DBTITLE 1,Sqoop
path_conn_file = dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-transport-sql-insleads-cs")
pa_sqoop.write.format('jdbc').mode('append').option('driver', 'com.microsoft.sqlserver.jdbc.SQLServerDriver').option \
        ('url', path_conn_file).option('dbtable',tablename).save()
