# Databricks notebook source
# DBTITLE 1,Input Parameters
dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("dataingestion_path","")
dbutils.widgets.getArgument("dataingestion_path")
dataingestion_path= getArgument("dataingestion_path")

dbutils.widgets.text("minmaxbyedipartnerfk_path","")
dbutils.widgets.getArgument("minmaxbyedipartnerfk_path")
minmaxbyedipartnerfk_path= getArgument("minmaxbyedipartnerfk_path")

dbutils.widgets.text("minmaxbyhospital_path","")
dbutils.widgets.getArgument("minmaxbyhospital_path")
minmaxbyhospital_path= getArgument("minmaxbyhospital_path")

dbutils.widgets.text("scratch_path","")
dbutils.widgets.getArgument("scratch_path")
scratch_path= getArgument("scratch_path")

dbutils.widgets.text("medicaidhelper_path","")
dbutils.widgets.getArgument("medicaidhelper_path")
medicaidhelper_path= getArgument("medicaidhelper_path")

dbutils.widgets.text("patientacctxleads_path","")
dbutils.widgets.getArgument("patientacctxleads_path")
patientacctxleads_path= getArgument("patientacctxleads_path")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("num_of_days_pa","")
dbutils.widgets.getArgument("num_of_days_pa")
num_of_days_pa= getArgument("num_of_days_pa")

# COMMAND ----------

# DBTITLE 1,Storage account access
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na': #defualt value
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user
print("baseurl : "+baseurl)

# COMMAND ----------

# DBTITLE 1,common get_candidate_patientaccts
# MAGIC %run /Insleads-code/LeadDiscovery/common/get_candidate_patientaccts

# COMMAND ----------

# DBTITLE 1,common_util functions
# MAGIC %run /Insleads-code/Common-Util/common_util

# COMMAND ----------

# DBTITLE 1,common process_leads
# MAGIC %run /Insleads-code/LeadDiscovery/common/process_leads

# COMMAND ----------

# DBTITLE 1,Input and Output paths
dataingestion_path=baseurl+dataingestion_path
minmaxbyhospital_path=baseurl+minmaxbyhospital_path+ bc
minmaxbyedipartnerfk_path=baseurl+minmaxbyedipartnerfk_path+ bc
scratch_path=baseurl+scratch_path+bc
medicaidhelper_path=baseurl+medicaidhelper_path
patientacctxleads_path=baseurl+patientacctxleads_path
pa_path=dataingestion_path+"patientaccts/current/20991231/"
print("dataingestion_path : "+dataingestion_path)
print("minmaxbyhospital_path : "+minmaxbyhospital_path)
print("minmaxbyedipartnerfk_path : "+minmaxbyedipartnerfk_path)
print("patientacctxleads_path : "+patientacctxleads_path)
print("scratch_path:",scratch_path)
print("medicaidhelper_path:",medicaidhelper_path)
print("pa_path:",pa_path)

# COMMAND ----------

# DBTITLE 1,Imports
import datetime
from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

# DBTITLE 1,Input Data  Reads
hospitals = spark.read.parquet(dataingestion_path+"hospitals/current/20991231/*")
hospitalattributes=spark.read.parquet(dataingestion_path+"hospitalattributes/current/20991231/*")
hospitalattributevalues=spark.read.parquet(dataingestion_path+"hospitalattributevalues/current/20991231/*")
hospphysicians=spark.read.parquet(dataingestion_path+"hospphysicians/current/20991231/*")
patientacctscodes=spark.read.format('delta').load(dataingestion_path+"patientacctscodes/current/20991231/").select("patientacctifk","hospitalfk","AttendingPhynName").dropDuplicates()
clusteredaccts=spark.read.format('delta').load(dataingestion_path+"clusteredaccts/current/20991231/").select("clusteredacctpk","firstname","middlename","lastname","dob","ssn")
minmaxbyedipartnerfk=spark.read.parquet(minmaxbyedipartnerfk_path)
minmaxbyhospital=spark.read.parquet(minmaxbyhospital_path)

# COMMAND ----------

# DBTITLE 1,Read Patientaccts and filter on MedicaidNum
pa_cols=["patientacctipk", "hospitalfk", "firstname", "middlename", "lastname", "ssn", "dob", "gender",
               "state", "admitdate", "dischargedate", "clusteredacctfk", "totalcharges", "createdate", "updatedate",
               "demographicsupdatedate", "medicaidnum", "medicarehic" ,"trgupdatedate"]
allpatientaccts = extract_deltalake_data(spark,pa_path, pa_cols)              
pa = allpatientaccts.where(datediff(current_date(),allpatientaccts.trgupdatedate.cast(TimestampType())) <= int(num_of_days_pa) )
pa = pa.filter("medicaidnum is not null")
pa = getpatientacctswithadmitdt(spark,pa,minmaxbyhospital)

# COMMAND ----------

# DBTITLE 1,hpn list with enabled partners
hpn = spark.read.parquet(dataingestion_path + "hospitalprovidernums/current/20991231/")
hpn.createOrReplaceTempView("hpn")
hpn=spark.sql("""select hpn.* , Case
                              When activestate = 'L2' Then 'IL'
                              When activestate = 'L3' Then 'LA'
                              When activestate in('CL','CU') Then 'CA'
                              Else activestate End as activestate_updated
                              from hpn where enabled =1 """).drop("activestate")
hpn= hpn.withColumnRenamed("activestate_updated", "activestate")

# COMMAND ----------

# DBTITLE 1,Temp Views
hospitals.createOrReplaceTempView("hosp")
hpn.createOrReplaceTempView("hpn")
hospitalattributes.createOrReplaceTempView("ha")
hospitalattributevalues.createOrReplaceTempView("hav")
pa.createOrReplaceTempView("pa")
hospphysicians.createOrReplaceTempView("phy")
patientacctscodes.createOrReplaceTempView("pac")
clusteredaccts.createOrReplaceTempView("ca")
minmaxbyedipartnerfk.createOrReplaceTempView("minmaxbyedipartnerfk")

# COMMAND ----------

# DBTITLE 1,hpn list with medicaidpartners
hpn_mcaidpartners=spark.sql(""" Select hpn.* from hpn join minmaxbyedipartnerfk on hpn.HospitalfK = minmaxbyedipartnerfk.HospitalfK and hpn.edipartnerfk = minmaxbyedipartnerfk.edipartnerpk """)
hpn_mcaidpartners.createOrReplaceTempView("hpn_mcaidpartners")

# COMMAND ----------

# DBTITLE 1,Auditz Hospitals
hosp_auditz=spark.sql("""select  h.hospitalpk
            from hosp as h
            CROSS JOIN (SELECT ha.AttributeDefaultValue FROM ha WHERE HospitalAttributePK = 68 AND ActiveFlag = 1) a
            LEFT JOIN hav v ON h.HospitalPK = v.HospitalFK AND v.HospitalAttributeFK = 68
            WHERE COALESCE(v.HospitalAttributeValue,a.AttributeDefaultValue) = '1' AND h.active=1 """)
hosp_auditz.createOrReplaceTempView("hosp_auditz")

# COMMAND ----------

# DBTITLE 1,Hospitals with Auditz Flag
hosp_final=spark.sql("""select h.hospitalpk,h.UseDSHZeroCharge,h.state,
                     CASE when v.hospitalpk is null then 0 else 1 END as Auditzflag
            from hosp as h
            LEFT JOIN hosp_auditz v ON h.HospitalPK = v.hospitalpk
            Where h.active=1 """)
hosp_final.createOrReplaceTempView("hosp_final")

# COMMAND ----------

# DBTITLE 1,Total charges filter
pa_totalcharges= spark.sql(""" SELECT pa.*, hosp_final.Auditzflag,hosp_final.state as hospitalstate,
                         CASE when hosp_final.UseDSHZeroCharge='Y' Then 1
                         when hosp_final.UseDSHZeroCharge!='Y' and cast(totalcharges as decimal(32,4))>0 Then 1 
                         else 0 End as totalchargesflag
                         FROM  pa join hosp_final on pa.hospitalfk = hosp_final.hospitalpk  """ )
pa_totalcharges=pa_totalcharges.filter("totalchargesflag=1")
pa_totalcharges=pa_totalcharges.drop("totalchargesflag")
pa_totalcharges.createOrReplaceTempView("pa_totalcharges")

# COMMAND ----------

# DBTITLE 1,Assign Audit State
pa_auditstate=spark.sql("""SELECT pa_totalcharges.*, phy.PhysicianState as auditstate FROM pa_totalcharges
                                LEFT JOIN pac  ON pa_totalcharges.HospitalFK = pac.HospitalFK  AND pa_totalcharges.PatientAcctIPK = pac.PatientAcctIFK
                                LEFT JOIN  phy  ON pac.AttendingPhynName = phy.PhysicianName AND phy.HospitalFK = pac.HospitalFK""")#24435954
pa_auditstate.createOrReplaceTempView("pa_auditstate")

# COMMAND ----------

# DBTITLE 1,hpn InStateOnly=0
pa_outstate = spark.sql(""" SELECT pa.*,hpn.edipartnerfk  FROM pa_auditstate as pa
                   JOIN hpn_mcaidpartners as hpn ON hpn.HospitalFK = pa.HospitalFK
                   AND pa.State = hpn.ActiveState
                   WHERE hpn.InStateOnly = 0
                   """) 
pa_outstate.createOrReplaceTempView("pa_outstate")

# COMMAND ----------

# DBTITLE 1,hpn InStateOnly=1
pa_instate = spark.sql(""" SELECT pa.*, hpn.edipartnerfk  FROM pa_auditstate as pa
            JOIN hpn_mcaidpartners as hpn ON hpn.HospitalFK = pa.HospitalFK
            WHERE
            hpn.InStateOnly = 1
            AND ((pa.hospitalstate <> hpn.activestate and pa.state = hpn.activestate) 
            OR (pa.hospitalstate = hpn.activestate and coalesce(pa.State, hpn.activestate) = hpn.activestate) 
            OR (Auditzflag = 1 AND pa.auditstate = hpn.activestate )) """)
pa_instate.createOrReplaceTempView("pa_instate")

# COMMAND ----------

# DBTITLE 1,union instate  and outofstate
pa_final=pa_outstate.union(pa_instate)
pa_final=pa_final.withColumnRenamed("edipartnerfk","lsb_edipartnerfk").withColumnRenamed("medicaidnum","lsb_coverageid").withColumnRenamed("patientacctipk","patientacctifk")
pa_final=pa_final.drop("Auditzflag","auditstate","hospitalstate")

# COMMAND ----------

# DBTITLE 1,AdmitDate filter on EdipartnerFK
pa_admitdate = filter_coverageid_len_admitdt(spark, pa_final, minmaxbyedipartnerfk_path,scratch_path)

# COMMAND ----------

# DBTITLE 1,FC Temp Data
#create_temp_data(spark, dataingestion_path, scratch_path)
get_real_verified_hit_foundcoverages(spark, dataingestion_path, scratch_path)

# COMMAND ----------

# DBTITLE 1,FC Exists Check
# Filter out if any leads already in Foundcoverage 
pa_notinfc= filter_ifexistsinfc(spark, pa_admitdate, dataingestion_path, scratch_path) 

# COMMAND ----------

# DBTITLE 1,Ohi Batch Step for NPI and hospname
pa_ohi = ohibatchprocess(spark, pa_notinfc, dataingestion_path, scratch_path)
pa_ohi = pa_ohi.drop("isohi","excludeohilead")
writeparquet(spark, pa_ohi, scratch_path + "/tmpdata/pa_ohi", 0, "overwrite")
pa_ohi_tmp = readparquet(spark, scratch_path + "/tmpdata/pa_ohi/", "0", "na")
pa_ohi_tmp.createOrReplaceTempView("pa_ohi")

# COMMAND ----------

# DBTITLE 1,join with clusterdaccts to get demographics
pa_ca=spark.sql("""SELECT pa_ohi.*, ca.firstname as ca_firstname, ca.middlename as ca_middlename, ca.lastname as ca_lastname, ca.dob as ca_dob, ca.ssn as ca_ssn FROM pa_ohi left join ca on pa_ohi.clusteredacctfk=ca.clusteredacctpk""" )
pa_ca.createOrReplaceTempView("pa_ca")
pa_ca=spark.sql("""SELECT patientacctifk
                          ,hospitalfk
                          ,coalesce(ca_firstname,firstname) AS firstname
                          ,coalesce(ca_middlename,middlename) AS middlename
                          ,coalesce(ca_lastname,lastname) AS lastname
                          ,coalesce(ca_ssn,ssn) AS ssn
                          ,coalesce(ca_dob,dob) AS dob
                          ,gender
                          ,state
                          ,admitdate
                          ,dischargedate
                          ,clusteredacctfk
                          ,totalcharges
                          ,createdate
                          ,updatedate
                          ,demographicsupdatedate
                          ,lsb_coverageid
                          ,trgupdatedate
                          ,lsb_edipartnerfk
                          ,npi
                          ,hospitalname,
                          medicarehic
                          from pa_ca
                          """)
pa_ca_hash=pa_ca.withColumn('demohash', hash(concat_ws(":", upper(trim(pa_ca.firstname)), upper(trim(pa_ca.lastname)),trim(pa_ca.ssn), trim(pa_ca.dob), upper(trim(pa_ca.state)))))

# COMMAND ----------

# DBTITLE 1,bestleadselection with deduping
def bestleads(spark, all_leads, bc, scratch_path):
    lf1 = all_leads
    lf1.createOrReplaceTempView('lf1')
    final = spark.sql("""
    SELECT
           patientacctifk,
           hospitalfk,
           hospitalname,
           lsb_edipartnerfk AS edipartnerfk,
           'InProgress' AS PatientAcctXLeadStatus,
           GETDATE() AS PatientAcctXLeadStatusUpdateDate,
           firstname,
           lastname,
           middlename,
           CAST(dob AS TIMESTAMP) AS dob,
           ssn,
           gender,
           state,
           '' AS TraditionalIdentifier,
           admitdate,
           dischargedate,
           lsb_coverageid AS CoverageID,
           '' AS FC_SSN,
           CAST(NULL AS VARCHAR(1)) AS FC_DOB,
           '' AS FC_LastName,
           '' AS FC_FirstName,
           clusteredacctfk,
           totalcharges,
           npi,
           0 AS UsingFamilyDataFlag,
           demohash AS DemographicsHash,
           CAST(NULL AS VARCHAR(1)) AS LastAbiETLStartDate,
           '54' AS edidatasourcefk,
           updatedate,
           CAST(clusteredacctfk AS VARCHAR(50)) AS EDIDataSourceTableKey,
           '' AS AssociationSource,
           medicarehic,
           ROW_NUMBER() OVER (PARTITION BY hospitalfk,patientacctifk,lsb_edipartnerfk,lsb_coverageid
           ORDER BY CAST(updatedate AS TIMESTAMP) DESC,demohash DESC) AS rn
    FROM lf1
    """)
    final = final.filter("rn = 1").drop("rn","updatedate")
    writeparquet(spark, final, scratch_path+'/tmpdata/bestleads', 0, "overwrite")

    return final

# COMMAND ----------

# DBTITLE 1,bestleadselection function call
final_df=bestleads(spark, pa_ca_hash, bc, scratch_path)

# COMMAND ----------

# DBTITLE 1,Check against paxlead
patientacctxleads = spark.read.format('delta').load(patientacctxleads_path)
pa_final = final_df.join(
    patientacctxleads,
    (patientacctxleads.hospitalfk == final_df.hospitalfk) &
    (patientacctxleads.lsb_edipartnerfk == final_df.edipartnerfk) &
    (patientacctxleads.patientacctifk == final_df.patientacctifk)&
    (patientacctxleads.lsb_coverageid == final_df.CoverageID),
    how='leftanti'
)
pa_final.write.format('parquet').mode('overwrite').save(scratch_path + '/pa_final')

# COMMAND ----------

# DBTITLE 1,Delete Temp Data Folders
dbutils.fs.rm(scratch_path+"/tmpdata",True)

# COMMAND ----------

# DBTITLE 1,Final leads
pa_final = spark.read.format('parquet').load(scratch_path + '/pa_final')
if (pa_final.isEmpty()):
    ret_val = 0
else:
    ret_val = 1

dbutils.notebook.exit(ret_val)
