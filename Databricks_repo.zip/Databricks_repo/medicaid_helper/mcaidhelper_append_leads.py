# Databricks notebook source
# DBTITLE 1,Input Parameters
dbutils.widgets.text("user","")
dbutils.widgets.getArgument("user")
user= getArgument("user")

dbutils.widgets.text("container","")
dbutils.widgets.getArgument("container")
container= getArgument("container")

dbutils.widgets.text("storageaccount","")
dbutils.widgets.getArgument("storageaccount")
storageaccount= getArgument("storageaccount")

dbutils.widgets.text("bc","")
dbutils.widgets.getArgument("bc")
bc= getArgument("bc")

dbutils.widgets.text("mcaidhelper_input","")
dbutils.widgets.getArgument("mcaidhelper_input")
mcaidhelper_input= getArgument("mcaidhelper_input")

dbutils.widgets.text("mcaidhelper_output","")
dbutils.widgets.getArgument("mcaidhelper_output")
mcaidhelper_output= getArgument("mcaidhelper_output")

# COMMAND ----------

# DBTITLE 1,Storage Account Access
spark.conf.set("fs.azure.account.key."+storageaccount+".dfs.core.windows.net",dbutils.secrets.get(scope ="icd-insleads-dbwscope", key = "icd-adls-insleads-kvsecret"))

if user == 'na':
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net'
else:
    baseurl ='abfss://'+container+'@'+storageaccount+'.dfs.core.windows.net/'+user 

# COMMAND ----------

# DBTITLE 1,full paths
mcaidhelper_input = baseurl + mcaidhelper_input + bc + '/pa_final'
mcaidhelper_output = baseurl + mcaidhelper_output
print("mcaidhelper_input:", mcaidhelper_input)
print("mcaidhelper_output:", mcaidhelper_output)

# COMMAND ----------

# DBTITLE 1,Import
from pyspark.sql.types import *
from pyspark.sql.functions import *

# COMMAND ----------

# DBTITLE 1,Input Data and Adding Breadcrumb
new_pa = spark.read.parquet(mcaidhelper_input).dropDuplicates()
new_pa = new_pa.withColumn("breadcrumb", lit(bc))

# COMMAND ----------

# DBTITLE 1,new hints to patientacctsxhints
new_pa.write.mode("append").format("delta").save(mcaidhelper_output)
