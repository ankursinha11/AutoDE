# Chat Query Examples - Natural Language Guide

## Quick Reference: How to Ask Questions

This guide shows you how to interact with the system using natural language. The chat orchestrator understands **multi-intent queries** and will automatically detect what you want to do.

---

## 🎯 STAG Comparison Queries

### Basic STAG Comparison
Generate comprehensive Excel comparison report.

**Examples:**
```
"Generate STAG comparison for hadoop workflow cdd: bdf_download"
"Create STAG report for abinitio customer_transform"
"Generate full comparison for hadoop cdw_extract"
"Show me STAG comparison for cdd: bdf_download"
```

**Response:**
- ✅ Excel file with 5 sheets (Overview, Databricks Logic, Source Logic, Logic Comparison, STTM)
- ✅ Summary: business stages count, STTM mappings, differences
- ✅ File path for download

---

### STAG Comparison + Explanation
Get comparison report AND detailed business stage analysis.

**Examples:**
```
"Generate STAG for hadoop cdd: bdf_download and explain the differences"
"Create STAG comparison for abinitio customer_transform and describe the business stages"
"Generate full comparison for hadoop cdw_extract and tell me what's different"
"Show me STAG for cdd: bdf_download and explain the logic"
```

**Response:**
- ✅ Excel file (same as above)
- ✅ Detailed business stage breakdown with comparison status (Similar/Different)
- ✅ Source vs Databricks implementation descriptions
- ✅ Notes explaining differences

**Detected Intents:**
- Primary: `STAG_COMPARISON`
- Secondary: `LOGIC_ANALYSIS`

---

### STAG Comparison + STTM Focus
Get comparison report with emphasis on column mappings.

**Examples:**
```
"Generate STAG for hadoop cdd: bdf_download and show column mappings"
"Create STAG comparison for abinitio customer_transform with STTM details"
"Generate comparison for hadoop cdw_extract and show me the lineage"
"Show STAG for cdd: bdf_download with source-to-target mappings"
```

**Response:**
- ✅ Excel file (same as above)
- ✅ STTM sample section showing column mappings
- ✅ Transformation logic references
- ✅ Reference to Excel Sheet 5 for complete mappings

**Detected Intents:**
- Primary: `STAG_COMPARISON`
- Secondary: `LINEAGE`

---

## 🔍 Comparison Queries (Without STAG)

### Cross-System Comparison
Compare implementations across systems without generating full STAG report.

**Examples:**
```
"Compare hadoop and databricks implementations for cdd: bdf_download"
"What's the difference between hadoop cdw_extract and databricks cdw_extract"
"Show me similarities between abinitio customer_transform and databricks customer_pipeline"
```

**Response:**
- ✅ Business purpose comparison
- ✅ Complexity analysis
- ✅ Similarity scores
- ✅ Logic differences

**Detected Intents:**
- Primary: `COMPARISON`

---

### Comparison + Report Generation
Compare systems AND generate document.

**Examples:**
```
"Compare hadoop and databricks for cdd: bdf_download and create a report"
"Show differences between systems and generate comparison document"
"Compare implementations and export to Excel"
```

**Response:**
- ✅ Comparison analysis
- ✅ Generated document/Excel file
- ✅ Download link

**Detected Intents:**
- Primary: `COMPARISON`
- Secondary: `DOCUMENT_GENERATION`

---

## 🗺️ Lineage & Mapping Queries

### Column Lineage Tracing
Trace column-level lineage and transformations.

**Examples:**
```
"Show me the lineage for customer_id column in cdd: bdf_download"
"Trace where order_date comes from in hadoop cdw_extract"
"What's the source of revenue_amount in databricks pipeline"
"Show column flow for account_number"
```

**Response:**
- ✅ Column source tracking
- ✅ Transformation chain
- ✅ Upstream/downstream dependencies
- ✅ STTM mappings

**Detected Intents:**
- Primary: `LINEAGE`

---

### Workflow Mapping Queries
Understand workflow replacement patterns.

**Examples:**
```
"What databricks workflows replaced hadoop cdd: bdf_download?"
"Show me unmapped hadoop workflows"
"Which workflows have N:1 consolidation patterns?"
"What replaced abinitio customer_transform?"
```

**Response:**
- ✅ Workflow mapping details
- ✅ N:1, 1:N, or 1:1 pattern identification
- ✅ Unmapped workflow alerts
- ✅ Migration recommendations

**Detected Intents:**
- Primary: `WORKFLOW_MAPPING`

---

## 🧠 Logic Analysis Queries

### Understanding Transformation Logic
Get AI-powered explanation of business logic.

**Examples:**
```
"Explain how hadoop cdd: bdf_download transforms the data"
"What does the abinitio customer_transform graph do?"
"Describe the business logic in databricks cdw_extract"
"How does hadoop cdw_extract process customer data?"
```

**Response:**
- ✅ Natural language business purpose explanation
- ✅ Step-by-step transformation breakdown
- ✅ Business rules identification
- ✅ Complexity assessment

**Detected Intents:**
- Primary: `LOGIC_ANALYSIS`

---

## 🔎 Code Search Queries

### Finding Workflows & Components
Search for specific code patterns or workflows.

**Examples:**
```
"Find all hadoop workflows that process customer data"
"Search for workflows containing 'revenue' transformations"
"Show me all abinitio graphs with aggregations"
"List all databricks pipelines reading from ADLS"
```

**Response:**
- ✅ Matching workflows/graphs/pipelines
- ✅ Code snippets
- ✅ Relevance ranking
- ✅ File locations

**Detected Intents:**
- Primary: `CODE_SEARCH`

---

## 📄 Document Generation Queries

### Creating Documentation
Generate STTM, comparison documents, or reports.

**Examples:**
```
"Generate STTM document for hadoop cdd: bdf_download"
"Create documentation for abinitio customer_transform"
"Export workflow details to Excel"
"Generate mapping report for cdw_extract"
```

**Response:**
- ✅ Generated document (Excel/JSON/Markdown)
- ✅ Download link
- ✅ STTM mappings if applicable
- ✅ Metadata and transformations

**Detected Intents:**
- Primary: `DOCUMENT_GENERATION`

---

## 💬 Simple RAG Queries

### General Questions
Ask anything about the codebase.

**Examples:**
```
"What data sources are used in the hadoop workflows?"
"How many databricks pipelines do we have?"
"Explain the overall architecture"
"What are the most complex workflows?"
```

**Response:**
- ✅ AI-generated answer from vector search
- ✅ Top 5 relevant code chunks
- ✅ Context from multiple systems
- ✅ Natural language explanation

**Detected Intents:**
- Primary: `SIMPLE_RAG`

---

## 🔀 Multi-Intent Query Examples

### Example 1: Full Analysis Request
```
"Generate STAG for hadoop cdd: bdf_download, explain the business logic differences, and show me the column mappings"
```

**Detected Intents:**
- Primary: `STAG_COMPARISON` (0.99)
- Secondary: `LOGIC_ANALYSIS` (0.85), `LINEAGE` (0.90)

**Response Includes:**
- ✅ Full Excel STAG comparison report
- ✅ Business stage analysis section
- ✅ STTM column mappings sample
- ✅ Logic differences explanation

---

### Example 2: Comparison with Documentation
```
"Compare hadoop and databricks implementations for cdw_extract and create a detailed report"
```

**Detected Intents:**
- Primary: `COMPARISON` (0.95)
- Secondary: `DOCUMENT_GENERATION` (0.98)

**Response Includes:**
- ✅ Cross-system comparison analysis
- ✅ Generated Excel comparison document
- ✅ Similarity scores and differences
- ✅ Download link

---

### Example 3: Search and Generate
```
"Find the customer_transform workflow and generate STAG comparison"
```

**Detected Intents:**
- Primary: `CODE_SEARCH` (0.80)
- Secondary: `STAG_COMPARISON` (0.99)

**Response Includes:**
- ✅ Search results for customer_transform
- ✅ Full STAG comparison report
- ✅ Excel file with all details

---

## 🎨 Query Formatting Tips

### ✅ Good Queries (Natural & Clear)

```
✅ "Generate STAG for hadoop cdd: bdf_download and explain differences"
✅ "Compare hadoop and databricks logic for cdw_extract"
✅ "Show me column mappings for customer_transform"
✅ "What replaced hadoop workflow cdd: bdf_download?"
✅ "Explain the transformation logic in abinitio customer_graph"
```

### ❌ Avoid (Too Vague or Ambiguous)

```
❌ "Show me stuff"  (too vague)
❌ "Compare things"  (no specifics)
❌ "Generate report"  (what kind? for what?)
❌ "Explain"  (explain what?)
```

---

## 🚀 Pro Tips

### 1. Specify the Workflow Name
Always include the workflow/graph/pipeline name for best results:
```
✅ "Generate STAG for hadoop cdd: bdf_download"
❌ "Generate STAG for hadoop"
```

### 2. Use Keywords for Multi-Intent
Include keywords to trigger secondary intents:
- "and explain" → adds LOGIC_ANALYSIS
- "show mappings" → adds LINEAGE
- "create report" → adds DOCUMENT_GENERATION
- "show differences" → adds COMPARISON

### 3. System Names (Optional)
The system can infer the source system, but you can specify it explicitly:
```
✅ "Generate STAG for hadoop workflow cdd: bdf_download"
✅ "Generate STAG for cdd: bdf_download"  (system auto-detected)
```

### 4. Be Conversational
You don't need to use exact command syntax:
```
✅ "Can you generate a STAG comparison for the cdd: bdf_download workflow?"
✅ "I need to see the differences between hadoop and databricks for cdw_extract"
✅ "Please show me the column mappings for customer_transform"
```

### 5. Ask Follow-Up Questions
Use context from previous queries:
```
User: "Generate STAG for hadoop cdd: bdf_download"
System: [generates report]
User: "Now explain the differences"
System: [uses previous workflow context]
```

---

## 📊 Sample Multi-Intent Workflow

```
User Query:
"Generate a full STAG comparison for hadoop cdd: bdf_download and explain the business stages and column mappings"

Detected Intents:
├─ Primary: STAG_COMPARISON (0.99)
├─ Secondary: LOGIC_ANALYSIS (0.85)
└─ Secondary: LINEAGE (0.90)

Task Plan:
1. Identify source workflow
2. Look up Databricks mapping
3. Extract hadoop logic
4. Extract Databricks logic
5. Abstract to business stages (AI)
6. Generate STTM (AI)
7. Create Excel comparison report

Response Includes:
✅ Excel file: outputs/stag_comparisons/hadoop_cdd_bdf_download_vs_databricks_20250115.xlsx
✅ Summary: 12 business stages, 47 STTM mappings, 3 differences
✅ Business Stage Analysis: Detailed breakdown of all 12 stages
✅ STTM Sample: First 5 column mappings with transformation logic
✅ Reference to Excel sheets for complete data
```

---

## 🆘 Troubleshooting

### Issue: "Could not identify workflow name"
**Solution:** Be more explicit with the workflow name:
```
❌ "Generate STAG for the download workflow"
✅ "Generate STAG for hadoop cdd: bdf_download"
```

### Issue: "No Databricks mapping found"
**Solution:** Check if the workflow exists in system_mapping_layer.json:
```
User: "What workflows are available?"
System: [lists all mappings]
```

### Issue: Response too verbose
**Solution:** Ask for concise output:
```
"Generate STAG for hadoop cdd: bdf_download (concise summary only)"
```

### Issue: Missing STTM details
**Solution:** Explicitly request column mappings:
```
"Generate STAG for hadoop cdd: bdf_download and show column mappings"
```

---

## 📚 Additional Resources

- **[STAG Engine Documentation](STAG_ENGINE_COMPLETE.md)** - Complete STAG architecture
- **[Multi-Intent Integration](MULTI_INTENT_CHAT_INTEGRATION.md)** - Technical implementation details
- **[System Mapping](Input%20Files/system_mapping_layer.json)** - Available workflow mappings

---

## Summary

The chat orchestrator understands natural language and can:

✅ **Detect Multiple Intents** - Understand complex queries with multiple objectives
✅ **Extract Workflows** - AI-powered extraction from conversational queries
✅ **Generate STAG Reports** - Comprehensive 5-sheet Excel comparisons
✅ **Provide Explanations** - Business stage and logic analysis
✅ **Show Mappings** - Column-level STTM with transformations
✅ **Stream Progress** - Real-time updates during execution

**Just ask naturally, and the system will figure out what you need!**
