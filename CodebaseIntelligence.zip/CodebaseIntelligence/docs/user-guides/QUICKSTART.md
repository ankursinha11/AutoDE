# STAG Quick Start Guide

**Date**: 2025-11-12
**Status**: ✅ Ready for Testing

---

## 🚀 Quick Setup (5 Minutes)

### 1. Configure AI Provider (Azure OpenAI - Client AVD)

```bash
# Navigate to STAG directory
cd /path/to/CodebaseIntelligence

# Create .env file with Azure credentials
cat > .env << 'EOF'
AI_PROVIDER=azure
AZURE_OPENAI_API_KEY=your_azure_key_here
AZURE_OPENAI_ENDPOINT=your_azure_endpoint_here
AZURE_OPENAI_DEPLOYMENT_NAME=gpt-4
AZURE_OPENAI_API_VERSION=2024-02-15-preview
EOF
```

### 2. Run Validation Script

```bash
python3 validate_stag_setup.py
```

**Expected**: All checks should pass ✅

### 3. Start STAG

```bash
streamlit run stag_app.py
```

STAG will open in your browser at `http://localhost:8501`

---

## 📊 Index Your Systems (Fresh Start)

### Delete Old Data (Recommended)

```bash
rm -rf outputs/vector_db
rm -rf outputs/checkpoints
```

### Index Each System

**In STAG UI:**
1. Click **"System Integrations"** tab
2. For each system:
   - Select system type
   - Choose "Index from Directory"
   - Browse to repository path
   - Click "Index from Directory (DEEP)"

**Paths**:
- Hadoop: `hadoop_repos/hadoop_repos`
- Databricks: `Databricks_repo`
- Ab Initio: (your Ab Initio repo path)

**What Happens**:
- ✅ Resume capability active (auto-saves every 10 files)
- ✅ AI analyzes each script
- ✅ Vector DB indexes for search
- ✅ If crash: just restart - it resumes automatically!

---

## 🧪 Test Core Features

### Test 1: Search

**What to do**:
1. Go to **"Search"** tab
2. Enter query: `"patient accounts eligibility"`
3. Click Search

**What to verify**:
- ✅ Returns relevant scripts (Hadoop, Databricks, Ab Initio)
- ✅ Shows file paths correctly
- ✅ Ranks by relevance

---

### Test 2: Lineage Tracking

**What to do**:
1. Go to **"Lineage Tracking"** tab
2. Select system: **Hadoop**
3. Select table: **ack** (or any table you know)
4. Set max hops: **5**
5. Click **"Trace Lineage"**

**What to verify**:
- ✅ Shows multiple hops (not just "ack → ack")
- ✅ Source and target tables are different
- ✅ Transformations are meaningful (not "Transform")
- ✅ Follows actual data flow from code

**Example Good Output**:
```
Hop 1: es_ack → [CREATE EXTERNAL TABLE] → ack
Hop 2: ack → [INSERT SELECT] → ack_staging
Hop 3: ack_staging → [JOIN] → processed_ack
```

**Example Bad Output** (old behavior):
```
Hop 1: ack → [Transform] → ack
Hop 2: ack → [Transform] → ack
```

---

### Test 3: Workflow Comparison

**What to do**:
1. Go to **"Chat"** tab
2. Ask: `"Compare ie_prebdf workflow from Hadoop vs Databricks"`
3. Wait for response

**What to verify**:
- ✅ Finds both versions (Hadoop Pig/Oozie AND Databricks PySpark)
- ✅ Shows **Process Flow** comparison first (stages, pipeline flow)
- ✅ Shows **Logic** comparison (transformations, business rules)
- ✅ Shows **Data** comparison (tables, columns)
- ✅ Technology mentioned **last** (brief)
- ✅ Includes comparison tables

**Example Good Structure**:
```
## Pipeline Process Flow Comparison
- Hadoop: Stage 1 → Stage 2 → Stage 3
- Databricks: Notebook 1 → Notebook 2 → Notebook 3
- Similarity: HIGH

## Logic Comparison
- Transformation 1: Similar (both filter on status)
- Transformation 2: Different (Hadoop uses Pig JOIN, Databricks uses PySpark join)

## Data Comparison
- Sources: Both read from patient_accounts
- Targets: Both write to eligibility_queue

## Technology Differences
- Hadoop: Pig Latin + Oozie
- Databricks: PySpark + Notebooks
```

---

## ✅ Validation Checklist

Copy this to track your testing:

```
INFRASTRUCTURE
[ ] Azure OpenAI configured (.env file created)
[ ] validate_stag_setup.py passes all checks
[ ] STAG starts successfully (streamlit run stag_app.py)

INDEXING
[ ] Hadoop indexed (check System Statistics tab)
[ ] Databricks indexed (check System Statistics tab)
[ ] Ab Initio indexed (if available)
[ ] Resume works (tested by interrupting indexing)

SEARCH ACCURACY
[ ] Keyword search finds relevant files
[ ] Semantic search understands intent
[ ] Results show correct file paths
[ ] Ranking makes sense

LINEAGE ACCURACY
[ ] Multi-hop trace works (shows > 1 hop)
[ ] Source/target tables extracted correctly
[ ] Transformations are meaningful
[ ] Data flow matches your knowledge

COMPARISON ACCURACY
[ ] Finds both Hadoop and Databricks versions
[ ] Process flow comparison detailed
[ ] Logic comparison accurate
[ ] Data comparison shows tables
[ ] Technology mentioned last

CHAT FUNCTIONALITY
[ ] Answers workflow questions correctly
[ ] Provides file references
[ ] Uses actual indexed code
[ ] Explains clearly
```

---

## 📝 What to Report

### If Everything Works ✅
Tell me:
1. **Accuracy rating** (1-10) for each feature:
   - Search: __/10
   - Lineage: __/10
   - Comparison: __/10
   - Chat: __/10

2. **Performance notes**:
   - Indexing speed: Fast / Slow
   - Search speed: Fast / Slow
   - Lineage speed: Fast / Slow

3. **Feature requests**:
   - What would make it better?

### If Issues Found ❌
Tell me:
1. **What were you doing?** (exact steps)
2. **What did you expect?** (expected behavior)
3. **What happened?** (actual behavior)
4. **Error messages** (copy full error logs)
5. **Sample data** (if safe to share)

---

## 🆘 Common Issues

### Issue: "No AI provider configured"
**Fix**: Create `.env` file with Azure OpenAI credentials (see Step 1 above)

### Issue: "No collections found" during search
**Fix**: Index your systems first (System Integrations tab)

### Issue: Indexing crashes midway
**Fix**: Just restart STAG - it will resume automatically from checkpoint!

### Issue: Lineage shows "0 hops"
**Fix**:
1. Make sure system is indexed
2. Make sure table name is correct
3. Check that table exists in your code

### Issue: "Disk full" error
**Fix**:
1. Check disk space: `df -h`
2. Delete old data: `rm -rf outputs/ai_enriched_docs`
3. Re-index (content now truncated automatically)

---

## 📚 Full Documentation

For complete details, see:
- **[STAG_ENHANCEMENTS_COMPLETE.md](STAG_ENHANCEMENTS_COMPLETE.md)** - Full feature list and architecture
- **[LINEAGE_TRACKING_FIX.md](LINEAGE_TRACKING_FIX.md)** - Lineage improvements details
- **[DATABASE_SIZE_LIMIT_FIX.md](DATABASE_SIZE_LIMIT_FIX.md)** - Disk space fixes
- **[DISK_FULL_SOLUTIONS.md](DISK_FULL_SOLUTIONS.md)** - Disk space solutions

---

## 🎯 Success Criteria

STAG is working correctly if:

✅ **Search**: Finds relevant files across all systems
✅ **Lineage**: Traces data flow correctly through multiple hops
✅ **Comparison**: Shows meaningful workflow differences
✅ **Chat**: Answers questions using actual code
✅ **Resume**: Recovers from crashes automatically

---

**Ready to Test!** 🚀

Start with Step 1, work through the checklist, and report back your findings!

