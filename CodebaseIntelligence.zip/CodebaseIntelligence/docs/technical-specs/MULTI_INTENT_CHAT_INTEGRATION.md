# Multi-Intent Chat Integration with STAG Engine

## Overview

The chat orchestrator now supports **multi-intent query detection and handling**, enabling it to understand complex user requests that combine multiple objectives in a single natural language query.

### Key Features

✅ **Multi-Intent Detection** - Detects multiple intents in a single query
✅ **STAG Integration** - Full integration with STAG comparison engine
✅ **Context-Aware Responses** - Tailors output based on secondary intents
✅ **Natural Language Understanding** - Extracts workflows and systems from conversational queries
✅ **Streaming Progress** - Real-time updates during long-running operations

---

## Multi-Intent Examples

### Example 1: STAG Comparison + Explanation

**User Query:**
```
Generate a STAG comparison for hadoop workflow "cdd: bdf_download" and explain the business stages
```

**Detected Intents:**
- **Primary:** `STAG_COMPARISON` (0.99 confidence)
- **Secondary:** `LOGIC_ANALYSIS` (0.85 confidence)

**Behavior:**
1. Generates comprehensive Excel comparison report
2. Includes detailed business stage analysis in the response
3. Shows transformation logic differences
4. Returns Excel file path

**Response Structure:**
```
📊 STAG Comparison Report Generated

Source System: HADOOP
Source Workflow: cdd: bdf_download
Databricks Pipeline: bdf_download_pipeline

📄 Excel Report
File: outputs/stag_comparisons/hadoop_cdd_bdf_download_vs_databricks_20250115.xlsx

🎯 Business Stage Analysis
1. Data Ingestion ✅ (Similar)
   Hadoop: Ingests raw files from HDFS /data/cdd/raw...
   Databricks: Reads raw files from DBFS /mnt/data/cdd/raw...
   Notes: Both use similar file ingestion patterns

2. Data Transformation ⚠️ (Different)
   Hadoop: Uses Pig script for data transformation...
   Databricks: Uses PySpark DataFrame operations...
   Notes: Logic is equivalent but implementation differs
...
```

---

### Example 2: Comparison + Report Generation

**User Query:**
```
Compare hadoop and databricks implementations and create a comparison report
```

**Detected Intents:**
- **Primary:** `COMPARISON` (0.95 confidence)
- **Secondary:** `DOCUMENT_GENERATION` (0.98 confidence)

**Behavior:**
1. Performs cross-system logic comparison
2. Automatically generates document/Excel report
3. Returns both comparison analysis AND report file

---

### Example 3: STAG + STTM Focus

**User Query:**
```
Generate STAG comparison for abinitio graph "customer_transform" and show me the column mappings
```

**Detected Intents:**
- **Primary:** `STAG_COMPARISON` (0.99 confidence)
- **Secondary:** `LINEAGE` (0.90 confidence)

**Behavior:**
1. Generates full STAG comparison
2. Includes STTM (Source-To-Target Mapping) section in response
3. Shows sample column mappings with transformation logic

**Response Addition:**
```
🔗 Sample Column Mappings (STTM)

Showing first 5 column mappings (see Excel for complete 47 mappings):

*Complete STTM with transformation logic available in Excel Sheet 5*
```

---

## Implementation Architecture

### 1. Query Classifier Updates

**File:** [services/chat/query_classifier.py](services/chat/query_classifier.py)

#### New Fields in `ClassifiedQuery`:
```python
@dataclass
class ClassifiedQuery:
    intent: QueryIntent              # Primary intent
    confidence: float                # Confidence for primary intent
    secondary_intents: List[QueryIntent]  # NEW: Additional detected intents
    intent_scores: Dict[QueryIntent, float]  # NEW: Scores for all intents
    # ... other fields
```

#### Multi-Intent Detection Algorithm:

```python
def _determine_intent(...) -> tuple[QueryIntent, float, str, List[QueryIntent]]:
    """Detect ALL applicable intents, rank by confidence"""

    detected_intents = []

    # STAG Comparison (HIGHEST - 0.99)
    if 'stag' in query or 'full comparison' in query:
        detected_intents.append((QueryIntent.STAG_COMPARISON, 0.99, "..."))

    # Document Generation (HIGH - 0.98)
    if 'generate report' in query or 'create document' in query:
        detected_intents.append((QueryIntent.DOCUMENT_GENERATION, 0.98, "..."))

    # ... check all other intents ...

    # Sort by confidence
    detected_intents.sort(key=lambda x: x[1], reverse=True)

    # Primary = highest confidence
    primary_intent, primary_confidence, primary_reasoning = detected_intents[0]

    # Secondary = additional intents with confidence > 0.75
    secondary_intents = [intent for intent, conf, _ in detected_intents[1:] if conf > 0.75]

    return (primary_intent, primary_confidence, primary_reasoning, secondary_intents)
```

#### Multi-Intent Task Planning:

```python
def _create_task_plan_multi_intent(intents: List[QueryIntent], ...) -> List[str]:
    """Combine tasks from multiple intents intelligently"""

    # STAG is comprehensive - if present, it includes comparison, lineage, document gen
    if QueryIntent.STAG_COMPARISON in intents:
        all_tasks.extend(STAG_tasks)
        # Add non-overlapping tasks from other intents
        for intent in intents:
            if intent not in [STAG_COMPARISON, COMPARISON, LINEAGE, DOCUMENT_GENERATION]:
                all_tasks.extend(get_tasks(intent))
    else:
        # Combine all intent tasks
        for intent in intents:
            all_tasks.extend(get_tasks(intent))

    # Deduplicate while preserving order
    return unique_tasks
```

---

### 2. Chat Orchestrator Updates

**File:** [services/chat/chat_orchestrator.py](services/chat/chat_orchestrator.py)

#### Initialization:
```python
def __init__(self, ai_analyzer, indexer, vector_store=None):
    # ... existing agents ...

    # NEW: STAG Orchestrator
    self.stag_orchestrator = STAGOrchestrator(indexer=indexer, ai_analyzer=ai_analyzer)
```

#### Multi-Intent Routing:
```python
def process_query_stream(self, query, context):
    classified = self.classifier.classify(query, context)

    # Show secondary intents
    if classified.secondary_intents:
        yield f"Multi-intent query detected: {', '.join([i.value for i in classified.secondary_intents])}"

    # Route based on primary intent
    if classified.intent == QueryIntent.STAG_COMPARISON:
        yield from self._handle_stag_comparison(query, classified, context)
    elif classified.intent == QueryIntent.COMPARISON:
        # Check secondary intents for additional behavior
        yield from self._handle_comparison(query, classified, context)
    # ...
```

#### STAG Handler with Multi-Intent Support:
```python
def _handle_stag_comparison(self, query, classified, context):
    """
    Handle STAG comparison with context-aware output

    Multi-Intent Support:
    - If LOGIC_ANALYSIS or COMPARISON is secondary intent → include business stage details
    - If LINEAGE is secondary intent → include STTM sample
    - If specific keywords present → tailor output
    """

    # 1. Extract workflow from natural language
    workflow_info = self._extract_workflow_from_query(query, classified)

    # 2. Run STAG orchestrator
    result = self.stag_orchestrator.generate_comparison(
        source_system=workflow_info['source_system'],
        source_workflow=workflow_info['source_workflow']
    )

    # 3. Build base answer
    answer = f"📊 STAG Comparison Report Generated\n..."

    # 4. Add business stage details if COMPARISON or LOGIC_ANALYSIS in secondary intents
    if (QueryIntent.COMPARISON in classified.secondary_intents or
        QueryIntent.LOGIC_ANALYSIS in classified.secondary_intents or
        any(kw in query.lower() for kw in ['explain', 'what are', 'describe'])):

        answer += "\n🎯 Business Stage Analysis\n..."
        for stage in result['business_stages']:
            answer += f"{stage['stage_name']}: {stage['comparison']}\n..."

    # 5. Add STTM sample if LINEAGE in secondary intents
    if (QueryIntent.LINEAGE in classified.secondary_intents or
        any(kw in query.lower() for kw in ['sttm', 'mapping', 'column'])):

        answer += "\n🔗 Sample Column Mappings (STTM)\n..."

    return answer
```

---

### 3. Natural Language Workflow Extraction

**Challenge:** Users may phrase queries conversationally:
- "Generate comparison for the customer transform workflow"
- "Show me STAG for cdd: bdf_download"
- "Compare hadoop cdw_extract with databricks"

**Solution:** AI-powered workflow extraction

```python
def _extract_workflow_from_query(self, query, classified):
    """Use AI to extract workflow name and system from natural language"""

    extraction_prompt = f"""
    Extract the workflow/pipeline name and source system from this query:

    Query: "{query}"
    Detected entities: {classified.entities}
    Detected systems: {classified.systems}

    Return JSON:
    {{
        "source_system": "hadoop" or "abinitio",
        "source_workflow": "exact workflow name",
        "confidence": 0.0 to 1.0,
        "reasoning": "why you chose this"
    }}
    """

    result = self.ai_analyzer.analyze_code(extraction_prompt, ...)
    workflow_info = extract_json(result)

    # Fallback to detected entities if AI extraction fails
    if workflow_info['confidence'] < 0.5:
        workflow_info['source_workflow'] = classified.entities[0]
        workflow_info['source_system'] = classified.systems[0]

    return workflow_info
```

---

## Query Intent Priorities

Intent priorities determine which intent becomes primary when multiple are detected:

| Priority | Intent | Confidence | Triggers |
|----------|--------|-----------|----------|
| 1 | `STAG_COMPARISON` | 0.99 | 'stag', 'full comparison', 'migration report' |
| 2 | `DOCUMENT_GENERATION` | 0.98 | 'generate document', 'create report', 'export' |
| 3 | `WORKFLOW_MAPPING` | 0.96 | 'replaced', 'unmapped', 'n:1', '1:n' |
| 4 | `COMPARISON` | 0.95 | 2+ systems + 'compare', 'versus' |
| 5 | `LINEAGE` | 0.90 | 'lineage', 'trace', 'source', 'target' |
| 6 | `LOGIC_ANALYSIS` | 0.85 | 'how does', 'explain', 'logic' |
| 7 | `CODE_SEARCH` | 0.80 | 'find', 'search', 'locate' |
| 8 | `SIMPLE_RAG` | 0.60 | default fallback |

**Secondary Intent Threshold:** 0.75
Any intent with confidence > 0.75 becomes a secondary intent.

---

## Usage Examples

### Example 1: Basic STAG Comparison

```python
query = "Generate STAG comparison for hadoop workflow cdd: bdf_download"

# Result:
Primary Intent: STAG_COMPARISON (0.99)
Secondary Intents: []

# Output:
- Excel comparison report
- Basic summary
```

### Example 2: STAG with Explanation

```python
query = "Generate STAG comparison for hadoop cdd: bdf_download and explain the differences"

# Result:
Primary Intent: STAG_COMPARISON (0.99)
Secondary Intents: [LOGIC_ANALYSIS (0.85)]

# Output:
- Excel comparison report
- Detailed business stage analysis
- Transformation logic differences
```

### Example 3: STAG with STTM Focus

```python
query = "Generate STAG for abinitio customer_transform and show column mappings"

# Result:
Primary Intent: STAG_COMPARISON (0.99)
Secondary Intents: [LINEAGE (0.90)]

# Output:
- Excel comparison report
- STTM sample with transformation logic
- Column-level lineage details
```

### Example 4: Comparison + Report

```python
query = "Compare hadoop and databricks implementations and create a report"

# Result:
Primary Intent: COMPARISON (0.95)
Secondary Intents: [DOCUMENT_GENERATION (0.98)]

# Output:
- Logic comparison analysis
- Excel/document report file
```

---

## Response Streaming

The chat orchestrator streams progress updates in real-time:

```python
# Phase 1: Thinking
yield "🧠 Analyzing query intent..."
yield "🎯 Primary intent: STAG_COMPARISON (99% confidence)"
yield "📋 Multi-intent query detected. Secondary: logic_analysis"

# Phase 2: Task Plan
yield "Task Plan:"
yield "1. Identify source workflow"
yield "2. Look up Databricks mapping"
yield "3. Extract source logic"
yield "4. Extract Databricks logic"
yield "5. Abstract to business stages (AI)"
yield "6. Generate STTM (AI)"
yield "7. Create Excel report"

# Phase 3: Execution
yield "Task 1/7: Extracting workflow information..."
yield "✅ Identified: HADOOP workflow 'cdd: bdf_download' (confidence: 95%)"
yield "Task 2/7: Looking up Databricks mapping..."
yield "✅ Mapping found: cdd: bdf_download → bdf_download_pipeline"
# ...

# Phase 4: Final Answer
yield "📊 STAG Comparison Report Generated\n..."
```

---

## STAG Comparison Workflow

```mermaid
graph TD
    A[User Query] --> B[Query Classifier]
    B --> C{Multi-Intent?}
    C -->|Yes| D[Detect Primary + Secondary]
    C -->|No| E[Single Intent]
    D --> F[Create Multi-Intent Task Plan]
    E --> F
    F --> G[Route to STAG Handler]
    G --> H[Extract Workflow from NL]
    H --> I[STAG Orchestrator]
    I --> J[System Mapping Lookup]
    J --> K[Extract Source Logic]
    J --> L[Extract Databricks Logic]
    K --> M[Business Stage Abstraction AI]
    L --> M
    M --> N[STTM Generation AI]
    N --> O[Excel Report Generation]
    O --> P{Secondary Intents?}
    P -->|LOGIC_ANALYSIS| Q[Add Business Stage Details]
    P -->|LINEAGE| R[Add STTM Sample]
    P -->|None| S[Base Response]
    Q --> T[Stream Final Answer]
    R --> T
    S --> T
```

---

## Testing

### Unit Tests

Test multi-intent detection:

```python
def test_multi_intent_detection():
    classifier = QueryClassifier()

    query = "Generate STAG comparison for hadoop cdd: bdf_download and explain differences"
    classified = classifier.classify(query)

    assert classified.intent == QueryIntent.STAG_COMPARISON
    assert QueryIntent.LOGIC_ANALYSIS in classified.secondary_intents
    assert classified.confidence > 0.95
```

### Integration Tests

Test end-to-end STAG flow:

```python
def test_stag_comparison_with_explanation():
    orchestrator = ChatOrchestrator(ai_analyzer, indexer)

    query = "Generate STAG for hadoop cdd: bdf_download and explain the business stages"

    updates = list(orchestrator.process_query_stream(query))

    # Check for multi-intent detection
    assert any("Multi-intent" in u.content for u in updates)

    # Check for STAG execution
    assert any("STAG Comparison" in u.content for u in updates)

    # Check for business stage analysis
    assert any("Business Stage Analysis" in u.content for u in updates)

    # Check for Excel file
    final_update = updates[-1]
    assert final_update.type == UpdateType.FINAL_ANSWER
    assert 'excel_file' in final_update.data
```

---

## Benefits

### 1. Natural User Experience
Users can ask complex questions naturally without needing to know system commands:
- ❌ Bad: "Run STAG orchestrator with source_system=hadoop, source_workflow=cdd: bdf_download"
- ✅ Good: "Generate comparison for hadoop cdd: bdf_download and show me the differences"

### 2. Intelligent Context Awareness
System understands what additional information to include based on query intent:
- Query asks for "explanation" → includes business stage details
- Query mentions "column mappings" → includes STTM sample
- Query is basic → returns concise Excel file reference

### 3. Reduced Cognitive Load
Users don't need to:
- Remember exact workflow names (AI extracts them)
- Specify source system explicitly (AI infers from context)
- Make multiple queries for related information (multi-intent handles it)

### 4. Comprehensive Yet Focused
- Always generates full Excel report (comprehensive)
- Tailors response based on what user asked for (focused)
- Avoids information overload while ensuring completeness

---

## Future Enhancements

### 1. Intent Conflict Resolution
Handle conflicting intents intelligently:
```python
# Example: "Search for workflows but don't generate reports"
if QueryIntent.CODE_SEARCH in intents and QueryIntent.DOCUMENT_GENERATION in intents:
    if "don't" in query or "without" in query:
        # Remove DOCUMENT_GENERATION
        intents.remove(QueryIntent.DOCUMENT_GENERATION)
```

### 2. Intent Prioritization Learning
Learn from user feedback which intent combinations work best:
```python
# Track user satisfaction
feedback = {
    (STAG_COMPARISON, LOGIC_ANALYSIS): 0.95,  # High satisfaction
    (COMPARISON, DOCUMENT_GENERATION): 0.88,
    # ...
}
```

### 3. Conversational Context
Remember previous intents in conversation:
```python
# User: "Generate STAG for hadoop cdd: bdf_download"
# System: [generates report]
# User: "Now explain the differences"
# System: Uses conversation context to know which workflow
```

### 4. Batch Multi-Intent Operations
Handle requests for multiple workflows:
```python
query = "Generate STAG comparisons for all hadoop workflows and explain the differences"

# Process:
- Detect: STAG_COMPARISON + LOGIC_ANALYSIS + batch operation
- Execute: Loop through all hadoop workflows
- Return: Batch summary + individual reports
```

---

## Summary

The multi-intent chat integration provides:

✅ **Natural Language Understanding** - Extract workflows and intents from conversational queries
✅ **Multi-Intent Detection** - Detect and handle multiple objectives in single query
✅ **Context-Aware Responses** - Tailor output based on secondary intents and keywords
✅ **STAG Integration** - Full access to comprehensive comparison engine via chat
✅ **Streaming Progress** - Real-time updates during long-running operations
✅ **Intelligent Task Planning** - Combine tasks from multiple intents efficiently

**Result:** Users can interact with the system naturally and get exactly the information they need, whether it's a simple Excel file or a detailed analysis with business stages and column mappings.
