# Enhanced Lineage System Design

## Overview

Create comprehensive table-level and column-level lineage tracking that shows the complete journey of data through transformations across all systems (Ab Initio, Hadoop, Databricks).

---

## Requirements

### Table-Level Lineage
1. **Complete Journey**: Show where a table starts and all transformations it goes through IN ORDER
2. **Cross-System**: Track lineage across Ab Initio → Hadoop → Databricks
3. **Transformation Sequence**: Maintain chronological order of transformations
4. **Intermediate Tables**: Show all intermediate/staging tables in the flow

### Column-Level Lineage
1. **Column Journey**: Show complete transformation history for each column
2. **Transformation Details**: What happened at each step (CAST, CONCAT, AGGREGATE, etc.)
3. **Disambiguation**: Handle tables with same column names correctly
4. **Source Attribution**: Always know which table.column a column comes from

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                  Enhanced Lineage System                     │
└─────────────────────────────────────────────────────────────┘
                           │
           ┌───────────────┴───────────────┐
           │                               │
           ▼                               ▼
┌──────────────────────┐        ┌──────────────────────┐
│  Table Lineage Graph │        │ Column Lineage Graph │
│                      │        │                      │
│ - Source tables      │        │ - Column mappings    │
│ - Transformations    │        │ - Transformations    │
│ - Target tables      │        │ - Source attribution │
│ - Chronological order│        │ - Type tracking      │
└──────────────────────┘        └──────────────────────┘
           │                               │
           │                               │
           ▼                               ▼
┌─────────────────────────────────────────────────────────────┐
│                     Lineage Metadata Index                   │
│                                                              │
│  Stores:                                                     │
│  - Table definitions with full schema                        │
│  - Column metadata (name, type, source table)                │
│  - Transformation logic per step                             │
│  - Sequential transformation order                           │
│  - Cross-system mappings                                     │
│  - Graph structure (nodes + edges)                           │
└─────────────────────────────────────────────────────────────┘
```

---

## Data Structures

### TableLineageNode
```python
@dataclass
class TableLineageNode:
    """Represents a table in the lineage graph"""
    table_name: str                    # Fully qualified: system.database.table
    system: str                        # abinitio, hadoop, databricks
    database: str                      # Database/schema name
    table_type: str                    # source, intermediate, target
    columns: List[ColumnMetadata]      # All columns with metadata
    transformation_step: int           # Order in the transformation sequence (0=source)
    created_by: str                    # Job/graph/notebook that created it
    created_by_logic: str              # Actual transformation code
    input_tables: List[str]            # Parent tables
    output_tables: List[str]           # Child tables
    metadata: Dict[str, Any]           # Additional metadata
```

### ColumnMetadata
```python
@dataclass
class ColumnMetadata:
    """Detailed column information with disambiguation"""
    column_name: str                   # Column name
    qualified_name: str                # table.column for disambiguation
    data_type: str                     # Data type
    source_column: Optional[str]       # Parent column (qualified)
    transformation: Optional[str]      # What happened (CAST, CONCAT, etc.)
    transformation_logic: Optional[str] # Actual SQL/code
    is_derived: bool                   # True if computed/derived
    derivation_expr: Optional[str]     # Expression used to derive
    business_meaning: Optional[str]    # AI-inferred business purpose
```

### ColumnLineageChain
```python
@dataclass
class ColumnLineageChain:
    """Complete lineage for a single column"""
    target_column: str                 # Final column (qualified)
    source_columns: List[str]          # Original source columns (qualified)
    transformation_steps: List[TransformationStep]  # Ordered steps
    full_journey: str                  # Human-readable journey
    confidence: float                  # AI confidence in lineage
```

### TransformationStep
```python
@dataclass
class TransformationStep:
    """A single transformation in the lineage chain"""
    step_number: int                   # Order in sequence
    transformation_type: str           # JOIN, FILTER, AGGREGATE, CAST, etc.
    input_columns: List[str]           # Input columns (qualified)
    output_column: str                 # Output column (qualified)
    logic: str                         # Transformation SQL/code
    created_in: str                    # Job/graph/notebook
    created_in_step: str               # Specific component/activity
    metadata: Dict[str, Any]
```

---

## Lineage Graph Structure

### Table-Level Graph

```
Source Tables (Step 0)
    │
    ▼
[customer_raw]──────────────┐
    │                       │
    │ (Step 1: JOIN)        │
    ▼                       │
[customer_enriched]         │
    │                       │
    │ (Step 2: AGGREGATE)   │ (Step 1: FILTER)
    ▼                       ▼
[customer_summary]    [customer_valid]
    │                       │
    │ (Step 3: UNION)       │
    └───────────┬───────────┘
                ▼
        [customer_final] (Step 4)
```

### Column-Level Graph

```
customer_raw.customer_id (Step 0)
    │
    │ (CAST AS STRING)
    ▼
customer_enriched.cust_id (Step 1)
    │
    │ (GROUPBY - kept as-is)
    ▼
customer_summary.cust_id (Step 2)
    │
    │ (RENAME)
    ▼
customer_final.customer_identifier (Step 3)
```

---

## Disambiguation Strategy

### Problem
Multiple tables may have columns with the same name (e.g., `customer_id` in 5 different tables).

### Solution
Always use **qualified names**: `table_name.column_name`

```python
# Example
customer_raw.customer_id          # Source
customer_enriched.customer_id     # After JOIN
customer_summary.customer_id      # After AGGREGATE
customer_final.customer_id        # Final target

# Lineage knows:
# customer_final.customer_id
#   ← customer_summary.customer_id (RENAME from cust_id)
#   ← customer_enriched.cust_id (GROUPBY)
#   ← customer_enriched.customer_id (CAST from INTEGER to STRING)
#   ← customer_raw.customer_id (SOURCE)
```

---

## Transformation Detection

### From Ab Initio (.mp/.dml files)
```python
# Extract from Enhanced Parser output:
- Components: `input-table`, `filter-by-expression`, `join`, `output-table`
- Layouts: Schema definitions with column names and types
- Transforms: Reformat expressions, filter conditions

# Build lineage:
1. Identify INPUT_TABLE components → source tables
2. Trace through transform graph
3. Track column mappings in REFORMAT
4. Identify OUTPUT_TABLE components → target tables
5. Maintain sequential order based on component connections
```

### From Hadoop (.pig/.hql files)
```python
# Parse SQL/Pig scripts:
- CREATE TABLE / INSERT INTO → target tables
- FROM / JOIN → source tables
- SELECT expressions → column transformations
- WHERE clauses → filters

# Build lineage:
1. Parse DDL statements for schema
2. Parse DML statements for transformations
3. Extract column mappings from SELECT
4. Track transformation order by statement sequence
```

### From Databricks (ADF + notebooks)
```python
# Extract from ADF JSON + notebook search:
- Activities: Copy, Dataflow, Notebook
- Notebook code: PySpark DataFrame operations
- Schema definitions: df.schema, createDataFrame

# Build lineage:
1. Parse ADF pipeline for activity sequence
2. Extract source/target from Copy activities
3. Parse notebooks for DataFrame transformations
4. Track column mappings through select(), withColumn()
5. Maintain order via pipeline dependencies
```

---

## Implementation Plan

### Phase 1: Enhanced Indexing
Create enriched metadata during indexing:

```python
# For each file:
{
    "system": "hadoop",
    "file_path": "path/to/script.hql",
    "content": "CREATE TABLE...",
    "metadata": {
        # NEW: Enhanced lineage metadata
        "tables": [
            {
                "name": "customer_final",
                "type": "target",
                "database": "prod",
                "columns": [
                    {
                        "name": "customer_id",
                        "type": "STRING",
                        "source": "customer_raw.customer_id",
                        "transformation": "CAST(customer_id AS STRING)"
                    }
                ]
            }
        ],
        "transformations": [
            {
                "type": "JOIN",
                "input_tables": ["customer_raw", "address"],
                "output_table": "customer_enriched",
                "logic": "JOIN customer_raw c ON c.id = a.customer_id"
            }
        ],
        "transformation_sequence": [0, 1, 2, 3]  # Sequential order
    }
}
```

### Phase 2: Lineage Graph Builder

```python
class LineageGraphBuilder:
    """Build table and column lineage graphs"""

    def build_table_lineage(self, workflow_name: str) -> TableLineageGraph:
        """
        Build complete table lineage graph for a workflow

        Returns graph showing:
        - All source tables (step 0)
        - All intermediate tables (steps 1..n-1)
        - All target tables (step n)
        - Transformation sequence
        """

    def build_column_lineage(self, table_name: str, column_name: str) -> ColumnLineageChain:
        """
        Build complete lineage chain for a specific column

        Returns chain showing:
        - Source column(s) where it originated
        - Each transformation step in order
        - Final target column
        - Full journey in human-readable format
        """

    def trace_column_back_to_source(self, qualified_column: str) -> List[str]:
        """
        Trace a column back to its original source(s)

        Returns list of source columns (qualified names)
        """

    def get_transformation_steps(self, qualified_column: str) -> List[TransformationStep]:
        """
        Get ordered list of transformations for a column

        Returns transformation steps in chronological order
        """
```

### Phase 3: AI-Powered Lineage Extraction

Use AI to extract lineage from complex code:

```python
class AILineageExtractor:
    """AI-powered lineage extraction from code"""

    def extract_from_code(self, code: str, system: str) -> LineageMetadata:
        """
        Use AI to extract lineage from code

        Prompt:
        '''
        Analyze this {system} code and extract table/column lineage.

        Code:
        {code}

        Return JSON:
        {{
            "source_tables": [
                {{"name": "customer_raw", "columns": ["customer_id", "name"]}}
            ],
            "transformations": [
                {{
                    "type": "JOIN",
                    "inputs": ["customer_raw", "address"],
                    "output": "customer_enriched",
                    "column_mappings": [
                        {{
                            "source": "customer_raw.customer_id",
                            "target": "customer_enriched.cust_id",
                            "transformation": "CAST AS STRING"
                        }}
                    ]
                }}
            ],
            "target_tables": [
                {{"name": "customer_final", "columns": ["cust_id", "full_address"]}}
            ]
        }}
        '''
        """
```

---

## Reindexing Requirements

### What Needs Reindexing?

#### ❌ NO Reindexing Needed For:
- **STAG components** - They use existing indexed data
- **Query classifier** - Pattern matching only
- **Chat orchestrator** - Routing logic only
- **Multi-intent detection** - Uses existing vectors

#### ✅ YES - Reindexing Recommended For Enhanced Lineage:

1. **Ab Initio Collection** - Add lineage metadata
   - Extract table definitions from layouts
   - Extract transformation sequence from component graph
   - Extract column mappings from reformat expressions
   - Store in metadata.lineage

2. **Hadoop Collection** - Add lineage metadata
   - Parse DDL for table schemas
   - Parse DML for transformations
   - Extract column mappings from SELECT
   - Store transformation order

3. **Databricks Collection** - Add lineage metadata
   - Extract from ADF JSON
   - Parse notebooks for DataFrame ops
   - Track column transformations
   - Store activity sequence

### Incremental Approach (Recommended)

**Option 1: Enrich Existing Index**
- Read existing vectors
- Add lineage metadata without re-embedding
- Faster, preserves existing data

**Option 2: Parallel Index**
- Create new `lineage_metadata` collection
- Keep existing collections unchanged
- Join at query time

**Option 3: Full Reindex** (most comprehensive)
- Re-parse all files with lineage extraction
- Embed with enhanced metadata
- Best lineage quality

---

## Query Examples

### Table Lineage Query
```python
query = "Show me the complete table lineage for customer_final"

# Response:
Table Lineage for customer_final:

Source Tables (Step 0):
├─ customer_raw (abinitio.prod.customer_raw)
└─ address_master (hadoop.stage.address_master)

Step 1: Data Enrichment (JOIN)
├─ Created: customer_enriched
├─ Logic: JOIN customer_raw c ON c.id = address_master.customer_id
└─ Created by: abinitio/customer_enrich.mp (component: join_customer_address)

Step 2: Data Aggregation (GROUPBY)
├─ Created: customer_summary
├─ Logic: GROUP BY cust_id, SUM(order_total)
└─ Created by: hadoop/customer_agg.pig (line 45)

Step 3: Data Validation (FILTER)
├─ Created: customer_valid
├─ Logic: WHERE total_orders > 0 AND cust_id IS NOT NULL
└─ Created by: databricks/customer_validation.py (cell 3)

Step 4: Final Output (UNION + RENAME)
├─ Created: customer_final
├─ Logic: UNION customer_summary, customer_valid | RENAME cust_id AS customer_identifier
└─ Created by: databricks/customer_final_pipeline.py (cell 5)

Total Transformations: 4
Systems Involved: abinitio, hadoop, databricks
```

### Column Lineage Query
```python
query = "Show me column lineage for customer_final.customer_identifier"

# Response:
Column Lineage for customer_final.customer_identifier:

Journey:
customer_raw.customer_id → ... → customer_final.customer_identifier

Step 0 (SOURCE):
├─ Column: customer_raw.customer_id
├─ Type: INTEGER
└─ Source: Raw input file from CRM system

Step 1 (CAST):
├─ Column: customer_enriched.cust_id
├─ Type: STRING
├─ Logic: CAST(customer_id AS STRING)
└─ Created by: customer_enrich.mp (reformat component)

Step 2 (GROUPBY - kept as-is):
├─ Column: customer_summary.cust_id
├─ Type: STRING
├─ Logic: GROUP BY cust_id (no transformation)
└─ Created by: customer_agg.pig

Step 3 (RENAME):
├─ Column: customer_final.customer_identifier
├─ Type: STRING
├─ Logic: RENAME cust_id AS customer_identifier
└─ Created by: customer_final_pipeline.py

Source Columns: customer_raw.customer_id
Transformation Count: 3
Systems Traversed: abinitio → hadoop → databricks
```

---

## Summary

### Enhanced Lineage Provides:

✅ **Complete Table Journey** - Start to finish with all intermediate steps
✅ **Chronological Order** - Transformations in correct sequence
✅ **Column-Level Detail** - Each column's complete transformation history
✅ **Disambiguation** - Qualified names prevent confusion
✅ **Cross-System** - Tracks lineage across Ab Initio, Hadoop, Databricks
✅ **Transformation Logic** - Shows actual code for each step
✅ **AI-Powered** - Uses AI to extract complex lineage patterns

### Reindexing Recommendation:

**Incremental Approach:**
1. Keep existing indexes as-is
2. Create new `lineage_metadata` collection with enhanced data
3. Update lineage tab to query both
4. No disruption to existing functionality

**Timeline:**
- Phase 1 (Metadata Design): Complete
- Phase 2 (Lineage Extractor): 2-3 days
- Phase 3 (Graph Builder): 2-3 days
- Phase 4 (UI Integration): 1-2 days
- Phase 5 (Reindexing): 1 day

**Total: ~1 week for full implementation**
