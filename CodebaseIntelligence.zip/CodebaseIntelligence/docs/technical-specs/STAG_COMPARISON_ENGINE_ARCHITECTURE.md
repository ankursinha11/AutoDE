# STAG Comparison Engine Architecture

**Date**: 2025-11-15
**Status**: 🚧 IN PROGRESS - Design Phase

---

## 🎯 Objective

Build a comprehensive comparison engine that generates Excel reports comparing workflows across Hadoop, Ab Initio, and Databricks, matching the exact format specified in [EXCEL_COMPARISON_FORMAT_SPECIFICATION.md](EXCEL_COMPARISON_FORMAT_SPECIFICATION.md).

---

## 📋 Requirements

### Input
- **System A Workflow** (Hadoop or Ab Initio)
- **System B Workflow** (Databricks)
- **System Mapping Layer** ([system_mapping_layer.json](Input%20Files/system_mapping_layer.json))

### Output
**Excel File** with 5 sheets:
1. **Overview** - Business stage comparison
2. **Databricks Logic** - Detailed Databricks implementation
3. **[Source] Logic** - Detailed source system implementation
4. **Logic Comparison** - Side-by-side technical comparison
5. **STTM** - Source-to-Target Mapping (column-level)

---

## 🏗️ Architecture Components

### Component 1: System Mapping Service
**Purpose**: Load and query system mapping layer

**File**: `services/stag/system_mapping_service.py`

**Responsibilities**:
- Load [system_mapping_layer.json](Input%20Files/system_mapping_layer.json)
- Find Databricks pipeline for given Hadoop/Ab Initio workflow
- Handle N:1, 1:N mapping patterns
- Provide reverse lookup (Databricks → Source)

**API**:
```python
class SystemMappingService:
    def __init__(self, mapping_file: str)
    def get_databricks_mapping(self, source_system: str, source_workflow: str) -> List[str]
    def get_source_mapping(self, databricks_pipeline: str) -> Dict[str, List[str]]
    def is_n_to_1(self, source_workflows: List[str]) -> bool
    def is_1_to_n(self, source_workflow: str) -> bool
```

---

### Component 2: Logic Extractors
**Purpose**: Extract logic and transformations from each system

#### 2A: Hadoop Logic Extractor
**File**: `services/stag/hadoop_logic_extractor.py`

**Responsibilities**:
- Read Hadoop scripts (.sh, .pig, .py, .hql)
- Extract job sequence from Oozie workflow
- Parse shell commands, Pig scripts, Python logic
- Identify data sources, transformations, outputs
- Generate step-by-step logic descriptions

**API**:
```python
class HadoopLogicExtractor:
    def extract_logic(self, workflow_name: str) -> Dict[str, Any]:
        # Returns:
        # {
        #     'workflow_name': str,
        #     'jobs': [
        #         {
        #             'name': str,
        #             'script': str,
        #             'purpose': str,
        #             'logic': str,  # Step-by-step explanation
        #             'inputs': List[str],
        #             'outputs': List[str],
        #             'transformations': List[str]
        #         }
        #     ],
        #     'oozie_flow': str  # Job dependency sequence
        # }
```

#### 2B: Ab Initio Logic Extractor
**File**: `services/stag/abinitio_logic_extractor.py`

**Responsibilities**:
- Load parsed Ab Initio components (from Enhanced Parser)
- Read DML/XFR files for transformation logic
- Build graph flow from vertices/flows/ports
- Extract component transformation rules
- Generate dataset descriptions

**API**:
```python
class AbInitioLogicExtractor:
    def extract_logic(self, graph_name: str) -> Dict[str, Any]:
        # Returns:
        # {
        #     'graph_name': str,
        #     'steps': [
        #         {
        #             'step_number': str,
        #             'dataset': str,
        #             'transformation_rules': str,
        #             'components': List[str],
        #             'inputs': List[str],
        #             'outputs': List[str]
        #         }
        #     ],
        #     'graph_flow': str,  # Component dependency graph
        #     'dml_files': List[str]
        # }
```

#### 2C: Databricks Logic Extractor
**File**: `services/stag/databricks_logic_extractor.py`

**Responsibilities**:
- Parse ADF pipeline JSON for orchestration flow
- Read Databricks notebooks (.py) for logic
- Extract transformations, joins, filters, aggregations
- Identify data sources and sinks
- Generate activity descriptions with code snippets

**API**:
```python
class DatabricksLogicExtractor:
    def extract_logic(self, pipeline_name: str) -> Dict[str, Any]:
        # Returns:
        # {
        #     'pipeline_name': str,
        #     'activities': [
        #         {
        #             'name': str,
        #             'notebook': str,
        #             'purpose': str,
        #             'code_snippets': List[str],
        #             'inputs': List[str],
        #             'outputs': List[str],
        #             'transformations': List[str]
        #         }
        #     ],
        #     'orchestration_flow': str,  # Activity dependencies
        #     'conditional_branches': Dict[str, List[str]]
        # }
```

---

### Component 3: Business Stage Abstractor
**Purpose**: Convert technical steps into business-level stages using AI

**File**: `services/stag/business_stage_abstractor.py`

**Responsibilities**:
- Group related technical steps into business stages
- Generate human-readable stage descriptions
- Compare stages between systems
- Identify "Similar" vs "Different" stages
- Create Overview sheet content

**API**:
```python
class BusinessStageAbstractor:
    def __init__(self, ai_analyzer)

    def abstract_to_business_stages(
        self,
        source_logic: Dict[str, Any],
        databricks_logic: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        # Returns:
        # [
        #     {
        #         'stage_name': str,
        #         'databricks_description': str,
        #         'source_description': str,
        #         'comparison': 'Similar' | 'Different',
        #         'notes': str
        #     }
        # ]
```

**Implementation**:
- Use AI to analyze source logic and Databricks logic
- Identify equivalent stages (e.g., "Data Ingestion", "Validation", "Transformation")
- Generate natural language descriptions
- Determine if stages match conceptually

---

### Component 4: STTM Generator
**Purpose**: Generate column-level Source-to-Target Mappings

**File**: `services/stag/stag_sttm_generator.py` (wrapper around Ab Initio STTM generator)

**Responsibilities**:
- Extract source schema from Hadoop/Ab Initio
- Extract target schema from Databricks
- Use AI to infer column mappings
- Generate transformation logic (CONCAT, SPLIT, JOIN)
- List dependencies (source files, lookup tables)

**API**:
```python
class STAGSTTMGenerator:
    def __init__(self, ai_analyzer)

    def generate_sttm(
        self,
        source_logic: Dict[str, Any],
        databricks_logic: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        # Returns:
        # [
        #     {
        #         'target_column': str,
        #         'data_type': str,
        #         'source_columns': List[str],
        #         'transformation_logic': str,
        #         'dependencies': List[str]
        #     }
        # ]
```

---

### Component 5: Excel Generator
**Purpose**: Generate Excel file matching exact format specification

**File**: `services/stag/excel_generator.py`

**Responsibilities**:
- Create 5-sheet Excel workbook
- Format headers (bold, background color)
- Auto-adjust column widths
- Preserve code formatting (monospace)
- Generate download link

**API**:
```python
class STAGExcelGenerator:
    def generate_comparison_excel(
        self,
        source_system: str,
        source_workflow: str,
        databricks_pipeline: str,
        business_stages: List[Dict],
        source_logic: Dict,
        databricks_logic: Dict,
        logic_comparison: List[Dict],
        sttm_mappings: List[Dict],
        output_folder: str = "outputs/stag_comparisons"
    ) -> str:
        # Returns: Path to generated Excel file
```

**Sheet Generation Methods**:
- `_create_overview_sheet()` - Business stages
- `_create_databricks_logic_sheet()` - Activity details with code
- `_create_source_logic_sheet()` - Hadoop/Ab Initio details
- `_create_logic_comparison_sheet()` - Side-by-side comparison
- `_create_sttm_sheet()` - Column mappings

---

### Component 6: STAG Orchestrator
**Purpose**: Coordinate all components to generate complete comparison

**File**: `services/stag/stag_orchestrator.py`

**Responsibilities**:
- Load system mappings
- Extract logic from both systems
- Abstract to business stages
- Generate STTM
- Create Excel file
- Return results

**API**:
```python
class STAGOrchestrator:
    def __init__(
        self,
        indexer,
        ai_analyzer,
        system_mapping_file: str = "Input Files/system_mapping_layer.json"
    )

    def generate_comparison(
        self,
        source_system: str,  # "hadoop" or "abinitio"
        source_workflow: str,
        databricks_pipeline: str = None,  # Optional, will look up if not provided
        output_folder: str = "outputs/stag_comparisons"
    ) -> Dict[str, Any]:
        # Returns:
        # {
        #     'excel_file': str,
        #     'source_workflow': str,
        #     'databricks_pipeline': str,
        #     'business_stages': List[Dict],
        #     'sttm_count': int,
        #     'differences_count': int
        # }
```

**Process Flow**:
1. Look up Databricks mapping (if not provided)
2. Extract source logic (Hadoop or Ab Initio)
3. Extract Databricks logic
4. Abstract to business stages (AI)
5. Generate STTM (AI)
6. Generate logic comparison
7. Create Excel file
8. Return results

---

## 🔄 Data Flow

```
User Query: "Compare Hadoop ES_BDF_DOWNLOAD vs Databricks"
    ↓
Chat Orchestrator (FULL_STAG_REPORT intent)
    ↓
STAG Orchestrator
    ↓
    ├─→ System Mapping Service
    │   └─ Finds: pl_cdd_bdf_download
    │
    ├─→ Hadoop Logic Extractor
    │   ├─ Read Oozie workflow
    │   ├─ Read shell scripts
    │   ├─ Read Pig scripts
    │   └─ Returns: Hadoop logic structure
    │
    ├─→ Databricks Logic Extractor
    │   ├─ Read ADF pipeline JSON
    │   ├─ Read Databricks notebooks
    │   └─ Returns: Databricks logic structure
    │
    ├─→ Business Stage Abstractor (AI)
    │   ├─ Group technical steps
    │   ├─ Generate descriptions
    │   └─ Returns: Business stages with comparison
    │
    ├─→ STTM Generator (AI)
    │   ├─ Extract source/target schemas
    │   ├─ Infer column mappings
    │   └─ Returns: Column-level mappings
    │
    └─→ Excel Generator
        ├─ Sheet 1: Overview (business stages)
        ├─ Sheet 2: Databricks Logic
        ├─ Sheet 3: Hadoop Logic
        ├─ Sheet 4: Logic Comparison
        ├─ Sheet 5: STTM
        └─ Returns: Excel file path
    ↓
Chat Orchestrator
    ↓
User: Download link + summary
```

---

## 📦 File Structure

```
services/stag/
├── __init__.py
├── system_mapping_service.py
├── hadoop_logic_extractor.py
├── abinitio_logic_extractor.py
├── databricks_logic_extractor.py
├── business_stage_abstractor.py
├── stag_sttm_generator.py
├── excel_generator.py
└── stag_orchestrator.py
```

---

## 🧪 Testing Strategy

### Test Case 1: Hadoop → Databricks
**Input**:
- Source: Hadoop `cdd: bdf_download`
- Target: Databricks `pl_cdd_bdf_download`

**Expected Output**:
- Excel file with 5 sheets
- Business stages identified
- Code snippets extracted
- STTM generated
- Format matches manual example

---

### Test Case 2: Ab Initio → Databricks
**Input**:
- Source: Ab Initio `1300_CDD_PatientAcctsXRefPermID.pset`
- Target: Databricks `pl_cdd_bdf_download`

**Expected Output**:
- Excel file with 5 sheets
- Graph components extracted
- DML transformations documented
- STTM generated
- Format matches manual example

---

### Test Case 3: N:1 Consolidation
**Input**:
- Sources: 7 Hadoop workflows
- Target: Databricks `gmrn_create_graph_data`

**Expected Output**:
- Excel file showing consolidation
- All source workflows listed
- Merged logic comparison
- STTM for combined flows

---

## ⏱️ Implementation Plan

### Phase 1: Core Services (2-3 hours)
1. ✅ System Mapping Service
2. ✅ Hadoop Logic Extractor
3. ✅ Ab Initio Logic Extractor
4. ✅ Databricks Logic Extractor

### Phase 2: AI Components (1-2 hours)
1. ✅ Business Stage Abstractor
2. ✅ STTM Generator

### Phase 3: Excel Generation (1-2 hours)
1. ✅ Excel Generator (5 sheets)
2. ✅ Format matching validation

### Phase 4: Orchestration (1 hour)
1. ✅ STAG Orchestrator
2. ✅ Integration with Chat Orchestrator

### Phase 5: Testing (1 hour)
1. ✅ Test Case 1 (Hadoop → Databricks)
2. ✅ Test Case 2 (Ab Initio → Databricks)
3. ✅ Validate against manual examples

---

**Total Estimated Time**: 6-9 hours

**Status**: 🚧 Ready to begin implementation!

---

## 📝 Next Steps

1. Create `services/stag/` directory
2. Implement System Mapping Service
3. Implement Logic Extractors (Hadoop, Ab Initio, Databricks)
4. Implement Business Stage Abstractor (AI)
5. Implement STTM Generator
6. Implement Excel Generator
7. Implement STAG Orchestrator
8. Test with sample workflows
9. Integrate into Chat Orchestrator

---

**Ready to Build!** 🚀
