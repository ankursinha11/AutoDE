#!/bin/bash

# STAG Launcher Script
# ====================
# Quick start script for STAG Streamlit application

echo "🚀 Starting STAG - Smart Transform and Analysis Generator"
echo "=========================================================="

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "⚠️  Virtual environment not found. Creating..."
    python3 -m venv venv
fi

# Activate virtual environment
echo "📦 Activating virtual environment..."
source venv/bin/activate

# Install/upgrade requirements
echo "📥 Checking dependencies..."
pip install -q --upgrade -r requirements_stag.txt

# Check environment variables
echo "🔍 Checking Azure OpenAI configuration..."

if [ -z "$AZURE_OPENAI_API_KEY" ]; then
    echo "⚠️  AZURE_OPENAI_API_KEY not set"
    echo "   Set it with: export AZURE_OPENAI_API_KEY='your-key'"
    echo "   Or add to .env file"
fi

if [ -z "$AZURE_OPENAI_ENDPOINT" ]; then
    echo "⚠️  AZURE_OPENAI_ENDPOINT not set"
    echo "   Set it with: export AZURE_OPENAI_ENDPOINT='https://your-endpoint.openai.azure.com/'"
fi

# Load .env if exists
if [ -f ".env" ]; then
    echo "✓ Loading environment from .env file"
    export $(cat .env | grep -v '^#' | xargs)
fi

# Check if vector database exists
if [ ! -d "outputs/vector_db" ]; then
    echo ""
    echo "⚠️  Vector database not found at outputs/vector_db"
    echo "   Please index your codebase first:"
    echo "   python -c \"from services.multi_collection_indexer import MultiCollectionIndexer; indexer = MultiCollectionIndexer()\""
    echo ""
    echo "   Or use the file upload feature in STAG to index on-the-fly"
    echo ""
fi

echo ""
echo "✓ All checks complete!"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🌐 STAG is starting on remote Windows machine..."
echo ""
echo "   OPTION 1 (Recommended): VS Code Port Forwarding"
echo "   1. In VS Code, open 'PORTS' tab (bottom panel)"
echo "   2. Click 'Forward a Port'"
echo "   3. Enter: 8501"
echo "   4. Click the 🌐 icon to open in browser"
echo ""
echo "   OPTION 2: Direct URL (if port forwarding enabled)"
echo "   👉 http://localhost:8501"
echo ""
echo "   Press Ctrl+C to stop the server"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Launch Streamlit
streamlit run stag_app.py \
    --server.port 8501 \
    --server.address 0.0.0.0 \
    --server.headless true \
    --browser.gatherUsageStats false \
    --theme.base "light" \
    --theme.primaryColor "#FF4B4B" \
    --theme.backgroundColor "#FFFFFF" \
    --theme.secondaryBackgroundColor "#F0F2F6"
