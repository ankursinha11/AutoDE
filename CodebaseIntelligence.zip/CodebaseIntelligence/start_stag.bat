@echo off
REM STAG Launcher for Windows
REM =========================

echo.
echo ========================================
echo  STAG - Smart Transform Analysis
echo ========================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: Python not found!
    echo Please install Python 3.8+ from https://www.python.org/
    pause
    exit /b 1
)

REM Check if streamlit is installed
python -c "import streamlit" >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo Streamlit not found. Installing requirements...
    pip install -r requirements_stag.txt
)

REM Check environment variables
if "%AZURE_OPENAI_API_KEY%"=="" (
    echo.
    echo WARNING: AZURE_OPENAI_API_KEY not set
    echo Set it with: set AZURE_OPENAI_API_KEY=your-key
    echo Or create a .env file
    echo.
)

echo.
echo ========================================
echo  Starting STAG...
echo ========================================
echo.
echo  Open your browser and go to:
echo  http://localhost:8501
echo.
echo  In VS Code:
echo  1. Look for PORTS tab at bottom
echo  2. Click "Forward a Port"
echo  3. Enter: 8501
echo  4. Click globe icon to open
echo.
echo  Press Ctrl+C to stop the server
echo ========================================
echo.

REM Launch Streamlit
streamlit run stag_app.py --server.port 8501 --server.address 0.0.0.0 --server.headless true --browser.gatherUsageStats false --theme.base light --theme.primaryColor "#FF4B4B"

pause
