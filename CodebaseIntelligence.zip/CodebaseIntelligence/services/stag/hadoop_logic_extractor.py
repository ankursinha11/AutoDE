"""
Hadoop Logic Extractor

Extracts logic and transformations from Hadoop workflows using:
1. Vector search to find Hadoop workflow documents
2. AI analysis to extract job sequences and transformations
3. Pattern matching for common Hadoop components (Pig, Hive, Shell, Python)

Handles:
- Oozie workflow orchestration
- Shell scripts (.sh)
- Pig scripts (.pig)
- Hive queries (.hql)
- Python scripts (.py)
"""

from pathlib import Path
from typing import Dict, List, Any, Optional
from loguru import logger
import re


class HadoopLogicExtractor:
    """Extract logic from Hadoop workflows using AI analysis"""

    def __init__(self, indexer=None, ai_analyzer=None):
        """
        Initialize Hadoop Logic Extractor

        Args:
            indexer: MultiCollectionIndexer for vector search
            ai_analyzer: AIAnalyzer for natural language extraction
        """
        self.indexer = indexer
        self.ai_analyzer = ai_analyzer

    def extract_logic(self, workflow_name: str) -> Dict[str, Any]:
        """
        Extract comprehensive logic from Hadoop workflow

        Args:
            workflow_name: Name of the Hadoop workflow

        Returns:
            {
                'workflow_name': str,
                'system': 'hadoop',
                'jobs': [
                    {
                        'name': str,
                        'script': str,
                        'purpose': str,
                        'logic': str,
                        'inputs': List[str],
                        'outputs': List[str],
                        'transformations': List[str]
                    }
                ],
                'oozie_flow': str,
                'data_lineage': Dict[str, Any]
            }
        """
        logger.info(f"📊 Extracting logic for Hadoop workflow: {workflow_name}")

        # Step 1: Search for workflow documents in vector DB
        workflow_docs = self._search_workflow_documents(workflow_name)

        if not workflow_docs:
            logger.warning(f"No documents found for workflow: {workflow_name}")
            return self._create_empty_result(workflow_name)

        # Step 2: Extract job information using AI
        jobs = self._extract_jobs_with_ai(workflow_docs, workflow_name)

        # Step 3: Extract Oozie flow if available
        oozie_flow = self._extract_oozie_flow(workflow_docs)

        # Step 4: Build data lineage
        data_lineage = self._build_data_lineage(jobs)

        result = {
            'workflow_name': workflow_name,
            'system': 'hadoop',
            'jobs': jobs,
            'oozie_flow': oozie_flow,
            'data_lineage': data_lineage,
            'total_jobs': len(jobs)
        }

        logger.info(f"✅ Extracted {len(jobs)} jobs from Hadoop workflow: {workflow_name}")
        return result

    def _search_workflow_documents(self, workflow_name: str) -> List[Dict[str, Any]]:
        """Search for workflow documents in vector DB"""
        if not self.indexer:
            logger.warning("No indexer provided - cannot search for workflow documents")
            return []

        try:
            # Search in hadoop_collection
            search_results = self.indexer.search_multi_collection(
                query=f"Hadoop workflow {workflow_name} oozie orchestration jobs scripts",
                collections=["hadoop_collection"],
                top_k=20
            )

            hadoop_docs = search_results.get('hadoop_collection', [])
            logger.info(f"   Found {len(hadoop_docs)} Hadoop documents for {workflow_name}")

            return hadoop_docs

        except Exception as e:
            logger.error(f"Failed to search workflow documents: {e}")
            return []

    def _extract_jobs_with_ai(self, workflow_docs: List[Dict[str, Any]], workflow_name: str) -> List[Dict[str, Any]]:
        """Extract jobs using AI analysis of workflow documents"""
        if not self.ai_analyzer or not workflow_docs:
            # Fallback to pattern matching
            return self._extract_jobs_with_patterns(workflow_docs)

        try:
            # Combine all document content
            combined_content = "\n\n".join([
                f"Document: {doc.get('metadata', {}).get('file_name', 'Unknown')}\n{doc.get('content', '')}"
                for doc in workflow_docs
            ])

            # AI prompt to extract job information
            prompt = f"""
Analyze this Hadoop workflow and extract detailed job information.

Workflow Name: {workflow_name}

Workflow Content:
{combined_content[:20000]}  # Limit to avoid token limits

Extract the following for each job/step in the workflow:
1. Job name
2. Script file (if mentioned)
3. Purpose/description
4. Detailed logic (what does this job do?)
5. Input datasets/files
6. Output datasets/files
7. Transformations performed (filters, joins, aggregations, etc.)

Return a structured JSON array with this format:
[
  {{
    "name": "job_name",
    "script": "script_file.pig or script_file.sh",
    "purpose": "Brief purpose",
    "logic": "Detailed step-by-step logic",
    "inputs": ["input_file1", "input_file2"],
    "outputs": ["output_file1"],
    "transformations": ["Filter records where...", "Join with...", "Aggregate by..."]
  }}
]

Be specific and extract actual file names, table names, and transformation logic mentioned in the workflow.
"""

            # Get AI response
            ai_response = self.ai_analyzer.analyze(prompt)

            # Parse AI response
            jobs = self._parse_ai_response_to_jobs(ai_response)

            if jobs:
                logger.info(f"   ✅ AI extracted {len(jobs)} jobs")
                return jobs
            else:
                # Fallback to pattern matching
                logger.warning("   AI extraction failed - using pattern matching")
                return self._extract_jobs_with_patterns(workflow_docs)

        except Exception as e:
            logger.error(f"AI extraction failed: {e}")
            return self._extract_jobs_with_patterns(workflow_docs)

    def _extract_jobs_with_patterns(self, workflow_docs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Fallback: Extract jobs using pattern matching"""
        jobs = []

        for doc in workflow_docs:
            content = doc.get('content', '')
            metadata = doc.get('metadata', {})
            file_name = metadata.get('file_name', 'Unknown')

            # Pattern: Look for common Hadoop job patterns
            # Example: "pig -f script.pig", "hive -f query.hql", "bash run.sh"

            # Extract Pig jobs
            pig_matches = re.findall(r'pig\s+-f\s+(\S+\.pig)', content, re.IGNORECASE)
            for pig_script in pig_matches:
                jobs.append({
                    'name': f"Pig Job: {Path(pig_script).stem}",
                    'script': pig_script,
                    'purpose': f"Execute Pig script {pig_script}",
                    'logic': f"Runs Pig data transformation script",
                    'inputs': self._extract_inputs_from_content(content),
                    'outputs': self._extract_outputs_from_content(content),
                    'transformations': ["Pig data transformation"]
                })

            # Extract Hive jobs
            hive_matches = re.findall(r'hive\s+-f\s+(\S+\.hql)', content, re.IGNORECASE)
            for hive_script in hive_matches:
                jobs.append({
                    'name': f"Hive Job: {Path(hive_script).stem}",
                    'script': hive_script,
                    'purpose': f"Execute Hive query {hive_script}",
                    'logic': f"Runs Hive SQL transformation",
                    'inputs': self._extract_inputs_from_content(content),
                    'outputs': self._extract_outputs_from_content(content),
                    'transformations': ["Hive SQL transformation"]
                })

            # Extract Shell jobs
            shell_matches = re.findall(r'(?:bash|sh)\s+(\S+\.sh)', content, re.IGNORECASE)
            for shell_script in shell_matches:
                jobs.append({
                    'name': f"Shell Job: {Path(shell_script).stem}",
                    'script': shell_script,
                    'purpose': f"Execute shell script {shell_script}",
                    'logic': f"Runs shell commands",
                    'inputs': self._extract_inputs_from_content(content),
                    'outputs': self._extract_outputs_from_content(content),
                    'transformations': ["Shell command execution"]
                })

        # If no specific jobs found, create a generic job from the workflow
        if not jobs and workflow_docs:
            jobs.append({
                'name': workflow_docs[0].get('metadata', {}).get('file_name', 'Unknown Job'),
                'script': workflow_docs[0].get('metadata', {}).get('file_path', ''),
                'purpose': "Hadoop data processing workflow",
                'logic': workflow_docs[0].get('content', '')[:500],  # First 500 chars
                'inputs': self._extract_inputs_from_content(workflow_docs[0].get('content', '')),
                'outputs': self._extract_outputs_from_content(workflow_docs[0].get('content', '')),
                'transformations': ["Data processing"]
            })

        logger.info(f"   Pattern matching extracted {len(jobs)} jobs")
        return jobs

    def _extract_oozie_flow(self, workflow_docs: List[Dict[str, Any]]) -> str:
        """Extract Oozie workflow orchestration flow"""
        for doc in workflow_docs:
            content = doc.get('content', '')
            metadata = doc.get('metadata', {})

            # Look for Oozie workflow.xml patterns
            if 'workflow.xml' in metadata.get('file_name', '').lower() or '<workflow' in content:
                # Extract action sequence
                action_matches = re.findall(r'<action[^>]*name="([^"]+)"', content)
                if action_matches:
                    return " → ".join(action_matches)

        return "Workflow sequence not found"

    def _build_data_lineage(self, jobs: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Build data lineage from jobs"""
        all_inputs = []
        all_outputs = []

        for job in jobs:
            all_inputs.extend(job.get('inputs', []))
            all_outputs.extend(job.get('outputs', []))

        return {
            'inputs': list(set(all_inputs)),
            'outputs': list(set(all_outputs)),
            'intermediate': list(set(all_outputs) & set(all_inputs))  # Files that are both input and output
        }

    def _extract_inputs_from_content(self, content: str) -> List[str]:
        """Extract input file/table names from content"""
        inputs = []

        # Pattern: LOAD, FROM, INPUT, etc.
        load_patterns = [
            r'LOAD\s+[\'"]([^\'"]+)[\'"]',
            r'FROM\s+(\w+)',
            r'INPUT\s*=\s*[\'"]([^\'"]+)[\'"]',
            r'--input[=\s]+([^\s]+)',
        ]

        for pattern in load_patterns:
            matches = re.findall(pattern, content, re.IGNORECASE)
            inputs.extend(matches)

        return list(set(inputs))[:10]  # Limit to 10 unique inputs

    def _extract_outputs_from_content(self, content: str) -> List[str]:
        """Extract output file/table names from content"""
        outputs = []

        # Pattern: STORE, INTO, OUTPUT, etc.
        store_patterns = [
            r'STORE\s+\w+\s+INTO\s+[\'"]([^\'"]+)[\'"]',
            r'INTO\s+(\w+)',
            r'OUTPUT\s*=\s*[\'"]([^\'"]+)[\'"]',
            r'--output[=\s]+([^\s]+)',
        ]

        for pattern in store_patterns:
            matches = re.findall(pattern, content, re.IGNORECASE)
            outputs.extend(matches)

        return list(set(outputs))[:10]  # Limit to 10 unique outputs

    def _parse_ai_response_to_jobs(self, ai_response: str) -> List[Dict[str, Any]]:
        """Parse AI response into job structures"""
        import json

        try:
            # Try to extract JSON array from response
            # AI might wrap it in markdown code blocks
            json_match = re.search(r'```(?:json)?\s*(\[.*?\])\s*```', ai_response, re.DOTALL)
            if json_match:
                json_str = json_match.group(1)
            else:
                # Try to find JSON array directly
                json_match = re.search(r'\[.*\]', ai_response, re.DOTALL)
                if json_match:
                    json_str = json_match.group(0)
                else:
                    return []

            jobs = json.loads(json_str)

            # Validate structure
            if isinstance(jobs, list):
                return jobs
            else:
                return []

        except Exception as e:
            logger.warning(f"Failed to parse AI response as JSON: {e}")
            return []

    def _create_empty_result(self, workflow_name: str) -> Dict[str, Any]:
        """Create empty result when no workflow found"""
        return {
            'workflow_name': workflow_name,
            'system': 'hadoop',
            'jobs': [],
            'oozie_flow': '',
            'data_lineage': {'inputs': [], 'outputs': [], 'intermediate': []},
            'total_jobs': 0
        }


# Example usage
if __name__ == "__main__":
    # Test without indexer/AI (pattern matching only)
    extractor = HadoopLogicExtractor()

    print("\n" + "=" * 80)
    print("HADOOP LOGIC EXTRACTOR TEST")
    print("=" * 80)

    # Test with sample workflow
    test_workflow = "ES_BDF_DOWNLOAD"

    print(f"\nTesting workflow: {test_workflow}")
    print("Note: Without indexer/AI, this will return empty result")

    result = extractor.extract_logic(test_workflow)

    print(f"\n✅ Extraction Result:")
    print(f"   Workflow: {result['workflow_name']}")
    print(f"   System: {result['system']}")
    print(f"   Total Jobs: {result['total_jobs']}")
    print(f"   Oozie Flow: {result['oozie_flow']}")

    if result['jobs']:
        print(f"\n   Jobs:")
        for i, job in enumerate(result['jobs'], 1):
            print(f"      {i}. {job['name']}")
            print(f"         Script: {job['script']}")
            print(f"         Purpose: {job['purpose']}")

    print("\n" + "=" * 80)
    print("Note: Full functionality requires indexer and AI analyzer")
    print("=" * 80)
