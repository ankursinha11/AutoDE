#!/usr/bin/env python3
"""
Workflow Migration Validation Script
Run this to validate Hadoop→Databricks migration and Databricks↔Ab Initio correlation
"""

import sys
from pathlib import Path

# Add current directory to path
sys.path.insert(0, str(Path(__file__).parent))

from services.workflow_integration import WorkflowIntegration


def main():
    """Run workflow validation analysis"""
    print("\n" + "=" * 70)
    print("WORKFLOW MIGRATION VALIDATION")
    print("Validating Hadoop→Databricks migration (2 years ago)")
    print("Analyzing Databricks↔Ab Initio correlation (current)")
    print("=" * 70)

    # Configuration
    hadoop_repo_path = "./hadoop_repos/hadoop_repos"
    databricks_analysis = "databricks_pipeline_analysis.json"
    abinitio_mappings = "abinitio_graph_mappings.json"
    similarity_threshold = 0.3  # Lower threshold to catch more potential mappings
    output_dir = "./outputs"

    # Check if required files exist
    required_files = [
        (hadoop_repo_path, "Hadoop repository"),
        (databricks_analysis, "Databricks analysis"),
    ]

    missing_files = []
    for file_path, description in required_files:
        if not Path(file_path).exists():
            missing_files.append(f"{description}: {file_path}")

    if missing_files:
        print("\n⚠️ MISSING REQUIRED FILES:")
        for missing in missing_files:
            print(f"   - {missing}")
        print("\n💡 Make sure you have:")
        print("   1. Hadoop repository at: ./hadoop_repos/hadoop_repos")
        print("   2. Databricks analysis at: ./databricks_pipeline_analysis.json")
        print("      (Run databricks_analyzer.py first if missing)")
        print("   3. (Optional) Ab Initio mappings at: ./abinitio_graph_mappings.json")
        return

    # Check Ab Initio (optional)
    has_abinitio = Path(abinitio_mappings).exists()
    if not has_abinitio:
        print("\nℹ️ Ab Initio mappings not found (optional) - will skip Ab Initio correlation")

    # Run validation
    try:
        integration = WorkflowIntegration()

        integration.run_complete_analysis(
            hadoop_repo_path=hadoop_repo_path,
            databricks_analysis_file=databricks_analysis,
            abinitio_mappings_file=abinitio_mappings if has_abinitio else None,
            similarity_threshold=similarity_threshold,
            output_dir=output_dir
        )

        print("\n" + "=" * 70)
        print("📁 VALIDATION COMPLETE!")
        print("=" * 70)
        print(f"\n📊 Reports available in: {output_dir}/")
        print("\nGenerated files:")
        print("   1. hadoop_to_databricks_validation.json")
        print("      → Migration completeness report")
        print("      → Unmapped workflows (gaps)")
        print("      → Confidence scores")
        if has_abinitio:
            print("   2. databricks_to_abinitio_correlation.json")
            print("      → Databricks↔Ab Initio correlation analysis")
        print("   3. workflow_mappings.json")
        print("      → All detected workflow mappings")
        print("      → 1:1, N:1, and 1:N relationships")

        print("\n💡 NEXT STEPS:")
        print("   1. Review validation reports in outputs/ directory")
        print("   2. Check unmapped workflows (potential migration gaps)")
        print("   3. Verify N:1 mappings (workflow consolidation)")
        print("   4. Investigate critical gaps (business-critical workflows)")

        print("\n🔍 TO QUERY SPECIFIC WORKFLOW MAPPINGS:")
        print("   from services.workflow_integration import WorkflowIntegration")
        print("   integration = WorkflowIntegration()")
        print("   # Load data first, then:")
        print("   mappings = integration.get_mapping_for_workflow('ie_prebdf')")

    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        print("\nTroubleshooting:")
        print("   - Verify all file paths are correct")
        print("   - Check that Databricks analysis JSON is valid")
        print("   - Ensure Hadoop repository contains .pig, .hql, or .py files")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
