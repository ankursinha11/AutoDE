@echo off
REM Quick fix script for Windows - Deletes Python cache

echo ========================================
echo   Fixing Python Cache Issues
echo ========================================
echo.

echo Deleting all __pycache__ folders...
for /d /r %%i in (__pycache__) do @if exist "%%i" (
    echo Deleting: %%i
    rmdir /s /q "%%i"
)

echo.
echo Deleting all .pyc files...
del /s /q *.pyc 2>nul

echo.
echo ========================================
echo   Cache Cleaned!
echo ========================================
echo.

echo Now run:
echo   python VERIFY_FIX.py
echo.

pause
